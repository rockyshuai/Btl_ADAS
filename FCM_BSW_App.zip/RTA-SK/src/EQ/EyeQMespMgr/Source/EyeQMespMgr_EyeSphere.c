
/******************************************************************************

WBTL ELECTRONIC document

Copyright WBTL. All rights reserved.

******************************************************************************/
/******************************************************************************

@details
   <Describes details of this component implementation and design>

******************************************************************************/
/******************************************************************************
External Dependencies
******************************************************************************/
#include <EyeQMespMgr.h>
#include <EyeQMespMgr_EyeSphere.h>
#include <EyeQMespMgr_Intl.h>
#include <EyeQAppl.h>

/******************************************************************************
Component Defines
******************************************************************************/
#define EYEQMESPMGR_EYESPHERE_CMD_OFFSET       (4u)

/******************************************************************************
Component Types
******************************************************************************/
typedef struct EyeQMespMgr_EyeSphereDataTypeTag
{
   EyeQMespMgr_EyeSphereRetType LastCmdRetValue[EYEQMESPMGR_EYESPHERE_IDX_NUM];
   EyeQMespMgr_ReqCallbackFct CallbackFctPtr[EYEQMESPMGR_EYESPHERE_IDX_NUM];
   EyeQMespMgr_EyeSphereStsType Status;
   EyeQMespMgr_EyeSphereFctIdType ActiveFunction;
   EyeQAppl_CallbackStsType LastApplStatus[EYEQMESPMGR_EYESPHERE_IDX_NUM];
   uint16 RequestTimer;
   uint16 TxCmdStringLength;
   uint16 RxCmdStringLength;
   uint8 RxCmdString[EYEQMESPMGR_EYESPHERE_CMD_BUFF_SIZE];
   boolean Requested[EYEQMESPMGR_EYESPHERE_IDX_NUM];
   boolean IsOkOnce[EYEQMESPMGR_EYESPHERE_IDX_NUM];
   boolean IsLastOk[EYEQMESPMGR_EYESPHERE_IDX_NUM];
   boolean ProcessStatus;
}EyeQMespMgr_EyeSphereDataType;

/******************************************************************************
Declaration of Local Functions
******************************************************************************/
LOCAL_INLINE FUNC(Std_ReturnType, EyeQMespMgr_CODE) eyeqmespmgr_EyeSphereCmd(void);
LOCAL_INLINE FUNC(Std_ReturnType, EyeQMespMgr_CODE) eyeqmespmgr_EyeSphereReset(void);
LOCAL_INLINE FUNC(Std_ReturnType, EyeQMespMgr_CODE) eyeqmespmgr_EyeSphereHalt(void);

#define EyeQMespMgr_START_SEC_VAR
#include "EyeQMespMgr_MemMap.h"
/******************************************************************************
Definition Of Local Variables
******************************************************************************/
LOCAL VAR(EyeQMespMgr_EyeSphereDataType, EyeQMespMgr_VAR) EyeQMespMgr_EyeSphereData;

/******************************************************************************
Definition Of Global Variables
******************************************************************************/
VAR(uint32, EyeQMespMgr_VAR) EyeQMespMgr_EyeSphereRespLength;
VAR(uint8, EyeQMespMgr_VAR) EyeQMespMgr_EyeSphereRespData[EYEQMESPMGR_EYESPHERE_RESP_BUFF_SIZE];
VAR(uint8, EyeQMespMgr_VAR) EyeQMespMgr_EyeSphereCmdTxData[EYEQMESPMGR_EYESPHERE_CMD_BUFF_SIZE];

#define EyeQMespMgr_STOP_SEC_VAR
#include "EyeQMespMgr_MemMap.h"

#define EyeQMespMgr_START_SEC_CONST
#include "EyeQMespMgr_MemMap.h"
/******************************************************************************
Definition Of Local Constant Data
******************************************************************************/

/******************************************************************************
Definition Of Global Constant Data
******************************************************************************/

#define EyeQMespMgr_STOP_SEC_CONST
#include "EyeQMespMgr_MemMap.h"
/******************************************************************************
Component Function-like Macros
******************************************************************************/
#define EyeQMespMgr_GetRespRet()          (*(uint32*)EyeQMespMgr_EyeSphereRespData)

/******************************************************************************
Definition Of APIs
******************************************************************************/
#define EyeQMespMgr_START_SEC_CODE
#include "EyeQMespMgr_MemMap.h"

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQMespMgr_CODE) EyeQMespMgr_EyeSphereInit(void)
{
   EyeQMespMgr_EyeSphereIdxType function_index;

   for (function_index = 0; function_index < EYEQMESPMGR_EYESPHERE_IDX_NUM; function_index++)
   {
      EyeQMespMgr_EyeSphereData.IsLastOk[function_index] = FALSE;
      EyeQMespMgr_EyeSphereData.IsOkOnce[function_index] = FALSE;
      EyeQMespMgr_EyeSphereData.Requested[function_index] = FALSE;
      EyeQMespMgr_EyeSphereData.LastApplStatus[function_index] = EYEQAPPL_CB_STS_TX_FAILED;
      EyeQMespMgr_EyeSphereData.LastCmdRetValue[function_index] = EYEQMESPMGR_EYESPHERE_RET_OK;
   }
   EyeQMespMgr_EyeSphereData.ActiveFunction = EYEQMESPMGR_EYESPHERE_FCT_ID_NULL;
   EyeQMespMgr_EyeSphereData.Status = 0u;
   EyeQMespMgr_EyeSphereData.RequestTimer = 0u;
   EyeQMespMgr_EyeSphereData.TxCmdStringLength = 0u;
   EyeQMespMgr_EyeSphereData.RxCmdStringLength = 0u;
   EyeQMespMgr_EyeSphereData.ProcessStatus = FALSE;
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQMespMgr_CODE) EyeQMespMgr_EyeSphereMainFunction(void)
{
   Std_ReturnType ret;
   EyeQMespMgr_EyeSphereIdxType fct_index;

   if (EYEQMESPMGR_EYESPHERE_FCT_ID_NULL == EyeQMespMgr_EyeSphereData.ActiveFunction)
   {
      fct_index = 0u;
      while (fct_index < EYEQMESPMGR_EYESPHERE_IDX_NUM)
      {
         if (FALSE != EyeQMespMgr_EyeSphereData.Requested[fct_index])
         {
            switch (fct_index)
            {
               case EYEQMESPMGR_EYESPHERE_IDX_CMD:
               {
                  ret = eyeqmespmgr_EyeSphereCmd();
                  if (E_OK == ret)
                  {
                     EyeQMespMgr_EyeSphereData.RequestTimer = 0u;
                  }

                  break;
               }
               case EYEQMESPMGR_EYESPHERE_IDX_RESET:
               {
                  ret = eyeqmespmgr_EyeSphereReset();
                  if (E_OK == ret)
                  {
                     EyeQMespMgr_EyeSphereData.RequestTimer = 0u;
                  }

                  break;
               }
               case EYEQMESPMGR_EYESPHERE_IDX_HALT:
               {
                  ret = eyeqmespmgr_EyeSphereHalt();
                  if (E_OK == ret)
                  {
                     EyeQMespMgr_EyeSphereData.RequestTimer = 0u;
                  }

                  break;
               }
               default:
                  break;
            }
            fct_index = EYEQMESPMGR_EYESPHERE_IDX_NUM;
         }
         else
         {
            fct_index++;
         }

      }
   }
   else
   {
      /* check if timeout */
      EyeQMespMgr_EyeSphereData.RequestTimer++;
      if (EYEQMESPMGR_REQ_TIMEOUT_CNT < EyeQMespMgr_EyeSphereData.RequestTimer)
      {
         EyeQMespMgr_EyeSphereData.RequestTimer = 0u;
         fct_index = EyeQMespMgr_EyeSphereConvertFctIdToIdx(EyeQMespMgr_EyeSphereData.ActiveFunction);
         EyeQMespMgr_EyeSphereData.Status |= EYEQMESPMGR_EYESPHERE_STS_REQ_TIMEOUT;
         EyeQMespMgr_EyeSphereData.ProcessStatus = TRUE;
         EyeQMespMgr_EyeSphereData.Requested[fct_index] = FALSE;
         EyeQMespMgr_EyeSphereData.ActiveFunction = EYEQMESPMGR_EYESPHERE_FCT_ID_NULL;
         if (NULL_PTR != EyeQMespMgr_EyeSphereData.CallbackFctPtr[fct_index])
         {
            EyeQMespMgr_EyeSphereData.CallbackFctPtr[fct_index](EYEQMESPMGR_CB_STS_REQ_FAILED);
         }
      }
   }

   if (FALSE != EyeQMespMgr_EyeSphereData.ProcessStatus)
   {
      if (0u == EyeQMespMgr_EyeSphereData.Status)
      {
         Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQMESPMGR_E_EYESPHERE_RET_ERR, DEM_EVENT_STATUS_PREPASSED);
      }
      else
      {
         Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQMESPMGR_E_EYESPHERE_RET_ERR, DEM_EVENT_STATUS_PREFAILED);
      }
      EyeQMespMgr_EyeSphereData.Status = 0u;
      EyeQMespMgr_EyeSphereData.ProcessStatus = FALSE;
   }
}
/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
LOCAL_INLINE FUNC(Std_ReturnType, EyeQMespMgr_CODE) eyeqmespmgr_EyeSphereCmd(void)
{
   Std_ReturnType ret;

   ret = EyeQAppl_TxRequest(EYEQMESPMGR_SRV_ID_EYESPHERE, EYEQMESPMGR_EYESPHERE_FCT_ID_CMD);
   if (E_OK == ret)
   {
      EyeQMespMgr_EyeSphereData.ActiveFunction = EYEQMESPMGR_EYESPHERE_FCT_ID_CMD;
   }

   return (ret);
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
LOCAL_INLINE FUNC(Std_ReturnType, EyeQMespMgr_CODE) eyeqmespmgr_EyeSphereReset(void)
{
   Std_ReturnType ret;

   ret = EyeQAppl_TxRequest(EYEQMESPMGR_SRV_ID_EYESPHERE, EYEQMESPMGR_EYESPHERE_FCT_ID_RESET);
   if (E_OK == ret)
   {
      EyeQMespMgr_EyeSphereData.ActiveFunction = EYEQMESPMGR_EYESPHERE_FCT_ID_RESET;
   }

   return (ret);
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
LOCAL_INLINE FUNC(Std_ReturnType, EyeQMespMgr_CODE) eyeqmespmgr_EyeSphereHalt(void)
{
   Std_ReturnType ret;

   ret = EyeQAppl_TxRequest(EYEQMESPMGR_SRV_ID_EYESPHERE, EYEQMESPMGR_EYESPHERE_FCT_ID_HALT);
   if (E_OK == ret)
   {
      EyeQMespMgr_EyeSphereData.ActiveFunction = EYEQMESPMGR_EYESPHERE_FCT_ID_HALT;
   }

   return (ret);
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQMespMgr_CODE) EyeQMespMgr_EyeSphereCmdCallback(CONST(EyeQAppl_CallbackStsType, AUTOMATIC)Status)
{
   uint32 resp_ret;
   uint8_least string_index;

   if (EYEQMESPMGR_EYESPHERE_FCT_ID_CMD == EyeQMespMgr_EyeSphereData.ActiveFunction)
   {
      EyeQMespMgr_EyeSphereData.LastApplStatus[EYEQMESPMGR_EYESPHERE_IDX_CMD] = Status;
      switch (Status)
      {
         case EYEQAPPL_CB_STS_RX_FAILED:
         case EYEQAPPL_CB_STS_TX_FAILED:
         {
            EyeQMespMgr_EyeSphereData.IsLastOk[EYEQMESPMGR_EYESPHERE_IDX_CMD] = FALSE;
            EyeQMespMgr_EyeSphereData.Status |= EYEQMESPMGR_EYESPHERE_STS_APPL_FAILED;
            if (NULL_PTR != EyeQMespMgr_EyeSphereData.CallbackFctPtr[EYEQMESPMGR_EYESPHERE_IDX_CMD])
            {
               EyeQMespMgr_EyeSphereData.CallbackFctPtr[EYEQMESPMGR_EYESPHERE_IDX_CMD](EYEQMESPMGR_CB_STS_REQ_FAILED);
            }
            EyeQMespMgr_EyeSphereData.ActiveFunction = EYEQMESPMGR_EYESPHERE_FCT_ID_NULL;
            EyeQMespMgr_EyeSphereData.Requested[EYEQMESPMGR_EYESPHERE_IDX_CMD] = FALSE;
            break;
         }
         case EYEQAPPL_CB_STS_RX_OK:
         {
            resp_ret = EyeQMespMgr_GetRespRet();
            EyeQMespMgr_EyeSphereData.LastCmdRetValue[EYEQMESPMGR_EYESPHERE_IDX_CMD] = resp_ret;
            if (EYEQMESPMGR_EYESPHERE_RET_OK == resp_ret)
            {
               if ((EYEQMESPMGR_EYESPHERE_CMD_BUFF_SIZE >= (EyeQMespMgr_EyeSphereRespLength - EYEQMESPMGR_EYESPHERE_CMD_OFFSET))
                  && (EYEQMESPMGR_EYESPHERE_CMD_OFFSET < EyeQMespMgr_EyeSphereRespLength))
               {
                  for (string_index = 0u; string_index < (EyeQMespMgr_EyeSphereRespLength - EYEQMESPMGR_EYESPHERE_CMD_OFFSET); string_index++)
                  {
                     EyeQMespMgr_EyeSphereData.RxCmdString[string_index] = EyeQMespMgr_EyeSphereRespData[string_index + EYEQMESPMGR_EYESPHERE_CMD_OFFSET];
                  }
                  EyeQMespMgr_EyeSphereData.RxCmdStringLength = EyeQMespMgr_EyeSphereRespLength - EYEQMESPMGR_EYESPHERE_CMD_OFFSET;
                  EyeQMespMgr_EyeSphereData.IsLastOk[EYEQMESPMGR_EYESPHERE_IDX_CMD] = TRUE;
                  EyeQMespMgr_EyeSphereData.IsOkOnce[EYEQMESPMGR_EYESPHERE_IDX_CMD] = TRUE;
                  if (NULL_PTR != EyeQMespMgr_EyeSphereData.CallbackFctPtr[EYEQMESPMGR_EYESPHERE_IDX_CMD])
                  {
                     EyeQMespMgr_EyeSphereData.CallbackFctPtr[EYEQMESPMGR_EYESPHERE_IDX_CMD](EYEQMESPMGR_CB_STS_REQ_FINISHED);
                  }
               }
               else
               {
                  EyeQMespMgr_EyeSphereData.IsLastOk[EYEQMESPMGR_EYESPHERE_IDX_CMD] = FALSE;
                  EyeQMespMgr_EyeSphereData.Status |= EYEQMESPMGR_EYESPHERE_STS_DATA_ERROR;
                  if (NULL_PTR != EyeQMespMgr_EyeSphereData.CallbackFctPtr[EYEQMESPMGR_EYESPHERE_IDX_CMD])
                  {
                     EyeQMespMgr_EyeSphereData.CallbackFctPtr[EYEQMESPMGR_EYESPHERE_IDX_CMD](EYEQMESPMGR_CB_STS_REQ_FAILED);
                  }
               }
            }
            else
            {
               EyeQMespMgr_EyeSphereData.IsLastOk[EYEQMESPMGR_EYESPHERE_IDX_CMD] = FALSE;
               EyeQMespMgr_EyeSphereData.Status |= EYEQMESPMGR_EYESPHERE_STS_RET_ERROR;
               if (NULL_PTR != EyeQMespMgr_EyeSphereData.CallbackFctPtr[EYEQMESPMGR_EYESPHERE_IDX_CMD])
               {
                  EyeQMespMgr_EyeSphereData.CallbackFctPtr[EYEQMESPMGR_EYESPHERE_IDX_CMD](EYEQMESPMGR_CB_STS_REQ_FAILED);
               }
            }
            EyeQMespMgr_EyeSphereData.ActiveFunction = EYEQMESPMGR_EYESPHERE_FCT_ID_NULL;
            EyeQMespMgr_EyeSphereData.Requested[EYEQMESPMGR_EYESPHERE_IDX_CMD] = FALSE;
            break;
         }
         case EYEQAPPL_CB_STS_TX_OK:
         case EYEQAPPL_CB_STS_RX_NEW_FRAME:
         default:
            break;
      }
   }
   else
   {
      EyeQMespMgr_EyeSphereData.Status |= EYEQMESPMGR_EYESPHERE_STS_INVALID_RESP;
   }
   EyeQMespMgr_EyeSphereData.ProcessStatus = TRUE;
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQMespMgr_CODE) EyeQMespMgr_EyeSphereResetCallback(CONST(EyeQAppl_CallbackStsType, AUTOMATIC)Status)
{
   uint32 resp_ret;

   if (EYEQMESPMGR_EYESPHERE_FCT_ID_RESET == EyeQMespMgr_EyeSphereData.ActiveFunction)
   {
      EyeQMespMgr_EyeSphereData.LastApplStatus[EYEQMESPMGR_EYESPHERE_IDX_RESET] = Status;
      switch (Status)
      {
         case EYEQAPPL_CB_STS_RX_FAILED:
         case EYEQAPPL_CB_STS_TX_FAILED:
         {
            EyeQMespMgr_EyeSphereData.IsLastOk[EYEQMESPMGR_EYESPHERE_IDX_RESET] = FALSE;
            EyeQMespMgr_EyeSphereData.Status |= EYEQMESPMGR_EYESPHERE_STS_APPL_FAILED;
            if (NULL_PTR != EyeQMespMgr_EyeSphereData.CallbackFctPtr[EYEQMESPMGR_EYESPHERE_IDX_RESET])
            {
               EyeQMespMgr_EyeSphereData.CallbackFctPtr[EYEQMESPMGR_EYESPHERE_IDX_RESET](EYEQMESPMGR_CB_STS_REQ_FAILED);
            }
            EyeQMespMgr_EyeSphereData.ActiveFunction = EYEQMESPMGR_EYESPHERE_FCT_ID_NULL;
            EyeQMespMgr_EyeSphereData.Requested[EYEQMESPMGR_EYESPHERE_IDX_RESET] = FALSE;
            break;
         }
         case EYEQAPPL_CB_STS_RX_OK:
         {
            resp_ret = EyeQMespMgr_GetRespRet();
            EyeQMespMgr_EyeSphereData.LastCmdRetValue[EYEQMESPMGR_EYESPHERE_IDX_RESET] = resp_ret;
            if (EYEQMESPMGR_EYESPHERE_RET_OK == resp_ret)
            {
               EyeQMespMgr_EyeSphereData.IsLastOk[EYEQMESPMGR_EYESPHERE_IDX_RESET] = TRUE;
               EyeQMespMgr_EyeSphereData.IsOkOnce[EYEQMESPMGR_EYESPHERE_IDX_RESET] = TRUE;
               if (NULL_PTR != EyeQMespMgr_EyeSphereData.CallbackFctPtr[EYEQMESPMGR_EYESPHERE_IDX_RESET])
               {
                  EyeQMespMgr_EyeSphereData.CallbackFctPtr[EYEQMESPMGR_EYESPHERE_IDX_RESET](EYEQMESPMGR_CB_STS_REQ_FINISHED);
               }
            }
            else
            {
               EyeQMespMgr_EyeSphereData.IsLastOk[EYEQMESPMGR_EYESPHERE_IDX_RESET] = FALSE;
               EyeQMespMgr_EyeSphereData.Status |= EYEQMESPMGR_EYESPHERE_STS_RET_ERROR;
               if (NULL_PTR != EyeQMespMgr_EyeSphereData.CallbackFctPtr[EYEQMESPMGR_EYESPHERE_IDX_RESET])
               {
                  EyeQMespMgr_EyeSphereData.CallbackFctPtr[EYEQMESPMGR_EYESPHERE_IDX_RESET](EYEQMESPMGR_CB_STS_REQ_FAILED);
               }
            }
            EyeQMespMgr_EyeSphereData.ActiveFunction = EYEQMESPMGR_EYESPHERE_FCT_ID_NULL;
            EyeQMespMgr_EyeSphereData.Requested[EYEQMESPMGR_EYESPHERE_IDX_RESET] = FALSE;
            break;
         }
         case EYEQAPPL_CB_STS_TX_OK:
         case EYEQAPPL_CB_STS_RX_NEW_FRAME:
         default:
            break;
      }
   }
   else
   {
      EyeQMespMgr_EyeSphereData.Status |= EYEQMESPMGR_EYESPHERE_STS_INVALID_RESP;
   }
   EyeQMespMgr_EyeSphereData.ProcessStatus = TRUE;
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQMespMgr_CODE) EyeQMespMgr_EyeSphereHaltCallback(CONST(EyeQAppl_CallbackStsType, AUTOMATIC)Status)
{
   uint32 resp_ret;

   if (EYEQMESPMGR_EYESPHERE_FCT_ID_HALT == EyeQMespMgr_EyeSphereData.ActiveFunction)
   {
      EyeQMespMgr_EyeSphereData.LastApplStatus[EYEQMESPMGR_EYESPHERE_IDX_HALT] = Status;
      switch (Status)
      {
         case EYEQAPPL_CB_STS_RX_FAILED:
         case EYEQAPPL_CB_STS_TX_FAILED:
         {
            EyeQMespMgr_EyeSphereData.IsLastOk[EYEQMESPMGR_EYESPHERE_IDX_HALT] = FALSE;
            EyeQMespMgr_EyeSphereData.Status |= EYEQMESPMGR_EYESPHERE_STS_APPL_FAILED;
            if (NULL_PTR != EyeQMespMgr_EyeSphereData.CallbackFctPtr[EYEQMESPMGR_EYESPHERE_IDX_HALT])
            {
               EyeQMespMgr_EyeSphereData.CallbackFctPtr[EYEQMESPMGR_EYESPHERE_IDX_HALT](EYEQMESPMGR_CB_STS_REQ_FAILED);
            }
            break;
         }
         case EYEQAPPL_CB_STS_RX_OK:
         {
            resp_ret = EyeQMespMgr_GetRespRet();
            EyeQMespMgr_EyeSphereData.LastCmdRetValue[EYEQMESPMGR_EYESPHERE_IDX_HALT] = resp_ret;
            EyeQMespMgr_EyeSphereData.ActiveFunction = EYEQMESPMGR_EYESPHERE_FCT_ID_NULL;
            EyeQMespMgr_EyeSphereData.Requested[EYEQMESPMGR_EYESPHERE_IDX_HALT] = FALSE;
            if (EYEQMESPMGR_EYESPHERE_RET_OK == resp_ret)
            {
               EyeQMespMgr_EyeSphereData.IsLastOk[EYEQMESPMGR_EYESPHERE_IDX_HALT] = TRUE;
               EyeQMespMgr_EyeSphereData.IsOkOnce[EYEQMESPMGR_EYESPHERE_IDX_HALT] = TRUE;
               if (NULL_PTR != EyeQMespMgr_EyeSphereData.CallbackFctPtr[EYEQMESPMGR_EYESPHERE_IDX_HALT])
               {
                  EyeQMespMgr_EyeSphereData.CallbackFctPtr[EYEQMESPMGR_EYESPHERE_IDX_HALT](EYEQMESPMGR_CB_STS_REQ_FINISHED);
               }
            }
            else
            {
               EyeQMespMgr_EyeSphereData.IsLastOk[EYEQMESPMGR_EYESPHERE_IDX_HALT] = FALSE;
               EyeQMespMgr_EyeSphereData.Status |= EYEQMESPMGR_EYESPHERE_STS_RET_ERROR;
               if (NULL_PTR != EyeQMespMgr_EyeSphereData.CallbackFctPtr[EYEQMESPMGR_EYESPHERE_IDX_HALT])
               {
                  EyeQMespMgr_EyeSphereData.CallbackFctPtr[EYEQMESPMGR_EYESPHERE_IDX_HALT](EYEQMESPMGR_CB_STS_REQ_FAILED);
               }
            }
            EyeQMespMgr_EyeSphereData.ActiveFunction = EYEQMESPMGR_EYESPHERE_FCT_ID_NULL;
            EyeQMespMgr_EyeSphereData.Requested[EYEQMESPMGR_EYESPHERE_IDX_HALT] = FALSE;
            break;
         }
         case EYEQAPPL_CB_STS_TX_OK:
         case EYEQAPPL_CB_STS_RX_NEW_FRAME:
         default:
            break;
      }
   }
   else
   {
      EyeQMespMgr_EyeSphereData.Status |= EYEQMESPMGR_EYESPHERE_STS_INVALID_RESP;
   }
   EyeQMespMgr_EyeSphereData.ProcessStatus = TRUE;
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(Std_ReturnType, EyeQMespMgr_CODE) EyeQMespMgr_EyeSphereCmd(CONST(EyeQMespMgr_ReqCallbackFct, AUTOMATIC) CallbackFctPtr, 
   CONSTP2CONST(uint8, AUTOMATIC, EyeQMespMgr_APPL_CONST) CmdPtr, CONST(uint16, AUTOMATIC) CmdLength)
{
   Std_ReturnType ret;
   uint8_least data_index;
   uint8* src_ptr;
   uint8* dst_ptr;

   if ((FALSE == EyeQMespMgr_EyeSphereData.Requested[EYEQMESPMGR_EYESPHERE_IDX_CMD])
      && (CmdLength < EYEQMESPMGR_EYESPHERE_CMD_BUFF_SIZE)
      && ((0u == CmdLength) || (NULL_PTR != CmdPtr)))
   {
      dst_ptr = &EyeQMespMgr_EyeSphereCmdTxData[0];
      src_ptr = (uint8*)CmdPtr;
      for (data_index = 0u; data_index < CmdLength; data_index++)
      {
         *dst_ptr = *src_ptr;
         dst_ptr++;
         src_ptr++;
      }
      EyeQMespMgr_EyeSphereData.TxCmdStringLength = CmdLength;
      EyeQMespMgr_EyeSphereData.CallbackFctPtr[EYEQMESPMGR_EYESPHERE_IDX_CMD] = CallbackFctPtr;
      EyeQMespMgr_EyeSphereData.Requested[EYEQMESPMGR_EYESPHERE_IDX_CMD] = TRUE;
      ret = E_OK;
   }
   else
   {
      ret = E_NOT_OK;
   }

   return (ret);
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(Std_ReturnType, EyeQMespMgr_CODE) EyeQMespMgr_EyeSphereReset(CONST(EyeQMespMgr_ReqCallbackFct, AUTOMATIC) CallbackFctPtr)
{
   Std_ReturnType ret;

   if (FALSE == EyeQMespMgr_EyeSphereData.Requested[EYEQMESPMGR_EYESPHERE_IDX_RESET])
   {
      EyeQMespMgr_EyeSphereData.CallbackFctPtr[EYEQMESPMGR_EYESPHERE_IDX_RESET] = CallbackFctPtr;
      EyeQMespMgr_EyeSphereData.Requested[EYEQMESPMGR_EYESPHERE_IDX_RESET] = TRUE;
      ret = E_OK;
   }
   else
   {
      ret = E_NOT_OK;
   }

   return (ret);
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(Std_ReturnType, EyeQMespMgr_CODE) EyeQMespMgr_EyeSphereHalt(CONST(EyeQMespMgr_ReqCallbackFct, AUTOMATIC) CallbackFctPtr)
{
   Std_ReturnType ret;

   if (FALSE == EyeQMespMgr_EyeSphereData.Requested[EYEQMESPMGR_EYESPHERE_IDX_HALT])
   {
      EyeQMespMgr_EyeSphereData.Requested[EYEQMESPMGR_EYESPHERE_IDX_HALT] = TRUE;
      EyeQMespMgr_EyeSphereData.CallbackFctPtr[EYEQMESPMGR_EYESPHERE_IDX_HALT] = CallbackFctPtr;
      ret = E_OK;
   }
   else
   {
      ret = E_NOT_OK;
   }

   return (ret);
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(uint16, EyeQMespMgr_CODE) EyeQMespMgr_EyeSphereGetCmdTxLength(void)
{
   return (EyeQMespMgr_EyeSphereData.TxCmdStringLength);
}


#define EyeQMespMgr_STOP_SEC_CODE
#include "EyeQMespMgr_MemMap.h"
/******************************************************************************
End Of File
******************************************************************************/
