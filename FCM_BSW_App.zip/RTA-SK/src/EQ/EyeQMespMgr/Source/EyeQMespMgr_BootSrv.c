
/******************************************************************************

WBTL ELECTRONIC document

Copyright WBTL. All rights reserved.

******************************************************************************/
/******************************************************************************

@details
   <Describes details of this component implementation and design>

******************************************************************************/
/******************************************************************************
External Dependencies
******************************************************************************/
#include <EyeQMespMgr.h>
#include <EyeQMespMgr_BootSrv.h>
#include <EyeQMespMgr_Intl.h>
#include <EyeQAppl.h>

/******************************************************************************
Component Defines
******************************************************************************/
#define EYEQMESPMGR_BOOTSRV_DATA_FRAME_SIZE_LEN     (4u)
#define EYEQMESPMGR_BOOTSRV_TRANSFER_TX_HEADER_LEN  (4u)

#define EYEQMESPMGR_BOOTSRV_RX_HEADER_LEN           (4u)

#define EYEQMESPMGR_BOOTSRV_RX_MAX_LEN              (EYEQMESPMGR_BOOTSRV_RESP_BUFF_SIZE)
#define EYEQMESPMGR_BOOTSRV_TRANSFER_TX_MIN_LEN     (EYEQMESPMGR_BOOTSRV_TRANSFER_TX_HEADER_LEN + EYEQMESPMGR_BOOTSRV_DATA_FRAME_SIZE_LEN)
#define EYEQMESPMGR_BOOTSRV_TRANSFER_TX_MAX_LEN     (sizeof(EyeQMespMgr_BootSrvTransferTxDataType))

/******************************************************************************
Component Types
******************************************************************************/
typedef struct EyeQMespMgr_BootSrvDataTypeTag
{
   EyeQMespMgr_BootSrvProgressRxDataType ProgressRxData;
   EyeQMespMgr_BootSrvCrcRxDataType GetCrcRxData;
   EyeQMespMgr_ReqCallbackFct CallbackFctPtr[EYEQMESPMGR_BOOTSRV_IDX_NUM];
   EyeQMespMgr_BootSrvRetType LastCmdRetValue[EYEQMESPMGR_BOOTSRV_IDX_NUM];
   EyeQMespMgr_BootSrvStsType Status;
   EyeQMespMgr_BootSrvFctIdType ActiveFunction;
   EyeQAppl_CallbackStsType LastApplStatus[EYEQMESPMGR_BOOTSRV_IDX_NUM];
   uint16 RequestTimer;
   uint16 TransferTxLength;
   boolean Requested[EYEQMESPMGR_BOOTSRV_IDX_NUM];
   boolean IsOkOnce[EYEQMESPMGR_BOOTSRV_IDX_NUM];
   boolean IsLastOk[EYEQMESPMGR_BOOTSRV_IDX_NUM];
   boolean ProcessStatus;
}EyeQMespMgr_BootSrvDataType;

/******************************************************************************
Declaration of Local Functions
******************************************************************************/
LOCAL_INLINE FUNC(Std_ReturnType, EyeQMespMgr_CODE) eyeqmespmgr_BootSrvInit(void);
LOCAL_INLINE FUNC(Std_ReturnType, EyeQMespMgr_CODE) eyeqmespmgr_BootSrvTransfer(void);
LOCAL_INLINE FUNC(Std_ReturnType, EyeQMespMgr_CODE) eyeqmespmgr_BootSrvClose(void);
LOCAL_INLINE FUNC(Std_ReturnType, EyeQMespMgr_CODE) eyeqmespmgr_BootSrvProgress(void);
LOCAL_INLINE FUNC(Std_ReturnType, EyeQMespMgr_CODE) eyeqmespmgr_BootSrvGetCrc(void);

#define EyeQMespMgr_START_SEC_VAR
#include "EyeQMespMgr_MemMap.h"
/******************************************************************************
Definition Of Local Variables
******************************************************************************/
LOCAL VAR(EyeQMespMgr_BootSrvDataType, EyeQMespMgr_VAR) EyeQMespMgr_BootSrvData;

/******************************************************************************
Definition Of Global Variables
******************************************************************************/
VAR(uint32, EyeQMespMgr_VAR) EyeQMespMgr_BootSrvRespLength;
VAR(uint8, EyeQMespMgr_VAR) EyeQMespMgr_BootSrvRespData[EYEQMESPMGR_BOOTSRV_RESP_BUFF_SIZE];
VAR(EyeQMespMgr_BootSrvInitTxDataType, EyeQMespMgr_VAR) EyeQMespMgr_BootSrvInitTxData;
VAR(EyeQMespMgr_BootSrvTransferTxDataType, EyeQMespMgr_VAR) EyeQMespMgr_BootSrvTransferTxData;
VAR(EyeQMespMgr_BootSrvCloseTxDataType, EyeQMespMgr_VAR) EyeQMespMgr_BootSrvCloseTxData;


#define EyeQMespMgr_STOP_SEC_VAR
#include "EyeQMespMgr_MemMap.h"

#define EyeQMespMgr_START_SEC_CONST
#include "EyeQMespMgr_MemMap.h"
/******************************************************************************
Definition Of Local Constant Data
******************************************************************************/

/******************************************************************************
Definition Of Global Constant Data
******************************************************************************/

#define EyeQMespMgr_STOP_SEC_CONST
#include "EyeQMespMgr_MemMap.h"
/******************************************************************************
Component Function-like Macros
******************************************************************************/
#define EyeQMespMgr_GetRespRet()          (*(uint32*)EyeQMespMgr_BootSrvRespData)

/******************************************************************************
Definition Of APIs
******************************************************************************/
#define EyeQMespMgr_START_SEC_CODE
#include "EyeQMespMgr_MemMap.h"

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQMespMgr_CODE) EyeQMespMgr_BootSrvInit(void)
{
   EyeQMespMgr_BootSrvIdxType function_index;

   for (function_index = 0; function_index < EYEQMESPMGR_BOOTSRV_IDX_NUM; function_index++)
   {
      EyeQMespMgr_BootSrvData.IsLastOk[function_index] = FALSE;
      EyeQMespMgr_BootSrvData.IsOkOnce[function_index] = FALSE;
      EyeQMespMgr_BootSrvData.Requested[function_index] = FALSE;
      EyeQMespMgr_BootSrvData.LastApplStatus[function_index] = EYEQAPPL_CB_STS_TX_FAILED;
      EyeQMespMgr_BootSrvData.LastCmdRetValue[function_index] = EYEQMESPMGR_BOOTSRV_RET_OK;
   }
   EyeQMespMgr_BootSrvData.ActiveFunction = EYEQMESPMGR_BOOTSRV_FCT_ID_NULL;
   EyeQMespMgr_BootSrvData.Status = 0u;
   EyeQMespMgr_BootSrvData.RequestTimer = 0u;
   EyeQMespMgr_BootSrvData.ProcessStatus = FALSE;
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQMespMgr_CODE) EyeQMespMgr_BootSrvMainFunction(void)
{
   Std_ReturnType ret;
   EyeQMespMgr_BootSrvIdxType fct_index;

   if (EYEQMESPMGR_BOOTSRV_FCT_ID_NULL == EyeQMespMgr_BootSrvData.ActiveFunction)
   {
      fct_index = 0u;
      /* If no active function then search if any function has been requested then serve one if any */
      while (fct_index < EYEQMESPMGR_BOOTSRV_IDX_NUM)
      {
         if (FALSE != EyeQMespMgr_BootSrvData.Requested[fct_index])
         {
            switch (fct_index)
            {
               case EYEQMESPMGR_BOOTSRV_IDX_INIT:
               {
                  ret = eyeqmespmgr_BootSrvInit();
                  if (E_OK == ret)
                  {
                     EyeQMespMgr_BootSrvData.RequestTimer = 0u;
                  }

                  break;
               }
               case EYEQMESPMGR_BOOTSRV_IDX_TRANSFER:
               {
                  ret = eyeqmespmgr_BootSrvTransfer();
                  if (E_OK == ret)
                  {
                     EyeQMespMgr_BootSrvData.RequestTimer = 0u;
                  }

                  break;
               }
               case EYEQMESPMGR_BOOTSRV_IDX_CLOSE:
               {
                  ret = eyeqmespmgr_BootSrvClose();
                  if (E_OK == ret)
                  {
                     EyeQMespMgr_BootSrvData.RequestTimer = 0u;
                  }

                  break;
               }
               case EYEQMESPMGR_BOOTSRV_IDX_PROGRESS:
               {
                  ret = eyeqmespmgr_BootSrvProgress();
                  if (E_OK == ret)
                  {
                     EyeQMespMgr_BootSrvData.RequestTimer = 0u;
                  }

                  break;
               }
               case EYEQMESPMGR_BOOTSRV_IDX_GET_CRC:
               {
                  ret = eyeqmespmgr_BootSrvGetCrc();
                  if (E_OK == ret)
                  {
                     EyeQMespMgr_BootSrvData.RequestTimer = 0u;
                  }

                  break;
               }
               default:
                  break;
            }
            fct_index = EYEQMESPMGR_BOOTSRV_IDX_NUM;
         }
         else
         {
            fct_index++;
         }

      }
   }
   else
   {
      /* check if timeout */
      EyeQMespMgr_BootSrvData.RequestTimer++;
      if (EYEQMESPMGR_REQ_TIMEOUT_CNT < EyeQMespMgr_BootSrvData.RequestTimer)
      {
         EyeQMespMgr_BootSrvData.RequestTimer = 0u;
         fct_index = EyeQMespMgr_BootSrvConvertFctIdToIdx(EyeQMespMgr_BootSrvData.ActiveFunction);
         EyeQMespMgr_BootSrvData.Status |= EYEQMESPMGR_BOOTSRV_STS_REQ_TIMEOUT;
         EyeQMespMgr_BootSrvData.ProcessStatus = TRUE;
         EyeQMespMgr_BootSrvData.Requested[fct_index] = FALSE;
         EyeQMespMgr_BootSrvData.ActiveFunction = EYEQMESPMGR_BOOTSRV_FCT_ID_NULL;
         if (NULL_PTR != EyeQMespMgr_BootSrvData.CallbackFctPtr[fct_index])
         {
            EyeQMespMgr_BootSrvData.CallbackFctPtr[fct_index](EYEQMESPMGR_CB_STS_REQ_FAILED);
         }
      }
   }

   if (FALSE != EyeQMespMgr_BootSrvData.ProcessStatus)
   {
      if (0u == EyeQMespMgr_BootSrvData.Status)
      {
         Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQMESPMGR_E_BOOTSRV_RET_ERR, DEM_EVENT_STATUS_PREPASSED);
      }
      else
      {
         Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQMESPMGR_E_BOOTSRV_RET_ERR, DEM_EVENT_STATUS_PREFAILED);
      }
      EyeQMespMgr_BootSrvData.Status = 0u;
      EyeQMespMgr_BootSrvData.ProcessStatus = FALSE;
   }

}
/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
LOCAL_INLINE FUNC(Std_ReturnType, EyeQMespMgr_CODE) eyeqmespmgr_BootSrvInit(void)
{
   Std_ReturnType ret;

   ret = EyeQAppl_TxRequest(EYEQMESPMGR_SRV_ID_BOOTSRV, EYEQMESPMGR_BOOTSRV_FCT_ID_INIT);
   if (E_OK == ret)
   {
      EyeQMespMgr_BootSrvData.ActiveFunction = EYEQMESPMGR_BOOTSRV_FCT_ID_INIT;
   }

   return (ret);
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
LOCAL_INLINE FUNC(Std_ReturnType, EyeQMespMgr_CODE) eyeqmespmgr_BootSrvTransfer(void)
{
   Std_ReturnType ret;

   ret = EyeQAppl_TxRequest(EYEQMESPMGR_SRV_ID_BOOTSRV, EYEQMESPMGR_BOOTSRV_FCT_ID_TRANSFER);
   if (E_OK == ret)
   {
      EyeQMespMgr_BootSrvData.ActiveFunction = EYEQMESPMGR_BOOTSRV_FCT_ID_TRANSFER;
   }

   return (ret);
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
LOCAL_INLINE FUNC(Std_ReturnType, EyeQMespMgr_CODE) eyeqmespmgr_BootSrvClose(void)
{
   Std_ReturnType ret;

   ret = EyeQAppl_TxRequest(EYEQMESPMGR_SRV_ID_BOOTSRV, EYEQMESPMGR_BOOTSRV_FCT_ID_CLOSE);
   if (E_OK == ret)
   {
      EyeQMespMgr_BootSrvData.ActiveFunction = EYEQMESPMGR_BOOTSRV_FCT_ID_CLOSE;
   }

   return (ret);
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
LOCAL_INLINE FUNC(Std_ReturnType, EyeQMespMgr_CODE) eyeqmespmgr_BootSrvProgress(void)
{
   Std_ReturnType ret;

   ret = EyeQAppl_TxRequest(EYEQMESPMGR_SRV_ID_BOOTSRV, EYEQMESPMGR_BOOTSRV_FCT_ID_PROGRESS);
   if (E_OK == ret)
   {
      EyeQMespMgr_BootSrvData.ActiveFunction = EYEQMESPMGR_BOOTSRV_FCT_ID_PROGRESS;
   }

   return (ret);
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
LOCAL_INLINE FUNC(Std_ReturnType, EyeQMespMgr_CODE) eyeqmespmgr_BootSrvGetCrc(void)
{
   Std_ReturnType ret;

   ret = EyeQAppl_TxRequest(EYEQMESPMGR_SRV_ID_BOOTSRV, EYEQMESPMGR_BOOTSRV_FCT_ID_GET_CRC);
   if (E_OK == ret)
   {
      EyeQMespMgr_BootSrvData.ActiveFunction = EYEQMESPMGR_BOOTSRV_FCT_ID_GET_CRC;
   }

   return (ret);
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQMespMgr_CODE) EyeQMespMgr_BootSrvInitCallback(CONST(EyeQAppl_CallbackStsType, AUTOMATIC)Status)
{
   uint32 resp_ret;

   if (EYEQMESPMGR_BOOTSRV_FCT_ID_INIT == EyeQMespMgr_BootSrvData.ActiveFunction)
   {
      EyeQMespMgr_BootSrvData.LastApplStatus[EYEQMESPMGR_BOOTSRV_IDX_INIT] = Status;
      switch (Status)
      {
         case EYEQAPPL_CB_STS_RX_FAILED:
         case EYEQAPPL_CB_STS_TX_FAILED:
         {
            EyeQMespMgr_BootSrvData.IsLastOk[EYEQMESPMGR_BOOTSRV_IDX_INIT] = FALSE;
            EyeQMespMgr_BootSrvData.Status |= EYEQMESPMGR_BOOTSRV_STS_APPL_FAILED;
            if (NULL_PTR != EyeQMespMgr_BootSrvData.CallbackFctPtr[EYEQMESPMGR_BOOTSRV_IDX_INIT])
            {
               EyeQMespMgr_BootSrvData.CallbackFctPtr[EYEQMESPMGR_BOOTSRV_IDX_INIT](EYEQMESPMGR_CB_STS_REQ_FAILED);
            }
            EyeQMespMgr_BootSrvData.ActiveFunction = EYEQMESPMGR_BOOTSRV_FCT_ID_NULL;
            EyeQMespMgr_BootSrvData.Requested[EYEQMESPMGR_BOOTSRV_IDX_INIT] = FALSE;
            break;
         }
         case EYEQAPPL_CB_STS_RX_OK:
         {
            resp_ret = EyeQMespMgr_GetRespRet();
            EyeQMespMgr_BootSrvData.LastCmdRetValue[EYEQMESPMGR_BOOTSRV_IDX_INIT] = resp_ret;
            if (EYEQMESPMGR_BOOTSRV_RET_OK == resp_ret)
            {
               if (EYEQMESPMGR_BOOTSRV_REGULAR_RESP_LEN == EyeQMespMgr_BootSrvRespLength)
               {
                  EyeQMespMgr_BootSrvData.IsLastOk[EYEQMESPMGR_BOOTSRV_IDX_INIT] = TRUE;
                  EyeQMespMgr_BootSrvData.IsOkOnce[EYEQMESPMGR_BOOTSRV_IDX_INIT] = TRUE;
                  if (NULL_PTR != EyeQMespMgr_BootSrvData.CallbackFctPtr[EYEQMESPMGR_BOOTSRV_IDX_INIT])
                  {
                     EyeQMespMgr_BootSrvData.CallbackFctPtr[EYEQMESPMGR_BOOTSRV_IDX_INIT](EYEQMESPMGR_CB_STS_REQ_FINISHED);
                  }
               }
               else
               {
                  EyeQMespMgr_BootSrvData.IsLastOk[EYEQMESPMGR_BOOTSRV_IDX_INIT] = FALSE;
                  EyeQMespMgr_BootSrvData.Status |= EYEQMESPMGR_BOOTSRV_STS_DATA_ERROR;
                  if (NULL_PTR != EyeQMespMgr_BootSrvData.CallbackFctPtr[EYEQMESPMGR_BOOTSRV_IDX_INIT])
                  {
                     EyeQMespMgr_BootSrvData.CallbackFctPtr[EYEQMESPMGR_BOOTSRV_IDX_INIT](EYEQMESPMGR_CB_STS_REQ_FAILED);
                  }
               }
            }
            else
            {
               EyeQMespMgr_BootSrvData.IsLastOk[EYEQMESPMGR_BOOTSRV_IDX_INIT] = FALSE;
               EyeQMespMgr_BootSrvData.Status |= EYEQMESPMGR_BOOTSRV_STS_RET_ERROR;
               if (NULL_PTR != EyeQMespMgr_BootSrvData.CallbackFctPtr[EYEQMESPMGR_BOOTSRV_IDX_INIT])
               {
                  EyeQMespMgr_BootSrvData.CallbackFctPtr[EYEQMESPMGR_BOOTSRV_IDX_INIT](EYEQMESPMGR_CB_STS_REQ_FAILED);
               }
            }
            EyeQMespMgr_BootSrvData.ActiveFunction = EYEQMESPMGR_BOOTSRV_FCT_ID_NULL;
            EyeQMespMgr_BootSrvData.Requested[EYEQMESPMGR_BOOTSRV_IDX_INIT] = FALSE;
            break;
         }
         case EYEQAPPL_CB_STS_TX_OK:
         case EYEQAPPL_CB_STS_RX_NEW_FRAME:
         default:
            break;
      }
   }
   else
   {
      EyeQMespMgr_BootSrvData.Status |= EYEQMESPMGR_BOOTSRV_STS_INVALID_RESP;
   }
   EyeQMespMgr_BootSrvData.ProcessStatus = TRUE;
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQMespMgr_CODE) EyeQMespMgr_BootSrvTransferCallback(CONST(EyeQAppl_CallbackStsType, AUTOMATIC)Status)
{
   uint32 resp_ret;

   if (EYEQMESPMGR_BOOTSRV_FCT_ID_TRANSFER == EyeQMespMgr_BootSrvData.ActiveFunction)
   {
      EyeQMespMgr_BootSrvData.LastApplStatus[EYEQMESPMGR_BOOTSRV_IDX_TRANSFER] = Status;
      switch (Status)
      {
         case EYEQAPPL_CB_STS_RX_FAILED:
         case EYEQAPPL_CB_STS_TX_FAILED:
         {
            EyeQMespMgr_BootSrvData.IsLastOk[EYEQMESPMGR_BOOTSRV_IDX_TRANSFER] = FALSE;
            EyeQMespMgr_BootSrvData.Status |= EYEQMESPMGR_BOOTSRV_STS_APPL_FAILED;
            if (NULL_PTR != EyeQMespMgr_BootSrvData.CallbackFctPtr[EYEQMESPMGR_BOOTSRV_IDX_TRANSFER])
            {
               EyeQMespMgr_BootSrvData.CallbackFctPtr[EYEQMESPMGR_BOOTSRV_IDX_TRANSFER](EYEQMESPMGR_CB_STS_REQ_FAILED);
            }
            EyeQMespMgr_BootSrvData.ActiveFunction = EYEQMESPMGR_BOOTSRV_FCT_ID_NULL;
            EyeQMespMgr_BootSrvData.Requested[EYEQMESPMGR_BOOTSRV_IDX_TRANSFER] = FALSE;
            break;
         }
         case EYEQAPPL_CB_STS_RX_OK:
         {
            resp_ret = EyeQMespMgr_GetRespRet();
            EyeQMespMgr_BootSrvData.LastCmdRetValue[EYEQMESPMGR_BOOTSRV_IDX_TRANSFER] = resp_ret;
            if (EYEQMESPMGR_BOOTSRV_RET_OK == resp_ret)
            {
               if (EYEQMESPMGR_BOOTSRV_REGULAR_RESP_LEN == EyeQMespMgr_BootSrvRespLength)
               {
                  EyeQMespMgr_BootSrvData.IsLastOk[EYEQMESPMGR_BOOTSRV_IDX_TRANSFER] = TRUE;
                  EyeQMespMgr_BootSrvData.IsOkOnce[EYEQMESPMGR_BOOTSRV_IDX_TRANSFER] = TRUE;
                  if (NULL_PTR != EyeQMespMgr_BootSrvData.CallbackFctPtr[EYEQMESPMGR_BOOTSRV_IDX_TRANSFER])
                  {
                     EyeQMespMgr_BootSrvData.CallbackFctPtr[EYEQMESPMGR_BOOTSRV_IDX_TRANSFER](EYEQMESPMGR_CB_STS_REQ_FINISHED);
                  }
               }
               else
               {
                  EyeQMespMgr_BootSrvData.IsLastOk[EYEQMESPMGR_BOOTSRV_IDX_TRANSFER] = FALSE;
                  EyeQMespMgr_BootSrvData.Status |= EYEQMESPMGR_BOOTSRV_STS_DATA_ERROR;
                  if (NULL_PTR != EyeQMespMgr_BootSrvData.CallbackFctPtr[EYEQMESPMGR_BOOTSRV_IDX_TRANSFER])
                  {
                     EyeQMespMgr_BootSrvData.CallbackFctPtr[EYEQMESPMGR_BOOTSRV_IDX_TRANSFER](EYEQMESPMGR_CB_STS_REQ_FAILED);
                  }
               }

            }
            else
            {
               EyeQMespMgr_BootSrvData.IsLastOk[EYEQMESPMGR_BOOTSRV_IDX_TRANSFER] = FALSE;
               EyeQMespMgr_BootSrvData.Status |= EYEQMESPMGR_BOOTSRV_STS_RET_ERROR;
               if (NULL_PTR != EyeQMespMgr_BootSrvData.CallbackFctPtr[EYEQMESPMGR_BOOTSRV_IDX_TRANSFER])
               {
                  EyeQMespMgr_BootSrvData.CallbackFctPtr[EYEQMESPMGR_BOOTSRV_IDX_TRANSFER](EYEQMESPMGR_CB_STS_REQ_FAILED);
               }
            }
            EyeQMespMgr_BootSrvData.ActiveFunction = EYEQMESPMGR_BOOTSRV_FCT_ID_NULL;
            EyeQMespMgr_BootSrvData.Requested[EYEQMESPMGR_BOOTSRV_IDX_TRANSFER] = FALSE;
            break;
         }
         case EYEQAPPL_CB_STS_TX_OK:
         case EYEQAPPL_CB_STS_RX_NEW_FRAME:
         default:
            break;
      }
   }
   else
   {
      EyeQMespMgr_BootSrvData.Status |= EYEQMESPMGR_BOOTSRV_STS_INVALID_RESP;
   }
   EyeQMespMgr_BootSrvData.ProcessStatus = TRUE;
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQMespMgr_CODE) EyeQMespMgr_BootSrvCloseCallback(CONST(EyeQAppl_CallbackStsType, AUTOMATIC)Status)
{
   uint32 resp_ret;

   if (EYEQMESPMGR_BOOTSRV_FCT_ID_CLOSE == EyeQMespMgr_BootSrvData.ActiveFunction)
   {
      EyeQMespMgr_BootSrvData.LastApplStatus[EYEQMESPMGR_BOOTSRV_IDX_CLOSE] = Status;
      switch (Status)
      {
         case EYEQAPPL_CB_STS_RX_FAILED:
         case EYEQAPPL_CB_STS_TX_FAILED:
         {
            EyeQMespMgr_BootSrvData.IsLastOk[EYEQMESPMGR_BOOTSRV_IDX_CLOSE] = FALSE;
            EyeQMespMgr_BootSrvData.Status |= EYEQMESPMGR_BOOTSRV_STS_APPL_FAILED;
            if (NULL_PTR != EyeQMespMgr_BootSrvData.CallbackFctPtr[EYEQMESPMGR_BOOTSRV_IDX_CLOSE])
            {
               EyeQMespMgr_BootSrvData.CallbackFctPtr[EYEQMESPMGR_BOOTSRV_IDX_CLOSE](EYEQMESPMGR_CB_STS_REQ_FAILED);
            }
            EyeQMespMgr_BootSrvData.ActiveFunction = EYEQMESPMGR_BOOTSRV_FCT_ID_NULL;
            EyeQMespMgr_BootSrvData.Requested[EYEQMESPMGR_BOOTSRV_IDX_CLOSE] = FALSE;
            break;
         }
         case EYEQAPPL_CB_STS_RX_OK:
         {
            resp_ret = EyeQMespMgr_GetRespRet();
            EyeQMespMgr_BootSrvData.LastCmdRetValue[EYEQMESPMGR_BOOTSRV_IDX_CLOSE] = resp_ret;
            if (EYEQMESPMGR_BOOTSRV_RET_OK == resp_ret)
            {
               if (EYEQMESPMGR_BOOTSRV_REGULAR_RESP_LEN == EyeQMespMgr_BootSrvRespLength)
               {
                  EyeQMespMgr_BootSrvData.IsLastOk[EYEQMESPMGR_BOOTSRV_IDX_CLOSE] = TRUE;
                  EyeQMespMgr_BootSrvData.IsOkOnce[EYEQMESPMGR_BOOTSRV_IDX_CLOSE] = TRUE;
                  if (NULL_PTR != EyeQMespMgr_BootSrvData.CallbackFctPtr[EYEQMESPMGR_BOOTSRV_IDX_CLOSE])
                  {
                     EyeQMespMgr_BootSrvData.CallbackFctPtr[EYEQMESPMGR_BOOTSRV_IDX_CLOSE](EYEQMESPMGR_CB_STS_REQ_FINISHED);
                  }
               }
               else
               {
                  EyeQMespMgr_BootSrvData.IsLastOk[EYEQMESPMGR_BOOTSRV_IDX_CLOSE] = FALSE;
                  EyeQMespMgr_BootSrvData.Status |= EYEQMESPMGR_BOOTSRV_STS_DATA_ERROR;
                  if (NULL_PTR != EyeQMespMgr_BootSrvData.CallbackFctPtr[EYEQMESPMGR_BOOTSRV_IDX_CLOSE])
                  {
                     EyeQMespMgr_BootSrvData.CallbackFctPtr[EYEQMESPMGR_BOOTSRV_IDX_CLOSE](EYEQMESPMGR_CB_STS_REQ_FAILED);
                  }
               }
            }
            else
            {
               EyeQMespMgr_BootSrvData.IsLastOk[EYEQMESPMGR_BOOTSRV_IDX_CLOSE] = FALSE;
               EyeQMespMgr_BootSrvData.Status |= EYEQMESPMGR_BOOTSRV_STS_RET_ERROR;
               if (NULL_PTR != EyeQMespMgr_BootSrvData.CallbackFctPtr[EYEQMESPMGR_BOOTSRV_IDX_CLOSE])
               {
                  EyeQMespMgr_BootSrvData.CallbackFctPtr[EYEQMESPMGR_BOOTSRV_IDX_CLOSE](EYEQMESPMGR_CB_STS_REQ_FAILED);
               }
            }
            EyeQMespMgr_BootSrvData.ActiveFunction = EYEQMESPMGR_BOOTSRV_FCT_ID_NULL;
            EyeQMespMgr_BootSrvData.Requested[EYEQMESPMGR_BOOTSRV_IDX_CLOSE] = FALSE;
            break;
         }
         case EYEQAPPL_CB_STS_TX_OK:
         case EYEQAPPL_CB_STS_RX_NEW_FRAME:
         default:
            break;
      }
   }
   else
   {
      EyeQMespMgr_BootSrvData.Status |= EYEQMESPMGR_BOOTSRV_STS_INVALID_RESP;
   }
   EyeQMespMgr_BootSrvData.ProcessStatus = TRUE;
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQMespMgr_CODE) EyeQMespMgr_BootSrvProgressCallback(CONST(EyeQAppl_CallbackStsType, AUTOMATIC)Status)
{
   uint32 resp_ret;
   EyeQMespMgr_BootSrvProgressRxDataType* src_ptr;

   if (EYEQMESPMGR_BOOTSRV_FCT_ID_PROGRESS == EyeQMespMgr_BootSrvData.ActiveFunction)
   {
      EyeQMespMgr_BootSrvData.LastApplStatus[EYEQMESPMGR_BOOTSRV_IDX_PROGRESS] = Status;
      switch (Status)
      {
         case EYEQAPPL_CB_STS_RX_FAILED:
         case EYEQAPPL_CB_STS_TX_FAILED:
         {
            EyeQMespMgr_BootSrvData.IsLastOk[EYEQMESPMGR_BOOTSRV_IDX_PROGRESS] = FALSE;
            EyeQMespMgr_BootSrvData.Status |= EYEQMESPMGR_BOOTSRV_STS_APPL_FAILED;
            if (NULL_PTR != EyeQMespMgr_BootSrvData.CallbackFctPtr[EYEQMESPMGR_BOOTSRV_IDX_PROGRESS])
            {
               EyeQMespMgr_BootSrvData.CallbackFctPtr[EYEQMESPMGR_BOOTSRV_IDX_PROGRESS](EYEQMESPMGR_CB_STS_REQ_FAILED);
            }
            EyeQMespMgr_BootSrvData.ActiveFunction = EYEQMESPMGR_BOOTSRV_FCT_ID_NULL;
            EyeQMespMgr_BootSrvData.Requested[EYEQMESPMGR_BOOTSRV_IDX_PROGRESS] = FALSE;
            break;
         }
         case EYEQAPPL_CB_STS_RX_OK:
         {
            resp_ret = EyeQMespMgr_GetRespRet();
            EyeQMespMgr_BootSrvData.LastCmdRetValue[EYEQMESPMGR_BOOTSRV_IDX_PROGRESS] = resp_ret;
            if (EYEQMESPMGR_BOOTSRV_RET_OK == resp_ret)
            {
               if (EYEQMESPMGR_BOOTSRV_PROGRESS_RESP_LEN == EyeQMespMgr_BootSrvRespLength)
               {
                  src_ptr = (EyeQMespMgr_BootSrvProgressRxDataType*)&EyeQMespMgr_BootSrvRespData[0];
                  EyeQMespMgr_BootSrvData.ProgressRxData = *src_ptr;

                  EyeQMespMgr_BootSrvData.IsLastOk[EYEQMESPMGR_BOOTSRV_IDX_PROGRESS] = TRUE;
                  EyeQMespMgr_BootSrvData.IsOkOnce[EYEQMESPMGR_BOOTSRV_IDX_PROGRESS] = TRUE;

                  if (NULL_PTR != EyeQMespMgr_BootSrvData.CallbackFctPtr[EYEQMESPMGR_BOOTSRV_IDX_PROGRESS])
                  {
                     EyeQMespMgr_BootSrvData.CallbackFctPtr[EYEQMESPMGR_BOOTSRV_IDX_PROGRESS](EYEQMESPMGR_CB_STS_REQ_FINISHED);
                  }
               }
               else
               {
                  EyeQMespMgr_BootSrvData.IsLastOk[EYEQMESPMGR_BOOTSRV_IDX_PROGRESS] = FALSE;
                  EyeQMespMgr_BootSrvData.Status |= EYEQMESPMGR_BOOTSRV_STS_DATA_ERROR;
                  if (NULL_PTR != EyeQMespMgr_BootSrvData.CallbackFctPtr[EYEQMESPMGR_BOOTSRV_IDX_PROGRESS])
                  {
                     EyeQMespMgr_BootSrvData.CallbackFctPtr[EYEQMESPMGR_BOOTSRV_IDX_PROGRESS](EYEQMESPMGR_CB_STS_REQ_FAILED);
                  }
               }
            }
            else
            {
               EyeQMespMgr_BootSrvData.IsLastOk[EYEQMESPMGR_BOOTSRV_IDX_PROGRESS] = FALSE;
               EyeQMespMgr_BootSrvData.Status |= EYEQMESPMGR_BOOTSRV_STS_RET_ERROR;
               if (NULL_PTR != EyeQMespMgr_BootSrvData.CallbackFctPtr[EYEQMESPMGR_BOOTSRV_IDX_PROGRESS])
               {
                  EyeQMespMgr_BootSrvData.CallbackFctPtr[EYEQMESPMGR_BOOTSRV_IDX_PROGRESS](EYEQMESPMGR_CB_STS_REQ_FAILED);
               }
            }
            EyeQMespMgr_BootSrvData.ActiveFunction = EYEQMESPMGR_BOOTSRV_FCT_ID_NULL;
            EyeQMespMgr_BootSrvData.Requested[EYEQMESPMGR_BOOTSRV_IDX_PROGRESS] = FALSE;
            break;
         }
         case EYEQAPPL_CB_STS_TX_OK:
         case EYEQAPPL_CB_STS_RX_NEW_FRAME:
         default:
            break;
      }
   }
   else
   {
      EyeQMespMgr_BootSrvData.Status |= EYEQMESPMGR_BOOTSRV_STS_INVALID_RESP;
   }
   EyeQMespMgr_BootSrvData.ProcessStatus = TRUE;
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQMespMgr_CODE) EyeQMespMgr_BootSrvGetCrcCallback(CONST(EyeQAppl_CallbackStsType, AUTOMATIC)Status)
{
   uint32 resp_ret;
   EyeQMespMgr_BootSrvCrcRxDataType* src_ptr;

   if (EYEQMESPMGR_BOOTSRV_FCT_ID_GET_CRC == EyeQMespMgr_BootSrvData.ActiveFunction)
   {
      EyeQMespMgr_BootSrvData.LastApplStatus[EYEQMESPMGR_BOOTSRV_IDX_GET_CRC] = Status;
      switch (Status)
      {
         case EYEQAPPL_CB_STS_RX_FAILED:
         case EYEQAPPL_CB_STS_TX_FAILED:
         {
            EyeQMespMgr_BootSrvData.IsLastOk[EYEQMESPMGR_BOOTSRV_IDX_GET_CRC] = FALSE;
            EyeQMespMgr_BootSrvData.Status |= EYEQMESPMGR_BOOTSRV_STS_APPL_FAILED;
            if (NULL_PTR != EyeQMespMgr_BootSrvData.CallbackFctPtr[EYEQMESPMGR_BOOTSRV_IDX_GET_CRC])
            {
               EyeQMespMgr_BootSrvData.CallbackFctPtr[EYEQMESPMGR_BOOTSRV_IDX_GET_CRC](EYEQMESPMGR_CB_STS_REQ_FAILED);
            }
            EyeQMespMgr_BootSrvData.ActiveFunction = EYEQMESPMGR_BOOTSRV_FCT_ID_NULL;
            EyeQMespMgr_BootSrvData.Requested[EYEQMESPMGR_BOOTSRV_IDX_GET_CRC] = FALSE;
            break;
         }
         case EYEQAPPL_CB_STS_RX_OK:
         {
            resp_ret = EyeQMespMgr_GetRespRet();
            EyeQMespMgr_BootSrvData.LastCmdRetValue[EYEQMESPMGR_BOOTSRV_IDX_GET_CRC] = resp_ret;
            if (EYEQMESPMGR_BOOTSRV_RET_OK == resp_ret)
            {
               if (EYEQMESPMGR_BOOTSRV_CRC_RESP_LEN == EyeQMespMgr_BootSrvRespLength)
               {
                  src_ptr = (EyeQMespMgr_BootSrvCrcRxDataType*)&EyeQMespMgr_BootSrvRespData[0];
                  EyeQMespMgr_BootSrvData.GetCrcRxData = *src_ptr;

                  EyeQMespMgr_BootSrvData.IsLastOk[EYEQMESPMGR_BOOTSRV_IDX_GET_CRC] = TRUE;
                  EyeQMespMgr_BootSrvData.IsOkOnce[EYEQMESPMGR_BOOTSRV_IDX_GET_CRC] = TRUE;

                  if (NULL_PTR != EyeQMespMgr_BootSrvData.CallbackFctPtr[EYEQMESPMGR_BOOTSRV_IDX_GET_CRC])
                  {
                     EyeQMespMgr_BootSrvData.CallbackFctPtr[EYEQMESPMGR_BOOTSRV_IDX_GET_CRC](EYEQMESPMGR_CB_STS_REQ_FINISHED);
                  }
               }
               else
               {
                  EyeQMespMgr_BootSrvData.IsLastOk[EYEQMESPMGR_BOOTSRV_IDX_GET_CRC] = FALSE;
                  EyeQMespMgr_BootSrvData.Status |= EYEQMESPMGR_BOOTSRV_STS_DATA_ERROR;
                  if (NULL_PTR != EyeQMespMgr_BootSrvData.CallbackFctPtr[EYEQMESPMGR_BOOTSRV_IDX_GET_CRC])
                  {
                     EyeQMespMgr_BootSrvData.CallbackFctPtr[EYEQMESPMGR_BOOTSRV_IDX_GET_CRC](EYEQMESPMGR_CB_STS_REQ_FAILED);
                  }
               }
            }
            else
            {
               EyeQMespMgr_BootSrvData.IsLastOk[EYEQMESPMGR_BOOTSRV_IDX_GET_CRC] = FALSE;
               EyeQMespMgr_BootSrvData.Status |= EYEQMESPMGR_BOOTSRV_STS_RET_ERROR;
               if (NULL_PTR != EyeQMespMgr_BootSrvData.CallbackFctPtr[EYEQMESPMGR_BOOTSRV_IDX_GET_CRC])
               {
                  EyeQMespMgr_BootSrvData.CallbackFctPtr[EYEQMESPMGR_BOOTSRV_IDX_GET_CRC](EYEQMESPMGR_CB_STS_REQ_FAILED);
               }
            }
            EyeQMespMgr_BootSrvData.ActiveFunction = EYEQMESPMGR_BOOTSRV_FCT_ID_NULL;
            EyeQMespMgr_BootSrvData.Requested[EYEQMESPMGR_BOOTSRV_IDX_GET_CRC] = FALSE;
            break;
         }
         case EYEQAPPL_CB_STS_TX_OK:
         case EYEQAPPL_CB_STS_RX_NEW_FRAME:
         default:
            break;
      }
   }
   else
   {
      EyeQMespMgr_BootSrvData.Status |= EYEQMESPMGR_BOOTSRV_STS_INVALID_RESP;
   }
   EyeQMespMgr_BootSrvData.ProcessStatus = TRUE;
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(Std_ReturnType, EyeQMespMgr_CODE) EyeQMespMgr_BootSrvInitProcess(CONST(EyeQMespMgr_ReqCallbackFct, AUTOMATIC) CallbackFctPtr, 
   CONSTP2CONST(EyeQMespMgr_BootSrvInitTxDataType, AUTOMATIC, EyeQMespMgr_APPL_CONST) TxDataPtr)
{
   Std_ReturnType ret;
   
   if ((FALSE == EyeQMespMgr_BootSrvData.Requested[EYEQMESPMGR_BOOTSRV_IDX_INIT])
      && (NULL_PTR != TxDataPtr))
   {
      EyeQMespMgr_BootSrvInitTxData = *TxDataPtr;
      EyeQMespMgr_BootSrvData.CallbackFctPtr[EYEQMESPMGR_BOOTSRV_IDX_INIT] = CallbackFctPtr;
      EyeQMespMgr_BootSrvData.Requested[EYEQMESPMGR_BOOTSRV_IDX_INIT] = TRUE;
      ret = E_OK;
   }
   else
   {
      ret = E_NOT_OK;
   }

   return (ret);
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(Std_ReturnType, EyeQMespMgr_CODE) EyeQMespMgr_BootSrvTransfer(CONST(EyeQMespMgr_ReqCallbackFct, AUTOMATIC) CallbackFctPtr, 
   CONSTP2CONST(EyeQMespMgr_BootSrvTransferTxDataType, AUTOMATIC, EyeQMespMgr_APPL_CONST) TxDataPtr, CONST(uint16, AUTOMATIC) TxDataLength)
{
   Std_ReturnType ret;

   if ((FALSE == EyeQMespMgr_BootSrvData.Requested[EYEQMESPMGR_BOOTSRV_IDX_TRANSFER])
      && (TxDataLength <= EYEQMESPMGR_BOOTSRV_TRANSFER_TX_MAX_LEN)
      && (TxDataLength >= EYEQMESPMGR_BOOTSRV_TRANSFER_TX_MIN_LEN)
      && (NULL_PTR != TxDataPtr))
   {
      EyeQMespMgr_BootSrvTransferTxData = *TxDataPtr;
      EyeQMespMgr_BootSrvData.TransferTxLength = TxDataLength;
      EyeQMespMgr_BootSrvData.CallbackFctPtr[EYEQMESPMGR_BOOTSRV_IDX_TRANSFER] = CallbackFctPtr;
      EyeQMespMgr_BootSrvData.Requested[EYEQMESPMGR_BOOTSRV_IDX_TRANSFER] = TRUE;
      ret = E_OK;
   }
   else
   {
      ret = E_NOT_OK;
   }

   return (ret);
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(Std_ReturnType, EyeQMespMgr_CODE) EyeQMespMgr_BootSrvClose(CONST(EyeQMespMgr_ReqCallbackFct, AUTOMATIC) CallbackFctPtr, 
   CONSTP2CONST(EyeQMespMgr_BootSrvCloseTxDataType, AUTOMATIC, EyeQMespMgr_APPL_CONST) TxDataPtr)
{
   Std_ReturnType ret;

   if ((FALSE == EyeQMespMgr_BootSrvData.Requested[EYEQMESPMGR_BOOTSRV_IDX_CLOSE])
      && (NULL_PTR != TxDataPtr))
   {
      EyeQMespMgr_BootSrvCloseTxData = *TxDataPtr;
      EyeQMespMgr_BootSrvData.CallbackFctPtr[EYEQMESPMGR_BOOTSRV_IDX_CLOSE] = CallbackFctPtr;
      EyeQMespMgr_BootSrvData.Requested[EYEQMESPMGR_BOOTSRV_IDX_CLOSE] = TRUE;
      ret = E_OK;
   }
   else
   {
      ret = E_NOT_OK;
   }

   return (ret);
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(Std_ReturnType, EyeQMespMgr_CODE) EyeQMespMgr_BootSrvProgress(CONST(EyeQMespMgr_ReqCallbackFct, AUTOMATIC) CallbackFctPtr)
{
   Std_ReturnType ret;

   if (FALSE == EyeQMespMgr_BootSrvData.Requested[EYEQMESPMGR_BOOTSRV_IDX_PROGRESS])
   {
      EyeQMespMgr_BootSrvData.CallbackFctPtr[EYEQMESPMGR_BOOTSRV_IDX_PROGRESS] = CallbackFctPtr;
      EyeQMespMgr_BootSrvData.Requested[EYEQMESPMGR_BOOTSRV_IDX_PROGRESS] = TRUE;
      ret = E_OK;
   }
   else
   {
      ret = E_NOT_OK;
   }

   return (ret);
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(Std_ReturnType, EyeQMespMgr_CODE) EyeQMespMgr_BootSrvCrc(CONST(EyeQMespMgr_ReqCallbackFct, AUTOMATIC) CallbackFctPtr)
{
   Std_ReturnType ret;

   if (FALSE == EyeQMespMgr_BootSrvData.Requested[EYEQMESPMGR_BOOTSRV_IDX_GET_CRC])
   {
      EyeQMespMgr_BootSrvData.CallbackFctPtr[EYEQMESPMGR_BOOTSRV_IDX_GET_CRC] = CallbackFctPtr;
      EyeQMespMgr_BootSrvData.Requested[EYEQMESPMGR_BOOTSRV_IDX_GET_CRC] = TRUE;
      ret = E_OK;
   }
   else
   {
      ret = E_NOT_OK;
   }

   return (ret);
}


/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(uint32, EyeQMespMgr_CODE) EyeQMespMgr_BootSrvGetTransferTxLength(void)
{
   return ((uint32)EyeQMespMgr_BootSrvData.TransferTxLength);
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(Std_ReturnType, EyeQMespMgr_CODE) EyeQMespMgr_BootSrvGetRxProgressData(CONSTP2VAR(EyeQMespMgr_BootSrvProgressRxDataType, AUTOMATIC, EyeQMespMgr_APPL_CONST) RetDataPtr)
{
   Std_ReturnType ret;

   if ((FALSE != EyeQMespMgr_BootSrvData.IsLastOk[EYEQMESPMGR_BOOTSRV_IDX_PROGRESS])
      && (EYEQMESPMGR_BOOTSRV_FCT_ID_PROGRESS != EyeQMespMgr_BootSrvData.ActiveFunction)
      && (NULL_PTR != RetDataPtr))
   {
      *RetDataPtr = EyeQMespMgr_BootSrvData.ProgressRxData;
      ret = E_OK;
   }
   else
   {
      ret = E_NOT_OK;
   }

   return (ret);
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(Std_ReturnType, EyeQMespMgr_CODE) EyeQMespMgr_BootSrvGetRxCrcData(CONSTP2VAR(EyeQMespMgr_BootSrvCrcRxDataType, AUTOMATIC, EyeQMespMgr_APPL_CONST) RetDataPtr)
{
   Std_ReturnType ret;

   if ((FALSE != EyeQMespMgr_BootSrvData.IsLastOk[EYEQMESPMGR_BOOTSRV_IDX_GET_CRC])
      && (EYEQMESPMGR_BOOTSRV_FCT_ID_GET_CRC != EyeQMespMgr_BootSrvData.ActiveFunction)
      && (NULL_PTR != RetDataPtr))
   {
      *RetDataPtr = EyeQMespMgr_BootSrvData.GetCrcRxData;
      ret = E_OK;
   }
   else
   {
      ret = E_NOT_OK;
   }

   return (ret);
}


#define EyeQMespMgr_STOP_SEC_CODE
#include "EyeQMespMgr_MemMap.h"
/******************************************************************************
End Of File
******************************************************************************/
