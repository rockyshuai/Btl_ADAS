
/******************************************************************************

WBTL ELECTRONIC document

Copyright WBTL. All rights reserved.

******************************************************************************/
/******************************************************************************

@details
   <Describes details of this component implementation and design>

******************************************************************************/
/******************************************************************************
External Dependencies
******************************************************************************/
#include <EyeQMespMgr.h>

/******************************************************************************
Component Defines
******************************************************************************/

/******************************************************************************
Component Types
******************************************************************************/

/******************************************************************************
Declaration of Local Functions
******************************************************************************/

#define EyeQMespMgr_START_SEC_VAR
#include "EyeQMespMgr_MemMap.h"
/******************************************************************************
Definition Of Local Variables
******************************************************************************/

/******************************************************************************
Definition Of Global Variables
******************************************************************************/

#define EyeQMespMgr_STOP_SEC_VAR
#include "EyeQMespMgr_MemMap.h"

#define EyeQMespMgr_START_SEC_CONST
#include "EyeQMespMgr_MemMap.h"
/******************************************************************************
Definition Of Local Constant Data
******************************************************************************/

/******************************************************************************
Definition Of Global Constant Data
******************************************************************************/

#define EyeQMespMgr_STOP_SEC_CONST
#include "EyeQMespMgr_MemMap.h"
/******************************************************************************
Component Function-like Macros
******************************************************************************/

/******************************************************************************
Definition Of APIs
******************************************************************************/
#define EyeQMespMgr_START_SEC_CODE
#include "EyeQMespMgr_MemMap.h"

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQMespMgr_CODE) EyeQMespMgr_Init(void)
{
   EyeQMespMgr_BascSrvInit();
   EyeQMespMgr_EyeSphereInit();
   EyeQMespMgr_BootSrvInit();
   EyeQMespMgr_CalToolSrvInit();
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQMespMgr_CODE) EyeQMespMgr_MainFunction(void)
{
   EyeQMespMgr_BascSrvMainFunction();
   EyeQMespMgr_EyeSphereMainFunction();
   EyeQMespMgr_CalToolSrvMainFunction();
   EyeQMespMgr_BootSrvMainFunction();
}

#define EyeQMespMgr_STOP_SEC_CODE
#include "EyeQMespMgr_MemMap.h"
/******************************************************************************
End Of File
******************************************************************************/
