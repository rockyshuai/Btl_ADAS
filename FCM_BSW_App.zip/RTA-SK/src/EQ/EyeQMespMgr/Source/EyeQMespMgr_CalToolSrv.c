
/******************************************************************************

WBTL ELECTRONIC document

Copyright WBTL. All rights reserved.

******************************************************************************/
/******************************************************************************

@details
   <Describes details of this component implementation and design>

******************************************************************************/
/******************************************************************************
External Dependencies
******************************************************************************/
#include <EyeQMespMgr.h>
#include <EyeQMespMgr_CalToolSrv.h>
#include <EyeQMespMgr_Intl.h>
#include <EyeQAppl.h>
#include <Crc.h>

/******************************************************************************
Component Defines
******************************************************************************/
#define EYEQMESPMGR_CALTOOLSRV_CRC_START_VAL           (0xffffffffu)
/******************************************************************************
Component Types
******************************************************************************/
typedef struct EyeQMespMgr_CalToolSrvDataTypeTag
{
   EyeQMespMgr_CalToolSrvSendParamsRxDataType SendParamsRxData;
   EyeQMespMgr_CalToolSrvGetParamsRxDataType GetParamsRxData;
   EyeQMespMgr_CalToolSrvEventRxDataType EventRxData;
   EyeQMespMgr_ReqCallbackFct CallbackFctPtr[EYEQMESPMGR_CALTOOLSRV_IDX_NUM];
   EyeQMespMgr_CalToolSrvStsType Status;
   EyeQMespMgr_CalToolSrvFctIdType ActiveFunction;
   EyeQAppl_CallbackStsType LastApplStatus[EYEQMESPMGR_CALTOOLSRV_IDX_NUM];
   EyeQMespMgr_CalToolSrvRetType LastRespRet[EYEQMESPMGR_CALTOOLSRV_IDX_NUM];
   uint16 RequestTimer;
   uint16 SendParamsTxLength;
   uint16 EventTxLength;
   uint16 GetParamsRxLength;
   uint16 EventRxLength;
   boolean Requested[EYEQMESPMGR_CALTOOLSRV_IDX_NUM];
   boolean IsOkOnce[EYEQMESPMGR_CALTOOLSRV_IDX_NUM];
   boolean IsLastOk[EYEQMESPMGR_CALTOOLSRV_IDX_NUM];
   boolean ProcessStatus;
}EyeQMespMgr_CalToolSrvDataType;

/******************************************************************************
Declaration of Local Functions
******************************************************************************/
LOCAL_INLINE FUNC(Std_ReturnType, EyeQMespMgr_CODE) eyeqmespmgr_CalToolSrvSendParams(void);
LOCAL_INLINE FUNC(Std_ReturnType, EyeQMespMgr_CODE) eyeqmespmgr_CalToolSrvGetParams(void);
LOCAL_INLINE FUNC(Std_ReturnType, EyeQMespMgr_CODE) eyeqmespmgr_CalToolSrvEvent(void);

#define EyeQMespMgr_START_SEC_VAR
#include "EyeQMespMgr_MemMap.h"
/******************************************************************************
Definition Of Local Variables
******************************************************************************/
LOCAL VAR(EyeQMespMgr_CalToolSrvDataType, EyeQMespMgr_VAR) EyeQMespMgr_CalToolSrvData;

/******************************************************************************
Definition Of Global Variables
******************************************************************************/
VAR(uint32, EyeQMespMgr_VAR) EyeQMespMgr_CalToolSrvRespLength;
VAR(uint8, EyeQMespMgr_VAR) EyeQMespMgr_CalToolSrvRespData[EYEQMESPMGR_CALTOOLSRV_RESP_BUFF_SIZE];
VAR(EyeQMespMgr_CalToolSrvSendParamsTxDataType, EyeQMespMgr_VAR) EyeQMespMgr_CalToolSrvSendParamsTxData;
VAR(EyeQMespMgr_CalToolSrvGetParamsTxDataType, EyeQMespMgr_VAR) EyeQMespMgr_CalToolSrvGetParamsTxData;
VAR(EyeQMespMgr_CalToolSrvEventTxDataType, EyeQMespMgr_VAR) EyeQMespMgr_CalToolSrvEventTxData;


#define EyeQMespMgr_STOP_SEC_VAR
#include "EyeQMespMgr_MemMap.h"

#define EyeQMespMgr_START_SEC_CONST
#include "EyeQMespMgr_MemMap.h"
/******************************************************************************
Definition Of Local Constant Data
******************************************************************************/

/******************************************************************************
Definition Of Global Constant Data
******************************************************************************/

#define EyeQMespMgr_STOP_SEC_CONST
#include "EyeQMespMgr_MemMap.h"
/******************************************************************************
Component Function-like Macros
******************************************************************************/
#define EyeQMespMgr_GetRespRet()          (*(EyeQMespMgr_CalToolSrvRetType*)EyeQMespMgr_CalToolSrvRespData)

/******************************************************************************
Definition Of APIs
******************************************************************************/
#define EyeQMespMgr_START_SEC_CODE
#include "EyeQMespMgr_MemMap.h"

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQMespMgr_CODE) EyeQMespMgr_CalToolSrvInit(void)
{
   EyeQMespMgr_CalToolSrvIdxType function_index;

   for (function_index = 0; function_index < EYEQMESPMGR_CALTOOLSRV_IDX_NUM; function_index++)
   {
      EyeQMespMgr_CalToolSrvData.IsLastOk[function_index] = FALSE;
      EyeQMespMgr_CalToolSrvData.IsOkOnce[function_index] = FALSE;
      EyeQMespMgr_CalToolSrvData.Requested[function_index] = FALSE;
      EyeQMespMgr_CalToolSrvData.LastApplStatus[function_index] = EYEQAPPL_CB_STS_TX_FAILED;
      EyeQMespMgr_CalToolSrvData.LastRespRet[function_index] = EYEQMESPMGR_CALTOOLSRV_RET_OK;
   }
   EyeQMespMgr_CalToolSrvData.ActiveFunction = EYEQMESPMGR_CALTOOLSRV_FCT_ID_NULL;
   EyeQMespMgr_CalToolSrvData.Status = 0u;
   EyeQMespMgr_CalToolSrvData.RequestTimer = 0u;
   EyeQMespMgr_CalToolSrvData.ProcessStatus = FALSE;
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQMespMgr_CODE) EyeQMespMgr_CalToolSrvMainFunction(void)
{
   Std_ReturnType ret;
   EyeQMespMgr_CalToolSrvIdxType fct_index;

   if (EYEQMESPMGR_CALTOOLSRV_FCT_ID_NULL == EyeQMespMgr_CalToolSrvData.ActiveFunction)
   {
      fct_index = 0u;
      while (fct_index < EYEQMESPMGR_CALTOOLSRV_IDX_NUM)
      {
         if (FALSE != EyeQMespMgr_CalToolSrvData.Requested[fct_index])
         {
            switch (fct_index)
            {
               case EYEQMESPMGR_CALTOOLSRV_IDX_SEND_PARAMS:
               {
                  ret = eyeqmespmgr_CalToolSrvSendParams();
                  if (E_OK == ret)
                  {
                     EyeQMespMgr_CalToolSrvData.RequestTimer = 0u;
                  }

                  break;
               }
               case EYEQMESPMGR_CALTOOLSRV_IDX_GET_PARAMS:
               {
                  ret = eyeqmespmgr_CalToolSrvGetParams();
                  if (E_OK == ret)
                  {
                     EyeQMespMgr_CalToolSrvData.RequestTimer = 0u;
                  }

                  break;
               }
               case EYEQMESPMGR_CALTOOLSRV_IDX_EVENT:
               {
                  ret = eyeqmespmgr_CalToolSrvEvent();
                  if (E_OK == ret)
                  {
                     EyeQMespMgr_CalToolSrvData.RequestTimer = 0u;
                  }

                  break;
               }
               default:
                  break;
            }
            fct_index = EYEQMESPMGR_CALTOOLSRV_IDX_NUM;
         }
         else
         {
            fct_index++;
         }

      }
   }
   else
   {
      /* check if timeout */
      EyeQMespMgr_CalToolSrvData.RequestTimer++;
      if (EYEQMESPMGR_REQ_TIMEOUT_CNT < EyeQMespMgr_CalToolSrvData.RequestTimer)
      {
         EyeQMespMgr_CalToolSrvData.RequestTimer = 0u;
         fct_index = EyeQMespMgr_CalToolSrvConvertFctIdToIdx(EyeQMespMgr_CalToolSrvData.ActiveFunction);
         EyeQMespMgr_CalToolSrvData.Status |= EYEQMESPMGR_CALTOOLSRV_STS_REQ_TIMEOUT;
         EyeQMespMgr_CalToolSrvData.ProcessStatus = TRUE;
         EyeQMespMgr_CalToolSrvData.Requested[fct_index] = FALSE;
         EyeQMespMgr_CalToolSrvData.ActiveFunction = EYEQMESPMGR_CALTOOLSRV_FCT_ID_NULL;
         if (NULL_PTR != EyeQMespMgr_CalToolSrvData.CallbackFctPtr[fct_index])
         {
            EyeQMespMgr_CalToolSrvData.CallbackFctPtr[fct_index](EYEQMESPMGR_CB_STS_REQ_FAILED);
         }
      }
   }

   if (FALSE != EyeQMespMgr_CalToolSrvData.ProcessStatus)
   {
      if (0u == EyeQMespMgr_CalToolSrvData.Status)
      {
         Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQMESPMGR_E_CALTOOL_RET_ERR, DEM_EVENT_STATUS_PREPASSED);
      }
      else
      {
         Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQMESPMGR_E_CALTOOL_RET_ERR, DEM_EVENT_STATUS_PREFAILED);
      }
      EyeQMespMgr_CalToolSrvData.Status = 0u;
      EyeQMespMgr_CalToolSrvData.ProcessStatus = FALSE;
   }
}
/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
LOCAL_INLINE FUNC(Std_ReturnType, EyeQMespMgr_CODE) eyeqmespmgr_CalToolSrvSendParams(void)
{
   Std_ReturnType ret;

   ret = EyeQAppl_TxRequest(EYEQMESPMGR_SRV_ID_CALTOOLSRV, EYEQMESPMGR_CALTOOLSRV_FCT_ID_SEND_PARAMS);
   if (E_OK == ret)
   {
      EyeQMespMgr_CalToolSrvData.ActiveFunction = EYEQMESPMGR_CALTOOLSRV_FCT_ID_SEND_PARAMS;
   }

   return (ret);
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
LOCAL_INLINE FUNC(Std_ReturnType, EyeQMespMgr_CODE) eyeqmespmgr_CalToolSrvGetParams(void)
{
   Std_ReturnType ret;

   ret = EyeQAppl_TxRequest(EYEQMESPMGR_SRV_ID_CALTOOLSRV, EYEQMESPMGR_CALTOOLSRV_FCT_ID_GET_PARAMS);
   if (E_OK == ret)
   {
      EyeQMespMgr_CalToolSrvData.ActiveFunction = EYEQMESPMGR_CALTOOLSRV_FCT_ID_GET_PARAMS;
   }

   return (ret);
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
LOCAL_INLINE FUNC(Std_ReturnType, EyeQMespMgr_CODE) eyeqmespmgr_CalToolSrvEvent(void)
{
   Std_ReturnType ret;

   ret = EyeQAppl_TxRequest(EYEQMESPMGR_SRV_ID_CALTOOLSRV, EYEQMESPMGR_CALTOOLSRV_FCT_ID_EVENT);
   if (E_OK == ret)
   {
      EyeQMespMgr_CalToolSrvData.ActiveFunction = EYEQMESPMGR_CALTOOLSRV_FCT_ID_EVENT;
   }

   return (ret);
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQMespMgr_CODE) EyeQMespMgr_CalToolSrvSendParamsCallback(CONST(EyeQAppl_CallbackStsType, AUTOMATIC)Status)
{
   EyeQMespMgr_CalToolSrvRetType resp_ret;
   EyeQMespMgr_CalToolSrvSendParamsRxDataType* src_ptr;

   if (EYEQMESPMGR_CALTOOLSRV_FCT_ID_SEND_PARAMS == EyeQMespMgr_CalToolSrvData.ActiveFunction)
   {
      EyeQMespMgr_CalToolSrvData.LastApplStatus[EYEQMESPMGR_CALTOOLSRV_IDX_SEND_PARAMS] = Status;
      switch (Status)
      {
         case EYEQAPPL_CB_STS_RX_FAILED:
         case EYEQAPPL_CB_STS_TX_FAILED:
         {
            EyeQMespMgr_CalToolSrvData.IsLastOk[EYEQMESPMGR_CALTOOLSRV_IDX_SEND_PARAMS] = FALSE;
            EyeQMespMgr_CalToolSrvData.Status |= EYEQMESPMGR_CALTOOLSRV_STS_APPL_FAILED;
            if (NULL_PTR != EyeQMespMgr_CalToolSrvData.CallbackFctPtr[EYEQMESPMGR_CALTOOLSRV_IDX_SEND_PARAMS])
            {
               EyeQMespMgr_CalToolSrvData.CallbackFctPtr[EYEQMESPMGR_CALTOOLSRV_IDX_SEND_PARAMS](EYEQMESPMGR_CB_STS_REQ_FAILED);
            }
            EyeQMespMgr_CalToolSrvData.ActiveFunction = EYEQMESPMGR_CALTOOLSRV_FCT_ID_NULL;
            EyeQMespMgr_CalToolSrvData.Requested[EYEQMESPMGR_CALTOOLSRV_IDX_SEND_PARAMS] = FALSE;
            break;
         }
         case EYEQAPPL_CB_STS_RX_OK:
         {
            resp_ret = EyeQMespMgr_GetRespRet();
            EyeQMespMgr_CalToolSrvData.LastRespRet[EYEQMESPMGR_CALTOOLSRV_IDX_SEND_PARAMS] = resp_ret;
            if (EYEQMESPMGR_CALTOOLSRV_RET_OK == resp_ret)
            {
               if (EYEQMESPMGR_CALTOOLSRV_SEND_PARAMS_RESP_LEN == EyeQMespMgr_CalToolSrvRespLength)
               {
                  src_ptr = (EyeQMespMgr_CalToolSrvSendParamsRxDataType*)&EyeQMespMgr_CalToolSrvRespData[0];
                  EyeQMespMgr_CalToolSrvData.SendParamsRxData = *src_ptr;
                  EyeQMespMgr_CalToolSrvData.IsLastOk[EYEQMESPMGR_CALTOOLSRV_IDX_SEND_PARAMS] = TRUE;
                  EyeQMespMgr_CalToolSrvData.IsOkOnce[EYEQMESPMGR_CALTOOLSRV_IDX_SEND_PARAMS] = TRUE;
                  if (NULL_PTR != EyeQMespMgr_CalToolSrvData.CallbackFctPtr[EYEQMESPMGR_CALTOOLSRV_IDX_SEND_PARAMS])
                  {
                     EyeQMespMgr_CalToolSrvData.CallbackFctPtr[EYEQMESPMGR_CALTOOLSRV_IDX_SEND_PARAMS](EYEQMESPMGR_CB_STS_REQ_FINISHED);
                  }
               }
               else
               {
                  EyeQMespMgr_CalToolSrvData.IsLastOk[EYEQMESPMGR_CALTOOLSRV_IDX_SEND_PARAMS] = FALSE;
                  EyeQMespMgr_CalToolSrvData.Status |= EYEQMESPMGR_CALTOOLSRV_STS_DATA_ERROR;
                  if (NULL_PTR != EyeQMespMgr_CalToolSrvData.CallbackFctPtr[EYEQMESPMGR_CALTOOLSRV_IDX_SEND_PARAMS])
                  {
                     EyeQMespMgr_CalToolSrvData.CallbackFctPtr[EYEQMESPMGR_CALTOOLSRV_IDX_SEND_PARAMS](EYEQMESPMGR_CB_STS_REQ_FAILED);
                  }
               }
            }
            else
            {
               EyeQMespMgr_CalToolSrvData.IsLastOk[EYEQMESPMGR_CALTOOLSRV_IDX_SEND_PARAMS] = FALSE;
               EyeQMespMgr_CalToolSrvData.Status |= EYEQMESPMGR_CALTOOLSRV_STS_RET_ERROR;
               if (NULL_PTR != EyeQMespMgr_CalToolSrvData.CallbackFctPtr[EYEQMESPMGR_CALTOOLSRV_IDX_SEND_PARAMS])
               {
                  EyeQMespMgr_CalToolSrvData.CallbackFctPtr[EYEQMESPMGR_CALTOOLSRV_IDX_SEND_PARAMS](EYEQMESPMGR_CB_STS_REQ_FAILED);
               }
            }
            EyeQMespMgr_CalToolSrvData.ActiveFunction = EYEQMESPMGR_CALTOOLSRV_FCT_ID_NULL;
            EyeQMespMgr_CalToolSrvData.Requested[EYEQMESPMGR_CALTOOLSRV_IDX_SEND_PARAMS] = FALSE;
            break;
         }
         case EYEQAPPL_CB_STS_TX_OK:
         case EYEQAPPL_CB_STS_RX_NEW_FRAME:
            EyeQMespMgr_CalToolSrvData.RequestTimer = 0u;
            break;
         default:
            break;
      }
   }
   else
   {
      EyeQMespMgr_CalToolSrvData.Status |= EYEQMESPMGR_CALTOOLSRV_STS_INVALID_RESP;
   }
   EyeQMespMgr_CalToolSrvData.ProcessStatus = TRUE;
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQMespMgr_CODE) EyeQMespMgr_CalToolSrvGetParamsCallback(CONST(EyeQAppl_CallbackStsType, AUTOMATIC)Status)
{
   EyeQMespMgr_CalToolSrvRetType resp_ret;
   EyeQMespMgr_CalToolSrvGetParamsRxDataType* src_ptr;

   if (EYEQMESPMGR_CALTOOLSRV_FCT_ID_GET_PARAMS == EyeQMespMgr_CalToolSrvData.ActiveFunction)
   {
      EyeQMespMgr_CalToolSrvData.LastApplStatus[EYEQMESPMGR_CALTOOLSRV_IDX_GET_PARAMS] = Status;
      switch (Status)
      {
         case EYEQAPPL_CB_STS_RX_FAILED:
         case EYEQAPPL_CB_STS_TX_FAILED:
         {
            EyeQMespMgr_CalToolSrvData.IsLastOk[EYEQMESPMGR_CALTOOLSRV_IDX_GET_PARAMS] = FALSE;
            EyeQMespMgr_CalToolSrvData.Status |= EYEQMESPMGR_CALTOOLSRV_STS_APPL_FAILED;
            if (NULL_PTR != EyeQMespMgr_CalToolSrvData.CallbackFctPtr[EYEQMESPMGR_CALTOOLSRV_IDX_GET_PARAMS])
            {
               EyeQMespMgr_CalToolSrvData.CallbackFctPtr[EYEQMESPMGR_CALTOOLSRV_IDX_GET_PARAMS](EYEQMESPMGR_CB_STS_REQ_FAILED);
            }
            EyeQMespMgr_CalToolSrvData.ActiveFunction = EYEQMESPMGR_CALTOOLSRV_FCT_ID_NULL;
            EyeQMespMgr_CalToolSrvData.Requested[EYEQMESPMGR_CALTOOLSRV_IDX_GET_PARAMS] = FALSE;
            break;
         }
         case EYEQAPPL_CB_STS_RX_OK:
         {
            resp_ret = EyeQMespMgr_GetRespRet();
            EyeQMespMgr_CalToolSrvData.LastRespRet[EYEQMESPMGR_CALTOOLSRV_IDX_GET_PARAMS] = resp_ret;
            if (EYEQMESPMGR_CALTOOLSRV_RET_OK == resp_ret)
            {
               if (EYEQMESPMGR_CALTOOLSRV_GET_PARAMS_RX_MIN_LEN <= EyeQMespMgr_CalToolSrvRespLength)
               {
                  EyeQMespMgr_CalToolSrvData.GetParamsRxLength = (uint16)EyeQMespMgr_CalToolSrvRespLength;
                  src_ptr = (EyeQMespMgr_CalToolSrvGetParamsRxDataType*)&EyeQMespMgr_CalToolSrvRespData[0];
                  /* 
                   * Copy the whole GetParamsRxData from response buffer, when need to get/return data please 
                   *  use the RxLength or params size info to decide the data size to be returned 
                   */
                  EyeQMespMgr_CalToolSrvData.GetParamsRxData = *src_ptr;
                  EyeQMespMgr_CalToolSrvData.IsLastOk[EYEQMESPMGR_CALTOOLSRV_IDX_GET_PARAMS] = TRUE;
                  EyeQMespMgr_CalToolSrvData.IsOkOnce[EYEQMESPMGR_CALTOOLSRV_IDX_GET_PARAMS] = TRUE;
                  if (NULL_PTR != EyeQMespMgr_CalToolSrvData.CallbackFctPtr[EYEQMESPMGR_CALTOOLSRV_IDX_GET_PARAMS])
                  {
                     EyeQMespMgr_CalToolSrvData.CallbackFctPtr[EYEQMESPMGR_CALTOOLSRV_IDX_GET_PARAMS](EYEQMESPMGR_CB_STS_REQ_FINISHED);
                  }
               }
               else
               {
                  EyeQMespMgr_CalToolSrvData.IsLastOk[EYEQMESPMGR_CALTOOLSRV_IDX_GET_PARAMS] = FALSE;
                  EyeQMespMgr_CalToolSrvData.Status |= EYEQMESPMGR_CALTOOLSRV_STS_DATA_ERROR;
                  if (NULL_PTR != EyeQMespMgr_CalToolSrvData.CallbackFctPtr[EYEQMESPMGR_CALTOOLSRV_IDX_GET_PARAMS])
                  {
                     EyeQMespMgr_CalToolSrvData.CallbackFctPtr[EYEQMESPMGR_CALTOOLSRV_IDX_GET_PARAMS](EYEQMESPMGR_CB_STS_REQ_FAILED);
                  }
               }

            }
            else
            {
               EyeQMespMgr_CalToolSrvData.IsLastOk[EYEQMESPMGR_CALTOOLSRV_IDX_GET_PARAMS] = FALSE;
               EyeQMespMgr_CalToolSrvData.Status |= EYEQMESPMGR_CALTOOLSRV_STS_RET_ERROR;
               if (NULL_PTR != EyeQMespMgr_CalToolSrvData.CallbackFctPtr[EYEQMESPMGR_CALTOOLSRV_IDX_GET_PARAMS])
               {
                  EyeQMespMgr_CalToolSrvData.CallbackFctPtr[EYEQMESPMGR_CALTOOLSRV_IDX_GET_PARAMS](EYEQMESPMGR_CB_STS_REQ_FAILED);
               }
            }
            EyeQMespMgr_CalToolSrvData.ActiveFunction = EYEQMESPMGR_CALTOOLSRV_FCT_ID_NULL;
            EyeQMespMgr_CalToolSrvData.Requested[EYEQMESPMGR_CALTOOLSRV_IDX_GET_PARAMS] = FALSE;
            break;
         }
         case EYEQAPPL_CB_STS_TX_OK:
         case EYEQAPPL_CB_STS_RX_NEW_FRAME:
            EyeQMespMgr_CalToolSrvData.RequestTimer = 0u;
            break;
         default:
            break;
      }
   }
   else
   {
      EyeQMespMgr_CalToolSrvData.Status |= EYEQMESPMGR_CALTOOLSRV_STS_INVALID_RESP;
   }
   EyeQMespMgr_CalToolSrvData.ProcessStatus = TRUE;
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQMespMgr_CODE) EyeQMespMgr_CalToolSrvEventCallback(CONST(EyeQAppl_CallbackStsType, AUTOMATIC)Status)
{
   EyeQMespMgr_CalToolSrvRetType resp_ret;
   EyeQMespMgr_CalToolSrvEventRxDataType* src_ptr;

   if (EYEQMESPMGR_CALTOOLSRV_FCT_ID_EVENT == EyeQMespMgr_CalToolSrvData.ActiveFunction)
   {
      EyeQMespMgr_CalToolSrvData.LastApplStatus[EYEQMESPMGR_CALTOOLSRV_IDX_EVENT] = Status;
      switch (Status)
      {
         case EYEQAPPL_CB_STS_RX_FAILED:
         case EYEQAPPL_CB_STS_TX_FAILED:
         {
            EyeQMespMgr_CalToolSrvData.IsLastOk[EYEQMESPMGR_CALTOOLSRV_IDX_EVENT] = FALSE;
            EyeQMespMgr_CalToolSrvData.Status |= EYEQMESPMGR_CALTOOLSRV_STS_APPL_FAILED;
            if (NULL_PTR != EyeQMespMgr_CalToolSrvData.CallbackFctPtr[EYEQMESPMGR_CALTOOLSRV_IDX_EVENT])
            {
               EyeQMespMgr_CalToolSrvData.CallbackFctPtr[EYEQMESPMGR_CALTOOLSRV_IDX_EVENT](EYEQMESPMGR_CB_STS_REQ_FAILED);
            }
            EyeQMespMgr_CalToolSrvData.ActiveFunction = EYEQMESPMGR_CALTOOLSRV_FCT_ID_NULL;
            EyeQMespMgr_CalToolSrvData.Requested[EYEQMESPMGR_CALTOOLSRV_IDX_EVENT] = FALSE;
            break;
         }
         case EYEQAPPL_CB_STS_RX_OK:
         {
            resp_ret = EyeQMespMgr_GetRespRet();
            EyeQMespMgr_CalToolSrvData.LastRespRet[EYEQMESPMGR_CALTOOLSRV_IDX_EVENT] = resp_ret;
            if (EYEQMESPMGR_CALTOOLSRV_RET_OK == resp_ret)
            {
               if (EYEQMESPMGR_CALTOOLSRV_EVENT_RX_MIN_LEN <= EyeQMespMgr_CalToolSrvRespLength)
               {
                  EyeQMespMgr_CalToolSrvData.EventRxLength = (uint16)EyeQMespMgr_CalToolSrvRespLength;
                  src_ptr = (EyeQMespMgr_CalToolSrvEventRxDataType*)&EyeQMespMgr_CalToolSrvRespData[0];
                  /*
                   * Copy the whole EventRxData from response buffer, when need to get/return data please
                   *  use the RxLength or params size info to decide the data size to be returned
                   */
                  EyeQMespMgr_CalToolSrvData.EventRxData = *src_ptr;
                  EyeQMespMgr_CalToolSrvData.IsLastOk[EYEQMESPMGR_CALTOOLSRV_IDX_EVENT] = TRUE;
                  EyeQMespMgr_CalToolSrvData.IsOkOnce[EYEQMESPMGR_CALTOOLSRV_IDX_EVENT] = TRUE;
                  if (NULL_PTR != EyeQMespMgr_CalToolSrvData.CallbackFctPtr[EYEQMESPMGR_CALTOOLSRV_IDX_EVENT])
                  {
                     EyeQMespMgr_CalToolSrvData.CallbackFctPtr[EYEQMESPMGR_CALTOOLSRV_IDX_EVENT](EYEQMESPMGR_CB_STS_REQ_FINISHED);
                  }
               }
               else
               {
                  EyeQMespMgr_CalToolSrvData.IsLastOk[EYEQMESPMGR_CALTOOLSRV_IDX_EVENT] = FALSE;
                  EyeQMespMgr_CalToolSrvData.Status |= EYEQMESPMGR_CALTOOLSRV_STS_DATA_ERROR;
                  if (NULL_PTR != EyeQMespMgr_CalToolSrvData.CallbackFctPtr[EYEQMESPMGR_CALTOOLSRV_IDX_EVENT])
                  {
                     EyeQMespMgr_CalToolSrvData.CallbackFctPtr[EYEQMESPMGR_CALTOOLSRV_IDX_EVENT](EYEQMESPMGR_CB_STS_REQ_FAILED);
                  }
               }
               
            }
            else
            {
               EyeQMespMgr_CalToolSrvData.IsLastOk[EYEQMESPMGR_CALTOOLSRV_IDX_EVENT] = FALSE;
               EyeQMespMgr_CalToolSrvData.Status |= EYEQMESPMGR_CALTOOLSRV_STS_RET_ERROR;
               if (NULL_PTR != EyeQMespMgr_CalToolSrvData.CallbackFctPtr[EYEQMESPMGR_CALTOOLSRV_IDX_EVENT])
               {
                  EyeQMespMgr_CalToolSrvData.CallbackFctPtr[EYEQMESPMGR_CALTOOLSRV_IDX_EVENT](EYEQMESPMGR_CB_STS_REQ_FAILED);
               }
            }
            EyeQMespMgr_CalToolSrvData.ActiveFunction = EYEQMESPMGR_CALTOOLSRV_FCT_ID_NULL;
            EyeQMespMgr_CalToolSrvData.Requested[EYEQMESPMGR_CALTOOLSRV_IDX_EVENT] = FALSE;
            break;
         }
         case EYEQAPPL_CB_STS_TX_OK:
         case EYEQAPPL_CB_STS_RX_NEW_FRAME:
            EyeQMespMgr_CalToolSrvData.RequestTimer = 0u;
            break;
         default:
            break;
      }
   }
   else
   {
      EyeQMespMgr_CalToolSrvData.Status |= EYEQMESPMGR_CALTOOLSRV_STS_INVALID_RESP;
   }
   EyeQMespMgr_CalToolSrvData.ProcessStatus = TRUE;
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(Std_ReturnType, EyeQMespMgr_CODE) EyeQMespMgr_CalToolSrvSendParams(CONST(EyeQMespMgr_ReqCallbackFct, AUTOMATIC) CallbackFctPtr, 
   CONSTP2CONST(EyeQMespMgr_CalToolSrvSendParamsTxDataType, AUTOMATIC, EyeQMespMgr_APPL_CONST) TxDataPtr, CONST(uint16, AUTOMATIC) TxDataLength)
{
   Std_ReturnType ret;
   
   if ((FALSE == EyeQMespMgr_CalToolSrvData.Requested[EYEQMESPMGR_CALTOOLSRV_IDX_SEND_PARAMS])
      && (TxDataLength <= sizeof(EyeQMespMgr_CalToolSrvSendParamsTxDataType))
      && (EYEQMESPMGR_CALTOOLSRV_SEND_PARAMS_TX_MIN_LEN <= TxDataLength) 
      && (NULL_PTR != TxDataPtr))
   {
      /*
       * Copy the whole data structure from TxDataPtr, when need to get/return data please
       *  use the TxDataLength or params size info to decide the data size to be copied
       */
      EyeQMespMgr_CalToolSrvSendParamsTxData = *TxDataPtr;
      EyeQMespMgr_CalToolSrvData.SendParamsTxLength = TxDataLength;
      EyeQMespMgr_CalToolSrvData.CallbackFctPtr[EYEQMESPMGR_CALTOOLSRV_IDX_SEND_PARAMS] = CallbackFctPtr;
      EyeQMespMgr_CalToolSrvData.Requested[EYEQMESPMGR_CALTOOLSRV_IDX_SEND_PARAMS] = TRUE;
      ret = E_OK;
   }
   else
   {
      ret = E_NOT_OK;
   }

   return (ret);
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(Std_ReturnType, EyeQMespMgr_CODE) EyeQMespMgr_CalToolSrvGetParams(CONST(EyeQMespMgr_ReqCallbackFct, AUTOMATIC) CallbackFctPtr, 
   CONSTP2CONST(EyeQMespMgr_CalToolSrvGetParamsTxDataType, AUTOMATIC, EyeQMespMgr_APPL_CONST) TxDataPtr, CONST(uint16, AUTOMATIC) TxDataLength)
{
   Std_ReturnType ret;

   if ((FALSE == EyeQMespMgr_CalToolSrvData.Requested[EYEQMESPMGR_CALTOOLSRV_IDX_GET_PARAMS])
      && (TxDataLength == sizeof(EyeQMespMgr_CalToolSrvGetParamsTxDataType))
      && (NULL_PTR != TxDataPtr))
   {
      EyeQMespMgr_CalToolSrvGetParamsTxData = *TxDataPtr;
      EyeQMespMgr_CalToolSrvData.CallbackFctPtr[EYEQMESPMGR_CALTOOLSRV_IDX_GET_PARAMS] = CallbackFctPtr;
      EyeQMespMgr_CalToolSrvData.Requested[EYEQMESPMGR_CALTOOLSRV_IDX_GET_PARAMS] = TRUE;
      ret = E_OK;
   }
   else
   {
      ret = E_NOT_OK;
   }

   return (ret);
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*   The caller of this Api should also calculate and provide the ct_crc in the message data
******************************************************************************/
FUNC(Std_ReturnType, EyeQMespMgr_CODE) EyeQMespMgr_CalToolSrvEvent(
   CONST(EyeQMespMgr_CalToolSrvCtType, AUTOMATIC) CtType,
   CONST(uint8, AUTOMATIC) StageOrMsgId,
   CONSTP2CONST(uint8, AUTOMATIC, EyeQMespMgr_APPL_CONST) TxDataPtr,
   CONST(uint16, AUTOMATIC) TxDataLength,
   CONST(uint16, AUTOMATIC) ParamsNum,
   CONST(EyeQMespMgr_ReqCallbackFct, AUTOMATIC) CallbackFctPtr)
{
   Std_ReturnType ret;
   uint16 data_index;

   if ((FALSE == EyeQMespMgr_CalToolSrvData.Requested[EYEQMESPMGR_CALTOOLSRV_IDX_EVENT])
      && (TxDataLength <= EYEQMESPMGR_PARAMS_BYTE_MAX_SIZE)
      && (NULL_PTR != TxDataPtr))
   {
      /*
       * Copy the whole data structure from TxDataPtr, when need to get/return data please
       *  use the TxDataLength or params size info to decide the data size to be copied
       */
      EyeQMespMgr_CalToolSrvEventTxData.ct_type = CtType;
      EyeQMespMgr_CalToolSrvEventTxData.ct_params_num = ParamsNum;
      EyeQMespMgr_CalToolSrvEventTxData.ct_stage = StageOrMsgId;
      EyeQMespMgr_CalToolSrvEventTxData.params.Size = TxDataLength;
      EyeQMespMgr_CalToolSrvEventTxData.ct_version = EYEQMESPMGR_CALTOOLSRV_CTVERSION_2;
      for (data_index = 0u; data_index < TxDataLength; data_index++)
      {
         EyeQMespMgr_CalToolSrvEventTxData.params.Bytes[data_index] = TxDataPtr[data_index];
      }

      EyeQMespMgr_CalToolSrvEventTxData.ct_crc = Crc_CalculateCRC32((uint8*)&EyeQMespMgr_CalToolSrvEventTxData.params.Bytes[0],
            TxDataLength, EYEQMESPMGR_CALTOOLSRV_CRC_START_VAL, TRUE);

      EyeQMespMgr_CalToolSrvData.EventTxLength = TxDataLength + EYEQMESPMGR_CALTOOLSRV_EVENT_TX_MIN_LEN;
      EyeQMespMgr_CalToolSrvData.CallbackFctPtr[EYEQMESPMGR_CALTOOLSRV_IDX_EVENT] = CallbackFctPtr;
      EyeQMespMgr_CalToolSrvData.Requested[EYEQMESPMGR_CALTOOLSRV_IDX_EVENT] = TRUE;
      ret = E_OK;
   }
   else
   {
      ret = E_NOT_OK;
   }

   return (ret);
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(uint32, EyeQMespMgr_CODE) EyeQMespMgr_CalToolSrvGetSendParamsTxLength(void)
{
   return ((uint32)EyeQMespMgr_CalToolSrvData.SendParamsTxLength);
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(uint32, EyeQMespMgr_CODE) EyeQMespMgr_CalToolSrvGetEventTxLength(void)
{
   return ((uint32)EyeQMespMgr_CalToolSrvData.EventTxLength);
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(Std_ReturnType, EyeQMespMgr_CODE) EyeQMespMgr_CalToolSrvGetRxSendParamsData(CONSTP2VAR(EyeQMespMgr_CalToolSrvSendParamsRxDataType, AUTOMATIC, EyeQMespMgr_APPL_CONST) RetDataPtr)
{
   Std_ReturnType ret;

   if ((FALSE != EyeQMespMgr_CalToolSrvData.IsLastOk[EYEQMESPMGR_CALTOOLSRV_IDX_SEND_PARAMS])
      && (EYEQMESPMGR_CALTOOLSRV_FCT_ID_SEND_PARAMS != EyeQMespMgr_CalToolSrvData.ActiveFunction)
      && (NULL_PTR != RetDataPtr))
   {
      *RetDataPtr = EyeQMespMgr_CalToolSrvData.SendParamsRxData;
      ret = E_OK;
   }
   else
   {
      ret = E_NOT_OK;
   }

   return (ret);
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(Std_ReturnType, EyeQMespMgr_CODE) EyeQMespMgr_CalToolSrvGetRxGetParamsData(CONSTP2VAR(EyeQMespMgr_CalToolSrvGetParamsRxDataType, AUTOMATIC, EyeQMespMgr_APPL_CONST) RetDataPtr)
{
   Std_ReturnType ret;

   if ((FALSE != EyeQMespMgr_CalToolSrvData.IsLastOk[EYEQMESPMGR_CALTOOLSRV_IDX_GET_PARAMS])
      && (EYEQMESPMGR_CALTOOLSRV_FCT_ID_GET_PARAMS != EyeQMespMgr_CalToolSrvData.ActiveFunction)
      && (NULL_PTR != RetDataPtr))
   {
      *RetDataPtr = EyeQMespMgr_CalToolSrvData.GetParamsRxData;
      ret = E_OK;
   }
   else
   {
      ret = E_NOT_OK;
   }

   return (ret);
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*   The caller of this Api should also verify the ct_crc is correct in the message data
******************************************************************************/
FUNC(Std_ReturnType, EyeQMespMgr_CODE) EyeQMespMgr_CalToolSrvGetRxEventData(CONSTP2VAR(EyeQMespMgr_CalToolSrvEventRxDataType, AUTOMATIC, EyeQMespMgr_APPL_CONST) RetDataPtr)
{
   Std_ReturnType ret;

   if ((FALSE != EyeQMespMgr_CalToolSrvData.IsLastOk[EYEQMESPMGR_CALTOOLSRV_IDX_EVENT])
      && (EYEQMESPMGR_CALTOOLSRV_FCT_ID_EVENT != EyeQMespMgr_CalToolSrvData.ActiveFunction)
      && (NULL_PTR != RetDataPtr))
   {
      *RetDataPtr = EyeQMespMgr_CalToolSrvData.EventRxData;
      ret = E_OK;
   }
   else
   {
      ret = E_NOT_OK;
   }

   return (ret);
}

#define EyeQMespMgr_STOP_SEC_CODE
#include "EyeQMespMgr_MemMap.h"
/******************************************************************************
End Of File
******************************************************************************/
