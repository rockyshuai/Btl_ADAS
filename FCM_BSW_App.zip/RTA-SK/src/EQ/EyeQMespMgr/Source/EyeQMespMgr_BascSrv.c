
/******************************************************************************

WBTL ELECTRONIC document

Copyright WBTL. All rights reserved.

******************************************************************************/
/******************************************************************************

@details
   <Describes details of this component implementation and design>

******************************************************************************/
/******************************************************************************
External Dependencies
******************************************************************************/
#include <EyeQMespMgr.h>
#include <EyeQMespMgr_BascSrv.h>
#include <EyeQMespMgr_Intl.h>
#include <EyeQAppl.h>

/******************************************************************************
Component Defines
******************************************************************************/
#define EYEQMESPMGR_BASCSRV_MAIN_ST_OFFSET       (4u)
#define EYEQMESPMGR_BASCSRV_SUB_ST_OFFSET        (5u)
#define EYEQMESPMGR_BASCSRV_ABOUT_OFFSET         (4u)
#define EYEQMESPMGR_BASCSRV_VERS_OFFSET          (4u)
/******************************************************************************
Component Types
******************************************************************************/
typedef struct EyeQMespMgr_BascSrvDataTypeTag
{
   uint32 Versions[EYEQMESPMGR_BASCSRV_VERSION_BUFF_SIZE];
   EyeQMespMgr_BascSrvRetType LastCmdRetValue[EYEQMESPMGR_BASCSRV_IDX_NUM];
   EyeQMespMgr_ReqCallbackFct CallbackFctPtr[EYEQMESPMGR_BASCSRV_IDX_NUM];
   EyeQMespMgr_BascSrvStsType Status;
   EyeQMespMgr_BascSrvFctIdType ActiveFunction;
   EyeQMespMgr_BascSrvMainStType MainSt;
   EyeQMespMgr_BascSrvSubStType SubSt;
   EyeQAppl_CallbackStsType LastApplStatus[EYEQMESPMGR_BASCSRV_IDX_NUM];
   uint16 RequestTimer;
   uint16 AboutStringLength;
   uint8 AboutStr[EYEQMESPMGR_BASCSRV_ABOUT_BUFF_SIZE];
   boolean Requested[EYEQMESPMGR_BASCSRV_IDX_NUM];
   boolean IsOkOnce[EYEQMESPMGR_BASCSRV_IDX_NUM];
   boolean IsLastOk[EYEQMESPMGR_BASCSRV_IDX_NUM];
   boolean ProcessStatus;
}EyeQMespMgr_BascSrvDataType;

/******************************************************************************
Declaration of Local Functions
******************************************************************************/
LOCAL_INLINE FUNC(Std_ReturnType, EyeQMespMgr_CODE) eyeqmespmgr_BascSrvSwitchApp(CONST(EyeQMespMgr_BascSrvSwtAppIdType, AUTOMATIC) AppId);
LOCAL_INLINE FUNC(Std_ReturnType, EyeQMespMgr_CODE) eyeqmespmgr_BascSrvReadMainSt(void);
LOCAL_INLINE FUNC(Std_ReturnType, EyeQMespMgr_CODE) eyeqmespmgr_BascSrvReadExSt(void);
LOCAL_INLINE FUNC(Std_ReturnType, EyeQMespMgr_CODE) eyeqmespmgr_BascSrvReadAbout(void);
LOCAL_INLINE FUNC(Std_ReturnType, EyeQMespMgr_CODE) eyeqmespmgr_BascSrvReadVers(void);
LOCAL_INLINE FUNC(void, EyeQMespMgr_CODE) eyeqmespmgr_BascSrvProcessStatus(void);

#define EyeQMespMgr_START_SEC_VAR
#include "EyeQMespMgr_MemMap.h"
/******************************************************************************
Definition Of Local Variables
******************************************************************************/
LOCAL VAR(EyeQMespMgr_BascSrvDataType, EyeQMespMgr_VAR) EyeQMespMgr_BascSrvData;

/******************************************************************************
Definition Of Global Variables
******************************************************************************/
VAR(uint32, EyeQMespMgr_VAR) EyeQMespMgr_BascSrvRespLength;
VAR(uint8, EyeQMespMgr_VAR) EyeQMespMgr_BascSrvRespData[EYEQMESPMGR_BASCSRV_RESP_BUFF_SIZE];
VAR(EyeQMespMgr_BascSrvSwtAppIdType, EyeQMespMgr_VAR) EyeQMespMgr_SwitchAppData;

#define EyeQMespMgr_STOP_SEC_VAR
#include "EyeQMespMgr_MemMap.h"

#define EyeQMespMgr_START_SEC_CONST
#include "EyeQMespMgr_MemMap.h"
/******************************************************************************
Definition Of Local Constant Data
******************************************************************************/

/******************************************************************************
Definition Of Global Constant Data
******************************************************************************/

#define EyeQMespMgr_STOP_SEC_CONST
#include "EyeQMespMgr_MemMap.h"
/******************************************************************************
Component Function-like Macros
******************************************************************************/
#define EyeQMespMgr_GetRespRet()          (*(uint32*)EyeQMespMgr_BascSrvRespData)

/******************************************************************************
Definition Of APIs
******************************************************************************/
#define EyeQMespMgr_START_SEC_CODE
#include "EyeQMespMgr_MemMap.h"

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQMespMgr_CODE) EyeQMespMgr_BascSrvInit(void)
{
   EyeQMespMgr_BascSrvIdxType function_index;

   for (function_index = 0; function_index < EYEQMESPMGR_BASCSRV_IDX_NUM; function_index++)
   {
      EyeQMespMgr_BascSrvData.IsLastOk[function_index] = FALSE;
      EyeQMespMgr_BascSrvData.IsOkOnce[function_index] = FALSE;
      EyeQMespMgr_BascSrvData.Requested[function_index] = FALSE;
      EyeQMespMgr_BascSrvData.LastApplStatus[function_index] = EYEQAPPL_CB_STS_TX_FAILED;
      EyeQMespMgr_BascSrvData.LastCmdRetValue[function_index] = EYEQMESPMGR_BASCSRV_RET_OK;
   }
   EyeQMespMgr_BascSrvData.ActiveFunction = EYEQMESPMGR_BASCSRV_FCT_ID_NULL;
   EyeQMespMgr_BascSrvData.Status = 0u;
   EyeQMespMgr_BascSrvData.ProcessStatus = FALSE;
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQMespMgr_CODE) EyeQMespMgr_BascSrvMainFunction(void)
{
   Std_ReturnType ret;
   EyeQMespMgr_BascSrvIdxType fct_index;

   if (EYEQMESPMGR_BASCSRV_FCT_ID_NULL == EyeQMespMgr_BascSrvData.ActiveFunction)
   {
      fct_index = 0u;
      while (fct_index < EYEQMESPMGR_BASCSRV_IDX_NUM)
      {
         if (FALSE != EyeQMespMgr_BascSrvData.Requested[fct_index])
         {
            switch (fct_index)
            {
               case EYEQMESPMGR_BASCSRV_IDX_MAIN_ST:
               {
                  ret = eyeqmespmgr_BascSrvReadMainSt();
                  if (E_OK == ret)
                  {
                     EyeQMespMgr_BascSrvData.RequestTimer = 0u;
                  }

                  break;
               }
               case EYEQMESPMGR_BASCSRV_IDX_ABOUT:
               {
                  ret = eyeqmespmgr_BascSrvReadAbout();
                  if (E_OK == ret)
                  {
                     EyeQMespMgr_BascSrvData.RequestTimer = 0u;
                  }

                  break;
               }
               case EYEQMESPMGR_BASCSRV_IDX_EX_ST:
               {
                  ret = eyeqmespmgr_BascSrvReadExSt();
                  if (E_OK == ret)
                  {
                     EyeQMespMgr_BascSrvData.RequestTimer = 0u;
                  }

                  break;
               }
               case EYEQMESPMGR_BASCSRV_IDX_VERS:
               {
                  ret = eyeqmespmgr_BascSrvReadVers();
                  if (E_OK == ret)
                  {
                     EyeQMespMgr_BascSrvData.RequestTimer = 0u;
                  }

                  break;
               }
               case EYEQMESPMGR_BASCSRV_IDX_SWT_APP:
               {
                  ret = eyeqmespmgr_BascSrvSwitchApp(EyeQMespMgr_SwitchAppData);
                  if (E_OK == ret)
                  {
                     EyeQMespMgr_BascSrvData.RequestTimer = 0u;
                  }

                  break;
               }
               default:
                  break;
            }
            fct_index = EYEQMESPMGR_BASCSRV_IDX_NUM;
         }
         else
         {
            fct_index++;
         }

      }
   }
   else
   {
      /* check if timeout */
      EyeQMespMgr_BascSrvData.RequestTimer++;
      if (EYEQMESPMGR_REQ_TIMEOUT_CNT < EyeQMespMgr_BascSrvData.RequestTimer)
      {
         EyeQMespMgr_BascSrvData.RequestTimer = 0u;
         fct_index = EyeQMespMgr_BascSrvConvertFctIdToIdx(EyeQMespMgr_BascSrvData.ActiveFunction);
         EyeQMespMgr_BascSrvData.Status |= EYEQMESPMGR_BASCSRV_STS_REQ_TIMEOUT;
         EyeQMespMgr_BascSrvData.ProcessStatus = TRUE;
         EyeQMespMgr_BascSrvData.Requested[fct_index] = FALSE;
         EyeQMespMgr_BascSrvData.ActiveFunction = EYEQMESPMGR_BASCSRV_FCT_ID_NULL;
         if (NULL_PTR != EyeQMespMgr_BascSrvData.CallbackFctPtr[fct_index])
         {
            EyeQMespMgr_BascSrvData.CallbackFctPtr[fct_index](EYEQMESPMGR_CB_STS_REQ_FAILED);
         }
      }
   }

   if (FALSE != EyeQMespMgr_BascSrvData.ProcessStatus)
   {
      eyeqmespmgr_BascSrvProcessStatus();
      EyeQMespMgr_BascSrvData.ProcessStatus = FALSE;
   }
}
/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
LOCAL_INLINE FUNC(Std_ReturnType, EyeQMespMgr_CODE) eyeqmespmgr_BascSrvReadMainSt(void)
{
   Std_ReturnType ret;

   ret = EyeQAppl_TxRequest(EYEQMESPMGR_SRV_ID_BASCSRV, EYEQMESPMGR_BASCSRV_FCT_ID_MAIN_ST);
   if (E_OK == ret)
   {
      EyeQMespMgr_BascSrvData.ActiveFunction = EYEQMESPMGR_BASCSRV_FCT_ID_MAIN_ST;
   }

   return (ret);
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
LOCAL_INLINE FUNC(Std_ReturnType, EyeQMespMgr_CODE) eyeqmespmgr_BascSrvReadExSt(void)
{
   Std_ReturnType ret;

   ret = EyeQAppl_TxRequest(EYEQMESPMGR_SRV_ID_BASCSRV, EYEQMESPMGR_BASCSRV_FCT_ID_EX_ST);
   if (E_OK == ret)
   {
      EyeQMespMgr_BascSrvData.ActiveFunction = EYEQMESPMGR_BASCSRV_FCT_ID_EX_ST;
   }

   return (ret);
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
LOCAL_INLINE FUNC(Std_ReturnType, EyeQMespMgr_CODE) eyeqmespmgr_BascSrvReadAbout(void)
{
   Std_ReturnType ret;

   ret = EyeQAppl_TxRequest(EYEQMESPMGR_SRV_ID_BASCSRV, EYEQMESPMGR_BASCSRV_FCT_ID_ABOUT);
   if (E_OK == ret)
   {
      EyeQMespMgr_BascSrvData.ActiveFunction = EYEQMESPMGR_BASCSRV_FCT_ID_ABOUT;
   }

   return (ret);
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
LOCAL_INLINE FUNC(Std_ReturnType, EyeQMespMgr_CODE) eyeqmespmgr_BascSrvReadVers(void)
{
   Std_ReturnType ret;

   ret = EyeQAppl_TxRequest(EYEQMESPMGR_SRV_ID_BASCSRV, EYEQMESPMGR_BASCSRV_FCT_ID_VERS);
   if (E_OK == ret)
   {
      EyeQMespMgr_BascSrvData.ActiveFunction = EYEQMESPMGR_BASCSRV_FCT_ID_VERS;
   }

   return (ret);
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
LOCAL_INLINE FUNC(Std_ReturnType, EyeQMespMgr_CODE) eyeqmespmgr_BascSrvSwitchApp(CONST(EyeQMespMgr_BascSrvSwtAppIdType, AUTOMATIC) AppId)
{
   Std_ReturnType ret;

   EyeQMespMgr_SwitchAppData = AppId;
   ret = EyeQAppl_TxRequest(EYEQMESPMGR_SRV_ID_BASCSRV, EYEQMESPMGR_BASCSRV_FCT_ID_SWT_APP);
   if (E_OK == ret)
   {
      EyeQMespMgr_BascSrvData.ActiveFunction = EYEQMESPMGR_BASCSRV_FCT_ID_SWT_APP;
   }

   return (ret);
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
LOCAL_INLINE FUNC(void, EyeQMespMgr_CODE) eyeqmespmgr_BascSrvProcessStatus(void)
{
   if (0u == EyeQMespMgr_BascSrvData.Status)
   {
      Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQMESPMGR_E_BASCSRV_RET_ERR, DEM_EVENT_STATUS_PREPASSED);
   }
   else
   {
      Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQMESPMGR_E_BASCSRV_RET_ERR, DEM_EVENT_STATUS_PREFAILED);
   }
   EyeQMespMgr_BascSrvData.Status = 0u;
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQMespMgr_CODE) EyeQMespMgr_BascSrvMainStCallback(CONST(EyeQAppl_CallbackStsType, AUTOMATIC)Status)
{
   uint32 resp_ret;

   if (EYEQMESPMGR_BASCSRV_FCT_ID_MAIN_ST == EyeQMespMgr_BascSrvData.ActiveFunction)
   {
      EyeQMespMgr_BascSrvData.LastApplStatus[EYEQMESPMGR_BASCSRV_IDX_MAIN_ST] = Status;
      switch (Status)
      {
         case EYEQAPPL_CB_STS_RX_FAILED:
         case EYEQAPPL_CB_STS_TX_FAILED:
         {
            EyeQMespMgr_BascSrvData.IsLastOk[EYEQMESPMGR_BASCSRV_IDX_MAIN_ST] = FALSE;
            EyeQMespMgr_BascSrvData.Status |= EYEQMESPMGR_BASCSRV_STS_APPL_FAILED;
            if (NULL_PTR != EyeQMespMgr_BascSrvData.CallbackFctPtr[EYEQMESPMGR_BASCSRV_IDX_MAIN_ST])
            {
               EyeQMespMgr_BascSrvData.CallbackFctPtr[EYEQMESPMGR_BASCSRV_IDX_MAIN_ST](EYEQMESPMGR_CB_STS_REQ_FAILED);
            }
            EyeQMespMgr_BascSrvData.ActiveFunction = EYEQMESPMGR_BASCSRV_FCT_ID_NULL;
            EyeQMespMgr_BascSrvData.Requested[EYEQMESPMGR_BASCSRV_IDX_MAIN_ST] = FALSE;
            break;
         }
         case EYEQAPPL_CB_STS_RX_OK:
         {
            resp_ret = EyeQMespMgr_GetRespRet();
            EyeQMespMgr_BascSrvData.LastCmdRetValue[EYEQMESPMGR_BASCSRV_IDX_MAIN_ST] = resp_ret;
            if (EYEQMESPMGR_BASCSRV_RET_OK == resp_ret)
            {
               EyeQMespMgr_BascSrvData.MainSt = EyeQMespMgr_BascSrvRespData[EYEQMESPMGR_BASCSRV_MAIN_ST_OFFSET];
               EyeQMespMgr_BascSrvData.IsLastOk[EYEQMESPMGR_BASCSRV_IDX_MAIN_ST] = TRUE;
               EyeQMespMgr_BascSrvData.IsOkOnce[EYEQMESPMGR_BASCSRV_IDX_MAIN_ST] = TRUE;
               if (NULL_PTR != EyeQMespMgr_BascSrvData.CallbackFctPtr[EYEQMESPMGR_BASCSRV_IDX_MAIN_ST])
               {
                  EyeQMespMgr_BascSrvData.CallbackFctPtr[EYEQMESPMGR_BASCSRV_IDX_MAIN_ST](EYEQMESPMGR_CB_STS_REQ_FINISHED);
               }
            }
            else
            {
               EyeQMespMgr_BascSrvData.IsLastOk[EYEQMESPMGR_BASCSRV_IDX_MAIN_ST] = FALSE;
               EyeQMespMgr_BascSrvData.Status |= EYEQMESPMGR_BASCSRV_STS_RET_ERROR;
               if (NULL_PTR != EyeQMespMgr_BascSrvData.CallbackFctPtr[EYEQMESPMGR_BASCSRV_IDX_MAIN_ST])
               {
                  EyeQMespMgr_BascSrvData.CallbackFctPtr[EYEQMESPMGR_BASCSRV_IDX_MAIN_ST](EYEQMESPMGR_CB_STS_REQ_FAILED);
               }
            }
            EyeQMespMgr_BascSrvData.ActiveFunction = EYEQMESPMGR_BASCSRV_FCT_ID_NULL;
            EyeQMespMgr_BascSrvData.Requested[EYEQMESPMGR_BASCSRV_IDX_MAIN_ST] = FALSE;
            break;
         }
         case EYEQAPPL_CB_STS_TX_OK:
         case EYEQAPPL_CB_STS_RX_NEW_FRAME:
         default:
            break;
      }
   }
   else
   {
      EyeQMespMgr_BascSrvData.Status |= EYEQMESPMGR_BASCSRV_STS_INVALID_RESP;
   }
   EyeQMespMgr_BascSrvData.ProcessStatus = TRUE;
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQMespMgr_CODE) EyeQMespMgr_BascSrvAboutCallback(CONST(EyeQAppl_CallbackStsType, AUTOMATIC)Status)
{
   uint32 resp_ret;
   uint32 string_index;

   if (EYEQMESPMGR_BASCSRV_FCT_ID_ABOUT == EyeQMespMgr_BascSrvData.ActiveFunction)
   {
      EyeQMespMgr_BascSrvData.LastApplStatus[EYEQMESPMGR_BASCSRV_IDX_ABOUT] = Status;
      switch (Status)
      {
         case EYEQAPPL_CB_STS_RX_FAILED:
         case EYEQAPPL_CB_STS_TX_FAILED:
         {
            EyeQMespMgr_BascSrvData.IsLastOk[EYEQMESPMGR_BASCSRV_IDX_ABOUT] = FALSE;
            EyeQMespMgr_BascSrvData.Status |= EYEQMESPMGR_BASCSRV_STS_APPL_FAILED;
            if (NULL_PTR != EyeQMespMgr_BascSrvData.CallbackFctPtr[EYEQMESPMGR_BASCSRV_IDX_ABOUT])
            {
               EyeQMespMgr_BascSrvData.CallbackFctPtr[EYEQMESPMGR_BASCSRV_IDX_ABOUT](EYEQMESPMGR_CB_STS_REQ_FAILED);
            }
            EyeQMespMgr_BascSrvData.ActiveFunction = EYEQMESPMGR_BASCSRV_FCT_ID_NULL;
            EyeQMespMgr_BascSrvData.Requested[EYEQMESPMGR_BASCSRV_IDX_ABOUT] = FALSE;
            break;
         }
         case EYEQAPPL_CB_STS_RX_OK:
         {
            resp_ret = EyeQMespMgr_GetRespRet();
            EyeQMespMgr_BascSrvData.LastCmdRetValue[EYEQMESPMGR_BASCSRV_IDX_ABOUT] = resp_ret;
            if (EYEQMESPMGR_BASCSRV_RET_OK == resp_ret)
            {
               if ((EYEQMESPMGR_BASCSRV_ABOUT_BUFF_SIZE >= (EyeQMespMgr_BascSrvRespLength - EYEQMESPMGR_BASCSRV_ABOUT_OFFSET))
                  && (EYEQMESPMGR_BASCSRV_ABOUT_OFFSET < EyeQMespMgr_BascSrvRespLength))
               {
                  for (string_index = 0u; string_index < (EyeQMespMgr_BascSrvRespLength - EYEQMESPMGR_BASCSRV_ABOUT_OFFSET); string_index++)
                  {
                     EyeQMespMgr_BascSrvData.AboutStr[string_index] = EyeQMespMgr_BascSrvRespData[string_index + EYEQMESPMGR_BASCSRV_ABOUT_OFFSET];
                  }
                  EyeQMespMgr_BascSrvData.AboutStringLength = EyeQMespMgr_BascSrvRespLength - EYEQMESPMGR_BASCSRV_ABOUT_OFFSET;
                  EyeQMespMgr_BascSrvData.IsLastOk[EYEQMESPMGR_BASCSRV_IDX_ABOUT] = TRUE;
                  EyeQMespMgr_BascSrvData.IsOkOnce[EYEQMESPMGR_BASCSRV_IDX_ABOUT] = TRUE;
                  if (NULL_PTR != EyeQMespMgr_BascSrvData.CallbackFctPtr[EYEQMESPMGR_BASCSRV_IDX_ABOUT])
                  {
                     EyeQMespMgr_BascSrvData.CallbackFctPtr[EYEQMESPMGR_BASCSRV_IDX_ABOUT](EYEQMESPMGR_CB_STS_REQ_FINISHED);
                  }
               }
               else
               {
                  EyeQMespMgr_BascSrvData.IsLastOk[EYEQMESPMGR_BASCSRV_IDX_ABOUT] = FALSE;
                  EyeQMespMgr_BascSrvData.Status |= EYEQMESPMGR_BASCSRV_STS_DATA_ERROR;
                  if (NULL_PTR != EyeQMespMgr_BascSrvData.CallbackFctPtr[EYEQMESPMGR_BASCSRV_IDX_ABOUT])
                  {
                     EyeQMespMgr_BascSrvData.CallbackFctPtr[EYEQMESPMGR_BASCSRV_IDX_ABOUT](EYEQMESPMGR_CB_STS_REQ_FAILED);
                  }
               }
            }
            else
            {
               EyeQMespMgr_BascSrvData.IsLastOk[EYEQMESPMGR_BASCSRV_IDX_ABOUT] = FALSE;
               EyeQMespMgr_BascSrvData.Status |= EYEQMESPMGR_BASCSRV_STS_RET_ERROR;
               if (NULL_PTR != EyeQMespMgr_BascSrvData.CallbackFctPtr[EYEQMESPMGR_BASCSRV_IDX_ABOUT])
               {
                  EyeQMespMgr_BascSrvData.CallbackFctPtr[EYEQMESPMGR_BASCSRV_IDX_ABOUT](EYEQMESPMGR_CB_STS_REQ_FAILED);
               }
               
            }
            EyeQMespMgr_BascSrvData.ActiveFunction = EYEQMESPMGR_BASCSRV_FCT_ID_NULL;
            EyeQMespMgr_BascSrvData.Requested[EYEQMESPMGR_BASCSRV_IDX_ABOUT] = FALSE;
            break;
         }
         case EYEQAPPL_CB_STS_TX_OK:
         case EYEQAPPL_CB_STS_RX_NEW_FRAME:
         default:
            break;
      }
   }
   else
   {
      EyeQMespMgr_BascSrvData.Status |= EYEQMESPMGR_BASCSRV_STS_INVALID_RESP;
   }
   EyeQMespMgr_BascSrvData.ProcessStatus = TRUE;
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQMespMgr_CODE) EyeQMespMgr_BascSrvExStCallback(CONST(EyeQAppl_CallbackStsType, AUTOMATIC)Status)
{
   uint32 resp_ret;

   if (EYEQMESPMGR_BASCSRV_FCT_ID_EX_ST == EyeQMespMgr_BascSrvData.ActiveFunction)
   {
      EyeQMespMgr_BascSrvData.LastApplStatus[EYEQMESPMGR_BASCSRV_IDX_EX_ST] = Status;
      switch (Status)
      {
         case EYEQAPPL_CB_STS_RX_FAILED:
         case EYEQAPPL_CB_STS_TX_FAILED:
         {
            EyeQMespMgr_BascSrvData.IsLastOk[EYEQMESPMGR_BASCSRV_IDX_EX_ST] = FALSE;
            EyeQMespMgr_BascSrvData.Status |= EYEQMESPMGR_BASCSRV_STS_APPL_FAILED;
            if (NULL_PTR != EyeQMespMgr_BascSrvData.CallbackFctPtr[EYEQMESPMGR_BASCSRV_IDX_EX_ST])
            {
               EyeQMespMgr_BascSrvData.CallbackFctPtr[EYEQMESPMGR_BASCSRV_IDX_EX_ST](EYEQMESPMGR_CB_STS_REQ_FAILED);
            }
            EyeQMespMgr_BascSrvData.ActiveFunction = EYEQMESPMGR_BASCSRV_FCT_ID_NULL;
            EyeQMespMgr_BascSrvData.Requested[EYEQMESPMGR_BASCSRV_IDX_EX_ST] = FALSE;
            break;
         }
         case EYEQAPPL_CB_STS_RX_OK:
         {
            resp_ret = EyeQMespMgr_GetRespRet();
            EyeQMespMgr_BascSrvData.LastCmdRetValue[EYEQMESPMGR_BASCSRV_IDX_EX_ST] = resp_ret;
            if (EYEQMESPMGR_BASCSRV_RET_OK == resp_ret)
            {
               EyeQMespMgr_BascSrvData.MainSt = EyeQMespMgr_BascSrvRespData[EYEQMESPMGR_BASCSRV_MAIN_ST_OFFSET];
               EyeQMespMgr_BascSrvData.SubSt = EyeQMespMgr_BascSrvRespData[EYEQMESPMGR_BASCSRV_SUB_ST_OFFSET];
               EyeQMespMgr_BascSrvData.IsLastOk[EYEQMESPMGR_BASCSRV_IDX_EX_ST] = TRUE;
               EyeQMespMgr_BascSrvData.IsOkOnce[EYEQMESPMGR_BASCSRV_IDX_EX_ST] = TRUE;
               if (NULL_PTR != EyeQMespMgr_BascSrvData.CallbackFctPtr[EYEQMESPMGR_BASCSRV_IDX_EX_ST])
               {
                  EyeQMespMgr_BascSrvData.CallbackFctPtr[EYEQMESPMGR_BASCSRV_IDX_EX_ST](EYEQMESPMGR_CB_STS_REQ_FINISHED);
               }
            }
            else
            {
               EyeQMespMgr_BascSrvData.IsLastOk[EYEQMESPMGR_BASCSRV_IDX_EX_ST] = FALSE;
               EyeQMespMgr_BascSrvData.Status |= EYEQMESPMGR_BASCSRV_STS_RET_ERROR;
               if (NULL_PTR != EyeQMespMgr_BascSrvData.CallbackFctPtr[EYEQMESPMGR_BASCSRV_IDX_EX_ST])
               {
                  EyeQMespMgr_BascSrvData.CallbackFctPtr[EYEQMESPMGR_BASCSRV_IDX_EX_ST](EYEQMESPMGR_CB_STS_REQ_FAILED);
               }
            }
            EyeQMespMgr_BascSrvData.ActiveFunction = EYEQMESPMGR_BASCSRV_FCT_ID_NULL;
            EyeQMespMgr_BascSrvData.Requested[EYEQMESPMGR_BASCSRV_IDX_EX_ST] = FALSE;
            break;
         }
         case EYEQAPPL_CB_STS_TX_OK:
         case EYEQAPPL_CB_STS_RX_NEW_FRAME:
         default:
            break;
      }
   }
   else
   {
      EyeQMespMgr_BascSrvData.Status |= EYEQMESPMGR_BASCSRV_STS_INVALID_RESP;
   }
   EyeQMespMgr_BascSrvData.ProcessStatus = TRUE;
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQMespMgr_CODE) EyeQMespMgr_BascSrvVersCallback(CONST(EyeQAppl_CallbackStsType, AUTOMATIC) Status)
{
   uint32 resp_ret;
   uint32 string_index;
   uint8* des_data_ptr;
   uint8* src_data_ptr;

   if (EYEQMESPMGR_BASCSRV_FCT_ID_VERS == EyeQMespMgr_BascSrvData.ActiveFunction)
   {
      EyeQMespMgr_BascSrvData.LastApplStatus[EYEQMESPMGR_BASCSRV_IDX_VERS] = Status;
      switch (Status)
      {
         case EYEQAPPL_CB_STS_RX_FAILED:
         case EYEQAPPL_CB_STS_TX_FAILED:
         {
            EyeQMespMgr_BascSrvData.IsLastOk[EYEQMESPMGR_BASCSRV_IDX_VERS] = FALSE;
            EyeQMespMgr_BascSrvData.Status |= EYEQMESPMGR_BASCSRV_STS_APPL_FAILED;
            if (NULL_PTR != EyeQMespMgr_BascSrvData.CallbackFctPtr[EYEQMESPMGR_BASCSRV_IDX_VERS])
            {
               EyeQMespMgr_BascSrvData.CallbackFctPtr[EYEQMESPMGR_BASCSRV_IDX_VERS](EYEQMESPMGR_CB_STS_REQ_FAILED);
            }
            EyeQMespMgr_BascSrvData.ActiveFunction = EYEQMESPMGR_BASCSRV_FCT_ID_NULL;
            EyeQMespMgr_BascSrvData.Requested[EYEQMESPMGR_BASCSRV_IDX_VERS] = FALSE;
            break;
         }
         case EYEQAPPL_CB_STS_RX_OK:
         {
            resp_ret = EyeQMespMgr_GetRespRet();
            EyeQMespMgr_BascSrvData.LastCmdRetValue[EYEQMESPMGR_BASCSRV_IDX_VERS] = resp_ret;
            if (EYEQMESPMGR_BASCSRV_RET_OK == resp_ret)
            {
               if ((sizeof(EyeQMespMgr_BascSrvData.Versions) == (EyeQMespMgr_BascSrvRespLength - EYEQMESPMGR_BASCSRV_VERS_OFFSET))
                  && (EYEQMESPMGR_BASCSRV_VERS_OFFSET < EyeQMespMgr_BascSrvRespLength))
               {
                  des_data_ptr = (uint8*)(&EyeQMespMgr_BascSrvData.Versions[0]);
                  src_data_ptr = &EyeQMespMgr_BascSrvRespData[EYEQMESPMGR_BASCSRV_VERS_OFFSET];
                  for (string_index = 0u; string_index <= (EyeQMespMgr_BascSrvRespLength - EYEQMESPMGR_BASCSRV_VERS_OFFSET); string_index++)
                  {
                     *des_data_ptr = *src_data_ptr;
                     des_data_ptr++;
                     src_data_ptr++;
                  }
                  EyeQMespMgr_BascSrvData.IsLastOk[EYEQMESPMGR_BASCSRV_IDX_ABOUT] = TRUE;
                  EyeQMespMgr_BascSrvData.IsOkOnce[EYEQMESPMGR_BASCSRV_IDX_ABOUT] = TRUE;
                  if (NULL_PTR != EyeQMespMgr_BascSrvData.CallbackFctPtr[EYEQMESPMGR_BASCSRV_IDX_VERS])
                  {
                     EyeQMespMgr_BascSrvData.CallbackFctPtr[EYEQMESPMGR_BASCSRV_IDX_VERS](EYEQMESPMGR_CB_STS_REQ_FINISHED);
                  }
               }
               else
               {
                  EyeQMespMgr_BascSrvData.IsLastOk[EYEQMESPMGR_BASCSRV_IDX_ABOUT] = FALSE;
                  EyeQMespMgr_BascSrvData.Status |= EYEQMESPMGR_BASCSRV_STS_DATA_ERROR;
                  if (NULL_PTR != EyeQMespMgr_BascSrvData.CallbackFctPtr[EYEQMESPMGR_BASCSRV_IDX_VERS])
                  {
                     EyeQMespMgr_BascSrvData.CallbackFctPtr[EYEQMESPMGR_BASCSRV_IDX_VERS](EYEQMESPMGR_CB_STS_REQ_FAILED);
                  }
               }
            }
            else
            {
               EyeQMespMgr_BascSrvData.IsLastOk[EYEQMESPMGR_BASCSRV_IDX_VERS] = FALSE;
               EyeQMespMgr_BascSrvData.Status |= EYEQMESPMGR_BASCSRV_STS_RET_ERROR;
               if (NULL_PTR != EyeQMespMgr_BascSrvData.CallbackFctPtr[EYEQMESPMGR_BASCSRV_IDX_VERS])
               {
                  EyeQMespMgr_BascSrvData.CallbackFctPtr[EYEQMESPMGR_BASCSRV_IDX_VERS](EYEQMESPMGR_CB_STS_REQ_FAILED);
               }
            }
            EyeQMespMgr_BascSrvData.ActiveFunction = EYEQMESPMGR_BASCSRV_FCT_ID_NULL;
            EyeQMespMgr_BascSrvData.Requested[EYEQMESPMGR_BASCSRV_IDX_VERS] = FALSE;
            break;
         }
         case EYEQAPPL_CB_STS_TX_OK:
         case EYEQAPPL_CB_STS_RX_NEW_FRAME:
         default:
            break;
      }
   }
   else
   {
      EyeQMespMgr_BascSrvData.Status |= EYEQMESPMGR_BASCSRV_STS_INVALID_RESP;
   }
   EyeQMespMgr_BascSrvData.ProcessStatus = TRUE;
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQMespMgr_CODE) EyeQMespMgr_BascSrvSwtAppCallback(CONST(EyeQAppl_CallbackStsType, AUTOMATIC) Status)
{
   uint32 resp_ret;

   if (EYEQMESPMGR_BASCSRV_FCT_ID_SWT_APP == EyeQMespMgr_BascSrvData.ActiveFunction)
   {
      EyeQMespMgr_BascSrvData.LastApplStatus[EYEQMESPMGR_BASCSRV_IDX_SWT_APP] = Status;
      switch (Status)
      {
         case EYEQAPPL_CB_STS_RX_FAILED:
         case EYEQAPPL_CB_STS_TX_FAILED:
         {
            EyeQMespMgr_BascSrvData.IsLastOk[EYEQMESPMGR_BASCSRV_IDX_SWT_APP] = FALSE;
            EyeQMespMgr_BascSrvData.Status |= EYEQMESPMGR_BASCSRV_STS_APPL_FAILED;
            if (NULL_PTR != EyeQMespMgr_BascSrvData.CallbackFctPtr[EYEQMESPMGR_BASCSRV_IDX_SWT_APP])
            {
               EyeQMespMgr_BascSrvData.CallbackFctPtr[EYEQMESPMGR_BASCSRV_IDX_SWT_APP](EYEQMESPMGR_CB_STS_REQ_FAILED);
            }
            EyeQMespMgr_BascSrvData.ActiveFunction = EYEQMESPMGR_BASCSRV_FCT_ID_NULL;
            EyeQMespMgr_BascSrvData.Requested[EYEQMESPMGR_BASCSRV_IDX_SWT_APP] = FALSE;
            break;
         }
         case EYEQAPPL_CB_STS_RX_OK:
         {
            resp_ret = EyeQMespMgr_GetRespRet();
            EyeQMespMgr_BascSrvData.LastCmdRetValue[EYEQMESPMGR_BASCSRV_IDX_SWT_APP] = resp_ret;
            if (EYEQMESPMGR_BASCSRV_RET_OK == resp_ret)
            {
               EyeQMespMgr_BascSrvData.IsLastOk[EYEQMESPMGR_BASCSRV_IDX_SWT_APP] = TRUE;
               EyeQMespMgr_BascSrvData.IsOkOnce[EYEQMESPMGR_BASCSRV_IDX_SWT_APP] = TRUE;
               if (NULL_PTR != EyeQMespMgr_BascSrvData.CallbackFctPtr[EYEQMESPMGR_BASCSRV_IDX_SWT_APP])
               {
                  EyeQMespMgr_BascSrvData.CallbackFctPtr[EYEQMESPMGR_BASCSRV_IDX_SWT_APP](EYEQMESPMGR_CB_STS_REQ_FINISHED);
               }
            }
            else
            {
               EyeQMespMgr_BascSrvData.IsLastOk[EYEQMESPMGR_BASCSRV_IDX_SWT_APP] = FALSE;
               EyeQMespMgr_BascSrvData.Status |= EYEQMESPMGR_BASCSRV_STS_RET_ERROR;
               if (NULL_PTR != EyeQMespMgr_BascSrvData.CallbackFctPtr[EYEQMESPMGR_BASCSRV_IDX_SWT_APP])
               {
                  EyeQMespMgr_BascSrvData.CallbackFctPtr[EYEQMESPMGR_BASCSRV_IDX_SWT_APP](EYEQMESPMGR_CB_STS_REQ_FAILED);
               }
            }
            EyeQMespMgr_BascSrvData.ActiveFunction = EYEQMESPMGR_BASCSRV_FCT_ID_NULL;
            EyeQMespMgr_BascSrvData.Requested[EYEQMESPMGR_BASCSRV_IDX_SWT_APP] = FALSE;
            break;
         }
         case EYEQAPPL_CB_STS_TX_OK:
         case EYEQAPPL_CB_STS_RX_NEW_FRAME:
         default:
            break;
      }
   }
   else
   {
      EyeQMespMgr_BascSrvData.Status |= EYEQMESPMGR_BASCSRV_STS_INVALID_RESP;
   }
   EyeQMespMgr_BascSrvData.ProcessStatus = TRUE;
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(Std_ReturnType, EyeQMespMgr_CODE) EyeQMespMgr_BascSrvSwitchApp(CONST(EyeQMespMgr_ReqCallbackFct, AUTOMATIC) CallbackFctPtr, 
   CONST(EyeQMespMgr_BascSrvSwtAppIdType, AUTOMATIC) AppId)
{
   Std_ReturnType ret;

   //zke: Todo: add checks for AppId valid range
   if (FALSE == EyeQMespMgr_BascSrvData.Requested[EYEQMESPMGR_BASCSRV_IDX_SWT_APP])
   {
      EyeQMespMgr_SwitchAppData = AppId;
      EyeQMespMgr_BascSrvData.CallbackFctPtr[EYEQMESPMGR_BASCSRV_IDX_SWT_APP] = CallbackFctPtr;
      EyeQMespMgr_BascSrvData.Requested[EYEQMESPMGR_BASCSRV_IDX_SWT_APP] = TRUE;
      ret = E_OK;
   }
   else
   {
      ret = E_NOT_OK;
   }

   return (ret);
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(Std_ReturnType, EyeQMespMgr_CODE) EyeQMespMgr_BascSrvReadMainSt(CONST(EyeQMespMgr_ReqCallbackFct, AUTOMATIC) CallbackFctPtr)
{
   Std_ReturnType ret;

   if (FALSE == EyeQMespMgr_BascSrvData.Requested[EYEQMESPMGR_BASCSRV_IDX_MAIN_ST])
   {
      EyeQMespMgr_BascSrvData.CallbackFctPtr[EYEQMESPMGR_BASCSRV_IDX_MAIN_ST] = CallbackFctPtr;
      EyeQMespMgr_BascSrvData.Requested[EYEQMESPMGR_BASCSRV_IDX_MAIN_ST] = TRUE;
      ret = E_OK;
   }
   else
   {
      ret = E_NOT_OK;
   }

   return (ret);
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(Std_ReturnType, EyeQMespMgr_CODE) EyeQMespMgr_BascSrvReadExSt(CONST(EyeQMespMgr_ReqCallbackFct, AUTOMATIC) CallbackFctPtr)
{
   Std_ReturnType ret;

   if (FALSE == EyeQMespMgr_BascSrvData.Requested[EYEQMESPMGR_BASCSRV_IDX_EX_ST])
   {
      EyeQMespMgr_BascSrvData.CallbackFctPtr[EYEQMESPMGR_BASCSRV_IDX_EX_ST] = CallbackFctPtr;
      EyeQMespMgr_BascSrvData.Requested[EYEQMESPMGR_BASCSRV_IDX_EX_ST] = TRUE;
      ret = E_OK;
   }
   else
   {
      ret = E_NOT_OK;
   }

   return (ret);
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(Std_ReturnType, EyeQMespMgr_CODE) EyeQMespMgr_BascSrvReadAbout(CONST(EyeQMespMgr_ReqCallbackFct, AUTOMATIC) CallbackFctPtr)
{
   Std_ReturnType ret;

   if (FALSE == EyeQMespMgr_BascSrvData.Requested[EYEQMESPMGR_BASCSRV_IDX_ABOUT])
   {
      EyeQMespMgr_BascSrvData.CallbackFctPtr[EYEQMESPMGR_BASCSRV_IDX_ABOUT] = CallbackFctPtr;
      EyeQMespMgr_BascSrvData.Requested[EYEQMESPMGR_BASCSRV_IDX_ABOUT] = TRUE;
      ret = E_OK;
   }
   else
   {
      ret = E_NOT_OK;
   }

   return (ret);
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(Std_ReturnType, EyeQMespMgr_CODE) EyeQMespMgr_BascSrvReadVers(CONST(EyeQMespMgr_ReqCallbackFct, AUTOMATIC) CallbackFctPtr)
{
   Std_ReturnType ret;

   if (FALSE == EyeQMespMgr_BascSrvData.Requested[EYEQMESPMGR_BASCSRV_IDX_VERS])
   {
      EyeQMespMgr_BascSrvData.CallbackFctPtr[EYEQMESPMGR_BASCSRV_IDX_VERS] = CallbackFctPtr;
      EyeQMespMgr_BascSrvData.Requested[EYEQMESPMGR_BASCSRV_IDX_VERS] = TRUE;
      ret = E_OK;
   }
   else
   {
      ret = E_NOT_OK;
   }

   return (ret);
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(Std_ReturnType, EyeQMespMgr_CODE) EyeQMespMgr_BascSrvGetMainSt(
   CONSTP2VAR(EyeQMespMgr_BascSrvMainStType, AUTOMATIC, EyeQMespMgr_APPL_DATA) MainStPtr)
{
   Std_ReturnType ret = E_NOT_OK;

   if ((NULL_PTR != MainStPtr) && (FALSE != EyeQMespMgr_BascSrvData.IsOkOnce[EYEQMESPMGR_BASCSRV_IDX_MAIN_ST]))
   {
      *MainStPtr = EyeQMespMgr_BascSrvData.MainSt;
      ret = E_OK;
   }

   return (ret);
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(Std_ReturnType, EyeQMespMgr_CODE) EyeQMespMgr_BascSrvGetExSt(
   CONSTP2VAR(EyeQMespMgr_BascSrvMainStType, AUTOMATIC, EyeQMespMgr_APPL_DATA) MainStPtr,
   CONSTP2VAR(EyeQMespMgr_BascSrvSubStType, AUTOMATIC, EyeQMespMgr_APPL_DATA) SubStPtr)
{
   Std_ReturnType ret = E_NOT_OK;

   if ((NULL_PTR != MainStPtr) 
      && (NULL_PTR != SubStPtr) 
      && (FALSE != EyeQMespMgr_BascSrvData.IsOkOnce[EYEQMESPMGR_BASCSRV_IDX_EX_ST]))
   {
      *MainStPtr = EyeQMespMgr_BascSrvData.MainSt;
      *SubStPtr = EyeQMespMgr_BascSrvData.SubSt;
      ret = E_OK;
   }

   return (ret);
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(Std_ReturnType, EyeQMespMgr_CODE) EyeQMespMgr_BascSrvGetAbout(CONSTP2VAR(uint8, AUTOMATIC, EyeQMespMgr_APPL_DATA) AboutStringPtr)
{
   Std_ReturnType ret = E_NOT_OK;
   uint8_least data_index;

   if ((NULL_PTR != AboutStringPtr)
      && (FALSE != EyeQMespMgr_BascSrvData.IsOkOnce[EYEQMESPMGR_BASCSRV_IDX_ABOUT]))
   {
      for (data_index = 0u; data_index < EyeQMespMgr_BascSrvData.AboutStringLength; data_index++)
      {
         AboutStringPtr[data_index] = EyeQMespMgr_BascSrvData.AboutStr[data_index];
      }
      ret = E_OK;
   }

   return (ret);
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(Std_ReturnType, EyeQMespMgr_CODE) EyeQMespMgr_BascSrvGetVers(CONSTP2VAR(uint32, AUTOMATIC, EyeQMespMgr_APPL_DATA) VerArrayPtr)
{
   Std_ReturnType ret = E_NOT_OK;
   uint8_least data_index;

   if ((NULL_PTR != VerArrayPtr)
      && (FALSE != EyeQMespMgr_BascSrvData.IsOkOnce[EYEQMESPMGR_BASCSRV_IDX_VERS]))
   {
      for (data_index = 0u; data_index < EYEQMESPMGR_BASCSRV_VERSION_BUFF_SIZE; data_index++)
      {
         VerArrayPtr[data_index] = EyeQMespMgr_BascSrvData.Versions[data_index];
      }
      ret = E_OK;
   }

   return (ret);
}


#define EyeQMespMgr_STOP_SEC_CODE
#include "EyeQMespMgr_MemMap.h"
/******************************************************************************
End Of File
******************************************************************************/
