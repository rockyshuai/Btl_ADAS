
#ifndef EYEQMESPMGR_TYPES_H_
#define EYEQMESPMGR_TYPES_H_ 1

/******************************************************************************

WBTL ELECTRONIC document

Copyright WBTL All rights reserved.

*******************************************************************************

@details
   <Describes details of this header file>

******************************************************************************/
/******************************************************************************
External Dependencies
******************************************************************************/

/******************************************************************************
Definition Of Constants
******************************************************************************/
#define EYEQMESPMGR_HEADER_SIZE               (4u)
/* Todo: zke: TBD size to be used base on ME requirements, for now, CamInit takes 296bytes which is the longest message */
#define EYEQMESPMGR_PARAMS_BYTE_MAX_SIZE      (296u)
/* Todo: zke: TBD size to be used base on ME requirements */
#define EYEQMESPMGR_FRAME_DATA_BYTE_MAX_SIZE  (64u)
/******************************************************************************
Declaration Of Types
******************************************************************************/
/*!
 * @brief MESP manager callback status, used to return status of MESP service request status update
 * @param enum
 * @{
 */
#define EYEQMESPMGR_CB_STS_REQ_FINISHED      (0u)
#define EYEQMESPMGR_CB_STS_REQ_FAILED        (1u)
typedef VAR(uint8, TYPEDEF) EyeQMespMgr_CallbackStsType;
/*! @} */

typedef void (*EyeQMespMgr_ReqCallbackFct)(EyeQMespMgr_CallbackStsType Status);

/* EyeQMespMgr_BascSrv data types */
/*!
 * @brief Ret value
 * @param enum
 * @{
 */
#define EYEQMESPMGR_BASCSRV_RET_OK                     (0u)
#define EYEQMESPMGR_BASCSRV_RET_ERROR                  (1u)
#define EYEQMESPMGR_BASCSRV_RET_ERR_PROCESS_OTHER_TASK (2u)
#define EYEQMESPMGR_BASCSRV_RET_ERR_PARAMS_VALIDATION  (3u)
typedef VAR(uint32, TYPEDEF) EyeQMespMgr_BascSrvRetType;
/*! @} */

/* EyeQMespMgr_EyeSphere data types */
/*!
 * @brief Ret value
 * @param enum
 * @{
 */
#define EYEQMESPMGR_EYESPHERE_RET_OK                     (0u)
#define EYEQMESPMGR_EYESPHERE_RET_ERROR                  (1u)
#define EYEQMESPMGR_EYESPHERE_RET_ERR_PROCESS_OTHER_TASK (2u)
typedef VAR(uint32, TYPEDEF) EyeQMespMgr_EyeSphereRetType;
/*! @} */

/* EyeQMespMgr_CalToolSrv data types */
/*!
 * @brief Ret value
 * @param enum
 * @{
 */
#define EYEQMESPMGR_CALTOOLSRV_RET_OK                               (0x0u)
#define EYEQMESPMGR_CALTOOLSRV_RET_ERROR                            (0x1u)
#define EYEQMESPMGR_CALTOOLSRV_RET_E_WRONG_STATE                    (0x2u)
#define EYEQMESPMGR_CALTOOLSRV_RET_E_PROCESS_OTHER_TASK             (0x3u)
#define EYEQMESPMGR_CALTOOLSRV_RET_E_PARAMS_VALIDATION              (0x4u)
#define EYEQMESPMGR_CALTOOLSRV_RET_E_WRONG_PARAMS_NUM               (0x5u)
#define EYEQMESPMGR_CALTOOLSRV_RET_E_DATA_UNAVAILABLE               (0x6u)
#define EYEQMESPMGR_CALTOOLSRV_RET_E_FUNC_FAILED                    (0x7u)
#define EYEQMESPMGR_CALTOOLSRV_RET_E_TYPE_UNAVAILABLE               (0x8u)
#define EYEQMESPMGR_CALTOOLSRV_RET_E_WRONG_VERSION                  (0x9u)
#define EYEQMESPMGR_CALTOOLSRV_RET_E_CT_NOT_EXIST_OR_NOT_REGISTERED (0xAu)
#define EYEQMESPMGR_CALTOOLSRV_RET_E_CT_PROCESS_TASK_BUSY           (0xBu)
#define EYEQMESPMGR_CALTOOLSRV_RET_E_WRONG_PARAMS_DATA_SIZE         (0xCu)
#define EYEQMESPMGR_CALTOOLSRV_RET_E_FUNC_CANCELED                  (0xDu)
#define EYEQMESPMGR_CALTOOLSRV_RET_E_MISSING_VALIDATION_TOOL        (0xEu)
#define EYEQMESPMGR_CALTOOLSRV_RET_E_VALIDATION_TOOL_FAIL           (0xFu)
typedef VAR(uint32, TYPEDEF) EyeQMespMgr_CalToolSrvRetType;
/*! @} */

typedef struct EyeQMespMgr_ParamsDataTypeTag
{
   uint32 Size;
   uint8 Bytes[EYEQMESPMGR_PARAMS_BYTE_MAX_SIZE];
}EyeQMespMgr_ParamsDataType;

typedef struct EyeQMespMgr_DataFrameTypeTag
{
   uint32 Size;
   uint8 Bytes[EYEQMESPMGR_FRAME_DATA_BYTE_MAX_SIZE];
}EyeQMespMgr_DataFrameType;

typedef struct EyeQMespMgr_CalToolSrvSendParamsTxDataTypeTag
{
   uint8 ct_type;
   uint8 ct_version;
   uint8 ct_stage;
   uint8 ct_params_num;
   EyeQMespMgr_ParamsDataType params;
}EyeQMespMgr_CalToolSrvSendParamsTxDataType;

typedef struct EyeQMespMgr_CalToolSrvSendParamsRxDataTypeTag
{
   EyeQMespMgr_CalToolSrvRetType ret;
   uint8 ct_type;
   uint8 ct_version;
}EyeQMespMgr_CalToolSrvSendParamsRxDataType;

typedef struct EyeQMespMgr_CalToolSrvGetParamsTxDataTypeTag
{
   uint8 ct_type;
   uint8 ct_version;
   uint8 ct_stage;
}EyeQMespMgr_CalToolSrvGetParamsTxDataType;

typedef struct EyeQMespMgr_CalToolSrvGetParamsRxDataTypeTag
{
   EyeQMespMgr_CalToolSrvRetType ret;
   uint8 ct_type;
   uint8 ct_version;
   uint8 ct_stage;
   uint8 ct_params_num;
   EyeQMespMgr_ParamsDataType params;
}EyeQMespMgr_CalToolSrvGetParamsRxDataType;

typedef struct EyeQMespMgr_CalToolSrvEventTxDataTypeTag
{
   uint8 ct_type;
   uint8 ct_version;
   uint8 ct_stage;
   uint8 Reserved6;
   uint16 ct_params_num;
   uint16 Reserved7;
   uint32 ct_crc;
   uint32 Reserved1;
   uint32 Reserved2;
   uint32 Reserved3;
   uint32 Reserved4;
   uint32 Reserved5;
   EyeQMespMgr_ParamsDataType params;
}EyeQMespMgr_CalToolSrvEventTxDataType;

/* Note: please make sure the total struct size is no more than EYEQMESPMGR_CALTOOLSRV_RESP_BUFF_SIZE */
typedef struct EyeQMespMgr_CalToolSrvEventRxDataTypeTag
{
   EyeQMespMgr_CalToolSrvRetType ret;
   uint8 ct_type;
   uint8 ct_version;
   uint8 ct_stage;
   uint8 Reserved6;
   uint16 ct_params_num;
   uint16 Reserved7;
   uint32 ct_crc;
   uint32 Reserved1;
   uint32 Reserved2;
   uint32 Reserved3;
   uint32 Reserved4;
   uint32 Reserved5;
   EyeQMespMgr_ParamsDataType params;
}EyeQMespMgr_CalToolSrvEventRxDataType;


/* EyeQMespMgr_BootSrv data types */
/*!
 * @brief Ret value
 * @param enum
 * @{
 */
#define EYEQMESPMGR_BOOTSRV_RET_OK                                 (0x00u)
#define EYEQMESPMGR_BOOTSRV_RET_GENERAL_FAILURE                    (0x01u)
#define EYEQMESPMGR_BOOTSRV_RET_ERR_FILE_SIZE_TOO_BIG              (0x02u)
#define EYEQMESPMGR_BOOTSRV_RET_ERR_CLEAR_FLASH_LOCK_BIT           (0x03u)
#define EYEQMESPMGR_BOOTSRV_RET_ERR_ERASE_FLASH_SECTOR             (0x04u)
#define EYEQMESPMGR_BOOTSRV_RET_ERR_FAILED_BURN_DATA               (0x05u)
#define EYEQMESPMGR_BOOTSRV_RET_ERR_BURN_DATA_VALIDATION           (0x06u)
#define EYEQMESPMGR_BOOTSRV_RET_WRONG_REQUEST_ARGUMENT             (0x90u)
#define EYEQMESPMGR_BOOTSRV_RET_ERR_REQUEST_ON_WRONG_STATE         (0x91u)
#define EYEQMESPMGR_BOOTSRV_RET_ERR_NON_SEQUENTIAL_FRAME_IDX       (0x92u)
#define EYEQMESPMGR_BOOTSRV_RET_ERR_APP_ID_UNKNOWN                 (0x93u)
#define EYEQMESPMGR_BOOTSRV_RET_ERR_DATA_AMOUNT_MORE_THAN_EXPECTED (0x94u)
typedef VAR(uint32, TYPEDEF) EyeQMespMgr_BootSrvRetType;
/*! @} */

/*!
 * @brief Is burn code flag value
 * @param enum
 * @{
 */
#define EYEQMESPMGR_BOOTSRV_SET_CODE                               (0x00u)
#define EYEQMESPMGR_BOOTSRV_BURN_CODE                              (0x01u)
typedef VAR(uint8, TYPEDEF) EyeQMespMgr_BootSrvIsBurnCodeType;
/*! @} */

/*!
 * @brief Close sub task
 * @param enum
 * @{
 */
#define EYEQMESPMGR_BOOTSRV_ABORT                                 (0x00u)
#define EYEQMESPMGR_BOOTSRV_CONTINUE                              (0x01u)
typedef VAR(uint8, TYPEDEF) EyeQMespMgr_BootSrvCloseType;
/*! @} */

/*!
 * @brief Task indication
 * @param enum
 * @{
 */
#define EYEQMESPMGR_BOOTSRV_TASK_UNKNOWN                          (0x00u)
#define EYEQMESPMGR_BOOTSRV_TASK_ERASE                            (0x01u)
#define EYEQMESPMGR_BOOTSRV_TASK_BURN                             (0x02u)
#define EYEQMESPMGR_BOOTSRV_TASK_DONE                             (0x03u)
typedef VAR(uint8, TYPEDEF) EyeQMespMgr_BootSrvTaskType;
/*! @} */

typedef struct EyeQMespMgr_BootSrvInitTxDataTypeTag
{
   EyeQMespMgr_BootSrvIsBurnCodeType IsBurnCode;
   uint32 CodeFileSize;
   uint8 Reserved[32];
}EyeQMespMgr_BootSrvInitTxDataType;

typedef struct EyeQMespMgr_BootSrvTransferTxDataTypeTag
{
   uint16 PacketNum;
   EyeQMespMgr_DataFrameType DataFrame;
}EyeQMespMgr_BootSrvTransferTxDataType;

typedef struct EyeQMespMgr_BootSrvCloseTxDataTypeTag
{
   EyeQMespMgr_BootSrvCloseType CloseSubTask;
}EyeQMespMgr_BootSrvCloseTxDataType;

typedef struct EyeQMespMgr_BootSrvProgressRxDataTypeTag
{
   EyeQMespMgr_BootSrvRetType Ret;
   EyeQMespMgr_BootSrvTaskType Task;
   uint8 Progress;
}EyeQMespMgr_BootSrvProgressRxDataType;

typedef struct EyeQMespMgr_BootSrvCrcRxDataTypeTag
{
   EyeQMespMgr_BootSrvRetType Ret;
   uint32 ComputedCRC;
}EyeQMespMgr_BootSrvCrcRxDataType;

/******************************************************************************
Declaration Of Variables
******************************************************************************/

/******************************************************************************
Declaration Of Constant Data
******************************************************************************/

/******************************************************************************
Declaration Of Functions
******************************************************************************/

/******************************************************************************
Declaration Of Function-like Macros
******************************************************************************/

/******************************************************************************
End Of File
******************************************************************************/

#endif /* EYEQMESPMGR_TYPES_H_ */
