
#ifndef EYEQMESPMGR_H_
#define EYEQMESPMGR_H_ 1

/******************************************************************************

WBTL ELECTRONIC document

Copyright WBTL All rights reserved.

*******************************************************************************

@details
   <Describes details of this header file>

******************************************************************************/
/******************************************************************************
External Dependencies
******************************************************************************/
#include <Std_Types.h>
#include <EyeQMespMgr_BascSrv.h>
#include <EyeQMespMgr_BootSrv.h>
#include <EyeQMespMgr_CalToolSrv.h>
#include <EyeQMespMgr_CamSrv.h>
#include <EyeQMespMgr_FDSrv.h>
#include <EyeQMespMgr_FFSSrv.h>
#include <EyeQMespMgr_EyeSphere.h>


/******************************************************************************
Definition Of Constants
******************************************************************************/
#define EYEQMESPMGR_SRV_ID_BOOTSRV        (0x01u)
#define EYEQMESPMGR_SRV_ID_EYESPHERE      (0x04u)
#define EYEQMESPMGR_SRV_ID_BASCSRV        (0x05u)
#define EYEQMESPMGR_SRV_ID_CALTOOLSRV     (0x06u)

/* All function Ids from all supported services and functions */
//#define EYEQMESPMGR_FCT_BASCSRV_MAIN_ST   (0x00u)
//#define EYEQMESPMGR_FCT_BASCSRV_ABOUT     (0x01u)
//#define EYEQMESPMGR_FCT_BASCSRV_EX_ST     (0x02u)
//#define EYEQMESPMGR_FCT_BASCSRV_VERSION   (0x03u)
//#define EYEQMESPMGR_FCT_BASCSRV_SWT_APP   (0x04u)
//#define EYEQMESPMGR_FCT_TOTAL_NUM         (0x05u)
//
//#define EYEQMESPMGR_STS_NUM_PER_ELEMENT   (32u)
//#define EYEQMESPMGR_STS_ARRAY_SIZE        (EYEQMESPMGR_FCT_TOTAL_NUM / EYEQMESPMGR_STS_NUM_PER_ELEMENT)

/******************************************************************************
Declaration Of Types
******************************************************************************/

/******************************************************************************
Declaration Of Variables
******************************************************************************/

/******************************************************************************
Declaration Of Constant Data
******************************************************************************/

/******************************************************************************
Declaration Of Functions
******************************************************************************/
extern FUNC(void, EyeQMespMgr_CODE) EyeQMespMgr_Init(void);
extern FUNC(void, EyeQMespMgr_CODE) EyeQMespMgr_MainFunction(void);


/******************************************************************************
Declaration Of Function-like Macros
******************************************************************************/

/******************************************************************************
End Of File
******************************************************************************/

#endif /* EYEQMESPMGR_H_ */
