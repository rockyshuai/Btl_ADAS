
#ifndef EYEQMESPMGR_BOOTSRV_H_
#define EYEQMESPMGR_BOOTSRV_H_ 1

/******************************************************************************

WBTL ELECTRONIC document

Copyright WBTL All rights reserved.

*******************************************************************************

@details
   <Describes details of this header file>

******************************************************************************/
/******************************************************************************
External Dependencies
******************************************************************************/
#include <Std_Types.h>
#include "EyeQMespMgr_Types.h"
#include <EyeQMespMgr_Cfg.h>
#include <EyeQAppl.h>

/******************************************************************************
Definition Of Constants
******************************************************************************/
#define EYEQMESPMGR_BOOTSRV_REGULAR_RESP_LEN   (4u)
#define EYEQMESPMGR_BOOTSRV_PROGRESS_RESP_LEN  (sizeof(EyeQMespMgr_BootSrvProgressRxDataType))
#define EYEQMESPMGR_BOOTSRV_CRC_RESP_LEN       (sizeof(EyeQMespMgr_BootSrvCrcRxDataType))

#define EYEQMESPMGR_BOOTSRV_INIT_REQ_LEN       (37u)
#define EYEQMESPMGR_BOOTSRV_CLOSE_REQ_LEN      (1u)
#define EYEQMESPMGR_BOOTSRV_PROGRESS_REQ_LEN   (0u)
#define EYEQMESPMGR_BOOTSRV_CRC_REQ_LEN        (0u)

/******************************************************************************
Declaration Of Types
******************************************************************************/
/*!
 * @brief Function ID
 * @param enum
 * @{
 */
#define EYEQMESPMGR_BOOTSRV_FCT_ID_NULL        (0u)
#define EYEQMESPMGR_BOOTSRV_FCT_ID_INIT        (1u)
#define EYEQMESPMGR_BOOTSRV_FCT_ID_TRANSFER    (2u)
#define EYEQMESPMGR_BOOTSRV_FCT_ID_CLOSE       (3u)
#define EYEQMESPMGR_BOOTSRV_FCT_ID_PROGRESS    (4u)
#define EYEQMESPMGR_BOOTSRV_FCT_ID_GET_CRC     (5u)
#define EYEQMESPMGR_BOOTSRV_FCT_ID_NUM         (5u)
typedef VAR(uint8, TYPEDEF) EyeQMespMgr_BootSrvFctIdType;
/*! @} */

/*!
 * @brief Function Index
 * @param enum
 * @{
 */
#define EYEQMESPMGR_BOOTSRV_IDX_INIT           (0u)
#define EYEQMESPMGR_BOOTSRV_IDX_TRANSFER       (1u)
#define EYEQMESPMGR_BOOTSRV_IDX_CLOSE          (2u)
#define EYEQMESPMGR_BOOTSRV_IDX_PROGRESS       (3u)
#define EYEQMESPMGR_BOOTSRV_IDX_GET_CRC        (4u)
#define EYEQMESPMGR_BOOTSRV_IDX_NUM            (5u)
typedef VAR(uint8, TYPEDEF) EyeQMespMgr_BootSrvIdxType;
/*! @} */

/*!
 * @brief Status flags
 * @param enum
 * @{
 */
#define EYEQMESPMGR_BOOTSRV_STS_INVALID_RESP   (1u << 0u)
#define EYEQMESPMGR_BOOTSRV_STS_APPL_FAILED    (1u << 1u)
#define EYEQMESPMGR_BOOTSRV_STS_RET_ERROR      (1u << 2u)
#define EYEQMESPMGR_BOOTSRV_STS_DATA_ERROR     (1u << 3u)
#define EYEQMESPMGR_BOOTSRV_STS_REQ_TIMEOUT    (1u << 4u)
typedef VAR(uint32, TYPEDEF) EyeQMespMgr_BootSrvStsType;
/*! @} */

/******************************************************************************
Declaration Of Variables
******************************************************************************/
extern VAR(uint32, EyeQMespMgr_VAR) EyeQMespMgr_BootSrvRespLength;
extern VAR(uint8, EyeQMespMgr_VAR) EyeQMespMgr_BootSrvRespData[EYEQMESPMGR_BOOTSRV_RESP_BUFF_SIZE];
extern VAR(EyeQMespMgr_BootSrvInitTxDataType, EyeQMespMgr_VAR) EyeQMespMgr_BootSrvInitTxData;
extern VAR(EyeQMespMgr_BootSrvTransferTxDataType, EyeQMespMgr_VAR) EyeQMespMgr_BootSrvTransferTxData;
extern VAR(EyeQMespMgr_BootSrvCloseTxDataType, EyeQMespMgr_VAR) EyeQMespMgr_BootSrvCloseTxData;

/******************************************************************************
Declaration Of Constant Data
******************************************************************************/

/******************************************************************************
Declaration Of Functions
******************************************************************************/
extern FUNC(void, EyeQMespMgr_CODE) EyeQMespMgr_BootSrvInit(void);
extern FUNC(void, EyeQMespMgr_CODE) EyeQMespMgr_BootSrvMainFunction(void);

/* Callback functions for application layer */
extern FUNC(void, EyeQMespMgr_CODE) EyeQMespMgr_BootSrvInitCallback(CONST(EyeQAppl_CallbackStsType, AUTOMATIC) Status);
extern FUNC(void, EyeQMespMgr_CODE) EyeQMespMgr_BootSrvTransferCallback(CONST(EyeQAppl_CallbackStsType, AUTOMATIC) Status);
extern FUNC(void, EyeQMespMgr_CODE) EyeQMespMgr_BootSrvCloseCallback(CONST(EyeQAppl_CallbackStsType, AUTOMATIC) Status);
extern FUNC(void, EyeQMespMgr_CODE) EyeQMespMgr_BootSrvProgressCallback(CONST(EyeQAppl_CallbackStsType, AUTOMATIC) Status);
extern FUNC(void, EyeQMespMgr_CODE) EyeQMespMgr_BootSrvGetCrcCallback(CONST(EyeQAppl_CallbackStsType, AUTOMATIC) Status);

/* Trigger functions for basic services */
extern FUNC(Std_ReturnType, EyeQMespMgr_CODE) EyeQMespMgr_BootSrvInitProcess(CONST(EyeQMespMgr_ReqCallbackFct, AUTOMATIC) CallbackFctPtr, 
   CONSTP2CONST(EyeQMespMgr_BootSrvInitTxDataType, AUTOMATIC, EyeQMespMgr_APPL_CONST) TxDataPtr);
extern FUNC(Std_ReturnType, EyeQMespMgr_CODE) EyeQMespMgr_BootSrvTransfer(CONST(EyeQMespMgr_ReqCallbackFct, AUTOMATIC) CallbackFctPtr, 
   CONSTP2CONST(EyeQMespMgr_BootSrvTransferTxDataType, AUTOMATIC, EyeQMespMgr_APPL_CONST) TxDataPtr, CONST(uint16, AUTOMATIC) TxDataLength);
extern FUNC(Std_ReturnType, EyeQMespMgr_CODE) EyeQMespMgr_BootSrvClose(CONST(EyeQMespMgr_ReqCallbackFct, AUTOMATIC) CallbackFctPtr, 
   CONSTP2CONST(EyeQMespMgr_BootSrvCloseTxDataType, AUTOMATIC, EyeQMespMgr_APPL_CONST) TxDataPtr);
extern FUNC(Std_ReturnType, EyeQMespMgr_CODE) EyeQMespMgr_BootSrvProgress(CONST(EyeQMespMgr_ReqCallbackFct, AUTOMATIC) CallbackFctPtr);
extern FUNC(Std_ReturnType, EyeQMespMgr_CODE) EyeQMespMgr_BootSrvCrc(CONST(EyeQMespMgr_ReqCallbackFct, AUTOMATIC) CallbackFctPtr);

/* Get Tx data length functions */
extern FUNC(uint32, EyeQMespMgr_CODE) EyeQMespMgr_BootSrvGetTransferTxLength(void);

/* Get Response data functions */
extern FUNC(Std_ReturnType, EyeQMespMgr_CODE) EyeQMespMgr_BootSrvGetRxProgressData(CONSTP2VAR(EyeQMespMgr_BootSrvProgressRxDataType, AUTOMATIC, EyeQMespMgr_APPL_CONST) RetDataPtr);
extern FUNC(Std_ReturnType, EyeQMespMgr_CODE) EyeQMespMgr_BootSrvGetRxCrcData(CONSTP2VAR(EyeQMespMgr_BootSrvCrcRxDataType, AUTOMATIC, EyeQMespMgr_APPL_CONST) RetDataPtr);

/******************************************************************************
Declaration Of Function-like Macros
******************************************************************************/
#define EyeQMespMgr_BootSrvConvertFctIdToIdx(FctId)        (FctId - 1u)
#define EyeQMespMgr_BootSrvConvertFctIdxToId(FctIdx)       (FctIdx + 1u)
/******************************************************************************
End Of File
******************************************************************************/

#endif /* EYEQMESPMGR_BOOTSRV_H_ */
