
#ifndef EYEQMESPMGR_EYESPHERE_H_
#define EYEQMESPMGR_EYESPHERE_H_ 1

/******************************************************************************

WBTL ELECTRONIC document

Copyright WBTL All rights reserved.

*******************************************************************************

@details
   <Describes details of this header file>

******************************************************************************/
/******************************************************************************
External Dependencies
******************************************************************************/
#include <Std_Types.h>
#include "EyeQMespMgr_Types.h"
#include <EyeQMespMgr_Cfg.h>
#include <EyeQAppl.h>

/******************************************************************************
Definition Of Constants
******************************************************************************/
#define EYEQMESPMGR_EYESPHERE_RESET_RESP_LEN     (8u)
#define EYEQMESPMGR_EYESPHERE_HALT_RESP_LEN      (4u)

#define EYEQMESPMGR_EYESPHERE_RESET_REQ_LEN      (0u)
#define EYEQMESPMGR_EYESPHERE_HALT_REQ_LEN       (0u)
/******************************************************************************
Declaration Of Types
******************************************************************************/
/*!
 * @brief Function ID
 * @param enum
 * @{
 */
#define EYEQMESPMGR_EYESPHERE_FCT_ID_NULL        (0u)
#define EYEQMESPMGR_EYESPHERE_FCT_ID_CMD         (1u)
#define EYEQMESPMGR_EYESPHERE_FCT_ID_RESET       (2u)
#define EYEQMESPMGR_EYESPHERE_FCT_ID_HALT        (3u)
#define EYEQMESPMGR_EYESPHERE_FCT_ID_NUM         (3u)
typedef VAR(uint8, TYPEDEF) EyeQMespMgr_EyeSphereFctIdType;
/*! @} */

/*!
 * @brief Function Index
 * @param enum
 * @{
 */
#define EYEQMESPMGR_EYESPHERE_IDX_CMD            (0u)
#define EYEQMESPMGR_EYESPHERE_IDX_RESET          (1u)
#define EYEQMESPMGR_EYESPHERE_IDX_HALT           (2u)
#define EYEQMESPMGR_EYESPHERE_IDX_NUM            (3u)
typedef VAR(uint8, TYPEDEF) EyeQMespMgr_EyeSphereIdxType;
/*! @} */

/*!
 * @brief Status flags
 * @param enum
 * @{
 */
#define EYEQMESPMGR_EYESPHERE_STS_INVALID_RESP   (1u << 0u)
#define EYEQMESPMGR_EYESPHERE_STS_APPL_FAILED    (1u << 1u)
#define EYEQMESPMGR_EYESPHERE_STS_RET_ERROR      (1u << 2u)
#define EYEQMESPMGR_EYESPHERE_STS_DATA_ERROR     (1u << 3u)
#define EYEQMESPMGR_EYESPHERE_STS_REQ_TIMEOUT    (1u << 4u)
typedef VAR(uint32, TYPEDEF) EyeQMespMgr_EyeSphereStsType;
/*! @} */

/******************************************************************************
Declaration Of Variables
******************************************************************************/
extern VAR(uint32, EyeQMespMgr_VAR) EyeQMespMgr_EyeSphereRespLength;
extern VAR(uint8, EyeQMespMgr_VAR) EyeQMespMgr_EyeSphereRespData[EYEQMESPMGR_EYESPHERE_RESP_BUFF_SIZE];
extern VAR(uint8, EyeQMespMgr_VAR) EyeQMespMgr_EyeSphereCmdTxData[EYEQMESPMGR_EYESPHERE_CMD_BUFF_SIZE];

/******************************************************************************
Declaration Of Constant Data
******************************************************************************/

/******************************************************************************
Declaration Of Functions
******************************************************************************/
extern FUNC(void, EyeQMespMgr_CODE) EyeQMespMgr_EyeSphereInit(void);
extern FUNC(void, EyeQMespMgr_CODE) EyeQMespMgr_EyeSphereMainFunction(void);

/* Callback functions for application layer */
extern FUNC(void, EyeQMespMgr_CODE) EyeQMespMgr_EyeSphereCmdCallback(CONST(EyeQAppl_CallbackStsType, AUTOMATIC) Status);
extern FUNC(void, EyeQMespMgr_CODE) EyeQMespMgr_EyeSphereResetCallback(CONST(EyeQAppl_CallbackStsType, AUTOMATIC) Status);
extern FUNC(void, EyeQMespMgr_CODE) EyeQMespMgr_EyeSphereHaltCallback(CONST(EyeQAppl_CallbackStsType, AUTOMATIC) Status);

/* Trigger functions for basic services */
extern FUNC(Std_ReturnType, EyeQMespMgr_CODE) EyeQMespMgr_EyeSphereCmd(CONST(EyeQMespMgr_ReqCallbackFct, AUTOMATIC) CallbackFctPtr, 
   CONSTP2CONST(uint8, AUTOMATIC, EyeQMespMgr_APPL_CONST) CmdPtr, CONST(uint16, AUTOMATIC) CmdLength);
extern FUNC(Std_ReturnType, EyeQMespMgr_CODE) EyeQMespMgr_EyeSphereReset(CONST(EyeQMespMgr_ReqCallbackFct, AUTOMATIC) CallbackFctPtr);
extern FUNC(Std_ReturnType, EyeQMespMgr_CODE) EyeQMespMgr_EyeSphereHalt(CONST(EyeQMespMgr_ReqCallbackFct, AUTOMATIC) CallbackFctPtr);

/* Get functions */
extern FUNC(uint16, EyeQMespMgr_CODE) EyeQMespMgr_EyeSphereGetCmdTxLength(void);

/******************************************************************************
Declaration Of Function-like Macros
******************************************************************************/
#define EyeQMespMgr_EyeSphereConvertFctIdToIdx(FctId)        (FctId - 1u)
#define EyeQMespMgr_EyeSphereConvertFctIdxToId(FctIdx)       (FctIdx + 1u)
/******************************************************************************
End Of File
******************************************************************************/

#endif /* EYEQMESPMGR_EYESPHERE_H_ */
