
#ifndef EYEQMESPMGR_BASCSRV_H_
#define EYEQMESPMGR_BASCSRV_H_ 1

/******************************************************************************

WBTL ELECTRONIC document

Copyright WBTL All rights reserved.

*******************************************************************************

@details
   <Describes details of this header file>

******************************************************************************/
/******************************************************************************
External Dependencies
******************************************************************************/
#include <Std_Types.h>
#include "EyeQMespMgr_Types.h"
#include <EyeQMespMgr_Cfg.h>
#include <EyeQAppl.h>

/******************************************************************************
Definition Of Constants
******************************************************************************/
#define EYEQMESPMGR_BASCSRV_MAIN_ST_RESP_LEN   (5u + EYEQMESPMGR_HEADER_SIZE)
#define EYEQMESPMGR_BASCSRV_EX_ST_RESP_LEN     (8u + EYEQMESPMGR_HEADER_SIZE)
#define EYEQMESPMGR_BASCSRV_SWT_APP_RESP_LEN   (4u + EYEQMESPMGR_HEADER_SIZE)

#define EYEQMESPMGR_BASCSRV_MAIN_ST_REQ_LEN    (0u)
#define EYEQMESPMGR_BASCSRV_ABOUT_REQ_LEN      (0u)
#define EYEQMESPMGR_BASCSRV_VERS_REQ_LEN       (0u)
#define EYEQMESPMGR_BASCSRV_EX_ST_REQ_LEN      (0u)
#define EYEQMESPMGR_BASCSRV_SWT_APP_REQ_LEN    (1u)



/******************************************************************************
Declaration Of Types
******************************************************************************/
/*!
 * @brief Function ID
 * @param enum
 * @{
 */
#define EYEQMESPMGR_BASCSRV_FCT_ID_NULL        (0u)
#define EYEQMESPMGR_BASCSRV_FCT_ID_MAIN_ST     (1u)
#define EYEQMESPMGR_BASCSRV_FCT_ID_ABOUT       (2u)
#define EYEQMESPMGR_BASCSRV_FCT_ID_EX_ST       (3u)
#define EYEQMESPMGR_BASCSRV_FCT_ID_VERS        (4u)
#define EYEQMESPMGR_BASCSRV_FCT_ID_SWT_APP     (5u)
#define EYEQMESPMGR_BASCSRV_FCT_ID_NUM         (5u)
typedef VAR(uint8, TYPEDEF) EyeQMespMgr_BascSrvFctIdType;
/*! @} */

/*!
 * @brief Function Index
 * @param enum
 * @{
 */
#define EYEQMESPMGR_BASCSRV_IDX_MAIN_ST        (0u)
#define EYEQMESPMGR_BASCSRV_IDX_ABOUT          (1u)
#define EYEQMESPMGR_BASCSRV_IDX_EX_ST          (2u)
#define EYEQMESPMGR_BASCSRV_IDX_VERS           (3u)
#define EYEQMESPMGR_BASCSRV_IDX_SWT_APP        (4u)
#define EYEQMESPMGR_BASCSRV_IDX_NUM            (5u)
typedef VAR(uint8, TYPEDEF) EyeQMespMgr_BascSrvIdxType;
/*! @} */

/*!
 * @brief Status flags
 * @param enum
 * @{
 */
#define EYEQMESPMGR_BASCSRV_STS_INVALID_RESP   (1u << 0u)
#define EYEQMESPMGR_BASCSRV_STS_APPL_FAILED    (1u << 1u)
#define EYEQMESPMGR_BASCSRV_STS_RET_ERROR      (1u << 2u)
#define EYEQMESPMGR_BASCSRV_STS_DATA_ERROR     (1u << 3u)
#define EYEQMESPMGR_BASCSRV_STS_REQ_TIMEOUT    (1u << 4u)
typedef VAR(uint32, TYPEDEF) EyeQMespMgr_BascSrvStsType;
/*! @} */

/*!
 * @brief Main states
 * @param enum
 * @{
 */
#define EYEQMESPMGR_BASCSRV_MAIN_ST_UNKNOWN        (0x00u)
#define EYEQMESPMGR_BASCSRV_MAIN_ST_PENDING        (0x01u)
#define EYEQMESPMGR_BASCSRV_MAIN_ST_RUN_VISION     (0x02u)
#define EYEQMESPMGR_BASCSRV_MAIN_ST_BOOT           (0x03u)
//#define EYEQMESPMGR_BASCSRV_MAIN_ST_RUN_TAC        (0x20u)
#define EYEQMESPMGR_BASCSRV_MAIN_ST_RUN_SPTAC      (0x21u)
#define EYEQMESPMGR_BASCSRV_MAIN_ST_RUN_SPC        (0x22u)
#define EYEQMESPMGR_BASCSRV_MAIN_ST_PENDING_SPTAC  (0x81u)
#define EYEQMESPMGR_BASCSRV_MAIN_ST_PENDING_SPC    (0x82u)
#define EYEQMESPMGR_BASCSRV_MAIN_ST_PENDING_MTF    (0x83u)
#define EYEQMESPMGR_BASCSRV_MAIN_ST_PENDING_TAC2   (0x85u)
#define EYEQMESPMGR_BASCSRV_MAIN_ST_PENDING_DV     (0x86u)  //zke: BPP says 0x86? But WBTL_Core_Export_4.20.5_RC4.xlsx says 0xFF?
#define EYEQMESPMGR_BASCSRV_MAIN_ST_PENDING_VISION (0x92u)
#define EYEQMESPMGR_BASCSRV_MAIN_ST_RUN_DV         (0xAAu)
#define EYEQMESPMGR_BASCSRV_MAIN_ST_RUN_MTF        (0xABu)
#define EYEQMESPMGR_BASCSRV_MAIN_ST_RUN_TAC2       (0xACu)
#define EYEQMESPMGR_BASCSRV_MAIN_ST_NUM            (13u)
typedef VAR(uint8, TYPEDEF) EyeQMespMgr_BascSrvMainStType;
/*! @} */

/*!
 * @brief Sub states: In Vision app and DV App: if EDR exists - EDR internal state (else NONE). In all other apps: 0x0
 * @param enum
 * @{
 */
#define EYEQMESPMGR_BASCSRV_SUB_ST_DEFAULT         (0x00u)
#define EYEQMESPMGR_BASCSRV_SUB_ST_NUM             (1u)
typedef VAR(uint8, TYPEDEF) EyeQMespMgr_BascSrvSubStType;
/*! @} */

/*!
 * @brief Switch Application ID defines
 * @param enum
 * @{
 */
#define EYEQMESPMGR_BASCSRV_SWT_APP_ID_VISION      (0x01u)
#define EYEQMESPMGR_BASCSRV_SWT_APP_ID_TAC2        (0x02u)
#define EYEQMESPMGR_BASCSRV_SWT_APP_ID_SPTAC       (0x03u)
#define EYEQMESPMGR_BASCSRV_SWT_APP_ID_SPC         (0x04u)
#define EYEQMESPMGR_BASCSRV_SWT_APP_ID_DV          (0x05u)
#define EYEQMESPMGR_BASCSRV_SWT_APP_ID_MTF         (0x06u)
#define EYEQMESPMGR_BASCSRV_SWT_APP_ID_NUM         (6u)
typedef VAR(uint8, TYPEDEF) EyeQMespMgr_BascSrvSwtAppIdType;
/*! @} */

/******************************************************************************
Declaration Of Variables
******************************************************************************/
extern VAR(uint32, EyeQMespMgr_VAR) EyeQMespMgr_BascSrvRespLength;
extern VAR(uint8, EyeQMespMgr_VAR) EyeQMespMgr_BascSrvRespData[EYEQMESPMGR_BASCSRV_RESP_BUFF_SIZE];
extern VAR(EyeQMespMgr_BascSrvSwtAppIdType, EyeQMespMgr_VAR) EyeQMespMgr_SwitchAppData;

/******************************************************************************
Declaration Of Constant Data
******************************************************************************/

/******************************************************************************
Declaration Of Functions
******************************************************************************/
extern FUNC(void, EyeQMespMgr_CODE) EyeQMespMgr_BascSrvInit(void);
extern FUNC(void, EyeQMespMgr_CODE) EyeQMespMgr_BascSrvMainFunction(void);
/* Functions to return/get basic service response data */
extern FUNC(Std_ReturnType, EyeQMespMgr_CODE) EyeQMespMgr_BascSrvGetMainSt(
   CONSTP2VAR(EyeQMespMgr_BascSrvMainStType, AUTOMATIC, EyeQMespMgr_APPL_DATA) MainStPtr);
extern FUNC(Std_ReturnType, EyeQMespMgr_CODE) EyeQMespMgr_BascSrvGetExSt(
   CONSTP2VAR(EyeQMespMgr_BascSrvMainStType, AUTOMATIC, EyeQMespMgr_APPL_DATA) MainStPtr,
   CONSTP2VAR(EyeQMespMgr_BascSrvSubStType, AUTOMATIC, EyeQMespMgr_APPL_DATA) SubStPtr);
extern FUNC(Std_ReturnType, EyeQMespMgr_CODE) EyeQMespMgr_BascSrvGetAbout(CONSTP2VAR(uint8, AUTOMATIC, EyeQMespMgr_APPL_DATA) AboutStringPtr);
extern FUNC(Std_ReturnType, EyeQMespMgr_CODE) EyeQMespMgr_BascSrvGetVers(CONSTP2VAR(uint32, AUTOMATIC, EyeQMespMgr_APPL_DATA) VerArrayPtr);
/* Callback functions for application layer */
extern FUNC(void, EyeQMespMgr_CODE) EyeQMespMgr_BascSrvMainStCallback(CONST(EyeQAppl_CallbackStsType, AUTOMATIC) Status);
extern FUNC(void, EyeQMespMgr_CODE) EyeQMespMgr_BascSrvAboutCallback(CONST(EyeQAppl_CallbackStsType, AUTOMATIC) Status);
extern FUNC(void, EyeQMespMgr_CODE) EyeQMespMgr_BascSrvExStCallback(CONST(EyeQAppl_CallbackStsType, AUTOMATIC) Status);
extern FUNC(void, EyeQMespMgr_CODE) EyeQMespMgr_BascSrvVersCallback(CONST(EyeQAppl_CallbackStsType, AUTOMATIC) Status);
extern FUNC(void, EyeQMespMgr_CODE) EyeQMespMgr_BascSrvSwtAppCallback(CONST(EyeQAppl_CallbackStsType, AUTOMATIC) Status);
/* Trigger functions for basic services */
extern FUNC(Std_ReturnType, EyeQMespMgr_CODE) EyeQMespMgr_BascSrvSwitchApp(CONST(EyeQMespMgr_ReqCallbackFct, AUTOMATIC) CallbackFctPtr, 
   CONST(EyeQMespMgr_BascSrvSwtAppIdType, AUTOMATIC) AppId);
extern FUNC(Std_ReturnType, EyeQMespMgr_CODE) EyeQMespMgr_BascSrvReadMainSt(CONST(EyeQMespMgr_ReqCallbackFct, AUTOMATIC) CallbackFctPtr);
extern FUNC(Std_ReturnType, EyeQMespMgr_CODE) EyeQMespMgr_BascSrvReadExSt(CONST(EyeQMespMgr_ReqCallbackFct, AUTOMATIC) CallbackFctPtr);
extern FUNC(Std_ReturnType, EyeQMespMgr_CODE) EyeQMespMgr_BascSrvReadAbout(CONST(EyeQMespMgr_ReqCallbackFct, AUTOMATIC) CallbackFctPtr);
extern FUNC(Std_ReturnType, EyeQMespMgr_CODE) EyeQMespMgr_BascSrvReadVers(CONST(EyeQMespMgr_ReqCallbackFct, AUTOMATIC) CallbackFctPtr);

/******************************************************************************
Declaration Of Function-like Macros
******************************************************************************/
#define EyeQMespMgr_BascSrvConvertFctIdToIdx(FctId)        (FctId - 1u)
#define EyeQMespMgr_BascSrvConvertFctIdxToId(FctIdx)       (FctIdx + 1u)
/******************************************************************************
End Of File
******************************************************************************/

#endif /* EYEQMESPMGR_BASCSRV_H_ */
