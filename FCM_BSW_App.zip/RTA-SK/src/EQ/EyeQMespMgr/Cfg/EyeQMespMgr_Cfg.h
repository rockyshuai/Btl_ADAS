
#ifndef EYEQMESPMGR_CFG_H_
#define EYEQMESPMGR_CFG_H_ 1

/******************************************************************************

WBTL ELECTRONIC document

Copyright WBTL All rights reserved.

*******************************************************************************

@details
   <Describes details of this header file>

******************************************************************************/
/******************************************************************************
External Dependencies
******************************************************************************/
#include <Std_Types.h>

/******************************************************************************
Definition Of Constants
******************************************************************************/
/* Basic Service Configs */
#define EYEQMESPMGR_BASCSRV_RESP_BUFF_SIZE     (64u)
#define EYEQMESPMGR_BASCSRV_VERSION_BUFF_SIZE  (2u)
#define EYEQMESPMGR_BASCSRV_ABOUT_BUFF_SIZE    (64u)

/* EyeSphere Service Configs */
#define EYEQMESPMGR_EYESPHERE_RESP_BUFF_SIZE   (64u)
#define EYEQMESPMGR_EYESPHERE_CMD_BUFF_SIZE    (64u)

/* Boot Service Configs */
#define EYEQMESPMGR_BOOTSRV_RESP_BUFF_SIZE     (8u)

#define EYEQMESPMGR_MAIN_UPDATE_RATE_MS        (5u)
#define EYEQMESPMGR_REQ_TIMEOUT_MS             (500u)
#define EYEQMESPMGR_REQ_TIMEOUT_CNT            (EYEQMESPMGR_REQ_TIMEOUT_MS / EYEQMESPMGR_MAIN_UPDATE_RATE_MS)

/******************************************************************************
Declaration Of Types
******************************************************************************/

/******************************************************************************
Declaration Of Variables
******************************************************************************/

/******************************************************************************
Declaration Of Constant Data
******************************************************************************/

/******************************************************************************
Declaration Of Functions
******************************************************************************/

/******************************************************************************
Declaration Of Function-like Macros
******************************************************************************/

/******************************************************************************
End Of File
******************************************************************************/

#endif /* EYEQMESPMGR_CFG_H_ */
