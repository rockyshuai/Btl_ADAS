
#ifndef EYEQPROTMGR_CFG_H_
#define EYEQPROTMGR_CFG_H_ 1

/******************************************************************************

WBTL ELECTRONIC document

Copyright WBTL All rights reserved.

*******************************************************************************

@details
   <Describes details of this header file>

******************************************************************************/
/******************************************************************************
External Dependencies
******************************************************************************/
#include <Std_Types.h>

/******************************************************************************
Definition Of Constants
******************************************************************************/
#define EYEQPROTMGR_MAIN_UPDATE_RATE_MS        (1u)
#define EYEQPROTMGR_FRAME_RATE_MS              (28u)
#define EYEQPROTMGR_FRAME_RATE_TIMEOUT_MS      (115u)
#define EYEQPROTMGR_FRAME_RATE_MS_AVG_MAX      (38u)
#define EYEQPROTMGR_FRAME_RATE_CNT             (EYEQPROTMGR_FRAME_RATE_MS / EYEQPROTMGR_MAIN_UPDATE_RATE_MS)
#define EYEQPROTMGR_FRAME_RATE_CNT_MAX         (EYEQPROTMGR_FRAME_RATE_MS_AVG_MAX / EYEQPROTMGR_MAIN_UPDATE_RATE_MS)

#define EYEQPROTMGR_FRAME_RATE_AVG_SUM_NUM     (64u)
#define EYEQPROTMGR_FRAME_RATE_ERROR_SUM_NUM   (100u)
#define EYEQPROTMGR_FRAME_RATE_ERROR_SUM_MAX   (3u)

/******************************************************************************
Declaration Of Types
******************************************************************************/

/******************************************************************************
Declaration Of Variables
******************************************************************************/

/******************************************************************************
Declaration Of Constant Data
******************************************************************************/

/******************************************************************************
Declaration Of Functions
******************************************************************************/

/******************************************************************************
Declaration Of Function-like Macros
******************************************************************************/

/******************************************************************************
End Of File
******************************************************************************/

#endif /* EYEQPROTMGR_CFG_H_ */
