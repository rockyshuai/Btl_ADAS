
/******************************************************************************

WBTL ELECTRONIC document

Copyright WBTL. All rights reserved.

******************************************************************************/
/******************************************************************************

@details
   <Describes details of this component implementation and design>

******************************************************************************/
/******************************************************************************
External Dependencies
******************************************************************************/
#include "EyeQProtMgr.h"
#include "EyeQProtMgr_Intl.h"
#include "EyeQProtMgr_Cfg.h"
#include <EyeQ_defs.h>
#include <SysMgr.h>
#include <BswIf.h>
#include <EyeQStMgr.h>
#include <Dem.h>

/******************************************************************************
Component Defines
******************************************************************************/
#define EYEQPROTMGR_APP_EQ_T1_HI                  (125)
#define EYEQPROTMGR_APP_EQ_T1_LO                  (-40)
#define EYEQPROTMGR_APP_EQ_T2_HI                  (125)
#define EYEQPROTMGR_APP_EQ_T2_LO                  (-40)
#define EYEQPROTMGR_APP_CAM1_T1_HI                (125)
#define EYEQPROTMGR_APP_CAM1_T1_LO                (-40)
#define EYEQPROTMGR_APP_CAM1_T2_HI                (125)
#define EYEQPROTMGR_APP_CAM1_T2_LO                (-40)

#define EYEQPROTMGR_BOOTDIAG_BD_TEST_FLT_MASK     ((1u << C_EYEQMSG_BOOTDIAGMSG_BOOT_TEST_RESULTS_BIST)\
                                                  |(1u << C_EYEQMSG_BOOTDIAGMSG_BOOT_TEST_RESULTS_EYEQ_OVER_TEMPERATURE)\
                                                  |(1u << C_EYEQMSG_BOOTDIAGMSG_BOOT_TEST_RESULTS_PLL_INIT_FINISHED)\
                                                  |(1u << C_EYEQMSG_BOOTDIAGMSG_BOOT_TEST_RESULTS_PARITY_CHECK)\
                                                  |(1u << C_EYEQMSG_BOOTDIAGMSG_BOOT_TEST_RESULTS_FLASH_CRC_OF_BOOT)\
                                                  |(1u << C_EYEQMSG_BOOTDIAGMSG_BOOT_TEST_RESULTS_DDR_INIT_FINISHED)\
                                                  |(1u << C_EYEQMSG_BOOTDIAGMSG_BOOT_TEST_RESULTS_DDR_TEMPERATURE)\
                                                  |(1u << C_EYEQMSG_BOOTDIAGMSG_BOOT_TEST_RESULTS_DDR_TEST)\
                                                  |(1u << C_EYEQMSG_BOOTDIAGMSG_BOOT_TEST_RESULTS_FLASH_CRC_OF_APPLICATION)\
                                                  |(1u << C_EYEQMSG_BOOTDIAGMSG_BOOT_TEST_RESULTS_FLASH_CRC_OF_FFS)\
                                                  |(1u << C_EYEQMSG_BOOTDIAGMSG_BOOT_TEST_RESULTS_UNSUPPORTED_EYEQ_VERSION)\
                                                  |(1u << C_EYEQMSG_BOOTDIAGMSG_BOOT_TEST_RESULTS_AUTHENTICATION_FAILURE))

/******************************************************************************
Component Types
******************************************************************************/

/******************************************************************************
Declaration of Local Functions
******************************************************************************/

#define EyeQProtMgr_START_SEC_VAR
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
Definition Of Local Variables
******************************************************************************/

/******************************************************************************
Definition Of Global Variables
******************************************************************************/
extern VAR(EyeQProtMgr_BootDiagDataType, EyeQProtMgr_VAR) EyeQProtMgr_BootDiagData;

#define EyeQProtMgr_STOP_SEC_VAR
#include "EyeQProtMgr_MemMap.h"

#define EyeQProtMgr_START_SEC_CONST
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
Definition Of Local Constant Data
******************************************************************************/

/******************************************************************************
Definition Of Global Constant Data
******************************************************************************/

#define EyeQProtMgr_STOP_SEC_CONST
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
Component Function-like Macros
******************************************************************************/

/******************************************************************************
Definition Of APIs
******************************************************************************/
#define EyeQProtMgr_START_SEC_CODE
#include "EyeQProtMgr_MemMap.h"

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQProtMgr_CODE) eyeqprotmgr_PublishFrameData(void)
{
   /* TODO: zke: publish frame data to upper users */
   BswIf_NewFrameDataReadyNotify();
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQProtMgr_CODE) eyeqprotmgr_CommonRxProcess(void)
{
   Rte_ArPim_MemorySWC_PIM_EyeQProtMgr_VisionMsgNvMData.COM_HIL_Mode_Status = (uint8)EYEQMSG_CORECOMMON_ParamsApp_s.COM_HIL_Mode_Status_b1;
   Rte_ArPim_MemorySWC_PIM_EyeQProtMgr_VisionMsgNvMData.COM_Region_Code = (uint8)EYEQMSG_CORECOMMON_ParamsApp_s.COM_Region_Code_b5;
   Rte_ArPim_MemorySWC_PIM_EyeQProtMgr_VisionMsgNvMData.COM_Driving_Side = (uint8)EYEQMSG_CORECOMMON_ParamsApp_s.COM_Driving_Side_b8;

   /* Todo: Create new event for this time sync error */
   //if (0u == EYEQMSG_CORECOMMON_ParamsApp_s.COM_Last_Clock_Sync_Error_b1)
   //{
   //   Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_FRM_TIMING_FLT, DEM_EVENT_STATUS_PREPASSED);
   //}
   //else
   //{
   //   Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_FRM_TIMING_FLT, DEM_EVENT_STATUS_PREFAILED);
   //}
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQProtMgr_CODE) eyeqprotmgr_CalDynRxProcess(void)
{
   Std_Float32SigDataType eyeqprotvision_clb_dyn_yaw_deg = { .u = EYEQMSG_CALDYN_ParamsApp_s.CLB_DYN_Yaw_Deg_sb32 };
   Rte_ArPim_MemorySWC_PIM_EyeQProtMgr_VisionMsgNvMData.CLB_DYN_Yaw_Deg = eyeqprotvision_clb_dyn_yaw_deg.f;
   Std_Float32SigDataType eyeqprotvision_clb_dyn_pitch_deg = { .u = EYEQMSG_CALDYN_ParamsApp_s.CLB_DYN_Pitch_Deg_sb32 };
   Rte_ArPim_MemorySWC_PIM_EyeQProtMgr_VisionMsgNvMData.CLB_DYN_Pitch_Deg = eyeqprotvision_clb_dyn_pitch_deg.f;
   Std_Float32SigDataType eyeqprotvision_clb_dyn_roll_deg = { .u = EYEQMSG_CALDYN_ParamsApp_s.CLB_DYN_Roll_sb32 };
   Rte_ArPim_MemorySWC_PIM_EyeQProtMgr_VisionMsgNvMData.CLB_DYN_Roll = eyeqprotvision_clb_dyn_roll_deg.f;
   Rte_ArPim_MemorySWC_PIM_EyeQProtMgr_VisionMsgNvMData.CLB_DYN_Yaw_Px = (uint16)EYEQMSG_CALDYN_ParamsApp_s.CLB_DYN_Yaw_Px_b16;
   Rte_ArPim_MemorySWC_PIM_EyeQProtMgr_VisionMsgNvMData.CLB_DYN_Pitch_Px = (uint16)EYEQMSG_CALDYN_ParamsApp_s.CLB_DYN_Pitch_Px_b16;
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQProtMgr_CODE) eyeqprotmgr_CoreCalSPCRxProcess(void)
{
   Std_Float32SigDataType eyeqprotcalspc_baseline_roll = { .u = EYEQMSG_CORECALSPC_ParamsApp_s.CLB_SPC_Baseline_Roll_sb32 };
   Rte_ArPim_MemorySWC_PIM_EyeQProtMgr_CalSPCNvMData.CLB_SPC_Baseline_Roll = eyeqprotcalspc_baseline_roll.f;
   Rte_ArPim_MemorySWC_PIM_EyeQProtMgr_CalSPCNvMData.CLB_SPC_Baseline_Yaw = (uint16)EYEQMSG_CORECALSPC_ParamsApp_s.CLB_SPC_Baseline_Yaw_b16;
   Rte_ArPim_MemorySWC_PIM_EyeQProtMgr_CalSPCNvMData.CLB_SPC_Baseline_Pitch = (uint16)EYEQMSG_CORECALSPC_ParamsApp_s.CLB_SPC_Baseline_Pitch_b16;
   Rte_ArPim_MemorySWC_PIM_EyeQProtMgr_CalSPCNvMData.CLB_SPC_Baseline_Height = (uint16)EYEQMSG_CORECALSPC_ParamsApp_s.CLB_SPC_Baseline_Height_b16;
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQProtMgr_CODE) eyeqprotmgr_FailSafeRxProcess(void)
{
   Rte_ArPim_MemorySWC_PIM_EyeQProtMgr_VisionMsgNvMData.FS_TSR_Out_OF_Calib = (uint8)EYEQMSG_COREFAILSAFE_ParamsApp_s.EYEQMSG_COREFAILSAFEvH_Params_s.FS_TSR_Out_OF_Calib_b8;
   Rte_ArPim_MemorySWC_PIM_EyeQProtMgr_VisionMsgNvMData.FS_Out_Of_Calib = (uint8)EYEQMSG_COREFAILSAFE_ParamsApp_s.EYEQMSG_COREFAILSAFEvH_Params_s.FS_Out_Of_Calib_b3;
   Rte_ArPim_MemorySWC_PIM_EyeQProtMgr_VisionMsgNvMData.FS_Calibration_Misalignment = (uint8)EYEQMSG_COREFAILSAFE_ParamsApp_s.EYEQMSG_COREFAILSAFEvH_Params_s.FS_Calibration_Misalignment_b3;
   Rte_ArPim_MemorySWC_PIM_EyeQProtMgr_VisionMsgNvMData.FS_Out_Of_Focus = (uint8)EYEQMSG_COREFAILSAFE_ParamsApp_s.EYEQMSG_COREFAILSAFEvO_Params_as[0].FS_Out_Of_Focus_0_b3;
   Rte_ArPim_MemorySWC_PIM_EyeQProtMgr_VisionMsgNvMData.FS_C2C_Out_Of_Calib = (uint8)EYEQMSG_COREFAILSAFE_ParamsApp_s.EYEQMSG_COREFAILSAFEvO_Params_as[0].FS_C2C_Out_Of_Calib_0_b3;
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQProtMgr_CODE) eyeqprotmgr_AppRxProcess(void)
{
   sint16 temp_s16;
   sint8 temp_s8;
   Std_ReturnType ret_sts;

   EyeQProtMgr_AppMsgData.FatalError = EYEQMSG_APPMSG_ParamsApp_s.APP_Fatal_Error_b8;
   EyeQProtMgr_AppMsgData.MainSt = EYEQMSG_APPMSG_ParamsApp_s.APP_Main_State_b8;
   EyeQStMgr_NotifyNewAppMsg();

   /*handle temperatures*/
   ret_sts = EYEQMSG_Get_APPMSG_APP_EyeQTemperature1(&temp_s16);
   if (C_SIG_VALID == ret_sts)
   {
      EyeQProtMgr_AppMsgData.EyeQT1 = temp_s16;
      if ((EYEQPROTMGR_APP_EQ_T1_LO < temp_s16) && (EYEQPROTMGR_APP_EQ_T1_HI > temp_s16))
      {
         Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_APP_EQ_INTL_TEMP1_HI, DEM_EVENT_STATUS_PREPASSED);
         Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_APP_EQ_INTL_TEMP1_LO, DEM_EVENT_STATUS_PREPASSED);
      }
      else if (EYEQPROTMGR_APP_EQ_T1_HI <= temp_s16)
      {
         Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_APP_EQ_INTL_TEMP1_HI, DEM_EVENT_STATUS_PREFAILED);
         Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_APP_EQ_INTL_TEMP1_LO, DEM_EVENT_STATUS_PREPASSED);
      }
      else
      {
         Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_APP_EQ_INTL_TEMP1_HI, DEM_EVENT_STATUS_PREPASSED);
         Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_APP_EQ_INTL_TEMP1_LO, DEM_EVENT_STATUS_PREFAILED);
      }
   }
   ret_sts = EYEQMSG_Get_APPMSG_APP_EyeQTemperature2(&temp_s16);
   if (C_SIG_VALID == ret_sts)
   {
      EyeQProtMgr_AppMsgData.EyeQT2 = temp_s16;
      if ((EYEQPROTMGR_APP_EQ_T2_LO < temp_s16) && (EYEQPROTMGR_APP_EQ_T2_HI > temp_s16))
      {
         Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_APP_EQ_INTL_TEMP2_HI, DEM_EVENT_STATUS_PREPASSED);
         Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_APP_EQ_INTL_TEMP2_LO, DEM_EVENT_STATUS_PREPASSED);
      }
      else if (EYEQPROTMGR_APP_EQ_T2_HI <= temp_s16)
      {
         Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_APP_EQ_INTL_TEMP2_HI, DEM_EVENT_STATUS_PREFAILED);
         Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_APP_EQ_INTL_TEMP2_LO, DEM_EVENT_STATUS_PREPASSED);
      }
      else
      {
         Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_APP_EQ_INTL_TEMP2_HI, DEM_EVENT_STATUS_PREPASSED);
         Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_APP_EQ_INTL_TEMP2_LO, DEM_EVENT_STATUS_PREFAILED);
      }
   }
   ret_sts = EYEQMSG_Get_APPMSG_APP_Camera1_temperature_1(&temp_s8);
   if (C_SIG_VALID == ret_sts)
   {
      EyeQProtMgr_AppMsgData.Cam1T1 = temp_s8;
      if ((EYEQPROTMGR_APP_CAM1_T1_LO < temp_s8) && (EYEQPROTMGR_APP_CAM1_T1_HI > temp_s8))
      {
         Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_APP_CAM1_TEMP1_HI, DEM_EVENT_STATUS_PREPASSED);
         Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_APP_CAM1_TEMP1_LO, DEM_EVENT_STATUS_PREPASSED);
      }
      else if (EYEQPROTMGR_APP_CAM1_T1_HI <= temp_s8)
      {
         Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_APP_CAM1_TEMP1_HI, DEM_EVENT_STATUS_PREFAILED);
         Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_APP_CAM1_TEMP1_LO, DEM_EVENT_STATUS_PREPASSED);
      }
      else
      {
         Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_APP_CAM1_TEMP1_HI, DEM_EVENT_STATUS_PREPASSED);
         Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_APP_CAM1_TEMP1_LO, DEM_EVENT_STATUS_PREFAILED);
      }
   }

   ret_sts = EYEQMSG_Get_APPMSG_APP_Camera1_temperature_2(&temp_s8);
   if (C_SIG_VALID == ret_sts)
   {
      EyeQProtMgr_AppMsgData.Cam1T2 = temp_s8;
      if ((EYEQPROTMGR_APP_CAM1_T2_LO < temp_s8) && (EYEQPROTMGR_APP_CAM1_T2_HI > temp_s8))
      {
         Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_APP_CAM1_TEMP2_HI, DEM_EVENT_STATUS_PREPASSED);
         Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_APP_CAM1_TEMP2_LO, DEM_EVENT_STATUS_PREPASSED);
      }
      else if (EYEQPROTMGR_APP_CAM1_T2_HI <= temp_s8)
      {
         Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_APP_CAM1_TEMP2_HI, DEM_EVENT_STATUS_PREFAILED);
         Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_APP_CAM1_TEMP2_LO, DEM_EVENT_STATUS_PREPASSED);
      }
      else
      {
         Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_APP_CAM1_TEMP2_HI, DEM_EVENT_STATUS_PREPASSED);
         Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_APP_CAM1_TEMP2_LO, DEM_EVENT_STATUS_PREFAILED);
      }
   }

   /* Handles Fatal errors */
//   if (EYEQPROTMGR_FATAL_E_APP_OK != EyeQProtMgr_AppMsgData.FatalError)
//   {
//      SysMgr_ReportErrorStatus(SYSMGR_USER_EYEQ, SYSMGR_ERROR_EQ_APP_FATAL_ERROR, TRUE);
//   }
//   else
//   {
//      SysMgr_ReportErrorStatus(SYSMGR_USER_EYEQ, SYSMGR_ERROR_EQ_APP_FATAL_ERROR, FALSE);
//   }
   /* Handles Fatal errors */
   if (EYEQPROTMGR_FATAL_E_APP_OK != EyeQProtMgr_AppMsgData.FatalError)
   {
      Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_APP_EQ_FATAL_ERR, DEM_EVENT_STATUS_PREFAILED);
   }
   else
   {
      Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_APP_EQ_FATAL_ERR, DEM_EVENT_STATUS_PREPASSED);
   }

   if (C_EYEQMSG_APPMSG_APP_FATAL_ERROR_APP_INIT_CAMERA_INIT == EyeQProtMgr_AppMsgData.FatalError)
   {
      (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_APP_FATAL_21, TRUE);
   }
   else
   {
      (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_APP_FATAL_21, FALSE);
   }
   if (C_EYEQMSG_APPMSG_APP_FATAL_ERROR_PLL_COMPARISON_ERROR == EyeQProtMgr_AppMsgData.FatalError)
   {
      (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_APP_FATAL_81, TRUE);
   }
   else
   {
      (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_APP_FATAL_81, FALSE);
   }
   if (C_EYEQMSG_APPMSG_APP_FATAL_ERROR_APP_CPS_STL_FAILED == EyeQProtMgr_AppMsgData.FatalError)
   {
      (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_APP_FATAL_82, TRUE);
   }
   else
   {
      (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_APP_FATAL_82, FALSE);
   }
   if ((C_EYEQMSG_APPMSG_APP_FATAL_ERROR_PV_GENERAL_ERROR == EyeQProtMgr_AppMsgData.FatalError) || 
      (C_EYEQMSG_APPMSG_APP_FATAL_ERROR_PV_VERIFICATION_ERROR == EyeQProtMgr_AppMsgData.FatalError))
   {
      (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_APP_FATAL_90_91, TRUE);
   }
   else
   {
      (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_APP_FATAL_90_91, FALSE);
   }

   /* zke: Todo: publish message data */
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQProtMgr_CODE) eyeqprotmgr_BootDiagRxProcess(void)
{
   if (0u == (EyeQProtMgr_BootDiagData.BDTestResults & EYEQPROTMGR_BOOTDIAG_BD_TEST_FLT_MASK))
   {
      Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_BOOTDIAG_GEN_TEST_FLT, DEM_EVENT_STATUS_PREPASSED);
   }
   else
   {
      Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_BOOTDIAG_GEN_TEST_FLT, DEM_EVENT_STATUS_PREFAILED);
   }

   /* zke: Todo: TBD: For now only check if high or low temp exceeded, need to confirm what if other status? */
   if ((C_EYEQMSG_BOOTDIAGMSG_BOOT_LPDDR4_TEMPERATURE_STATUS_SDRAM_HIGH_TEMP_EXCEEDED != EyeQProtMgr_BootDiagData.BDTempStatus)
      && (C_EYEQMSG_BOOTDIAGMSG_BOOT_LPDDR4_TEMPERATURE_STATUS_SDRAM_LOW_TEMP_EXCEEDED != EyeQProtMgr_BootDiagData.BDTempStatus))
   {
      Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_BOOTDIAG_TEMP_FLT, DEM_EVENT_STATUS_PREPASSED);
   }
   else
   {
      Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_BOOTDIAG_TEMP_FLT, DEM_EVENT_STATUS_PREFAILED);
   }
}

#define EyeQProtMgr_STOP_SEC_CODE
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
End Of File
******************************************************************************/
