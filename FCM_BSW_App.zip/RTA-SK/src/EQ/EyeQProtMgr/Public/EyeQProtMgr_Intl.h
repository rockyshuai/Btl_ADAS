
#ifndef EYEQPROTMGR_INTL_H_
#define EYEQPROTMGR_INTL_H_ 1

/******************************************************************************

WBTL ELECTRONIC document

Copyright WBTL All rights reserved.

*******************************************************************************

@details
   <Describes details of this header file>

******************************************************************************/
/******************************************************************************
External Dependencies
******************************************************************************/
#include <Std_Types.h>
#include <EyeQProtMgr.h>
#include <Rte_Type.h>

/******************************************************************************
Definition Of Constants
******************************************************************************/
#define EYEQPROTMGR_ALL_FRM_RATE_MSG_RCVD_MASK   ((1u << EYEQPROTMGR_FRM_RATE_MSG_CMM)          \
                                                | (1u << EYEQPROTMGR_FRM_RATE_MSG_FCF_VD)       \
                                                | (1u << EYEQPROTMGR_FRM_RATE_MSG_FCF_VRU)      \
                                                | (1u << EYEQPROTMGR_FRM_RATE_MSG_CAL_DYN)      \
                                                | (1u << EYEQPROTMGR_FRM_RATE_MSG_FAIL_SAFE)    \
                                                | (1u << EYEQPROTMGR_FRM_RATE_MSG_SAF_DIAG)     \
                                                | (1u << EYEQPROTMGR_FRM_RATE_MSG_HLB)          \
                                                | (1u << EYEQPROTMGR_FRM_RATE_MSG_TRAFFIC_SIGN) \
                                                | (1u << EYEQPROTMGR_FRM_RATE_MSG_LANE_ADJ)     \
                                                | (1u << EYEQPROTMGR_FRM_RATE_MSG_LANE_HOST)    \
                                                | (1u << EYEQPROTMGR_FRM_RATE_MSG_LANE_RDEDGE)  \
                                                | (1u << EYEQPROTMGR_FRM_RATE_MSG_LANE_APPL)    \
                                                | (1u << EYEQPROTMGR_FRM_RATE_MSG_LDW)          \
                                                | (1u << EYEQPROTMGR_FRM_RATE_MSG_LSR)          \
                                                | (1u << EYEQPROTMGR_FRM_RATE_MSG_LSV)          \
                                                | (1u << EYEQPROTMGR_FRM_RATE_MSG_OBJ)          \
                                                | (1u << EYEQPROTMGR_FRM_RATE_MSG_APP))
/******************************************************************************
Declaration Of Types
******************************************************************************/
typedef struct EyeQProtMgr_DataTypeTag
{
   EyeQProtMgr_StsType Status;
   EyeQProtMgr_StsType FrmRateStatus;
   EyeQProtMgr_StsType LastFrmRateStatus;
   EyeQProtMgr_StsType HistoryStatus;
   uint64 FrmRateTotalCnt;
   uint64 FrmRateTotalErrorCnt;
   uint32 FrmRateMsgRcvdSts;
   uint32 LastFrmRateMsgRcvdSts;
   uint16 FrmRateMsgTimeSum;
   uint8 FrmRateMsgTimeSumCnt;
   uint8 FrmRateNumThisCycle;
   uint8 FrmRateErrorNumThisCycle;
   uint8 FrmRateErrorNumThisCycleMax;
   uint8 CurrSyncFrmId;
   uint8 ExpectedNextSyncFrmId;
   uint8 FrmRateMsgAppRxTime;
   uint8 FrmRateMsgTimer;
   uint8 FrmRateMsgTimeMax;
   uint8 FrmRateMsgTimeMin;
   uint8 FrmRateMsgTimeAvg;
   boolean VisionFrmRateActive;
   boolean FirstFrmRateFinished;
   boolean FrmRateDataReady;
   boolean NewFrmRateStarted;
}EyeQProtMgr_DataType;

typedef struct EyeQProtMgr_BootDiagDataTypeTag
{
   BOOTDIAGMSGBootStage BDStage;
   BOOTDIAGMSGBOOTTestResults BDTestResults;
   BOOTDIAGMSGBOOTLPDDR4TemperatureStatus BDTempStatus;
}EyeQProtMgr_BootDiagDataType;

/******************************************************************************
Declaration Of Variables
******************************************************************************/
extern VAR(EyeQProtMgr_VisionMsgNvMDataType_struct_Imp, RTE_APPL_DATA) Rte_ArPim_MemorySWC_PIM_EyeQProtMgr_VisionMsgNvMData;
extern VAR(EQProtMgr_MgrCalSPCNvMData_Impl, RTE_APPL_DATA) Rte_ArPim_MemorySWC_PIM_EyeQProtMgr_CalSPCNvMData;

/******************************************************************************
Declaration Of Constant Data
******************************************************************************/

/******************************************************************************
Declaration Of Functions
******************************************************************************/
extern FUNC(void, EyeQProtMgr_CODE) eyeqprotmgr_PublishFrameData(void);
extern FUNC(void, EyeQProtMgr_CODE) eyeqprotmgr_CommonRxProcess(void);
extern FUNC(void, EyeQProtMgr_CODE) eyeqprotmgr_CoreCalSPCRxProcess(void);
extern FUNC(void, EyeQProtMgr_CODE) eyeqprotmgr_CalDynRxProcess(void);
extern FUNC(void, EyeQProtMgr_CODE) eyeqprotmgr_AppRxProcess(void);
extern FUNC(void, EyeQProtMgr_CODE) eyeqprotmgr_BootDiagRxProcess(void);
extern FUNC(void, EyeQProtMgr_CODE) eyeqprotmgr_FailSafeRxProcess(void);
/******************************************************************************
Declaration Of Function-like Macros
******************************************************************************/

/******************************************************************************
End Of File
******************************************************************************/

#endif /* EYEQPROTMGR_INTL_H_ */
