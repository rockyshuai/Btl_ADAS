
#ifndef EYEQPROTMGR_CORESAFDIAGSRV_H_
#define EYEQPROTMGR_CORESAFDIAGSRV_H_ 1

/******************************************************************************

WBTL ELECTRONIC document

Copyright WBTL All rights reserved.

*******************************************************************************

@details
   <Describes details of this header file>

******************************************************************************/
/******************************************************************************
External Dependencies
******************************************************************************/
#include <Std_Types.h>
#include <EyeQAppl.h>
#include <EYEQMSG_CoreSafDiagProcess.h>

/******************************************************************************
Definition Of Constants
******************************************************************************/

/******************************************************************************
Declaration Of Types
******************************************************************************/

/******************************************************************************
Declaration Of Variables
******************************************************************************/
extern VAR(uint32, EyeQProtMgr_VAR) EyeQProtMgr_CoreSafDiagSrvRespLength;
/******************************************************************************
Declaration Of Constant Data
******************************************************************************/

/******************************************************************************
Declaration Of Functions
******************************************************************************/
/* Callback functions for application layer */
extern FUNC(void, EyeQProtMgr_CODE) EyeQProtMgr_CoreSafDiagSrvCallback(CONST(EyeQAppl_CallbackStsType, AUTOMATIC) Status);
extern FUNC(void, EyeQProtMgr_CODE) EyeQProtMgr_CoreSafDiagInit(void);
/******************************************************************************
Declaration Of Function-like Macros
******************************************************************************/

/******************************************************************************
End Of File
******************************************************************************/

#endif /* EYEQPROTMGR_CORESAFDIAGSRV_H_ */
