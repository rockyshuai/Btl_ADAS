
#ifndef EYEQPROTMGR_H_
#define EYEQPROTMGR_H_ 1

/******************************************************************************

WBTL ELECTRONIC document

Copyright WBTL All rights reserved.

*******************************************************************************

@details
   <Describes details of this header file>

******************************************************************************/
/******************************************************************************
External Dependencies
******************************************************************************/
#include <Std_Types.h>
#include <EyeQProtMgr_BootDiagSrv.h>
#include <EyeQProtMgr_CoreCommonSrv.h>
#include <EyeQProtMgr_FcfVd.h>
#include <EyeQProtMgr_FcfVru.h>
#include <EyeQProtMgr_CalDyn.h>
#include <EyeQProtMgr_FailSafe.h>
#include <EyeQProtMgr_HLB.h>
#include <EyeQProtMgr_AppMsgSrv.h>
#include <EyeQProtMgr_CoreObjSrv.h>
#include <EyeQProtMgr_CoreTrafficSignSrv.h>
#include <EyeQProtMgr_CoreLaneHostSrv.h>
#include <EyeQProtMgr_CoreLaneApplSrv.h>
#include <EyeQProtMgr_CoreLaneAdjSrv.h>
#include <EyeQProtMgr_CoreLaneRdEdgeSrv.h>
#include <EyeQProtMgr_CoreLatDepWarnSrv.h>
#include <EyeQProtMgr_CoreCalStaticSrv.h>
#include <EyeQProtMgr_CoreLightRFLSrv.h>
#include <EyeQProtMgr_CoreLightVCLSrv.h>
#include <EyeQProtMgr_CoreMTFVProtocolSrv.h>
#include <EyeQProtMgr_CoreCalSPCSrv.h>
#include <EyeQProtMgr_CoreSafDiagSrv.h>


/******************************************************************************
Definition Of Constants
******************************************************************************/

/******************************************************************************
Declaration Of Types
******************************************************************************/
/*!
 * @brief List of all vision mode frame rate protocol messages
 * @param enum
 * @{
 */
#define EYEQPROTMGR_FRM_RATE_MSG_CMM             (0u)
#define EYEQPROTMGR_FRM_RATE_MSG_APP             (1u)
#define EYEQPROTMGR_FRM_RATE_MSG_FCF_VD          (2u)
#define EYEQPROTMGR_FRM_RATE_MSG_FCF_VRU         (3u)
#define EYEQPROTMGR_FRM_RATE_MSG_CAL_DYN         (4u)
#define EYEQPROTMGR_FRM_RATE_MSG_FAIL_SAFE       (5u)
#define EYEQPROTMGR_FRM_RATE_MSG_HLB             (6u)
#define EYEQPROTMGR_FRM_RATE_MSG_OBJ             (7u)
#define EYEQPROTMGR_FRM_RATE_MSG_TRAFFIC_SIGN    (8u)
#define EYEQPROTMGR_FRM_RATE_MSG_LANE_HOST       (9u)
#define EYEQPROTMGR_FRM_RATE_MSG_LANE_ADJ        (10u)
#define EYEQPROTMGR_FRM_RATE_MSG_LANE_RDEDGE     (11u)
#define EYEQPROTMGR_FRM_RATE_MSG_LANE_APPL       (12u)
#define EYEQPROTMGR_FRM_RATE_MSG_LDW             (13u)
#define EYEQPROTMGR_FRM_RATE_MSG_LSR             (14u)
#define EYEQPROTMGR_FRM_RATE_MSG_LSV             (15u)
#define EYEQPROTMGR_FRM_RATE_MSG_SAF_DIAG        (16u)

#define EYEQPROTMGR_FRM_RATE_MSG_NUM             (17u)

typedef VAR(uint8, TYPEDEF) EyeQProtMgr_FrmRateMsgType;
/*! @} */

/*!
 * @brief List of all non frame rate protocol messages
 * @param enum
 * @{
 */
#define EYEQPROTMGR_MSG_BOOT_DIAG                (0u)
#define EYEQPROTMGR_MSG_CAL_SPC                  (1u)
#define EYEQPROTMGR_MSG_CAL_STATIC               (2u)
#define EYEQPROTMGR_MSG_MTFV                     (3u)
#define EYEQPROTMGR_MSG_NUM                      (4u)
typedef VAR(uint8, TYPEDEF) EyeQProtMgr_MsgType;
/*! @} */

/*!
 * @brief Message receive status
 * @param enum
 * @{
 */
#define EYEQPROTMGR_MSG_RX_STS_OK                (0u)
#define EYEQPROTMGR_MSG_RX_STS_NOT_OK            (1u)
#define EYEQPROTMGR_MSG_RX_STS_CRC_FAIL          (2u)
#define EYEQPROTMGR_MSG_RX_STS_SYNC_ID_ERR       (3u)
#define EYEQPROTMGR_MSG_RX_STS_DATA_NOT_MATCH    (4u)
#define EYEQPROTMGR_MSG_RX_STS_DG_MSG_UNAVAL     (5u)
#define EYEQPROTMGR_MSG_RX_STS_NUM               (6u)
typedef VAR(uint8, TYPEDEF) EyeQProtMgr_MsgRxStsType;
/*! @} */

/*!
 * @brief Failure status type
 * @param enum
 * @{
 */
#define EYEQPROTMGR_E_STS_MSG_RX_FLT             (1u << 0u)
#define EYEQPROTMGR_E_STS_MSG_RX_TIMEOUT         (1u << 1u)
#define EYEQPROTMGR_E_STS_SYNC_FRM_ID            (1u << 2u)
#define EYEQPROTMGR_E_STS_CRC                    (1u << 3u)
#define EYEQPROTMGR_E_STS_CONDITION_INVALID      (1u << 4u)
#define EYEQPROTMGR_E_STS_DATA_INVALID           (1u << 5u)
#define EYEQPROTMGR_E_STS_DG_MSG_UNAVAL          (1u << 6u)
#define EYEQPROTMGR_E_STS_NUM                    (7u)
typedef VAR(uint32, TYPEDEF) EyeQProtMgr_StsType;
/*! @} */

typedef struct EyeQProtMgr_FrmRateStsTypeTag
{
   EyeQProtMgr_StsType FrmStatus;
   EyeQProtMgr_StsType MsgStatus[EYEQPROTMGR_FRM_RATE_MSG_NUM];
   uint32 FrmMsgInvalidFlags;
   uint8 FrameSyncId;
   boolean NewFrameDataReady;
}EyeQProtMgr_FrmRateStsType;

typedef struct EyeQProtMgr_VisionMsgNvMDataTypeTag
{
   float32 CLB_DYN_Yaw_Deg;
   float32 CLB_DYN_Pitch_Deg;
   float32 CLB_DYN_Roll;
   uint16  CLB_DYN_Yaw_Px;
   uint16  CLB_DYN_Pitch_Px;
   uint8   COM_HIL_Mode_Status;
   uint8   COM_Region_Code;
   uint8   COM_Driving_Side;
   uint8   FS_TSR_Out_OF_Calib;
   uint8   FS_Out_Of_Calib;
   uint8   FS_Calibration_Misalignment;
   uint8   FS_Out_Of_Focus;
   uint8   FS_C2C_Out_Of_Calib;
   uint8   Reserved1[4];
   uint8   Reserved2[4];
}EyeQProtMgr_VisionMsgNvMDataType;

typedef struct EyeQProtMgr_CalSPCNvMDataTypeTag
{
   float32 CLB_SPC_Baseline_Roll;
   uint16  CLB_SPC_Baseline_Yaw;
   uint16  CLB_SPC_Baseline_Pitch;
   uint16  CLB_SPC_Baseline_Height;
   uint8   Reserved1[4];
} EyeQProtMgr_CalSPCNvMDataType;

/******************************************************************************
Declaration Of Variables
******************************************************************************/
//extern VAR(EyeQProtMgr_VisionMsgNvMDataType, EyeQProtMgr_VAR) EyeQProtMgr_VisionMsgNvMData;
//extern VAR(EyeQProtMgr_CalSPCNvMDataType, EyeQProtMgr_VAR) EyeQProtMgr_CalSPCNvMData;

/******************************************************************************
Declaration Of Constant Data
******************************************************************************/

/******************************************************************************
Declaration Of Functions
******************************************************************************/
extern FUNC(void, EyeQProtMgr_CODE) EyeQProtMgr_Init(void);
extern FUNC(void, EyeQProtMgr_CODE) EyeQProtMgr_EnterVisionInit(void);
extern FUNC(void, EyeQProtMgr_CODE) EyeQProtMgr_MainFunction(void);
extern FUNC(void, EyeQProtMgr_CODE) EyeQProtMgr_NotifyFrmRateMsgRxSts(CONST(EyeQProtMgr_FrmRateMsgType, AUTOMATIC) Msg, CONST(EyeQProtMgr_MsgRxStsType, AUTOMATIC) RxSts);
extern FUNC(void, EyeQProtMgr_CODE) EyeQProtMgr_NotifyMsgRxSts(CONST(EyeQProtMgr_MsgType, AUTOMATIC) Msg, CONST(EyeQProtMgr_MsgRxStsType, AUTOMATIC) RxSts);
extern FUNC(void, EyeQProtMgr_CODE) EyeQProtMgr_VisionFrameRateActive(CONST(boolean, AUTOMATIC) Active);
extern FUNC(uint8, EyeQProtMgr_CODE) EyeQProtMgr_GetCurrSyncFrmId(void);
extern FUNC(uint8, EyeQProtMgr_CODE) EyeQProtMgr_GetExpectedNextSyncFrmId(void);
extern FUNC(void, EyeQProtMgr_CODE) EyeQProtMgr_GetFrmRateSts(CONSTP2VAR(EyeQProtMgr_FrmRateStsType, AUTOMATIC, EyeQProtMgr_APPL_DATA) DstPtr);
extern FUNC(boolean, EyeQProtMgr_CODE) EyeQProtMgr_IsFirstFrameRateFinished(void);
extern FUNC(void, EyeQProtMgr_CODE) EyeQProtMgr_PrepareShutdown(void);

/******************************************************************************
Declaration Of Function-like Macros
******************************************************************************/

/******************************************************************************
End Of File
******************************************************************************/

#endif /* EYEQPROTMGR_H_ */
