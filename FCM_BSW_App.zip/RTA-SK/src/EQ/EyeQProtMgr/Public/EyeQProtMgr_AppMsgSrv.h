
#ifndef EYEQPROTMGR_APPMSGSRV_H_
#define EYEQPROTMGR_APPMSGSRV_H_ 1

/******************************************************************************

WBTL ELECTRONIC document

Copyright WBTL All rights reserved.

*******************************************************************************

@details
   <Describes details of this header file>

******************************************************************************/
/******************************************************************************
External Dependencies
******************************************************************************/
#include <Std_Types.h>
#include <EYEQMSG_AppMsgProcess.h>
#include <EyeQMespMgr_BascSrv.h>
/******************************************************************************
Definition Of Constants
******************************************************************************/

/******************************************************************************
Declaration Of Types
******************************************************************************/
/*!
 * @brief List of all fatal errors reported by EQ App Msg
 * @param enum
 * @{
 */
#define EYEQPROTMGR_FATAL_E_APP_OK                             (0u)
#define EYEQPROTMGR_FATAL_E_APP_ERROR                          (1u)
#define EYEQPROTMGR_FATAL_E_APP_FS_ERROR                       (10u)
#define EYEQPROTMGR_FATAL_E_APP_CONFIGURATION_ERROR            (11u)
#define EYEQPROTMGR_FATAL_E_APP_INIT_FAILED                    (20u)
#define EYEQPROTMGR_FATAL_E_APP_INIT_CAMERA_INIT               (21u)
#define EYEQPROTMGR_FATAL_E_APP_INIT_CAMERA_EEPROM             (22u)
#define EYEQPROTMGR_FATAL_E_APP_INIT_CAMERA_SER_CONNECTIVITY   (23u)
#define EYEQPROTMGR_FATAL_E_APP_INIT_CAMERA_SENSOR_ID_MISMATCH (24u)
#define EYEQPROTMGR_FATAL_E_APP_GRAB_CAM_FAILED                (30u)
#define EYEQPROTMGR_FATAL_E_APP_CODING_FROM_FLASH_FAILED       (40u)
#define EYEQPROTMGR_FATAL_E_APP_I2C_VIDEO_GRAB_FAILED          (50u)
#define EYEQPROTMGR_FATAL_E_APP_I2C_CAMERA_SELF_RESET          (51u)
#define EYEQPROTMGR_FATAL_E_APP_I2C_TIMEOUT_ERROR              (52u)
#define EYEQPROTMGR_FATAL_E_APP_PATTERN_TEST                   (70u)
#define EYEQPROTMGR_FATAL_E_APP_CAM_PARAMS_CCFT_CRC_FAILED     (80u)
#define EYEQPROTMGR_FATAL_E_PLL_COMPARISON_ERROR               (81u)
#define EYEQPROTMGR_FATAL_E_APP_CPS_STL_FAILED                 (82u)
#define EYEQPROTMGR_FATAL_E_APP_DDR_DRIFT_COMPARISON_FAILED    (83u)
#define EYEQPROTMGR_FATAL_E_PV_GENERAL_ERROR                   (90u)
#define EYEQPROTMGR_FATAL_E_PV_VERIFICATION_ERROR              (91u)
#define EYEQPROTMGR_FATAL_E_APP_GVPU_STATE_TERMINAL            (127u)
#define EYEQPROTMGR_FATAL_E_EDR_WROTE_TO_FLASH                 (129u)
typedef VAR(uint8, TYPEDEF) EyeQProtMgr_FatalErrorType;
/*! @} */

typedef struct EyeQProtMgr_AppMsgDataTypeTag
{
   EyeQProtMgr_FatalErrorType FatalError;
   EyeQMespMgr_BascSrvMainStType MainSt;
   sint16 EyeQT1;
   sint16 EyeQT2;
   sint8 Cam1T1;
   sint8 Cam1T2;
}EyeQProtMgr_AppMsgDataType;

/******************************************************************************
Declaration Of Variables
******************************************************************************/
extern VAR(uint32, EyeQProtMgr_VAR) EyeQProtMgr_AppSrvRespLength;
extern VAR(EyeQProtMgr_AppMsgDataType, EyeQProtMgr_VAR) EyeQProtMgr_AppMsgData;

/******************************************************************************
Declaration Of Constant Data
******************************************************************************/

/******************************************************************************
Declaration Of Functions
******************************************************************************/
extern FUNC(void, EyeQProtMgr_CODE) EyeQProtMgr_AppMsgSrvInit(void);
extern FUNC(void, EyeQProtMgr_CODE) EyeQProtMgr_AppMsgSrvCallback(CONST(EyeQAppl_CallbackStsType, AUTOMATIC) Status);
extern FUNC(EyeQMespMgr_BascSrvMainStType, EyeQProtMgr_CODE) EyeQProtMgr_AppMsgSrvGetMainSt(void);
extern FUNC(Std_ReturnType, EyeQProtMgr_CODE) EyeQProtMgr_AppMsgSrvGetTemperatures(
   CONSTP2VAR(sint16, AUTOMATIC, EyeQProtMgr_APPL_DATA) EyeQT1Ptr,
   CONSTP2VAR(sint16, AUTOMATIC, EyeQProtMgr_APPL_DATA) EyeQT2Ptr,
   CONSTP2VAR(sint8, AUTOMATIC, EyeQProtMgr_APPL_DATA) Cam1T1Ptr,
   CONSTP2VAR(sint8, AUTOMATIC, EyeQProtMgr_APPL_DATA) Cam1T2Ptr);

/******************************************************************************
Declaration Of Function-like Macros
******************************************************************************/

/******************************************************************************
End Of File
******************************************************************************/

#endif /* EYEQPROTMGR_APPMSGSRV_H_ */
