
#ifndef EYEQPROTMGR_BOOTDIAGSRV_H_
#define EYEQPROTMGR_BOOTDIAGSRV_H_ 1

/******************************************************************************

WBTL ELECTRONIC document

Copyright WBTL All rights reserved.

*******************************************************************************

@details
   <Describes details of this header file>

******************************************************************************/
/******************************************************************************
External Dependencies
******************************************************************************/
#include <Std_Types.h>
#include <EYEQMSG_BootDiagMsgProcess.h>
#include <EyeQAppl.h>

/******************************************************************************
Definition Of Constants
******************************************************************************/

/******************************************************************************
Declaration Of Types
******************************************************************************/

/******************************************************************************
Declaration Of Variables
******************************************************************************/
extern VAR(uint32, EyeQProtMgr_VAR) EyeQProtMgr_BootDiagSrvRespLength;

/******************************************************************************
Declaration Of Constant Data
******************************************************************************/

/******************************************************************************
Declaration Of Functions
******************************************************************************/
extern FUNC(void, EyeQProtMgr_CODE) EyeQProtMgr_BootDiagSrvCallback(CONST(EyeQAppl_CallbackStsType, EyeQProtMgr_CONST) Status);
extern FUNC(uint8, EyeQProtMgr_CODE) EyeQProtMgr_GetBootDiagRxCnt(void);
extern FUNC(void, EyeQProtMgr_CODE) EyeQProtMgr_BootDiagInit(void);

/******************************************************************************
Declaration Of Function-like Macros
******************************************************************************/

/******************************************************************************
End Of File
******************************************************************************/

#endif /* EYEQPROTMGR_BOOTDIAGSRV_H_ */
