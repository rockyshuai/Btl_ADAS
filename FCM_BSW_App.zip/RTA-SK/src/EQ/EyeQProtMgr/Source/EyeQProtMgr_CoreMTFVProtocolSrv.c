
/******************************************************************************

WBTL ELECTRONIC document

Copyright WBTL. All rights reserved.

******************************************************************************/
/******************************************************************************

@details
   <Describes details of this component implementation and design>

******************************************************************************/
/******************************************************************************
External Dependencies
******************************************************************************/
#include <EyeQProtMgr.h>
#include <EyeQProtMgr_Intl.h>
#include <EyeQProtMgr_CoreMTFVProtocolSrv.h>
#include <Crc.h>

/******************************************************************************
Component Defines
******************************************************************************/

#define EYEQPROTMGR_MTFV_PROT_VERSION      (0x01u)

/******************************************************************************
Component Types
******************************************************************************/

/******************************************************************************
Declaration of Local Functions
******************************************************************************/

#define EyeQProtMgr_START_SEC_VAR
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
Definition Of Local Variables
******************************************************************************/

/******************************************************************************
Definition Of Global Variables
******************************************************************************/
VAR(uint32, EyeQProtMgr_VAR) EyeQProtMgr_CoreMTFVSrvRespLength;

#define EyeQProtMgr_STOP_SEC_VAR
#include "EyeQProtMgr_MemMap.h"

#define EyeQProtMgr_START_SEC_CONST
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
Definition Of Local Constant Data
******************************************************************************/

/******************************************************************************
Definition Of Global Constant Data
******************************************************************************/

#define EyeQProtMgr_STOP_SEC_CONST
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
Component Function-like Macros
******************************************************************************/

/******************************************************************************
Definition Of APIs
******************************************************************************/
#define EyeQProtMgr_START_SEC_CODE
#include "EyeQProtMgr_MemMap.h"

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQProtMgr_CODE) EyeQProtMgr_CoreMTFVSrvCallback(CONST(EyeQAppl_CallbackStsType, AUTOMATIC) Status)
{
   uint32 msg_length;
   uint8 expected_sync_id;
   uint8 sync_id;

   switch (Status)
   {
      case EYEQAPPL_CB_STS_RX_OK:
      {
         msg_length = (uint32)(C_EYEQMSG_COREMTFVvH_MSG_LEN
            + (EYEQMSG_COREMTFV_Params_s.EYEQMSG_COREMTFVvH_Params_s.MTFV_Number_of_points_b4 * C_EYEQMSG_COREMTFVvO_MSG_LEN));
         if (msg_length == EyeQProtMgr_CoreMTFVSrvRespLength)
         {
            if (EYEQPROTMGR_MTFV_PROT_VERSION == EYEQMSG_COREMTFV_Params_s.EYEQMSG_COREMTFVvH_Params_s.MTFV_Protocol_Version_b8)
            {
               EYEQMSG_COREMTFV_ParamsApp_s = EYEQMSG_COREMTFV_Params_s;
               /* zke: TBD, Todo: confirm for MTFV the sync ID update may not be from common msg */
               expected_sync_id = EyeQProtMgr_GetCurrSyncFrmId();
               (void)EYEQMSG_Get_COREMTFVvH_MTFV_Sync_ID(&sync_id);
               if (expected_sync_id == sync_id)
               {
                  EyeQProtMgr_NotifyMsgRxSts(EYEQPROTMGR_MSG_MTFV, EYEQPROTMGR_MSG_RX_STS_OK);

               }
               else
               {
                  EyeQProtMgr_NotifyMsgRxSts(EYEQPROTMGR_MSG_MTFV, EYEQPROTMGR_MSG_RX_STS_SYNC_ID_ERR);
               }
            }
            else
            {
               EyeQProtMgr_NotifyMsgRxSts(EYEQPROTMGR_MSG_MTFV, EYEQPROTMGR_MSG_RX_STS_DATA_NOT_MATCH);
            }
         }
         else
         {
            EyeQProtMgr_NotifyMsgRxSts(EYEQPROTMGR_MSG_MTFV, EYEQPROTMGR_MSG_RX_STS_NOT_OK);
         }
         break;
      }
      case EYEQAPPL_CB_STS_RX_DG_UNAVAL:
      {
         EyeQProtMgr_NotifyMsgRxSts(EYEQPROTMGR_MSG_MTFV, EYEQPROTMGR_MSG_RX_STS_DG_MSG_UNAVAL);
         break;
      }
      /* This msg is Rx only and single frame, so if status is Tx or rx_new_frame then something is wrong */
      case EYEQAPPL_CB_STS_RX_FAILED:
      case EYEQAPPL_CB_STS_TX_OK:
      case EYEQAPPL_CB_STS_TX_FAILED:
      case EYEQAPPL_CB_STS_RX_NEW_FRAME:
      default:
      {
         EyeQProtMgr_NotifyMsgRxSts(EYEQPROTMGR_MSG_MTFV, EYEQPROTMGR_MSG_RX_STS_NOT_OK);
         break;
      }
   }
}

#define EyeQProtMgr_STOP_SEC_CODE
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
End Of File
******************************************************************************/
