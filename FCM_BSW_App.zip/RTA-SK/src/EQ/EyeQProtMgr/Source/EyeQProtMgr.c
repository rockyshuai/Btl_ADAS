
/******************************************************************************

WBTL ELECTRONIC document

Copyright WBTL. All rights reserved.

******************************************************************************/
/******************************************************************************

@details
   <Describes details of this component implementation and design>

******************************************************************************/
/******************************************************************************
External Dependencies
******************************************************************************/
#include <EyeQProtMgr.h>
#include <EyeQProtMgr_Cfg.h>
#include <EyeQProtMgr_Intl.h>
#include <EYEQMSG_CoreCommonProcess.h>
#include <Std_Limits.h>
#include <EyeQStMgr.h>
#include <NvM.h>
#include <Dem.h>


/******************************************************************************
Component Defines
******************************************************************************/

/******************************************************************************
Component Types
******************************************************************************/

/******************************************************************************
Declaration of Local Functions
******************************************************************************/
LOCAL FUNC(void, EyeQProtMgr_CODE) eyeqprotmgr_FrmRateStsInit(void);

#define EyeQProtMgr_START_SEC_VAR
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
Definition Of Local Variables
******************************************************************************/
LOCAL VAR(EyeQProtMgr_DataType, EyeQProtMgr_VAR) EyeQProtMgr_Data;
LOCAL VAR(EyeQProtMgr_VisionMsgNvMDataType_struct_Imp, EyeQProtMgr_VAR) EyeQProtMgr_VisionMsgNvMData;
LOCAL VAR(EQProtMgr_MgrCalSPCNvMData_Impl, EyeQProtMgr_VAR) EyeQProtMgr_CalSPCNvMData;

/******************************************************************************
Definition Of Global Variables
******************************************************************************/
VAR(EyeQProtMgr_FrmRateStsType, EyeQProtMgr_VAR) EyeQProtMgr_FrmRateSts;
//VAR(EyeQProtMgr_VisionMsgNvMDataType, EyeQProtMgr_VAR) EyeQProtMgr_VisionMsgNvMData;
//VAR(EyeQProtMgr_CalSPCNvMDataType, EyeQProtMgr_VAR) EyeQProtMgr_CalSPCNvMData;


#define EyeQProtMgr_STOP_SEC_VAR
#include "EyeQProtMgr_MemMap.h"

#define EyeQProtMgr_START_SEC_CONST
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
Definition Of Local Constant Data
******************************************************************************/

/******************************************************************************
Definition Of Global Constant Data
******************************************************************************/

#define EyeQProtMgr_STOP_SEC_CONST
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
Component Function-like Macros
******************************************************************************/

/******************************************************************************
Definition Of APIs
******************************************************************************/
#define EyeQProtMgr_START_SEC_CODE
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
LOCAL FUNC(void, EyeQProtMgr_CODE) eyeqprotmgr_FrmRateStsInit(void)
{
   uint8_least msg_index;

   EyeQProtMgr_FrmRateSts.FrameSyncId = 0u;
   EyeQProtMgr_FrmRateSts.FrmMsgInvalidFlags = EYEQPROTMGR_ALL_FRM_RATE_MSG_RCVD_MASK;
   EyeQProtMgr_FrmRateSts.FrmStatus = 0u;
   EyeQProtMgr_FrmRateSts.NewFrameDataReady = FALSE;
   
   for (msg_index = 0u; msg_index < EYEQPROTMGR_FRM_RATE_MSG_NUM; msg_index++)
   {
      EyeQProtMgr_FrmRateSts.MsgStatus[msg_index] = 0u;
   }
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQProtMgr_CODE) EyeQProtMgr_Init(void)
{
   EyeQProtMgr_Data.Status = 0u;
   EyeQProtMgr_Data.FrmRateStatus = 0u;
   EyeQProtMgr_Data.LastFrmRateStatus = 0u;
   EyeQProtMgr_Data.HistoryStatus = 0u;
   EyeQProtMgr_Data.VisionFrmRateActive = FALSE;
   EyeQProtMgr_Data.ExpectedNextSyncFrmId = 0u;
   EyeQProtMgr_Data.CurrSyncFrmId = 0u;
   EyeQProtMgr_Data.FrmRateMsgRcvdSts = 0u;
   EyeQProtMgr_Data.LastFrmRateMsgRcvdSts = 0u;
   EyeQProtMgr_Data.FrmRateMsgTimer = 0u;
   EyeQProtMgr_Data.FrmRateMsgTimeAvg = EYEQPROTMGR_FRAME_RATE_CNT;
   EyeQProtMgr_Data.FrmRateMsgTimeMax = EYEQPROTMGR_FRAME_RATE_CNT;
   EyeQProtMgr_Data.FrmRateMsgTimeMin = EYEQPROTMGR_FRAME_RATE_CNT;
   EyeQProtMgr_Data.FrmRateMsgTimeSum = 0u;
   EyeQProtMgr_Data.FrmRateMsgTimeSumCnt = 0u;
   EyeQProtMgr_Data.FirstFrmRateFinished = FALSE;
   EyeQProtMgr_Data.FrmRateMsgAppRxTime = 0u;
   EyeQProtMgr_Data.FrmRateDataReady = FALSE;
   EyeQProtMgr_Data.NewFrmRateStarted = FALSE;
   EyeQProtMgr_Data.FrmRateErrorNumThisCycle = 0u;
   EyeQProtMgr_Data.FrmRateErrorNumThisCycleMax = 0u;
   EyeQProtMgr_Data.FrmRateNumThisCycle = 0u;
   EyeQProtMgr_Data.FrmRateTotalCnt = 0u;
   EyeQProtMgr_Data.FrmRateTotalErrorCnt = 0u;

   EyeQProtMgr_VisionMsgNvMData = Rte_ArPim_MemorySWC_PIM_EyeQProtMgr_VisionMsgNvMData;
   EyeQProtMgr_CalSPCNvMData = Rte_ArPim_MemorySWC_PIM_EyeQProtMgr_CalSPCNvMData;

   EyeQProtMgr_CoreSafDiagInit();
   eyeqprotmgr_FrmRateStsInit();

   EyeQProtMgr_AppMsgSrvInit();
   EyeQProtMgr_BootDiagInit();
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQProtMgr_CODE) EyeQProtMgr_EnterVisionInit(void)
{
   EyeQProtMgr_CoreSafDiagInit();
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQProtMgr_CODE) EyeQProtMgr_MainFunction(void)
{
   if (FALSE != EyeQProtMgr_Data.VisionFrmRateActive)
   {
      if (STD_UINT8_MAX > EyeQProtMgr_Data.FrmRateMsgTimer)
      {
         EyeQProtMgr_Data.FrmRateMsgTimer++;
      }
      if (EYEQPROTMGR_FRAME_RATE_TIMEOUT_MS < EyeQProtMgr_Data.FrmRateMsgTimer)
      {
         EyeQProtMgr_Data.Status |= EYEQPROTMGR_E_STS_MSG_RX_TIMEOUT;
         /* If no frame message timeout then hard reset EQ */
         (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_NO_FRM_MSG_TOUT, TRUE);
         Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_FRM_TIMING_FLT, DEM_EVENT_STATUS_PREFAILED);
      }
      else
      {
         /* Nothing for now */
      }
   }

   /* Todo: zke: report DEM DTCs base on EyeQProtMgr_Data.Status and clears it, and if any fault matured, try to reset EyeQ or handles */
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQProtMgr_CODE) EyeQProtMgr_NotifyFrmRateMsgRxSts(CONST(EyeQProtMgr_FrmRateMsgType, AUTOMATIC) Msg, CONST(EyeQProtMgr_MsgRxStsType, AUTOMATIC) RxSts)
{
   EyeQProtMgr_StsType msg_status = 0u;
   boolean publish = FALSE;
   boolean clear_frm_status = FALSE;

   if ((Msg < EYEQPROTMGR_FRM_RATE_MSG_NUM) && (RxSts < EYEQPROTMGR_MSG_RX_STS_NUM))
   {
      if (FALSE != EyeQProtMgr_Data.VisionFrmRateActive)
      {
         /* If zero byte == 0xFF then message is unavailable but still want to count it as a valid frame message just don't use it */
         if ((EYEQPROTMGR_MSG_RX_STS_OK == RxSts) || (EYEQPROTMGR_MSG_RX_STS_DG_MSG_UNAVAL == RxSts))
         {
            if (0u != (EyeQProtMgr_Data.FrmRateMsgRcvdSts & (1u << Msg)))
            {
               /* Shall not receive for more than once */
               EyeQProtMgr_Data.FrmRateStatus |= EYEQPROTMGR_E_STS_CONDITION_INVALID;
               msg_status |= EYEQPROTMGR_E_STS_CONDITION_INVALID;
            }

            if (EYEQPROTMGR_MSG_RX_STS_DG_MSG_UNAVAL == RxSts)
            {
               EyeQProtMgr_Data.FrmRateStatus |= EYEQPROTMGR_E_STS_DG_MSG_UNAVAL;
               msg_status |= EYEQPROTMGR_E_STS_DG_MSG_UNAVAL;
            }
         }
         else
         {
            switch (RxSts)
            {
               case EYEQPROTMGR_MSG_RX_STS_NOT_OK:
               {
                  EyeQProtMgr_Data.FrmRateStatus |= EYEQPROTMGR_E_STS_MSG_RX_FLT;
                  msg_status |= EYEQPROTMGR_E_STS_MSG_RX_FLT;
                  break;
               }
               case EYEQPROTMGR_MSG_RX_STS_CRC_FAIL:
               {
                  EyeQProtMgr_Data.FrmRateStatus |= EYEQPROTMGR_E_STS_CRC;
                  msg_status |= EYEQPROTMGR_E_STS_CRC;
                  break;
               }
               case EYEQPROTMGR_MSG_RX_STS_SYNC_ID_ERR:
               {
                  EyeQProtMgr_Data.FrmRateStatus |= EYEQPROTMGR_E_STS_SYNC_FRM_ID;
                  msg_status |= EYEQPROTMGR_E_STS_SYNC_FRM_ID;
                  break;
               }
               case EYEQPROTMGR_MSG_RX_STS_DATA_NOT_MATCH:
               {
                  EyeQProtMgr_Data.FrmRateStatus |= EYEQPROTMGR_E_STS_DATA_INVALID;
                  msg_status |= EYEQPROTMGR_E_STS_DATA_INVALID;
                  break;
               }
               default:
               {
                  EyeQProtMgr_Data.FrmRateStatus |= EYEQPROTMGR_E_STS_CONDITION_INVALID;
                  msg_status |= EYEQPROTMGR_E_STS_CONDITION_INVALID;
                  break;
               }
            }
         }

         /* No matter what RxSts, set msg received flag because it is not a missing msg */
         EyeQProtMgr_Data.FrmRateMsgRcvdSts |= (1u << Msg);

         /* If first message of the camera frame per frame rate */
         if (EYEQPROTMGR_FRM_RATE_MSG_CMM == Msg)
         {
            eyeqprotmgr_FrmRateStsInit();

            EyeQProtMgr_Data.FrmRateDataReady = FALSE;
            EyeQProtMgr_Data.NewFrmRateStarted = TRUE;

            if (EYEQPROTMGR_MSG_RX_STS_OK == RxSts)
            {
               /* Update status for new cycle of frame messages */
               (void)EYEQMSG_Get_CORECOMMON_COM_Sync_Frame_ID(&EyeQProtMgr_Data.CurrSyncFrmId);
               if (EyeQProtMgr_Data.CurrSyncFrmId != EyeQProtMgr_Data.ExpectedNextSyncFrmId)
               {
                  if (FALSE != EyeQProtMgr_Data.FirstFrmRateFinished)
                  {
                     EyeQProtMgr_Data.FrmRateStatus |= EYEQPROTMGR_E_STS_SYNC_FRM_ID;
                     msg_status |= EYEQPROTMGR_E_STS_SYNC_FRM_ID;
                  }
               }
            }
            else
            {
               /* TBD: for now, suppose current sync frame ID will be next one if RX failed */
               EyeQProtMgr_Data.CurrSyncFrmId = EyeQProtMgr_Data.ExpectedNextSyncFrmId;
            }
            EyeQProtMgr_Data.ExpectedNextSyncFrmId = EyeQProtMgr_Data.CurrSyncFrmId + 1u;

            /* Calculate times between 2 camera frames */
            if (FALSE != EyeQProtMgr_Data.FirstFrmRateFinished)
            {
               EyeQProtMgr_Data.FrmRateMsgTimeSum += EyeQProtMgr_Data.FrmRateMsgTimer;
               EyeQProtMgr_Data.FrmRateMsgTimeSumCnt++;
               if (EYEQPROTMGR_FRAME_RATE_AVG_SUM_NUM <= EyeQProtMgr_Data.FrmRateMsgTimeSumCnt)
               {
                  EyeQProtMgr_Data.FrmRateMsgTimeAvg = (uint8)(EyeQProtMgr_Data.FrmRateMsgTimeSum / EyeQProtMgr_Data.FrmRateMsgTimeSumCnt);
                  EyeQProtMgr_Data.FrmRateMsgTimeSum = 0u;
                  EyeQProtMgr_Data.FrmRateMsgTimeSumCnt = 0u;
                  if (EYEQPROTMGR_FRAME_RATE_CNT_MAX < EyeQProtMgr_Data.FrmRateMsgTimeAvg)
                  {
                     /* Todo: TBD: what if frame rate avg received timing longer than limit for a while? Reset EQ? */
                     /* Todo: TBD: How about received too quick/frequent? */
                     Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_FRM_TIMING_FLT, DEM_EVENT_STATUS_PREFAILED);
                  }
                  else
                  {           
                     Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_FRM_TIMING_FLT, DEM_EVENT_STATUS_PREPASSED);
                  }
               }
               if (EyeQProtMgr_Data.FrmRateMsgTimer > EyeQProtMgr_Data.FrmRateMsgTimeMax)
               {
                  EyeQProtMgr_Data.FrmRateMsgTimeMax = EyeQProtMgr_Data.FrmRateMsgTimer;
               }
               else if (EyeQProtMgr_Data.FrmRateMsgTimer < EyeQProtMgr_Data.FrmRateMsgTimeMin)
               {
                  EyeQProtMgr_Data.FrmRateMsgTimeMin = EyeQProtMgr_Data.FrmRateMsgTimer;
               }
               else
               {
                  //Do nothing
               }
               
               /* Check if last App msg not received */
               if ((1u << EYEQPROTMGR_FRM_RATE_MSG_CMM) != EyeQProtMgr_Data.FrmRateMsgRcvdSts)
               {
                  EyeQProtMgr_Data.FrmRateErrorNumThisCycle++;
                  EyeQProtMgr_Data.FrmRateTotalErrorCnt++;
                  (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_FRM_MSG_MISSING, TRUE);
               }
               /* Check if last frame rate messages are all correct received */
               else if ((0u != EyeQProtMgr_Data.LastFrmRateStatus) 
                  || (EYEQPROTMGR_ALL_FRM_RATE_MSG_RCVD_MASK 
                     != (EyeQProtMgr_Data.LastFrmRateMsgRcvdSts 
                        & EYEQPROTMGR_ALL_FRM_RATE_MSG_RCVD_MASK)))
               {
                  EyeQProtMgr_Data.FrmRateErrorNumThisCycle++;
                  EyeQProtMgr_Data.FrmRateTotalErrorCnt++;
               }
               else
               {
                  /* Do nothing */
               }
               EyeQProtMgr_Data.FrmRateNumThisCycle++;
               EyeQProtMgr_Data.FrmRateTotalCnt++;

               /* Check if error rate is below limit */
               if (EYEQPROTMGR_FRAME_RATE_ERROR_SUM_NUM <= EyeQProtMgr_Data.FrmRateNumThisCycle)
               {
                  if (EYEQPROTMGR_FRAME_RATE_ERROR_SUM_MAX <= EyeQProtMgr_Data.FrmRateErrorNumThisCycle)
                  {
                     Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_FRM_ERR_FLT, DEM_EVENT_STATUS_PREFAILED);
                     /* Todo: TBD: what if frame rate error ratio bigger than limit? Reset EQ? */
                  }
                  else if (0u == EyeQProtMgr_Data.FrmRateErrorNumThisCycle)
                  {
                     Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_FRM_ERR_FLT, DEM_EVENT_STATUS_PREPASSED);
                  }
                  else
                  {
                     /* Do nothing */
                  }

                  if (EyeQProtMgr_Data.FrmRateErrorNumThisCycle > EyeQProtMgr_Data.FrmRateErrorNumThisCycleMax)
                  {
                     EyeQProtMgr_Data.FrmRateErrorNumThisCycleMax = EyeQProtMgr_Data.FrmRateErrorNumThisCycle;
                  }
                  EyeQProtMgr_Data.FrmRateNumThisCycle = 0u;
                  EyeQProtMgr_Data.FrmRateErrorNumThisCycle = 0u;
               }
            }

            /* Reset timer to start again for new cycle */
            EyeQProtMgr_Data.FrmRateMsgTimer = 0u;
         }
         /* If the last message of the camera frame per frame rate */
         else if (EYEQPROTMGR_FRM_RATE_MSG_APP == Msg)
         {
            if (FALSE != EyeQProtMgr_Data.NewFrmRateStarted)
            {
               EyeQProtMgr_Data.NewFrmRateStarted = FALSE;
               if (EYEQPROTMGR_ALL_FRM_RATE_MSG_RCVD_MASK == (EyeQProtMgr_Data.FrmRateMsgRcvdSts & EYEQPROTMGR_ALL_FRM_RATE_MSG_RCVD_MASK))
               {
                  /* All required messages received for the frame, need to update frame data to upper users */
                  publish = TRUE;
                  if (FALSE == EyeQProtMgr_Data.FirstFrmRateFinished)
                  {
                     if (((1u << EYEQPROTMGR_FRM_RATE_MSG_APP) == EyeQProtMgr_FrmRateSts.FrmMsgInvalidFlags) && (0u == msg_status))
                     {
                        EyeQProtMgr_Data.FirstFrmRateFinished = TRUE;
                     }
                  }
                  (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_FRM_MSG_MISSING, FALSE);
               }
               else
               {
                  if (FALSE != EyeQProtMgr_Data.FirstFrmRateFinished)
                  {
                     EyeQProtMgr_Data.FrmRateStatus |= EYEQPROTMGR_E_STS_MSG_RX_FLT;
                     msg_status |= EYEQPROTMGR_E_STS_MSG_RX_FLT;
                     (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_FRM_MSG_MISSING, TRUE);
                     /* TODO: zke: what if not all messages are valid? Still publish all or only valid or discard total? Temp still publish */
                     publish = TRUE;
                  }
               }

               EyeQProtMgr_Data.FrmRateMsgAppRxTime = EyeQProtMgr_Data.FrmRateMsgTimer;
               EyeQProtMgr_Data.LastFrmRateMsgRcvdSts = EyeQProtMgr_Data.FrmRateMsgRcvdSts;
               EyeQProtMgr_Data.LastFrmRateStatus = EyeQProtMgr_Data.FrmRateStatus;
               if (FALSE != EyeQProtMgr_Data.FirstFrmRateFinished)
               {
                  EyeQProtMgr_Data.HistoryStatus |= EyeQProtMgr_Data.FrmRateStatus;
               }
               EyeQProtMgr_Data.FrmRateMsgRcvdSts = 0u;
               clear_frm_status = TRUE;
               /* Todo: zke: Handle above status, report DEM or take actions. */
               EyeQProtMgr_Data.FrmRateDataReady = TRUE;

               EyeQProtMgr_FrmRateSts.FrameSyncId = EyeQProtMgr_Data.CurrSyncFrmId;
               EyeQProtMgr_FrmRateSts.FrmStatus = EyeQProtMgr_Data.LastFrmRateStatus;
               EyeQProtMgr_FrmRateSts.NewFrameDataReady = TRUE;
               EyeQStMgr_NotifySCFMNewFrm();
            }
            else
            {
               if (FALSE != EyeQProtMgr_Data.FirstFrmRateFinished)
               {
                  /* Shall not receive App messages other than common msg when NewFrmRateStarted == FALSE */
                  EyeQProtMgr_Data.FrmRateStatus |= EYEQPROTMGR_E_STS_CONDITION_INVALID;
                  msg_status |= EYEQPROTMGR_E_STS_CONDITION_INVALID;
                  EyeQProtMgr_Data.FrmRateMsgRcvdSts = 0u;
               }
            }
         }
         else
         {
            if (FALSE != EyeQProtMgr_Data.FrmRateDataReady)
            {
               /* Shall not receive any messages other than common msg when FrmRateDataReady == TRUE */
               EyeQProtMgr_Data.FrmRateStatus |= EYEQPROTMGR_E_STS_CONDITION_INVALID;
               msg_status |= EYEQPROTMGR_E_STS_CONDITION_INVALID;
               EyeQProtMgr_Data.FrmRateMsgRcvdSts = 0u;
            }
            /* TODO: zke: for other messages, TBD what to do */
         }

         EyeQProtMgr_FrmRateSts.MsgStatus[Msg] = msg_status;
         if (0u == msg_status)
         {
            EyeQProtMgr_FrmRateSts.FrmMsgInvalidFlags &= ~(1u << Msg);
         }
         if (FALSE != publish)
         {
            eyeqprotmgr_PublishFrameData();
         }
      }
      else /* FALSE == EyeQProtMgr_Data.VisionFrmRateActive */
      {
         /* TODO: zke: not in vision mode, TBD */
      }
   }
   else /* (Msg < EYEQPROTMGR_FRM_RATE_MSG_NUM) && (RxSts < EYEQPROTMGR_MSG_RX_STS_NUM) */
   {
      EyeQProtMgr_Data.FrmRateStatus |= EYEQPROTMGR_E_STS_CONDITION_INVALID;
   }

   /* Handles FrmRateStatus */
   if (FALSE != clear_frm_status)
   {
      if ((FALSE != EyeQProtMgr_Data.FirstFrmRateFinished))
      {
         if (0u == EyeQProtMgr_Data.FrmRateStatus)
         {
            (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_FRM_MSG_RFC, FALSE);
            Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_FRM_SYNC_ID_FLT, DEM_EVENT_STATUS_PREPASSED);
            (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_FRM_MSG_CRC, FALSE);
            Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_FRM_CRC_FLT, DEM_EVENT_STATUS_PREPASSED);
            Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_FRM_DATA_FLT, DEM_EVENT_STATUS_PREPASSED);
            Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_FRM_CONDITION_FLT, DEM_EVENT_STATUS_PREPASSED);
            Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_FRM_RX_FLT, DEM_EVENT_STATUS_PREPASSED);
         }
         else
         {
            if (0u == (EyeQProtMgr_Data.FrmRateStatus & EYEQPROTMGR_E_STS_SYNC_FRM_ID))
            {
               (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_FRM_MSG_RFC, FALSE);
               Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_FRM_SYNC_ID_FLT, DEM_EVENT_STATUS_PREPASSED);
            }
            else
            {
               (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_FRM_MSG_RFC, TRUE);
               Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_FRM_SYNC_ID_FLT, DEM_EVENT_STATUS_PREFAILED);
            }

            if (0u == (EyeQProtMgr_Data.FrmRateStatus & EYEQPROTMGR_E_STS_CRC))
            {
               (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_FRM_MSG_CRC, FALSE);
               Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_FRM_CRC_FLT, DEM_EVENT_STATUS_PREPASSED);
            }
            else
            {
               (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_FRM_MSG_CRC, TRUE);
               Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_FRM_CRC_FLT, DEM_EVENT_STATUS_PREFAILED);
            }

            if (0u == (EyeQProtMgr_Data.FrmRateStatus & EYEQPROTMGR_E_STS_DATA_INVALID))
            {
               Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_FRM_DATA_FLT, DEM_EVENT_STATUS_PREPASSED);
            }
            else
            {
               Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_FRM_DATA_FLT, DEM_EVENT_STATUS_PREFAILED);
            }

            if (0u == (EyeQProtMgr_Data.FrmRateStatus & EYEQPROTMGR_E_STS_CONDITION_INVALID))
            {
               Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_FRM_CONDITION_FLT, DEM_EVENT_STATUS_PREPASSED);
            }
            else
            {
               Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_FRM_CONDITION_FLT, DEM_EVENT_STATUS_PREFAILED);
            }

            if (0u == (EyeQProtMgr_Data.FrmRateStatus & EYEQPROTMGR_E_STS_MSG_RX_FLT))
            {
               Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_FRM_RX_FLT, DEM_EVENT_STATUS_PREPASSED);
            }
            else
            {
               Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_FRM_RX_FLT, DEM_EVENT_STATUS_PREFAILED);
            }
         }
      }
      EyeQProtMgr_Data.FrmRateStatus = 0u;
   }
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQProtMgr_CODE) EyeQProtMgr_NotifyMsgRxSts(CONST(EyeQProtMgr_MsgType, AUTOMATIC) Msg, CONST(EyeQProtMgr_MsgRxStsType, AUTOMATIC) RxSts)
{
   if ((Msg < EYEQPROTMGR_MSG_NUM) && (RxSts < EYEQPROTMGR_MSG_RX_STS_NUM))
   {
      switch (RxSts)
      {
         case EYEQPROTMGR_MSG_RX_STS_OK:
         {
            switch (Msg)
            {
               case EYEQPROTMGR_MSG_BOOT_DIAG:
               {
                  /* TODO: zke: implement things need to do for boot diag message */
                  break;
               }
               default:
               {
                  break;
               }
            }
            break;
         }
         case EYEQPROTMGR_MSG_RX_STS_NOT_OK:
         {
            EyeQProtMgr_Data.Status |= EYEQPROTMGR_E_STS_MSG_RX_FLT;
            break;
         }
         case EYEQPROTMGR_MSG_RX_STS_CRC_FAIL:
         {
            EyeQProtMgr_Data.Status |= EYEQPROTMGR_E_STS_CRC;
            break;
         }
         case EYEQPROTMGR_MSG_RX_STS_SYNC_ID_ERR:
         {
            EyeQProtMgr_Data.Status |= EYEQPROTMGR_E_STS_SYNC_FRM_ID;
            break;
         }
         case EYEQPROTMGR_MSG_RX_STS_DATA_NOT_MATCH:
         {
            EyeQProtMgr_Data.Status |= EYEQPROTMGR_E_STS_DATA_INVALID;
            break;
         }
         default:
         {
            EyeQProtMgr_Data.Status |= EYEQPROTMGR_E_STS_CONDITION_INVALID;
            break;
         }
      }
   }
   else /* (Msg < EYEQPROTMGR_FRM_RATE_MSG_NUM) && (RxSts < EYEQPROTMGR_MSG_RX_STS_NUM) */
   {
      EyeQProtMgr_Data.Status |= EYEQPROTMGR_E_STS_CONDITION_INVALID;
   }

   if (0u == (EyeQProtMgr_Data.Status & EYEQPROTMGR_E_STS_CRC))
   {
      Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_CRC_FLT, DEM_EVENT_STATUS_PREPASSED);
   }
   else
   {
      Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_CRC_FLT, DEM_EVENT_STATUS_PREFAILED);
   }

   if (0u == (EyeQProtMgr_Data.Status & EYEQPROTMGR_E_STS_DATA_INVALID))
   {
      Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_DATA_FLT, DEM_EVENT_STATUS_PREPASSED);
   }
   else
   {
      Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_DATA_FLT, DEM_EVENT_STATUS_PREFAILED);
   }

   if (0u == (EyeQProtMgr_Data.Status & EYEQPROTMGR_E_STS_CONDITION_INVALID))
   {
      Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_CONDITION_FLT, DEM_EVENT_STATUS_PREPASSED);
   }
   else
   {
      Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_CONDITION_FLT, DEM_EVENT_STATUS_PREFAILED);
   }

   if (0u == (EyeQProtMgr_Data.Status & EYEQPROTMGR_E_STS_MSG_RX_FLT))
   {
      Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_RX_FLT, DEM_EVENT_STATUS_PREPASSED);
   }
   else
   {
      Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_RX_FLT, DEM_EVENT_STATUS_PREFAILED);
   }

   if (0u == (EyeQProtMgr_Data.Status & EYEQPROTMGR_E_STS_SYNC_FRM_ID))
   {
      Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_SYNC_ID_FLT, DEM_EVENT_STATUS_PREPASSED);
   }
   else
   {
      Dem_ReportErrorStatus(DemConf_DemEventParameter_EYEQPROTMGR_E_SYNC_ID_FLT, DEM_EVENT_STATUS_PREFAILED);
   }
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQProtMgr_CODE) EyeQProtMgr_VisionFrameRateActive(CONST(boolean, AUTOMATIC) Active)
{
   /* TODO: TBD: zke: if need to init sync frame ID? */
   if (EyeQProtMgr_Data.VisionFrmRateActive != Active)
   {
      EyeQProtMgr_Data.FrmRateMsgTimer = 0u;
      EyeQProtMgr_Data.FrmRateMsgTimeSum = 0u;
      EyeQProtMgr_Data.FrmRateMsgTimeSumCnt = 0u;
      EyeQProtMgr_Data.FirstFrmRateFinished = FALSE;
      EyeQProtMgr_Data.FrmRateMsgAppRxTime = 0u;
   }
   EyeQProtMgr_Data.VisionFrmRateActive = Active;
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(uint8, EyeQProtMgr_CODE) EyeQProtMgr_GetCurrSyncFrmId(void)
{
   return (EyeQProtMgr_Data.CurrSyncFrmId);
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(uint8, EyeQProtMgr_CODE) EyeQProtMgr_GetExpectedNextSyncFrmId(void)
{
   return (EyeQProtMgr_Data.ExpectedNextSyncFrmId);
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQProtMgr_CODE) EyeQProtMgr_GetFrmRateSts(CONSTP2VAR(EyeQProtMgr_FrmRateStsType, AUTOMATIC, EyeQProtMgr_APPL_DATA) DstPtr)
{
   if (NULL_PTR != DstPtr)
   {
      *DstPtr = EyeQProtMgr_FrmRateSts;
   }
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(boolean, EyeQProtMgr_CODE) EyeQProtMgr_IsFirstFrameRateFinished(void)
{
   return (EyeQProtMgr_Data.FirstFrmRateFinished);
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQProtMgr_CODE) EyeQProtMgr_PrepareShutdown(void)
{
   uint8 loop = sizeof(Rte_ArPim_MemorySWC_PIM_EyeQProtMgr_VisionMsgNvMData);
   uint8* new_ptr = (uint8*)(&Rte_ArPim_MemorySWC_PIM_EyeQProtMgr_VisionMsgNvMData);
   uint8* old_ptr = (uint8*)(&EyeQProtMgr_VisionMsgNvMData);
   uint8_least data_index = 0u;
   boolean is_diff = FALSE;

   while ((data_index < loop) && (FALSE == is_diff))
   {
      if (*new_ptr != *old_ptr)
      {
         is_diff = TRUE;
      }
      old_ptr++;
      new_ptr++;
      data_index++;
   }

   if (FALSE != is_diff)
   {
      NvM_SetRamBlockStatus(NvMConf_NvMBlockDescriptor_EyeQProtMgr_VisionMsgNvMData, TRUE);
      EyeQProtMgr_VisionMsgNvMData = Rte_ArPim_MemorySWC_PIM_EyeQProtMgr_VisionMsgNvMData;
   }

   loop = sizeof(Rte_ArPim_MemorySWC_PIM_EyeQProtMgr_CalSPCNvMData);
   new_ptr = (uint8*)(&Rte_ArPim_MemorySWC_PIM_EyeQProtMgr_CalSPCNvMData);
   old_ptr = (uint8*)(&EyeQProtMgr_CalSPCNvMData);
   data_index = 0u;
   is_diff = FALSE;

   while ((data_index < loop) && (FALSE == is_diff))
   {
      if (*new_ptr != *old_ptr)
      {
         is_diff = TRUE;
      }
      old_ptr++;
      new_ptr++;
      data_index++;
   }

   if (FALSE != is_diff)
   {
      NvM_SetRamBlockStatus(NvMConf_NvMBlockDescriptor_NvM_EyeQProtMgr_CalSPCNvMData, TRUE);
      EyeQProtMgr_CalSPCNvMData = Rte_ArPim_MemorySWC_PIM_EyeQProtMgr_CalSPCNvMData;
   }
}

#define EyeQProtMgr_STOP_SEC_CODE
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
End Of File
******************************************************************************/
