
/******************************************************************************

WBTL ELECTRONIC document

Copyright WBTL. All rights reserved.

******************************************************************************/
/******************************************************************************

@details
   <Describes details of this component implementation and design>

******************************************************************************/
/******************************************************************************
External Dependencies
******************************************************************************/
#include <EyeQProtMgr.h>
#include <EyeQProtMgr_Cfg.h>
#include <EyeQProtMgr_Intl.h>
#include <EyeQProtMgr_CoreSafDiagSrv.h>
#include <Crc.h>
#include <SysMgr.h>
#include <EyeQStMgr.h>

/******************************************************************************
Component Defines
******************************************************************************/
#define EYEQPROTMGR_SD_CRC_OFFSET        (4u)
#define EYEQPROTMGR_SD_CRC_DATA_OFFSET   (8u)
#define EYEQPROTMGR_SD_CRC_START_VAL     (0xffffffffu)
                                         
#define EYEQPROTMGR_SD_PROT_VERSION      (0x02u)
                                         
#define EYEQPROTMGR_CR_PAIR_NUM          (10u)
                                         
#define EYEQPROTMGR_REPEAT_NUM           (6u)
#define EYEQPROTMGR_CR_ZERO_NUM          (8u)
#define EYEQPROTMGR_ZERO                 (0u)
#define EYEQPROTMGR_NINE                 (9u)

/* SD bits start from after header which is 16bytes and equals 4 offset of 64 bits */
#define EYEQPROTMGR_SDBIT_START_OFFSET_64          (4u)

/******************************************************************************
Component Types
******************************************************************************/
/*!
 * @brief SafeDiag C&R states
 * @param enum
 * @{
 */
#define EYEQPROTMGR_SD_ST_CHK_ZERO         (0u)
#define EYEQPROTMGR_SD_ST_NORMAL           (1u)
#define EYEQPROTMGR_SD_ST_FLT_SAFE         (2u)
#define EYEQPROTMGR_SD_ST_NUM              (3u)
typedef VAR(uint8, TYPEDEF) EyeQProtMgr_StType;
/*! @} */


typedef struct eyeqprotmgr_ChlgRspDataTypeTag
{
   EyeQProtMgr_StType CurrentState;
   uint8 PreviousChlgIdentifier;
   uint8 ChlgRspCounter;
}eyeqprotmgr_ChlgRspDataType;

typedef VAR(uint8, TYPEDEF) eyeqprotmgr_ResponseType;

/******************************************************************************
Declaration of Local Functions
******************************************************************************/
LOCAL FUNC(void, EyeQProtMgr_CODE) eyeqprotmgr_ChallengeResponse(uint8 Challenge_Identifier);
LOCAL FUNC(void, EyeQProtMgr_CODE) eyeqprotmgr_CheckZeros(uint8 Challenge_Identifier);

#define EyeQProtMgr_START_SEC_VAR
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
Definition Of Local Variables
******************************************************************************/
LOCAL VAR(eyeqprotmgr_ChlgRspDataType, EyeQStMgr_VAR) eyeqprotmgr_ChlgRspData;
/******************************************************************************
Definition Of Global Variables
******************************************************************************/
VAR(uint32, EyeQProtMgr_VAR) EyeQProtMgr_CoreSafDiagSrvRespLength;

#define EyeQProtMgr_STOP_SEC_VAR
#include "EyeQProtMgr_MemMap.h"

#define EyeQProtMgr_START_SEC_CONST
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
Definition Of Local Constant Data
******************************************************************************/
LOCAL CONST(eyeqprotmgr_ResponseType, EyeQProtMgr_CONST) eyeqprotmgr_Response[EYEQPROTMGR_CR_PAIR_NUM] = {
   27u,
   31u,
   13u,
   9u,
   12u,
   6u,
   71u,
   44u,
   22u,
   17u
};
/******************************************************************************
Definition Of Global Constant Data
******************************************************************************/

#define EyeQProtMgr_STOP_SEC_CONST
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
Component Function-like Macros
******************************************************************************/

/******************************************************************************
Definition Of APIs
******************************************************************************/
#define EyeQProtMgr_START_SEC_CODE
#include "EyeQProtMgr_MemMap.h"

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQProtMgr_CODE) EyeQProtMgr_CoreSafDiagSrvCallback(CONST(EyeQAppl_CallbackStsType, AUTOMATIC) Status)
{
   uint64 scfm_flags;
   uint64* sd_bits_ptr;
   uint32 computed_crc;
   uint32 rx_crc;
   uint8* crc_data_ptr = (uint8*)&EYEQMSG_CORESAFDIAG_Params_s;
   uint8 expected_sync_id;
   uint8 sync_id;
   uint8 challenge_identifier;

   crc_data_ptr += EYEQPROTMGR_SD_CRC_DATA_OFFSET;

   switch (Status)
   {
      case EYEQAPPL_CB_STS_RX_OK:
      {
         if (C_EYEQMSG_CORESAFDIAG_MSG_LEN == EyeQProtMgr_CoreSafDiagSrvRespLength)
         {
            if (EYEQPROTMGR_SD_PROT_VERSION == EYEQMSG_CORESAFDIAG_Params_s.SD_Protocol_Version_b8)
            {
               /* Check CRC */
               computed_crc = Crc_CalculateCRC32(crc_data_ptr, (C_EYEQMSG_CORESAFDIAG_MSG_LEN - EYEQPROTMGR_SD_CRC_DATA_OFFSET), EYEQPROTMGR_SD_CRC_START_VAL, TRUE);
               rx_crc = (uint32)EYEQMSG_CORESAFDIAG_Params_s.SD_CRC_b32;
               if (computed_crc == rx_crc)
               {
                  EYEQMSG_CORESAFDIAG_ParamsApp_s = EYEQMSG_CORESAFDIAG_Params_s;
                  expected_sync_id = EyeQProtMgr_GetCurrSyncFrmId();
                  (void)EYEQMSG_Get_CORESAFDIAG_SD_Sync_ID(&sync_id);
                  if (expected_sync_id == sync_id)
                  {
                     EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_SAF_DIAG, EYEQPROTMGR_MSG_RX_STS_OK);
                     EYEQMSG_Get_CORESAFDIAG_SD_Challenge_Identifier(&challenge_identifier);
                     switch (eyeqprotmgr_ChlgRspData.CurrentState)
                     {
                        case EYEQPROTMGR_SD_ST_CHK_ZERO:
                        {
                           eyeqprotmgr_CheckZeros(challenge_identifier);
                           break;
                        }
                        case EYEQPROTMGR_SD_ST_NORMAL:
                        {
                           if (eyeqprotmgr_ChlgRspData.PreviousChlgIdentifier != challenge_identifier)
                           {
                              eyeqprotmgr_ChallengeResponse(challenge_identifier);
                              eyeqprotmgr_ChlgRspData.PreviousChlgIdentifier = challenge_identifier;
                              eyeqprotmgr_ChlgRspData.ChlgRspCounter = 0u;
                           }
                           else
                           {
                              eyeqprotmgr_ChlgRspData.ChlgRspCounter++;
                              if(EYEQPROTMGR_REPEAT_NUM < eyeqprotmgr_ChlgRspData.ChlgRspCounter)
                              {
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_C_AND_R_TI_OUT, TRUE);
                              }
                           }

                           sd_bits_ptr = (uint64*)&EYEQMSG_CORESAFDIAG_ParamsApp_s;
                           if (0u != sd_bits_ptr[EYEQPROTMGR_SDBIT_START_OFFSET_64])
                           {
                              if (1u == EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_18_b1)
                              {
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM18, TRUE);
                              }

                              if (1u == EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_21_b1)
                              {
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM21, TRUE);
                              }

                              if (1u == EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_24_b1)
                              {
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM24, TRUE);
                              }

                              if (1u == EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_25_b1)
                              {
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM25, TRUE);
                              }

                              if (1u == EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_26_b1)
                              {
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM26, TRUE);
                              }

                              if (1u == EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_27_b1)
                              {
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM27, TRUE);
                              }

                              if (1u == EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_30_b1)
                              {
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM30, TRUE);
                              }

                              if (1u == EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_31_b1)
                              {
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM31, TRUE);
                              }

                              if (1u == EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_34_b1)
                              {
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM34, TRUE);
                              }

                              if (1u == EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_35_b1)
                              {
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM35, TRUE);
                              }

                              if (1u == EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_37_b1)
                              {
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM37, TRUE);
                              }

                              if (1u == EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_38_b1)
                              {
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM38, TRUE);
                              }

                              if (1u == EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_4_b1)
                              {
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM4, TRUE);
                              }

                              if (1u == EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_40_b1)
                              {
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM40, TRUE);
                              }

                              if (1u == EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_44_b1)
                              {
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM44, TRUE);
                              }

                              if (1u == EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_45_b1)
                              {
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM45, TRUE);
                              }

                              if (1u == EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_49_b1)
                              {
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM49, TRUE);
                              }

                              if (1u == EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_50_b1)
                              {
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM50, TRUE);
                              }

                              if (1u == EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_54_b1)
                              {
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM54, TRUE);
                              }

                              if (1u == EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_6_b1)
                              {
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM6, TRUE);
                              }

                              if (1u == EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_7_b1)
                              {
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM7, TRUE);
                              }

                              if (1u == EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_9_b1)
                              {
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM9, TRUE);
                              }

                              if (1u == EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_11_b1)
                              {
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM11, TRUE);
                              }

                              if (1u == EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_13_b1)
                              {
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM13, TRUE);
                              }

                              if (1u == EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_29_b1)
                              {
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM29, TRUE);
                              }

                              if (1u == EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_33_b1)
                              {
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM33, TRUE);
                              }

                              if (1u == EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_36_b1)
                              {
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM36, TRUE);
                              }

                              if (1u == EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_39_b1)
                              {
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM39, TRUE);
                              }

                              if (1u == EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_42_b1)
                              {
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM42, TRUE);
                              }

                              if (1u == EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_48_b1)
                              {
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM48, TRUE);
                              }

                              if (1u == EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_51_b1)
                              {
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM51, TRUE);
                              }

                              if (1u == EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_52_b1)
                              {
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM52, TRUE);
                              }

                              if (1u == EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_55_b1)
                              {
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM55, TRUE);
                              }

                              if (1u == EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_56_b1)
                              {
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM56, TRUE);
                              }
                           }
                           else
                           {
                              /* Report no fault to each SDM to clear SCFM active flags if any */
                              scfm_flags = EyeQStMgr_GetSCFMActiveFlags();
                              if (0u != scfm_flags)
                              {
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM18, FALSE);
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM21, FALSE);
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM24, FALSE);
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM25, FALSE);
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM26, FALSE);
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM27, FALSE);
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM30, FALSE);
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM31, FALSE);
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM34, FALSE);
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM35, FALSE);
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM37, FALSE);
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM38, FALSE);
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM4 , FALSE);
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM40, FALSE);
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM44, FALSE);
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM45, FALSE);
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM49, FALSE);
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM50, FALSE);
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM54, FALSE);
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM6 , FALSE);
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM7 , FALSE);
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM9 , FALSE);
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM11, FALSE);
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM13, FALSE);
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM29, FALSE);
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM33, FALSE);
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM36, FALSE);
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM39, FALSE);
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM42, FALSE);
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM48, FALSE);
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM51, FALSE);
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM52, FALSE);
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM55, FALSE);
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_SDM56, FALSE);
                              }
                           }
                           break;
                        }
                        case EYEQPROTMGR_SD_ST_FLT_SAFE:
                        {
                           if (eyeqprotmgr_ChlgRspData.PreviousChlgIdentifier != challenge_identifier)
                           {
                              eyeqprotmgr_ChallengeResponse(challenge_identifier);
                              eyeqprotmgr_ChlgRspData.PreviousChlgIdentifier = challenge_identifier;
                              eyeqprotmgr_ChlgRspData.ChlgRspCounter = 0u;
                           }
                           else
                           {
                              eyeqprotmgr_ChlgRspData.ChlgRspCounter++;
                              if(EYEQPROTMGR_REPEAT_NUM < eyeqprotmgr_ChlgRspData.ChlgRspCounter)
                              {
                                 (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_C_AND_R_TI_OUT, TRUE);
                              }
                           }
                           break;
                        }
                        default:
                        {
                           break;
                        }
                     }
                  }
                  else
                  {
                     EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_SAF_DIAG, EYEQPROTMGR_MSG_RX_STS_SYNC_ID_ERR);
                  }
               }
               else
               {
                  EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_SAF_DIAG, EYEQPROTMGR_MSG_RX_STS_CRC_FAIL);
               }
            }
            else
            {
               EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_SAF_DIAG, EYEQPROTMGR_MSG_RX_STS_DATA_NOT_MATCH);
            }
         }
         else
         {
            EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_SAF_DIAG, EYEQPROTMGR_MSG_RX_STS_NOT_OK);
         }
         break;
      }
      case EYEQAPPL_CB_STS_RX_DG_UNAVAL:
      {
         EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_SAF_DIAG, EYEQPROTMGR_MSG_RX_STS_DG_MSG_UNAVAL);
         break;
      }
      /* This msg is Rx only and single frame, so if status is Tx or rx_new_frame then something is wrong */
      case EYEQAPPL_CB_STS_RX_FAILED:
      case EYEQAPPL_CB_STS_TX_OK:
      case EYEQAPPL_CB_STS_TX_FAILED:
      case EYEQAPPL_CB_STS_RX_NEW_FRAME:
      default:
      {
         EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_SAF_DIAG, EYEQPROTMGR_MSG_RX_STS_NOT_OK);
         break;
      }
   }
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQProtMgr_CODE) eyeqprotmgr_ChallengeResponse(uint8 Challenge_Identifier)
{
   uint8 Challenge_Response1;
   uint8 Challenge_Response2;
   uint8 Challenge_Response3;
   uint8 Challenge_Response4;
   uint8 expected_Response;


   /* Challenge response */

   EYEQMSG_Get_CORESAFDIAG_SD_Challenge_Response1(&Challenge_Response1);
   EYEQMSG_Get_CORESAFDIAG_SD_Challenge_Response2(&Challenge_Response2);
   EYEQMSG_Get_CORESAFDIAG_SD_Challenge_Response3(&Challenge_Response3);
   EYEQMSG_Get_CORESAFDIAG_SD_Challenge_Response4(&Challenge_Response4);

   expected_Response = eyeqprotmgr_Response[Challenge_Identifier];

   if ((expected_Response == Challenge_Response1) && (expected_Response == Challenge_Response2)
      && (expected_Response == Challenge_Response3) && (expected_Response == Challenge_Response4))
   {      
      if (EYEQPROTMGR_SD_ST_FLT_SAFE == eyeqprotmgr_ChlgRspData.CurrentState)
      {
         eyeqprotmgr_ChlgRspData.CurrentState = EYEQPROTMGR_SD_ST_NORMAL;
         (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_C_AND_R_E, FALSE);
      }
   }
   else
   {
      eyeqprotmgr_ChlgRspData.CurrentState = EYEQPROTMGR_SD_ST_FLT_SAFE;
      (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_C_AND_R_E, TRUE);
   }
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQProtMgr_CODE) EyeQProtMgr_CoreSafDiagInit(void)
{
   eyeqprotmgr_ChlgRspData.ChlgRspCounter = 0u;
   /* Set previous Id to 9 so that the first rx id 0 will be treated as a new Id */
   eyeqprotmgr_ChlgRspData.PreviousChlgIdentifier = EYEQPROTMGR_NINE;
   eyeqprotmgr_ChlgRspData.CurrentState = EYEQPROTMGR_SD_ST_CHK_ZERO;
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQProtMgr_CODE) eyeqprotmgr_CheckZeros(uint8 Challenge_Identifier)
{
   uint8 Challenge_Response1;
   uint8 Challenge_Response2;
   uint8 Challenge_Response3;
   uint8 Challenge_Response4;

   /* Challenge response */

   EYEQMSG_Get_CORESAFDIAG_SD_Challenge_Response1(&Challenge_Response1);
   EYEQMSG_Get_CORESAFDIAG_SD_Challenge_Response2(&Challenge_Response2);
   EYEQMSG_Get_CORESAFDIAG_SD_Challenge_Response3(&Challenge_Response3);
   EYEQMSG_Get_CORESAFDIAG_SD_Challenge_Response4(&Challenge_Response4);
   if ((EYEQPROTMGR_ZERO == Challenge_Response1) && (EYEQPROTMGR_ZERO == Challenge_Response2)
      && (EYEQPROTMGR_ZERO == Challenge_Response3) && (EYEQPROTMGR_ZERO == Challenge_Response4)
      && (EYEQPROTMGR_ZERO == Challenge_Identifier))
   {
      eyeqprotmgr_ChlgRspData.ChlgRspCounter++;
      if (EYEQPROTMGR_CR_ZERO_NUM < eyeqprotmgr_ChlgRspData.ChlgRspCounter)
      {
         //eyeqprotmgr_ChlgRspData.CurrentState = EYEQPROTMGR_ST_SAFE;
         (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_C_AND_R_INIT, TRUE);

      }
   }
   else
   {
      eyeqprotmgr_ChlgRspData.CurrentState = EYEQPROTMGR_SD_ST_NORMAL;
      eyeqprotmgr_ChlgRspData.ChlgRspCounter = 0u;
      (void)EyeQStMgr_ReportSCFM(EYEQSTMGR_SCFM_ID_C_AND_R_INIT, FALSE);
   }
}

#define EyeQProtMgr_STOP_SEC_CODE
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
End Of File
******************************************************************************/
