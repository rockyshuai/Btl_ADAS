
/******************************************************************************

WBTL ELECTRONIC document

Copyright WBTL. All rights reserved.

******************************************************************************/
/******************************************************************************

@details
   <Describes details of this component implementation and design>

******************************************************************************/
/******************************************************************************
External Dependencies
******************************************************************************/
#include <EyeQProtMgr.h>
#include <EyeQProtMgr_Intl.h>
#include <EyeQProtMgr_CoreLaneHostSrv.h>
#include <Crc.h>

/******************************************************************************
Component Defines
******************************************************************************/
#define EYEQPROTMGR_LH_COMP_CRC_OFFSET        (4u)
#define EYEQPROTMGR_LH_COMP_CRC_DATA_OFFSET   (4u)
#define EYEQPROTMGR_LH_COMP_CRC_START_VAL     (0xffffffffu)

#define EYEQPROTMGR_LH_PROT_VERSION      (0x07u)

/******************************************************************************
Component Types
******************************************************************************/

/******************************************************************************
Declaration of Local Functions
******************************************************************************/

#define EyeQProtMgr_START_SEC_VAR
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
Definition Of Local Variables
******************************************************************************/

/******************************************************************************
Definition Of Global Variables
******************************************************************************/
VAR(uint32, EyeQProtMgr_VAR) EyeQProtMgr_CoreLaneHostSrvRespLength;

#define EyeQProtMgr_STOP_SEC_VAR
#include "EyeQProtMgr_MemMap.h"

#define EyeQProtMgr_START_SEC_CONST
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
Definition Of Local Constant Data
******************************************************************************/

/******************************************************************************
Definition Of Global Constant Data
******************************************************************************/

#define EyeQProtMgr_STOP_SEC_CONST
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
Component Function-like Macros
******************************************************************************/

/******************************************************************************
Definition Of APIs
******************************************************************************/
#define EyeQProtMgr_START_SEC_CODE
#include "EyeQProtMgr_MemMap.h"

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQProtMgr_CODE) EyeQProtMgr_CoreLaneHostSrvCallback(CONST(EyeQAppl_CallbackStsType, AUTOMATIC) Status)
{
   uint32 computed_crc;
   uint32 rx_crc;
   uint32 msg_length;
   uint8* crc_data_ptr = (uint8*)&EYEQMSG_CORELANEHOST_Params_s;
   uint8 expected_sync_id;
   uint8 sync_id;
   uint8 lane_idx;
   uint8 lane_count;
   boolean crc_fail = FALSE;

   switch (Status)
   {
      case EYEQAPPL_CB_STS_RX_OK:
      {
         lane_count = EYEQMSG_CORELANEHOST_Params_s.EYEQMSG_CORELANEHOSTvH_Params_s.LH_Lanes_Count_b3;
         msg_length = (uint32)(C_EYEQMSG_CORELANEHOSTvH_MSG_LEN 
            + (lane_count * C_EYEQMSG_CORELANEHOSTvO_MSG_LEN));
         if (msg_length == EyeQProtMgr_CoreLaneHostSrvRespLength)
         {
            if (EYEQPROTMGR_LH_PROT_VERSION == EYEQMSG_CORELANEHOST_Params_s.EYEQMSG_CORELANEHOSTvH_Params_s.LH_Protocol_Version_b8)
            {
               /* Check CRC */
               /* zke: Todo: fix it. Temp not check CRC base on test result that has no objects data received */
               for (lane_idx = 0u; lane_count > lane_idx; lane_idx++)
               {
                  crc_data_ptr = (uint8*)&EYEQMSG_CORELANEHOST_Params_s.EYEQMSG_CORELANEHOSTvO_Params_as[lane_idx];
                  crc_data_ptr += EYEQPROTMGR_LH_COMP_CRC_DATA_OFFSET;
                  computed_crc = Crc_CalculateCRC32(crc_data_ptr, (C_EYEQMSG_CORELANEHOSTvO_MSG_LEN - EYEQPROTMGR_LH_COMP_CRC_DATA_OFFSET), EYEQPROTMGR_LH_COMP_CRC_START_VAL, TRUE);
                  rx_crc = (uint32) (EYEQMSG_CORELANEHOST_Params_s.EYEQMSG_CORELANEHOSTvO_Params_as[lane_idx].LH_CRC_0_b32);
                  if (computed_crc != rx_crc)
                  {
                     crc_fail = TRUE;
                     lane_idx = lane_count;
                  }
               }
               if (crc_fail == FALSE)
               {
                  EYEQMSG_CORELANEHOST_ParamsApp_s = EYEQMSG_CORELANEHOST_Params_s;
                  expected_sync_id = EyeQProtMgr_GetCurrSyncFrmId();
                  (void)EYEQMSG_Get_CORELANEHOSTvH_LH_Sync_ID(&sync_id);
                  if (expected_sync_id == sync_id)
                  {
                     EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_LANE_HOST, EYEQPROTMGR_MSG_RX_STS_OK);
                  }
                  else
                  {
                     EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_LANE_HOST, EYEQPROTMGR_MSG_RX_STS_SYNC_ID_ERR);
                  }
               }
               else
               {
                  EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_LANE_HOST, EYEQPROTMGR_MSG_RX_STS_CRC_FAIL);
               }
            }
            else
            {
               EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_LANE_HOST, EYEQPROTMGR_MSG_RX_STS_DATA_NOT_MATCH);
            }
         }
         else
         {
            EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_LANE_HOST, EYEQPROTMGR_MSG_RX_STS_NOT_OK);
         }
         break;
      }
      case EYEQAPPL_CB_STS_RX_NEW_FRAME:
      {
         break;
      }
      case EYEQAPPL_CB_STS_RX_DG_UNAVAL:
      {
         EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_LANE_HOST, EYEQPROTMGR_MSG_RX_STS_DG_MSG_UNAVAL);
         break;
      }
      /* This msg is Rx only, so if status is Tx then something is wrong */
      case EYEQAPPL_CB_STS_RX_FAILED:
      case EYEQAPPL_CB_STS_TX_OK:
      case EYEQAPPL_CB_STS_TX_FAILED:
      default:
      {
         EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_LANE_HOST, EYEQPROTMGR_MSG_RX_STS_NOT_OK);
         break;
      }
   }
}

#define EyeQProtMgr_STOP_SEC_CODE
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
End Of File
******************************************************************************/
