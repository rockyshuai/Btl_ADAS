
/******************************************************************************

WBTL ELECTRONIC document

Copyright WBTL. All rights reserved.

******************************************************************************/
/******************************************************************************

@details
   <Describes details of this component implementation and design>

******************************************************************************/
/******************************************************************************
External Dependencies
******************************************************************************/
#include <EyeQProtMgr.h>
#include <EyeQProtMgr_Intl.h>
#include <EYEQMSG_CoreCalStaticProcess.h>
#include <Crc.h>

/******************************************************************************
Component Defines
******************************************************************************/
#define EYEQMSG_CORECALSTATIC_CRC_OFFSET        (4u)
#define EYEQMSG_CORECALSTATIC_CRC_DATA_OFFSET   (8u)
#define EYEQMSG_CORECALSTATIC_CRC_START_VAL     (0xffffffffu)

#define EYEQPROTMGR_CORECALSTATIC_PROT_VERSION  (0x04u)
/******************************************************************************
Component Types
******************************************************************************/

/******************************************************************************
Declaration of Local Functions
******************************************************************************/

#define EyeQProtMgr_START_SEC_VAR
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
Definition Of Local Variables
******************************************************************************/

/******************************************************************************
Definition Of Global Variables
******************************************************************************/
VAR(uint32, EyeQProtMgr_VAR) EyeQProtMgr_CoreCalStaticSrvRespLength;

#define EyeQProtMgr_STOP_SEC_VAR
#include "EyeQProtMgr_MemMap.h"

#define EyeQProtMgr_START_SEC_CONST
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
Definition Of Local Constant Data
******************************************************************************/

/******************************************************************************
Definition Of Global Constant Data
******************************************************************************/

#define EyeQProtMgr_STOP_SEC_CONST
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
Component Function-like Macros
******************************************************************************/

/******************************************************************************
Definition Of APIs
******************************************************************************/
#define EyeQProtMgr_START_SEC_CODE
#include "EyeQProtMgr_MemMap.h"

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQProtMgr_CODE) EyeQProtMgr_CoreCalStaticSrvCallback(CONST(EyeQAppl_CallbackStsType, AUTOMATIC) Status)
{
   uint32 computed_crc;
   uint32 rx_crc;
   uint8* crc_data_ptr = (uint8*)&EYEQMSG_CORECALSTATIC_Params_s;
   uint8 expected_sync_id;
   uint8 sync_id;

   crc_data_ptr += EYEQMSG_CORECALSTATIC_CRC_DATA_OFFSET;

   switch (Status)
   {
      case EYEQAPPL_CB_STS_RX_OK:
      {
         if (C_EYEQMSG_CORECALSTATIC_MSG_LEN == EyeQProtMgr_CoreCalStaticSrvRespLength)
         {
            if (EYEQPROTMGR_CORECALSTATIC_PROT_VERSION == EYEQMSG_CORECALSTATIC_Params_s.CLB_Stat_Protocol_Version_b8)
            {
               /* Check CRC */
               computed_crc = Crc_CalculateCRC32(crc_data_ptr, (C_EYEQMSG_CORECALSTATIC_MSG_LEN - EYEQMSG_CORECALSTATIC_CRC_DATA_OFFSET), EYEQMSG_CORECALSTATIC_CRC_START_VAL, TRUE);
               rx_crc = (uint32)EYEQMSG_CORECALSTATIC_Params_s.CLB_Stat_CRC_b32;
               if (computed_crc == rx_crc)
               {
                  EYEQMSG_CORECALSTATIC_ParamsApp_s = EYEQMSG_CORECALSTATIC_Params_s;
                  /* zke: TBD, Todo: confirm for CAL Static the sync ID update may not be from common msg */
                  expected_sync_id = EyeQProtMgr_GetCurrSyncFrmId();
                  (void)EYEQMSG_Get_CORECALSTATIC_CLB_Sync_ID(&sync_id);
                  if (expected_sync_id == sync_id)
                  {
                     EyeQProtMgr_NotifyMsgRxSts(EYEQPROTMGR_MSG_CAL_STATIC, EYEQPROTMGR_MSG_RX_STS_OK);

                  }
                  else
                  {
                     EyeQProtMgr_NotifyMsgRxSts(EYEQPROTMGR_MSG_CAL_STATIC, EYEQPROTMGR_MSG_RX_STS_SYNC_ID_ERR);
                  }
               }
               else
               {
                  EyeQProtMgr_NotifyMsgRxSts(EYEQPROTMGR_MSG_CAL_STATIC, EYEQPROTMGR_MSG_RX_STS_CRC_FAIL);
               }
            }
            else
            {
               EyeQProtMgr_NotifyMsgRxSts(EYEQPROTMGR_MSG_CAL_STATIC, EYEQPROTMGR_MSG_RX_STS_DATA_NOT_MATCH);
            }
         }
         else
         {
            EyeQProtMgr_NotifyMsgRxSts(EYEQPROTMGR_MSG_CAL_STATIC, EYEQPROTMGR_MSG_RX_STS_NOT_OK);
         }
         break;
      }
      case EYEQAPPL_CB_STS_RX_DG_UNAVAL:
      {
         EyeQProtMgr_NotifyMsgRxSts(EYEQPROTMGR_MSG_CAL_STATIC, EYEQPROTMGR_MSG_RX_STS_DG_MSG_UNAVAL);
         break;
      }
      /* This msg is Rx only and single frame, so if status is Tx or rx_new_frame then something is wrong */
      case EYEQAPPL_CB_STS_RX_FAILED:
      case EYEQAPPL_CB_STS_TX_OK:
      case EYEQAPPL_CB_STS_TX_FAILED:
      case EYEQAPPL_CB_STS_RX_NEW_FRAME:
      default:
      {
         EyeQProtMgr_NotifyMsgRxSts(EYEQPROTMGR_MSG_CAL_STATIC, EYEQPROTMGR_MSG_RX_STS_NOT_OK);
         break;
      }
   }
}

#define EyeQProtMgr_STOP_SEC_CODE
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
End Of File
******************************************************************************/
