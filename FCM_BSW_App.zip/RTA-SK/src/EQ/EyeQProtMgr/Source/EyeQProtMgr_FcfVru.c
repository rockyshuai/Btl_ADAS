
/******************************************************************************

WBTL ELECTRONIC document

Copyright WBTL. All rights reserved.

******************************************************************************/
/******************************************************************************

@details
   <Describes details of this component implementation and design>

******************************************************************************/
/******************************************************************************
External Dependencies
******************************************************************************/
#include <EyeQProtMgr.h>
#include <EyeQProtMgr_Intl.h>
#include <EyeQProtMgr_FcfVru.h>
#include <Crc.h>

/******************************************************************************
Component Defines
******************************************************************************/
#define EYEQPROTMGR_FCF_VRU_CRC_START_VAL               (0xffffffffu)

#define EYEQPROTMGR_FCF_VRU_COMP_CRC_DATA_OFFSET        (14u)
#define EYEQPROTMGR_FCF_VRU_COMP_CRC_DATA_LENGTH        (2u)
#define EYEQPROTMGR_FCF_VRU_COMP_CRC_DATA_CYCLE_LEN     (12u)
#define EYEQPROTMGR_FCF_VRU_COMP_CRC_DATA_CYCLE_NUM     (8u)

#define EYEQPROTMGR_FCF_VRU_PROT_VERSION                (0x06u)

/******************************************************************************
Component Types
******************************************************************************/

/******************************************************************************
Declaration of Local Functions
******************************************************************************/

#define EyeQProtMgr_START_SEC_VAR
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
Definition Of Local Variables
******************************************************************************/

/******************************************************************************
Definition Of Global Variables
******************************************************************************/
VAR(uint32, EyeQProtMgr_VAR) EyeQProtMgr_FcfVruRespLength;

#define EyeQProtMgr_STOP_SEC_VAR
#include "EyeQProtMgr_MemMap.h"

#define EyeQProtMgr_START_SEC_CONST
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
Definition Of Local Constant Data
******************************************************************************/

/******************************************************************************
Definition Of Global Constant Data
******************************************************************************/

#define EyeQProtMgr_STOP_SEC_CONST
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
Component Function-like Macros
******************************************************************************/

/******************************************************************************
Definition Of APIs
******************************************************************************/
#define EyeQProtMgr_START_SEC_CODE
#include "EyeQProtMgr_MemMap.h"

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQProtMgr_CODE) EyeQProtMgr_FcfVruCallback(CONST(EyeQAppl_CallbackStsType, AUTOMATIC) Status)
{
   uint32 crc_array[EYEQPROTMGR_FCF_VRU_COMP_CRC_DATA_CYCLE_NUM];
   uint32 computed_crc;
   uint8* crc_data_ptr = (uint8*)&EYEQMSG_COREFCFVRU_Params_s;
   uint8 expected_sync_id;
   uint8 sync_id;
   uint8 cyc_ind;
   boolean crc_fail;

   crc_fail = FALSE;

   switch (Status)
   {
      case EYEQAPPL_CB_STS_RX_OK:
      {
         if (C_EYEQMSG_COREFCFVRU_MSG_LEN == EyeQProtMgr_FcfVruRespLength)
         {
            if (EYEQPROTMGR_FCF_VRU_PROT_VERSION == EYEQMSG_COREFCFVRU_Params_s.FCF_VRU_Protocol_Version_b8)
            {
               crc_array[0] = EYEQMSG_COREFCFVRU_Params_s.FCF_VRU_CRC_L1_b32;
               crc_array[1] = EYEQMSG_COREFCFVRU_Params_s.FCF_VRU_CRC_L2_b32;
               crc_array[2] = EYEQMSG_COREFCFVRU_Params_s.FCF_VRU_CRC_L3_b32;
               crc_array[3] = EYEQMSG_COREFCFVRU_Params_s.FCF_VRU_CRC_L4_b32;
               crc_array[4] = EYEQMSG_COREFCFVRU_Params_s.FCF_VRU_CRC_L5_b32;
               crc_array[5] = EYEQMSG_COREFCFVRU_Params_s.FCF_VRU_CRC_L6_b32;
               crc_array[6] = EYEQMSG_COREFCFVRU_Params_s.FCF_VRU_CRC_L7_b32;
               crc_array[7] = EYEQMSG_COREFCFVRU_Params_s.FCF_VRU_CRC_L8_b32;

               crc_data_ptr += EYEQPROTMGR_FCF_VRU_COMP_CRC_DATA_OFFSET;

               /* Check CRC */
               for (cyc_ind = 0u; cyc_ind < EYEQPROTMGR_FCF_VRU_COMP_CRC_DATA_CYCLE_NUM; cyc_ind++)
               {
                  computed_crc = Crc_CalculateCRC32(crc_data_ptr, EYEQPROTMGR_FCF_VRU_COMP_CRC_DATA_LENGTH, EYEQPROTMGR_FCF_VRU_CRC_START_VAL, TRUE);

                  if (computed_crc != crc_array[cyc_ind])
                  {
                     crc_fail = TRUE;
                     /* End the for loop */
                     cyc_ind = EYEQPROTMGR_FCF_VRU_COMP_CRC_DATA_CYCLE_NUM;
                  }
                  crc_data_ptr = crc_data_ptr + EYEQPROTMGR_FCF_VRU_COMP_CRC_DATA_CYCLE_LEN;
               }
               if (crc_fail == FALSE)
               {
                  EYEQMSG_COREFCFVRU_ParamsApp_s = EYEQMSG_COREFCFVRU_Params_s;
                  expected_sync_id = EyeQProtMgr_GetCurrSyncFrmId();
                  (void)EYEQMSG_Get_COREFCFVRU_FCF_VRU_Sync_ID(&sync_id);
                  if (expected_sync_id == sync_id)
                  {
                     EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_FCF_VRU, EYEQPROTMGR_MSG_RX_STS_OK);
                  }
                  else
                  {
                     EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_FCF_VRU, EYEQPROTMGR_MSG_RX_STS_SYNC_ID_ERR);
                  }
                  //eyeqprotmgr_FcfVruRxProcess();
               }
               //else
               //{
               //   EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_FCF_VRU, EYEQPROTMGR_MSG_RX_STS_CRC_FAIL);
               //}
            }
            else
            {
               EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_FCF_VRU, EYEQPROTMGR_MSG_RX_STS_DATA_NOT_MATCH);
            }
         }
         else
         {
            EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_FCF_VRU, EYEQPROTMGR_MSG_RX_STS_NOT_OK);
         }
         break;
      }
      case EYEQAPPL_CB_STS_RX_DG_UNAVAL:
      {
         EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_FCF_VRU, EYEQPROTMGR_MSG_RX_STS_DG_MSG_UNAVAL);
         break;
      }
      /* This msg is Rx only and single frame, so if status is Tx or rx_new_frame then something is wrong */
      case EYEQAPPL_CB_STS_RX_FAILED:
      case EYEQAPPL_CB_STS_TX_OK:
      case EYEQAPPL_CB_STS_TX_FAILED:
      case EYEQAPPL_CB_STS_RX_NEW_FRAME:
      default:
      {
         EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_FCF_VRU, EYEQPROTMGR_MSG_RX_STS_NOT_OK);
         break;
      }
   }
}

#define EyeQProtMgr_STOP_SEC_CODE
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
End Of File
******************************************************************************/
