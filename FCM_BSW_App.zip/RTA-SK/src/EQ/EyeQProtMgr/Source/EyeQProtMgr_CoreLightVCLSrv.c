
/******************************************************************************

WBTL ELECTRONIC document

Copyright WBTL. All rights reserved.

******************************************************************************/
/******************************************************************************

@details
   <Describes details of this component implementation and design>

******************************************************************************/
/******************************************************************************
External Dependencies
******************************************************************************/
#include <EyeQProtMgr.h>
#include <EyeQProtMgr_Intl.h>
#include <EyeQProtMgr_CoreLightVCLSrv.h>

/******************************************************************************
Component Defines
******************************************************************************/

#define EYEQPROTMGR_LSV_PROT_VERSION      (10u)

/******************************************************************************
Component Types
******************************************************************************/

/******************************************************************************
Declaration of Local Functions
******************************************************************************/

#define EyeQProtMgr_START_SEC_VAR
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
Definition Of Local Variables
******************************************************************************/

/******************************************************************************
Definition Of Global Variables
******************************************************************************/
VAR(uint32, EyeQProtMgr_VAR) EyeQProtMgr_CoreLSVSrvRespLength;

#define EyeQProtMgr_STOP_SEC_VAR
#include "EyeQProtMgr_MemMap.h"

#define EyeQProtMgr_START_SEC_CONST
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
Definition Of Local Constant Data
******************************************************************************/

/******************************************************************************
Definition Of Global Constant Data
******************************************************************************/

#define EyeQProtMgr_STOP_SEC_CONST
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
Component Function-like Macros
******************************************************************************/

/******************************************************************************
Definition Of APIs
******************************************************************************/
#define EyeQProtMgr_START_SEC_CODE
#include "EyeQProtMgr_MemMap.h"

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQProtMgr_CODE) EyeQProtMgr_CoreLightVCLSrvCallback(CONST(EyeQAppl_CallbackStsType, AUTOMATIC) Status)
{
   uint32 msg_length;
   uint8 expected_sync_id;
   uint8 sync_id;

   switch (Status)
   {
      case EYEQAPPL_CB_STS_RX_OK:
      {
         msg_length = (uint32)(C_EYEQMSG_CORELIGHTVCLvH_MSG_LEN
            + (EYEQMSG_CORELIGHTVCL_Params_s.EYEQMSG_CORELIGHTVCLvH_Params_s.LSV_Vehicles_Count_b4 * C_EYEQMSG_CORELIGHTVCLvO_MSG_LEN));
         if (msg_length == EyeQProtMgr_CoreLSVSrvRespLength)
         {
            if (EYEQPROTMGR_LSV_PROT_VERSION == EYEQMSG_CORELIGHTVCL_Params_s.EYEQMSG_CORELIGHTVCLvH_Params_s.LSV_Protocol_Version_b8)
            {
               EYEQMSG_CORELIGHTVCL_ParamsApp_s = EYEQMSG_CORELIGHTVCL_Params_s;
               expected_sync_id = EyeQProtMgr_GetCurrSyncFrmId();
               (void)EYEQMSG_Get_CORELIGHTVCLvH_LSV_Sync_ID(&sync_id);
               if (expected_sync_id == sync_id)
               {
                  EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_LSV, EYEQPROTMGR_MSG_RX_STS_OK);
               }
               else
               {
                  EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_LSV, EYEQPROTMGR_MSG_RX_STS_SYNC_ID_ERR);
               }
            }
            else
            {
               EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_LSV, EYEQPROTMGR_MSG_RX_STS_DATA_NOT_MATCH);
            }
         }
         else
         {
            EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_LSV, EYEQPROTMGR_MSG_RX_STS_NOT_OK);
         }
         break;
      }
      case EYEQAPPL_CB_STS_RX_NEW_FRAME:
      {
         break;
      }
      case EYEQAPPL_CB_STS_RX_DG_UNAVAL:
      {
         EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_LSV, EYEQPROTMGR_MSG_RX_STS_DG_MSG_UNAVAL);
         break;
      }
      /* This msg is Rx only, so if status is Tx then something is wrong */
      case EYEQAPPL_CB_STS_RX_FAILED:
      case EYEQAPPL_CB_STS_TX_OK:
      case EYEQAPPL_CB_STS_TX_FAILED:
      default:
      {
         EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_LSV, EYEQPROTMGR_MSG_RX_STS_NOT_OK);
         break;
      }
   }
}

#define EyeQProtMgr_STOP_SEC_CODE
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
End Of File
******************************************************************************/
