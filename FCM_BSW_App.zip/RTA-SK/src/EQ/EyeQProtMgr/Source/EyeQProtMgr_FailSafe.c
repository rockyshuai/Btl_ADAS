
/******************************************************************************

WBTL ELECTRONIC document

Copyright WBTL. All rights reserved.

******************************************************************************/
/******************************************************************************

@details
   <Describes details of this component implementation and design>

******************************************************************************/
/******************************************************************************
External Dependencies
******************************************************************************/
#include <EyeQProtMgr.h>
#include <EyeQProtMgr_Intl.h>
#include <EyeQProtMgr_FailSafe.h>
#include <Crc.h>

/******************************************************************************
Component Defines
******************************************************************************/
#define EYEQPROTMGR_FAILSAFE_CRC_OFFSET             (4u)
#define EYEQPROTMGR_FAILSAFE_CRC_DATA_OFFSET        (8u)
#define EYEQPROTMGR_FAILSAFE_CRC_START_VAL          (0xFFFFFFFFu)
#define EYEQPROTMGR_FAILSAFE_COMP_CRC_OFFSET        (4u)
#define EYEQPROTMGR_FAILSAFE_COMP_CRC_DATA_LEN      (C_EYEQMSG_COREFAILSAFEvO_MSG_LEN - EYEQPROTMGR_FAILSAFE_COMP_CRC_OFFSET)


#define EYEQPROTMGR_FAILSAFE_PROT_VERSION           (0x06u)

/******************************************************************************
Component Types
******************************************************************************/

/******************************************************************************
Declaration of Local Functions
******************************************************************************/

#define EyeQProtMgr_START_SEC_VAR
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
Definition Of Local Variables
******************************************************************************/

/******************************************************************************
Definition Of Global Variables
******************************************************************************/
VAR(uint32, EyeQProtMgr_VAR) EyeQProtMgr_FailSafeRespLength;

#define EyeQProtMgr_STOP_SEC_VAR
#include "EyeQProtMgr_MemMap.h"

#define EyeQProtMgr_START_SEC_CONST
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
Definition Of Local Constant Data
******************************************************************************/

/******************************************************************************
Definition Of Global Constant Data
******************************************************************************/

#define EyeQProtMgr_STOP_SEC_CONST
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
Component Function-like Macros
******************************************************************************/

/******************************************************************************
Definition Of APIs
******************************************************************************/
#define EyeQProtMgr_START_SEC_CODE
#include "EyeQProtMgr_MemMap.h"

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQProtMgr_CODE) EyeQProtMgr_FailSafeCallback(CONST(EyeQAppl_CallbackStsType, AUTOMATIC) Status)
{
   uint32 computed_crc;
   uint32 rx_crc;
   uint8* crc_data_ptr = (uint8*)&EYEQMSG_COREFAILSAFE_Params_s;
   uint8 expected_sync_id;
   uint8 sync_id;
   uint8 camera_num;
   uint8 camera_idx;
   boolean crc_fail;

   crc_data_ptr += EYEQPROTMGR_FAILSAFE_CRC_DATA_OFFSET;
   crc_fail = FALSE;
   switch (Status)
   {
      case EYEQAPPL_CB_STS_RX_OK:
      {
         camera_num = EYEQMSG_COREFAILSAFE_Params_s.EYEQMSG_COREFAILSAFEvH_Params_s.FS_Cameras_Number_b4;
         if ((C_EYEQMSG_COREFAILSAFEvH_MSG_LEN +
               (camera_num * C_EYEQMSG_COREFAILSAFEvO_MSG_LEN))
               == EyeQProtMgr_FailSafeRespLength)
         {
            if (EYEQPROTMGR_FAILSAFE_PROT_VERSION == EYEQMSG_COREFAILSAFE_Params_s.EYEQMSG_COREFAILSAFEvH_Params_s.FS_Protocol_Version_b8)
            {
               /* Check CRC */
               computed_crc = Crc_CalculateCRC32(crc_data_ptr, (C_EYEQMSG_COREFAILSAFEvH_MSG_LEN - EYEQPROTMGR_FAILSAFE_CRC_DATA_OFFSET), EYEQPROTMGR_FAILSAFE_CRC_START_VAL, TRUE);
               rx_crc = (uint32)EYEQMSG_COREFAILSAFE_Params_s.EYEQMSG_COREFAILSAFEvH_Params_s.FS_Header_CRC_b32;
               if (computed_crc != rx_crc)
               {
                  crc_fail = TRUE;
               }
               else
               {
                  for (camera_idx = 0u; camera_idx < camera_num; camera_idx++)
                  {
                     crc_data_ptr = (uint8*)&EYEQMSG_COREFAILSAFE_Params_s.EYEQMSG_COREFAILSAFEvO_Params_as[camera_idx] + EYEQPROTMGR_FAILSAFE_COMP_CRC_OFFSET;
                     rx_crc = EYEQMSG_COREFAILSAFE_Params_s.EYEQMSG_COREFAILSAFEvO_Params_as[camera_idx].FS_CRC_0_b32;
                     computed_crc = Crc_CalculateCRC32(crc_data_ptr, EYEQPROTMGR_FAILSAFE_COMP_CRC_DATA_LEN, EYEQPROTMGR_FAILSAFE_CRC_START_VAL, TRUE);
                     if (computed_crc != rx_crc)
                     {
                        crc_fail = TRUE;
                        /* End the loop */
                        camera_idx = camera_num;
                     }
                  }
               }
               
               if (crc_fail == FALSE)
               {
                  EYEQMSG_COREFAILSAFE_ParamsApp_s = EYEQMSG_COREFAILSAFE_Params_s;
                  expected_sync_id = EyeQProtMgr_GetCurrSyncFrmId();
                  (void)EYEQMSG_Get_COREFAILSAFEvH_FS_Sync_ID(&sync_id);
                  if (expected_sync_id == sync_id)
                  {
                     EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_FAIL_SAFE, EYEQPROTMGR_MSG_RX_STS_OK);
                  }
                  else
                  {
                     EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_FAIL_SAFE, EYEQPROTMGR_MSG_RX_STS_SYNC_ID_ERR);
                  }

                  eyeqprotmgr_FailSafeRxProcess();
               }
               else
               {
                  EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_FAIL_SAFE, EYEQPROTMGR_MSG_RX_STS_CRC_FAIL);
               }
            }
            else
            {
               EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_FAIL_SAFE, EYEQPROTMGR_MSG_RX_STS_DATA_NOT_MATCH);
            }
         }
         else
         {
            EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_FAIL_SAFE, EYEQPROTMGR_MSG_RX_STS_NOT_OK);
         }
         break;
      }
      case EYEQAPPL_CB_STS_RX_NEW_FRAME:
      {
         break;
      }
      case EYEQAPPL_CB_STS_RX_DG_UNAVAL:
      {
         EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_FAIL_SAFE, EYEQPROTMGR_MSG_RX_STS_DG_MSG_UNAVAL);
         break;
      }
      /* This msg is Rx only, so if status is Tx then something is wrong */
      case EYEQAPPL_CB_STS_RX_FAILED:
      case EYEQAPPL_CB_STS_TX_OK:
      case EYEQAPPL_CB_STS_TX_FAILED:
      default:
      {
         EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_FAIL_SAFE, EYEQPROTMGR_MSG_RX_STS_NOT_OK);
         break;
      }
   }
}

#define EyeQProtMgr_STOP_SEC_CODE
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
End Of File
******************************************************************************/
