
/******************************************************************************

WBTL ELECTRONIC document

Copyright WBTL. All rights reserved.

******************************************************************************/
/******************************************************************************

@details
   <Describes details of this component implementation and design>

******************************************************************************/
/******************************************************************************
External Dependencies
******************************************************************************/
#include <EyeQProtMgr.h>
#include <EyeQProtMgr_Intl.h>
#include <EyeQProtMgr_BootDiagSrv.h>
#include <EyeQStMgr.h>
#include <Dem.h>


/******************************************************************************
Component Defines
******************************************************************************/
#define EYEQPROTMGR_BOOTDIAG_PROT_VERSION         (0x02u)

/******************************************************************************
Component Types
******************************************************************************/

/******************************************************************************
Declaration of Local Functions
******************************************************************************/
LOCAL FUNC(void, EyeQProtMgr_CODE) eyeqprotmgr_BootDiagProcess(void);

#define EyeQProtMgr_START_SEC_VAR
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
Definition Of Local Variables
******************************************************************************/
LOCAL VAR(uint8, EyeQProtMgr_VAR) eyeqprotmgr_BootDiagRxCnt = 0u;

/******************************************************************************
Definition Of Global Variables
******************************************************************************/
VAR(uint32, EyeQProtMgr_VAR) EyeQProtMgr_BootDiagSrvRespLength;
VAR(EyeQProtMgr_BootDiagDataType, EyeQProtMgr_VAR) EyeQProtMgr_BootDiagData;

#define EyeQProtMgr_STOP_SEC_VAR
#include "EyeQProtMgr_MemMap.h"

#define EyeQProtMgr_START_SEC_CONST
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
Definition Of Local Constant Data
******************************************************************************/

/******************************************************************************
Definition Of Global Constant Data
******************************************************************************/

#define EyeQProtMgr_STOP_SEC_CONST
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
Component Function-like Macros
******************************************************************************/

/******************************************************************************
Definition Of APIs
******************************************************************************/
#define EyeQProtMgr_START_SEC_CODE
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQProtMgr_CODE) EyeQProtMgr_BootDiagSrvCallback(CONST(EyeQAppl_CallbackStsType, EyeQProtMgr_CONST)Status)
{
   switch (Status)
   {
      case EYEQAPPL_CB_STS_RX_OK:
      {
         if (C_EYEQMSG_BOOTDIAGMSG_MSG_LEN == EyeQProtMgr_BootDiagSrvRespLength)
         {
            if (EYEQPROTMGR_BOOTDIAG_PROT_VERSION == EYEQMSG_BOOTDIAGMSG_Params_s.BootMsg_Protocol_Version_b8)
            {
               EYEQMSG_BOOTDIAGMSG_ParamsApp_s = EYEQMSG_BOOTDIAGMSG_Params_s;
               EyeQProtMgr_NotifyMsgRxSts(EYEQPROTMGR_MSG_BOOT_DIAG, EYEQPROTMGR_MSG_RX_STS_OK);
               eyeqprotmgr_BootDiagRxCnt++;
               /* Only ontify once at first BootDiag message which stage should be 1. */
               if (1u == EYEQMSG_BOOTDIAGMSG_ParamsApp_s.Boot_Stage_b8)
               {
                  EyeQStMgr_BootNotify();
               }
               EYEQMSG_Get_BOOTDIAGMSG_Boot_Stage(&EyeQProtMgr_BootDiagData.BDStage);
               EYEQMSG_Get_BOOTDIAGMSG_BOOT_Test_results(&EyeQProtMgr_BootDiagData.BDTestResults);
               EYEQMSG_Get_BOOTDIAGMSG_BOOT_LPDDR4_Temperature_Status(&EyeQProtMgr_BootDiagData.BDTempStatus);
               eyeqprotmgr_BootDiagRxProcess();
            }
            else
            {
               EyeQProtMgr_NotifyMsgRxSts(EYEQPROTMGR_MSG_BOOT_DIAG, EYEQPROTMGR_MSG_RX_STS_DATA_NOT_MATCH);
            }
         }
         else
         {
            EyeQProtMgr_NotifyMsgRxSts(EYEQPROTMGR_MSG_BOOT_DIAG, EYEQPROTMGR_MSG_RX_STS_NOT_OK);
         }
         break;
      }
      case EYEQAPPL_CB_STS_RX_DG_UNAVAL:
      {
         EyeQProtMgr_NotifyMsgRxSts(EYEQPROTMGR_MSG_BOOT_DIAG, EYEQPROTMGR_MSG_RX_STS_DG_MSG_UNAVAL);
         break;
      }
      /* This msg is Rx only and single frame, so if status is Tx or rx_new_frame then something is wrong */
      case EYEQAPPL_CB_STS_RX_FAILED:
      case EYEQAPPL_CB_STS_TX_OK:
      case EYEQAPPL_CB_STS_TX_FAILED:
      case EYEQAPPL_CB_STS_RX_NEW_FRAME:
      default:
      {
         EyeQProtMgr_NotifyMsgRxSts(EYEQPROTMGR_MSG_BOOT_DIAG, EYEQPROTMGR_MSG_RX_STS_NOT_OK);
         break;
      }
   }
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(uint8, EyeQProtMgr_CODE) EyeQProtMgr_GetBootDiagRxCnt(void)
{
   return (eyeqprotmgr_BootDiagRxCnt);
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQProtMgr_CODE) EyeQProtMgr_BootDiagInit(void)
{
   EyeQProtMgr_BootDiagData.BDStage = 0u;
   EyeQProtMgr_BootDiagData.BDTestResults = 0u;

}

#define EyeQProtMgr_STOP_SEC_CODE
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
End Of File
******************************************************************************/
