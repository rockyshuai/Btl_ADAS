
/******************************************************************************

WBTL ELECTRONIC document

Copyright WBTL. All rights reserved.

******************************************************************************/
/******************************************************************************

@details
   <Describes details of this component implementation and design>

******************************************************************************/
/******************************************************************************
External Dependencies
******************************************************************************/
#include <EyeQProtMgr.h>
#include <EyeQProtMgr_Intl.h>
#include <EyeQProtMgr_CoreLightRFLSrv.h>

/******************************************************************************
Component Defines
******************************************************************************/

#define EYEQPROTMGR_LSR_PROT_VERSION      (0x05u)

/******************************************************************************
Component Types
******************************************************************************/

/******************************************************************************
Declaration of Local Functions
******************************************************************************/

#define EyeQProtMgr_START_SEC_VAR
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
Definition Of Local Variables
******************************************************************************/

/******************************************************************************
Definition Of Global Variables
******************************************************************************/
VAR(uint32, EyeQProtMgr_VAR) EyeQProtMgr_CoreLightRFLSrvRespLength;

#define EyeQProtMgr_STOP_SEC_VAR
#include "EyeQProtMgr_MemMap.h"

#define EyeQProtMgr_START_SEC_CONST
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
Definition Of Local Constant Data
******************************************************************************/

/******************************************************************************
Definition Of Global Constant Data
******************************************************************************/

#define EyeQProtMgr_STOP_SEC_CONST
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
Component Function-like Macros
******************************************************************************/

/******************************************************************************
Definition Of APIs
******************************************************************************/
#define EyeQProtMgr_START_SEC_CODE
#include "EyeQProtMgr_MemMap.h"

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQProtMgr_CODE) EyeQProtMgr_CoreLightRFLSrvCallback(CONST(EyeQAppl_CallbackStsType, AUTOMATIC) Status)
{
   uint32 msg_length;
   uint8 expected_sync_id;
   uint8 sync_id;

   switch (Status)
   {
      case EYEQAPPL_CB_STS_RX_OK:
      {
         msg_length = (uint32)(C_EYEQMSG_CORELIGHTRFLvH_MSG_LEN
            + (EYEQMSG_CORELIGHTRFL_Params_s.EYEQMSG_CORELIGHTRFLvH_Params_s.LSR_Strong_Reflectors_Count_b4 * C_EYEQMSG_CORELIGHTRFLvO_MSG_LEN));
         if (msg_length == EyeQProtMgr_CoreLightRFLSrvRespLength)
         {
            if (EYEQPROTMGR_LSR_PROT_VERSION == EYEQMSG_CORELIGHTRFL_Params_s.EYEQMSG_CORELIGHTRFLvH_Params_s.LSR_Protocol_Version_b7)
            {
               EYEQMSG_CORELIGHTRFL_ParamsApp_s = EYEQMSG_CORELIGHTRFL_Params_s;
               expected_sync_id = EyeQProtMgr_GetCurrSyncFrmId();
               (void)EYEQMSG_Get_CORELIGHTRFLvH_LSR_Sync_ID(&sync_id);
               if (expected_sync_id == sync_id)
               {
                  EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_LSR, EYEQPROTMGR_MSG_RX_STS_OK);
               }
               else
               {
                  EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_LSR, EYEQPROTMGR_MSG_RX_STS_SYNC_ID_ERR);
               }
            }
            else
            {
               EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_LSR, EYEQPROTMGR_MSG_RX_STS_DATA_NOT_MATCH);
            }
         }
         else
         {
            EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_LSR, EYEQPROTMGR_MSG_RX_STS_NOT_OK);
         }
         break;
      }
      case EYEQAPPL_CB_STS_RX_NEW_FRAME:
      {
         break;
      }
      case EYEQAPPL_CB_STS_RX_DG_UNAVAL:
      {
         EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_LSR, EYEQPROTMGR_MSG_RX_STS_DG_MSG_UNAVAL);
         break;
      }
      /* This msg is Rx only, so if status is Tx then something is wrong */
      case EYEQAPPL_CB_STS_RX_FAILED:
      case EYEQAPPL_CB_STS_TX_OK:
      case EYEQAPPL_CB_STS_TX_FAILED:
      default:
      {
         EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_LSR, EYEQPROTMGR_MSG_RX_STS_NOT_OK);
         break;
      }
   }
}

#define EyeQProtMgr_STOP_SEC_CODE
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
End Of File
******************************************************************************/
