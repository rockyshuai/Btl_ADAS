
/******************************************************************************

WBTL ELECTRONIC document

Copyright WBTL. All rights reserved.

******************************************************************************/
/******************************************************************************

@details
   <Describes details of this component implementation and design>

******************************************************************************/
/******************************************************************************
External Dependencies
******************************************************************************/
#include <EyeQProtMgr.h>
#include <EyeQProtMgr_Intl.h>
#include <EyeQProtMgr_FcfVd.h>
#include <Crc.h>

/******************************************************************************
Component Defines
******************************************************************************/
#define EYEQPROTMGR_FCFVD_CRC_OFFSET                  (4u)
#define EYEQPROTMGR_FCFVD_CRC_DATA_OFFSET             (8u)
#define EYEQPROTMGR_FCFVD_CRC_DATA_SIZE               (12u)
#define EYEQPROTMGR_FCFVD_CRC_START_VAL               (0xffffffffu)

#define EYEQPROTMGR_FCFVD_COMP_CRC_DATA_OFFSET        (26u)
#define EYEQPROTMGR_FCFVD_COMP_CRC_DATA_LENGTH        (2u)
#define EYEQPROTMGR_FCFVD_COMP_CRC_DATA_CYCLE_LEN     (20u)
#define EYEQPROTMGR_FCFVD_COMP_CRC_DATA_CYCLE_NUM     (8u)

#define EYEQPROTMGR_FCFVD_PROT_VERSION                (0x07u)

/******************************************************************************
Component Types
******************************************************************************/

/******************************************************************************
Declaration of Local Functions
******************************************************************************/

#define EyeQProtMgr_START_SEC_VAR
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
Definition Of Local Variables
******************************************************************************/

/******************************************************************************
Definition Of Global Variables
******************************************************************************/
VAR(uint32, EyeQProtMgr_VAR) EyeQProtMgr_FcfVdRespLength;

#define EyeQProtMgr_STOP_SEC_VAR
#include "EyeQProtMgr_MemMap.h"

#define EyeQProtMgr_START_SEC_CONST
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
Definition Of Local Constant Data
******************************************************************************/

/******************************************************************************
Definition Of Global Constant Data
******************************************************************************/

#define EyeQProtMgr_STOP_SEC_CONST
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
Component Function-like Macros
******************************************************************************/

/******************************************************************************
Definition Of APIs
******************************************************************************/
#define EyeQProtMgr_START_SEC_CODE
#include "EyeQProtMgr_MemMap.h"

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQProtMgr_CODE) EyeQProtMgr_FcfVdCallback(CONST(EyeQAppl_CallbackStsType, AUTOMATIC) Status)
{
   uint32 crc_array[EYEQPROTMGR_FCFVD_COMP_CRC_DATA_CYCLE_NUM];
   uint32 computed_crc;
   uint32 rx_crc;
   uint8* crc_data_ptr = (uint8*)&EYEQMSG_COREFCFVD_Params_s;
   uint8 expected_sync_id;
   uint8 sync_id;
   uint8 cyc_indx;
   boolean crc_fail;


   crc_data_ptr += EYEQPROTMGR_FCFVD_CRC_DATA_OFFSET;
   crc_fail = FALSE;

   switch (Status)
   {
      case EYEQAPPL_CB_STS_RX_OK:
      {
         if (C_EYEQMSG_COREFCFVD_MSG_LEN == EyeQProtMgr_FcfVdRespLength)
         {
            if (EYEQPROTMGR_FCFVD_PROT_VERSION == EYEQMSG_COREFCFVD_Params_s.FCF_VD_Protocol_Version_b8)
            {
               /* Check CRC */
               computed_crc = Crc_CalculateCRC32(crc_data_ptr, EYEQPROTMGR_FCFVD_CRC_DATA_SIZE, EYEQPROTMGR_FCFVD_CRC_START_VAL, TRUE);
               rx_crc = (uint32)EYEQMSG_COREFCFVD_Params_s.FCF_Header_CRC_b32;
               if (computed_crc != rx_crc)
               {
                  crc_fail = TRUE;
               }
               else
               {
                  crc_array[0] = EYEQMSG_COREFCFVD_Params_s.FCF_VD_CRC_A_b32;
                  crc_array[1] = EYEQMSG_COREFCFVD_Params_s.FCF_VD_CRC_B_b32;               
                  crc_array[2] = EYEQMSG_COREFCFVD_Params_s.FCF_VD_CRC_C_b32;
                  crc_array[3] = EYEQMSG_COREFCFVD_Params_s.FCF_VD_CRC_D_b32; 
                  crc_array[4] = EYEQMSG_COREFCFVD_Params_s.FCF_VD_CRC_E_b32;
                  crc_array[5] = EYEQMSG_COREFCFVD_Params_s.FCF_VD_CRC_F_b32;
                  crc_array[6] = EYEQMSG_COREFCFVD_Params_s.FCF_VD_CRC_G_b32;
                  crc_array[7] = EYEQMSG_COREFCFVD_Params_s.FCF_VD_CRC_H_b32;

                  crc_data_ptr = (uint8*)&EYEQMSG_COREFCFVD_Params_s;
                  crc_data_ptr += EYEQPROTMGR_FCFVD_COMP_CRC_DATA_OFFSET;

                  for (cyc_indx = 0u; cyc_indx < EYEQPROTMGR_FCFVD_COMP_CRC_DATA_CYCLE_NUM; cyc_indx++)
                  {
                     computed_crc = Crc_CalculateCRC32(crc_data_ptr, EYEQPROTMGR_FCFVD_COMP_CRC_DATA_LENGTH, EYEQPROTMGR_FCFVD_CRC_START_VAL, TRUE);

                     if (computed_crc != crc_array[cyc_indx])
                     {
                        crc_fail = TRUE;
                        cyc_indx = EYEQPROTMGR_FCFVD_COMP_CRC_DATA_CYCLE_NUM;
                     }

                     crc_data_ptr = crc_data_ptr + EYEQPROTMGR_FCFVD_COMP_CRC_DATA_CYCLE_LEN;
                  }
               }
               
               if (crc_fail == FALSE)
               {
                  EYEQMSG_COREFCFVD_ParamsApp_s = EYEQMSG_COREFCFVD_Params_s;
                  expected_sync_id = EyeQProtMgr_GetCurrSyncFrmId();
                  (void)EYEQMSG_Get_COREFCFVD_FCF_VD_SyncID(&sync_id);
                  if (expected_sync_id == sync_id)
                  {
                     EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_FCF_VD, EYEQPROTMGR_MSG_RX_STS_OK);
                  }
                  else
                  {
                     EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_FCF_VD, EYEQPROTMGR_MSG_RX_STS_SYNC_ID_ERR);
                  }

                  //eyeqprotmgr_FcfVdRxProcess();
               }
               else
               {
                  EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_FCF_VD, EYEQPROTMGR_MSG_RX_STS_CRC_FAIL);
               }
            }
            else
            {
               EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_FCF_VD, EYEQPROTMGR_MSG_RX_STS_DATA_NOT_MATCH);
            }
         }
         else
         {
            EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_FCF_VD, EYEQPROTMGR_MSG_RX_STS_NOT_OK);
         }
         break;
      }
      case EYEQAPPL_CB_STS_RX_NEW_FRAME:
      {
         break;
      }
      case EYEQAPPL_CB_STS_RX_DG_UNAVAL:
      {
         EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_FCF_VD, EYEQPROTMGR_MSG_RX_STS_DG_MSG_UNAVAL);
         break;
      }
      /* This msg is Rx only, so if status is Tx then something is wrong */
      case EYEQAPPL_CB_STS_RX_FAILED:
      case EYEQAPPL_CB_STS_TX_OK:
      case EYEQAPPL_CB_STS_TX_FAILED:
      default:
      {
         EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_FCF_VD, EYEQPROTMGR_MSG_RX_STS_NOT_OK);
         break;
      }
   }
}

#define EyeQProtMgr_STOP_SEC_CODE
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
End Of File
******************************************************************************/
