
/******************************************************************************

WBTL ELECTRONIC document

Copyright WBTL. All rights reserved.

******************************************************************************/
/******************************************************************************

@details
   <Describes details of this component implementation and design>

******************************************************************************/
/******************************************************************************
External Dependencies
******************************************************************************/
#include <EyeQProtMgr.h>
#include <EyeQProtMgr_Intl.h>
#include <Crc.h>
#include <EyeQProtMgr_AppMsgSrv.h>

/******************************************************************************
Component Defines
******************************************************************************/
#define EYEQPROTMGR_APP_CRC_SIZE          (4u)
#define EYEQPROTMGR_APP_CRC_START_VAL     (0xffffffffu)

#define EYEQPROTMGR_APP_PROT_VERSION      (0x08u)
#define EYEQPROTMGR_APP_MSG_VERSION       (16u)

/******************************************************************************
Component Types
******************************************************************************/

/******************************************************************************
Declaration of Local Functions
******************************************************************************/

#define EyeQProtMgr_START_SEC_VAR
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
Definition Of Local Variables
******************************************************************************/

/******************************************************************************
Definition Of Global Variables
******************************************************************************/
VAR(uint32, EyeQProtMgr_VAR) EyeQProtMgr_AppSrvRespLength;
VAR(EyeQProtMgr_AppMsgDataType, EyeQProtMgr_VAR) EyeQProtMgr_AppMsgData;

#define EyeQProtMgr_STOP_SEC_VAR
#include "EyeQProtMgr_MemMap.h"

#define EyeQProtMgr_START_SEC_CONST
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
Definition Of Local Constant Data
******************************************************************************/

/******************************************************************************
Definition Of Global Constant Data
******************************************************************************/

#define EyeQProtMgr_STOP_SEC_CONST
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
Component Function-like Macros
******************************************************************************/

/******************************************************************************
Definition Of APIs
******************************************************************************/
#define EyeQProtMgr_START_SEC_CODE
#include "EyeQProtMgr_MemMap.h"

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQProtMgr_CODE) EyeQProtMgr_AppMsgSrvInit(void)
{
   EyeQProtMgr_AppMsgData.FatalError = EYEQPROTMGR_FATAL_E_APP_OK;
   EyeQProtMgr_AppMsgData.MainSt = EYEQMESPMGR_BASCSRV_MAIN_ST_UNKNOWN;
   EyeQProtMgr_AppMsgData.EyeQT1 = 0;
   EyeQProtMgr_AppMsgData.EyeQT2 = 0;
   EyeQProtMgr_AppMsgData.Cam1T1 = 0;
   EyeQProtMgr_AppMsgData.Cam1T2 = 0;
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQProtMgr_CODE) EyeQProtMgr_AppMsgSrvCallback(CONST(EyeQAppl_CallbackStsType, AUTOMATIC) Status)
{
   uint32 computed_crc;
   uint32 rx_crc;
   uint8* crc_data_ptr = (uint8*)&EYEQMSG_APPMSG_Params_s;

	//crc_data_ptr += EYEQPROTMGR_APP_CRC_DATA_OFFSET;

   switch (Status)
   {
      case EYEQAPPL_CB_STS_RX_OK:
      {
         if (C_EYEQMSG_APPMSG_MSG_LEN == EyeQProtMgr_AppSrvRespLength)
         {
            if (EYEQPROTMGR_APP_MSG_VERSION == EYEQMSG_APPMSG_Params_s.Application_Message_Version_b8)
            {
               /* Check CRC */
               computed_crc = Crc_CalculateCRC32(crc_data_ptr, (C_EYEQMSG_APPMSG_MSG_LEN - EYEQPROTMGR_APP_CRC_SIZE), EYEQPROTMGR_APP_CRC_START_VAL, TRUE);
               rx_crc = (uint32)EYEQMSG_APPMSG_Params_s.App_CRC32_b32;
               if (computed_crc == rx_crc)
               {
                  EYEQMSG_APPMSG_ParamsApp_s = EYEQMSG_APPMSG_Params_s;
                  EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_APP, EYEQPROTMGR_MSG_RX_STS_OK);
                  eyeqprotmgr_AppRxProcess();
               }
               else
               {
                  EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_APP, EYEQPROTMGR_MSG_RX_STS_CRC_FAIL);
               }
            }
            else
            {
               EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_APP, EYEQPROTMGR_MSG_RX_STS_DATA_NOT_MATCH);
            }
         }
         else
         {
            EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_APP, EYEQPROTMGR_MSG_RX_STS_NOT_OK);
         }
         break;
      }
      case EYEQAPPL_CB_STS_RX_DG_UNAVAL:
      {
         EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_APP, EYEQPROTMGR_MSG_RX_STS_DG_MSG_UNAVAL);
         break;
      }
      /* This msg is Rx only and single frame, so if status is Tx or rx_new_frame then something is wrong */
      case EYEQAPPL_CB_STS_RX_FAILED:
      case EYEQAPPL_CB_STS_TX_OK:
      case EYEQAPPL_CB_STS_TX_FAILED:
      case EYEQAPPL_CB_STS_RX_NEW_FRAME:
      default:
      {
         EyeQProtMgr_NotifyFrmRateMsgRxSts(EYEQPROTMGR_FRM_RATE_MSG_APP, EYEQPROTMGR_MSG_RX_STS_NOT_OK);
         break;
      }
   }
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(EyeQMespMgr_BascSrvMainStType, EyeQProtMgr_CODE) EyeQProtMgr_AppMsgSrvGetMainSt(void)
{
   return (EyeQProtMgr_AppMsgData.MainSt);
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(Std_ReturnType, EyeQProtMgr_CODE) EyeQProtMgr_AppMsgSrvGetTemperatures(
   CONSTP2VAR(sint16, AUTOMATIC, EyeQProtMgr_APPL_DATA) EyeQT1Ptr,
   CONSTP2VAR(sint16, AUTOMATIC, EyeQProtMgr_APPL_DATA) EyeQT2Ptr,
   CONSTP2VAR(sint8, AUTOMATIC, EyeQProtMgr_APPL_DATA) Cam1T1Ptr,
   CONSTP2VAR(sint8, AUTOMATIC, EyeQProtMgr_APPL_DATA) Cam1T2Ptr)
{
   Std_ReturnType ret_val = E_OK;

   if ((NULL_PTR == EyeQT1Ptr) || (NULL_PTR == EyeQT2Ptr) || (NULL_PTR == Cam1T1Ptr) || (NULL_PTR == Cam1T2Ptr))
   {
      ret_val = E_NOT_OK;
   }
   else
   {
      *EyeQT1Ptr = EyeQProtMgr_AppMsgData.EyeQT1;
      *EyeQT2Ptr = EyeQProtMgr_AppMsgData.EyeQT2;
      *Cam1T1Ptr = EyeQProtMgr_AppMsgData.Cam1T1;
      *Cam1T2Ptr = EyeQProtMgr_AppMsgData.Cam1T2;
   }

   return (ret_val);
}

#define EyeQProtMgr_STOP_SEC_CODE
#include "EyeQProtMgr_MemMap.h"
/******************************************************************************
End Of File
******************************************************************************/
