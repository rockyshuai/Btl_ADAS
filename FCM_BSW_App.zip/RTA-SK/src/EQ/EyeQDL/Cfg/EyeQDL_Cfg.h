
#ifndef EYEQDL_CFG_H_
#define EYEQDL_CFG_H_ 1

/******************************************************************************

WBTL ELECTRONIC document

Copyright WBTL All rights reserved.

*******************************************************************************

@details
   <Describes details of this header file>

******************************************************************************/
/******************************************************************************
External Dependencies
******************************************************************************/

/******************************************************************************
Definition Of Constants
******************************************************************************/
#define EYEQDL_RX_BUFF_SIZE_FRAME     (5u)
#define EYEQDL_RX_BUFF_SIZE_WORD      (EYEQDL_FRAME_LENGTH_WORD * EYEQDL_RX_BUFF_SIZE_FRAME)
#define EYEQDL_RX_BUFF_SIZE_BYTE      (EYEQDL_FRAME_LENGTH_WORD * EYEQDL_RX_BUFF_SIZE_FRAME * EYEQDL_WORD_SIZE)
/* 
 * Size of Tx buffer shall be 2^n, to simplify the frame number to buffer index calculation,
 * n is bits of index mask.
 */
#define EYEQDL_TX_BUFF_SIZE_FRAME        (16u)
#define EYEQDL_TX_BUFF_INDEX_MASK        (0xFu)
                                         
#define EYEQDL_RX_WINDOW_SIZE            (EYEQDL_TX_BUFF_SIZE_FRAME)   /* Protocol W variable */
                                         
#define EYEQDL_MAIN_TX_PERIOD_MS         (1u)
#define EYEQDL_TX_ACK_TIMEOUT_MS         (15u)
#define EYEQDL_TX_ACK_TIMEOUT_CNT        (EYEQDL_TX_ACK_TIMEOUT_MS / EYEQDL_MAIN_TX_PERIOD_MS)
#define EYEQDL_TX_ACK_TIMEOUT_STICKY_CNT (5u)

/******************************************************************************
Declaration Of Types
******************************************************************************/

/******************************************************************************
Declaration Of Variables
******************************************************************************/

/******************************************************************************
Declaration Of Constant Data
******************************************************************************/

/******************************************************************************
Declaration Of Functions
******************************************************************************/

/******************************************************************************
Declaration Of Function-like Macros
******************************************************************************/

/******************************************************************************
End Of File
******************************************************************************/

#endif /* EYEQDL_CFG_H_ */
