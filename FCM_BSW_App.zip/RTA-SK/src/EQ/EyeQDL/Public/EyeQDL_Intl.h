
#ifndef EYEQDL_INTL_H_
#define EYEQDL_INTL_H_ 1

/******************************************************************************

WBTL ELECTRONIC document

Copyright WBTL All rights reserved.

*******************************************************************************

@details
   <Describes details of this header file>

******************************************************************************/
/******************************************************************************
External Dependencies
******************************************************************************/
#include <EyeQDL_Cfg.h>

/******************************************************************************
Definition Of Constants
******************************************************************************/
#define EYEQDL_WORD_SIZE                  (4u)
#define EYEQDL_MAX_FRAME_NUM              (0x0FFFu)
#define EYEQDL_MODULO_4096_MASK           (0x0FFFu)
#define EYEQDL_FRAME_NUM_MODULUS          (0x1000u)
#define EYEQDL_FRAME_LENGTH_BYTE          (128u)
#define EYEQDL_FRAME_LENGTH_WORD          (EYEQDL_FRAME_LENGTH_BYTE / EYEQDL_WORD_SIZE)
#define EYEQDL_FRAME_HEADER_SIZE          (4u)
#define EYEQDL_FRAME_CRC_SIZE             (2u)
#define EYEQDL_DATA_FRAME_CRC_CAL_SIZE    (EYEQDL_FRAME_LENGTH_BYTE - EYEQDL_FRAME_CRC_SIZE)
#define EYEQDL_N_ACK_FRAME_CRC_CAL_SIZE   (EYEQDL_FRAME_HEADER_SIZE)
#define EYEQDL_FRAME_DATA_PADD_SIZE_BYTE  (122u)

#define EYEQDL_LOW_3_NIBBLE_MASK          (0x00000FFFu)
#define EYEQDL_LOW_1_NIBBLE_MASK          (0x0000000Fu)
#define EYEQDL_HIGH_3_NIBBLE_MASK         (0xFFF00000u)

/* EyeQ Data Link frame data section location (byte) */
#define EYEQDL_FRAME_LOC_D_R              (0u)
#define EYEQDL_FRAME_LOC_RSP              (1u)
#define EYEQDL_FRAME_LOC_NUM              (2u)
#define EYEQDL_FRAME_LOC_CRC              (4u)
#define EYEQDL_FRAME_LOC_DATA             (6u)
                                         
#define EYEQDL_FRAME_LOC_A_R              (0u)
#define EYEQDL_FRAME_LOC_FILL             (2u)
#define EYEQDL_FRAME_LOC_PADD             (6u)
                                         
#define EYEQDL_FRAME_LOC_N_R              (0u)
#define EYEQDL_FRAME_LOC_RSN              (2u)
                                         
#define EYEQDL_DATA_FRAME_ID              (0x8u)
#define EYEQDL_ACK_FRAME_ID               (0x9u)
#define EYEQDL_NAK_FRAME_ID               (0xAu)

/* Mask in little endian of 32bit header */
#define EYEQDL_FRAME_ID_MASK              (EYEQDL_LOW_1_NIBBLE_MASK)
#define EYEQDL_FRAME_RSP_MASK             (0x000FFF00u)
#define EYEQDL_FRAME_NUM_MASK             (EYEQDL_HIGH_3_NIBBLE_MASK)
#define EYEQDL_FRAME_FILL_MASK            (EYEQDL_HIGH_3_NIBBLE_MASK)
#define EYEQDL_FRAME_RSN_MASK             (EYEQDL_HIGH_3_NIBBLE_MASK)

#define EYEQDL_RSN_SEQUENCE_ERROR         (0x01u)
#define EYEQDL_RSN_CRC_ERROR              (0x02u)
#define EYEQDL_RSN_BUFF_UNAVAILABLE       (0x08u)
#define EYEQDL_RSN_RX_OVERRUN             (0x09u)
#define EYEQDL_RSN_FRAME_TOO_LONG         (0x10u)
#define EYEQDL_RSN_HEADER_FORMAT_ERROR    (0x11u)

#define EYEQDL_TX_BUFF_INDEX_INIT         (0xFFFFu)

#define EYEQDL_TX_STS_NORMAL              (0u)
#define EYEQDL_TX_STS_ACK_TIMEOUT         (1u << 0u)
#define EYEQDL_TX_STS_ACK_TIMEOUT_STICKY  (1u << 1u)

/******************************************************************************
Declaration Of Types
******************************************************************************/
typedef struct EyeQDL_TxDataTypeTag
{
   uint32  TxBuffer[EYEQDL_FRAME_LENGTH_WORD];

//   uint16  DlFrameNum;
   uint16  TpFrameNum;
//   uint8   TxTimer;
//   boolean IsSent;
//   boolean IsAcked;
} EyeQDL_TxDataType;

typedef struct EyeQDL_DataTypeTag
{
   EyeQDL_TxDataType TxData[EYEQDL_TX_BUFF_SIZE_FRAME];
   /* Below for EyeQSpi */
   uint32 RxNewFrameDataBuff[EYEQDL_RX_BUFF_SIZE_WORD];
   uint16 RxNewFrameLengthBuff[EYEQDL_RX_BUFF_SIZE_FRAME];
   uint16 RxPrevFrameIdx;
   uint16 RxLastReturnedFrameIdx;
   /* Below for received frames detected good or bad */
   uint16 RxHighestGoodFrameNum;   /* Protocol R variable */
   uint16 RxLastGoodFrameNum;   /* Protocol Y variable */
   uint16 RxLastBadFrameNum;
   uint16 RxLastNakFrameNum;
   uint8  RxLastBadFrameRsn;
   uint8  RxLastNakRsn;

   /* Below for transmit frames */
   uint16 TxHighestSentFrameNum; /* Protocol N variable */
   uint16 TxHighestAckedFrameNum; /* Protocol A variable */
   uint16 TxNextFrameNum; /* Protocol T variable */
   uint16 TxLastSentFrameNum; /* Protocol X variable */
   uint16 TxLastFilledFrameNum;
   uint16 TxReceiveAckTimer;
   uint16 TxStatus;
   uint16 TxLastRetransmitHiAcked;
   uint8  TxRetransmitCnt;
   uint8  TxBuffFreeNum;

   /* Flags */
   boolean SendNakFlag; /* Protocol SNAK */
   boolean SendAckFlag; /* Protocol SACK */
   boolean NakInProcess;
} EyeQDL_DataType;


/******************************************************************************
Declaration Of Variables
******************************************************************************/

/******************************************************************************
Declaration Of Constant Data
******************************************************************************/

/******************************************************************************
Declaration Of Functions
******************************************************************************/

/******************************************************************************
Declaration Of Function-like Macros
******************************************************************************/
/* Header is 32 bits */
#define EyeQDL_GetFrameId(Header)                (Header & EYEQDL_FRAME_ID_MASK)
#define EyeQDL_GetFrameRsp(Header)               ((Header & EYEQDL_FRAME_RSP_MASK) >> 8u)
#define EyeQDL_GetFrameNum(Header)               ((Header & EYEQDL_FRAME_NUM_MASK) >> 20u)
#define EyeQDL_GetFrameRsn(Header)               ((Header & EYEQDL_FRAME_RSN_MASK) >> 20u)
                                                 
#define EyeQDL_SetFrameId(Header, FrameId)       (Header = (Header | (FrameId & EYEQDL_LOW_1_NIBBLE_MASK)))
#define EyeQDL_SetFrameRsp(Header, Rsp)          (Header = (Header | ((Rsp & EYEQDL_LOW_3_NIBBLE_MASK) << 8u)))
#define EyeQDL_SetFrameNum(Header, Num)          (Header = (Header | ((Num & EYEQDL_LOW_3_NIBBLE_MASK) << 20u)))
#define EyeQDL_SetFrameRsn(Header, Rsn)          (Header = (Header | ((Rsn & EYEQDL_LOW_3_NIBBLE_MASK) << 20u)))

#define EyeQDL_GetFrameHeader(FramePtr, Header)  (Header = *(uint32*)FramePtr)
#define EyeQDL_SetFrameHeader(FramePtr, Header)  (*(uint32*)FramePtr = Header)

/* FramePtr is the pointer to byte0 of frame data */
#define EyeQDL_GetFrameCrc(FramePtr)             (uint16)(*((uint16*)FramePtr + 2u))
#define EyeQDL_SetFrameCrc(FramePtr, Crc)        (*((uint16*)FramePtr + 2u) = Crc)

#define EyeQDL_GetTxBufferIndex(FrameNum)        (FrameNum & EYEQDL_TX_BUFF_INDEX_MASK)
#define EyeQDL_GetNextTxBuffIdx(TxBuffIdx)       ((TxBuffIdx + 1u) & EYEQDL_TX_BUFF_INDEX_MASK)

/******************************************************************************
End Of File
******************************************************************************/

#endif /* EYEQDL_INTL_H_ */
