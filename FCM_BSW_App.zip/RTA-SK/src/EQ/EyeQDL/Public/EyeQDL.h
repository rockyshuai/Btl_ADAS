
#ifndef EYEQDL_H_
#define EYEQDL_H_ 1

/******************************************************************************

WBTL ELECTRONIC document

Copyright WBTL All rights reserved.

*******************************************************************************

@details
   <Describes details of this header file>

******************************************************************************/
/******************************************************************************
External Dependencies
******************************************************************************/
#include <Std_Types.h>

/******************************************************************************
Definition Of Constants
******************************************************************************/

/******************************************************************************
Declaration Of Types
******************************************************************************/

/******************************************************************************
Declaration Of Variables
******************************************************************************/

/******************************************************************************
Declaration Of Constant Data
******************************************************************************/

/******************************************************************************
Declaration Of Functions
******************************************************************************/
extern FUNC(void, EyeQDL_CODE) EyeQDL_Init(void);
extern FUNC(void, EyeQDL_CODE) EyeQDL_SoftResetInit(void);
extern FUNC(void, EyeQDL_CODE) EyeQDL_MainFunctionTx(void);
extern FUNC(void, EyeQDL_CODE) EyeQDL_MainFunctionRx(void);
extern FUNC(Std_ReturnType, EyeQDL_CODE) EyeQDL_ProvideTpFrame(CONSTP2CONST(uint8, AUTOMATIC, EyeQDL_APPL_DATA) TpFrameDataPtr,
                                                               CONST(uint16, AUTOMATIC) TpFrameDataLength,
                                                               CONST(uint16, AUTOMATIC) TpFrameId);
extern FUNC(uint8, EyeQDL_CODE) EyeQDL_GetFreeTxBufferNum(void);
/******************************************************************************
Declaration Of Function-like Macros
******************************************************************************/


/******************************************************************************
End Of File
******************************************************************************/

#endif /* EYEQDL_H_ */
