
#ifndef EYEQAPPL_CFG_H_
#define EYEQAPPL_CFG_H_ 1

/******************************************************************************

WBTL ELECTRONIC document

Copyright WBTL All rights reserved.

*******************************************************************************

@details
   <Describes details of this header file>

******************************************************************************/
/******************************************************************************
External Dependencies
******************************************************************************/
#include <Std_Types.h>

/******************************************************************************
Definition Of Constants
******************************************************************************/
#define EYEQAPPL_DATA_BUFF_SIZE           (16u)

#define EYEQAPPL_TX_RX_STS_IDLE           (0u)
#define EYEQAPPL_TX_RX_STS_TX_REQ_RCVED   (1u)
#define EYEQAPPL_TX_RX_STS_TX_SENDING     (2u)
#define EYEQAPPL_TX_RX_STS_WAIT_RESP      (3u)
#define EYEQAPPL_TX_RX_STS_RCVING         (4u)
#define EYEQAPPL_TX_RX_STS_FAILED         (5u)
#define EYEQAPPL_TX_RX_STS_NUM            (6u)


#define EYEQAPPL_MAIN_PERIOD_MS           (1u)
#define EYEQAPPL_TX_TIMEOUT_MS            (20u)
#define EYEQAPPL_TX_TIMEOUT_CNT           (EYEQAPPL_TX_TIMEOUT_MS / EYEQAPPL_MAIN_PERIOD_MS)
#define EYEQAPPL_RX_TIMEOUT_MS            (500u)
#define EYEQAPPL_RX_TIMEOUT_CNT           (EYEQAPPL_RX_TIMEOUT_MS / EYEQAPPL_MAIN_PERIOD_MS)
#define EYEQAPPL_REPORT_FLT_TIME_MS       (10u)
#define EYEQAPPL_REPORT_FLT_TIME_CNT      (EYEQAPPL_REPORT_FLT_TIME_MS / EYEQAPPL_MAIN_PERIOD_MS)

#define EYEQAPPL_FLAG_REPEAT_SERVICE_REQ  (1u << 0u)
#define EYEQAPPL_FLAG_INVALID_REQ         (1u << 1u)
#define EYEQAPPL_FLAG_OVERFLOW_REQ        (1u << 2u)
#define EYEQAPPL_FLAG_TX_TIMEOUT          (1u << 3u)
#define EYEQAPPL_FLAG_TX_FAILED           (1u << 4u)
#define EYEQAPPL_FLAG_TX_INVALID_ID_RCVED (1u << 5u)
#define EYEQAPPL_FLAG_RX_INVALID_MSG      (1u << 6u)
#define EYEQAPPL_FLAG_RX_QUEUE_BUSY       (1u << 7u)
#define EYEQAPPL_FLAG_RX_WRONG_STATE      (1u << 8u)

#define EYEQAPPL_FLAG_TX_FLT_MASK         (EYEQAPPL_FLAG_REPEAT_SERVICE_REQ | EYEQAPPL_FLAG_INVALID_REQ | EYEQAPPL_FLAG_OVERFLOW_REQ \
                                           | EYEQAPPL_FLAG_TX_TIMEOUT | EYEQAPPL_FLAG_TX_FAILED | EYEQAPPL_FLAG_TX_INVALID_ID_RCVED)
#define EYEQAPPL_FLAG_RX_FLT_MASK         (EYEQAPPL_FLAG_RX_INVALID_MSG | EYEQAPPL_FLAG_RX_QUEUE_BUSY | EYEQAPPL_FLAG_RX_WRONG_STATE)

#define EYEQAPPL_CALL_BACK_ON_NEW_FRAME   (STD_ON)

 /******************************************************************************
Declaration Of Types
******************************************************************************/

/******************************************************************************
Declaration Of Variables
******************************************************************************/

/******************************************************************************
Declaration Of Constant Data
******************************************************************************/

/******************************************************************************
Declaration Of Functions
******************************************************************************/

/******************************************************************************
Declaration Of Function-like Macros
******************************************************************************/

/******************************************************************************
End Of File
******************************************************************************/

#endif /* EYEQAPPL_CFG_H_ */
