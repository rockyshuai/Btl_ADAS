
#ifndef EYEQAPPL_H_
#define EYEQAPPL_H_ 1

/******************************************************************************

WBTL ELECTRONIC document

Copyright WBTL All rights reserved.

*******************************************************************************

@details
   <Describes details of this header file>

******************************************************************************/
/******************************************************************************
External Dependencies
******************************************************************************/
#include <Std_Types.h>

/******************************************************************************
Definition Of Constants
******************************************************************************/
/*  */


/******************************************************************************
Declaration Of Types
******************************************************************************/
/*!
 * @brief Appl callback Status, Used for return status of Application layer callback function for services
 * @param enum
 * @{
 */
#define EYEQAPPL_CB_STS_TX_OK             (0u)
#define EYEQAPPL_CB_STS_TX_FAILED         (1u)
#define EYEQAPPL_CB_STS_RX_NEW_FRAME      (2u)
#define EYEQAPPL_CB_STS_RX_OK             (3u)
#define EYEQAPPL_CB_STS_RX_FAILED         (4u)
#define EYEQAPPL_CB_STS_RX_DG_UNAVAL      (5u)
typedef VAR(uint8, TYPEDEF) EyeQAppl_CallbackStsType;
/*! @} */
/*
typedef struct EyeQAppl_TxPacketTypeTag
{
   uint8* PacketDataPtr;
   uint32 PacketDataLength;
   uint8 AppId;
   uint8 MespHeader[EYEQAPPL_MSG_MESP_HEADER_SIZE];
   boolean IsMesp;
}EyeQAppl_TxPacketType;*/

/******************************************************************************
Declaration Of Variables
******************************************************************************/

/******************************************************************************
Declaration Of Constant Data
******************************************************************************/

/******************************************************************************
Declaration Of Functions
******************************************************************************/
extern FUNC(void, EyeQAppl_CODE) EyeQAppl_Init(void);
extern FUNC(void, EyeQAppl_CODE) EyeQAppl_MainFunctionTx(void);
extern FUNC(void, EyeQAppl_CODE) EyeQAppl_MainFunctionRx(void);
extern FUNC(void, EyeQAppl_CODE) EyeQAppl_RequestLock(CONST(boolean, AUTOMATIC) Lock);
extern FUNC(boolean, EyeQAppl_CODE) EyeQAppl_IsLocked(void);
extern FUNC(Std_ReturnType, EyeQAppl_CODE) EyeQAppl_ReportTpRxFrame(
   P2CONST(uint8, AUTOMATIC, EyeQAppl_APPL_DATA) ApplMsgDataPtr,
   CONST(uint8, AUTOMATIC) AppId,
   CONST(uint32, AUTOMATIC) MsgLength,
   CONST(uint8, AUTOMATIC) CurrFrameDataLength,
   CONST(uint8, AUTOMATIC) TotalFrameNum,
   CONST(uint8, AUTOMATIC) CurrentFrameNum);
extern FUNC(Std_ReturnType, EyeQAppl_CODE) EyeQAppl_ReportTpTxSts(
   CONST(uint8, AUTOMATIC) AppId,
   CONST(boolean, AUTOMATIC) TxOk);
extern FUNC(Std_ReturnType, EyeQAppl_CODE) EyeQAppl_TxRequest(
   CONST(uint8, AUTOMATIC) ServiceId,
   CONST(uint8, AUTOMATIC) FunctionId);

/******************************************************************************
Declaration Of Function-like Macros
******************************************************************************/

/******************************************************************************
End Of File
******************************************************************************/

#endif /* EYEQAPPL_H_ */
