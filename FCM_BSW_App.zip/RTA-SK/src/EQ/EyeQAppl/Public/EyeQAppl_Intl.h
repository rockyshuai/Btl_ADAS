
#ifndef EYEQAPPL_INTL_H_
#define EYEQAPPL_INTL_H_ 1

/******************************************************************************

WBTL ELECTRONIC document

Copyright WBTL All rights reserved.

*******************************************************************************

@details
   <Describes details of this header file>

******************************************************************************/
/******************************************************************************
External Dependencies
******************************************************************************/
#include <Std_Types.h>

/******************************************************************************
Definition Of Constants
******************************************************************************/
#define EYEQAPPL_MSG_MESP_HEADER_SIZE     (4u)
#define EYEQAPPL_MSG_LOC_PROTOCOL         (0u)
#define EYEQAPPL_MSG_LOC_SERVICE_ID       (1u)
#define EYEQAPPL_MSG_LOC_FUNCTION_ID      (2u)
#define EYEQAPPL_MSG_LOC_MSG_TAG          (3u)
                                          
#define EYEQAPPL_PROTOCOL_MESP            (0x5Eu)
#define EYEQAPPL_PROTOCOL_DG              (0x00u)
#define EYEQAPPL_PROTOCOL_UNAVAILABLE     (0xFFu)
                                          
#define EYEQAPPL_MSG_TAG_CNT_MASK         (0x3Fu)
#define EYEQAPPL_MSG_TAG_REQ_REPLY_MASK   (0x80u)

#define EYEQAPPL_SHIFT_ONE_BYTE           (0x08u)

/******************************************************************************
Declaration Of Types
******************************************************************************/
typedef void (*EyeQAppl_RxCallbackFct)(EyeQAppl_CallbackStsType Status);

typedef struct EyeQAppl_UserReqConfigTypeTag
{
   /* Service Id Combined with Function Id, (ServiceId << 8u | FunctionId) */
   uint16 SrvFctId;

   /* Channel number */
   uint8 Channel;

   /* Channel number */
   uint8 Priority;

   /* Expected max response message length, same as RxRespBuffRef size */
   uint32 RxMaxRespLength;

   /* Address of Response length, used to return msg data length received */
   uint32* RxRespLength;

   /* Receive response buffer reference */
   uint8* RxRespBuffRef;

   /* Callback function address */
   EyeQAppl_RxCallbackFct CallbackFct;

   /* Command Length which is fixed */
   uint32 TxCmdLength;

   /* Command buffer reference */
   uint8* TxCmdBuffRef;

   /* Protocol (MESP = 0x5Eu) */
   uint8 Protocol;
} EyeQAppl_UserReqConfigType;

typedef struct EyeQAppl_TxRxDataTypeTag
{
   const EyeQAppl_UserReqConfigType* UserReqConfigPtr;
   uint32 RxDataOffset;
   uint32 TxDataLength;
   uint16 SrvFctId;
   uint16 TimeoutCnt;
   uint8 MespHeader[EYEQAPPL_MSG_MESP_HEADER_SIZE];
   uint8 UserReqConfIndex;
   uint8 TxRxstatus;
   uint8 Protocol;
   uint8 AppId;
   uint8 Priority;
   uint8 MsgTag;
   uint8 Channel;
}EyeQAppl_TxRxDataType;

typedef struct EyeQAppl_DataTypeTag
{
   uint32 StatusFlags;
   uint8 MsgTagCnt;
   uint8 ReportTimer;
   boolean Locked;
}EyeQAppl_DataType;

/******************************************************************************
Declaration Of Variables
******************************************************************************/
extern VAR(EyeQAppl_DataType, EyeQAppl_VAR)  EyeQAppl_Data;

/******************************************************************************
Declaration Of Constant Data
******************************************************************************/
extern CONST(EyeQAppl_UserReqConfigType, EyeQAppl_CONST) EyeQAppl_UserReqConfig[];
extern CONST(uint8, EyeQAppl_CONST) EyeQAppl_UserCfgSize;

/******************************************************************************
Declaration Of Functions
******************************************************************************/
extern FUNC(uint32, EyeQAppl_CODE) eyeqappl_GetMsgDataLength(CONST(uint16, AUTOMATIC) UserReqCfgIndex);
extern FUNC(void, EyeQAppl_CODE) eyeqappl_StatusFlagsProcess(void);
/******************************************************************************
Declaration Of Function-like Macros
******************************************************************************/
#define EyeQAppl_MsgTagSetReq(MsgTagCnt)             (MsgTagCnt & 0x7Fu)
#define EyeQAppl_MsgTagSetReply(MsgTagCnt)           (MsgTagCnt | 0x80u)
#define EyeQAppl_GetMsgTagReqReply(MsgTag)           (MsgTag & 0x80u)
#define EyeQAppl_GetMsgTagCnt(MsgTag)                (MsgTag & 0x3Fu)

#define EyeQAppl_GetSrvFctId(ServiceId, FunctionId)  (uint16)((ServiceId << EYEQAPPL_SHIFT_ONE_BYTE) | FunctionId)
#define EyeQAppl_GetServiceId(SrvFctId)              (uint8)(SrvFctId >> EYEQAPPL_SHIFT_ONE_BYTE)
#define EyeQAppl_GetFunctionId(SrvFctId)             (uint8)(SrvFctId)
/******************************************************************************
End Of File
******************************************************************************/

#endif /* EYEQAPPL_INTL_H_ */
