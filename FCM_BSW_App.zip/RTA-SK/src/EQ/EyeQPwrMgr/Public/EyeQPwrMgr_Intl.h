#ifndef EYEQPWRMGR_INTL_H_
#define EYEQPWRMGR_INTL_H_ 1

/******************************************************************************

*******************************************************************************

Overview of the interfaces:
   <Describes details of this header file>

******************************************************************************/
/******************************************************************************
EXTERNAL DEPENDENCIES
******************************************************************************/
#include "Std_Types.h"
#include "StMac.h"
#include "AdcAb.h"

#ifdef __cplusplus
extern "C" {
#endif
/******************************************************************************
DEFINITION OF CONSTANTS
******************************************************************************/

/******************************************************************************
DECLARATION OF TYPES
******************************************************************************/
/*
 *
 */
typedef struct EyeQPwrMgr_DataTypeTag
{
   /*
    * current state
    */
   StMac_StType CurrentState;
   /*
    * current event
    */
   StMac_EventType CurrentEvent;

   /* External power request */
   EyeQPwrMgr_PwrReqType PowerRequest;
   EyeQPwrMgr_ApplModReqType StartupApplMode;
   Dio_LevelType RstPinLevel;

   /*
    * ADC read values of all power voltages
    */
   AdcAb_VoltType PwrPS3V3Adc;
   AdcAb_VoltType Pwr3V3Adc;
   AdcAb_VoltType Pwr1V0Adc;
   AdcAb_VoltType Pwr1V1Adc;
   AdcAb_VoltType Pwr1V8Adc;
   /*
    * Init delay of state
    */
   uint16 StateInitDelay;
   /*
    * Each power status
    */
   EyeQPwrMgr_PwrStsType  PwrPS3V3Status;
   EyeQPwrMgr_PwrStsType  Pwr3V3Status;
   EyeQPwrMgr_PwrStsType  Pwr1V0Status;
   EyeQPwrMgr_PwrStsType  Pwr1V1Status;
   EyeQPwrMgr_PwrStsType  Pwr1V8Status;
   EyeQPwrMgr_PwrStsType  PSGoodStatus;
   /*
    * current status of power
    */
   EyeQPwrMgr_PwrStsType Status;

   sint8 StateTestDebounceCnt;

   uint8 ResetCnt;
   boolean ContinueNextEvent;
   boolean IsQuickOff;
} EyeQPwrMgr_DataType;

/******************************************************************************
DECLARATION OF VARIABLES
******************************************************************************/
extern VAR(EyeQPwrMgr_DataType, EYEQPWRMGR_VAR) eyeqpwrmgr_Data;

/******************************************************************************
DECLARATION OF CONSTANT DATA
******************************************************************************/

/******************************************************************************
DECLARATION OF FUNCTIONS
******************************************************************************/

/******************************************************************************
DECLARATION OF FUNCTION-LIKE MACROS
******************************************************************************/


#ifdef __cplusplus
}
#endif

#endif /* EYEQPWRMGR_INTL_H_ */
	
