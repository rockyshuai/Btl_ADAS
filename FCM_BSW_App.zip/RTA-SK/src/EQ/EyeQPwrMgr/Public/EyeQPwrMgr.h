#ifndef EYEQPWRMGR_H_
#define EYEQPWRMGR_H_ 1

/******************************************************************************

*******************************************************************************

Overview of the interfaces:
   <Describes details of this header file>

******************************************************************************/
/******************************************************************************
EXTERNAL DEPENDENCIES
******************************************************************************/
#include "Std_Types.h"
#include "EyeQPwrMgr_Types.h"
#include "EyeQPwrMgr_Cfg.h"
#include "Dio.h"

#ifdef __cplusplus
extern "C" {
#endif
/******************************************************************************
DEFINITION OF CONSTANTS
******************************************************************************/

/******************************************************************************
DECLARATION OF TYPES
******************************************************************************/

/******************************************************************************
DECLARATION OF VARIABLES
******************************************************************************/

/******************************************************************************
DECLARATION OF CONSTANT DATA
******************************************************************************/

/******************************************************************************
DECLARATION OF FUNCTIONS
******************************************************************************/
extern FUNC(void, EYEQPWRMGR_CODE) EyeQPwrMgr_Init(void);
extern FUNC(void, EYEQPWRMGR_CODE) EyeQPwrMgr_MainFunction(void);
extern FUNC(boolean, EYEQPWRMGR_CODE) EyeQPwrMgr_IsReadyOK(void);
extern FUNC(boolean, EYEQPWRMGR_CODE) EyeQPwrMgr_IsPowerOn(void);
extern FUNC(boolean, EYEQPWRMGR_CODE) EyeQPwrMgr_IsPowerOff(void);
extern FUNC(void, EYEQPWRMGR_CODE) EyeQPwrMgr_RequestPowerOn(void);
extern FUNC(void, EYEQPWRMGR_CODE) EyeQPwrMgr_RequestPowerOff(void);
extern FUNC(void, EYEQPWRMGR_CODE) EyeQPwrMgr_RequestPowerQuickOff(void);
extern FUNC(void, EYEQPWRMGR_CODE) EyeQPwrMgr_ForcePowerImmediateOff(void);
extern FUNC(void, EYEQPWRMGR_CODE) EyeQPwrMgr_RequestPowerReset(void);
extern FUNC(Std_ReturnType, EYEQPWRMGR_CODE) EyeQPwrMgr_SetStartupApplMode(CONST(EyeQPwrMgr_ApplModReqType, AUTOMATIC) ApplMode);
extern FUNC(void, EYEQPWRMGR_CODE) EyeQPwrMgr_AssertReset(void);
extern FUNC(void, EYEQPWRMGR_CODE) EyeQPwrMgr_DeAssertReset(void);
extern FUNC(void, EYEQPWRMGR_CODE) EyeQPwrMgr_RstPinReset(void);
extern FUNC(Dio_LevelType, EYEQPWRMGR_CODE) EyeQPwrMgr_GetRstPinCmdLvl(void);
extern FUNC(Dio_LevelType, EYEQPWRMGR_CODE) EyeQPwrMgr_GetRstPinActualLvl(void);
/******************************************************************************
DECLARATION OF FUNCTION-LIKE MACROS
******************************************************************************/


#ifdef __cplusplus
}
#endif

#endif /* EYEQPWRMGR_H_ */
	
