
#ifndef EYEQPWRMGR_CFG_H_
#define EYEQPWRMGR_CFG_H_ 1

/******************************************************************************



*******************************************************************************

Overview of the interfaces:
   <Describes details of this header file>

******************************************************************************/

/******************************************************************************
EXTERNAL DEPENDENCIES
******************************************************************************/
#include "Std_Types.h"
#include "EyeQPwrMgr_Types.h"
#include "Dio.h"
//#include "Adc.h"

#ifdef __cplusplus
extern "C" {
#endif
/******************************************************************************
DEFINITION OF CONSTANTS
******************************************************************************/
#define EYEQPWRMGR_ETH_ENA                           (STD_OFF)
#define EYEQPWRMGR_PS_HOLD_ENA                       (STD_OFF)


#define EYEQPWRMGR_MAIN_UPDATE_MS                    (5u)
/* Init delay configurations for each state */
#define EYEQPWRMGR_ST_PWR_UP_INIT_INIT_DELAY_MS      (20u)
#define EYEQPWRMGR_ST_PS_HOLD_ON_INIT_DELAY_MS       (10u)
#define EYEQPWRMGR_ST_3V3_ON_INIT_DELAY_MS           (10u)
#define EYEQPWRMGR_ST_1V0_ON_INIT_DELAY_MS           (10u)
#define EYEQPWRMGR_ST_1V8_ON_INIT_DELAY_MS           (10u)
#define EYEQPWRMGR_ST_1V1_ON_INIT_DELAY_MS           (10u)
#define EYEQPWRMGR_ST_NRST_ON_INIT_DELAY_MS          (0u)
#define EYEQPWRMGR_ST_RUN_INIT_DELAY_MS              (0u)
#define EYEQPWRMGR_ST_SHUTDOWN_INIT_INIT_DELAY_MS    (0u)
#define EYEQPWRMGR_ST_NRST_OFF_INIT_DELAY_MS         (20u)
#define EYEQPWRMGR_ST_1V1_OFF_INIT_DELAY_MS          (20u)
#define EYEQPWRMGR_ST_1V8_OFF_INIT_DELAY_MS          (20u)
#define EYEQPWRMGR_ST_1V0_OFF_INIT_DELAY_MS          (20u)
#define EYEQPWRMGR_ST_3V3_OFF_INIT_DELAY_MS          (50u)
#define EYEQPWRMGR_ST_PS_HOLD_OFF_INIT_DELAY_MS      (0u)
#define EYEQPWRMGR_ST_OFF_INIT_DELAY_MS              (0u)
#define EYEQPWRMGR_ST_RUN_RST_PIN_RESET_DELAY_MS     (5u)
/* Quick shutdown delays */
#define EYEQPWRMGR_ST_SHUTDOWN_INIT_INIT_DELAY_MS_Q  (0u)
#define EYEQPWRMGR_ST_NRST_OFF_INIT_DELAY_MS_Q       (5u)
#define EYEQPWRMGR_ST_1V1_OFF_INIT_DELAY_MS_Q        (5u)
#define EYEQPWRMGR_ST_1V8_OFF_INIT_DELAY_MS_Q        (5u)
#define EYEQPWRMGR_ST_1V0_OFF_INIT_DELAY_MS_Q        (5u)
#define EYEQPWRMGR_ST_3V3_OFF_INIT_DELAY_MS_Q        (2000u)
#define EYEQPWRMGR_ST_PS_HOLD_OFF_INIT_DELAY_MS_Q    (0u)
#define EYEQPWRMGR_ST_OFF_INIT_DELAY_MS_Q            (0u)

#define EYEQPWRMGR_ST_PWR_UP_INIT_INIT_DELAY         (EYEQPWRMGR_ST_PWR_UP_INIT_INIT_DELAY_MS   / EYEQPWRMGR_MAIN_UPDATE_MS)
#define EYEQPWRMGR_ST_PS_HOLD_ON_INIT_DELAY          (EYEQPWRMGR_ST_PS_HOLD_ON_INIT_DELAY_MS    / EYEQPWRMGR_MAIN_UPDATE_MS)
#define EYEQPWRMGR_ST_3V3_ON_INIT_DELAY              (EYEQPWRMGR_ST_3V3_ON_INIT_DELAY_MS        / EYEQPWRMGR_MAIN_UPDATE_MS)
#define EYEQPWRMGR_ST_1V0_ON_INIT_DELAY              (EYEQPWRMGR_ST_1V0_ON_INIT_DELAY_MS        / EYEQPWRMGR_MAIN_UPDATE_MS)
#define EYEQPWRMGR_ST_1V8_ON_INIT_DELAY              (EYEQPWRMGR_ST_1V8_ON_INIT_DELAY_MS        / EYEQPWRMGR_MAIN_UPDATE_MS)
#define EYEQPWRMGR_ST_1V1_ON_INIT_DELAY              (EYEQPWRMGR_ST_1V1_ON_INIT_DELAY_MS        / EYEQPWRMGR_MAIN_UPDATE_MS)
#define EYEQPWRMGR_ST_NRST_ON_INIT_DELAY             (EYEQPWRMGR_ST_NRST_ON_INIT_DELAY_MS       / EYEQPWRMGR_MAIN_UPDATE_MS)
#define EYEQPWRMGR_ST_RUN_INIT_DELAY                 (EYEQPWRMGR_ST_RUN_INIT_DELAY_MS           / EYEQPWRMGR_MAIN_UPDATE_MS)
#define EYEQPWRMGR_ST_SHUTDOWN_INIT_INIT_DELAY       (EYEQPWRMGR_ST_SHUTDOWN_INIT_INIT_DELAY_MS / EYEQPWRMGR_MAIN_UPDATE_MS)
#define EYEQPWRMGR_ST_NRST_OFF_INIT_DELAY            (EYEQPWRMGR_ST_NRST_OFF_INIT_DELAY_MS      / EYEQPWRMGR_MAIN_UPDATE_MS)
#define EYEQPWRMGR_ST_1V1_OFF_INIT_DELAY             (EYEQPWRMGR_ST_1V1_OFF_INIT_DELAY_MS       / EYEQPWRMGR_MAIN_UPDATE_MS)
#define EYEQPWRMGR_ST_1V8_OFF_INIT_DELAY             (EYEQPWRMGR_ST_1V8_OFF_INIT_DELAY_MS       / EYEQPWRMGR_MAIN_UPDATE_MS)
#define EYEQPWRMGR_ST_1V0_OFF_INIT_DELAY             (EYEQPWRMGR_ST_1V0_OFF_INIT_DELAY_MS       / EYEQPWRMGR_MAIN_UPDATE_MS)
#define EYEQPWRMGR_ST_3V3_OFF_INIT_DELAY             (EYEQPWRMGR_ST_3V3_OFF_INIT_DELAY_MS       / EYEQPWRMGR_MAIN_UPDATE_MS)
#define EYEQPWRMGR_ST_PS_HOLD_OFF_INIT_DELAY         (EYEQPWRMGR_ST_PS_HOLD_OFF_INIT_DELAY_MS   / EYEQPWRMGR_MAIN_UPDATE_MS)
#define EYEQPWRMGR_ST_OFF_INIT_DELAY                 (EYEQPWRMGR_ST_OFF_INIT_DELAY_MS           / EYEQPWRMGR_MAIN_UPDATE_MS)
#define EYEQPWRMGR_ST_RUN_RST_PIN_RESET_DELAY        (EYEQPWRMGR_ST_RUN_RST_PIN_RESET_DELAY_MS  / EYEQPWRMGR_MAIN_UPDATE_MS)
	
/* Quick shutdown delays */
#define EYEQPWRMGR_ST_SHUTDOWN_INIT_INIT_DELAY_Q     (EYEQPWRMGR_ST_SHUTDOWN_INIT_INIT_DELAY_MS_Q / EYEQPWRMGR_MAIN_UPDATE_MS)
#define EYEQPWRMGR_ST_NRST_OFF_INIT_DELAY_Q          (EYEQPWRMGR_ST_NRST_OFF_INIT_DELAY_MS_Q      / EYEQPWRMGR_MAIN_UPDATE_MS)
#define EYEQPWRMGR_ST_1V1_OFF_INIT_DELAY_Q           (EYEQPWRMGR_ST_1V1_OFF_INIT_DELAY_MS_Q       / EYEQPWRMGR_MAIN_UPDATE_MS)
#define EYEQPWRMGR_ST_1V8_OFF_INIT_DELAY_Q           (EYEQPWRMGR_ST_1V8_OFF_INIT_DELAY_MS_Q       / EYEQPWRMGR_MAIN_UPDATE_MS)
#define EYEQPWRMGR_ST_1V0_OFF_INIT_DELAY_Q           (EYEQPWRMGR_ST_1V0_OFF_INIT_DELAY_MS_Q       / EYEQPWRMGR_MAIN_UPDATE_MS)
#define EYEQPWRMGR_ST_3V3_OFF_INIT_DELAY_Q           (EYEQPWRMGR_ST_3V3_OFF_INIT_DELAY_MS_Q       / EYEQPWRMGR_MAIN_UPDATE_MS)
#define EYEQPWRMGR_ST_PS_HOLD_OFF_INIT_DELAY_Q       (EYEQPWRMGR_ST_PS_HOLD_OFF_INIT_DELAY_MS_Q   / EYEQPWRMGR_MAIN_UPDATE_MS)
#define EYEQPWRMGR_ST_OFF_INIT_DELAY_Q               (EYEQPWRMGR_ST_OFF_INIT_DELAY_MS_Q           / EYEQPWRMGR_MAIN_UPDATE_MS)

/* Pass count of test configurations for each state */
#define EYEQPWRMGR_ST_PWR_UP_INIT_TEST_PASS_CNT      (2)
#define EYEQPWRMGR_ST_3V3_ON_TEST_PASS_CNT           (2)
#define EYEQPWRMGR_ST_1V0_ON_TEST_PASS_CNT           (2)
#define EYEQPWRMGR_ST_1V1_ON_TEST_PASS_CNT           (2)
#define EYEQPWRMGR_ST_1V8_ON_TEST_PASS_CNT           (2)
#define EYEQPWRMGR_ST_RUN_TEST_PASS_CNT              (3)
#define EYEQPWRMGR_ST_SHUTDOWN_INIT_TEST_PASS_CNT    (2)

/* Fail count of test configurations for each state */
#define EYEQPWRMGR_ST_PWR_UP_INIT_TEST_FAIL_CNT      (-2)
#define EYEQPWRMGR_ST_3V3_ON_TEST_FAIL_CNT           (-2)
#define EYEQPWRMGR_ST_1V0_ON_TEST_FAIL_CNT           (-2)
#define EYEQPWRMGR_ST_1V1_ON_TEST_FAIL_CNT           (-2)
#define EYEQPWRMGR_ST_1V8_ON_TEST_FAIL_CNT           (-2)
#define EYEQPWRMGR_ST_RUN_TEST_FAIL_CNT              (-5)
#define EYEQPWRMGR_ST_SHUTDOWN_INIT_TEST_FAIL_CNT    (-2)
												   
/* DIO control channels for each power */          
#define EYEQPWRMGR_DIO_3V3                           (DioConf_DioChannel_EQ_3V3_EN)
#define EYEQPWRMGR_DIO_1V0                           (DioConf_DioChannel_EQ_1V0_EN)
#define EYEQPWRMGR_DIO_1V8                           (DioConf_DioChannel_EQ_1V8_EN)
#define EYEQPWRMGR_DIO_1V1                           (DioConf_DioChannel_EQ_1V1_EN)
#define EYEQPWRMGR_DIO_EYEQ_NRST                     (DioConf_DioChannel_EQ_NRST)
#define EYEQPWRMGR_DIO_ACC_STS                       (DioConf_DioChannel_ACC_STATUS)
#if (EYEQPWRMGR_PS_HOLD_ENA == STD_ON)
#define EYEQPWRMGR_DIO_PS_HOLD                       (DioConf_DioChannel_PS_HOLD)
#endif
#define EYEQPWRMGR_DIO_PS_GOOD                       (DioConf_DioChannel_PS_GOOD)
#if (EYEQPWRMGR_ETH_ENA == STD_ON)
#define EYEQPWRMGR_DIO_ETH_EN                        (DioConf_DioChannel_MCU_ETH_EN)
#define EYEQPWRMGR_DIO_ETH_RST                       (DioConf_DioChannel_ETH_RST)
#endif
/* TODO: zke: config the right DIO channels */
#define EYEQPWRMGR_DIO_STARTUP0                      (DioConf_DioChannel_EQ_STARTUP_0)
#define EYEQPWRMGR_DIO_STARTUP1                      (DioConf_DioChannel_EQ_STARTUP_1)
#define EYEQPWRMGR_DIO_STARTUP2                      (DioConf_DioChannel_EQ_STARTUP_2)
#define EYEQPWRMGR_DIO_CATALOG0                      (DioConf_DioChannel_EQ_CatalogID0)
#define EYEQPWRMGR_DIO_CATALOG1                      (DioConf_DioChannel_EQ_CatalogID1)
#define EYEQPWRMGR_DIO_CATALOG2                      (DioConf_DioChannel_EQ_CatalogID2)

/* ADC channels for each power */
#define EYEQPWRMGR_ADC_CHANNEL_PS_3V3                (ADCAB_CHANNEL_3V3)
#define EYEQPWRMGR_ADC_CHANNEL_3V3                   (ADCAB_CHANNEL_EQ_3V3)
#define EYEQPWRMGR_ADC_CHANNEL_1V0                   (ADCAB_CHANNEL_EQ_1V0)
#define EYEQPWRMGR_ADC_CHANNEL_1V8                   (ADCAB_CHANNEL_IMG_1V8)
#define EYEQPWRMGR_ADC_CHANNEL_1V1                   (ADCAB_CHANNEL_DDR_1V1)


/* ADC voltage limits for each power */
#define EYEQPWRMGR_ADC_PS_3V3_LMT_MAX                ((AdcAb_VoltType)(3.3f * 1.05f * ADCAB_VOLT_RES))
#define EYEQPWRMGR_ADC_PS_3V3_LMT_MIN                ((AdcAb_VoltType)(3.3f * 0.95f * ADCAB_VOLT_RES))
#define EYEQPWRMGR_ADC_3V3_LMT_MAX                   ((AdcAb_VoltType)(3.3f * 1.05f * ADCAB_VOLT_RES))
#define EYEQPWRMGR_ADC_3V3_LMT_MIN                   ((AdcAb_VoltType)(3.3f * 0.95f * ADCAB_VOLT_RES))
#define EYEQPWRMGR_ADC_1V0_LMT_MAX                   ((AdcAb_VoltType)(1.0f * 1.03f * ADCAB_VOLT_RES))
#define EYEQPWRMGR_ADC_1V0_LMT_MIN                   ((AdcAb_VoltType)(1.0f * 0.97f * ADCAB_VOLT_RES))
#define EYEQPWRMGR_ADC_1V1_LMT_MAX                   ((AdcAb_VoltType)(1.1f * 1.05f * ADCAB_VOLT_RES))
#define EYEQPWRMGR_ADC_1V1_LMT_MIN                   ((AdcAb_VoltType)(1.1f * 0.95f * ADCAB_VOLT_RES))
#define EYEQPWRMGR_ADC_1V8_LMT_MAX                   ((AdcAb_VoltType)(1.8f * 1.05f * ADCAB_VOLT_RES))
#define EYEQPWRMGR_ADC_1V8_LMT_MIN                   ((AdcAb_VoltType)(1.8f * 0.95f * ADCAB_VOLT_RES))

/* Number of resets allowed in a operation cycle */
#define EYEQPWRMGR_RESET_LMT                         (3u)

/* EyeQ catalog ID pin setup (bit 0, 1, 2 represents MCU Catalog ID 0, 1, 2 and EyeQ GPIO A16, A17, A19) */
#define EYEQPWRMGR_CATALOG_PINS                      (0x0u)

/******************************************************************************
DECLARATION OF TYPES
******************************************************************************/

/******************************************************************************
DECLARATION OF VARIABLES
******************************************************************************/

/******************************************************************************
DECLARATION OF CONSTANT DATA
******************************************************************************/

/******************************************************************************
DECLARATION OF FUNCTIONS
******************************************************************************/
extern FUNC(void, EYEQPWRMGR_CODE) eyeqpwrmgr_Publish(void);
extern FUNC(void, EYEQPWRMGR_CODE) eyeqpwrmgr_SetupEyeQGpio(void);

/******************************************************************************
DECLARATION OF FUNCTION-LIKE MACROS
******************************************************************************/

#ifdef __cplusplus
}
#endif

#endif /* EYEQPWRMGR_CFG_H_ */
	
