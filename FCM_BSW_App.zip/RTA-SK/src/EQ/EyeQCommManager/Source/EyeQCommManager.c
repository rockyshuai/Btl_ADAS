
/******************************************************************************

WBTL ELECTRONIC document

Copyright WBTL. All rights reserved.

******************************************************************************/
/******************************************************************************

@details
   <Describes details of this component implementation and design>

******************************************************************************/
/******************************************************************************
External Dependencies
******************************************************************************/
#include "EyeQCommManager.h"
#include "EyeQCommManager_Intl.h"
#include "EyeQCommManager_Cfg.h"
#include <EyeQSpi.h>
#include <EyeQDL.h>
#include <EyeQTp.h>
#include <EyeQAppl.h>
#include <EyeQMespMgr.h>
#include <EyeQProtMgr.h>
#include <EyeQSnsrMgr.h>
#include <EyeQStMgr.h>
#include <EyeQPwrMgr.h>

/******************************************************************************
Component Defines
******************************************************************************/

/******************************************************************************
Component Types
******************************************************************************/

/******************************************************************************
Declaration of Local Functions
******************************************************************************/

#define EyeQCommManager_START_SEC_VAR
#include "EyeQCommManager_MemMap.h"
/******************************************************************************
Definition Of Local Variables
******************************************************************************/

/******************************************************************************
Definition Of Global Variables
******************************************************************************/

#define EyeQCommManager_STOP_SEC_VAR
#include "EyeQCommManager_MemMap.h"

#define EyeQCommManager_START_SEC_CONST
#include "EyeQCommManager_MemMap.h"
/******************************************************************************
Definition Of Local Constant Data
******************************************************************************/

/******************************************************************************
Definition Of Global Constant Data
******************************************************************************/

#define EyeQCommManager_STOP_SEC_CONST
#include "EyeQCommManager_MemMap.h"
/******************************************************************************
Component Function-like Macros
******************************************************************************/

/******************************************************************************
Definition Of APIs
******************************************************************************/
#define EyeQCommManager_START_SEC_CODE
#include "EyeQCommManager_MemMap.h"

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQCommManager_CODE) EyeQCommManager_Init(void)
{
   EyeQSpi_Init();
   EyeQDL_Init();
   EyeQTp_Init();
   EyeQAppl_Init();
   EyeQMespMgr_Init();
   EyeQProtMgr_Init();
   EyeQSnsrMgr_Init();
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQCommManager_CODE) EyeQCommManager_MainFunction(void)
{
   EyeQAppl_MainFunctionTx();
   EyeQTp_MainFunctionTx();
   EyeQDL_MainFunctionTx();
   EyeQSpi_MainFunction();

   EyeQDL_MainFunctionRx();
   EyeQTp_MainFunctionRx();
   EyeQAppl_MainFunctionRx();

   EyeQProtMgr_MainFunction();
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQCommManager_CODE) EyeQCommManager_MainFunction5ms(void)
{
   EyeQMespMgr_MainFunction();
   EyeQSnsrMgr_MainFunction5ms();
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQCommManager_CODE) EyeQCommManager_SoftResetInit(void)
{
   EyeQCommManager_Init();
   EyeQDL_SoftResetInit();
}

/******************************************************************************
* @details
*    Describe details of the function
* @param[in]
*
* @param[out]
*
* @return
*
* @notes
*
******************************************************************************/
FUNC(void, EyeQCommManager_CODE) EyeQCommManager_HardResetInit(void)
{
   EyeQCommManager_Init();
}

#define EyeQCommManager_STOP_SEC_CODE
#include "EyeQCommManager_MemMap.h"
/******************************************************************************
End Of File
******************************************************************************/
