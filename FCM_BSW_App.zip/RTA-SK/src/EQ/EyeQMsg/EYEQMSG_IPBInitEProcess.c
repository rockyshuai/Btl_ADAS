

/*****************************************************************************
                  Include files
*****************************************************************************/
/* The suggested include file order is: */
#include "EyeQ_defs.h"    /* EyeQ project common definitions file    */

#include "EYEQMSG_IPBInitEProcess.h"

/*****************************************************************************
                  Local symbolic constants
*****************************************************************************/
/*****************************************************************************
                  Local types, enums definitions
*****************************************************************************/
/*****************************************************************************
                  Local function prototypes
*****************************************************************************/
/*****************************************************************************
                  Local object definitions
*****************************************************************************/
/*****************************************************************************
                  Exported object definitions
*****************************************************************************/
EYEQMSG_IPBINITE_Params_t   EYEQMSG_IPBINITE_Params_s;
EYEQMSG_IPBINITE_Params_t   EYEQMSG_IPBINITE_ParamsApp_s;
/*****************************************************************************
                  Local function-like macros
*****************************************************************************/
/*****************************************************************************
                  Local defined macros
*****************************************************************************/
/*****************************************************************************
                  Function definitions
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_IPBINITE_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_IPBINITE_Params_t * pIPB_Init_setE - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IPB_Init_setE message 
*    IPB_Init_setE message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IPB_Init_setE message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_IPBINITE_ParamsApp_MsgDataStruct( EYEQMSG_IPBINITE_Params_t * pIPB_Init_setE )
{
   Std_ReturnType status = C_SIG_INVALID;
   if( pIPB_Init_setE != C_NULL_P )
   {
      status = C_SIG_VALID;
      * pIPB_Init_setE = EYEQMSG_IPBINITE_ParamsApp_s;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pIIPB_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Zero_byte
*    IIPB_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Zero_byte signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Zero_byte( uint8 * pIIPB_Zero_byte )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pIIPB_Zero_byte != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Zero_byte_b8;
      * pIIPB_Zero_byte = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_ZERO_BYTE_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pIIPB_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Protocol_Version
*    IIPB_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Protocol_Version signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Protocol_Version( uint8 * pIIPB_Protocol_Version )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pIIPB_Protocol_Version != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Protocol_Version_b8;
      * pIIPB_Protocol_Version = signal_value;
      if( (signal_value >= C_EYEQMSG_IPBINITE_IIPB_PROTOCOL_VERSION_RMIN ) 
          && (signal_value <= C_EYEQMSG_IPBINITE_IIPB_PROTOCOL_VERSION_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Optional_Signals
*
* FUNCTION ARGUMENTS:
*    uint8 * pIIPB_Optional_Signals - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Optional_Signals
*    IIPB_Optional_Signals returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Optional_Signals signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Optional_Signals( uint8 * pIIPB_Optional_Signals )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pIIPB_Optional_Signals != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Optional_Signals_b8;
      * pIIPB_Optional_Signals = signal_value;
      if( (signal_value >= C_EYEQMSG_IPBINITE_IIPB_OPTIONAL_SIGNALS_RMIN ) 
          && (signal_value <= C_EYEQMSG_IPBINITE_IIPB_OPTIONAL_SIGNALS_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_AdhereToGapSensitivity_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEAdhereToGapSensitivityV * pAdhereToGapSensitivity_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of AdhereToGapSensitivity_V
*    AdhereToGapSensitivity_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns AdhereToGapSensitivity_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_AdhereToGapSensitivity_V( IPBINITEAdhereToGapSensitivityV * pAdhereToGapSensitivity_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEAdhereToGapSensitivityV signal_value;
   
   if( pAdhereToGapSensitivity_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.AdhereToGapSensitivity_V_b1;
      * pAdhereToGapSensitivity_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_AdhereToGapSensitivity
*
* FUNCTION ARGUMENTS:
*    IPBINITEAdhereToGapSensitivity * pAdhereToGapSensitivity - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of AdhereToGapSensitivity
*    AdhereToGapSensitivity returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns AdhereToGapSensitivity signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_AdhereToGapSensitivity( IPBINITEAdhereToGapSensitivity * pAdhereToGapSensitivity )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEAdhereToGapSensitivity signal_value;
   
   if( pAdhereToGapSensitivity != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.AdhereToGapSensitivity_b1;
      * pAdhereToGapSensitivity = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_AEB_BrakeToStillMode_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEAEBBrakeToStillModeV * pAEB_BrakeToStillMode_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of AEB_BrakeToStillMode_V
*    AEB_BrakeToStillMode_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns AEB_BrakeToStillMode_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_AEB_BrakeToStillMode_V( IPBINITEAEBBrakeToStillModeV * pAEB_BrakeToStillMode_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEAEBBrakeToStillModeV signal_value;
   
   if( pAEB_BrakeToStillMode_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.AEB_BrakeToStillMode_V_b1;
      * pAEB_BrakeToStillMode_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_AEB_BrakeToStillMode
*
* FUNCTION ARGUMENTS:
*    IPBINITEAEBBrakeToStillMode * pAEB_BrakeToStillMode - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of AEB_BrakeToStillMode
*    AEB_BrakeToStillMode returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns AEB_BrakeToStillMode signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_AEB_BrakeToStillMode( IPBINITEAEBBrakeToStillMode * pAEB_BrakeToStillMode )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEAEBBrakeToStillMode signal_value;
   
   if( pAEB_BrakeToStillMode != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.AEB_BrakeToStillMode_b2;
      * pAEB_BrakeToStillMode = signal_value;
      if( (signal_value >= C_EYEQMSG_IPBINITE_AEB_BRAKETOSTILLMODE_RMIN ) 
          && (signal_value <= C_EYEQMSG_IPBINITE_AEB_BRAKETOSTILLMODE_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_1_V
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_1_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_1_V
*    IIPB_Buffer_1_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_1_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_1_V( boolean * pIIPB_Buffer_1_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_1_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_1_V_b1;
      * pIIPB_Buffer_1_V = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_1_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_1
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_1
*    IIPB_Buffer_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_1 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_1( boolean * pIIPB_Buffer_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_1_b1;
      * pIIPB_Buffer_1 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_AEB_Deceleration_0_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEAEBDeceleration0V * pAEB_Deceleration_0_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of AEB_Deceleration_0_V
*    AEB_Deceleration_0_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns AEB_Deceleration_0_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_AEB_Deceleration_0_V( IPBINITEAEBDeceleration0V * pAEB_Deceleration_0_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEAEBDeceleration0V signal_value;
   
   if( pAEB_Deceleration_0_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.AEB_Deceleration_0_V_b1;
      * pAEB_Deceleration_0_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_AEB_Deceleration_0
*
* FUNCTION ARGUMENTS:
*    uint16 * pAEB_Deceleration_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of AEB_Deceleration_0
*    AEB_Deceleration_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns AEB_Deceleration_0 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_AEB_Deceleration_0( uint16 * pAEB_Deceleration_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pAEB_Deceleration_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.AEB_Deceleration_0_b10;
      * pAEB_Deceleration_0 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_AEB_DECELERATION_0_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_AEB_Deceleration_1_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEAEBDeceleration1V * pAEB_Deceleration_1_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of AEB_Deceleration_1_V
*    AEB_Deceleration_1_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns AEB_Deceleration_1_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_AEB_Deceleration_1_V( IPBINITEAEBDeceleration1V * pAEB_Deceleration_1_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEAEBDeceleration1V signal_value;
   
   if( pAEB_Deceleration_1_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.AEB_Deceleration_1_V_b1;
      * pAEB_Deceleration_1_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_AEB_Deceleration_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pAEB_Deceleration_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of AEB_Deceleration_1
*    AEB_Deceleration_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns AEB_Deceleration_1 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_AEB_Deceleration_1( uint16 * pAEB_Deceleration_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pAEB_Deceleration_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.AEB_Deceleration_1_b10;
      * pAEB_Deceleration_1 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_AEB_DECELERATION_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_AEB_Deceleration_2_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEAEBDeceleration2V * pAEB_Deceleration_2_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of AEB_Deceleration_2_V
*    AEB_Deceleration_2_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns AEB_Deceleration_2_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_AEB_Deceleration_2_V( IPBINITEAEBDeceleration2V * pAEB_Deceleration_2_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEAEBDeceleration2V signal_value;
   
   if( pAEB_Deceleration_2_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.AEB_Deceleration_2_V_b1;
      * pAEB_Deceleration_2_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_AEB_Deceleration_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pAEB_Deceleration_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of AEB_Deceleration_2
*    AEB_Deceleration_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns AEB_Deceleration_2 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_AEB_Deceleration_2( uint16 * pAEB_Deceleration_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pAEB_Deceleration_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.AEB_Deceleration_2_b10;
      * pAEB_Deceleration_2 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_AEB_DECELERATION_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_AEB_Deceleration_Reduction_0_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEAEBDecelerationReduction0V * pAEB_Deceleration_Reduction_0_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of AEB_Deceleration_Reduction_0_V
*    AEB_Deceleration_Reduction_0_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns AEB_Deceleration_Reduction_0_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_AEB_Deceleration_Reduction_0_V( IPBINITEAEBDecelerationReduction0V * pAEB_Deceleration_Reduction_0_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEAEBDecelerationReduction0V signal_value;
   
   if( pAEB_Deceleration_Reduction_0_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.AEB_Deceleration_Reduction_0_V_b1;
      * pAEB_Deceleration_Reduction_0_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_AEB_Deceleration_Reduction_0
*
* FUNCTION ARGUMENTS:
*    uint8 * pAEB_Deceleration_Reduction_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of AEB_Deceleration_Reduction_0
*    AEB_Deceleration_Reduction_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns AEB_Deceleration_Reduction_0 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_AEB_Deceleration_Reduction_0( uint8 * pAEB_Deceleration_Reduction_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pAEB_Deceleration_Reduction_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.AEB_Deceleration_Reduction_0_b8;
      * pAEB_Deceleration_Reduction_0 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_AEB_DECELERATION_REDUCTION_0_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_AEB_Deceleration_Reduction_1_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEAEBDecelerationReduction1V * pAEB_Deceleration_Reduction_1_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of AEB_Deceleration_Reduction_1_V
*    AEB_Deceleration_Reduction_1_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns AEB_Deceleration_Reduction_1_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_AEB_Deceleration_Reduction_1_V( IPBINITEAEBDecelerationReduction1V * pAEB_Deceleration_Reduction_1_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEAEBDecelerationReduction1V signal_value;
   
   if( pAEB_Deceleration_Reduction_1_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.AEB_Deceleration_Reduction_1_V_b1;
      * pAEB_Deceleration_Reduction_1_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_AEB_Deceleration_Reduction_1
*
* FUNCTION ARGUMENTS:
*    uint8 * pAEB_Deceleration_Reduction_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of AEB_Deceleration_Reduction_1
*    AEB_Deceleration_Reduction_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns AEB_Deceleration_Reduction_1 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_AEB_Deceleration_Reduction_1( uint8 * pAEB_Deceleration_Reduction_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pAEB_Deceleration_Reduction_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.AEB_Deceleration_Reduction_1_b8;
      * pAEB_Deceleration_Reduction_1 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_AEB_DECELERATION_REDUCTION_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_AEB_Deceleration_Reduction_2_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEAEBDecelerationReduction2V * pAEB_Deceleration_Reduction_2_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of AEB_Deceleration_Reduction_2_V
*    AEB_Deceleration_Reduction_2_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns AEB_Deceleration_Reduction_2_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_AEB_Deceleration_Reduction_2_V( IPBINITEAEBDecelerationReduction2V * pAEB_Deceleration_Reduction_2_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEAEBDecelerationReduction2V signal_value;
   
   if( pAEB_Deceleration_Reduction_2_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.AEB_Deceleration_Reduction_2_V_b1;
      * pAEB_Deceleration_Reduction_2_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_AEB_Deceleration_Reduction_2
*
* FUNCTION ARGUMENTS:
*    uint8 * pAEB_Deceleration_Reduction_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of AEB_Deceleration_Reduction_2
*    AEB_Deceleration_Reduction_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns AEB_Deceleration_Reduction_2 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_AEB_Deceleration_Reduction_2( uint8 * pAEB_Deceleration_Reduction_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pAEB_Deceleration_Reduction_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.AEB_Deceleration_Reduction_2_b8;
      * pAEB_Deceleration_Reduction_2 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_AEB_DECELERATION_REDUCTION_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_2_V
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_2_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_2_V
*    IIPB_Buffer_2_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_2_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_2_V( boolean * pIIPB_Buffer_2_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_2_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_2_V_b1;
      * pIIPB_Buffer_2_V = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_2_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_2
*
* FUNCTION ARGUMENTS:
*    uint8 * pIIPB_Buffer_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_2
*    IIPB_Buffer_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_2 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_2( uint8 * pIIPB_Buffer_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pIIPB_Buffer_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_2_b3;
      * pIIPB_Buffer_2 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_AEB_MaxRelV_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEAEBMaxRelVV * pAEB_MaxRelV_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of AEB_MaxRelV_V
*    AEB_MaxRelV_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns AEB_MaxRelV_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_AEB_MaxRelV_V( IPBINITEAEBMaxRelVV * pAEB_MaxRelV_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEAEBMaxRelVV signal_value;
   
   if( pAEB_MaxRelV_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.AEB_MaxRelV_V_b1;
      * pAEB_MaxRelV_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_AEB_MaxRelV
*
* FUNCTION ARGUMENTS:
*    uint16 * pAEB_MaxRelV - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of AEB_MaxRelV
*    AEB_MaxRelV returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns AEB_MaxRelV signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_AEB_MaxRelV( uint16 * pAEB_MaxRelV )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pAEB_MaxRelV != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.AEB_MaxRelV_b13;
      * pAEB_MaxRelV = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_AEB_MAXRELV_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_AEB_MaxSpeed_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEAEBMaxSpeedV * pAEB_MaxSpeed_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of AEB_MaxSpeed_V
*    AEB_MaxSpeed_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns AEB_MaxSpeed_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_AEB_MaxSpeed_V( IPBINITEAEBMaxSpeedV * pAEB_MaxSpeed_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEAEBMaxSpeedV signal_value;
   
   if( pAEB_MaxSpeed_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.AEB_MaxSpeed_V_b1;
      * pAEB_MaxSpeed_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_AEB_MaxSpeed
*
* FUNCTION ARGUMENTS:
*    uint16 * pAEB_MaxSpeed - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of AEB_MaxSpeed
*    AEB_MaxSpeed returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns AEB_MaxSpeed signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_AEB_MaxSpeed( uint16 * pAEB_MaxSpeed )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pAEB_MaxSpeed != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.AEB_MaxSpeed_b14;
      * pAEB_MaxSpeed = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_AEB_MAXSPEED_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_3_V
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_3_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_3_V
*    IIPB_Buffer_3_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_3_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_3_V( boolean * pIIPB_Buffer_3_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_3_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_3_V_b1;
      * pIIPB_Buffer_3_V = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_3_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_3
*
* FUNCTION ARGUMENTS:
*    uint8 * pIIPB_Buffer_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_3
*    IIPB_Buffer_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_3 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_3( uint8 * pIIPB_Buffer_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pIIPB_Buffer_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_3_b2;
      * pIIPB_Buffer_3 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_AEB_MaxSpeedReduction_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEAEBMaxSpeedReductionV * pAEB_MaxSpeedReduction_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of AEB_MaxSpeedReduction_V
*    AEB_MaxSpeedReduction_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns AEB_MaxSpeedReduction_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_AEB_MaxSpeedReduction_V( IPBINITEAEBMaxSpeedReductionV * pAEB_MaxSpeedReduction_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEAEBMaxSpeedReductionV signal_value;
   
   if( pAEB_MaxSpeedReduction_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.AEB_MaxSpeedReduction_V_b1;
      * pAEB_MaxSpeedReduction_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_AEB_MaxSpeedReduction
*
* FUNCTION ARGUMENTS:
*    uint16 * pAEB_MaxSpeedReduction - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of AEB_MaxSpeedReduction
*    AEB_MaxSpeedReduction returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns AEB_MaxSpeedReduction signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_AEB_MaxSpeedReduction( uint16 * pAEB_MaxSpeedReduction )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pAEB_MaxSpeedReduction != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.AEB_MaxSpeedReduction_b14;
      * pAEB_MaxSpeedReduction = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_AEB_MAXSPEEDREDUCTION_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_AEB_MaxYawRate_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEAEBMaxYawRateV * pAEB_MaxYawRate_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of AEB_MaxYawRate_V
*    AEB_MaxYawRate_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns AEB_MaxYawRate_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_AEB_MaxYawRate_V( IPBINITEAEBMaxYawRateV * pAEB_MaxYawRate_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEAEBMaxYawRateV signal_value;
   
   if( pAEB_MaxYawRate_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.AEB_MaxYawRate_V_b1;
      * pAEB_MaxYawRate_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_AEB_MaxYawRate
*
* FUNCTION ARGUMENTS:
*    uint16 * pAEB_MaxYawRate - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of AEB_MaxYawRate
*    AEB_MaxYawRate returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns AEB_MaxYawRate signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_AEB_MaxYawRate( uint16 * pAEB_MaxYawRate )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pAEB_MaxYawRate != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.AEB_MaxYawRate_b12;
      * pAEB_MaxYawRate = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_AEB_MAXYAWRATE_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_4_V
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_4_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_4_V
*    IIPB_Buffer_4_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_4_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_4_V( boolean * pIIPB_Buffer_4_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_4_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_4_V_b1;
      * pIIPB_Buffer_4_V = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_4_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_4
*
* FUNCTION ARGUMENTS:
*    uint8 * pIIPB_Buffer_4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_4
*    IIPB_Buffer_4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_4 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_4( uint8 * pIIPB_Buffer_4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pIIPB_Buffer_4 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_4_b3;
      * pIIPB_Buffer_4 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_4_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_AEB_Min_time_after_AEB_for_AEB_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEAEBMinTimeAfterAEBForAEBV * pAEB_Min_time_after_AEB_for_AEB_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of AEB_Min_time_after_AEB_for_AEB_V
*    AEB_Min_time_after_AEB_for_AEB_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns AEB_Min_time_after_AEB_for_AEB_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_AEB_Min_time_after_AEB_for_AEB_V( IPBINITEAEBMinTimeAfterAEBForAEBV * pAEB_Min_time_after_AEB_for_AEB_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEAEBMinTimeAfterAEBForAEBV signal_value;
   
   if( pAEB_Min_time_after_AEB_for_AEB_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.AEB_Min_time_after_AEB_for_AEB_V_b1;
      * pAEB_Min_time_after_AEB_for_AEB_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_AEB_Min_time_after_AEB_for_AEB
*
* FUNCTION ARGUMENTS:
*    uint16 * pAEB_Min_time_after_AEB_for_AEB - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of AEB_Min_time_after_AEB_for_AEB
*    AEB_Min_time_after_AEB_for_AEB returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns AEB_Min_time_after_AEB_for_AEB signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_AEB_Min_time_after_AEB_for_AEB( uint16 * pAEB_Min_time_after_AEB_for_AEB )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pAEB_Min_time_after_AEB_for_AEB != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.AEB_Min_time_after_AEB_for_AEB_b10;
      * pAEB_Min_time_after_AEB_for_AEB = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_AEB_MIN_TIME_AFTER_AEB_FOR_AEB_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_AEB_MinRelV_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEAEBMinRelVV * pAEB_MinRelV_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of AEB_MinRelV_V
*    AEB_MinRelV_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns AEB_MinRelV_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_AEB_MinRelV_V( IPBINITEAEBMinRelVV * pAEB_MinRelV_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEAEBMinRelVV signal_value;
   
   if( pAEB_MinRelV_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.AEB_MinRelV_V_b1;
      * pAEB_MinRelV_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_AEB_MinRelV
*
* FUNCTION ARGUMENTS:
*    uint16 * pAEB_MinRelV - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of AEB_MinRelV
*    AEB_MinRelV returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns AEB_MinRelV signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_AEB_MinRelV( uint16 * pAEB_MinRelV )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pAEB_MinRelV != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.AEB_MinRelV_b13;
      * pAEB_MinRelV = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_AEB_MINRELV_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_5_V
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_5_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_5_V
*    IIPB_Buffer_5_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_5_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_5_V( boolean * pIIPB_Buffer_5_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_5_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_5_V_b1;
      * pIIPB_Buffer_5_V = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_5_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_5
*
* FUNCTION ARGUMENTS:
*    uint8 * pIIPB_Buffer_5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_5
*    IIPB_Buffer_5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_5 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_5( uint8 * pIIPB_Buffer_5 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pIIPB_Buffer_5 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_5_b6;
      * pIIPB_Buffer_5 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_5_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_AEB_MinSpeed_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEAEBMinSpeedV * pAEB_MinSpeed_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of AEB_MinSpeed_V
*    AEB_MinSpeed_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns AEB_MinSpeed_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_AEB_MinSpeed_V( IPBINITEAEBMinSpeedV * pAEB_MinSpeed_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEAEBMinSpeedV signal_value;
   
   if( pAEB_MinSpeed_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.AEB_MinSpeed_V_b1;
      * pAEB_MinSpeed_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_AEB_MinSpeed
*
* FUNCTION ARGUMENTS:
*    uint16 * pAEB_MinSpeed - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of AEB_MinSpeed
*    AEB_MinSpeed returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns AEB_MinSpeed signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_AEB_MinSpeed( uint16 * pAEB_MinSpeed )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pAEB_MinSpeed != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.AEB_MinSpeed_b14;
      * pAEB_MinSpeed = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_AEB_MINSPEED_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_AEB_StandStillFollowTimeHyst_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEAEBStandStillFollowTimeHystV * pAEB_StandStillFollowTimeHyst_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of AEB_StandStillFollowTimeHyst_V
*    AEB_StandStillFollowTimeHyst_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns AEB_StandStillFollowTimeHyst_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_AEB_StandStillFollowTimeHyst_V( IPBINITEAEBStandStillFollowTimeHystV * pAEB_StandStillFollowTimeHyst_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEAEBStandStillFollowTimeHystV signal_value;
   
   if( pAEB_StandStillFollowTimeHyst_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.AEB_StandStillFollowTimeHyst_V_b1;
      * pAEB_StandStillFollowTimeHyst_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_AEB_StandStillFollowTimeHyst
*
* FUNCTION ARGUMENTS:
*    uint16 * pAEB_StandStillFollowTimeHyst - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of AEB_StandStillFollowTimeHyst
*    AEB_StandStillFollowTimeHyst returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns AEB_StandStillFollowTimeHyst signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_AEB_StandStillFollowTimeHyst( uint16 * pAEB_StandStillFollowTimeHyst )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pAEB_StandStillFollowTimeHyst != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.AEB_StandStillFollowTimeHyst_b9;
      * pAEB_StandStillFollowTimeHyst = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_AEB_STANDSTILLFOLLOWTIMEHYST_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_6_V
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_6_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_6_V
*    IIPB_Buffer_6_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_6_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_6_V( boolean * pIIPB_Buffer_6_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_6_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_6_V_b1;
      * pIIPB_Buffer_6_V = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_6_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_6
*
* FUNCTION ARGUMENTS:
*    uint8 * pIIPB_Buffer_6 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_6
*    IIPB_Buffer_6 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_6 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_6( uint8 * pIIPB_Buffer_6 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pIIPB_Buffer_6 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_6_b6;
      * pIIPB_Buffer_6 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_6_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_AEB_StandStillMaxSpeed_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEAEBStandStillMaxSpeedV * pAEB_StandStillMaxSpeed_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of AEB_StandStillMaxSpeed_V
*    AEB_StandStillMaxSpeed_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns AEB_StandStillMaxSpeed_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_AEB_StandStillMaxSpeed_V( IPBINITEAEBStandStillMaxSpeedV * pAEB_StandStillMaxSpeed_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEAEBStandStillMaxSpeedV signal_value;
   
   if( pAEB_StandStillMaxSpeed_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.AEB_StandStillMaxSpeed_V_b1;
      * pAEB_StandStillMaxSpeed_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_AEB_StandStillMaxSpeed
*
* FUNCTION ARGUMENTS:
*    uint16 * pAEB_StandStillMaxSpeed - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of AEB_StandStillMaxSpeed
*    AEB_StandStillMaxSpeed returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns AEB_StandStillMaxSpeed signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_AEB_StandStillMaxSpeed( uint16 * pAEB_StandStillMaxSpeed )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pAEB_StandStillMaxSpeed != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.AEB_StandStillMaxSpeed_b9;
      * pAEB_StandStillMaxSpeed = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_AEB_STANDSTILLMAXSPEED_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_AEB_StandStillStillTimeHyst_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEAEBStandStillStillTimeHystV * pAEB_StandStillStillTimeHyst_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of AEB_StandStillStillTimeHyst_V
*    AEB_StandStillStillTimeHyst_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns AEB_StandStillStillTimeHyst_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_AEB_StandStillStillTimeHyst_V( IPBINITEAEBStandStillStillTimeHystV * pAEB_StandStillStillTimeHyst_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEAEBStandStillStillTimeHystV signal_value;
   
   if( pAEB_StandStillStillTimeHyst_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.AEB_StandStillStillTimeHyst_V_b1;
      * pAEB_StandStillStillTimeHyst_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_AEB_StandStillStillTimeHyst
*
* FUNCTION ARGUMENTS:
*    uint16 * pAEB_StandStillStillTimeHyst - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of AEB_StandStillStillTimeHyst
*    AEB_StandStillStillTimeHyst returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns AEB_StandStillStillTimeHyst signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_AEB_StandStillStillTimeHyst( uint16 * pAEB_StandStillStillTimeHyst )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pAEB_StandStillStillTimeHyst != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.AEB_StandStillStillTimeHyst_b9;
      * pAEB_StandStillStillTimeHyst = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_AEB_STANDSTILLSTILLTIMEHYST_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_Far_FCA_HW_VAL_0_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEFarFCAHWVAL0V * pFar_FCA_HW_VAL_0_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Far_FCA_HW_VAL_0_V
*    Far_FCA_HW_VAL_0_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Far_FCA_HW_VAL_0_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_Far_FCA_HW_VAL_0_V( IPBINITEFarFCAHWVAL0V * pFar_FCA_HW_VAL_0_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEFarFCAHWVAL0V signal_value;
   
   if( pFar_FCA_HW_VAL_0_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.Far_FCA_HW_VAL_0_V_b1;
      * pFar_FCA_HW_VAL_0_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_Far_FCA_HW_VAL_0
*
* FUNCTION ARGUMENTS:
*    uint8 * pFar_FCA_HW_VAL_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Far_FCA_HW_VAL_0
*    Far_FCA_HW_VAL_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Far_FCA_HW_VAL_0 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_Far_FCA_HW_VAL_0( uint8 * pFar_FCA_HW_VAL_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFar_FCA_HW_VAL_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.Far_FCA_HW_VAL_0_b8;
      * pFar_FCA_HW_VAL_0 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_7_V
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_7_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_7_V
*    IIPB_Buffer_7_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_7_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_7_V( boolean * pIIPB_Buffer_7_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_7_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_7_V_b1;
      * pIIPB_Buffer_7_V = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_7_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_7
*
* FUNCTION ARGUMENTS:
*    uint8 * pIIPB_Buffer_7 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_7
*    IIPB_Buffer_7 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_7 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_7( uint8 * pIIPB_Buffer_7 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pIIPB_Buffer_7 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_7_b2;
      * pIIPB_Buffer_7 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_7_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_Far_FCA_HW_VAL_1_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEFarFCAHWVAL1V * pFar_FCA_HW_VAL_1_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Far_FCA_HW_VAL_1_V
*    Far_FCA_HW_VAL_1_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Far_FCA_HW_VAL_1_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_Far_FCA_HW_VAL_1_V( IPBINITEFarFCAHWVAL1V * pFar_FCA_HW_VAL_1_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEFarFCAHWVAL1V signal_value;
   
   if( pFar_FCA_HW_VAL_1_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.Far_FCA_HW_VAL_1_V_b1;
      * pFar_FCA_HW_VAL_1_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_Far_FCA_HW_VAL_1
*
* FUNCTION ARGUMENTS:
*    uint8 * pFar_FCA_HW_VAL_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Far_FCA_HW_VAL_1
*    Far_FCA_HW_VAL_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Far_FCA_HW_VAL_1 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_Far_FCA_HW_VAL_1( uint8 * pFar_FCA_HW_VAL_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFar_FCA_HW_VAL_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.Far_FCA_HW_VAL_1_b8;
      * pFar_FCA_HW_VAL_1 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_Far_FCA_HW_VAL_2_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEFarFCAHWVAL2V * pFar_FCA_HW_VAL_2_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Far_FCA_HW_VAL_2_V
*    Far_FCA_HW_VAL_2_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Far_FCA_HW_VAL_2_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_Far_FCA_HW_VAL_2_V( IPBINITEFarFCAHWVAL2V * pFar_FCA_HW_VAL_2_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEFarFCAHWVAL2V signal_value;
   
   if( pFar_FCA_HW_VAL_2_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.Far_FCA_HW_VAL_2_V_b1;
      * pFar_FCA_HW_VAL_2_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_Far_FCA_HW_VAL_2
*
* FUNCTION ARGUMENTS:
*    uint8 * pFar_FCA_HW_VAL_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Far_FCA_HW_VAL_2
*    Far_FCA_HW_VAL_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Far_FCA_HW_VAL_2 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_Far_FCA_HW_VAL_2( uint8 * pFar_FCA_HW_VAL_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFar_FCA_HW_VAL_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.Far_FCA_HW_VAL_2_b8;
      * pFar_FCA_HW_VAL_2 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_Far_FCA_HW_VAL_3_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEFarFCAHWVAL3V * pFar_FCA_HW_VAL_3_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Far_FCA_HW_VAL_3_V
*    Far_FCA_HW_VAL_3_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Far_FCA_HW_VAL_3_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_Far_FCA_HW_VAL_3_V( IPBINITEFarFCAHWVAL3V * pFar_FCA_HW_VAL_3_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEFarFCAHWVAL3V signal_value;
   
   if( pFar_FCA_HW_VAL_3_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.Far_FCA_HW_VAL_3_V_b1;
      * pFar_FCA_HW_VAL_3_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_Far_FCA_HW_VAL_3
*
* FUNCTION ARGUMENTS:
*    uint8 * pFar_FCA_HW_VAL_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Far_FCA_HW_VAL_3
*    Far_FCA_HW_VAL_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Far_FCA_HW_VAL_3 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_Far_FCA_HW_VAL_3( uint8 * pFar_FCA_HW_VAL_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFar_FCA_HW_VAL_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.Far_FCA_HW_VAL_3_b8;
      * pFar_FCA_HW_VAL_3 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_8_V
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_8_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_8_V
*    IIPB_Buffer_8_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_8_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_8_V( boolean * pIIPB_Buffer_8_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_8_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_8_V_b1;
      * pIIPB_Buffer_8_V = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_8_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_8
*
* FUNCTION ARGUMENTS:
*    uint8 * pIIPB_Buffer_8 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_8
*    IIPB_Buffer_8 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_8 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_8( uint8 * pIIPB_Buffer_8 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pIIPB_Buffer_8 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_8_b4;
      * pIIPB_Buffer_8 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_8_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_Far_FCA_HW_VAL_4_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEFarFCAHWVAL4V * pFar_FCA_HW_VAL_4_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Far_FCA_HW_VAL_4_V
*    Far_FCA_HW_VAL_4_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Far_FCA_HW_VAL_4_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_Far_FCA_HW_VAL_4_V( IPBINITEFarFCAHWVAL4V * pFar_FCA_HW_VAL_4_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEFarFCAHWVAL4V signal_value;
   
   if( pFar_FCA_HW_VAL_4_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.Far_FCA_HW_VAL_4_V_b1;
      * pFar_FCA_HW_VAL_4_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_Far_FCA_HW_VAL_4
*
* FUNCTION ARGUMENTS:
*    uint8 * pFar_FCA_HW_VAL_4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Far_FCA_HW_VAL_4
*    Far_FCA_HW_VAL_4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Far_FCA_HW_VAL_4 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_Far_FCA_HW_VAL_4( uint8 * pFar_FCA_HW_VAL_4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFar_FCA_HW_VAL_4 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.Far_FCA_HW_VAL_4_b8;
      * pFar_FCA_HW_VAL_4 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_Far_FCA_HW_VAL_5_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEFarFCAHWVAL5V * pFar_FCA_HW_VAL_5_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Far_FCA_HW_VAL_5_V
*    Far_FCA_HW_VAL_5_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Far_FCA_HW_VAL_5_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_Far_FCA_HW_VAL_5_V( IPBINITEFarFCAHWVAL5V * pFar_FCA_HW_VAL_5_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEFarFCAHWVAL5V signal_value;
   
   if( pFar_FCA_HW_VAL_5_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.Far_FCA_HW_VAL_5_V_b1;
      * pFar_FCA_HW_VAL_5_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_Far_FCA_HW_VAL_5
*
* FUNCTION ARGUMENTS:
*    uint8 * pFar_FCA_HW_VAL_5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Far_FCA_HW_VAL_5
*    Far_FCA_HW_VAL_5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Far_FCA_HW_VAL_5 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_Far_FCA_HW_VAL_5( uint8 * pFar_FCA_HW_VAL_5 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFar_FCA_HW_VAL_5 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.Far_FCA_HW_VAL_5_b8;
      * pFar_FCA_HW_VAL_5 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FAR_TTC_TABLE_0_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEFARTTCTABLE0V * pFAR_TTC_TABLE_0_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FAR_TTC_TABLE_0_V
*    FAR_TTC_TABLE_0_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FAR_TTC_TABLE_0_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FAR_TTC_TABLE_0_V( IPBINITEFARTTCTABLE0V * pFAR_TTC_TABLE_0_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEFARTTCTABLE0V signal_value;
   
   if( pFAR_TTC_TABLE_0_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FAR_TTC_TABLE_0_V_b1;
      * pFAR_TTC_TABLE_0_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FAR_TTC_TABLE_0
*
* FUNCTION ARGUMENTS:
*    uint16 * pFAR_TTC_TABLE_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FAR_TTC_TABLE_0
*    FAR_TTC_TABLE_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FAR_TTC_TABLE_0 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FAR_TTC_TABLE_0( uint16 * pFAR_TTC_TABLE_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFAR_TTC_TABLE_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FAR_TTC_TABLE_0_b10;
      * pFAR_TTC_TABLE_0 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_FAR_TTC_TABLE_0_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_9_V
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_9_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_9_V
*    IIPB_Buffer_9_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_9_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_9_V( boolean * pIIPB_Buffer_9_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_9_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_9_V_b1;
      * pIIPB_Buffer_9_V = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_9_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_9
*
* FUNCTION ARGUMENTS:
*    uint8 * pIIPB_Buffer_9 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_9
*    IIPB_Buffer_9 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_9 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_9( uint8 * pIIPB_Buffer_9 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pIIPB_Buffer_9 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_9_b2;
      * pIIPB_Buffer_9 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_9_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FAR_TTC_TABLE_1_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEFARTTCTABLE1V * pFAR_TTC_TABLE_1_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FAR_TTC_TABLE_1_V
*    FAR_TTC_TABLE_1_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FAR_TTC_TABLE_1_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FAR_TTC_TABLE_1_V( IPBINITEFARTTCTABLE1V * pFAR_TTC_TABLE_1_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEFARTTCTABLE1V signal_value;
   
   if( pFAR_TTC_TABLE_1_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FAR_TTC_TABLE_1_V_b1;
      * pFAR_TTC_TABLE_1_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FAR_TTC_TABLE_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pFAR_TTC_TABLE_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FAR_TTC_TABLE_1
*    FAR_TTC_TABLE_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FAR_TTC_TABLE_1 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FAR_TTC_TABLE_1( uint16 * pFAR_TTC_TABLE_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFAR_TTC_TABLE_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FAR_TTC_TABLE_1_b10;
      * pFAR_TTC_TABLE_1 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_FAR_TTC_TABLE_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FAR_TTC_TABLE_2_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEFARTTCTABLE2V * pFAR_TTC_TABLE_2_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FAR_TTC_TABLE_2_V
*    FAR_TTC_TABLE_2_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FAR_TTC_TABLE_2_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FAR_TTC_TABLE_2_V( IPBINITEFARTTCTABLE2V * pFAR_TTC_TABLE_2_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEFARTTCTABLE2V signal_value;
   
   if( pFAR_TTC_TABLE_2_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FAR_TTC_TABLE_2_V_b1;
      * pFAR_TTC_TABLE_2_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FAR_TTC_TABLE_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pFAR_TTC_TABLE_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FAR_TTC_TABLE_2
*    FAR_TTC_TABLE_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FAR_TTC_TABLE_2 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FAR_TTC_TABLE_2( uint16 * pFAR_TTC_TABLE_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFAR_TTC_TABLE_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FAR_TTC_TABLE_2_b10;
      * pFAR_TTC_TABLE_2 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_FAR_TTC_TABLE_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FAR_TTC_TABLE_3_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEFARTTCTABLE3V * pFAR_TTC_TABLE_3_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FAR_TTC_TABLE_3_V
*    FAR_TTC_TABLE_3_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FAR_TTC_TABLE_3_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FAR_TTC_TABLE_3_V( IPBINITEFARTTCTABLE3V * pFAR_TTC_TABLE_3_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEFARTTCTABLE3V signal_value;
   
   if( pFAR_TTC_TABLE_3_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FAR_TTC_TABLE_3_V_b1;
      * pFAR_TTC_TABLE_3_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FAR_TTC_TABLE_3
*
* FUNCTION ARGUMENTS:
*    uint16 * pFAR_TTC_TABLE_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FAR_TTC_TABLE_3
*    FAR_TTC_TABLE_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FAR_TTC_TABLE_3 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FAR_TTC_TABLE_3( uint16 * pFAR_TTC_TABLE_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFAR_TTC_TABLE_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FAR_TTC_TABLE_3_b10;
      * pFAR_TTC_TABLE_3 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_FAR_TTC_TABLE_3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FAR_TTC_TABLE_4_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEFARTTCTABLE4V * pFAR_TTC_TABLE_4_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FAR_TTC_TABLE_4_V
*    FAR_TTC_TABLE_4_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FAR_TTC_TABLE_4_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FAR_TTC_TABLE_4_V( IPBINITEFARTTCTABLE4V * pFAR_TTC_TABLE_4_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEFARTTCTABLE4V signal_value;
   
   if( pFAR_TTC_TABLE_4_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FAR_TTC_TABLE_4_V_b1;
      * pFAR_TTC_TABLE_4_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FAR_TTC_TABLE_4
*
* FUNCTION ARGUMENTS:
*    uint16 * pFAR_TTC_TABLE_4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FAR_TTC_TABLE_4
*    FAR_TTC_TABLE_4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FAR_TTC_TABLE_4 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FAR_TTC_TABLE_4( uint16 * pFAR_TTC_TABLE_4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFAR_TTC_TABLE_4 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FAR_TTC_TABLE_4_b10;
      * pFAR_TTC_TABLE_4 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_FAR_TTC_TABLE_4_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FAR_TTC_TABLE_5_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEFARTTCTABLE5V * pFAR_TTC_TABLE_5_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FAR_TTC_TABLE_5_V
*    FAR_TTC_TABLE_5_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FAR_TTC_TABLE_5_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FAR_TTC_TABLE_5_V( IPBINITEFARTTCTABLE5V * pFAR_TTC_TABLE_5_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEFARTTCTABLE5V signal_value;
   
   if( pFAR_TTC_TABLE_5_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FAR_TTC_TABLE_5_V_b1;
      * pFAR_TTC_TABLE_5_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FAR_TTC_TABLE_5
*
* FUNCTION ARGUMENTS:
*    uint16 * pFAR_TTC_TABLE_5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FAR_TTC_TABLE_5
*    FAR_TTC_TABLE_5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FAR_TTC_TABLE_5 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FAR_TTC_TABLE_5( uint16 * pFAR_TTC_TABLE_5 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFAR_TTC_TABLE_5 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FAR_TTC_TABLE_5_b10;
      * pFAR_TTC_TABLE_5 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_FAR_TTC_TABLE_5_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_10_V
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_10_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_10_V
*    IIPB_Buffer_10_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_10_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_10_V( boolean * pIIPB_Buffer_10_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_10_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_10_V_b1;
      * pIIPB_Buffer_10_V = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_10_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_10
*
* FUNCTION ARGUMENTS:
*    uint8 * pIIPB_Buffer_10 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_10
*    IIPB_Buffer_10 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_10 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_10( uint8 * pIIPB_Buffer_10 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pIIPB_Buffer_10 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_10_b8;
      * pIIPB_Buffer_10 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_10_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FAR_TTC_TABLE_6_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEFARTTCTABLE6V * pFAR_TTC_TABLE_6_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FAR_TTC_TABLE_6_V
*    FAR_TTC_TABLE_6_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FAR_TTC_TABLE_6_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FAR_TTC_TABLE_6_V( IPBINITEFARTTCTABLE6V * pFAR_TTC_TABLE_6_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEFARTTCTABLE6V signal_value;
   
   if( pFAR_TTC_TABLE_6_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FAR_TTC_TABLE_6_V_b1;
      * pFAR_TTC_TABLE_6_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FAR_TTC_TABLE_6
*
* FUNCTION ARGUMENTS:
*    uint16 * pFAR_TTC_TABLE_6 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FAR_TTC_TABLE_6
*    FAR_TTC_TABLE_6 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FAR_TTC_TABLE_6 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FAR_TTC_TABLE_6( uint16 * pFAR_TTC_TABLE_6 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFAR_TTC_TABLE_6 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FAR_TTC_TABLE_6_b10;
      * pFAR_TTC_TABLE_6 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_FAR_TTC_TABLE_6_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FAR_TTC_TABLE_7_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEFARTTCTABLE7V * pFAR_TTC_TABLE_7_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FAR_TTC_TABLE_7_V
*    FAR_TTC_TABLE_7_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FAR_TTC_TABLE_7_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FAR_TTC_TABLE_7_V( IPBINITEFARTTCTABLE7V * pFAR_TTC_TABLE_7_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEFARTTCTABLE7V signal_value;
   
   if( pFAR_TTC_TABLE_7_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FAR_TTC_TABLE_7_V_b1;
      * pFAR_TTC_TABLE_7_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FAR_TTC_TABLE_7
*
* FUNCTION ARGUMENTS:
*    uint16 * pFAR_TTC_TABLE_7 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FAR_TTC_TABLE_7
*    FAR_TTC_TABLE_7 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FAR_TTC_TABLE_7 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FAR_TTC_TABLE_7( uint16 * pFAR_TTC_TABLE_7 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFAR_TTC_TABLE_7 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FAR_TTC_TABLE_7_b10;
      * pFAR_TTC_TABLE_7 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_FAR_TTC_TABLE_7_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_11_V
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_11_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_11_V
*    IIPB_Buffer_11_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_11_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_11_V( boolean * pIIPB_Buffer_11_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_11_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_11_V_b1;
      * pIIPB_Buffer_11_V = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_11_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_11
*
* FUNCTION ARGUMENTS:
*    uint16 * pIIPB_Buffer_11 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_11
*    IIPB_Buffer_11 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_11 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_11( uint16 * pIIPB_Buffer_11 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pIIPB_Buffer_11 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_11_b9;
      * pIIPB_Buffer_11 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_11_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FCA_HW_Kneepoints_0_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEFCAHWKneepoints0V * pFCA_HW_Kneepoints_0_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCA_HW_Kneepoints_0_V
*    FCA_HW_Kneepoints_0_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCA_HW_Kneepoints_0_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FCA_HW_Kneepoints_0_V( IPBINITEFCAHWKneepoints0V * pFCA_HW_Kneepoints_0_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEFCAHWKneepoints0V signal_value;
   
   if( pFCA_HW_Kneepoints_0_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FCA_HW_Kneepoints_0_V_b1;
      * pFCA_HW_Kneepoints_0_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FCA_HW_Kneepoints_0
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCA_HW_Kneepoints_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCA_HW_Kneepoints_0
*    FCA_HW_Kneepoints_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCA_HW_Kneepoints_0 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FCA_HW_Kneepoints_0( uint16 * pFCA_HW_Kneepoints_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCA_HW_Kneepoints_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FCA_HW_Kneepoints_0_b15;
      * pFCA_HW_Kneepoints_0 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_FCA_HW_KNEEPOINTS_0_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FCA_HW_Kneepoints_1_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEFCAHWKneepoints1V * pFCA_HW_Kneepoints_1_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCA_HW_Kneepoints_1_V
*    FCA_HW_Kneepoints_1_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCA_HW_Kneepoints_1_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FCA_HW_Kneepoints_1_V( IPBINITEFCAHWKneepoints1V * pFCA_HW_Kneepoints_1_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEFCAHWKneepoints1V signal_value;
   
   if( pFCA_HW_Kneepoints_1_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FCA_HW_Kneepoints_1_V_b1;
      * pFCA_HW_Kneepoints_1_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FCA_HW_Kneepoints_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCA_HW_Kneepoints_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCA_HW_Kneepoints_1
*    FCA_HW_Kneepoints_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCA_HW_Kneepoints_1 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FCA_HW_Kneepoints_1( uint16 * pFCA_HW_Kneepoints_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCA_HW_Kneepoints_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FCA_HW_Kneepoints_1_b15;
      * pFCA_HW_Kneepoints_1 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_FCA_HW_KNEEPOINTS_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FCA_HW_Kneepoints_2_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEFCAHWKneepoints2V * pFCA_HW_Kneepoints_2_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCA_HW_Kneepoints_2_V
*    FCA_HW_Kneepoints_2_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCA_HW_Kneepoints_2_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FCA_HW_Kneepoints_2_V( IPBINITEFCAHWKneepoints2V * pFCA_HW_Kneepoints_2_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEFCAHWKneepoints2V signal_value;
   
   if( pFCA_HW_Kneepoints_2_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FCA_HW_Kneepoints_2_V_b1;
      * pFCA_HW_Kneepoints_2_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FCA_HW_Kneepoints_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCA_HW_Kneepoints_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCA_HW_Kneepoints_2
*    FCA_HW_Kneepoints_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCA_HW_Kneepoints_2 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FCA_HW_Kneepoints_2( uint16 * pFCA_HW_Kneepoints_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCA_HW_Kneepoints_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FCA_HW_Kneepoints_2_b15;
      * pFCA_HW_Kneepoints_2 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_FCA_HW_KNEEPOINTS_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FCA_HW_Kneepoints_3_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEFCAHWKneepoints3V * pFCA_HW_Kneepoints_3_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCA_HW_Kneepoints_3_V
*    FCA_HW_Kneepoints_3_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCA_HW_Kneepoints_3_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FCA_HW_Kneepoints_3_V( IPBINITEFCAHWKneepoints3V * pFCA_HW_Kneepoints_3_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEFCAHWKneepoints3V signal_value;
   
   if( pFCA_HW_Kneepoints_3_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FCA_HW_Kneepoints_3_V_b1;
      * pFCA_HW_Kneepoints_3_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FCA_HW_Kneepoints_3
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCA_HW_Kneepoints_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCA_HW_Kneepoints_3
*    FCA_HW_Kneepoints_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCA_HW_Kneepoints_3 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FCA_HW_Kneepoints_3( uint16 * pFCA_HW_Kneepoints_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCA_HW_Kneepoints_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FCA_HW_Kneepoints_3_b15;
      * pFCA_HW_Kneepoints_3 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_FCA_HW_KNEEPOINTS_3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FCA_HW_Kneepoints_4_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEFCAHWKneepoints4V * pFCA_HW_Kneepoints_4_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCA_HW_Kneepoints_4_V
*    FCA_HW_Kneepoints_4_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCA_HW_Kneepoints_4_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FCA_HW_Kneepoints_4_V( IPBINITEFCAHWKneepoints4V * pFCA_HW_Kneepoints_4_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEFCAHWKneepoints4V signal_value;
   
   if( pFCA_HW_Kneepoints_4_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FCA_HW_Kneepoints_4_V_b1;
      * pFCA_HW_Kneepoints_4_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FCA_HW_Kneepoints_4
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCA_HW_Kneepoints_4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCA_HW_Kneepoints_4
*    FCA_HW_Kneepoints_4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCA_HW_Kneepoints_4 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FCA_HW_Kneepoints_4( uint16 * pFCA_HW_Kneepoints_4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCA_HW_Kneepoints_4 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FCA_HW_Kneepoints_4_b15;
      * pFCA_HW_Kneepoints_4 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_FCA_HW_KNEEPOINTS_4_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FCA_HW_Kneepoints_5_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEFCAHWKneepoints5V * pFCA_HW_Kneepoints_5_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCA_HW_Kneepoints_5_V
*    FCA_HW_Kneepoints_5_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCA_HW_Kneepoints_5_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FCA_HW_Kneepoints_5_V( IPBINITEFCAHWKneepoints5V * pFCA_HW_Kneepoints_5_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEFCAHWKneepoints5V signal_value;
   
   if( pFCA_HW_Kneepoints_5_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FCA_HW_Kneepoints_5_V_b1;
      * pFCA_HW_Kneepoints_5_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FCA_HW_Kneepoints_5
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCA_HW_Kneepoints_5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCA_HW_Kneepoints_5
*    FCA_HW_Kneepoints_5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCA_HW_Kneepoints_5 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FCA_HW_Kneepoints_5( uint16 * pFCA_HW_Kneepoints_5 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCA_HW_Kneepoints_5 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FCA_HW_Kneepoints_5_b15;
      * pFCA_HW_Kneepoints_5 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_FCA_HW_KNEEPOINTS_5_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FCA_HW_Stop_Fact_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEFCAHWStopFactV * pFCA_HW_Stop_Fact_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCA_HW_Stop_Fact_V
*    FCA_HW_Stop_Fact_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCA_HW_Stop_Fact_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FCA_HW_Stop_Fact_V( IPBINITEFCAHWStopFactV * pFCA_HW_Stop_Fact_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEFCAHWStopFactV signal_value;
   
   if( pFCA_HW_Stop_Fact_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FCA_HW_Stop_Fact_V_b1;
      * pFCA_HW_Stop_Fact_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FCA_HW_Stop_Fact
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCA_HW_Stop_Fact - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCA_HW_Stop_Fact
*    FCA_HW_Stop_Fact returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCA_HW_Stop_Fact signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FCA_HW_Stop_Fact( uint16 * pFCA_HW_Stop_Fact )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCA_HW_Stop_Fact != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FCA_HW_Stop_Fact_b9;
      * pFCA_HW_Stop_Fact = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_FCA_HW_STOP_FACT_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FCA_Ignition_default_state_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEFCAIgnitionDefaultStateV * pFCA_Ignition_default_state_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCA_Ignition_default_state_V
*    FCA_Ignition_default_state_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCA_Ignition_default_state_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FCA_Ignition_default_state_V( IPBINITEFCAIgnitionDefaultStateV * pFCA_Ignition_default_state_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEFCAIgnitionDefaultStateV signal_value;
   
   if( pFCA_Ignition_default_state_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FCA_Ignition_default_state_V_b1;
      * pFCA_Ignition_default_state_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FCA_Ignition_default_state
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCA_Ignition_default_state - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCA_Ignition_default_state
*    FCA_Ignition_default_state returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCA_Ignition_default_state signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FCA_Ignition_default_state( uint8 * pFCA_Ignition_default_state )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCA_Ignition_default_state != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FCA_Ignition_default_state_b2;
      * pFCA_Ignition_default_state = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FCW_BaseSpeeds_0_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEFCWBaseSpeeds0V * pFCW_BaseSpeeds_0_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCW_BaseSpeeds_0_V
*    FCW_BaseSpeeds_0_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCW_BaseSpeeds_0_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FCW_BaseSpeeds_0_V( IPBINITEFCWBaseSpeeds0V * pFCW_BaseSpeeds_0_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEFCWBaseSpeeds0V signal_value;
   
   if( pFCW_BaseSpeeds_0_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FCW_BaseSpeeds_0_V_b1;
      * pFCW_BaseSpeeds_0_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FCW_BaseSpeeds_0
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCW_BaseSpeeds_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCW_BaseSpeeds_0
*    FCW_BaseSpeeds_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCW_BaseSpeeds_0 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FCW_BaseSpeeds_0( uint16 * pFCW_BaseSpeeds_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCW_BaseSpeeds_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FCW_BaseSpeeds_0_b15;
      * pFCW_BaseSpeeds_0 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_FCW_BASESPEEDS_0_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_12_V
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_12_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_12_V
*    IIPB_Buffer_12_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_12_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_12_V( boolean * pIIPB_Buffer_12_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_12_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_12_V_b1;
      * pIIPB_Buffer_12_V = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_12_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_12
*
* FUNCTION ARGUMENTS:
*    uint8 * pIIPB_Buffer_12 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_12
*    IIPB_Buffer_12 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_12 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_12( uint8 * pIIPB_Buffer_12 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pIIPB_Buffer_12 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_12_b2;
      * pIIPB_Buffer_12 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_12_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FCW_BaseSpeeds_1_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEFCWBaseSpeeds1V * pFCW_BaseSpeeds_1_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCW_BaseSpeeds_1_V
*    FCW_BaseSpeeds_1_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCW_BaseSpeeds_1_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FCW_BaseSpeeds_1_V( IPBINITEFCWBaseSpeeds1V * pFCW_BaseSpeeds_1_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEFCWBaseSpeeds1V signal_value;
   
   if( pFCW_BaseSpeeds_1_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FCW_BaseSpeeds_1_V_b1;
      * pFCW_BaseSpeeds_1_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FCW_BaseSpeeds_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCW_BaseSpeeds_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCW_BaseSpeeds_1
*    FCW_BaseSpeeds_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCW_BaseSpeeds_1 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FCW_BaseSpeeds_1( uint16 * pFCW_BaseSpeeds_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCW_BaseSpeeds_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FCW_BaseSpeeds_1_b15;
      * pFCW_BaseSpeeds_1 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_FCW_BASESPEEDS_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FCW_BaseSpeeds_2_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEFCWBaseSpeeds2V * pFCW_BaseSpeeds_2_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCW_BaseSpeeds_2_V
*    FCW_BaseSpeeds_2_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCW_BaseSpeeds_2_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FCW_BaseSpeeds_2_V( IPBINITEFCWBaseSpeeds2V * pFCW_BaseSpeeds_2_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEFCWBaseSpeeds2V signal_value;
   
   if( pFCW_BaseSpeeds_2_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FCW_BaseSpeeds_2_V_b1;
      * pFCW_BaseSpeeds_2_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FCW_BaseSpeeds_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCW_BaseSpeeds_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCW_BaseSpeeds_2
*    FCW_BaseSpeeds_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCW_BaseSpeeds_2 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FCW_BaseSpeeds_2( uint16 * pFCW_BaseSpeeds_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCW_BaseSpeeds_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FCW_BaseSpeeds_2_b15;
      * pFCW_BaseSpeeds_2 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_FCW_BASESPEEDS_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FCW_BaseSpeeds_3_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEFCWBaseSpeeds3V * pFCW_BaseSpeeds_3_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCW_BaseSpeeds_3_V
*    FCW_BaseSpeeds_3_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCW_BaseSpeeds_3_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FCW_BaseSpeeds_3_V( IPBINITEFCWBaseSpeeds3V * pFCW_BaseSpeeds_3_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEFCWBaseSpeeds3V signal_value;
   
   if( pFCW_BaseSpeeds_3_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FCW_BaseSpeeds_3_V_b1;
      * pFCW_BaseSpeeds_3_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FCW_BaseSpeeds_3
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCW_BaseSpeeds_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCW_BaseSpeeds_3
*    FCW_BaseSpeeds_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCW_BaseSpeeds_3 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FCW_BaseSpeeds_3( uint16 * pFCW_BaseSpeeds_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCW_BaseSpeeds_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FCW_BaseSpeeds_3_b15;
      * pFCW_BaseSpeeds_3 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_FCW_BASESPEEDS_3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FCW_BaseSpeeds_4_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEFCWBaseSpeeds4V * pFCW_BaseSpeeds_4_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCW_BaseSpeeds_4_V
*    FCW_BaseSpeeds_4_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCW_BaseSpeeds_4_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FCW_BaseSpeeds_4_V( IPBINITEFCWBaseSpeeds4V * pFCW_BaseSpeeds_4_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEFCWBaseSpeeds4V signal_value;
   
   if( pFCW_BaseSpeeds_4_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FCW_BaseSpeeds_4_V_b1;
      * pFCW_BaseSpeeds_4_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FCW_BaseSpeeds_4
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCW_BaseSpeeds_4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCW_BaseSpeeds_4
*    FCW_BaseSpeeds_4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCW_BaseSpeeds_4 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FCW_BaseSpeeds_4( uint16 * pFCW_BaseSpeeds_4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCW_BaseSpeeds_4 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FCW_BaseSpeeds_4_b15;
      * pFCW_BaseSpeeds_4 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_FCW_BASESPEEDS_4_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FCW_BaseSpeeds_5_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEFCWBaseSpeeds5V * pFCW_BaseSpeeds_5_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCW_BaseSpeeds_5_V
*    FCW_BaseSpeeds_5_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCW_BaseSpeeds_5_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FCW_BaseSpeeds_5_V( IPBINITEFCWBaseSpeeds5V * pFCW_BaseSpeeds_5_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEFCWBaseSpeeds5V signal_value;
   
   if( pFCW_BaseSpeeds_5_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FCW_BaseSpeeds_5_V_b1;
      * pFCW_BaseSpeeds_5_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FCW_BaseSpeeds_5
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCW_BaseSpeeds_5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCW_BaseSpeeds_5
*    FCW_BaseSpeeds_5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCW_BaseSpeeds_5 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FCW_BaseSpeeds_5( uint16 * pFCW_BaseSpeeds_5 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCW_BaseSpeeds_5 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FCW_BaseSpeeds_5_b15;
      * pFCW_BaseSpeeds_5 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_FCW_BASESPEEDS_5_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FCW_BaseSpeeds_6_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEFCWBaseSpeeds6V * pFCW_BaseSpeeds_6_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCW_BaseSpeeds_6_V
*    FCW_BaseSpeeds_6_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCW_BaseSpeeds_6_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FCW_BaseSpeeds_6_V( IPBINITEFCWBaseSpeeds6V * pFCW_BaseSpeeds_6_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEFCWBaseSpeeds6V signal_value;
   
   if( pFCW_BaseSpeeds_6_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FCW_BaseSpeeds_6_V_b1;
      * pFCW_BaseSpeeds_6_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FCW_BaseSpeeds_6
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCW_BaseSpeeds_6 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCW_BaseSpeeds_6
*    FCW_BaseSpeeds_6 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCW_BaseSpeeds_6 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FCW_BaseSpeeds_6( uint16 * pFCW_BaseSpeeds_6 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCW_BaseSpeeds_6 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FCW_BaseSpeeds_6_b15;
      * pFCW_BaseSpeeds_6 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_FCW_BASESPEEDS_6_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FCW_BaseSpeeds_7_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEFCWBaseSpeeds7V * pFCW_BaseSpeeds_7_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCW_BaseSpeeds_7_V
*    FCW_BaseSpeeds_7_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCW_BaseSpeeds_7_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FCW_BaseSpeeds_7_V( IPBINITEFCWBaseSpeeds7V * pFCW_BaseSpeeds_7_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEFCWBaseSpeeds7V signal_value;
   
   if( pFCW_BaseSpeeds_7_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FCW_BaseSpeeds_7_V_b1;
      * pFCW_BaseSpeeds_7_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FCW_BaseSpeeds_7
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCW_BaseSpeeds_7 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCW_BaseSpeeds_7
*    FCW_BaseSpeeds_7 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCW_BaseSpeeds_7 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FCW_BaseSpeeds_7( uint16 * pFCW_BaseSpeeds_7 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCW_BaseSpeeds_7 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FCW_BaseSpeeds_7_b15;
      * pFCW_BaseSpeeds_7 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_FCW_BASESPEEDS_7_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FCW_Deceleration_0_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEFCWDeceleration0V * pFCW_Deceleration_0_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCW_Deceleration_0_V
*    FCW_Deceleration_0_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCW_Deceleration_0_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FCW_Deceleration_0_V( IPBINITEFCWDeceleration0V * pFCW_Deceleration_0_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEFCWDeceleration0V signal_value;
   
   if( pFCW_Deceleration_0_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FCW_Deceleration_0_V_b1;
      * pFCW_Deceleration_0_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FCW_Deceleration_0
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCW_Deceleration_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCW_Deceleration_0
*    FCW_Deceleration_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCW_Deceleration_0 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FCW_Deceleration_0( uint16 * pFCW_Deceleration_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCW_Deceleration_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FCW_Deceleration_0_b10;
      * pFCW_Deceleration_0 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_FCW_DECELERATION_0_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_13_V
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_13_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_13_V
*    IIPB_Buffer_13_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_13_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_13_V( boolean * pIIPB_Buffer_13_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_13_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_13_V_b1;
      * pIIPB_Buffer_13_V = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_13_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_13
*
* FUNCTION ARGUMENTS:
*    uint8 * pIIPB_Buffer_13 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_13
*    IIPB_Buffer_13 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_13 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_13( uint8 * pIIPB_Buffer_13 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pIIPB_Buffer_13 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_13_b4;
      * pIIPB_Buffer_13 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_13_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FCW_Deceleration_1_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEFCWDeceleration1V * pFCW_Deceleration_1_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCW_Deceleration_1_V
*    FCW_Deceleration_1_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCW_Deceleration_1_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FCW_Deceleration_1_V( IPBINITEFCWDeceleration1V * pFCW_Deceleration_1_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEFCWDeceleration1V signal_value;
   
   if( pFCW_Deceleration_1_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FCW_Deceleration_1_V_b1;
      * pFCW_Deceleration_1_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FCW_Deceleration_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCW_Deceleration_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCW_Deceleration_1
*    FCW_Deceleration_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCW_Deceleration_1 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FCW_Deceleration_1( uint16 * pFCW_Deceleration_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCW_Deceleration_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FCW_Deceleration_1_b10;
      * pFCW_Deceleration_1 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_FCW_DECELERATION_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FCW_Deceleration_2_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEFCWDeceleration2V * pFCW_Deceleration_2_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCW_Deceleration_2_V
*    FCW_Deceleration_2_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCW_Deceleration_2_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FCW_Deceleration_2_V( IPBINITEFCWDeceleration2V * pFCW_Deceleration_2_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEFCWDeceleration2V signal_value;
   
   if( pFCW_Deceleration_2_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FCW_Deceleration_2_V_b1;
      * pFCW_Deceleration_2_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FCW_Deceleration_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCW_Deceleration_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCW_Deceleration_2
*    FCW_Deceleration_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCW_Deceleration_2 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FCW_Deceleration_2( uint16 * pFCW_Deceleration_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCW_Deceleration_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FCW_Deceleration_2_b10;
      * pFCW_Deceleration_2 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_FCW_DECELERATION_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FCW_Deceleration_reduction_0_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEFCWDecelerationReduction0V * pFCW_Deceleration_reduction_0_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCW_Deceleration_reduction_0_V
*    FCW_Deceleration_reduction_0_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCW_Deceleration_reduction_0_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FCW_Deceleration_reduction_0_V( IPBINITEFCWDecelerationReduction0V * pFCW_Deceleration_reduction_0_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEFCWDecelerationReduction0V signal_value;
   
   if( pFCW_Deceleration_reduction_0_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FCW_Deceleration_reduction_0_V_b1;
      * pFCW_Deceleration_reduction_0_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FCW_Deceleration_reduction_0
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCW_Deceleration_reduction_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCW_Deceleration_reduction_0
*    FCW_Deceleration_reduction_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCW_Deceleration_reduction_0 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FCW_Deceleration_reduction_0( uint16 * pFCW_Deceleration_reduction_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCW_Deceleration_reduction_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FCW_Deceleration_reduction_0_b9;
      * pFCW_Deceleration_reduction_0 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_FCW_DECELERATION_REDUCTION_0_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FCW_Deceleration_reduction_1_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEFCWDecelerationReduction1V * pFCW_Deceleration_reduction_1_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCW_Deceleration_reduction_1_V
*    FCW_Deceleration_reduction_1_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCW_Deceleration_reduction_1_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FCW_Deceleration_reduction_1_V( IPBINITEFCWDecelerationReduction1V * pFCW_Deceleration_reduction_1_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEFCWDecelerationReduction1V signal_value;
   
   if( pFCW_Deceleration_reduction_1_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FCW_Deceleration_reduction_1_V_b1;
      * pFCW_Deceleration_reduction_1_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FCW_Deceleration_reduction_1
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCW_Deceleration_reduction_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCW_Deceleration_reduction_1
*    FCW_Deceleration_reduction_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCW_Deceleration_reduction_1 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FCW_Deceleration_reduction_1( uint8 * pFCW_Deceleration_reduction_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCW_Deceleration_reduction_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FCW_Deceleration_reduction_1_b8;
      * pFCW_Deceleration_reduction_1 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_FCW_DECELERATION_REDUCTION_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FCW_Deceleration_reduction_2_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEFCWDecelerationReduction2V * pFCW_Deceleration_reduction_2_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCW_Deceleration_reduction_2_V
*    FCW_Deceleration_reduction_2_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCW_Deceleration_reduction_2_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FCW_Deceleration_reduction_2_V( IPBINITEFCWDecelerationReduction2V * pFCW_Deceleration_reduction_2_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEFCWDecelerationReduction2V signal_value;
   
   if( pFCW_Deceleration_reduction_2_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FCW_Deceleration_reduction_2_V_b1;
      * pFCW_Deceleration_reduction_2_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FCW_Deceleration_reduction_2
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCW_Deceleration_reduction_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCW_Deceleration_reduction_2
*    FCW_Deceleration_reduction_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCW_Deceleration_reduction_2 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FCW_Deceleration_reduction_2( uint8 * pFCW_Deceleration_reduction_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCW_Deceleration_reduction_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FCW_Deceleration_reduction_2_b8;
      * pFCW_Deceleration_reduction_2 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_FCW_DECELERATION_REDUCTION_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FCW_MaxDistance_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEFCWMaxDistanceV * pFCW_MaxDistance_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCW_MaxDistance_V
*    FCW_MaxDistance_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCW_MaxDistance_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FCW_MaxDistance_V( IPBINITEFCWMaxDistanceV * pFCW_MaxDistance_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEFCWMaxDistanceV signal_value;
   
   if( pFCW_MaxDistance_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FCW_MaxDistance_V_b1;
      * pFCW_MaxDistance_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FCW_MaxDistance
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCW_MaxDistance - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCW_MaxDistance
*    FCW_MaxDistance returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCW_MaxDistance signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FCW_MaxDistance( uint16 * pFCW_MaxDistance )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCW_MaxDistance != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FCW_MaxDistance_b14;
      * pFCW_MaxDistance = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_FCW_MAXDISTANCE_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FCW_MaxThresh_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEFCWMaxThreshV * pFCW_MaxThresh_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCW_MaxThresh_V
*    FCW_MaxThresh_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCW_MaxThresh_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FCW_MaxThresh_V( IPBINITEFCWMaxThreshV * pFCW_MaxThresh_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEFCWMaxThreshV signal_value;
   
   if( pFCW_MaxThresh_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FCW_MaxThresh_V_b1;
      * pFCW_MaxThresh_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_FCW_MaxThresh
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCW_MaxThresh - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCW_MaxThresh
*    FCW_MaxThresh returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCW_MaxThresh signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_FCW_MaxThresh( uint16 * pFCW_MaxThresh )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCW_MaxThresh != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.FCW_MaxThresh_b9;
      * pFCW_MaxThresh = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_FCW_MAXTHRESH_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_K_FCAAccelHaloTime_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEKFCAAccelHaloTimeV * pK_FCAAccelHaloTime_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of K_FCAAccelHaloTime_V
*    K_FCAAccelHaloTime_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns K_FCAAccelHaloTime_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_K_FCAAccelHaloTime_V( IPBINITEKFCAAccelHaloTimeV * pK_FCAAccelHaloTime_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEKFCAAccelHaloTimeV signal_value;
   
   if( pK_FCAAccelHaloTime_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.K_FCAAccelHaloTime_V_b1;
      * pK_FCAAccelHaloTime_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_K_FCAAccelHaloTime
*
* FUNCTION ARGUMENTS:
*    uint16 * pK_FCAAccelHaloTime - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of K_FCAAccelHaloTime
*    K_FCAAccelHaloTime returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns K_FCAAccelHaloTime signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_K_FCAAccelHaloTime( uint16 * pK_FCAAccelHaloTime )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pK_FCAAccelHaloTime != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.K_FCAAccelHaloTime_b9;
      * pK_FCAAccelHaloTime = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_K_FCAACCELHALOTIME_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_K_FCAAccelLevel_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEKFCAAccelLevelV * pK_FCAAccelLevel_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of K_FCAAccelLevel_V
*    K_FCAAccelLevel_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns K_FCAAccelLevel_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_K_FCAAccelLevel_V( IPBINITEKFCAAccelLevelV * pK_FCAAccelLevel_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEKFCAAccelLevelV signal_value;
   
   if( pK_FCAAccelLevel_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.K_FCAAccelLevel_V_b1;
      * pK_FCAAccelLevel_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_K_FCAAccelLevel
*
* FUNCTION ARGUMENTS:
*    uint16 * pK_FCAAccelLevel - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of K_FCAAccelLevel
*    K_FCAAccelLevel returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns K_FCAAccelLevel signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_K_FCAAccelLevel( uint16 * pK_FCAAccelLevel )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pK_FCAAccelLevel != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.K_FCAAccelLevel_b10;
      * pK_FCAAccelLevel = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_K_FCAACCELLEVEL_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_K_FCABrakeApplyDur_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEKFCABrakeApplyDurV * pK_FCABrakeApplyDur_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of K_FCABrakeApplyDur_V
*    K_FCABrakeApplyDur_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns K_FCABrakeApplyDur_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_K_FCABrakeApplyDur_V( IPBINITEKFCABrakeApplyDurV * pK_FCABrakeApplyDur_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEKFCABrakeApplyDurV signal_value;
   
   if( pK_FCABrakeApplyDur_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.K_FCABrakeApplyDur_V_b1;
      * pK_FCABrakeApplyDur_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_K_FCABrakeApplyDur
*
* FUNCTION ARGUMENTS:
*    uint8 * pK_FCABrakeApplyDur - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of K_FCABrakeApplyDur
*    K_FCABrakeApplyDur returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns K_FCABrakeApplyDur signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_K_FCABrakeApplyDur( uint8 * pK_FCABrakeApplyDur )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pK_FCABrakeApplyDur != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.K_FCABrakeApplyDur_b7;
      * pK_FCABrakeApplyDur = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_K_FCABRAKEAPPLYDUR_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_K_FCABrakeApplyHaloTime_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEKFCABrakeApplyHaloTimeV * pK_FCABrakeApplyHaloTime_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of K_FCABrakeApplyHaloTime_V
*    K_FCABrakeApplyHaloTime_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns K_FCABrakeApplyHaloTime_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_K_FCABrakeApplyHaloTime_V( IPBINITEKFCABrakeApplyHaloTimeV * pK_FCABrakeApplyHaloTime_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEKFCABrakeApplyHaloTimeV signal_value;
   
   if( pK_FCABrakeApplyHaloTime_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.K_FCABrakeApplyHaloTime_V_b1;
      * pK_FCABrakeApplyHaloTime_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_K_FCABrakeApplyHaloTime
*
* FUNCTION ARGUMENTS:
*    uint16 * pK_FCABrakeApplyHaloTime - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of K_FCABrakeApplyHaloTime
*    K_FCABrakeApplyHaloTime returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns K_FCABrakeApplyHaloTime signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_K_FCABrakeApplyHaloTime( uint16 * pK_FCABrakeApplyHaloTime )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pK_FCABrakeApplyHaloTime != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.K_FCABrakeApplyHaloTime_b9;
      * pK_FCABrakeApplyHaloTime = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_K_FCABRAKEAPPLYHALOTIME_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_K_FCALIATime_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEKFCALIATimeV * pK_FCALIATime_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of K_FCALIATime_V
*    K_FCALIATime_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns K_FCALIATime_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_K_FCALIATime_V( IPBINITEKFCALIATimeV * pK_FCALIATime_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEKFCALIATimeV signal_value;
   
   if( pK_FCALIATime_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.K_FCALIATime_V_b1;
      * pK_FCALIATime_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_K_FCALIATime
*
* FUNCTION ARGUMENTS:
*    uint16 * pK_FCALIATime - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of K_FCALIATime
*    K_FCALIATime returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns K_FCALIATime signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_K_FCALIATime( uint16 * pK_FCALIATime )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pK_FCALIATime != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.K_FCALIATime_b9;
      * pK_FCALIATime = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_K_FCALIATIME_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_14_V
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_14_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_14_V
*    IIPB_Buffer_14_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_14_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_14_V( boolean * pIIPB_Buffer_14_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_14_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_14_V_b1;
      * pIIPB_Buffer_14_V = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_14_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_14
*
* FUNCTION ARGUMENTS:
*    uint8 * pIIPB_Buffer_14 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_14
*    IIPB_Buffer_14 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_14 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_14( uint8 * pIIPB_Buffer_14 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pIIPB_Buffer_14 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_14_b3;
      * pIIPB_Buffer_14 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_14_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_K_FCAR_t_ClutchHaloTime_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEKFCARTClutchHaloTimeV * pK_FCAR_t_ClutchHaloTime_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of K_FCAR_t_ClutchHaloTime_V
*    K_FCAR_t_ClutchHaloTime_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns K_FCAR_t_ClutchHaloTime_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_K_FCAR_t_ClutchHaloTime_V( IPBINITEKFCARTClutchHaloTimeV * pK_FCAR_t_ClutchHaloTime_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEKFCARTClutchHaloTimeV signal_value;
   
   if( pK_FCAR_t_ClutchHaloTime_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.K_FCAR_t_ClutchHaloTime_V_b1;
      * pK_FCAR_t_ClutchHaloTime_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_K_FCAR_t_ClutchHaloTime
*
* FUNCTION ARGUMENTS:
*    uint16 * pK_FCAR_t_ClutchHaloTime - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of K_FCAR_t_ClutchHaloTime
*    K_FCAR_t_ClutchHaloTime returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns K_FCAR_t_ClutchHaloTime signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_K_FCAR_t_ClutchHaloTime( uint16 * pK_FCAR_t_ClutchHaloTime )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pK_FCAR_t_ClutchHaloTime != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.K_FCAR_t_ClutchHaloTime_b9;
      * pK_FCAR_t_ClutchHaloTime = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_K_FCAR_T_CLUTCHHALOTIME_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_K_MaxFCAEnableSpeed_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEKMaxFCAEnableSpeedV * pK_MaxFCAEnableSpeed_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of K_MaxFCAEnableSpeed_V
*    K_MaxFCAEnableSpeed_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns K_MaxFCAEnableSpeed_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_K_MaxFCAEnableSpeed_V( IPBINITEKMaxFCAEnableSpeedV * pK_MaxFCAEnableSpeed_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEKMaxFCAEnableSpeedV signal_value;
   
   if( pK_MaxFCAEnableSpeed_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.K_MaxFCAEnableSpeed_V_b1;
      * pK_MaxFCAEnableSpeed_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_K_MaxFCAEnableSpeed
*
* FUNCTION ARGUMENTS:
*    uint8 * pK_MaxFCAEnableSpeed - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of K_MaxFCAEnableSpeed
*    K_MaxFCAEnableSpeed returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns K_MaxFCAEnableSpeed signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_K_MaxFCAEnableSpeed( uint8 * pK_MaxFCAEnableSpeed )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pK_MaxFCAEnableSpeed != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.K_MaxFCAEnableSpeed_b8;
      * pK_MaxFCAEnableSpeed = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_K_MAXFCAENABLESPEED_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_K_MaxFCAEnableSpeedHysteresis_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEKMaxFCAEnableSpeedHysteresisV * pK_MaxFCAEnableSpeedHysteresis_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of K_MaxFCAEnableSpeedHysteresis_V
*    K_MaxFCAEnableSpeedHysteresis_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns K_MaxFCAEnableSpeedHysteresis_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_K_MaxFCAEnableSpeedHysteresis_V( IPBINITEKMaxFCAEnableSpeedHysteresisV * pK_MaxFCAEnableSpeedHysteresis_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEKMaxFCAEnableSpeedHysteresisV signal_value;
   
   if( pK_MaxFCAEnableSpeedHysteresis_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.K_MaxFCAEnableSpeedHysteresis_V_b1;
      * pK_MaxFCAEnableSpeedHysteresis_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_K_MaxFCAEnableSpeedHysteresis
*
* FUNCTION ARGUMENTS:
*    uint8 * pK_MaxFCAEnableSpeedHysteresis - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of K_MaxFCAEnableSpeedHysteresis
*    K_MaxFCAEnableSpeedHysteresis returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns K_MaxFCAEnableSpeedHysteresis signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_K_MaxFCAEnableSpeedHysteresis( uint8 * pK_MaxFCAEnableSpeedHysteresis )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pK_MaxFCAEnableSpeedHysteresis != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.K_MaxFCAEnableSpeedHysteresis_b6;
      * pK_MaxFCAEnableSpeedHysteresis = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_K_MAXFCAENABLESPEEDHYSTERESIS_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_15_V
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_15_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_15_V
*    IIPB_Buffer_15_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_15_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_15_V( boolean * pIIPB_Buffer_15_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_15_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_15_V_b1;
      * pIIPB_Buffer_15_V = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_15_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_15
*
* FUNCTION ARGUMENTS:
*    uint8 * pIIPB_Buffer_15 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_15
*    IIPB_Buffer_15 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_15 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_15( uint8 * pIIPB_Buffer_15 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pIIPB_Buffer_15 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_15_b5;
      * pIIPB_Buffer_15 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_15_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_K_MinFCAEnableSpeed_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEKMinFCAEnableSpeedV * pK_MinFCAEnableSpeed_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of K_MinFCAEnableSpeed_V
*    K_MinFCAEnableSpeed_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns K_MinFCAEnableSpeed_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_K_MinFCAEnableSpeed_V( IPBINITEKMinFCAEnableSpeedV * pK_MinFCAEnableSpeed_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEKMinFCAEnableSpeedV signal_value;
   
   if( pK_MinFCAEnableSpeed_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.K_MinFCAEnableSpeed_V_b1;
      * pK_MinFCAEnableSpeed_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_K_MinFCAEnableSpeed
*
* FUNCTION ARGUMENTS:
*    uint8 * pK_MinFCAEnableSpeed - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of K_MinFCAEnableSpeed
*    K_MinFCAEnableSpeed returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns K_MinFCAEnableSpeed signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_K_MinFCAEnableSpeed( uint8 * pK_MinFCAEnableSpeed )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pK_MinFCAEnableSpeed != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.K_MinFCAEnableSpeed_b7;
      * pK_MinFCAEnableSpeed = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_K_MINFCAENABLESPEED_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_K_MinFCAEnableSpeedHysteresis_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEKMinFCAEnableSpeedHysteresisV * pK_MinFCAEnableSpeedHysteresis_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of K_MinFCAEnableSpeedHysteresis_V
*    K_MinFCAEnableSpeedHysteresis_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns K_MinFCAEnableSpeedHysteresis_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_K_MinFCAEnableSpeedHysteresis_V( IPBINITEKMinFCAEnableSpeedHysteresisV * pK_MinFCAEnableSpeedHysteresis_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEKMinFCAEnableSpeedHysteresisV signal_value;
   
   if( pK_MinFCAEnableSpeedHysteresis_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.K_MinFCAEnableSpeedHysteresis_V_b1;
      * pK_MinFCAEnableSpeedHysteresis_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_K_MinFCAEnableSpeedHysteresis
*
* FUNCTION ARGUMENTS:
*    uint8 * pK_MinFCAEnableSpeedHysteresis - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of K_MinFCAEnableSpeedHysteresis
*    K_MinFCAEnableSpeedHysteresis returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns K_MinFCAEnableSpeedHysteresis signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_K_MinFCAEnableSpeedHysteresis( uint8 * pK_MinFCAEnableSpeedHysteresis )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pK_MinFCAEnableSpeedHysteresis != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.K_MinFCAEnableSpeedHysteresis_b6;
      * pK_MinFCAEnableSpeedHysteresis = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_K_MINFCAENABLESPEEDHYSTERESIS_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_Medium_FCA_HW_VAL_0_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEMediumFCAHWVAL0V * pMedium_FCA_HW_VAL_0_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Medium_FCA_HW_VAL_0_V
*    Medium_FCA_HW_VAL_0_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Medium_FCA_HW_VAL_0_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_Medium_FCA_HW_VAL_0_V( IPBINITEMediumFCAHWVAL0V * pMedium_FCA_HW_VAL_0_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEMediumFCAHWVAL0V signal_value;
   
   if( pMedium_FCA_HW_VAL_0_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.Medium_FCA_HW_VAL_0_V_b1;
      * pMedium_FCA_HW_VAL_0_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_Medium_FCA_HW_VAL_0
*
* FUNCTION ARGUMENTS:
*    uint8 * pMedium_FCA_HW_VAL_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Medium_FCA_HW_VAL_0
*    Medium_FCA_HW_VAL_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Medium_FCA_HW_VAL_0 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_Medium_FCA_HW_VAL_0( uint8 * pMedium_FCA_HW_VAL_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pMedium_FCA_HW_VAL_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.Medium_FCA_HW_VAL_0_b8;
      * pMedium_FCA_HW_VAL_0 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_Medium_FCA_HW_VAL_1_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEMediumFCAHWVAL1V * pMedium_FCA_HW_VAL_1_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Medium_FCA_HW_VAL_1_V
*    Medium_FCA_HW_VAL_1_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Medium_FCA_HW_VAL_1_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_Medium_FCA_HW_VAL_1_V( IPBINITEMediumFCAHWVAL1V * pMedium_FCA_HW_VAL_1_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEMediumFCAHWVAL1V signal_value;
   
   if( pMedium_FCA_HW_VAL_1_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.Medium_FCA_HW_VAL_1_V_b1;
      * pMedium_FCA_HW_VAL_1_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_Medium_FCA_HW_VAL_1
*
* FUNCTION ARGUMENTS:
*    uint8 * pMedium_FCA_HW_VAL_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Medium_FCA_HW_VAL_1
*    Medium_FCA_HW_VAL_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Medium_FCA_HW_VAL_1 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_Medium_FCA_HW_VAL_1( uint8 * pMedium_FCA_HW_VAL_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pMedium_FCA_HW_VAL_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.Medium_FCA_HW_VAL_1_b8;
      * pMedium_FCA_HW_VAL_1 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_Medium_FCA_HW_VAL_2_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEMediumFCAHWVAL2V * pMedium_FCA_HW_VAL_2_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Medium_FCA_HW_VAL_2_V
*    Medium_FCA_HW_VAL_2_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Medium_FCA_HW_VAL_2_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_Medium_FCA_HW_VAL_2_V( IPBINITEMediumFCAHWVAL2V * pMedium_FCA_HW_VAL_2_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEMediumFCAHWVAL2V signal_value;
   
   if( pMedium_FCA_HW_VAL_2_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.Medium_FCA_HW_VAL_2_V_b1;
      * pMedium_FCA_HW_VAL_2_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_Medium_FCA_HW_VAL_2
*
* FUNCTION ARGUMENTS:
*    uint8 * pMedium_FCA_HW_VAL_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Medium_FCA_HW_VAL_2
*    Medium_FCA_HW_VAL_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Medium_FCA_HW_VAL_2 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_Medium_FCA_HW_VAL_2( uint8 * pMedium_FCA_HW_VAL_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pMedium_FCA_HW_VAL_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.Medium_FCA_HW_VAL_2_b8;
      * pMedium_FCA_HW_VAL_2 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_Medium_FCA_HW_VAL_3_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEMediumFCAHWVAL3V * pMedium_FCA_HW_VAL_3_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Medium_FCA_HW_VAL_3_V
*    Medium_FCA_HW_VAL_3_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Medium_FCA_HW_VAL_3_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_Medium_FCA_HW_VAL_3_V( IPBINITEMediumFCAHWVAL3V * pMedium_FCA_HW_VAL_3_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEMediumFCAHWVAL3V signal_value;
   
   if( pMedium_FCA_HW_VAL_3_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.Medium_FCA_HW_VAL_3_V_b1;
      * pMedium_FCA_HW_VAL_3_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_Medium_FCA_HW_VAL_3
*
* FUNCTION ARGUMENTS:
*    uint8 * pMedium_FCA_HW_VAL_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Medium_FCA_HW_VAL_3
*    Medium_FCA_HW_VAL_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Medium_FCA_HW_VAL_3 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_Medium_FCA_HW_VAL_3( uint8 * pMedium_FCA_HW_VAL_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pMedium_FCA_HW_VAL_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.Medium_FCA_HW_VAL_3_b8;
      * pMedium_FCA_HW_VAL_3 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_Medium_FCA_HW_VAL_4_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEMediumFCAHWVAL4V * pMedium_FCA_HW_VAL_4_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Medium_FCA_HW_VAL_4_V
*    Medium_FCA_HW_VAL_4_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Medium_FCA_HW_VAL_4_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_Medium_FCA_HW_VAL_4_V( IPBINITEMediumFCAHWVAL4V * pMedium_FCA_HW_VAL_4_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEMediumFCAHWVAL4V signal_value;
   
   if( pMedium_FCA_HW_VAL_4_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.Medium_FCA_HW_VAL_4_V_b1;
      * pMedium_FCA_HW_VAL_4_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_Medium_FCA_HW_VAL_4
*
* FUNCTION ARGUMENTS:
*    uint8 * pMedium_FCA_HW_VAL_4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Medium_FCA_HW_VAL_4
*    Medium_FCA_HW_VAL_4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Medium_FCA_HW_VAL_4 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_Medium_FCA_HW_VAL_4( uint8 * pMedium_FCA_HW_VAL_4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pMedium_FCA_HW_VAL_4 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.Medium_FCA_HW_VAL_4_b8;
      * pMedium_FCA_HW_VAL_4 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_16_V
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_16_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_16_V
*    IIPB_Buffer_16_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_16_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_16_V( boolean * pIIPB_Buffer_16_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_16_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_16_V_b1;
      * pIIPB_Buffer_16_V = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_16_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_16
*
* FUNCTION ARGUMENTS:
*    uint8 * pIIPB_Buffer_16 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_16
*    IIPB_Buffer_16 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_16 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_16( uint8 * pIIPB_Buffer_16 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pIIPB_Buffer_16 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_16_b3;
      * pIIPB_Buffer_16 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_16_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_Medium_FCA_HW_VAL_5_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEMediumFCAHWVAL5V * pMedium_FCA_HW_VAL_5_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Medium_FCA_HW_VAL_5_V
*    Medium_FCA_HW_VAL_5_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Medium_FCA_HW_VAL_5_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_Medium_FCA_HW_VAL_5_V( IPBINITEMediumFCAHWVAL5V * pMedium_FCA_HW_VAL_5_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEMediumFCAHWVAL5V signal_value;
   
   if( pMedium_FCA_HW_VAL_5_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.Medium_FCA_HW_VAL_5_V_b1;
      * pMedium_FCA_HW_VAL_5_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_Medium_FCA_HW_VAL_5
*
* FUNCTION ARGUMENTS:
*    uint8 * pMedium_FCA_HW_VAL_5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Medium_FCA_HW_VAL_5
*    Medium_FCA_HW_VAL_5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Medium_FCA_HW_VAL_5 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_Medium_FCA_HW_VAL_5( uint8 * pMedium_FCA_HW_VAL_5 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pMedium_FCA_HW_VAL_5 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.Medium_FCA_HW_VAL_5_b8;
      * pMedium_FCA_HW_VAL_5 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_MEDIUM_TTC_TABLE_0_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEMEDIUMTTCTABLE0V * pMEDIUM_TTC_TABLE_0_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MEDIUM_TTC_TABLE_0_V
*    MEDIUM_TTC_TABLE_0_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MEDIUM_TTC_TABLE_0_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_MEDIUM_TTC_TABLE_0_V( IPBINITEMEDIUMTTCTABLE0V * pMEDIUM_TTC_TABLE_0_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEMEDIUMTTCTABLE0V signal_value;
   
   if( pMEDIUM_TTC_TABLE_0_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.MEDIUM_TTC_TABLE_0_V_b1;
      * pMEDIUM_TTC_TABLE_0_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_MEDIUM_TTC_TABLE_0
*
* FUNCTION ARGUMENTS:
*    uint16 * pMEDIUM_TTC_TABLE_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MEDIUM_TTC_TABLE_0
*    MEDIUM_TTC_TABLE_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MEDIUM_TTC_TABLE_0 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_MEDIUM_TTC_TABLE_0( uint16 * pMEDIUM_TTC_TABLE_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pMEDIUM_TTC_TABLE_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.MEDIUM_TTC_TABLE_0_b10;
      * pMEDIUM_TTC_TABLE_0 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_MEDIUM_TTC_TABLE_0_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_MEDIUM_TTC_TABLE_1_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEMEDIUMTTCTABLE1V * pMEDIUM_TTC_TABLE_1_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MEDIUM_TTC_TABLE_1_V
*    MEDIUM_TTC_TABLE_1_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MEDIUM_TTC_TABLE_1_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_MEDIUM_TTC_TABLE_1_V( IPBINITEMEDIUMTTCTABLE1V * pMEDIUM_TTC_TABLE_1_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEMEDIUMTTCTABLE1V signal_value;
   
   if( pMEDIUM_TTC_TABLE_1_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.MEDIUM_TTC_TABLE_1_V_b1;
      * pMEDIUM_TTC_TABLE_1_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_MEDIUM_TTC_TABLE_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pMEDIUM_TTC_TABLE_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MEDIUM_TTC_TABLE_1
*    MEDIUM_TTC_TABLE_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MEDIUM_TTC_TABLE_1 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_MEDIUM_TTC_TABLE_1( uint16 * pMEDIUM_TTC_TABLE_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pMEDIUM_TTC_TABLE_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.MEDIUM_TTC_TABLE_1_b11;
      * pMEDIUM_TTC_TABLE_1 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_MEDIUM_TTC_TABLE_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_MEDIUM_TTC_TABLE_2_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEMEDIUMTTCTABLE2V * pMEDIUM_TTC_TABLE_2_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MEDIUM_TTC_TABLE_2_V
*    MEDIUM_TTC_TABLE_2_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MEDIUM_TTC_TABLE_2_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_MEDIUM_TTC_TABLE_2_V( IPBINITEMEDIUMTTCTABLE2V * pMEDIUM_TTC_TABLE_2_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEMEDIUMTTCTABLE2V signal_value;
   
   if( pMEDIUM_TTC_TABLE_2_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.MEDIUM_TTC_TABLE_2_V_b1;
      * pMEDIUM_TTC_TABLE_2_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_MEDIUM_TTC_TABLE_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pMEDIUM_TTC_TABLE_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MEDIUM_TTC_TABLE_2
*    MEDIUM_TTC_TABLE_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MEDIUM_TTC_TABLE_2 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_MEDIUM_TTC_TABLE_2( uint16 * pMEDIUM_TTC_TABLE_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pMEDIUM_TTC_TABLE_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.MEDIUM_TTC_TABLE_2_b10;
      * pMEDIUM_TTC_TABLE_2 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_MEDIUM_TTC_TABLE_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_MEDIUM_TTC_TABLE_3_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEMEDIUMTTCTABLE3V * pMEDIUM_TTC_TABLE_3_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MEDIUM_TTC_TABLE_3_V
*    MEDIUM_TTC_TABLE_3_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MEDIUM_TTC_TABLE_3_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_MEDIUM_TTC_TABLE_3_V( IPBINITEMEDIUMTTCTABLE3V * pMEDIUM_TTC_TABLE_3_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEMEDIUMTTCTABLE3V signal_value;
   
   if( pMEDIUM_TTC_TABLE_3_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.MEDIUM_TTC_TABLE_3_V_b1;
      * pMEDIUM_TTC_TABLE_3_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_MEDIUM_TTC_TABLE_3
*
* FUNCTION ARGUMENTS:
*    uint16 * pMEDIUM_TTC_TABLE_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MEDIUM_TTC_TABLE_3
*    MEDIUM_TTC_TABLE_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MEDIUM_TTC_TABLE_3 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_MEDIUM_TTC_TABLE_3( uint16 * pMEDIUM_TTC_TABLE_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pMEDIUM_TTC_TABLE_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.MEDIUM_TTC_TABLE_3_b10;
      * pMEDIUM_TTC_TABLE_3 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_MEDIUM_TTC_TABLE_3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_MEDIUM_TTC_TABLE_4_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEMEDIUMTTCTABLE4V * pMEDIUM_TTC_TABLE_4_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MEDIUM_TTC_TABLE_4_V
*    MEDIUM_TTC_TABLE_4_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MEDIUM_TTC_TABLE_4_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_MEDIUM_TTC_TABLE_4_V( IPBINITEMEDIUMTTCTABLE4V * pMEDIUM_TTC_TABLE_4_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEMEDIUMTTCTABLE4V signal_value;
   
   if( pMEDIUM_TTC_TABLE_4_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.MEDIUM_TTC_TABLE_4_V_b1;
      * pMEDIUM_TTC_TABLE_4_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_MEDIUM_TTC_TABLE_4
*
* FUNCTION ARGUMENTS:
*    uint16 * pMEDIUM_TTC_TABLE_4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MEDIUM_TTC_TABLE_4
*    MEDIUM_TTC_TABLE_4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MEDIUM_TTC_TABLE_4 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_MEDIUM_TTC_TABLE_4( uint16 * pMEDIUM_TTC_TABLE_4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pMEDIUM_TTC_TABLE_4 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.MEDIUM_TTC_TABLE_4_b10;
      * pMEDIUM_TTC_TABLE_4 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_MEDIUM_TTC_TABLE_4_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_MEDIUM_TTC_TABLE_5_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEMEDIUMTTCTABLE5V * pMEDIUM_TTC_TABLE_5_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MEDIUM_TTC_TABLE_5_V
*    MEDIUM_TTC_TABLE_5_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MEDIUM_TTC_TABLE_5_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_MEDIUM_TTC_TABLE_5_V( IPBINITEMEDIUMTTCTABLE5V * pMEDIUM_TTC_TABLE_5_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEMEDIUMTTCTABLE5V signal_value;
   
   if( pMEDIUM_TTC_TABLE_5_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.MEDIUM_TTC_TABLE_5_V_b1;
      * pMEDIUM_TTC_TABLE_5_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_MEDIUM_TTC_TABLE_5
*
* FUNCTION ARGUMENTS:
*    uint16 * pMEDIUM_TTC_TABLE_5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MEDIUM_TTC_TABLE_5
*    MEDIUM_TTC_TABLE_5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MEDIUM_TTC_TABLE_5 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_MEDIUM_TTC_TABLE_5( uint16 * pMEDIUM_TTC_TABLE_5 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pMEDIUM_TTC_TABLE_5 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.MEDIUM_TTC_TABLE_5_b10;
      * pMEDIUM_TTC_TABLE_5 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_MEDIUM_TTC_TABLE_5_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_MEDIUM_TTC_TABLE_6_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEMEDIUMTTCTABLE6V * pMEDIUM_TTC_TABLE_6_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MEDIUM_TTC_TABLE_6_V
*    MEDIUM_TTC_TABLE_6_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MEDIUM_TTC_TABLE_6_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_MEDIUM_TTC_TABLE_6_V( IPBINITEMEDIUMTTCTABLE6V * pMEDIUM_TTC_TABLE_6_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEMEDIUMTTCTABLE6V signal_value;
   
   if( pMEDIUM_TTC_TABLE_6_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.MEDIUM_TTC_TABLE_6_V_b1;
      * pMEDIUM_TTC_TABLE_6_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_MEDIUM_TTC_TABLE_6
*
* FUNCTION ARGUMENTS:
*    uint16 * pMEDIUM_TTC_TABLE_6 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MEDIUM_TTC_TABLE_6
*    MEDIUM_TTC_TABLE_6 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MEDIUM_TTC_TABLE_6 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_MEDIUM_TTC_TABLE_6( uint16 * pMEDIUM_TTC_TABLE_6 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pMEDIUM_TTC_TABLE_6 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.MEDIUM_TTC_TABLE_6_b10;
      * pMEDIUM_TTC_TABLE_6 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_MEDIUM_TTC_TABLE_6_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_17_V
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_17_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_17_V
*    IIPB_Buffer_17_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_17_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_17_V( boolean * pIIPB_Buffer_17_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_17_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_17_V_b1;
      * pIIPB_Buffer_17_V = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_17_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_17
*
* FUNCTION ARGUMENTS:
*    uint8 * pIIPB_Buffer_17 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_17
*    IIPB_Buffer_17 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_17 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_17( uint8 * pIIPB_Buffer_17 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pIIPB_Buffer_17 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_17_b8;
      * pIIPB_Buffer_17 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_17_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_MEDIUM_TTC_TABLE_7_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEMEDIUMTTCTABLE7V * pMEDIUM_TTC_TABLE_7_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MEDIUM_TTC_TABLE_7_V
*    MEDIUM_TTC_TABLE_7_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MEDIUM_TTC_TABLE_7_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_MEDIUM_TTC_TABLE_7_V( IPBINITEMEDIUMTTCTABLE7V * pMEDIUM_TTC_TABLE_7_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEMEDIUMTTCTABLE7V signal_value;
   
   if( pMEDIUM_TTC_TABLE_7_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.MEDIUM_TTC_TABLE_7_V_b1;
      * pMEDIUM_TTC_TABLE_7_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_MEDIUM_TTC_TABLE_7
*
* FUNCTION ARGUMENTS:
*    uint16 * pMEDIUM_TTC_TABLE_7 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MEDIUM_TTC_TABLE_7
*    MEDIUM_TTC_TABLE_7 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MEDIUM_TTC_TABLE_7 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_MEDIUM_TTC_TABLE_7( uint16 * pMEDIUM_TTC_TABLE_7 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pMEDIUM_TTC_TABLE_7 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.MEDIUM_TTC_TABLE_7_b10;
      * pMEDIUM_TTC_TABLE_7 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_MEDIUM_TTC_TABLE_7_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_Near_FCA_HW_VAL_0_V
*
* FUNCTION ARGUMENTS:
*    IPBINITENearFCAHWVAL0V * pNear_FCA_HW_VAL_0_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Near_FCA_HW_VAL_0_V
*    Near_FCA_HW_VAL_0_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Near_FCA_HW_VAL_0_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_Near_FCA_HW_VAL_0_V( IPBINITENearFCAHWVAL0V * pNear_FCA_HW_VAL_0_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITENearFCAHWVAL0V signal_value;
   
   if( pNear_FCA_HW_VAL_0_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.Near_FCA_HW_VAL_0_V_b1;
      * pNear_FCA_HW_VAL_0_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_Near_FCA_HW_VAL_0
*
* FUNCTION ARGUMENTS:
*    uint8 * pNear_FCA_HW_VAL_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Near_FCA_HW_VAL_0
*    Near_FCA_HW_VAL_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Near_FCA_HW_VAL_0 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_Near_FCA_HW_VAL_0( uint8 * pNear_FCA_HW_VAL_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pNear_FCA_HW_VAL_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.Near_FCA_HW_VAL_0_b8;
      * pNear_FCA_HW_VAL_0 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_Near_FCA_HW_VAL_1_V
*
* FUNCTION ARGUMENTS:
*    IPBINITENearFCAHWVAL1V * pNear_FCA_HW_VAL_1_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Near_FCA_HW_VAL_1_V
*    Near_FCA_HW_VAL_1_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Near_FCA_HW_VAL_1_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_Near_FCA_HW_VAL_1_V( IPBINITENearFCAHWVAL1V * pNear_FCA_HW_VAL_1_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITENearFCAHWVAL1V signal_value;
   
   if( pNear_FCA_HW_VAL_1_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.Near_FCA_HW_VAL_1_V_b1;
      * pNear_FCA_HW_VAL_1_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_Near_FCA_HW_VAL_1
*
* FUNCTION ARGUMENTS:
*    uint8 * pNear_FCA_HW_VAL_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Near_FCA_HW_VAL_1
*    Near_FCA_HW_VAL_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Near_FCA_HW_VAL_1 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_Near_FCA_HW_VAL_1( uint8 * pNear_FCA_HW_VAL_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pNear_FCA_HW_VAL_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.Near_FCA_HW_VAL_1_b8;
      * pNear_FCA_HW_VAL_1 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_18_V
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_18_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_18_V
*    IIPB_Buffer_18_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_18_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_18_V( boolean * pIIPB_Buffer_18_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_18_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_18_V_b1;
      * pIIPB_Buffer_18_V = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_18_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_18
*
* FUNCTION ARGUMENTS:
*    uint8 * pIIPB_Buffer_18 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_18
*    IIPB_Buffer_18 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_18 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_18( uint8 * pIIPB_Buffer_18 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pIIPB_Buffer_18 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_18_b2;
      * pIIPB_Buffer_18 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_18_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_Near_FCA_HW_VAL_2_V
*
* FUNCTION ARGUMENTS:
*    IPBINITENearFCAHWVAL2V * pNear_FCA_HW_VAL_2_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Near_FCA_HW_VAL_2_V
*    Near_FCA_HW_VAL_2_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Near_FCA_HW_VAL_2_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_Near_FCA_HW_VAL_2_V( IPBINITENearFCAHWVAL2V * pNear_FCA_HW_VAL_2_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITENearFCAHWVAL2V signal_value;
   
   if( pNear_FCA_HW_VAL_2_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.Near_FCA_HW_VAL_2_V_b1;
      * pNear_FCA_HW_VAL_2_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_Near_FCA_HW_VAL_2
*
* FUNCTION ARGUMENTS:
*    uint8 * pNear_FCA_HW_VAL_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Near_FCA_HW_VAL_2
*    Near_FCA_HW_VAL_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Near_FCA_HW_VAL_2 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_Near_FCA_HW_VAL_2( uint8 * pNear_FCA_HW_VAL_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pNear_FCA_HW_VAL_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.Near_FCA_HW_VAL_2_b8;
      * pNear_FCA_HW_VAL_2 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_Near_FCA_HW_VAL_3_V
*
* FUNCTION ARGUMENTS:
*    IPBINITENearFCAHWVAL3V * pNear_FCA_HW_VAL_3_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Near_FCA_HW_VAL_3_V
*    Near_FCA_HW_VAL_3_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Near_FCA_HW_VAL_3_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_Near_FCA_HW_VAL_3_V( IPBINITENearFCAHWVAL3V * pNear_FCA_HW_VAL_3_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITENearFCAHWVAL3V signal_value;
   
   if( pNear_FCA_HW_VAL_3_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.Near_FCA_HW_VAL_3_V_b1;
      * pNear_FCA_HW_VAL_3_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_Near_FCA_HW_VAL_3
*
* FUNCTION ARGUMENTS:
*    uint8 * pNear_FCA_HW_VAL_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Near_FCA_HW_VAL_3
*    Near_FCA_HW_VAL_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Near_FCA_HW_VAL_3 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_Near_FCA_HW_VAL_3( uint8 * pNear_FCA_HW_VAL_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pNear_FCA_HW_VAL_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.Near_FCA_HW_VAL_3_b8;
      * pNear_FCA_HW_VAL_3 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_Near_FCA_HW_VAL_4_V
*
* FUNCTION ARGUMENTS:
*    IPBINITENearFCAHWVAL4V * pNear_FCA_HW_VAL_4_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Near_FCA_HW_VAL_4_V
*    Near_FCA_HW_VAL_4_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Near_FCA_HW_VAL_4_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_Near_FCA_HW_VAL_4_V( IPBINITENearFCAHWVAL4V * pNear_FCA_HW_VAL_4_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITENearFCAHWVAL4V signal_value;
   
   if( pNear_FCA_HW_VAL_4_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.Near_FCA_HW_VAL_4_V_b1;
      * pNear_FCA_HW_VAL_4_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_Near_FCA_HW_VAL_4
*
* FUNCTION ARGUMENTS:
*    uint8 * pNear_FCA_HW_VAL_4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Near_FCA_HW_VAL_4
*    Near_FCA_HW_VAL_4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Near_FCA_HW_VAL_4 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_Near_FCA_HW_VAL_4( uint8 * pNear_FCA_HW_VAL_4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pNear_FCA_HW_VAL_4 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.Near_FCA_HW_VAL_4_b8;
      * pNear_FCA_HW_VAL_4 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_19_V
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_19_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_19_V
*    IIPB_Buffer_19_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_19_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_19_V( boolean * pIIPB_Buffer_19_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_19_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_19_V_b1;
      * pIIPB_Buffer_19_V = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_19_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_19
*
* FUNCTION ARGUMENTS:
*    uint8 * pIIPB_Buffer_19 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_19
*    IIPB_Buffer_19 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_19 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_19( uint8 * pIIPB_Buffer_19 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pIIPB_Buffer_19 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_19_b4;
      * pIIPB_Buffer_19 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_19_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_Near_FCA_HW_VAL_5_V
*
* FUNCTION ARGUMENTS:
*    IPBINITENearFCAHWVAL5V * pNear_FCA_HW_VAL_5_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Near_FCA_HW_VAL_5_V
*    Near_FCA_HW_VAL_5_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Near_FCA_HW_VAL_5_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_Near_FCA_HW_VAL_5_V( IPBINITENearFCAHWVAL5V * pNear_FCA_HW_VAL_5_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITENearFCAHWVAL5V signal_value;
   
   if( pNear_FCA_HW_VAL_5_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.Near_FCA_HW_VAL_5_V_b1;
      * pNear_FCA_HW_VAL_5_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_Near_FCA_HW_VAL_5
*
* FUNCTION ARGUMENTS:
*    uint8 * pNear_FCA_HW_VAL_5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Near_FCA_HW_VAL_5
*    Near_FCA_HW_VAL_5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Near_FCA_HW_VAL_5 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_Near_FCA_HW_VAL_5( uint8 * pNear_FCA_HW_VAL_5 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pNear_FCA_HW_VAL_5 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.Near_FCA_HW_VAL_5_b8;
      * pNear_FCA_HW_VAL_5 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_NEAR_TTC_TABLE_0_V
*
* FUNCTION ARGUMENTS:
*    IPBINITENEARTTCTABLE0V * pNEAR_TTC_TABLE_0_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of NEAR_TTC_TABLE_0_V
*    NEAR_TTC_TABLE_0_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns NEAR_TTC_TABLE_0_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_NEAR_TTC_TABLE_0_V( IPBINITENEARTTCTABLE0V * pNEAR_TTC_TABLE_0_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITENEARTTCTABLE0V signal_value;
   
   if( pNEAR_TTC_TABLE_0_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.NEAR_TTC_TABLE_0_V_b1;
      * pNEAR_TTC_TABLE_0_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_NEAR_TTC_TABLE_0
*
* FUNCTION ARGUMENTS:
*    uint16 * pNEAR_TTC_TABLE_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of NEAR_TTC_TABLE_0
*    NEAR_TTC_TABLE_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns NEAR_TTC_TABLE_0 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_NEAR_TTC_TABLE_0( uint16 * pNEAR_TTC_TABLE_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pNEAR_TTC_TABLE_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.NEAR_TTC_TABLE_0_b10;
      * pNEAR_TTC_TABLE_0 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_NEAR_TTC_TABLE_0_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_NEAR_TTC_TABLE_1_V
*
* FUNCTION ARGUMENTS:
*    IPBINITENEARTTCTABLE1V * pNEAR_TTC_TABLE_1_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of NEAR_TTC_TABLE_1_V
*    NEAR_TTC_TABLE_1_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns NEAR_TTC_TABLE_1_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_NEAR_TTC_TABLE_1_V( IPBINITENEARTTCTABLE1V * pNEAR_TTC_TABLE_1_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITENEARTTCTABLE1V signal_value;
   
   if( pNEAR_TTC_TABLE_1_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.NEAR_TTC_TABLE_1_V_b1;
      * pNEAR_TTC_TABLE_1_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_NEAR_TTC_TABLE_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pNEAR_TTC_TABLE_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of NEAR_TTC_TABLE_1
*    NEAR_TTC_TABLE_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns NEAR_TTC_TABLE_1 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_NEAR_TTC_TABLE_1( uint16 * pNEAR_TTC_TABLE_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pNEAR_TTC_TABLE_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.NEAR_TTC_TABLE_1_b11;
      * pNEAR_TTC_TABLE_1 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_NEAR_TTC_TABLE_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_NEAR_TTC_TABLE_2_V
*
* FUNCTION ARGUMENTS:
*    IPBINITENEARTTCTABLE2V * pNEAR_TTC_TABLE_2_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of NEAR_TTC_TABLE_2_V
*    NEAR_TTC_TABLE_2_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns NEAR_TTC_TABLE_2_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_NEAR_TTC_TABLE_2_V( IPBINITENEARTTCTABLE2V * pNEAR_TTC_TABLE_2_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITENEARTTCTABLE2V signal_value;
   
   if( pNEAR_TTC_TABLE_2_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.NEAR_TTC_TABLE_2_V_b1;
      * pNEAR_TTC_TABLE_2_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_NEAR_TTC_TABLE_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pNEAR_TTC_TABLE_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of NEAR_TTC_TABLE_2
*    NEAR_TTC_TABLE_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns NEAR_TTC_TABLE_2 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_NEAR_TTC_TABLE_2( uint16 * pNEAR_TTC_TABLE_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pNEAR_TTC_TABLE_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.NEAR_TTC_TABLE_2_b10;
      * pNEAR_TTC_TABLE_2 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_NEAR_TTC_TABLE_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_NEAR_TTC_TABLE_3_V
*
* FUNCTION ARGUMENTS:
*    IPBINITENEARTTCTABLE3V * pNEAR_TTC_TABLE_3_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of NEAR_TTC_TABLE_3_V
*    NEAR_TTC_TABLE_3_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns NEAR_TTC_TABLE_3_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_NEAR_TTC_TABLE_3_V( IPBINITENEARTTCTABLE3V * pNEAR_TTC_TABLE_3_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITENEARTTCTABLE3V signal_value;
   
   if( pNEAR_TTC_TABLE_3_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.NEAR_TTC_TABLE_3_V_b1;
      * pNEAR_TTC_TABLE_3_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_NEAR_TTC_TABLE_3
*
* FUNCTION ARGUMENTS:
*    uint16 * pNEAR_TTC_TABLE_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of NEAR_TTC_TABLE_3
*    NEAR_TTC_TABLE_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns NEAR_TTC_TABLE_3 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_NEAR_TTC_TABLE_3( uint16 * pNEAR_TTC_TABLE_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pNEAR_TTC_TABLE_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.NEAR_TTC_TABLE_3_b10;
      * pNEAR_TTC_TABLE_3 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_NEAR_TTC_TABLE_3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_NEAR_TTC_TABLE_4_V
*
* FUNCTION ARGUMENTS:
*    IPBINITENEARTTCTABLE4V * pNEAR_TTC_TABLE_4_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of NEAR_TTC_TABLE_4_V
*    NEAR_TTC_TABLE_4_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns NEAR_TTC_TABLE_4_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_NEAR_TTC_TABLE_4_V( IPBINITENEARTTCTABLE4V * pNEAR_TTC_TABLE_4_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITENEARTTCTABLE4V signal_value;
   
   if( pNEAR_TTC_TABLE_4_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.NEAR_TTC_TABLE_4_V_b1;
      * pNEAR_TTC_TABLE_4_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_NEAR_TTC_TABLE_4
*
* FUNCTION ARGUMENTS:
*    uint16 * pNEAR_TTC_TABLE_4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of NEAR_TTC_TABLE_4
*    NEAR_TTC_TABLE_4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns NEAR_TTC_TABLE_4 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_NEAR_TTC_TABLE_4( uint16 * pNEAR_TTC_TABLE_4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pNEAR_TTC_TABLE_4 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.NEAR_TTC_TABLE_4_b10;
      * pNEAR_TTC_TABLE_4 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_NEAR_TTC_TABLE_4_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_NEAR_TTC_TABLE_5_V
*
* FUNCTION ARGUMENTS:
*    IPBINITENEARTTCTABLE5V * pNEAR_TTC_TABLE_5_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of NEAR_TTC_TABLE_5_V
*    NEAR_TTC_TABLE_5_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns NEAR_TTC_TABLE_5_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_NEAR_TTC_TABLE_5_V( IPBINITENEARTTCTABLE5V * pNEAR_TTC_TABLE_5_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITENEARTTCTABLE5V signal_value;
   
   if( pNEAR_TTC_TABLE_5_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.NEAR_TTC_TABLE_5_V_b1;
      * pNEAR_TTC_TABLE_5_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_NEAR_TTC_TABLE_5
*
* FUNCTION ARGUMENTS:
*    uint16 * pNEAR_TTC_TABLE_5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of NEAR_TTC_TABLE_5
*    NEAR_TTC_TABLE_5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns NEAR_TTC_TABLE_5 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_NEAR_TTC_TABLE_5( uint16 * pNEAR_TTC_TABLE_5 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pNEAR_TTC_TABLE_5 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.NEAR_TTC_TABLE_5_b10;
      * pNEAR_TTC_TABLE_5 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_NEAR_TTC_TABLE_5_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_NEAR_TTC_TABLE_6_V
*
* FUNCTION ARGUMENTS:
*    IPBINITENEARTTCTABLE6V * pNEAR_TTC_TABLE_6_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of NEAR_TTC_TABLE_6_V
*    NEAR_TTC_TABLE_6_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns NEAR_TTC_TABLE_6_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_NEAR_TTC_TABLE_6_V( IPBINITENEARTTCTABLE6V * pNEAR_TTC_TABLE_6_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITENEARTTCTABLE6V signal_value;
   
   if( pNEAR_TTC_TABLE_6_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.NEAR_TTC_TABLE_6_V_b1;
      * pNEAR_TTC_TABLE_6_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_NEAR_TTC_TABLE_6
*
* FUNCTION ARGUMENTS:
*    uint16 * pNEAR_TTC_TABLE_6 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of NEAR_TTC_TABLE_6
*    NEAR_TTC_TABLE_6 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns NEAR_TTC_TABLE_6 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_NEAR_TTC_TABLE_6( uint16 * pNEAR_TTC_TABLE_6 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pNEAR_TTC_TABLE_6 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.NEAR_TTC_TABLE_6_b10;
      * pNEAR_TTC_TABLE_6 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_NEAR_TTC_TABLE_6_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_20_V
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_20_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_20_V
*    IIPB_Buffer_20_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_20_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_20_V( boolean * pIIPB_Buffer_20_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_20_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_20_V_b1;
      * pIIPB_Buffer_20_V = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_20_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_20
*
* FUNCTION ARGUMENTS:
*    uint8 * pIIPB_Buffer_20 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_20
*    IIPB_Buffer_20 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_20 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_20( uint8 * pIIPB_Buffer_20 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pIIPB_Buffer_20 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_20_b8;
      * pIIPB_Buffer_20 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_20_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_NEAR_TTC_TABLE_7_V
*
* FUNCTION ARGUMENTS:
*    IPBINITENEARTTCTABLE7V * pNEAR_TTC_TABLE_7_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of NEAR_TTC_TABLE_7_V
*    NEAR_TTC_TABLE_7_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns NEAR_TTC_TABLE_7_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_NEAR_TTC_TABLE_7_V( IPBINITENEARTTCTABLE7V * pNEAR_TTC_TABLE_7_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITENEARTTCTABLE7V signal_value;
   
   if( pNEAR_TTC_TABLE_7_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.NEAR_TTC_TABLE_7_V_b1;
      * pNEAR_TTC_TABLE_7_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_NEAR_TTC_TABLE_7
*
* FUNCTION ARGUMENTS:
*    uint16 * pNEAR_TTC_TABLE_7 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of NEAR_TTC_TABLE_7
*    NEAR_TTC_TABLE_7 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns NEAR_TTC_TABLE_7 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_NEAR_TTC_TABLE_7( uint16 * pNEAR_TTC_TABLE_7 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pNEAR_TTC_TABLE_7 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.NEAR_TTC_TABLE_7_b10;
      * pNEAR_TTC_TABLE_7 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_NEAR_TTC_TABLE_7_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_STEERING_VALUES_TABLE_0_V
*
* FUNCTION ARGUMENTS:
*    IPBINITESTEERINGVALUESTABLE0V * pSTEERING_VALUES_TABLE_0_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of STEERING_VALUES_TABLE_0_V
*    STEERING_VALUES_TABLE_0_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns STEERING_VALUES_TABLE_0_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_STEERING_VALUES_TABLE_0_V( IPBINITESTEERINGVALUESTABLE0V * pSTEERING_VALUES_TABLE_0_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITESTEERINGVALUESTABLE0V signal_value;
   
   if( pSTEERING_VALUES_TABLE_0_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.STEERING_VALUES_TABLE_0_V_b1;
      * pSTEERING_VALUES_TABLE_0_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_STEERING_VALUES_TABLE_0
*
* FUNCTION ARGUMENTS:
*    uint16 * pSTEERING_VALUES_TABLE_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of STEERING_VALUES_TABLE_0
*    STEERING_VALUES_TABLE_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns STEERING_VALUES_TABLE_0 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_STEERING_VALUES_TABLE_0( uint16 * pSTEERING_VALUES_TABLE_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pSTEERING_VALUES_TABLE_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.STEERING_VALUES_TABLE_0_b10;
      * pSTEERING_VALUES_TABLE_0 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_STEERING_VALUES_TABLE_0_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_STEERING_VALUES_TABLE_1_V
*
* FUNCTION ARGUMENTS:
*    IPBINITESTEERINGVALUESTABLE1V * pSTEERING_VALUES_TABLE_1_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of STEERING_VALUES_TABLE_1_V
*    STEERING_VALUES_TABLE_1_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns STEERING_VALUES_TABLE_1_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_STEERING_VALUES_TABLE_1_V( IPBINITESTEERINGVALUESTABLE1V * pSTEERING_VALUES_TABLE_1_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITESTEERINGVALUESTABLE1V signal_value;
   
   if( pSTEERING_VALUES_TABLE_1_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.STEERING_VALUES_TABLE_1_V_b1;
      * pSTEERING_VALUES_TABLE_1_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_STEERING_VALUES_TABLE_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pSTEERING_VALUES_TABLE_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of STEERING_VALUES_TABLE_1
*    STEERING_VALUES_TABLE_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns STEERING_VALUES_TABLE_1 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_STEERING_VALUES_TABLE_1( uint16 * pSTEERING_VALUES_TABLE_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pSTEERING_VALUES_TABLE_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.STEERING_VALUES_TABLE_1_b10;
      * pSTEERING_VALUES_TABLE_1 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_STEERING_VALUES_TABLE_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_STEERING_VALUES_TABLE_2_V
*
* FUNCTION ARGUMENTS:
*    IPBINITESTEERINGVALUESTABLE2V * pSTEERING_VALUES_TABLE_2_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of STEERING_VALUES_TABLE_2_V
*    STEERING_VALUES_TABLE_2_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns STEERING_VALUES_TABLE_2_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_STEERING_VALUES_TABLE_2_V( IPBINITESTEERINGVALUESTABLE2V * pSTEERING_VALUES_TABLE_2_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITESTEERINGVALUESTABLE2V signal_value;
   
   if( pSTEERING_VALUES_TABLE_2_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.STEERING_VALUES_TABLE_2_V_b1;
      * pSTEERING_VALUES_TABLE_2_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_STEERING_VALUES_TABLE_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pSTEERING_VALUES_TABLE_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of STEERING_VALUES_TABLE_2
*    STEERING_VALUES_TABLE_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns STEERING_VALUES_TABLE_2 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_STEERING_VALUES_TABLE_2( uint16 * pSTEERING_VALUES_TABLE_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pSTEERING_VALUES_TABLE_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.STEERING_VALUES_TABLE_2_b10;
      * pSTEERING_VALUES_TABLE_2 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_STEERING_VALUES_TABLE_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_0_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVEgoVsVRelThreshAdditive0V * pvEgo_vs_vRel_threshAdditive_0_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_threshAdditive_0_V
*    vEgo_vs_vRel_threshAdditive_0_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_threshAdditive_0_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_0_V( IPBINITEVEgoVsVRelThreshAdditive0V * pvEgo_vs_vRel_threshAdditive_0_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVEgoVsVRelThreshAdditive0V signal_value;
   
   if( pvEgo_vs_vRel_threshAdditive_0_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_threshAdditive_0_V_b1;
      * pvEgo_vs_vRel_threshAdditive_0_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_0
*
* FUNCTION ARGUMENTS:
*    uint16 * pvEgo_vs_vRel_threshAdditive_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_threshAdditive_0
*    vEgo_vs_vRel_threshAdditive_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_threshAdditive_0 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_0( uint16 * pvEgo_vs_vRel_threshAdditive_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvEgo_vs_vRel_threshAdditive_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_threshAdditive_0_b9;
      * pvEgo_vs_vRel_threshAdditive_0 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VEGO_VS_VREL_THRESHADDITIVE_0_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_1_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVEgoVsVRelThreshAdditive1V * pvEgo_vs_vRel_threshAdditive_1_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_threshAdditive_1_V
*    vEgo_vs_vRel_threshAdditive_1_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_threshAdditive_1_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_1_V( IPBINITEVEgoVsVRelThreshAdditive1V * pvEgo_vs_vRel_threshAdditive_1_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVEgoVsVRelThreshAdditive1V signal_value;
   
   if( pvEgo_vs_vRel_threshAdditive_1_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_threshAdditive_1_V_b1;
      * pvEgo_vs_vRel_threshAdditive_1_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pvEgo_vs_vRel_threshAdditive_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_threshAdditive_1
*    vEgo_vs_vRel_threshAdditive_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_threshAdditive_1 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_1( uint16 * pvEgo_vs_vRel_threshAdditive_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvEgo_vs_vRel_threshAdditive_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_threshAdditive_1_b9;
      * pvEgo_vs_vRel_threshAdditive_1 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VEGO_VS_VREL_THRESHADDITIVE_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_2_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVEgoVsVRelThreshAdditive2V * pvEgo_vs_vRel_threshAdditive_2_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_threshAdditive_2_V
*    vEgo_vs_vRel_threshAdditive_2_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_threshAdditive_2_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_2_V( IPBINITEVEgoVsVRelThreshAdditive2V * pvEgo_vs_vRel_threshAdditive_2_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVEgoVsVRelThreshAdditive2V signal_value;
   
   if( pvEgo_vs_vRel_threshAdditive_2_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_threshAdditive_2_V_b1;
      * pvEgo_vs_vRel_threshAdditive_2_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pvEgo_vs_vRel_threshAdditive_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_threshAdditive_2
*    vEgo_vs_vRel_threshAdditive_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_threshAdditive_2 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_2( uint16 * pvEgo_vs_vRel_threshAdditive_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvEgo_vs_vRel_threshAdditive_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_threshAdditive_2_b9;
      * pvEgo_vs_vRel_threshAdditive_2 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VEGO_VS_VREL_THRESHADDITIVE_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_3_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVEgoVsVRelThreshAdditive3V * pvEgo_vs_vRel_threshAdditive_3_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_threshAdditive_3_V
*    vEgo_vs_vRel_threshAdditive_3_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_threshAdditive_3_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_3_V( IPBINITEVEgoVsVRelThreshAdditive3V * pvEgo_vs_vRel_threshAdditive_3_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVEgoVsVRelThreshAdditive3V signal_value;
   
   if( pvEgo_vs_vRel_threshAdditive_3_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_threshAdditive_3_V_b1;
      * pvEgo_vs_vRel_threshAdditive_3_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_3
*
* FUNCTION ARGUMENTS:
*    uint16 * pvEgo_vs_vRel_threshAdditive_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_threshAdditive_3
*    vEgo_vs_vRel_threshAdditive_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_threshAdditive_3 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_3( uint16 * pvEgo_vs_vRel_threshAdditive_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvEgo_vs_vRel_threshAdditive_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_threshAdditive_3_b9;
      * pvEgo_vs_vRel_threshAdditive_3 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VEGO_VS_VREL_THRESHADDITIVE_3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_4_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVEgoVsVRelThreshAdditive4V * pvEgo_vs_vRel_threshAdditive_4_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_threshAdditive_4_V
*    vEgo_vs_vRel_threshAdditive_4_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_threshAdditive_4_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_4_V( IPBINITEVEgoVsVRelThreshAdditive4V * pvEgo_vs_vRel_threshAdditive_4_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVEgoVsVRelThreshAdditive4V signal_value;
   
   if( pvEgo_vs_vRel_threshAdditive_4_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_threshAdditive_4_V_b1;
      * pvEgo_vs_vRel_threshAdditive_4_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_4
*
* FUNCTION ARGUMENTS:
*    uint16 * pvEgo_vs_vRel_threshAdditive_4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_threshAdditive_4
*    vEgo_vs_vRel_threshAdditive_4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_threshAdditive_4 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_4( uint16 * pvEgo_vs_vRel_threshAdditive_4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvEgo_vs_vRel_threshAdditive_4 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_threshAdditive_4_b9;
      * pvEgo_vs_vRel_threshAdditive_4 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VEGO_VS_VREL_THRESHADDITIVE_4_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_21_V
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_21_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_21_V
*    IIPB_Buffer_21_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_21_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_21_V( boolean * pIIPB_Buffer_21_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_21_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_21_V_b1;
      * pIIPB_Buffer_21_V = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_21_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_21
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_21 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_21
*    IIPB_Buffer_21 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_21 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_21( boolean * pIIPB_Buffer_21 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_21 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_21_b1;
      * pIIPB_Buffer_21 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_21_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_5_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVEgoVsVRelThreshAdditive5V * pvEgo_vs_vRel_threshAdditive_5_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_threshAdditive_5_V
*    vEgo_vs_vRel_threshAdditive_5_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_threshAdditive_5_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_5_V( IPBINITEVEgoVsVRelThreshAdditive5V * pvEgo_vs_vRel_threshAdditive_5_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVEgoVsVRelThreshAdditive5V signal_value;
   
   if( pvEgo_vs_vRel_threshAdditive_5_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_threshAdditive_5_V_b1;
      * pvEgo_vs_vRel_threshAdditive_5_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_5
*
* FUNCTION ARGUMENTS:
*    uint16 * pvEgo_vs_vRel_threshAdditive_5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_threshAdditive_5
*    vEgo_vs_vRel_threshAdditive_5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_threshAdditive_5 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_5( uint16 * pvEgo_vs_vRel_threshAdditive_5 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvEgo_vs_vRel_threshAdditive_5 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_threshAdditive_5_b9;
      * pvEgo_vs_vRel_threshAdditive_5 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VEGO_VS_VREL_THRESHADDITIVE_5_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_6_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVEgoVsVRelThreshAdditive6V * pvEgo_vs_vRel_threshAdditive_6_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_threshAdditive_6_V
*    vEgo_vs_vRel_threshAdditive_6_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_threshAdditive_6_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_6_V( IPBINITEVEgoVsVRelThreshAdditive6V * pvEgo_vs_vRel_threshAdditive_6_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVEgoVsVRelThreshAdditive6V signal_value;
   
   if( pvEgo_vs_vRel_threshAdditive_6_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_threshAdditive_6_V_b1;
      * pvEgo_vs_vRel_threshAdditive_6_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_6
*
* FUNCTION ARGUMENTS:
*    uint16 * pvEgo_vs_vRel_threshAdditive_6 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_threshAdditive_6
*    vEgo_vs_vRel_threshAdditive_6 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_threshAdditive_6 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_6( uint16 * pvEgo_vs_vRel_threshAdditive_6 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvEgo_vs_vRel_threshAdditive_6 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_threshAdditive_6_b9;
      * pvEgo_vs_vRel_threshAdditive_6 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VEGO_VS_VREL_THRESHADDITIVE_6_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_7_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVEgoVsVRelThreshAdditive7V * pvEgo_vs_vRel_threshAdditive_7_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_threshAdditive_7_V
*    vEgo_vs_vRel_threshAdditive_7_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_threshAdditive_7_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_7_V( IPBINITEVEgoVsVRelThreshAdditive7V * pvEgo_vs_vRel_threshAdditive_7_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVEgoVsVRelThreshAdditive7V signal_value;
   
   if( pvEgo_vs_vRel_threshAdditive_7_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_threshAdditive_7_V_b1;
      * pvEgo_vs_vRel_threshAdditive_7_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_7
*
* FUNCTION ARGUMENTS:
*    uint16 * pvEgo_vs_vRel_threshAdditive_7 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_threshAdditive_7
*    vEgo_vs_vRel_threshAdditive_7 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_threshAdditive_7 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_7( uint16 * pvEgo_vs_vRel_threshAdditive_7 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvEgo_vs_vRel_threshAdditive_7 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_threshAdditive_7_b9;
      * pvEgo_vs_vRel_threshAdditive_7 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VEGO_VS_VREL_THRESHADDITIVE_7_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_22_V
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_22_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_22_V
*    IIPB_Buffer_22_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_22_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_22_V( boolean * pIIPB_Buffer_22_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_22_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_22_V_b1;
      * pIIPB_Buffer_22_V = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_22_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_22
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_22 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_22
*    IIPB_Buffer_22 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_22 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_22( boolean * pIIPB_Buffer_22 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_22 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_22_b1;
      * pIIPB_Buffer_22 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_22_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_8_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVEgoVsVRelThreshAdditive8V * pvEgo_vs_vRel_threshAdditive_8_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_threshAdditive_8_V
*    vEgo_vs_vRel_threshAdditive_8_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_threshAdditive_8_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_8_V( IPBINITEVEgoVsVRelThreshAdditive8V * pvEgo_vs_vRel_threshAdditive_8_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVEgoVsVRelThreshAdditive8V signal_value;
   
   if( pvEgo_vs_vRel_threshAdditive_8_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_threshAdditive_8_V_b1;
      * pvEgo_vs_vRel_threshAdditive_8_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_8
*
* FUNCTION ARGUMENTS:
*    uint16 * pvEgo_vs_vRel_threshAdditive_8 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_threshAdditive_8
*    vEgo_vs_vRel_threshAdditive_8 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_threshAdditive_8 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_8( uint16 * pvEgo_vs_vRel_threshAdditive_8 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvEgo_vs_vRel_threshAdditive_8 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_threshAdditive_8_b9;
      * pvEgo_vs_vRel_threshAdditive_8 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VEGO_VS_VREL_THRESHADDITIVE_8_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_9_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVEgoVsVRelThreshAdditive9V * pvEgo_vs_vRel_threshAdditive_9_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_threshAdditive_9_V
*    vEgo_vs_vRel_threshAdditive_9_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_threshAdditive_9_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_9_V( IPBINITEVEgoVsVRelThreshAdditive9V * pvEgo_vs_vRel_threshAdditive_9_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVEgoVsVRelThreshAdditive9V signal_value;
   
   if( pvEgo_vs_vRel_threshAdditive_9_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_threshAdditive_9_V_b1;
      * pvEgo_vs_vRel_threshAdditive_9_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_9
*
* FUNCTION ARGUMENTS:
*    uint16 * pvEgo_vs_vRel_threshAdditive_9 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_threshAdditive_9
*    vEgo_vs_vRel_threshAdditive_9 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_threshAdditive_9 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_9( uint16 * pvEgo_vs_vRel_threshAdditive_9 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvEgo_vs_vRel_threshAdditive_9 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_threshAdditive_9_b9;
      * pvEgo_vs_vRel_threshAdditive_9 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VEGO_VS_VREL_THRESHADDITIVE_9_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_10_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVEgoVsVRelThreshAdditive10V * pvEgo_vs_vRel_threshAdditive_10_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_threshAdditive_10_V
*    vEgo_vs_vRel_threshAdditive_10_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_threshAdditive_10_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_10_V( IPBINITEVEgoVsVRelThreshAdditive10V * pvEgo_vs_vRel_threshAdditive_10_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVEgoVsVRelThreshAdditive10V signal_value;
   
   if( pvEgo_vs_vRel_threshAdditive_10_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_threshAdditive_10_V_b1;
      * pvEgo_vs_vRel_threshAdditive_10_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_10
*
* FUNCTION ARGUMENTS:
*    uint16 * pvEgo_vs_vRel_threshAdditive_10 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_threshAdditive_10
*    vEgo_vs_vRel_threshAdditive_10 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_threshAdditive_10 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_10( uint16 * pvEgo_vs_vRel_threshAdditive_10 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvEgo_vs_vRel_threshAdditive_10 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_threshAdditive_10_b9;
      * pvEgo_vs_vRel_threshAdditive_10 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VEGO_VS_VREL_THRESHADDITIVE_10_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_23_V
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_23_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_23_V
*    IIPB_Buffer_23_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_23_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_23_V( boolean * pIIPB_Buffer_23_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_23_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_23_V_b1;
      * pIIPB_Buffer_23_V = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_23_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_23
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_23 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_23
*    IIPB_Buffer_23 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_23 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_23( boolean * pIIPB_Buffer_23 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_23 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_23_b1;
      * pIIPB_Buffer_23 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_23_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_11_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVEgoVsVRelThreshAdditive11V * pvEgo_vs_vRel_threshAdditive_11_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_threshAdditive_11_V
*    vEgo_vs_vRel_threshAdditive_11_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_threshAdditive_11_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_11_V( IPBINITEVEgoVsVRelThreshAdditive11V * pvEgo_vs_vRel_threshAdditive_11_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVEgoVsVRelThreshAdditive11V signal_value;
   
   if( pvEgo_vs_vRel_threshAdditive_11_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_threshAdditive_11_V_b1;
      * pvEgo_vs_vRel_threshAdditive_11_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_11
*
* FUNCTION ARGUMENTS:
*    uint16 * pvEgo_vs_vRel_threshAdditive_11 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_threshAdditive_11
*    vEgo_vs_vRel_threshAdditive_11 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_threshAdditive_11 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_11( uint16 * pvEgo_vs_vRel_threshAdditive_11 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvEgo_vs_vRel_threshAdditive_11 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_threshAdditive_11_b9;
      * pvEgo_vs_vRel_threshAdditive_11 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VEGO_VS_VREL_THRESHADDITIVE_11_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_12_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVEgoVsVRelThreshAdditive12V * pvEgo_vs_vRel_threshAdditive_12_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_threshAdditive_12_V
*    vEgo_vs_vRel_threshAdditive_12_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_threshAdditive_12_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_12_V( IPBINITEVEgoVsVRelThreshAdditive12V * pvEgo_vs_vRel_threshAdditive_12_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVEgoVsVRelThreshAdditive12V signal_value;
   
   if( pvEgo_vs_vRel_threshAdditive_12_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_threshAdditive_12_V_b1;
      * pvEgo_vs_vRel_threshAdditive_12_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_12
*
* FUNCTION ARGUMENTS:
*    uint16 * pvEgo_vs_vRel_threshAdditive_12 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_threshAdditive_12
*    vEgo_vs_vRel_threshAdditive_12 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_threshAdditive_12 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_12( uint16 * pvEgo_vs_vRel_threshAdditive_12 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvEgo_vs_vRel_threshAdditive_12 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_threshAdditive_12_b9;
      * pvEgo_vs_vRel_threshAdditive_12 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VEGO_VS_VREL_THRESHADDITIVE_12_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_13_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVEgoVsVRelThreshAdditive13V * pvEgo_vs_vRel_threshAdditive_13_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_threshAdditive_13_V
*    vEgo_vs_vRel_threshAdditive_13_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_threshAdditive_13_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_13_V( IPBINITEVEgoVsVRelThreshAdditive13V * pvEgo_vs_vRel_threshAdditive_13_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVEgoVsVRelThreshAdditive13V signal_value;
   
   if( pvEgo_vs_vRel_threshAdditive_13_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_threshAdditive_13_V_b1;
      * pvEgo_vs_vRel_threshAdditive_13_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_13
*
* FUNCTION ARGUMENTS:
*    uint16 * pvEgo_vs_vRel_threshAdditive_13 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_threshAdditive_13
*    vEgo_vs_vRel_threshAdditive_13 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_threshAdditive_13 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_13( uint16 * pvEgo_vs_vRel_threshAdditive_13 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvEgo_vs_vRel_threshAdditive_13 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_threshAdditive_13_b9;
      * pvEgo_vs_vRel_threshAdditive_13 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VEGO_VS_VREL_THRESHADDITIVE_13_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_24_V
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_24_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_24_V
*    IIPB_Buffer_24_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_24_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_24_V( boolean * pIIPB_Buffer_24_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_24_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_24_V_b1;
      * pIIPB_Buffer_24_V = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_24_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_24
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_24 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_24
*    IIPB_Buffer_24 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_24 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_24( boolean * pIIPB_Buffer_24 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_24 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_24_b1;
      * pIIPB_Buffer_24 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_24_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_14_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVEgoVsVRelThreshAdditive14V * pvEgo_vs_vRel_threshAdditive_14_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_threshAdditive_14_V
*    vEgo_vs_vRel_threshAdditive_14_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_threshAdditive_14_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_14_V( IPBINITEVEgoVsVRelThreshAdditive14V * pvEgo_vs_vRel_threshAdditive_14_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVEgoVsVRelThreshAdditive14V signal_value;
   
   if( pvEgo_vs_vRel_threshAdditive_14_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_threshAdditive_14_V_b1;
      * pvEgo_vs_vRel_threshAdditive_14_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_14
*
* FUNCTION ARGUMENTS:
*    uint16 * pvEgo_vs_vRel_threshAdditive_14 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_threshAdditive_14
*    vEgo_vs_vRel_threshAdditive_14 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_threshAdditive_14 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_14( uint16 * pvEgo_vs_vRel_threshAdditive_14 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvEgo_vs_vRel_threshAdditive_14 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_threshAdditive_14_b9;
      * pvEgo_vs_vRel_threshAdditive_14 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VEGO_VS_VREL_THRESHADDITIVE_14_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_15_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVEgoVsVRelThreshAdditive15V * pvEgo_vs_vRel_threshAdditive_15_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_threshAdditive_15_V
*    vEgo_vs_vRel_threshAdditive_15_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_threshAdditive_15_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_15_V( IPBINITEVEgoVsVRelThreshAdditive15V * pvEgo_vs_vRel_threshAdditive_15_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVEgoVsVRelThreshAdditive15V signal_value;
   
   if( pvEgo_vs_vRel_threshAdditive_15_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_threshAdditive_15_V_b1;
      * pvEgo_vs_vRel_threshAdditive_15_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_15
*
* FUNCTION ARGUMENTS:
*    uint16 * pvEgo_vs_vRel_threshAdditive_15 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_threshAdditive_15
*    vEgo_vs_vRel_threshAdditive_15 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_threshAdditive_15 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_15( uint16 * pvEgo_vs_vRel_threshAdditive_15 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvEgo_vs_vRel_threshAdditive_15 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_threshAdditive_15_b9;
      * pvEgo_vs_vRel_threshAdditive_15 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VEGO_VS_VREL_THRESHADDITIVE_15_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_16_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVEgoVsVRelThreshAdditive16V * pvEgo_vs_vRel_threshAdditive_16_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_threshAdditive_16_V
*    vEgo_vs_vRel_threshAdditive_16_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_threshAdditive_16_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_16_V( IPBINITEVEgoVsVRelThreshAdditive16V * pvEgo_vs_vRel_threshAdditive_16_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVEgoVsVRelThreshAdditive16V signal_value;
   
   if( pvEgo_vs_vRel_threshAdditive_16_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_threshAdditive_16_V_b1;
      * pvEgo_vs_vRel_threshAdditive_16_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_16
*
* FUNCTION ARGUMENTS:
*    uint16 * pvEgo_vs_vRel_threshAdditive_16 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_threshAdditive_16
*    vEgo_vs_vRel_threshAdditive_16 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_threshAdditive_16 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_16( uint16 * pvEgo_vs_vRel_threshAdditive_16 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvEgo_vs_vRel_threshAdditive_16 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_threshAdditive_16_b9;
      * pvEgo_vs_vRel_threshAdditive_16 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VEGO_VS_VREL_THRESHADDITIVE_16_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_25_V
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_25_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_25_V
*    IIPB_Buffer_25_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_25_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_25_V( boolean * pIIPB_Buffer_25_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_25_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_25_V_b1;
      * pIIPB_Buffer_25_V = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_25_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_25
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_25 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_25
*    IIPB_Buffer_25 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_25 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_25( boolean * pIIPB_Buffer_25 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_25 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_25_b1;
      * pIIPB_Buffer_25 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_25_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_17_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVEgoVsVRelThreshAdditive17V * pvEgo_vs_vRel_threshAdditive_17_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_threshAdditive_17_V
*    vEgo_vs_vRel_threshAdditive_17_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_threshAdditive_17_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_17_V( IPBINITEVEgoVsVRelThreshAdditive17V * pvEgo_vs_vRel_threshAdditive_17_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVEgoVsVRelThreshAdditive17V signal_value;
   
   if( pvEgo_vs_vRel_threshAdditive_17_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_threshAdditive_17_V_b1;
      * pvEgo_vs_vRel_threshAdditive_17_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_17
*
* FUNCTION ARGUMENTS:
*    uint16 * pvEgo_vs_vRel_threshAdditive_17 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_threshAdditive_17
*    vEgo_vs_vRel_threshAdditive_17 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_threshAdditive_17 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_17( uint16 * pvEgo_vs_vRel_threshAdditive_17 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvEgo_vs_vRel_threshAdditive_17 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_threshAdditive_17_b9;
      * pvEgo_vs_vRel_threshAdditive_17 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VEGO_VS_VREL_THRESHADDITIVE_17_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_18_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVEgoVsVRelThreshAdditive18V * pvEgo_vs_vRel_threshAdditive_18_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_threshAdditive_18_V
*    vEgo_vs_vRel_threshAdditive_18_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_threshAdditive_18_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_18_V( IPBINITEVEgoVsVRelThreshAdditive18V * pvEgo_vs_vRel_threshAdditive_18_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVEgoVsVRelThreshAdditive18V signal_value;
   
   if( pvEgo_vs_vRel_threshAdditive_18_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_threshAdditive_18_V_b1;
      * pvEgo_vs_vRel_threshAdditive_18_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_18
*
* FUNCTION ARGUMENTS:
*    uint16 * pvEgo_vs_vRel_threshAdditive_18 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_threshAdditive_18
*    vEgo_vs_vRel_threshAdditive_18 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_threshAdditive_18 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_18( uint16 * pvEgo_vs_vRel_threshAdditive_18 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvEgo_vs_vRel_threshAdditive_18 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_threshAdditive_18_b9;
      * pvEgo_vs_vRel_threshAdditive_18 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VEGO_VS_VREL_THRESHADDITIVE_18_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_19_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVEgoVsVRelThreshAdditive19V * pvEgo_vs_vRel_threshAdditive_19_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_threshAdditive_19_V
*    vEgo_vs_vRel_threshAdditive_19_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_threshAdditive_19_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_19_V( IPBINITEVEgoVsVRelThreshAdditive19V * pvEgo_vs_vRel_threshAdditive_19_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVEgoVsVRelThreshAdditive19V signal_value;
   
   if( pvEgo_vs_vRel_threshAdditive_19_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_threshAdditive_19_V_b1;
      * pvEgo_vs_vRel_threshAdditive_19_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_19
*
* FUNCTION ARGUMENTS:
*    uint16 * pvEgo_vs_vRel_threshAdditive_19 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_threshAdditive_19
*    vEgo_vs_vRel_threshAdditive_19 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_threshAdditive_19 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_19( uint16 * pvEgo_vs_vRel_threshAdditive_19 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvEgo_vs_vRel_threshAdditive_19 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_threshAdditive_19_b9;
      * pvEgo_vs_vRel_threshAdditive_19 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VEGO_VS_VREL_THRESHADDITIVE_19_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_26_V
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_26_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_26_V
*    IIPB_Buffer_26_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_26_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_26_V( boolean * pIIPB_Buffer_26_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_26_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_26_V_b1;
      * pIIPB_Buffer_26_V = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_26_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_26
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_26 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_26
*    IIPB_Buffer_26 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_26 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_26( boolean * pIIPB_Buffer_26 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_26 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_26_b1;
      * pIIPB_Buffer_26 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_26_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_20_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVEgoVsVRelThreshAdditive20V * pvEgo_vs_vRel_threshAdditive_20_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_threshAdditive_20_V
*    vEgo_vs_vRel_threshAdditive_20_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_threshAdditive_20_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_20_V( IPBINITEVEgoVsVRelThreshAdditive20V * pvEgo_vs_vRel_threshAdditive_20_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVEgoVsVRelThreshAdditive20V signal_value;
   
   if( pvEgo_vs_vRel_threshAdditive_20_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_threshAdditive_20_V_b1;
      * pvEgo_vs_vRel_threshAdditive_20_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_20
*
* FUNCTION ARGUMENTS:
*    uint16 * pvEgo_vs_vRel_threshAdditive_20 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_threshAdditive_20
*    vEgo_vs_vRel_threshAdditive_20 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_threshAdditive_20 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_20( uint16 * pvEgo_vs_vRel_threshAdditive_20 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvEgo_vs_vRel_threshAdditive_20 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_threshAdditive_20_b9;
      * pvEgo_vs_vRel_threshAdditive_20 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VEGO_VS_VREL_THRESHADDITIVE_20_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_21_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVEgoVsVRelThreshAdditive21V * pvEgo_vs_vRel_threshAdditive_21_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_threshAdditive_21_V
*    vEgo_vs_vRel_threshAdditive_21_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_threshAdditive_21_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_21_V( IPBINITEVEgoVsVRelThreshAdditive21V * pvEgo_vs_vRel_threshAdditive_21_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVEgoVsVRelThreshAdditive21V signal_value;
   
   if( pvEgo_vs_vRel_threshAdditive_21_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_threshAdditive_21_V_b1;
      * pvEgo_vs_vRel_threshAdditive_21_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_21
*
* FUNCTION ARGUMENTS:
*    uint16 * pvEgo_vs_vRel_threshAdditive_21 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_threshAdditive_21
*    vEgo_vs_vRel_threshAdditive_21 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_threshAdditive_21 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_21( uint16 * pvEgo_vs_vRel_threshAdditive_21 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvEgo_vs_vRel_threshAdditive_21 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_threshAdditive_21_b9;
      * pvEgo_vs_vRel_threshAdditive_21 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VEGO_VS_VREL_THRESHADDITIVE_21_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_22_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVEgoVsVRelThreshAdditive22V * pvEgo_vs_vRel_threshAdditive_22_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_threshAdditive_22_V
*    vEgo_vs_vRel_threshAdditive_22_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_threshAdditive_22_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_22_V( IPBINITEVEgoVsVRelThreshAdditive22V * pvEgo_vs_vRel_threshAdditive_22_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVEgoVsVRelThreshAdditive22V signal_value;
   
   if( pvEgo_vs_vRel_threshAdditive_22_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_threshAdditive_22_V_b1;
      * pvEgo_vs_vRel_threshAdditive_22_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_22
*
* FUNCTION ARGUMENTS:
*    uint16 * pvEgo_vs_vRel_threshAdditive_22 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_threshAdditive_22
*    vEgo_vs_vRel_threshAdditive_22 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_threshAdditive_22 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_22( uint16 * pvEgo_vs_vRel_threshAdditive_22 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvEgo_vs_vRel_threshAdditive_22 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_threshAdditive_22_b9;
      * pvEgo_vs_vRel_threshAdditive_22 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VEGO_VS_VREL_THRESHADDITIVE_22_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_27_V
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_27_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_27_V
*    IIPB_Buffer_27_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_27_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_27_V( boolean * pIIPB_Buffer_27_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_27_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_27_V_b1;
      * pIIPB_Buffer_27_V = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_27_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_27
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_27 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_27
*    IIPB_Buffer_27 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_27 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_27( boolean * pIIPB_Buffer_27 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_27 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_27_b1;
      * pIIPB_Buffer_27 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_27_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_23_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVEgoVsVRelThreshAdditive23V * pvEgo_vs_vRel_threshAdditive_23_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_threshAdditive_23_V
*    vEgo_vs_vRel_threshAdditive_23_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_threshAdditive_23_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_23_V( IPBINITEVEgoVsVRelThreshAdditive23V * pvEgo_vs_vRel_threshAdditive_23_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVEgoVsVRelThreshAdditive23V signal_value;
   
   if( pvEgo_vs_vRel_threshAdditive_23_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_threshAdditive_23_V_b1;
      * pvEgo_vs_vRel_threshAdditive_23_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_23
*
* FUNCTION ARGUMENTS:
*    uint16 * pvEgo_vs_vRel_threshAdditive_23 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_threshAdditive_23
*    vEgo_vs_vRel_threshAdditive_23 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_threshAdditive_23 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_23( uint16 * pvEgo_vs_vRel_threshAdditive_23 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvEgo_vs_vRel_threshAdditive_23 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_threshAdditive_23_b9;
      * pvEgo_vs_vRel_threshAdditive_23 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VEGO_VS_VREL_THRESHADDITIVE_23_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_24_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVEgoVsVRelThreshAdditive24V * pvEgo_vs_vRel_threshAdditive_24_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_threshAdditive_24_V
*    vEgo_vs_vRel_threshAdditive_24_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_threshAdditive_24_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_24_V( IPBINITEVEgoVsVRelThreshAdditive24V * pvEgo_vs_vRel_threshAdditive_24_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVEgoVsVRelThreshAdditive24V signal_value;
   
   if( pvEgo_vs_vRel_threshAdditive_24_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_threshAdditive_24_V_b1;
      * pvEgo_vs_vRel_threshAdditive_24_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_24
*
* FUNCTION ARGUMENTS:
*    uint16 * pvEgo_vs_vRel_threshAdditive_24 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_threshAdditive_24
*    vEgo_vs_vRel_threshAdditive_24 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_threshAdditive_24 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_threshAdditive_24( uint16 * pvEgo_vs_vRel_threshAdditive_24 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvEgo_vs_vRel_threshAdditive_24 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_threshAdditive_24_b9;
      * pvEgo_vs_vRel_threshAdditive_24 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VEGO_VS_VREL_THRESHADDITIVE_24_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_vEgoKneePts_0_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVEgoVsVRelVEgoKneePts0V * pvEgo_vs_vRel_vEgoKneePts_0_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_vEgoKneePts_0_V
*    vEgo_vs_vRel_vEgoKneePts_0_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_vEgoKneePts_0_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_vEgoKneePts_0_V( IPBINITEVEgoVsVRelVEgoKneePts0V * pvEgo_vs_vRel_vEgoKneePts_0_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVEgoVsVRelVEgoKneePts0V signal_value;
   
   if( pvEgo_vs_vRel_vEgoKneePts_0_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_vEgoKneePts_0_V_b1;
      * pvEgo_vs_vRel_vEgoKneePts_0_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_vEgoKneePts_0
*
* FUNCTION ARGUMENTS:
*    uint16 * pvEgo_vs_vRel_vEgoKneePts_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_vEgoKneePts_0
*    vEgo_vs_vRel_vEgoKneePts_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_vEgoKneePts_0 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_vEgoKneePts_0( uint16 * pvEgo_vs_vRel_vEgoKneePts_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvEgo_vs_vRel_vEgoKneePts_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_vEgoKneePts_0_b12;
      * pvEgo_vs_vRel_vEgoKneePts_0 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VEGO_VS_VREL_VEGOKNEEPTS_0_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_vEgoKneePts_1_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVEgoVsVRelVEgoKneePts1V * pvEgo_vs_vRel_vEgoKneePts_1_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_vEgoKneePts_1_V
*    vEgo_vs_vRel_vEgoKneePts_1_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_vEgoKneePts_1_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_vEgoKneePts_1_V( IPBINITEVEgoVsVRelVEgoKneePts1V * pvEgo_vs_vRel_vEgoKneePts_1_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVEgoVsVRelVEgoKneePts1V signal_value;
   
   if( pvEgo_vs_vRel_vEgoKneePts_1_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_vEgoKneePts_1_V_b1;
      * pvEgo_vs_vRel_vEgoKneePts_1_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_vEgoKneePts_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pvEgo_vs_vRel_vEgoKneePts_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_vEgoKneePts_1
*    vEgo_vs_vRel_vEgoKneePts_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_vEgoKneePts_1 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_vEgoKneePts_1( uint16 * pvEgo_vs_vRel_vEgoKneePts_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvEgo_vs_vRel_vEgoKneePts_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_vEgoKneePts_1_b12;
      * pvEgo_vs_vRel_vEgoKneePts_1 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VEGO_VS_VREL_VEGOKNEEPTS_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_vEgoKneePts_2_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVEgoVsVRelVEgoKneePts2V * pvEgo_vs_vRel_vEgoKneePts_2_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_vEgoKneePts_2_V
*    vEgo_vs_vRel_vEgoKneePts_2_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_vEgoKneePts_2_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_vEgoKneePts_2_V( IPBINITEVEgoVsVRelVEgoKneePts2V * pvEgo_vs_vRel_vEgoKneePts_2_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVEgoVsVRelVEgoKneePts2V signal_value;
   
   if( pvEgo_vs_vRel_vEgoKneePts_2_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_vEgoKneePts_2_V_b1;
      * pvEgo_vs_vRel_vEgoKneePts_2_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_vEgoKneePts_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pvEgo_vs_vRel_vEgoKneePts_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_vEgoKneePts_2
*    vEgo_vs_vRel_vEgoKneePts_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_vEgoKneePts_2 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_vEgoKneePts_2( uint16 * pvEgo_vs_vRel_vEgoKneePts_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvEgo_vs_vRel_vEgoKneePts_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_vEgoKneePts_2_b12;
      * pvEgo_vs_vRel_vEgoKneePts_2 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VEGO_VS_VREL_VEGOKNEEPTS_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_28_V
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_28_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_28_V
*    IIPB_Buffer_28_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_28_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_28_V( boolean * pIIPB_Buffer_28_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_28_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_28_V_b1;
      * pIIPB_Buffer_28_V = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_28_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_28
*
* FUNCTION ARGUMENTS:
*    uint8 * pIIPB_Buffer_28 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_28
*    IIPB_Buffer_28 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_28 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_28( uint8 * pIIPB_Buffer_28 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pIIPB_Buffer_28 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_28_b4;
      * pIIPB_Buffer_28 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_28_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_vEgoKneePts_3_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVEgoVsVRelVEgoKneePts3V * pvEgo_vs_vRel_vEgoKneePts_3_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_vEgoKneePts_3_V
*    vEgo_vs_vRel_vEgoKneePts_3_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_vEgoKneePts_3_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_vEgoKneePts_3_V( IPBINITEVEgoVsVRelVEgoKneePts3V * pvEgo_vs_vRel_vEgoKneePts_3_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVEgoVsVRelVEgoKneePts3V signal_value;
   
   if( pvEgo_vs_vRel_vEgoKneePts_3_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_vEgoKneePts_3_V_b1;
      * pvEgo_vs_vRel_vEgoKneePts_3_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_vEgoKneePts_3
*
* FUNCTION ARGUMENTS:
*    uint16 * pvEgo_vs_vRel_vEgoKneePts_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_vEgoKneePts_3
*    vEgo_vs_vRel_vEgoKneePts_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_vEgoKneePts_3 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_vEgoKneePts_3( uint16 * pvEgo_vs_vRel_vEgoKneePts_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvEgo_vs_vRel_vEgoKneePts_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_vEgoKneePts_3_b12;
      * pvEgo_vs_vRel_vEgoKneePts_3 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VEGO_VS_VREL_VEGOKNEEPTS_3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_vEgoKneePts_4_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVEgoVsVRelVEgoKneePts4V * pvEgo_vs_vRel_vEgoKneePts_4_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_vEgoKneePts_4_V
*    vEgo_vs_vRel_vEgoKneePts_4_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_vEgoKneePts_4_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_vEgoKneePts_4_V( IPBINITEVEgoVsVRelVEgoKneePts4V * pvEgo_vs_vRel_vEgoKneePts_4_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVEgoVsVRelVEgoKneePts4V signal_value;
   
   if( pvEgo_vs_vRel_vEgoKneePts_4_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_vEgoKneePts_4_V_b1;
      * pvEgo_vs_vRel_vEgoKneePts_4_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_vEgoKneePts_4
*
* FUNCTION ARGUMENTS:
*    uint16 * pvEgo_vs_vRel_vEgoKneePts_4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_vEgoKneePts_4
*    vEgo_vs_vRel_vEgoKneePts_4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_vEgoKneePts_4 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_vEgoKneePts_4( uint16 * pvEgo_vs_vRel_vEgoKneePts_4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvEgo_vs_vRel_vEgoKneePts_4 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_vEgoKneePts_4_b12;
      * pvEgo_vs_vRel_vEgoKneePts_4 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VEGO_VS_VREL_VEGOKNEEPTS_4_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_29_V
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_29_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_29_V
*    IIPB_Buffer_29_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_29_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_29_V( boolean * pIIPB_Buffer_29_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_29_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_29_V_b1;
      * pIIPB_Buffer_29_V = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_29_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_29
*
* FUNCTION ARGUMENTS:
*    uint8 * pIIPB_Buffer_29 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_29
*    IIPB_Buffer_29 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_29 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_29( uint8 * pIIPB_Buffer_29 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pIIPB_Buffer_29 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_29_b5;
      * pIIPB_Buffer_29 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_29_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_vRelKneePts_0_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVEgoVsVRelVRelKneePts0V * pvEgo_vs_vRel_vRelKneePts_0_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_vRelKneePts_0_V
*    vEgo_vs_vRel_vRelKneePts_0_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_vRelKneePts_0_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_vRelKneePts_0_V( IPBINITEVEgoVsVRelVRelKneePts0V * pvEgo_vs_vRel_vRelKneePts_0_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVEgoVsVRelVRelKneePts0V signal_value;
   
   if( pvEgo_vs_vRel_vRelKneePts_0_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_vRelKneePts_0_V_b1;
      * pvEgo_vs_vRel_vRelKneePts_0_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_vRelKneePts_0
*
* FUNCTION ARGUMENTS:
*    uint16 * pvEgo_vs_vRel_vRelKneePts_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_vRelKneePts_0
*    vEgo_vs_vRel_vRelKneePts_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_vRelKneePts_0 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_vRelKneePts_0( uint16 * pvEgo_vs_vRel_vRelKneePts_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvEgo_vs_vRel_vRelKneePts_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_vRelKneePts_0_b12;
      * pvEgo_vs_vRel_vRelKneePts_0 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VEGO_VS_VREL_VRELKNEEPTS_0_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_vRelKneePts_1_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVEgoVsVRelVRelKneePts1V * pvEgo_vs_vRel_vRelKneePts_1_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_vRelKneePts_1_V
*    vEgo_vs_vRel_vRelKneePts_1_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_vRelKneePts_1_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_vRelKneePts_1_V( IPBINITEVEgoVsVRelVRelKneePts1V * pvEgo_vs_vRel_vRelKneePts_1_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVEgoVsVRelVRelKneePts1V signal_value;
   
   if( pvEgo_vs_vRel_vRelKneePts_1_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_vRelKneePts_1_V_b1;
      * pvEgo_vs_vRel_vRelKneePts_1_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_vRelKneePts_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pvEgo_vs_vRel_vRelKneePts_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_vRelKneePts_1
*    vEgo_vs_vRel_vRelKneePts_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_vRelKneePts_1 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_vRelKneePts_1( uint16 * pvEgo_vs_vRel_vRelKneePts_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvEgo_vs_vRel_vRelKneePts_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_vRelKneePts_1_b12;
      * pvEgo_vs_vRel_vRelKneePts_1 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VEGO_VS_VREL_VRELKNEEPTS_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_30_V
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_30_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_30_V
*    IIPB_Buffer_30_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_30_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_30_V( boolean * pIIPB_Buffer_30_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_30_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_30_V_b1;
      * pIIPB_Buffer_30_V = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_30_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_30
*
* FUNCTION ARGUMENTS:
*    uint8 * pIIPB_Buffer_30 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_30
*    IIPB_Buffer_30 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_30 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_30( uint8 * pIIPB_Buffer_30 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pIIPB_Buffer_30 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_30_b5;
      * pIIPB_Buffer_30 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_30_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_vRelKneePts_2_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVEgoVsVRelVRelKneePts2V * pvEgo_vs_vRel_vRelKneePts_2_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_vRelKneePts_2_V
*    vEgo_vs_vRel_vRelKneePts_2_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_vRelKneePts_2_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_vRelKneePts_2_V( IPBINITEVEgoVsVRelVRelKneePts2V * pvEgo_vs_vRel_vRelKneePts_2_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVEgoVsVRelVRelKneePts2V signal_value;
   
   if( pvEgo_vs_vRel_vRelKneePts_2_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_vRelKneePts_2_V_b1;
      * pvEgo_vs_vRel_vRelKneePts_2_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_vRelKneePts_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pvEgo_vs_vRel_vRelKneePts_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_vRelKneePts_2
*    vEgo_vs_vRel_vRelKneePts_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_vRelKneePts_2 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_vRelKneePts_2( uint16 * pvEgo_vs_vRel_vRelKneePts_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvEgo_vs_vRel_vRelKneePts_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_vRelKneePts_2_b12;
      * pvEgo_vs_vRel_vRelKneePts_2 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VEGO_VS_VREL_VRELKNEEPTS_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_vRelKneePts_3_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVEgoVsVRelVRelKneePts3V * pvEgo_vs_vRel_vRelKneePts_3_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_vRelKneePts_3_V
*    vEgo_vs_vRel_vRelKneePts_3_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_vRelKneePts_3_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_vRelKneePts_3_V( IPBINITEVEgoVsVRelVRelKneePts3V * pvEgo_vs_vRel_vRelKneePts_3_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVEgoVsVRelVRelKneePts3V signal_value;
   
   if( pvEgo_vs_vRel_vRelKneePts_3_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_vRelKneePts_3_V_b1;
      * pvEgo_vs_vRel_vRelKneePts_3_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_vRelKneePts_3
*
* FUNCTION ARGUMENTS:
*    uint16 * pvEgo_vs_vRel_vRelKneePts_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_vRelKneePts_3
*    vEgo_vs_vRel_vRelKneePts_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_vRelKneePts_3 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_vRelKneePts_3( uint16 * pvEgo_vs_vRel_vRelKneePts_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvEgo_vs_vRel_vRelKneePts_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_vRelKneePts_3_b12;
      * pvEgo_vs_vRel_vRelKneePts_3 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VEGO_VS_VREL_VRELKNEEPTS_3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_31_V
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_31_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_31_V
*    IIPB_Buffer_31_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_31_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_31_V( boolean * pIIPB_Buffer_31_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_31_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_31_V_b1;
      * pIIPB_Buffer_31_V = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_31_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_31
*
* FUNCTION ARGUMENTS:
*    uint8 * pIIPB_Buffer_31 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_31
*    IIPB_Buffer_31 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_31 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_31( uint8 * pIIPB_Buffer_31 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pIIPB_Buffer_31 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_31_b5;
      * pIIPB_Buffer_31 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_31_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_vRelKneePts_4_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVEgoVsVRelVRelKneePts4V * pvEgo_vs_vRel_vRelKneePts_4_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_vRelKneePts_4_V
*    vEgo_vs_vRel_vRelKneePts_4_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_vRelKneePts_4_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_vRelKneePts_4_V( IPBINITEVEgoVsVRelVRelKneePts4V * pvEgo_vs_vRel_vRelKneePts_4_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVEgoVsVRelVRelKneePts4V signal_value;
   
   if( pvEgo_vs_vRel_vRelKneePts_4_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_vRelKneePts_4_V_b1;
      * pvEgo_vs_vRel_vRelKneePts_4_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_vRelKneePts_4
*
* FUNCTION ARGUMENTS:
*    uint16 * pvEgo_vs_vRel_vRelKneePts_4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vEgo_vs_vRel_vRelKneePts_4
*    vEgo_vs_vRel_vRelKneePts_4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vEgo_vs_vRel_vRelKneePts_4 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vEgo_vs_vRel_vRelKneePts_4( uint16 * pvEgo_vs_vRel_vRelKneePts_4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvEgo_vs_vRel_vRelKneePts_4 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vEgo_vs_vRel_vRelKneePts_4_b12;
      * pvEgo_vs_vRel_vRelKneePts_4 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VEGO_VS_VREL_VRELKNEEPTS_4_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_OlapKnePts_0_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVRelVsOlapOlapKnePts0V * pvRel_vs_Olap_OlapKnePts_0_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_OlapKnePts_0_V
*    vRel_vs_Olap_OlapKnePts_0_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_OlapKnePts_0_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_OlapKnePts_0_V( IPBINITEVRelVsOlapOlapKnePts0V * pvRel_vs_Olap_OlapKnePts_0_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVRelVsOlapOlapKnePts0V signal_value;
   
   if( pvRel_vs_Olap_OlapKnePts_0_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_OlapKnePts_0_V_b1;
      * pvRel_vs_Olap_OlapKnePts_0_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_OlapKnePts_0
*
* FUNCTION ARGUMENTS:
*    uint8 * pvRel_vs_Olap_OlapKnePts_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_OlapKnePts_0
*    vRel_vs_Olap_OlapKnePts_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_OlapKnePts_0 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_OlapKnePts_0( uint8 * pvRel_vs_Olap_OlapKnePts_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pvRel_vs_Olap_OlapKnePts_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_OlapKnePts_0_b8;
      * pvRel_vs_Olap_OlapKnePts_0 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VREL_VS_OLAP_OLAPKNEPTS_0_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_OlapKnePts_1_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVRelVsOlapOlapKnePts1V * pvRel_vs_Olap_OlapKnePts_1_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_OlapKnePts_1_V
*    vRel_vs_Olap_OlapKnePts_1_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_OlapKnePts_1_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_OlapKnePts_1_V( IPBINITEVRelVsOlapOlapKnePts1V * pvRel_vs_Olap_OlapKnePts_1_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVRelVsOlapOlapKnePts1V signal_value;
   
   if( pvRel_vs_Olap_OlapKnePts_1_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_OlapKnePts_1_V_b1;
      * pvRel_vs_Olap_OlapKnePts_1_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_OlapKnePts_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pvRel_vs_Olap_OlapKnePts_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_OlapKnePts_1
*    vRel_vs_Olap_OlapKnePts_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_OlapKnePts_1 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_OlapKnePts_1( uint16 * pvRel_vs_Olap_OlapKnePts_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvRel_vs_Olap_OlapKnePts_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_OlapKnePts_1_b9;
      * pvRel_vs_Olap_OlapKnePts_1 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VREL_VS_OLAP_OLAPKNEPTS_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_OlapKnePts_2_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVRelVsOlapOlapKnePts2V * pvRel_vs_Olap_OlapKnePts_2_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_OlapKnePts_2_V
*    vRel_vs_Olap_OlapKnePts_2_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_OlapKnePts_2_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_OlapKnePts_2_V( IPBINITEVRelVsOlapOlapKnePts2V * pvRel_vs_Olap_OlapKnePts_2_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVRelVsOlapOlapKnePts2V signal_value;
   
   if( pvRel_vs_Olap_OlapKnePts_2_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_OlapKnePts_2_V_b1;
      * pvRel_vs_Olap_OlapKnePts_2_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_OlapKnePts_2
*
* FUNCTION ARGUMENTS:
*    uint8 * pvRel_vs_Olap_OlapKnePts_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_OlapKnePts_2
*    vRel_vs_Olap_OlapKnePts_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_OlapKnePts_2 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_OlapKnePts_2( uint8 * pvRel_vs_Olap_OlapKnePts_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pvRel_vs_Olap_OlapKnePts_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_OlapKnePts_2_b8;
      * pvRel_vs_Olap_OlapKnePts_2 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VREL_VS_OLAP_OLAPKNEPTS_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_OlapKnePts_3_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVRelVsOlapOlapKnePts3V * pvRel_vs_Olap_OlapKnePts_3_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_OlapKnePts_3_V
*    vRel_vs_Olap_OlapKnePts_3_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_OlapKnePts_3_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_OlapKnePts_3_V( IPBINITEVRelVsOlapOlapKnePts3V * pvRel_vs_Olap_OlapKnePts_3_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVRelVsOlapOlapKnePts3V signal_value;
   
   if( pvRel_vs_Olap_OlapKnePts_3_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_OlapKnePts_3_V_b1;
      * pvRel_vs_Olap_OlapKnePts_3_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_OlapKnePts_3
*
* FUNCTION ARGUMENTS:
*    uint8 * pvRel_vs_Olap_OlapKnePts_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_OlapKnePts_3
*    vRel_vs_Olap_OlapKnePts_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_OlapKnePts_3 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_OlapKnePts_3( uint8 * pvRel_vs_Olap_OlapKnePts_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pvRel_vs_Olap_OlapKnePts_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_OlapKnePts_3_b8;
      * pvRel_vs_Olap_OlapKnePts_3 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VREL_VS_OLAP_OLAPKNEPTS_3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_OlapKnePts_4_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVRelVsOlapOlapKnePts4V * pvRel_vs_Olap_OlapKnePts_4_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_OlapKnePts_4_V
*    vRel_vs_Olap_OlapKnePts_4_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_OlapKnePts_4_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_OlapKnePts_4_V( IPBINITEVRelVsOlapOlapKnePts4V * pvRel_vs_Olap_OlapKnePts_4_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVRelVsOlapOlapKnePts4V signal_value;
   
   if( pvRel_vs_Olap_OlapKnePts_4_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_OlapKnePts_4_V_b1;
      * pvRel_vs_Olap_OlapKnePts_4_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_OlapKnePts_4
*
* FUNCTION ARGUMENTS:
*    uint8 * pvRel_vs_Olap_OlapKnePts_4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_OlapKnePts_4
*    vRel_vs_Olap_OlapKnePts_4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_OlapKnePts_4 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_OlapKnePts_4( uint8 * pvRel_vs_Olap_OlapKnePts_4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pvRel_vs_Olap_OlapKnePts_4 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_OlapKnePts_4_b8;
      * pvRel_vs_Olap_OlapKnePts_4 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VREL_VS_OLAP_OLAPKNEPTS_4_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_32_V
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_32_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_32_V
*    IIPB_Buffer_32_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_32_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_32_V( boolean * pIIPB_Buffer_32_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_32_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_32_V_b1;
      * pIIPB_Buffer_32_V = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_32_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_32
*
* FUNCTION ARGUMENTS:
*    uint8 * pIIPB_Buffer_32 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_32
*    IIPB_Buffer_32 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_32 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_32( uint8 * pIIPB_Buffer_32 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pIIPB_Buffer_32 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_32_b4;
      * pIIPB_Buffer_32 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_32_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_0_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVRelVsOlapReductionVals0V * pvRel_vs_Olap_ReductionVals_0_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_ReductionVals_0_V
*    vRel_vs_Olap_ReductionVals_0_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_ReductionVals_0_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_0_V( IPBINITEVRelVsOlapReductionVals0V * pvRel_vs_Olap_ReductionVals_0_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVRelVsOlapReductionVals0V signal_value;
   
   if( pvRel_vs_Olap_ReductionVals_0_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_ReductionVals_0_V_b1;
      * pvRel_vs_Olap_ReductionVals_0_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_0
*
* FUNCTION ARGUMENTS:
*    uint16 * pvRel_vs_Olap_ReductionVals_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_ReductionVals_0
*    vRel_vs_Olap_ReductionVals_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_ReductionVals_0 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_0( uint16 * pvRel_vs_Olap_ReductionVals_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvRel_vs_Olap_ReductionVals_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_ReductionVals_0_b9;
      * pvRel_vs_Olap_ReductionVals_0 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VREL_VS_OLAP_REDUCTIONVALS_0_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_1_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVRelVsOlapReductionVals1V * pvRel_vs_Olap_ReductionVals_1_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_ReductionVals_1_V
*    vRel_vs_Olap_ReductionVals_1_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_ReductionVals_1_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_1_V( IPBINITEVRelVsOlapReductionVals1V * pvRel_vs_Olap_ReductionVals_1_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVRelVsOlapReductionVals1V signal_value;
   
   if( pvRel_vs_Olap_ReductionVals_1_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_ReductionVals_1_V_b1;
      * pvRel_vs_Olap_ReductionVals_1_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pvRel_vs_Olap_ReductionVals_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_ReductionVals_1
*    vRel_vs_Olap_ReductionVals_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_ReductionVals_1 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_1( uint16 * pvRel_vs_Olap_ReductionVals_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvRel_vs_Olap_ReductionVals_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_ReductionVals_1_b9;
      * pvRel_vs_Olap_ReductionVals_1 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VREL_VS_OLAP_REDUCTIONVALS_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_2_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVRelVsOlapReductionVals2V * pvRel_vs_Olap_ReductionVals_2_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_ReductionVals_2_V
*    vRel_vs_Olap_ReductionVals_2_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_ReductionVals_2_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_2_V( IPBINITEVRelVsOlapReductionVals2V * pvRel_vs_Olap_ReductionVals_2_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVRelVsOlapReductionVals2V signal_value;
   
   if( pvRel_vs_Olap_ReductionVals_2_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_ReductionVals_2_V_b1;
      * pvRel_vs_Olap_ReductionVals_2_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pvRel_vs_Olap_ReductionVals_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_ReductionVals_2
*    vRel_vs_Olap_ReductionVals_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_ReductionVals_2 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_2( uint16 * pvRel_vs_Olap_ReductionVals_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvRel_vs_Olap_ReductionVals_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_ReductionVals_2_b9;
      * pvRel_vs_Olap_ReductionVals_2 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VREL_VS_OLAP_REDUCTIONVALS_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_33_V
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_33_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_33_V
*    IIPB_Buffer_33_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_33_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_33_V( boolean * pIIPB_Buffer_33_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_33_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_33_V_b1;
      * pIIPB_Buffer_33_V = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_33_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_33
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_33 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_33
*    IIPB_Buffer_33 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_33 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_33( boolean * pIIPB_Buffer_33 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_33 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_33_b1;
      * pIIPB_Buffer_33 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_33_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_3_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVRelVsOlapReductionVals3V * pvRel_vs_Olap_ReductionVals_3_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_ReductionVals_3_V
*    vRel_vs_Olap_ReductionVals_3_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_ReductionVals_3_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_3_V( IPBINITEVRelVsOlapReductionVals3V * pvRel_vs_Olap_ReductionVals_3_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVRelVsOlapReductionVals3V signal_value;
   
   if( pvRel_vs_Olap_ReductionVals_3_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_ReductionVals_3_V_b1;
      * pvRel_vs_Olap_ReductionVals_3_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_3
*
* FUNCTION ARGUMENTS:
*    uint16 * pvRel_vs_Olap_ReductionVals_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_ReductionVals_3
*    vRel_vs_Olap_ReductionVals_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_ReductionVals_3 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_3( uint16 * pvRel_vs_Olap_ReductionVals_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvRel_vs_Olap_ReductionVals_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_ReductionVals_3_b9;
      * pvRel_vs_Olap_ReductionVals_3 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VREL_VS_OLAP_REDUCTIONVALS_3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_4_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVRelVsOlapReductionVals4V * pvRel_vs_Olap_ReductionVals_4_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_ReductionVals_4_V
*    vRel_vs_Olap_ReductionVals_4_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_ReductionVals_4_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_4_V( IPBINITEVRelVsOlapReductionVals4V * pvRel_vs_Olap_ReductionVals_4_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVRelVsOlapReductionVals4V signal_value;
   
   if( pvRel_vs_Olap_ReductionVals_4_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_ReductionVals_4_V_b1;
      * pvRel_vs_Olap_ReductionVals_4_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_4
*
* FUNCTION ARGUMENTS:
*    uint16 * pvRel_vs_Olap_ReductionVals_4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_ReductionVals_4
*    vRel_vs_Olap_ReductionVals_4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_ReductionVals_4 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_4( uint16 * pvRel_vs_Olap_ReductionVals_4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvRel_vs_Olap_ReductionVals_4 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_ReductionVals_4_b9;
      * pvRel_vs_Olap_ReductionVals_4 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VREL_VS_OLAP_REDUCTIONVALS_4_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_5_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVRelVsOlapReductionVals5V * pvRel_vs_Olap_ReductionVals_5_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_ReductionVals_5_V
*    vRel_vs_Olap_ReductionVals_5_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_ReductionVals_5_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_5_V( IPBINITEVRelVsOlapReductionVals5V * pvRel_vs_Olap_ReductionVals_5_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVRelVsOlapReductionVals5V signal_value;
   
   if( pvRel_vs_Olap_ReductionVals_5_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_ReductionVals_5_V_b1;
      * pvRel_vs_Olap_ReductionVals_5_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_5
*
* FUNCTION ARGUMENTS:
*    uint16 * pvRel_vs_Olap_ReductionVals_5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_ReductionVals_5
*    vRel_vs_Olap_ReductionVals_5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_ReductionVals_5 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_5( uint16 * pvRel_vs_Olap_ReductionVals_5 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvRel_vs_Olap_ReductionVals_5 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_ReductionVals_5_b9;
      * pvRel_vs_Olap_ReductionVals_5 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VREL_VS_OLAP_REDUCTIONVALS_5_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_34_V
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_34_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_34_V
*    IIPB_Buffer_34_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_34_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_34_V( boolean * pIIPB_Buffer_34_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_34_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_34_V_b1;
      * pIIPB_Buffer_34_V = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_34_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_34
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_34 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_34
*    IIPB_Buffer_34 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_34 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_34( boolean * pIIPB_Buffer_34 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_34 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_34_b1;
      * pIIPB_Buffer_34 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_34_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_6_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVRelVsOlapReductionVals6V * pvRel_vs_Olap_ReductionVals_6_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_ReductionVals_6_V
*    vRel_vs_Olap_ReductionVals_6_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_ReductionVals_6_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_6_V( IPBINITEVRelVsOlapReductionVals6V * pvRel_vs_Olap_ReductionVals_6_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVRelVsOlapReductionVals6V signal_value;
   
   if( pvRel_vs_Olap_ReductionVals_6_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_ReductionVals_6_V_b1;
      * pvRel_vs_Olap_ReductionVals_6_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_6
*
* FUNCTION ARGUMENTS:
*    uint16 * pvRel_vs_Olap_ReductionVals_6 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_ReductionVals_6
*    vRel_vs_Olap_ReductionVals_6 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_ReductionVals_6 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_6( uint16 * pvRel_vs_Olap_ReductionVals_6 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvRel_vs_Olap_ReductionVals_6 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_ReductionVals_6_b9;
      * pvRel_vs_Olap_ReductionVals_6 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VREL_VS_OLAP_REDUCTIONVALS_6_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_7_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVRelVsOlapReductionVals7V * pvRel_vs_Olap_ReductionVals_7_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_ReductionVals_7_V
*    vRel_vs_Olap_ReductionVals_7_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_ReductionVals_7_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_7_V( IPBINITEVRelVsOlapReductionVals7V * pvRel_vs_Olap_ReductionVals_7_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVRelVsOlapReductionVals7V signal_value;
   
   if( pvRel_vs_Olap_ReductionVals_7_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_ReductionVals_7_V_b1;
      * pvRel_vs_Olap_ReductionVals_7_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_7
*
* FUNCTION ARGUMENTS:
*    uint16 * pvRel_vs_Olap_ReductionVals_7 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_ReductionVals_7
*    vRel_vs_Olap_ReductionVals_7 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_ReductionVals_7 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_7( uint16 * pvRel_vs_Olap_ReductionVals_7 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvRel_vs_Olap_ReductionVals_7 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_ReductionVals_7_b9;
      * pvRel_vs_Olap_ReductionVals_7 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VREL_VS_OLAP_REDUCTIONVALS_7_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_8_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVRelVsOlapReductionVals8V * pvRel_vs_Olap_ReductionVals_8_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_ReductionVals_8_V
*    vRel_vs_Olap_ReductionVals_8_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_ReductionVals_8_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_8_V( IPBINITEVRelVsOlapReductionVals8V * pvRel_vs_Olap_ReductionVals_8_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVRelVsOlapReductionVals8V signal_value;
   
   if( pvRel_vs_Olap_ReductionVals_8_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_ReductionVals_8_V_b1;
      * pvRel_vs_Olap_ReductionVals_8_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_8
*
* FUNCTION ARGUMENTS:
*    uint16 * pvRel_vs_Olap_ReductionVals_8 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_ReductionVals_8
*    vRel_vs_Olap_ReductionVals_8 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_ReductionVals_8 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_8( uint16 * pvRel_vs_Olap_ReductionVals_8 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvRel_vs_Olap_ReductionVals_8 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_ReductionVals_8_b9;
      * pvRel_vs_Olap_ReductionVals_8 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VREL_VS_OLAP_REDUCTIONVALS_8_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_35_V
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_35_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_35_V
*    IIPB_Buffer_35_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_35_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_35_V( boolean * pIIPB_Buffer_35_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_35_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_35_V_b1;
      * pIIPB_Buffer_35_V = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_35_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_35
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_35 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_35
*    IIPB_Buffer_35 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_35 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_35( boolean * pIIPB_Buffer_35 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_35 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_35_b1;
      * pIIPB_Buffer_35 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_35_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_9_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVRelVsOlapReductionVals9V * pvRel_vs_Olap_ReductionVals_9_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_ReductionVals_9_V
*    vRel_vs_Olap_ReductionVals_9_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_ReductionVals_9_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_9_V( IPBINITEVRelVsOlapReductionVals9V * pvRel_vs_Olap_ReductionVals_9_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVRelVsOlapReductionVals9V signal_value;
   
   if( pvRel_vs_Olap_ReductionVals_9_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_ReductionVals_9_V_b1;
      * pvRel_vs_Olap_ReductionVals_9_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_9
*
* FUNCTION ARGUMENTS:
*    uint16 * pvRel_vs_Olap_ReductionVals_9 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_ReductionVals_9
*    vRel_vs_Olap_ReductionVals_9 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_ReductionVals_9 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_9( uint16 * pvRel_vs_Olap_ReductionVals_9 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvRel_vs_Olap_ReductionVals_9 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_ReductionVals_9_b9;
      * pvRel_vs_Olap_ReductionVals_9 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VREL_VS_OLAP_REDUCTIONVALS_9_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_10_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVRelVsOlapReductionVals10V * pvRel_vs_Olap_ReductionVals_10_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_ReductionVals_10_V
*    vRel_vs_Olap_ReductionVals_10_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_ReductionVals_10_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_10_V( IPBINITEVRelVsOlapReductionVals10V * pvRel_vs_Olap_ReductionVals_10_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVRelVsOlapReductionVals10V signal_value;
   
   if( pvRel_vs_Olap_ReductionVals_10_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_ReductionVals_10_V_b1;
      * pvRel_vs_Olap_ReductionVals_10_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_10
*
* FUNCTION ARGUMENTS:
*    uint16 * pvRel_vs_Olap_ReductionVals_10 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_ReductionVals_10
*    vRel_vs_Olap_ReductionVals_10 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_ReductionVals_10 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_10( uint16 * pvRel_vs_Olap_ReductionVals_10 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvRel_vs_Olap_ReductionVals_10 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_ReductionVals_10_b9;
      * pvRel_vs_Olap_ReductionVals_10 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VREL_VS_OLAP_REDUCTIONVALS_10_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_11_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVRelVsOlapReductionVals11V * pvRel_vs_Olap_ReductionVals_11_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_ReductionVals_11_V
*    vRel_vs_Olap_ReductionVals_11_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_ReductionVals_11_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_11_V( IPBINITEVRelVsOlapReductionVals11V * pvRel_vs_Olap_ReductionVals_11_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVRelVsOlapReductionVals11V signal_value;
   
   if( pvRel_vs_Olap_ReductionVals_11_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_ReductionVals_11_V_b1;
      * pvRel_vs_Olap_ReductionVals_11_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_11
*
* FUNCTION ARGUMENTS:
*    uint16 * pvRel_vs_Olap_ReductionVals_11 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_ReductionVals_11
*    vRel_vs_Olap_ReductionVals_11 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_ReductionVals_11 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_11( uint16 * pvRel_vs_Olap_ReductionVals_11 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvRel_vs_Olap_ReductionVals_11 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_ReductionVals_11_b9;
      * pvRel_vs_Olap_ReductionVals_11 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VREL_VS_OLAP_REDUCTIONVALS_11_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_36_V
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_36_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_36_V
*    IIPB_Buffer_36_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_36_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_36_V( boolean * pIIPB_Buffer_36_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_36_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_36_V_b1;
      * pIIPB_Buffer_36_V = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_36_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_36
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_36 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_36
*    IIPB_Buffer_36 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_36 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_36( boolean * pIIPB_Buffer_36 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_36 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_36_b1;
      * pIIPB_Buffer_36 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_36_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_12_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVRelVsOlapReductionVals12V * pvRel_vs_Olap_ReductionVals_12_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_ReductionVals_12_V
*    vRel_vs_Olap_ReductionVals_12_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_ReductionVals_12_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_12_V( IPBINITEVRelVsOlapReductionVals12V * pvRel_vs_Olap_ReductionVals_12_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVRelVsOlapReductionVals12V signal_value;
   
   if( pvRel_vs_Olap_ReductionVals_12_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_ReductionVals_12_V_b1;
      * pvRel_vs_Olap_ReductionVals_12_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_12
*
* FUNCTION ARGUMENTS:
*    uint16 * pvRel_vs_Olap_ReductionVals_12 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_ReductionVals_12
*    vRel_vs_Olap_ReductionVals_12 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_ReductionVals_12 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_12( uint16 * pvRel_vs_Olap_ReductionVals_12 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvRel_vs_Olap_ReductionVals_12 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_ReductionVals_12_b9;
      * pvRel_vs_Olap_ReductionVals_12 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VREL_VS_OLAP_REDUCTIONVALS_12_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_13_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVRelVsOlapReductionVals13V * pvRel_vs_Olap_ReductionVals_13_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_ReductionVals_13_V
*    vRel_vs_Olap_ReductionVals_13_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_ReductionVals_13_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_13_V( IPBINITEVRelVsOlapReductionVals13V * pvRel_vs_Olap_ReductionVals_13_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVRelVsOlapReductionVals13V signal_value;
   
   if( pvRel_vs_Olap_ReductionVals_13_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_ReductionVals_13_V_b1;
      * pvRel_vs_Olap_ReductionVals_13_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_13
*
* FUNCTION ARGUMENTS:
*    uint16 * pvRel_vs_Olap_ReductionVals_13 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_ReductionVals_13
*    vRel_vs_Olap_ReductionVals_13 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_ReductionVals_13 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_13( uint16 * pvRel_vs_Olap_ReductionVals_13 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvRel_vs_Olap_ReductionVals_13 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_ReductionVals_13_b9;
      * pvRel_vs_Olap_ReductionVals_13 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VREL_VS_OLAP_REDUCTIONVALS_13_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_14_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVRelVsOlapReductionVals14V * pvRel_vs_Olap_ReductionVals_14_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_ReductionVals_14_V
*    vRel_vs_Olap_ReductionVals_14_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_ReductionVals_14_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_14_V( IPBINITEVRelVsOlapReductionVals14V * pvRel_vs_Olap_ReductionVals_14_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVRelVsOlapReductionVals14V signal_value;
   
   if( pvRel_vs_Olap_ReductionVals_14_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_ReductionVals_14_V_b1;
      * pvRel_vs_Olap_ReductionVals_14_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_14
*
* FUNCTION ARGUMENTS:
*    uint16 * pvRel_vs_Olap_ReductionVals_14 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_ReductionVals_14
*    vRel_vs_Olap_ReductionVals_14 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_ReductionVals_14 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_14( uint16 * pvRel_vs_Olap_ReductionVals_14 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvRel_vs_Olap_ReductionVals_14 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_ReductionVals_14_b9;
      * pvRel_vs_Olap_ReductionVals_14 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VREL_VS_OLAP_REDUCTIONVALS_14_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_37_V
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_37_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_37_V
*    IIPB_Buffer_37_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_37_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_37_V( boolean * pIIPB_Buffer_37_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_37_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_37_V_b1;
      * pIIPB_Buffer_37_V = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_37_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_37
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_37 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_37
*    IIPB_Buffer_37 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_37 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_37( boolean * pIIPB_Buffer_37 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_37 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_37_b1;
      * pIIPB_Buffer_37 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_37_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_15_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVRelVsOlapReductionVals15V * pvRel_vs_Olap_ReductionVals_15_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_ReductionVals_15_V
*    vRel_vs_Olap_ReductionVals_15_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_ReductionVals_15_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_15_V( IPBINITEVRelVsOlapReductionVals15V * pvRel_vs_Olap_ReductionVals_15_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVRelVsOlapReductionVals15V signal_value;
   
   if( pvRel_vs_Olap_ReductionVals_15_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_ReductionVals_15_V_b1;
      * pvRel_vs_Olap_ReductionVals_15_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_15
*
* FUNCTION ARGUMENTS:
*    uint16 * pvRel_vs_Olap_ReductionVals_15 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_ReductionVals_15
*    vRel_vs_Olap_ReductionVals_15 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_ReductionVals_15 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_15( uint16 * pvRel_vs_Olap_ReductionVals_15 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvRel_vs_Olap_ReductionVals_15 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_ReductionVals_15_b9;
      * pvRel_vs_Olap_ReductionVals_15 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VREL_VS_OLAP_REDUCTIONVALS_15_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_16_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVRelVsOlapReductionVals16V * pvRel_vs_Olap_ReductionVals_16_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_ReductionVals_16_V
*    vRel_vs_Olap_ReductionVals_16_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_ReductionVals_16_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_16_V( IPBINITEVRelVsOlapReductionVals16V * pvRel_vs_Olap_ReductionVals_16_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVRelVsOlapReductionVals16V signal_value;
   
   if( pvRel_vs_Olap_ReductionVals_16_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_ReductionVals_16_V_b1;
      * pvRel_vs_Olap_ReductionVals_16_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_16
*
* FUNCTION ARGUMENTS:
*    uint16 * pvRel_vs_Olap_ReductionVals_16 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_ReductionVals_16
*    vRel_vs_Olap_ReductionVals_16 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_ReductionVals_16 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_16( uint16 * pvRel_vs_Olap_ReductionVals_16 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvRel_vs_Olap_ReductionVals_16 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_ReductionVals_16_b9;
      * pvRel_vs_Olap_ReductionVals_16 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VREL_VS_OLAP_REDUCTIONVALS_16_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_17_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVRelVsOlapReductionVals17V * pvRel_vs_Olap_ReductionVals_17_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_ReductionVals_17_V
*    vRel_vs_Olap_ReductionVals_17_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_ReductionVals_17_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_17_V( IPBINITEVRelVsOlapReductionVals17V * pvRel_vs_Olap_ReductionVals_17_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVRelVsOlapReductionVals17V signal_value;
   
   if( pvRel_vs_Olap_ReductionVals_17_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_ReductionVals_17_V_b1;
      * pvRel_vs_Olap_ReductionVals_17_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_17
*
* FUNCTION ARGUMENTS:
*    uint16 * pvRel_vs_Olap_ReductionVals_17 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_ReductionVals_17
*    vRel_vs_Olap_ReductionVals_17 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_ReductionVals_17 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_17( uint16 * pvRel_vs_Olap_ReductionVals_17 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvRel_vs_Olap_ReductionVals_17 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_ReductionVals_17_b9;
      * pvRel_vs_Olap_ReductionVals_17 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VREL_VS_OLAP_REDUCTIONVALS_17_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_38_V
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_38_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_38_V
*    IIPB_Buffer_38_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_38_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_38_V( boolean * pIIPB_Buffer_38_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_38_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_38_V_b1;
      * pIIPB_Buffer_38_V = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_38_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_38
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_38 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_38
*    IIPB_Buffer_38 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_38 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_38( boolean * pIIPB_Buffer_38 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_38 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_38_b1;
      * pIIPB_Buffer_38 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_38_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_18_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVRelVsOlapReductionVals18V * pvRel_vs_Olap_ReductionVals_18_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_ReductionVals_18_V
*    vRel_vs_Olap_ReductionVals_18_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_ReductionVals_18_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_18_V( IPBINITEVRelVsOlapReductionVals18V * pvRel_vs_Olap_ReductionVals_18_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVRelVsOlapReductionVals18V signal_value;
   
   if( pvRel_vs_Olap_ReductionVals_18_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_ReductionVals_18_V_b1;
      * pvRel_vs_Olap_ReductionVals_18_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_18
*
* FUNCTION ARGUMENTS:
*    uint16 * pvRel_vs_Olap_ReductionVals_18 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_ReductionVals_18
*    vRel_vs_Olap_ReductionVals_18 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_ReductionVals_18 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_18( uint16 * pvRel_vs_Olap_ReductionVals_18 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvRel_vs_Olap_ReductionVals_18 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_ReductionVals_18_b9;
      * pvRel_vs_Olap_ReductionVals_18 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VREL_VS_OLAP_REDUCTIONVALS_18_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_19_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVRelVsOlapReductionVals19V * pvRel_vs_Olap_ReductionVals_19_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_ReductionVals_19_V
*    vRel_vs_Olap_ReductionVals_19_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_ReductionVals_19_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_19_V( IPBINITEVRelVsOlapReductionVals19V * pvRel_vs_Olap_ReductionVals_19_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVRelVsOlapReductionVals19V signal_value;
   
   if( pvRel_vs_Olap_ReductionVals_19_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_ReductionVals_19_V_b1;
      * pvRel_vs_Olap_ReductionVals_19_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_19
*
* FUNCTION ARGUMENTS:
*    uint16 * pvRel_vs_Olap_ReductionVals_19 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_ReductionVals_19
*    vRel_vs_Olap_ReductionVals_19 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_ReductionVals_19 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_19( uint16 * pvRel_vs_Olap_ReductionVals_19 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvRel_vs_Olap_ReductionVals_19 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_ReductionVals_19_b9;
      * pvRel_vs_Olap_ReductionVals_19 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VREL_VS_OLAP_REDUCTIONVALS_19_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_20_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVRelVsOlapReductionVals20V * pvRel_vs_Olap_ReductionVals_20_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_ReductionVals_20_V
*    vRel_vs_Olap_ReductionVals_20_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_ReductionVals_20_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_20_V( IPBINITEVRelVsOlapReductionVals20V * pvRel_vs_Olap_ReductionVals_20_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVRelVsOlapReductionVals20V signal_value;
   
   if( pvRel_vs_Olap_ReductionVals_20_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_ReductionVals_20_V_b1;
      * pvRel_vs_Olap_ReductionVals_20_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_20
*
* FUNCTION ARGUMENTS:
*    uint16 * pvRel_vs_Olap_ReductionVals_20 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_ReductionVals_20
*    vRel_vs_Olap_ReductionVals_20 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_ReductionVals_20 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_20( uint16 * pvRel_vs_Olap_ReductionVals_20 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvRel_vs_Olap_ReductionVals_20 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_ReductionVals_20_b9;
      * pvRel_vs_Olap_ReductionVals_20 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VREL_VS_OLAP_REDUCTIONVALS_20_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_39_V
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_39_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_39_V
*    IIPB_Buffer_39_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_39_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_39_V( boolean * pIIPB_Buffer_39_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_39_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_39_V_b1;
      * pIIPB_Buffer_39_V = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_39_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_39
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_39 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_39
*    IIPB_Buffer_39 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_39 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_39( boolean * pIIPB_Buffer_39 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_39 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_39_b1;
      * pIIPB_Buffer_39 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_39_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_21_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVRelVsOlapReductionVals21V * pvRel_vs_Olap_ReductionVals_21_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_ReductionVals_21_V
*    vRel_vs_Olap_ReductionVals_21_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_ReductionVals_21_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_21_V( IPBINITEVRelVsOlapReductionVals21V * pvRel_vs_Olap_ReductionVals_21_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVRelVsOlapReductionVals21V signal_value;
   
   if( pvRel_vs_Olap_ReductionVals_21_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_ReductionVals_21_V_b1;
      * pvRel_vs_Olap_ReductionVals_21_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_21
*
* FUNCTION ARGUMENTS:
*    uint16 * pvRel_vs_Olap_ReductionVals_21 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_ReductionVals_21
*    vRel_vs_Olap_ReductionVals_21 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_ReductionVals_21 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_21( uint16 * pvRel_vs_Olap_ReductionVals_21 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvRel_vs_Olap_ReductionVals_21 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_ReductionVals_21_b9;
      * pvRel_vs_Olap_ReductionVals_21 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VREL_VS_OLAP_REDUCTIONVALS_21_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_22_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVRelVsOlapReductionVals22V * pvRel_vs_Olap_ReductionVals_22_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_ReductionVals_22_V
*    vRel_vs_Olap_ReductionVals_22_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_ReductionVals_22_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_22_V( IPBINITEVRelVsOlapReductionVals22V * pvRel_vs_Olap_ReductionVals_22_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVRelVsOlapReductionVals22V signal_value;
   
   if( pvRel_vs_Olap_ReductionVals_22_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_ReductionVals_22_V_b1;
      * pvRel_vs_Olap_ReductionVals_22_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_22
*
* FUNCTION ARGUMENTS:
*    uint16 * pvRel_vs_Olap_ReductionVals_22 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_ReductionVals_22
*    vRel_vs_Olap_ReductionVals_22 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_ReductionVals_22 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_22( uint16 * pvRel_vs_Olap_ReductionVals_22 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvRel_vs_Olap_ReductionVals_22 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_ReductionVals_22_b9;
      * pvRel_vs_Olap_ReductionVals_22 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VREL_VS_OLAP_REDUCTIONVALS_22_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_23_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVRelVsOlapReductionVals23V * pvRel_vs_Olap_ReductionVals_23_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_ReductionVals_23_V
*    vRel_vs_Olap_ReductionVals_23_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_ReductionVals_23_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_23_V( IPBINITEVRelVsOlapReductionVals23V * pvRel_vs_Olap_ReductionVals_23_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVRelVsOlapReductionVals23V signal_value;
   
   if( pvRel_vs_Olap_ReductionVals_23_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_ReductionVals_23_V_b1;
      * pvRel_vs_Olap_ReductionVals_23_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_23
*
* FUNCTION ARGUMENTS:
*    uint16 * pvRel_vs_Olap_ReductionVals_23 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_ReductionVals_23
*    vRel_vs_Olap_ReductionVals_23 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_ReductionVals_23 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_23( uint16 * pvRel_vs_Olap_ReductionVals_23 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvRel_vs_Olap_ReductionVals_23 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_ReductionVals_23_b9;
      * pvRel_vs_Olap_ReductionVals_23 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VREL_VS_OLAP_REDUCTIONVALS_23_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_40_V
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_40_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_40_V
*    IIPB_Buffer_40_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_40_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_40_V( boolean * pIIPB_Buffer_40_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_40_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_40_V_b1;
      * pIIPB_Buffer_40_V = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_40_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_40
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_40 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_40
*    IIPB_Buffer_40 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_40 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_40( boolean * pIIPB_Buffer_40 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_40 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_40_b1;
      * pIIPB_Buffer_40 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_40_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_24_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVRelVsOlapReductionVals24V * pvRel_vs_Olap_ReductionVals_24_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_ReductionVals_24_V
*    vRel_vs_Olap_ReductionVals_24_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_ReductionVals_24_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_24_V( IPBINITEVRelVsOlapReductionVals24V * pvRel_vs_Olap_ReductionVals_24_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVRelVsOlapReductionVals24V signal_value;
   
   if( pvRel_vs_Olap_ReductionVals_24_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_ReductionVals_24_V_b1;
      * pvRel_vs_Olap_ReductionVals_24_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_24
*
* FUNCTION ARGUMENTS:
*    uint16 * pvRel_vs_Olap_ReductionVals_24 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_ReductionVals_24
*    vRel_vs_Olap_ReductionVals_24 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_ReductionVals_24 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_ReductionVals_24( uint16 * pvRel_vs_Olap_ReductionVals_24 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvRel_vs_Olap_ReductionVals_24 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_ReductionVals_24_b9;
      * pvRel_vs_Olap_ReductionVals_24 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VREL_VS_OLAP_REDUCTIONVALS_24_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_vRelKneePts_0_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVRelVsOlapVRelKneePts0V * pvRel_vs_Olap_vRelKneePts_0_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_vRelKneePts_0_V
*    vRel_vs_Olap_vRelKneePts_0_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_vRelKneePts_0_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_vRelKneePts_0_V( IPBINITEVRelVsOlapVRelKneePts0V * pvRel_vs_Olap_vRelKneePts_0_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVRelVsOlapVRelKneePts0V signal_value;
   
   if( pvRel_vs_Olap_vRelKneePts_0_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_vRelKneePts_0_V_b1;
      * pvRel_vs_Olap_vRelKneePts_0_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_vRelKneePts_0
*
* FUNCTION ARGUMENTS:
*    uint16 * pvRel_vs_Olap_vRelKneePts_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_vRelKneePts_0
*    vRel_vs_Olap_vRelKneePts_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_vRelKneePts_0 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_vRelKneePts_0( uint16 * pvRel_vs_Olap_vRelKneePts_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvRel_vs_Olap_vRelKneePts_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_vRelKneePts_0_b12;
      * pvRel_vs_Olap_vRelKneePts_0 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VREL_VS_OLAP_VRELKNEEPTS_0_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_41_V
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_41_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_41_V
*    IIPB_Buffer_41_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_41_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_41_V( boolean * pIIPB_Buffer_41_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_41_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_41_V_b1;
      * pIIPB_Buffer_41_V = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_41_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_41
*
* FUNCTION ARGUMENTS:
*    uint8 * pIIPB_Buffer_41 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_41
*    IIPB_Buffer_41 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_41 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_41( uint8 * pIIPB_Buffer_41 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pIIPB_Buffer_41 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_41_b8;
      * pIIPB_Buffer_41 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_41_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_vRelKneePts_1_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVRelVsOlapVRelKneePts1V * pvRel_vs_Olap_vRelKneePts_1_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_vRelKneePts_1_V
*    vRel_vs_Olap_vRelKneePts_1_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_vRelKneePts_1_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_vRelKneePts_1_V( IPBINITEVRelVsOlapVRelKneePts1V * pvRel_vs_Olap_vRelKneePts_1_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVRelVsOlapVRelKneePts1V signal_value;
   
   if( pvRel_vs_Olap_vRelKneePts_1_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_vRelKneePts_1_V_b1;
      * pvRel_vs_Olap_vRelKneePts_1_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_vRelKneePts_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pvRel_vs_Olap_vRelKneePts_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_vRelKneePts_1
*    vRel_vs_Olap_vRelKneePts_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_vRelKneePts_1 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_vRelKneePts_1( uint16 * pvRel_vs_Olap_vRelKneePts_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvRel_vs_Olap_vRelKneePts_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_vRelKneePts_1_b12;
      * pvRel_vs_Olap_vRelKneePts_1 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VREL_VS_OLAP_VRELKNEEPTS_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_vRelKneePts_2_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVRelVsOlapVRelKneePts2V * pvRel_vs_Olap_vRelKneePts_2_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_vRelKneePts_2_V
*    vRel_vs_Olap_vRelKneePts_2_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_vRelKneePts_2_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_vRelKneePts_2_V( IPBINITEVRelVsOlapVRelKneePts2V * pvRel_vs_Olap_vRelKneePts_2_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVRelVsOlapVRelKneePts2V signal_value;
   
   if( pvRel_vs_Olap_vRelKneePts_2_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_vRelKneePts_2_V_b1;
      * pvRel_vs_Olap_vRelKneePts_2_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_vRelKneePts_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pvRel_vs_Olap_vRelKneePts_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_vRelKneePts_2
*    vRel_vs_Olap_vRelKneePts_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_vRelKneePts_2 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_vRelKneePts_2( uint16 * pvRel_vs_Olap_vRelKneePts_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvRel_vs_Olap_vRelKneePts_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_vRelKneePts_2_b12;
      * pvRel_vs_Olap_vRelKneePts_2 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VREL_VS_OLAP_VRELKNEEPTS_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_42_V
*
* FUNCTION ARGUMENTS:
*    boolean * pIIPB_Buffer_42_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_42_V
*    IIPB_Buffer_42_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_42_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_42_V( boolean * pIIPB_Buffer_42_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIIPB_Buffer_42_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_42_V_b1;
      * pIIPB_Buffer_42_V = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_42_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_IIPB_Buffer_42
*
* FUNCTION ARGUMENTS:
*    uint8 * pIIPB_Buffer_42 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IIPB_Buffer_42
*    IIPB_Buffer_42 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IIPB_Buffer_42 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_IIPB_Buffer_42( uint8 * pIIPB_Buffer_42 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pIIPB_Buffer_42 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.IIPB_Buffer_42_b5;
      * pIIPB_Buffer_42 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_IIPB_BUFFER_42_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_vRelKneePts_3_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVRelVsOlapVRelKneePts3V * pvRel_vs_Olap_vRelKneePts_3_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_vRelKneePts_3_V
*    vRel_vs_Olap_vRelKneePts_3_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_vRelKneePts_3_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_vRelKneePts_3_V( IPBINITEVRelVsOlapVRelKneePts3V * pvRel_vs_Olap_vRelKneePts_3_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVRelVsOlapVRelKneePts3V signal_value;
   
   if( pvRel_vs_Olap_vRelKneePts_3_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_vRelKneePts_3_V_b1;
      * pvRel_vs_Olap_vRelKneePts_3_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_vRelKneePts_3
*
* FUNCTION ARGUMENTS:
*    uint16 * pvRel_vs_Olap_vRelKneePts_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_vRelKneePts_3
*    vRel_vs_Olap_vRelKneePts_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_vRelKneePts_3 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_vRelKneePts_3( uint16 * pvRel_vs_Olap_vRelKneePts_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvRel_vs_Olap_vRelKneePts_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_vRelKneePts_3_b12;
      * pvRel_vs_Olap_vRelKneePts_3 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VREL_VS_OLAP_VRELKNEEPTS_3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_vRelKneePts_4_V
*
* FUNCTION ARGUMENTS:
*    IPBINITEVRelVsOlapVRelKneePts4V * pvRel_vs_Olap_vRelKneePts_4_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_vRelKneePts_4_V
*    vRel_vs_Olap_vRelKneePts_4_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_vRelKneePts_4_V signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_vRelKneePts_4_V( IPBINITEVRelVsOlapVRelKneePts4V * pvRel_vs_Olap_vRelKneePts_4_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   IPBINITEVRelVsOlapVRelKneePts4V signal_value;
   
   if( pvRel_vs_Olap_vRelKneePts_4_V != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_vRelKneePts_4_V_b1;
      * pvRel_vs_Olap_vRelKneePts_4_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_vRel_vs_Olap_vRelKneePts_4
*
* FUNCTION ARGUMENTS:
*    uint16 * pvRel_vs_Olap_vRelKneePts_4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of vRel_vs_Olap_vRelKneePts_4
*    vRel_vs_Olap_vRelKneePts_4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns vRel_vs_Olap_vRelKneePts_4 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_vRel_vs_Olap_vRelKneePts_4( uint16 * pvRel_vs_Olap_vRelKneePts_4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pvRel_vs_Olap_vRelKneePts_4 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.vRel_vs_Olap_vRelKneePts_4_b12;
      * pvRel_vs_Olap_vRelKneePts_4 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_VREL_VS_OLAP_VRELKNEEPTS_4_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_IPBINITE_Reserved_1
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1
*    Reserved_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1 signal value of IPB_Init_setE message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_IPBINITE_Reserved_1( uint8 * pReserved_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pReserved_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_IPBINITE_ParamsApp_s.Reserved_1_b7;
      * pReserved_1 = signal_value;
      if( signal_value <= C_EYEQMSG_IPBINITE_RESERVED_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

