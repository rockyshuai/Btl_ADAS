

/*****************************************************************************
                  Include files
*****************************************************************************/
/* The suggested include file order is: */
#include "EyeQ_defs.h"    /* EyeQ project common definitions file    */

#include "EYEQMSG_CoreLatDepWarnProcess.h"

/*****************************************************************************
                  Local symbolic constants
*****************************************************************************/
/*****************************************************************************
                  Local types, enums definitions
*****************************************************************************/
/*****************************************************************************
                  Local function prototypes
*****************************************************************************/
/*****************************************************************************
                  Local object definitions
*****************************************************************************/
/*****************************************************************************
                  Exported object definitions
*****************************************************************************/
EYEQMSG_CORELDW_Params_t   EYEQMSG_CORELDW_Params_s;
EYEQMSG_CORELDW_Params_t   EYEQMSG_CORELDW_ParamsApp_s;
/*****************************************************************************
                  Local function-like macros
*****************************************************************************/
/*****************************************************************************
                  Local defined macros
*****************************************************************************/
/*****************************************************************************
                  Function definitions
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELDWvH_LDW_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pLDW_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LDW_Zero_byte
*    LDW_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LDW_Zero_byte signal value of Virtual_HEADER_msg_Core_Lateral_Departure_Warning_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELDWvH_LDW_Zero_byte( uint8 * pLDW_Zero_byte )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pLDW_Zero_byte != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELDW_ParamsApp_s.EYEQMSG_CORELDWvH_Params_s.LDW_Zero_byte_b8;
      * pLDW_Zero_byte = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELDWvH_LDW_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pLDW_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LDW_Protocol_Version
*    LDW_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LDW_Protocol_Version signal value of Virtual_HEADER_msg_Core_Lateral_Departure_Warning_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELDWvH_LDW_Protocol_Version( uint8 * pLDW_Protocol_Version )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pLDW_Protocol_Version != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELDW_ParamsApp_s.EYEQMSG_CORELDWvH_Params_s.LDW_Protocol_Version_b8;
      * pLDW_Protocol_Version = signal_value;
      if( (signal_value >= C_EYEQMSG_CORELDWvH_LDW_PROTOCOL_VERSION_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORELDWvH_LDW_PROTOCOL_VERSION_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELDWvH_LDW_Sync_ID
*
* FUNCTION ARGUMENTS:
*    uint8 * pLDW_Sync_ID - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LDW_Sync_ID
*    LDW_Sync_ID returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LDW_Sync_ID signal value of Virtual_HEADER_msg_Core_Lateral_Departure_Warning_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELDWvH_LDW_Sync_ID( uint8 * pLDW_Sync_ID )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pLDW_Sync_ID != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELDW_ParamsApp_s.EYEQMSG_CORELDWvH_Params_s.LDW_Sync_ID_b8;
      * pLDW_Sync_ID = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELDWvH_LDW_Line_Valid_Left
*
* FUNCTION ARGUMENTS:
*    CORELDWvHLDWLineValidLeft * pLDW_Line_Valid_Left - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LDW_Line_Valid_Left
*    LDW_Line_Valid_Left returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LDW_Line_Valid_Left signal value of Virtual_HEADER_msg_Core_Lateral_Departure_Warning_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELDWvH_LDW_Line_Valid_Left( CORELDWvHLDWLineValidLeft * pLDW_Line_Valid_Left )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELDWvHLDWLineValidLeft signal_value;
   
   if( pLDW_Line_Valid_Left != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELDW_ParamsApp_s.EYEQMSG_CORELDWvH_Params_s.LDW_Line_Valid_Left_b1;
      * pLDW_Line_Valid_Left = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELDWvH_LDW_Line_Valid_Right
*
* FUNCTION ARGUMENTS:
*    CORELDWvHLDWLineValidRight * pLDW_Line_Valid_Right - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LDW_Line_Valid_Right
*    LDW_Line_Valid_Right returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LDW_Line_Valid_Right signal value of Virtual_HEADER_msg_Core_Lateral_Departure_Warning_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELDWvH_LDW_Line_Valid_Right( CORELDWvHLDWLineValidRight * pLDW_Line_Valid_Right )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELDWvHLDWLineValidRight signal_value;
   
   if( pLDW_Line_Valid_Right != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELDW_ParamsApp_s.EYEQMSG_CORELDWvH_Params_s.LDW_Line_Valid_Right_b1;
      * pLDW_Line_Valid_Right = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELDWvH_Reserved_1
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1
*    Reserved_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1 signal value of Virtual_HEADER_msg_Core_Lateral_Departure_Warning_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELDWvH_Reserved_1( uint8 * pReserved_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pReserved_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELDW_ParamsApp_s.EYEQMSG_CORELDWvH_Params_s.Reserved_1_b6;
      * pReserved_1 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELDWvH_RESERVED_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELDWvH_LDW_Time_To_Host_Left
*
* FUNCTION ARGUMENTS:
*    uint8 * pLDW_Time_To_Host_Left - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LDW_Time_To_Host_Left
*    LDW_Time_To_Host_Left returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LDW_Time_To_Host_Left signal value of Virtual_HEADER_msg_Core_Lateral_Departure_Warning_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELDWvH_LDW_Time_To_Host_Left( uint8 * pLDW_Time_To_Host_Left )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pLDW_Time_To_Host_Left != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELDW_ParamsApp_s.EYEQMSG_CORELDWvH_Params_s.LDW_Time_To_Host_Left_b8;
      * pLDW_Time_To_Host_Left = signal_value;
      if( signal_value <= C_EYEQMSG_CORELDWvH_LDW_TIME_TO_HOST_LEFT_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELDWvH_LDW_Time_To_Host_Right
*
* FUNCTION ARGUMENTS:
*    uint8 * pLDW_Time_To_Host_Right - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LDW_Time_To_Host_Right
*    LDW_Time_To_Host_Right returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LDW_Time_To_Host_Right signal value of Virtual_HEADER_msg_Core_Lateral_Departure_Warning_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELDWvH_LDW_Time_To_Host_Right( uint8 * pLDW_Time_To_Host_Right )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pLDW_Time_To_Host_Right != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELDW_ParamsApp_s.EYEQMSG_CORELDWvH_Params_s.LDW_Time_To_Host_Right_b8;
      * pLDW_Time_To_Host_Right = signal_value;
      if( signal_value <= C_EYEQMSG_CORELDWvH_LDW_TIME_TO_HOST_RIGHT_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELDWvH_Reserved_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pReserved_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_2
*    Reserved_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_2 signal value of Virtual_HEADER_msg_Core_Lateral_Departure_Warning_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELDWvH_Reserved_2( uint16 * pReserved_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pReserved_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELDW_ParamsApp_s.EYEQMSG_CORELDWvH_Params_s.Reserved_2_b16;
      * pReserved_2 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELDWvH_RESERVED_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELDWvO_LDW_Suppression_Reason_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLDW_Suppression_Reason_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LDW_Suppression_Reason_0
*    LDW_Suppression_Reason_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LDW_Suppression_Reason_0 signal value of Virtual_OBJECT_msg_Core_Lateral_Departure_Warning_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELDWvO_LDW_Suppression_Reason_0( uint8 objIndx_u8, uint16 * pLDW_Suppression_Reason_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lateral_Departure_Warning_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELDWvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLDW_Suppression_Reason_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELDW_ParamsApp_s.EYEQMSG_CORELDWvO_Params_as[objIndx_u8].LDW_Suppression_Reason_0_b10;
         * pLDW_Suppression_Reason_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELDWvO_LDW_Time_To_Warning_Left_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLDW_Time_To_Warning_Left_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LDW_Time_To_Warning_Left_0
*    LDW_Time_To_Warning_Left_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LDW_Time_To_Warning_Left_0 signal value of Virtual_OBJECT_msg_Core_Lateral_Departure_Warning_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELDWvO_LDW_Time_To_Warning_Left_0( uint8 objIndx_u8, uint8 * pLDW_Time_To_Warning_Left_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lateral_Departure_Warning_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELDWvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLDW_Time_To_Warning_Left_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELDW_ParamsApp_s.EYEQMSG_CORELDWvO_Params_as[objIndx_u8].LDW_Time_To_Warning_Left_0_b8;
         * pLDW_Time_To_Warning_Left_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELDWvO_LDW_TIME_TO_WARNING_LEFT_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELDWvO_LDW_Time_To_Warning_Right_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLDW_Time_To_Warning_Right_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LDW_Time_To_Warning_Right_0
*    LDW_Time_To_Warning_Right_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LDW_Time_To_Warning_Right_0 signal value of Virtual_OBJECT_msg_Core_Lateral_Departure_Warning_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELDWvO_LDW_Time_To_Warning_Right_0( uint8 objIndx_u8, uint8 * pLDW_Time_To_Warning_Right_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lateral_Departure_Warning_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELDWvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLDW_Time_To_Warning_Right_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELDW_ParamsApp_s.EYEQMSG_CORELDWvO_Params_as[objIndx_u8].LDW_Time_To_Warning_Right_0_b8;
         * pLDW_Time_To_Warning_Right_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELDWvO_LDW_TIME_TO_WARNING_RIGHT_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELDWvO_LDW_Warning_Status_Left_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELDWvOLDWWarningStatusLeft0 * pLDW_Warning_Status_Left_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LDW_Warning_Status_Left_0
*    LDW_Warning_Status_Left_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LDW_Warning_Status_Left_0 signal value of Virtual_OBJECT_msg_Core_Lateral_Departure_Warning_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELDWvO_LDW_Warning_Status_Left_0( uint8 objIndx_u8, CORELDWvOLDWWarningStatusLeft0 * pLDW_Warning_Status_Left_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELDWvOLDWWarningStatusLeft0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lateral_Departure_Warning_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELDWvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLDW_Warning_Status_Left_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELDW_ParamsApp_s.EYEQMSG_CORELDWvO_Params_as[objIndx_u8].LDW_Warning_Status_Left_0_b2;
         * pLDW_Warning_Status_Left_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELDWvO_LDW_Warning_Status_Right_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELDWvOLDWWarningStatusRight0 * pLDW_Warning_Status_Right_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LDW_Warning_Status_Right_0
*    LDW_Warning_Status_Right_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LDW_Warning_Status_Right_0 signal value of Virtual_OBJECT_msg_Core_Lateral_Departure_Warning_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELDWvO_LDW_Warning_Status_Right_0( uint8 objIndx_u8, CORELDWvOLDWWarningStatusRight0 * pLDW_Warning_Status_Right_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELDWvOLDWWarningStatusRight0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lateral_Departure_Warning_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELDWvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLDW_Warning_Status_Right_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELDW_ParamsApp_s.EYEQMSG_CORELDWvO_Params_as[objIndx_u8].LDW_Warning_Status_Right_0_b2;
         * pLDW_Warning_Status_Right_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELDWvO_Reserved_3_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_3_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_3_0
*    Reserved_3_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_3_0 signal value of Virtual_OBJECT_msg_Core_Lateral_Departure_Warning_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELDWvO_Reserved_3_0( uint8 objIndx_u8, uint8 * pReserved_3_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lateral_Departure_Warning_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELDWvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_3_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELDW_ParamsApp_s.EYEQMSG_CORELDWvO_Params_as[objIndx_u8].Reserved_3_0_b2;
         * pReserved_3_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELDWvO_RESERVED_3_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_CORELDW_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_CORELDW_Params_t * pCore_Lateral_Departure_Warning_protocol - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_Lateral_Departure_Warning_protocol message 
*    Core_Lateral_Departure_Warning_protocol message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_Lateral_Departure_Warning_protocol message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_CORELDW_ParamsApp_MsgDataStruct( EYEQMSG_CORELDW_Params_t * pCore_Lateral_Departure_Warning_protocol )
{
   Std_ReturnType status = C_SIG_INVALID;
   if( pCore_Lateral_Departure_Warning_protocol != C_NULL_P )
   {
      status = C_SIG_VALID;
      * pCore_Lateral_Departure_Warning_protocol = EYEQMSG_CORELDW_ParamsApp_s;
   }
   return ( status );
}

