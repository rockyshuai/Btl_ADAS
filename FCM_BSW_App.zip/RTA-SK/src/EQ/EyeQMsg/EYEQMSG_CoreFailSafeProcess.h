#ifndef _EYEQMSG_COREFAILSAFEPROCESS_H_
#define _EYEQMSG_COREFAILSAFEPROCESS_H_

/*****************************************************************************
                  Included header files
*****************************************************************************/
#include <Std_Types.h>

/*****************************************************************************
                  Include files
*****************************************************************************/
/*****************************************************************************
                  Exported symbolic constants
*****************************************************************************/
#define C_EYEQMSG_COREFAILSAFEvH_VIRTUAL_OBJECT_INDEX_RMAX ( 15U )

/* Datagram message ID */
#define C_EYEQMSG_COREFAILSAFEvH_MSG_ID                       ( 0x71U )
#define C_EYEQMSG_COREFAILSAFEvO_MSG_ID                       ( 0x71U )
#define C_EYEQMSG_COREFAILSAFE_MSG_ID                         ( 0x71U )

/* Datagram message lengths */
#define C_EYEQMSG_COREFAILSAFEvH_MSG_LEN                      ( sizeof(EYEQMSG_COREFAILSAFEvH_Params_t) )
#define C_EYEQMSG_COREFAILSAFEvO_MSG_LEN                      ( sizeof(EYEQMSG_COREFAILSAFEvO_Params_t) )
#define C_EYEQMSG_COREFAILSAFE_MSG_LEN                        ( sizeof(EYEQMSG_COREFAILSAFE_Params_t) )

/* Protocol ENUMs */

/* MCU output messages */

/* Virtual_HEADER_msg_Core_Failsafe_protocol Enums */
/* Reserved_3_b20 signal Min & Max range limits */
#define C_EYEQMSG_COREFAILSAFEvH_RESERVED_3_RMIN              ( 0U )
#define C_EYEQMSG_COREFAILSAFEvH_RESERVED_3_RMAX              ( 0U )
#define C_EYEQMSG_COREFAILSAFEvH_RESERVED_3_NUMR              ( 1U )
#define C_EYEQMSG_COREFAILSAFEvH_RESERVED_3_DEMNR             ( 1U )
#define C_EYEQMSG_COREFAILSAFEvH_RESERVED_3_OFFSET            ( 0U )

/* FS_C2W_OOR_b3 signal Enums */
typedef uint8 COREFAILSAFEvHFSC2WOOR;
#define C_EYEQMSG_COREFAILSAFEvH_FS_C2W_OOR_NOT_READY         ( COREFAILSAFEvHFSC2WOOR ) ( 0U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_C2W_OOR_CALIBRATED_STATE  ( COREFAILSAFEvHFSC2WOOR ) ( 1U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_C2W_OOR_UNVALIDATED_STATE ( COREFAILSAFEvHFSC2WOOR ) ( 2U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_C2W_OOR_RESERVED          ( COREFAILSAFEvHFSC2WOOR ) ( 3U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_C2W_OOR_SUSPECTED_STATE   ( COREFAILSAFEvHFSC2WOOR ) ( 4U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_C2W_OOR_OOR_STATE         ( COREFAILSAFEvHFSC2WOOR ) ( 5U )

/* FS_C2W_OOR_b3 signal Min & Max range limits */
#define C_EYEQMSG_COREFAILSAFEvH_FS_C2W_OOR_RMIN              ( 0U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_C2W_OOR_RMAX              ( 5U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_C2W_OOR_NUMR              ( 1U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_C2W_OOR_DEMNR             ( 1U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_C2W_OOR_OFFSET            ( 0U )

/* FS_Calibration_Misalignment_b3 signal Enums */
typedef uint8 COREFAILSAFEvHFSCalibrationMisalignment;
#define C_EYEQMSG_COREFAILSAFEvH_FS_CALIBRATION_MISALIGNMENT_NOT_READY ( COREFAILSAFEvHFSCalibrationMisalignment ) ( 0U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_CALIBRATION_MISALIGNMENT_NONE ( COREFAILSAFEvHFSCalibrationMisalignment ) ( 1U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_CALIBRATION_MISALIGNMENT_25 ( COREFAILSAFEvHFSCalibrationMisalignment ) ( 2U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_CALIBRATION_MISALIGNMENT_50 ( COREFAILSAFEvHFSCalibrationMisalignment ) ( 3U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_CALIBRATION_MISALIGNMENT_75 ( COREFAILSAFEvHFSCalibrationMisalignment ) ( 4U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_CALIBRATION_MISALIGNMENT_99 ( COREFAILSAFEvHFSCalibrationMisalignment ) ( 5U )

/* FS_Calibration_Misalignment_b3 signal Min & Max range limits */
#define C_EYEQMSG_COREFAILSAFEvH_FS_CALIBRATION_MISALIGNMENT_RMIN ( 0U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_CALIBRATION_MISALIGNMENT_RMAX ( 5U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_CALIBRATION_MISALIGNMENT_NUMR ( 1U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_CALIBRATION_MISALIGNMENT_DEMNR ( 1U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_CALIBRATION_MISALIGNMENT_OFFSET ( 0U )

/* FS_Fog_b3 signal Enums */
typedef uint8 COREFAILSAFEvHFSFog;
#define C_EYEQMSG_COREFAILSAFEvH_FS_FOG_NOT_READY             ( COREFAILSAFEvHFSFog ) ( 0U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_FOG_NONE                  ( COREFAILSAFEvHFSFog ) ( 1U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_FOG_25                    ( COREFAILSAFEvHFSFog ) ( 2U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_FOG_50                    ( COREFAILSAFEvHFSFog ) ( 3U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_FOG_75                    ( COREFAILSAFEvHFSFog ) ( 4U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_FOG_99                    ( COREFAILSAFEvHFSFog ) ( 5U )

/* FS_Fog_b3 signal Min & Max range limits */
#define C_EYEQMSG_COREFAILSAFEvH_FS_FOG_RMIN                  ( 0U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_FOG_RMAX                  ( 5U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_FOG_NUMR                  ( 1U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_FOG_DEMNR                 ( 1U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_FOG_OFFSET                ( 0U )

/* FS_Rain_b3 signal Enums */
typedef uint8 COREFAILSAFEvHFSRain;
#define C_EYEQMSG_COREFAILSAFEvH_FS_RAIN_NOT_READY            ( COREFAILSAFEvHFSRain ) ( 0U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_RAIN_NONE                 ( COREFAILSAFEvHFSRain ) ( 1U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_RAIN_25                   ( COREFAILSAFEvHFSRain ) ( 2U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_RAIN_50                   ( COREFAILSAFEvHFSRain ) ( 3U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_RAIN_75                   ( COREFAILSAFEvHFSRain ) ( 4U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_RAIN_99                   ( COREFAILSAFEvHFSRain ) ( 5U )

/* FS_Rain_b3 signal Min & Max range limits */
#define C_EYEQMSG_COREFAILSAFEvH_FS_RAIN_RMIN                 ( 0U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_RAIN_RMAX                 ( 5U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_RAIN_NUMR                 ( 1U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_RAIN_DEMNR                ( 1U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_RAIN_OFFSET               ( 0U )

/* FS_Impacted_Technologies_Surround_b16 signal Enums */
typedef uint16 COREFAILSAFEvHFSImpactedTechnologiesSurround;
#define C_EYEQMSG_COREFAILSAFEvH_FS_IMPACTED_TECHNOLOGIES_SURROUND_RESERVED_1 ( COREFAILSAFEvHFSImpactedTechnologiesSurround ) ( 0U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_IMPACTED_TECHNOLOGIES_SURROUND_RESERVED_2 ( COREFAILSAFEvHFSImpactedTechnologiesSurround ) ( 1U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_IMPACTED_TECHNOLOGIES_SURROUND_RESERVED_3 ( COREFAILSAFEvHFSImpactedTechnologiesSurround ) ( 2U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_IMPACTED_TECHNOLOGIES_SURROUND_RESERVED_4 ( COREFAILSAFEvHFSImpactedTechnologiesSurround ) ( 3U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_IMPACTED_TECHNOLOGIES_SURROUND_RESERVED_5 ( COREFAILSAFEvHFSImpactedTechnologiesSurround ) ( 4U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_IMPACTED_TECHNOLOGIES_SURROUND_RESERVED_6 ( COREFAILSAFEvHFSImpactedTechnologiesSurround ) ( 5U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_IMPACTED_TECHNOLOGIES_SURROUND_RESERVED_7 ( COREFAILSAFEvHFSImpactedTechnologiesSurround ) ( 6U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_IMPACTED_TECHNOLOGIES_SURROUND_RESERVED_8 ( COREFAILSAFEvHFSImpactedTechnologiesSurround ) ( 7U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_IMPACTED_TECHNOLOGIES_SURROUND_RESERVED_9 ( COREFAILSAFEvHFSImpactedTechnologiesSurround ) ( 8U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_IMPACTED_TECHNOLOGIES_SURROUND_RESERVED_10 ( COREFAILSAFEvHFSImpactedTechnologiesSurround ) ( 9U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_IMPACTED_TECHNOLOGIES_SURROUND_RESERVED_11 ( COREFAILSAFEvHFSImpactedTechnologiesSurround ) ( 10U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_IMPACTED_TECHNOLOGIES_SURROUND_RESERVED_12 ( COREFAILSAFEvHFSImpactedTechnologiesSurround ) ( 11U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_IMPACTED_TECHNOLOGIES_SURROUND_RESERVED_13 ( COREFAILSAFEvHFSImpactedTechnologiesSurround ) ( 12U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_IMPACTED_TECHNOLOGIES_SURROUND_RESERVED_14 ( COREFAILSAFEvHFSImpactedTechnologiesSurround ) ( 13U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_IMPACTED_TECHNOLOGIES_SURROUND_RESERVED_15 ( COREFAILSAFEvHFSImpactedTechnologiesSurround ) ( 14U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_IMPACTED_TECHNOLOGIES_SURROUND_RESERVED_16 ( COREFAILSAFEvHFSImpactedTechnologiesSurround ) ( 15U )

/* FS_Impacted_Technologies_Surround_b16 signal Min & Max range limits */
#define C_EYEQMSG_COREFAILSAFEvH_FS_IMPACTED_TECHNOLOGIES_SURROUND_RMIN ( 0U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_IMPACTED_TECHNOLOGIES_SURROUND_RMAX ( 65535U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_IMPACTED_TECHNOLOGIES_SURROUND_NUMR ( 1U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_IMPACTED_TECHNOLOGIES_SURROUND_DEMNR ( 1U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_IMPACTED_TECHNOLOGIES_SURROUND_OFFSET ( 0U )

/* FS_Impacted_Technologies_b16 signal Enums */
typedef uint16 COREFAILSAFEvHFSImpactedTechnologies;
#define C_EYEQMSG_COREFAILSAFEvH_FS_IMPACTED_TECHNOLOGIES__BIT_0_VBACC ( COREFAILSAFEvHFSImpactedTechnologies ) ( 0U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_IMPACTED_TECHNOLOGIES__BIT_1_TSR ( COREFAILSAFEvHFSImpactedTechnologies ) ( 1U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_IMPACTED_TECHNOLOGIES__BIT_2_HLB ( COREFAILSAFEvHFSImpactedTechnologies ) ( 2U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_IMPACTED_TECHNOLOGIES__BIT_3_PEDNONEAEB ( COREFAILSAFEvHFSImpactedTechnologies ) ( 3U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_IMPACTED_TECHNOLOGIES__BIT_4_LDNONELC ( COREFAILSAFEvHFSImpactedTechnologies ) ( 4U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_IMPACTED_TECHNOLOGIES__BIT_5_VDNONEAEB ( COREFAILSAFEvHFSImpactedTechnologies ) ( 5U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_IMPACTED_TECHNOLOGIES__BIT_6_RPE ( COREFAILSAFEvHFSImpactedTechnologies ) ( 6U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_IMPACTED_TECHNOLOGIES__BIT_7_FREE_SPACE ( COREFAILSAFEvHFSImpactedTechnologies ) ( 7U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_IMPACTED_TECHNOLOGIES__BIT_8_HEATER ( COREFAILSAFEvHFSImpactedTechnologies ) ( 8U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_IMPACTED_TECHNOLOGIES__BIT_9_PED_FCW ( COREFAILSAFEvHFSImpactedTechnologies ) ( 9U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_IMPACTED_TECHNOLOGIES__BIT_10_VDNONEFCW ( COREFAILSAFEvHFSImpactedTechnologies ) ( 10U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_IMPACTED_TECHNOLOGIES_RESERVED_3 ( COREFAILSAFEvHFSImpactedTechnologies ) ( 11U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_IMPACTED_TECHNOLOGIES_RESERVED_4 ( COREFAILSAFEvHFSImpactedTechnologies ) ( 12U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_IMPACTED_TECHNOLOGIES_RESERVED_5 ( COREFAILSAFEvHFSImpactedTechnologies ) ( 13U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_IMPACTED_TECHNOLOGIES_RESERVED_6 ( COREFAILSAFEvHFSImpactedTechnologies ) ( 14U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_IMPACTED_TECHNOLOGIES_RESERVED_7 ( COREFAILSAFEvHFSImpactedTechnologies ) ( 15U )

/* FS_Impacted_Technologies_b16 signal Min & Max range limits */
#define C_EYEQMSG_COREFAILSAFEvH_FS_IMPACTED_TECHNOLOGIES_RMIN ( 0U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_IMPACTED_TECHNOLOGIES_RMAX ( 65535U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_IMPACTED_TECHNOLOGIES_NUMR ( 1U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_IMPACTED_TECHNOLOGIES_DEMNR ( 1U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_IMPACTED_TECHNOLOGIES_OFFSET ( 0U )

/* Reserved_2_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREFAILSAFEvH_RESERVED_2_RMIN              ( 0U )
#define C_EYEQMSG_COREFAILSAFEvH_RESERVED_2_RMAX              ( 0U )
#define C_EYEQMSG_COREFAILSAFEvH_RESERVED_2_NUMR              ( 1U )
#define C_EYEQMSG_COREFAILSAFEvH_RESERVED_2_DEMNR             ( 1U )
#define C_EYEQMSG_COREFAILSAFEvH_RESERVED_2_OFFSET            ( 0U )

/* FS_Out_Of_Calib_b3 signal Enums */
typedef uint8 COREFAILSAFEvHFSOutOfCalib;
#define C_EYEQMSG_COREFAILSAFEvH_FS_OUT_OF_CALIB_NOT_READY    ( COREFAILSAFEvHFSOutOfCalib ) ( 0U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_OUT_OF_CALIB_NONE         ( COREFAILSAFEvHFSOutOfCalib ) ( 1U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_OUT_OF_CALIB_25           ( COREFAILSAFEvHFSOutOfCalib ) ( 2U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_OUT_OF_CALIB_50           ( COREFAILSAFEvHFSOutOfCalib ) ( 3U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_OUT_OF_CALIB_75           ( COREFAILSAFEvHFSOutOfCalib ) ( 4U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_OUT_OF_CALIB_99           ( COREFAILSAFEvHFSOutOfCalib ) ( 5U )

/* FS_Out_Of_Calib_b3 signal Min & Max range limits */
#define C_EYEQMSG_COREFAILSAFEvH_FS_OUT_OF_CALIB_RMIN         ( 0U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_OUT_OF_CALIB_RMAX         ( 5U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_OUT_OF_CALIB_NUMR         ( 1U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_OUT_OF_CALIB_DEMNR        ( 1U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_OUT_OF_CALIB_OFFSET       ( 0U )

/* FS_TSR_Out_OF_Calib_b8 signal Enums */
typedef uint8 COREFAILSAFEvHFSTSROutOFCalib;
#define C_EYEQMSG_COREFAILSAFEvH_FS_TSR_OUT_OF_CALIB_TSR_OUT_OF_CALIB ( COREFAILSAFEvHFSTSROutOFCalib ) ( 1U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_TSR_OUT_OF_CALIB_TSR_OUT_OF_CALIB_AEB ( COREFAILSAFEvHFSTSROutOFCalib ) ( 2U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_TSR_OUT_OF_CALIB_TSR_OUT_OF_CALIB_YAW ( COREFAILSAFEvHFSTSROutOFCalib ) ( 3U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_TSR_OUT_OF_CALIB_TSR_OUT_OF_CALIB_HORIZON ( COREFAILSAFEvHFSTSROutOFCalib ) ( 4U )

/* FS_TSR_Out_OF_Calib_b8 signal Min & Max range limits */
#define C_EYEQMSG_COREFAILSAFEvH_FS_TSR_OUT_OF_CALIB_RMIN     ( 0U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_TSR_OUT_OF_CALIB_RMAX     ( 15U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_TSR_OUT_OF_CALIB_NUMR     ( 1U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_TSR_OUT_OF_CALIB_DEMNR    ( 1U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_TSR_OUT_OF_CALIB_OFFSET   ( 0U )

/* FS_Cameras_Number_b4 signal Min & Max range limits */
#define C_EYEQMSG_COREFAILSAFEvH_FS_CAMERAS_NUMBER_RMIN       ( 0U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_CAMERAS_NUMBER_RMAX       ( 15U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_CAMERAS_NUMBER_NUMR       ( 1U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_CAMERAS_NUMBER_DEMNR      ( 1U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_CAMERAS_NUMBER_OFFSET     ( 0U )

/* FS_Sync_ID_b8 signal Min & Max range limits */
#define C_EYEQMSG_COREFAILSAFEvH_FS_SYNC_ID_RMIN              ( 0U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_SYNC_ID_RMAX              ( 255U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_SYNC_ID_NUMR              ( 1U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_SYNC_ID_DEMNR             ( 1U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_SYNC_ID_OFFSET            ( 0U )

/* FS_Protocol_Version_b8 signal Min & Max range limits */
#define C_EYEQMSG_COREFAILSAFEvH_FS_PROTOCOL_VERSION_RMIN     ( 6U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_PROTOCOL_VERSION_RMAX     ( 6U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_PROTOCOL_VERSION_NUMR     ( 1U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_PROTOCOL_VERSION_DEMNR    ( 1U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_PROTOCOL_VERSION_OFFSET   ( 0U )

/* FS_Header_CRC_b32 signal Min & Max range limits */
#define C_EYEQMSG_COREFAILSAFEvH_FS_HEADER_CRC_RMIN           ( 0U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_HEADER_CRC_RMAX           ( 4294967295U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_HEADER_CRC_NUMR           ( 1U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_HEADER_CRC_DEMNR          ( 1U )
#define C_EYEQMSG_COREFAILSAFEvH_FS_HEADER_CRC_OFFSET         ( 0U )

/* Reserved_1_b24 signal Min & Max range limits */
#define C_EYEQMSG_COREFAILSAFEvH_RESERVED_1_RMIN              ( 0U )
#define C_EYEQMSG_COREFAILSAFEvH_RESERVED_1_RMAX              ( 0U )
#define C_EYEQMSG_COREFAILSAFEvH_RESERVED_1_NUMR              ( 1U )
#define C_EYEQMSG_COREFAILSAFEvH_RESERVED_1_DEMNR             ( 1U )
#define C_EYEQMSG_COREFAILSAFEvH_RESERVED_1_OFFSET            ( 0U )

/* FSP_Zero_byte_b8 signal Min & Max range limits */
#define C_EYEQMSG_COREFAILSAFEvH_FSP_ZERO_BYTE_RMIN           ( 0U )
#define C_EYEQMSG_COREFAILSAFEvH_FSP_ZERO_BYTE_RMAX           ( 255U )
#define C_EYEQMSG_COREFAILSAFEvH_FSP_ZERO_BYTE_NUMR           ( 1U )
#define C_EYEQMSG_COREFAILSAFEvH_FSP_ZERO_BYTE_DEMNR          ( 1U )
#define C_EYEQMSG_COREFAILSAFEvH_FSP_ZERO_BYTE_OFFSET         ( 0U )


/* Virtual_OBJECT_msg_Core_Failsafe_protocol Enums */
/* FS_C2C_Out_Of_Calib_0_b3 signal Enums */
typedef uint8 COREFAILSAFEvOFSC2COutOfCalib0;
#define C_EYEQMSG_COREFAILSAFEvO_FS_C2C_OUT_OF_CALIB_0_NOT_READY ( COREFAILSAFEvOFSC2COutOfCalib0 ) ( 0U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_C2C_OUT_OF_CALIB_0_NONE   ( COREFAILSAFEvOFSC2COutOfCalib0 ) ( 1U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_C2C_OUT_OF_CALIB_0_25     ( COREFAILSAFEvOFSC2COutOfCalib0 ) ( 2U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_C2C_OUT_OF_CALIB_0_50     ( COREFAILSAFEvOFSC2COutOfCalib0 ) ( 3U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_C2C_OUT_OF_CALIB_0_75     ( COREFAILSAFEvOFSC2COutOfCalib0 ) ( 4U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_C2C_OUT_OF_CALIB_0_99     ( COREFAILSAFEvOFSC2COutOfCalib0 ) ( 5U )

/* FS_C2C_Out_Of_Calib_0_b3 signal Min & Max range limits */
#define C_EYEQMSG_COREFAILSAFEvO_FS_C2C_OUT_OF_CALIB_0_RMIN   ( 0U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_C2C_OUT_OF_CALIB_0_RMAX   ( 5U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_C2C_OUT_OF_CALIB_0_NUMR   ( 1U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_C2C_OUT_OF_CALIB_0_DEMNR  ( 1U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_C2C_OUT_OF_CALIB_0_OFFSET ( 0U )

/* FS_Out_Of_Focus_0_b3 signal Enums */
typedef uint8 COREFAILSAFEvOFSOutOfFocus0;
#define C_EYEQMSG_COREFAILSAFEvO_FS_OUT_OF_FOCUS_0_NOT_READY  ( COREFAILSAFEvOFSOutOfFocus0 ) ( 0U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_OUT_OF_FOCUS_0_NONE       ( COREFAILSAFEvOFSOutOfFocus0 ) ( 1U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_OUT_OF_FOCUS_0_25         ( COREFAILSAFEvOFSOutOfFocus0 ) ( 2U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_OUT_OF_FOCUS_0_50         ( COREFAILSAFEvOFSOutOfFocus0 ) ( 3U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_OUT_OF_FOCUS_0_75         ( COREFAILSAFEvOFSOutOfFocus0 ) ( 4U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_OUT_OF_FOCUS_0_99         ( COREFAILSAFEvOFSOutOfFocus0 ) ( 5U )

/* FS_Out_Of_Focus_0_b3 signal Min & Max range limits */
#define C_EYEQMSG_COREFAILSAFEvO_FS_OUT_OF_FOCUS_0_RMIN       ( 0U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_OUT_OF_FOCUS_0_RMAX       ( 5U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_OUT_OF_FOCUS_0_NUMR       ( 1U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_OUT_OF_FOCUS_0_DEMNR      ( 1U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_OUT_OF_FOCUS_0_OFFSET     ( 0U )

/* FS_Frozen_Windshield_Lens_0_b3 signal Enums */
typedef uint8 COREFAILSAFEvOFSFrozenWindshieldLens0;
#define C_EYEQMSG_COREFAILSAFEvO_FS_FROZEN_WINDSHIELD_LENS_0_NOT_READY ( COREFAILSAFEvOFSFrozenWindshieldLens0 ) ( 0U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_FROZEN_WINDSHIELD_LENS_0_NONE ( COREFAILSAFEvOFSFrozenWindshieldLens0 ) ( 1U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_FROZEN_WINDSHIELD_LENS_0_25 ( COREFAILSAFEvOFSFrozenWindshieldLens0 ) ( 2U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_FROZEN_WINDSHIELD_LENS_0_50 ( COREFAILSAFEvOFSFrozenWindshieldLens0 ) ( 3U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_FROZEN_WINDSHIELD_LENS_0_75 ( COREFAILSAFEvOFSFrozenWindshieldLens0 ) ( 4U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_FROZEN_WINDSHIELD_LENS_0_99 ( COREFAILSAFEvOFSFrozenWindshieldLens0 ) ( 5U )

/* FS_Frozen_Windshield_Lens_0_b3 signal Min & Max range limits */
#define C_EYEQMSG_COREFAILSAFEvO_FS_FROZEN_WINDSHIELD_LENS_0_RMIN ( 0U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_FROZEN_WINDSHIELD_LENS_0_RMAX ( 5U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_FROZEN_WINDSHIELD_LENS_0_NUMR ( 1U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_FROZEN_WINDSHIELD_LENS_0_DEMNR ( 1U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_FROZEN_WINDSHIELD_LENS_0_OFFSET ( 0U )

/* FS_Full_Blockage_0_b3 signal Enums */
typedef uint8 COREFAILSAFEvOFSFullBlockage0;
#define C_EYEQMSG_COREFAILSAFEvO_FS_FULL_BLOCKAGE_0_NOT_READY ( COREFAILSAFEvOFSFullBlockage0 ) ( 0U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_FULL_BLOCKAGE_0_NONE      ( COREFAILSAFEvOFSFullBlockage0 ) ( 1U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_FULL_BLOCKAGE_0_25        ( COREFAILSAFEvOFSFullBlockage0 ) ( 2U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_FULL_BLOCKAGE_0_50        ( COREFAILSAFEvOFSFullBlockage0 ) ( 3U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_FULL_BLOCKAGE_0_75        ( COREFAILSAFEvOFSFullBlockage0 ) ( 4U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_FULL_BLOCKAGE_0_99        ( COREFAILSAFEvOFSFullBlockage0 ) ( 5U )

/* FS_Full_Blockage_0_b3 signal Min & Max range limits */
#define C_EYEQMSG_COREFAILSAFEvO_FS_FULL_BLOCKAGE_0_RMIN      ( 0U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_FULL_BLOCKAGE_0_RMAX      ( 5U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_FULL_BLOCKAGE_0_NUMR      ( 1U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_FULL_BLOCKAGE_0_DEMNR     ( 1U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_FULL_BLOCKAGE_0_OFFSET    ( 0U )

/* FS_Partial_Blockage_0_b3 signal Enums */
typedef uint8 COREFAILSAFEvOFSPartialBlockage0;
#define C_EYEQMSG_COREFAILSAFEvO_FS_PARTIAL_BLOCKAGE_0_NOT_READY ( COREFAILSAFEvOFSPartialBlockage0 ) ( 0U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_PARTIAL_BLOCKAGE_0_NONE   ( COREFAILSAFEvOFSPartialBlockage0 ) ( 1U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_PARTIAL_BLOCKAGE_0_25     ( COREFAILSAFEvOFSPartialBlockage0 ) ( 2U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_PARTIAL_BLOCKAGE_0_50     ( COREFAILSAFEvOFSPartialBlockage0 ) ( 3U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_PARTIAL_BLOCKAGE_0_75     ( COREFAILSAFEvOFSPartialBlockage0 ) ( 4U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_PARTIAL_BLOCKAGE_0_99     ( COREFAILSAFEvOFSPartialBlockage0 ) ( 5U )

/* FS_Partial_Blockage_0_b3 signal Min & Max range limits */
#define C_EYEQMSG_COREFAILSAFEvO_FS_PARTIAL_BLOCKAGE_0_RMIN   ( 0U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_PARTIAL_BLOCKAGE_0_RMAX   ( 5U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_PARTIAL_BLOCKAGE_0_NUMR   ( 1U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_PARTIAL_BLOCKAGE_0_DEMNR  ( 1U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_PARTIAL_BLOCKAGE_0_OFFSET ( 0U )

/* FS_Blur_Image_0_b3 signal Enums */
typedef uint8 COREFAILSAFEvOFSBlurImage0;
#define C_EYEQMSG_COREFAILSAFEvO_FS_BLUR_IMAGE_0_NOT_READY    ( COREFAILSAFEvOFSBlurImage0 ) ( 0U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_BLUR_IMAGE_0_NONE         ( COREFAILSAFEvOFSBlurImage0 ) ( 1U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_BLUR_IMAGE_0_25           ( COREFAILSAFEvOFSBlurImage0 ) ( 2U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_BLUR_IMAGE_0_50           ( COREFAILSAFEvOFSBlurImage0 ) ( 3U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_BLUR_IMAGE_0_75           ( COREFAILSAFEvOFSBlurImage0 ) ( 4U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_BLUR_IMAGE_0_99           ( COREFAILSAFEvOFSBlurImage0 ) ( 5U )

/* FS_Blur_Image_0_b3 signal Min & Max range limits */
#define C_EYEQMSG_COREFAILSAFEvO_FS_BLUR_IMAGE_0_RMIN         ( 0U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_BLUR_IMAGE_0_RMAX         ( 5U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_BLUR_IMAGE_0_NUMR         ( 1U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_BLUR_IMAGE_0_DEMNR        ( 1U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_BLUR_IMAGE_0_OFFSET       ( 0U )

/* FS_Low_Sun_0_b3 signal Enums */
typedef uint8 COREFAILSAFEvOFSLowSun0;
#define C_EYEQMSG_COREFAILSAFEvO_FS_LOW_SUN_0_NOT_READY       ( COREFAILSAFEvOFSLowSun0 ) ( 0U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_LOW_SUN_0_NONE            ( COREFAILSAFEvOFSLowSun0 ) ( 1U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_LOW_SUN_0_25              ( COREFAILSAFEvOFSLowSun0 ) ( 2U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_LOW_SUN_0_50              ( COREFAILSAFEvOFSLowSun0 ) ( 3U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_LOW_SUN_0_75              ( COREFAILSAFEvOFSLowSun0 ) ( 4U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_LOW_SUN_0_99              ( COREFAILSAFEvOFSLowSun0 ) ( 5U )

/* FS_Low_Sun_0_b3 signal Min & Max range limits */
#define C_EYEQMSG_COREFAILSAFEvO_FS_LOW_SUN_0_RMIN            ( 0U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_LOW_SUN_0_RMAX            ( 5U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_LOW_SUN_0_NUMR            ( 1U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_LOW_SUN_0_DEMNR           ( 1U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_LOW_SUN_0_OFFSET          ( 0U )

/* FS_Sun_Ray_0_b3 signal Enums */
typedef uint8 COREFAILSAFEvOFSSunRay0;
#define C_EYEQMSG_COREFAILSAFEvO_FS_SUN_RAY_0_NOT_READY       ( COREFAILSAFEvOFSSunRay0 ) ( 0U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_SUN_RAY_0_NONE            ( COREFAILSAFEvOFSSunRay0 ) ( 1U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_SUN_RAY_0_25              ( COREFAILSAFEvOFSSunRay0 ) ( 2U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_SUN_RAY_0_50              ( COREFAILSAFEvOFSSunRay0 ) ( 3U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_SUN_RAY_0_75              ( COREFAILSAFEvOFSSunRay0 ) ( 4U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_SUN_RAY_0_99              ( COREFAILSAFEvOFSSunRay0 ) ( 5U )

/* FS_Sun_Ray_0_b3 signal Min & Max range limits */
#define C_EYEQMSG_COREFAILSAFEvO_FS_SUN_RAY_0_RMIN            ( 0U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_SUN_RAY_0_RMAX            ( 5U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_SUN_RAY_0_NUMR            ( 1U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_SUN_RAY_0_DEMNR           ( 1U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_SUN_RAY_0_OFFSET          ( 0U )

/* FS_Splashes_0_b3 signal Enums */
typedef uint8 COREFAILSAFEvOFSSplashes0;
#define C_EYEQMSG_COREFAILSAFEvO_FS_SPLASHES_0_NOT_READY      ( COREFAILSAFEvOFSSplashes0 ) ( 0U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_SPLASHES_0_NONE           ( COREFAILSAFEvOFSSplashes0 ) ( 1U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_SPLASHES_0_25             ( COREFAILSAFEvOFSSplashes0 ) ( 2U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_SPLASHES_0_50             ( COREFAILSAFEvOFSSplashes0 ) ( 3U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_SPLASHES_0_75             ( COREFAILSAFEvOFSSplashes0 ) ( 4U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_SPLASHES_0_99             ( COREFAILSAFEvOFSSplashes0 ) ( 5U )

/* FS_Splashes_0_b3 signal Min & Max range limits */
#define C_EYEQMSG_COREFAILSAFEvO_FS_SPLASHES_0_RMIN           ( 0U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_SPLASHES_0_RMAX           ( 5U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_SPLASHES_0_NUMR           ( 1U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_SPLASHES_0_DEMNR          ( 1U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_SPLASHES_0_OFFSET         ( 0U )

/* FS_Free_Sight_0_b1 signal Enums */
typedef boolean COREFAILSAFEvOFSFreeSight0;
#define C_EYEQMSG_COREFAILSAFEvO_FS_FREE_SIGHT_0_FALSE        ( COREFAILSAFEvOFSFreeSight0 ) ( 0U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_FREE_SIGHT_0_TRUE         ( COREFAILSAFEvOFSFreeSight0 ) ( 1U )

/* FS_Free_Sight_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREFAILSAFEvO_FS_FREE_SIGHT_0_RMIN         ( 0U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_FREE_SIGHT_0_RMAX         ( 1U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_FREE_SIGHT_0_NUMR         ( 1U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_FREE_SIGHT_0_DEMNR        ( 1U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_FREE_SIGHT_0_OFFSET       ( 0U )

/* FS_Camera_ID_0_b4 signal Min & Max range limits */
#define C_EYEQMSG_COREFAILSAFEvO_FS_CAMERA_ID_0_RMIN          ( 0U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_CAMERA_ID_0_RMAX          ( 11U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_CAMERA_ID_0_NUMR          ( 1U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_CAMERA_ID_0_DEMNR         ( 1U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_CAMERA_ID_0_OFFSET        ( 0U )

/* FS_CRC_0_b32 signal Min & Max range limits */
#define C_EYEQMSG_COREFAILSAFEvO_FS_CRC_0_RMIN                ( 0U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_CRC_0_RMAX                ( 4294967295U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_CRC_0_NUMR                ( 1U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_CRC_0_DEMNR               ( 1U )
#define C_EYEQMSG_COREFAILSAFEvO_FS_CRC_0_OFFSET              ( 0U )


/*****************************************************************************
                  Exported function-like macros
*****************************************************************************/
/*****************************************************************************
                  Exported defined macros
*****************************************************************************/
/*****************************************************************************
                  Exported types, enums definitions
*****************************************************************************/
typedef struct
{
   #if ENABLE_BIG_ENDIAN_FORMAT
      uint32        FSP_Zero_byte_b8                             : 8U;
      
      uint32        Reserved_1_1_b8                              : 8U;
      
      uint32        Reserved_1_2_b8                              : 8U;
      
      uint32        Reserved_1_3_b8                              : 8U;
      
      uint32        FS_Header_CRC_1_b8                           : 8U;
      
      uint32        FS_Header_CRC_2_b8                           : 8U;
      
      uint32        FS_Header_CRC_3_b8                           : 8U;
      
      uint32        FS_Header_CRC_4_b8                           : 8U;
      
      uint32        FS_Protocol_Version_b8                       : 8U;
      
      uint32        FS_Sync_ID_b8                                : 8U;
      
      uint32        unused1_b4                                   : 4;
      uint32        FS_Cameras_Number_b4                         : 4U;
      
      uint32        FS_TSR_Out_OF_Calib_1_b4                     : 4U;
      
      uint32        FS_TSR_Out_OF_Calib_2_b4                     : 4U;
      
      uint32        FS_Out_Of_Calib_b3                           : 3U;
      
      uint32        Reserved_2_b1                                : 1U;
      
      uint32        FS_Impacted_Technologies_1_b8                : 8U;
      
      uint32        FS_Impacted_Technologies_2_b8                : 8U;
      
      uint32        FS_Impacted_Technologies_Surround_1_b8       : 8U;
      
      uint32        FS_Impacted_Technologies_Surround_2_b8       : 8U;
      
      uint32        unused2_b1                                   : 1;
      uint32        FS_Rain_b3                                   : 3U;
      
      uint32        FS_Fog_b3                                    : 3U;
      
      uint32        FS_Calibration_Misalignment_1_b2             : 2U;
      
      uint32        unused3_b2                                   : 2;
      uint32        FS_Calibration_Misalignment_2_b1             : 1U;
      
      uint32        FS_C2W_OOR_b3                                : 3U;
      
      uint32        Reserved_3_1_b4                              : 4U;
      
      uint32        Reserved_3_2_b8                              : 8U;
      
      uint32        Reserved_3_3_b8                              : 8U;
      
   #else
      uint32        FSP_Zero_byte_b8                             : 8U;
      
      uint32        Reserved_1_b24                               : 24U;
      
      uint32        FS_Header_CRC_b32                            : 32U;
      
      uint32        FS_Protocol_Version_b8                       : 8U;
      
      uint32        FS_Sync_ID_b8                                : 8U;
      
      uint32        FS_Cameras_Number_b4                         : 4U;
      
      uint32        FS_TSR_Out_OF_Calib_b8                       : 8U;
      
      uint32        FS_Out_Of_Calib_b3                           : 3U;
      
      uint32        Reserved_2_b1                                : 1U;
      
      uint32        FS_Impacted_Technologies_b16                 : 16U;
      
      uint32        FS_Impacted_Technologies_Surround_b16        : 16U;
      
      uint32        FS_Rain_b3                                   : 3U;
      
      uint32        FS_Fog_b3                                    : 3U;
      
      uint32        FS_Calibration_Misalignment_b3               : 3U;
      
      uint32        FS_C2W_OOR_b3                                : 3U;
      
      uint32        Reserved_3_b20                               : 20U;
      
   #endif
} EYEQMSG_COREFAILSAFEvH_Params_t;


typedef struct
{
   #if ENABLE_BIG_ENDIAN_FORMAT
      uint32        unused1_b160                                 : 160;
      uint32        FS_CRC_0_1_b8                                : 8U;
      
      uint32        FS_CRC_0_2_b8                                : 8U;
      
      uint32        FS_CRC_0_3_b8                                : 8U;
      
      uint32        FS_CRC_0_4_b8                                : 8U;
      
      uint32        unused2_b4                                   : 4;
      uint32        FS_Camera_ID_0_b4                            : 4U;
      
      uint32        FS_Free_Sight_0_b1                           : 1U;
      
      uint32        FS_Splashes_0_b3                             : 3U;
      
      uint32        unused3_b1                                   : 1;
      uint32        FS_Sun_Ray_0_b3                              : 3U;
      
      uint32        FS_Low_Sun_0_b3                              : 3U;
      
      uint32        FS_Blur_Image_0_1_b2                         : 2U;
      
      uint32        unused4_b2                                   : 2;
      uint32        FS_Blur_Image_0_2_b1                         : 1U;
      
      uint32        FS_Partial_Blockage_0_b3                     : 3U;
      
      uint32        FS_Full_Blockage_0_b3                        : 3U;
      
      uint32        FS_Frozen_Windshield_Lens_0_1_b1             : 1U;
      
      uint32        FS_Frozen_Windshield_Lens_0_2_b2             : 2U;
      
      uint32        FS_Out_Of_Focus_0_b3                         : 3U;
      
      uint32        FS_C2C_Out_Of_Calib_0_b3                     : 3U;
      
   #else
      uint32        FS_CRC_0_b32                                 : 32U;
      
      uint32        FS_Camera_ID_0_b4                            : 4U;
      
      uint32        FS_Free_Sight_0_b1                           : 1U;
      
      uint32        FS_Splashes_0_b3                             : 3U;
      
      uint32        FS_Sun_Ray_0_b3                              : 3U;
      
      uint32        FS_Low_Sun_0_b3                              : 3U;
      
      uint32        FS_Blur_Image_0_b3                           : 3U;
      
      uint32        FS_Partial_Blockage_0_b3                     : 3U;
      
      uint32        FS_Full_Blockage_0_b3                        : 3U;
      
      uint32        FS_Frozen_Windshield_Lens_0_b3               : 3U;
      
      uint32        FS_Out_Of_Focus_0_b3                         : 3U;
      
      uint32        FS_C2C_Out_Of_Calib_0_b3                     : 3U;
      
   #endif
} EYEQMSG_COREFAILSAFEvO_Params_t;


typedef struct
{
   EYEQMSG_COREFAILSAFEvH_Params_t EYEQMSG_COREFAILSAFEvH_Params_s;
   EYEQMSG_COREFAILSAFEvO_Params_t EYEQMSG_COREFAILSAFEvO_Params_as[C_EYEQMSG_COREFAILSAFEvH_VIRTUAL_OBJECT_INDEX_RMAX];
} EYEQMSG_COREFAILSAFE_Params_t;


/*****************************************************************************
                  Exported function prototypes
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvH_FSP_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pFSP_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FSP_Zero_byte
*    FSP_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FSP_Zero_byte signal value of Virtual_HEADER_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvH_FSP_Zero_byte( uint8 * pFSP_Zero_byte );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvH_Reserved_1
*
* FUNCTION ARGUMENTS:
*    uint32 * pReserved_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1
*    Reserved_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1 signal value of Virtual_HEADER_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvH_Reserved_1( uint32 * pReserved_1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvH_FS_Header_CRC
*
* FUNCTION ARGUMENTS:
*    uint32 * pFS_Header_CRC - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FS_Header_CRC
*    FS_Header_CRC returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FS_Header_CRC signal value of Virtual_HEADER_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvH_FS_Header_CRC( uint32 * pFS_Header_CRC );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvH_FS_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pFS_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FS_Protocol_Version
*    FS_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FS_Protocol_Version signal value of Virtual_HEADER_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvH_FS_Protocol_Version( uint8 * pFS_Protocol_Version );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvH_FS_Sync_ID
*
* FUNCTION ARGUMENTS:
*    uint8 * pFS_Sync_ID - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FS_Sync_ID
*    FS_Sync_ID returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FS_Sync_ID signal value of Virtual_HEADER_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvH_FS_Sync_ID( uint8 * pFS_Sync_ID );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvH_FS_Cameras_Number
*
* FUNCTION ARGUMENTS:
*    uint8 * pFS_Cameras_Number - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FS_Cameras_Number
*    FS_Cameras_Number returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FS_Cameras_Number signal value of Virtual_HEADER_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvH_FS_Cameras_Number( uint8 * pFS_Cameras_Number );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvH_FS_TSR_Out_OF_Calib
*
* FUNCTION ARGUMENTS:
*    COREFAILSAFEvHFSTSROutOFCalib * pFS_TSR_Out_OF_Calib - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FS_TSR_Out_OF_Calib
*    FS_TSR_Out_OF_Calib returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FS_TSR_Out_OF_Calib signal value of Virtual_HEADER_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvH_FS_TSR_Out_OF_Calib( COREFAILSAFEvHFSTSROutOFCalib * pFS_TSR_Out_OF_Calib );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvH_FS_Out_Of_Calib
*
* FUNCTION ARGUMENTS:
*    COREFAILSAFEvHFSOutOfCalib * pFS_Out_Of_Calib - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FS_Out_Of_Calib
*    FS_Out_Of_Calib returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FS_Out_Of_Calib signal value of Virtual_HEADER_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvH_FS_Out_Of_Calib( COREFAILSAFEvHFSOutOfCalib * pFS_Out_Of_Calib );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvH_Reserved_2
*
* FUNCTION ARGUMENTS:
*    boolean * pReserved_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_2
*    Reserved_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_2 signal value of Virtual_HEADER_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvH_Reserved_2( boolean * pReserved_2 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvH_FS_Impacted_Technologies
*
* FUNCTION ARGUMENTS:
*    COREFAILSAFEvHFSImpactedTechnologies * pFS_Impacted_Technologies - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FS_Impacted_Technologies
*    FS_Impacted_Technologies returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FS_Impacted_Technologies signal value of Virtual_HEADER_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvH_FS_Impacted_Technologies( COREFAILSAFEvHFSImpactedTechnologies * pFS_Impacted_Technologies );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvH_FS_Impacted_Technologies_Surround
*
* FUNCTION ARGUMENTS:
*    COREFAILSAFEvHFSImpactedTechnologiesSurround * pFS_Impacted_Technologies_Surround - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FS_Impacted_Technologies_Surround
*    FS_Impacted_Technologies_Surround returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FS_Impacted_Technologies_Surround signal value of Virtual_HEADER_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvH_FS_Impacted_Technologies_Surround( COREFAILSAFEvHFSImpactedTechnologiesSurround * pFS_Impacted_Technologies_Surround );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvH_FS_Rain
*
* FUNCTION ARGUMENTS:
*    COREFAILSAFEvHFSRain * pFS_Rain - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FS_Rain
*    FS_Rain returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FS_Rain signal value of Virtual_HEADER_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvH_FS_Rain( COREFAILSAFEvHFSRain * pFS_Rain );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvH_FS_Fog
*
* FUNCTION ARGUMENTS:
*    COREFAILSAFEvHFSFog * pFS_Fog - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FS_Fog
*    FS_Fog returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FS_Fog signal value of Virtual_HEADER_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvH_FS_Fog( COREFAILSAFEvHFSFog * pFS_Fog );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvH_FS_Calibration_Misalignment
*
* FUNCTION ARGUMENTS:
*    COREFAILSAFEvHFSCalibrationMisalignment * pFS_Calibration_Misalignment - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FS_Calibration_Misalignment
*    FS_Calibration_Misalignment returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FS_Calibration_Misalignment signal value of Virtual_HEADER_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvH_FS_Calibration_Misalignment( COREFAILSAFEvHFSCalibrationMisalignment * pFS_Calibration_Misalignment );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvH_FS_C2W_OOR
*
* FUNCTION ARGUMENTS:
*    COREFAILSAFEvHFSC2WOOR * pFS_C2W_OOR - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FS_C2W_OOR
*    FS_C2W_OOR returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FS_C2W_OOR signal value of Virtual_HEADER_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvH_FS_C2W_OOR( COREFAILSAFEvHFSC2WOOR * pFS_C2W_OOR );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvH_Reserved_3
*
* FUNCTION ARGUMENTS:
*    uint32 * pReserved_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_3
*    Reserved_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_3 signal value of Virtual_HEADER_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvH_Reserved_3( uint32 * pReserved_3 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvO_FS_CRC_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint32 * pFS_CRC_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FS_CRC_0
*    FS_CRC_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FS_CRC_0 signal value of Virtual_OBJECT_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvO_FS_CRC_0( uint8 objIndx_u8, uint32 * pFS_CRC_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvO_FS_Camera_ID_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pFS_Camera_ID_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FS_Camera_ID_0
*    FS_Camera_ID_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FS_Camera_ID_0 signal value of Virtual_OBJECT_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvO_FS_Camera_ID_0( uint8 objIndx_u8, uint8 * pFS_Camera_ID_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvO_FS_Free_Sight_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREFAILSAFEvOFSFreeSight0 * pFS_Free_Sight_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FS_Free_Sight_0
*    FS_Free_Sight_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FS_Free_Sight_0 signal value of Virtual_OBJECT_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvO_FS_Free_Sight_0( uint8 objIndx_u8, COREFAILSAFEvOFSFreeSight0 * pFS_Free_Sight_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvO_FS_Splashes_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREFAILSAFEvOFSSplashes0 * pFS_Splashes_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FS_Splashes_0
*    FS_Splashes_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FS_Splashes_0 signal value of Virtual_OBJECT_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvO_FS_Splashes_0( uint8 objIndx_u8, COREFAILSAFEvOFSSplashes0 * pFS_Splashes_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvO_FS_Sun_Ray_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREFAILSAFEvOFSSunRay0 * pFS_Sun_Ray_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FS_Sun_Ray_0
*    FS_Sun_Ray_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FS_Sun_Ray_0 signal value of Virtual_OBJECT_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvO_FS_Sun_Ray_0( uint8 objIndx_u8, COREFAILSAFEvOFSSunRay0 * pFS_Sun_Ray_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvO_FS_Low_Sun_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREFAILSAFEvOFSLowSun0 * pFS_Low_Sun_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FS_Low_Sun_0
*    FS_Low_Sun_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FS_Low_Sun_0 signal value of Virtual_OBJECT_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvO_FS_Low_Sun_0( uint8 objIndx_u8, COREFAILSAFEvOFSLowSun0 * pFS_Low_Sun_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvO_FS_Blur_Image_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREFAILSAFEvOFSBlurImage0 * pFS_Blur_Image_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FS_Blur_Image_0
*    FS_Blur_Image_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FS_Blur_Image_0 signal value of Virtual_OBJECT_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvO_FS_Blur_Image_0( uint8 objIndx_u8, COREFAILSAFEvOFSBlurImage0 * pFS_Blur_Image_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvO_FS_Partial_Blockage_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREFAILSAFEvOFSPartialBlockage0 * pFS_Partial_Blockage_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FS_Partial_Blockage_0
*    FS_Partial_Blockage_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FS_Partial_Blockage_0 signal value of Virtual_OBJECT_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvO_FS_Partial_Blockage_0( uint8 objIndx_u8, COREFAILSAFEvOFSPartialBlockage0 * pFS_Partial_Blockage_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvO_FS_Full_Blockage_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREFAILSAFEvOFSFullBlockage0 * pFS_Full_Blockage_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FS_Full_Blockage_0
*    FS_Full_Blockage_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FS_Full_Blockage_0 signal value of Virtual_OBJECT_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvO_FS_Full_Blockage_0( uint8 objIndx_u8, COREFAILSAFEvOFSFullBlockage0 * pFS_Full_Blockage_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvO_FS_Frozen_Windshield_Lens_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREFAILSAFEvOFSFrozenWindshieldLens0 * pFS_Frozen_Windshield_Lens_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FS_Frozen_Windshield_Lens_0
*    FS_Frozen_Windshield_Lens_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FS_Frozen_Windshield_Lens_0 signal value of Virtual_OBJECT_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvO_FS_Frozen_Windshield_Lens_0( uint8 objIndx_u8, COREFAILSAFEvOFSFrozenWindshieldLens0 * pFS_Frozen_Windshield_Lens_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvO_FS_Out_Of_Focus_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREFAILSAFEvOFSOutOfFocus0 * pFS_Out_Of_Focus_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FS_Out_Of_Focus_0
*    FS_Out_Of_Focus_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FS_Out_Of_Focus_0 signal value of Virtual_OBJECT_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvO_FS_Out_Of_Focus_0( uint8 objIndx_u8, COREFAILSAFEvOFSOutOfFocus0 * pFS_Out_Of_Focus_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvO_FS_C2C_Out_Of_Calib_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREFAILSAFEvOFSC2COutOfCalib0 * pFS_C2C_Out_Of_Calib_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FS_C2C_Out_Of_Calib_0
*    FS_C2C_Out_Of_Calib_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FS_C2C_Out_Of_Calib_0 signal value of Virtual_OBJECT_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvO_FS_C2C_Out_Of_Calib_0( uint8 objIndx_u8, COREFAILSAFEvOFSC2COutOfCalib0 * pFS_C2C_Out_Of_Calib_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_COREFAILSAFE_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_COREFAILSAFE_Params_t * pCore_Failsafe_protocol - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_Failsafe_protocol message 
*    Core_Failsafe_protocol message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_Failsafe_protocol message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_COREFAILSAFE_ParamsApp_MsgDataStruct( EYEQMSG_COREFAILSAFE_Params_t * pCore_Failsafe_protocol );
/*****************************************************************************
                  Exported object declarations
*****************************************************************************/
extern EYEQMSG_COREFAILSAFE_Params_t   EYEQMSG_COREFAILSAFE_Params_s;
extern EYEQMSG_COREFAILSAFE_Params_t   EYEQMSG_COREFAILSAFE_ParamsApp_s;
/****************************************************************************/
#endif /* _EYEQMSG_COREFAILSAFEPROCESS_H_ */


