#ifndef _EYEQMSG_COREDVINITPROCESS_H_
#define _EYEQMSG_COREDVINITPROCESS_H_

/*****************************************************************************
                  Included header files
*****************************************************************************/
#include <Std_Types.h>

/*****************************************************************************
                  Include files
*****************************************************************************/
/*****************************************************************************
                  Exported symbolic constants
*****************************************************************************/

/* Datagram message ID */
#define C_EYEQMSG_COREDVINIT_MSG_ID                           ( 0x86U )

/* Datagram message lengths */
#define C_EYEQMSG_COREDVINIT_MSG_LEN                          ( sizeof(EYEQMSG_COREDVINIT_Params_t) )

/* Protocol ENUMs */

/* MCU output messages */

/* Core_DV_Init Enums */
/* IDV_Optional_Signals_b16 signal Min & Max range limits */
#define C_EYEQMSG_COREDVINIT_IDV_OPTIONAL_SIGNALS_RMIN        ( 0U )
#define C_EYEQMSG_COREDVINIT_IDV_OPTIONAL_SIGNALS_RMAX        ( 0U )
#define C_EYEQMSG_COREDVINIT_IDV_OPTIONAL_SIGNALS_NUMR        ( 1U )
#define C_EYEQMSG_COREDVINIT_IDV_OPTIONAL_SIGNALS_DEMNR       ( 1U )
#define C_EYEQMSG_COREDVINIT_IDV_OPTIONAL_SIGNALS_OFFSET      ( 0U )

/* IDV_Protocol_Version_b8 signal Min & Max range limits */
#define C_EYEQMSG_COREDVINIT_IDV_PROTOCOL_VERSION_RMIN        ( 2U )
#define C_EYEQMSG_COREDVINIT_IDV_PROTOCOL_VERSION_RMAX        ( 2U )
#define C_EYEQMSG_COREDVINIT_IDV_PROTOCOL_VERSION_NUMR        ( 1U )
#define C_EYEQMSG_COREDVINIT_IDV_PROTOCOL_VERSION_DEMNR       ( 1U )
#define C_EYEQMSG_COREDVINIT_IDV_PROTOCOL_VERSION_OFFSET      ( 0U )

/* IDV_Zero_byte_b8 signal Min & Max range limits */
#define C_EYEQMSG_COREDVINIT_IDV_ZERO_BYTE_RMIN               ( 0U )
#define C_EYEQMSG_COREDVINIT_IDV_ZERO_BYTE_RMAX               ( 0U )
#define C_EYEQMSG_COREDVINIT_IDV_ZERO_BYTE_NUMR               ( 1U )
#define C_EYEQMSG_COREDVINIT_IDV_ZERO_BYTE_DEMNR              ( 1U )
#define C_EYEQMSG_COREDVINIT_IDV_ZERO_BYTE_OFFSET             ( 0U )


/*****************************************************************************
                  Exported function-like macros
*****************************************************************************/
/*****************************************************************************
                  Exported defined macros
*****************************************************************************/
/*****************************************************************************
                  Exported types, enums definitions
*****************************************************************************/
typedef struct
{
   #if ENABLE_BIG_ENDIAN_FORMAT
      uint32        IDV_Zero_byte_b8                             : 8U;
      
      uint32        IDV_Protocol_Version_b8                      : 8U;
      
      uint32        IDV_Optional_Signals_1_b8                    : 8U;
      
      uint32        IDV_Optional_Signals_2_b8                    : 8U;
      
   #else
      uint32        IDV_Zero_byte_b8                             : 8U;
      
      uint32        IDV_Protocol_Version_b8                      : 8U;
      
      uint32        IDV_Optional_Signals_b16                     : 16U;
      
   #endif
} EYEQMSG_COREDVINIT_Params_t;


/*****************************************************************************
                  Exported function prototypes
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_COREDVINIT_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_COREDVINIT_Params_t * pCore_DV_Init - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_DV_Init message 
*    Core_DV_Init message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_DV_Init message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_COREDVINIT_ParamsApp_MsgDataStruct( EYEQMSG_COREDVINIT_Params_t * pCore_DV_Init );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREDVINIT_IDV_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pIDV_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IDV_Zero_byte
*    IDV_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IDV_Zero_byte signal value of Core_DV_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREDVINIT_IDV_Zero_byte( uint8 * pIDV_Zero_byte );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREDVINIT_IDV_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pIDV_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IDV_Protocol_Version
*    IDV_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IDV_Protocol_Version signal value of Core_DV_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREDVINIT_IDV_Protocol_Version( uint8 * pIDV_Protocol_Version );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREDVINIT_IDV_Optional_Signals
*
* FUNCTION ARGUMENTS:
*    uint16 * pIDV_Optional_Signals - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IDV_Optional_Signals
*    IDV_Optional_Signals returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IDV_Optional_Signals signal value of Core_DV_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREDVINIT_IDV_Optional_Signals( uint16 * pIDV_Optional_Signals );
/*****************************************************************************
                  Exported object declarations
*****************************************************************************/
extern EYEQMSG_COREDVINIT_Params_t   EYEQMSG_COREDVINIT_Params_s;
extern EYEQMSG_COREDVINIT_Params_t   EYEQMSG_COREDVINIT_ParamsApp_s;
/****************************************************************************/
#endif /* _EYEQMSG_COREDVINITPROCESS_H_ */


