

/*****************************************************************************
                  Include files
*****************************************************************************/
/* The suggested include file order is: */
#include "EyeQ_defs.h"    /* EyeQ project common definitions file    */

#include "EYEQMSG_GenInitProcess.h"

/*****************************************************************************
                  Local symbolic constants
*****************************************************************************/
/*****************************************************************************
                  Local types, enums definitions
*****************************************************************************/
/*****************************************************************************
                  Local function prototypes
*****************************************************************************/
/*****************************************************************************
                  Local object definitions
*****************************************************************************/
/*****************************************************************************
                  Exported object definitions
*****************************************************************************/
EYEQMSG_GENINIT_Params_t   EYEQMSG_GENINIT_Params_s;
EYEQMSG_GENINIT_Params_t   EYEQMSG_GENINIT_ParamsApp_s;
/*****************************************************************************
                  Local function-like macros
*****************************************************************************/
/*****************************************************************************
                  Local defined macros
*****************************************************************************/
/*****************************************************************************
                  Function definitions
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_GENINIT_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_GENINIT_Params_t * pGeneral_Init - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of General_Init message 
*    General_Init message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns General_Init message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_GENINIT_ParamsApp_MsgDataStruct( EYEQMSG_GENINIT_Params_t * pGeneral_Init )
{
   Std_ReturnType status = C_SIG_INVALID;
   if( pGeneral_Init != C_NULL_P )
   {
      status = C_SIG_VALID;
      * pGeneral_Init = EYEQMSG_GENINIT_ParamsApp_s;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_GENINIT_IGeneral_Zero_Byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pIGeneral_Zero_Byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IGeneral_Zero_Byte
*    IGeneral_Zero_Byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IGeneral_Zero_Byte signal value of General_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_GENINIT_IGeneral_Zero_Byte( uint8 * pIGeneral_Zero_Byte )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pIGeneral_Zero_Byte != C_NULL_P )
   {
      signal_value = EYEQMSG_GENINIT_ParamsApp_s.IGeneral_Zero_Byte_b8;
      * pIGeneral_Zero_Byte = signal_value;
      if( signal_value <= C_EYEQMSG_GENINIT_IGENERAL_ZERO_BYTE_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_GENINIT_IGeneral_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pIGeneral_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IGeneral_Protocol_Version
*    IGeneral_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IGeneral_Protocol_Version signal value of General_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_GENINIT_IGeneral_Protocol_Version( uint8 * pIGeneral_Protocol_Version )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pIGeneral_Protocol_Version != C_NULL_P )
   {
      signal_value = EYEQMSG_GENINIT_ParamsApp_s.IGeneral_Protocol_Version_b8;
      * pIGeneral_Protocol_Version = signal_value;
      if( (signal_value >= C_EYEQMSG_GENINIT_IGENERAL_PROTOCOL_VERSION_RMIN ) 
          && (signal_value <= C_EYEQMSG_GENINIT_IGENERAL_PROTOCOL_VERSION_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_GENINIT_IGeneral_Optional_Signals
*
* FUNCTION ARGUMENTS:
*    uint8 * pIGeneral_Optional_Signals - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IGeneral_Optional_Signals
*    IGeneral_Optional_Signals returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IGeneral_Optional_Signals signal value of General_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_GENINIT_IGeneral_Optional_Signals( uint8 * pIGeneral_Optional_Signals )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pIGeneral_Optional_Signals != C_NULL_P )
   {
      signal_value = EYEQMSG_GENINIT_ParamsApp_s.IGeneral_Optional_Signals_b3;
      * pIGeneral_Optional_Signals = signal_value;
      if( (signal_value >= C_EYEQMSG_GENINIT_IGENERAL_OPTIONAL_SIGNALS_RMIN ) 
          && (signal_value <= C_EYEQMSG_GENINIT_IGENERAL_OPTIONAL_SIGNALS_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_GENINIT_IGeneral_Buffer_1_V
*
* FUNCTION ARGUMENTS:
*    boolean * pIGeneral_Buffer_1_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IGeneral_Buffer_1_V
*    IGeneral_Buffer_1_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IGeneral_Buffer_1_V signal value of General_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_GENINIT_IGeneral_Buffer_1_V( boolean * pIGeneral_Buffer_1_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIGeneral_Buffer_1_V != C_NULL_P )
   {
      signal_value = EYEQMSG_GENINIT_ParamsApp_s.IGeneral_Buffer_1_V_b1;
      * pIGeneral_Buffer_1_V = signal_value;
      if( signal_value <= C_EYEQMSG_GENINIT_IGENERAL_BUFFER_1_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_GENINIT_IGeneral_Buffer_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pIGeneral_Buffer_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IGeneral_Buffer_1
*    IGeneral_Buffer_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IGeneral_Buffer_1 signal value of General_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_GENINIT_IGeneral_Buffer_1( uint16 * pIGeneral_Buffer_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pIGeneral_Buffer_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_GENINIT_ParamsApp_s.IGeneral_Buffer_1_b11;
      * pIGeneral_Buffer_1 = signal_value;
      if( signal_value <= C_EYEQMSG_GENINIT_IGENERAL_BUFFER_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_GENINIT_IGeneral_Roll_Angle_Base_V
*
* FUNCTION ARGUMENTS:
*    GENINITIGeneralRollAngleBaseV * pIGeneral_Roll_Angle_Base_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IGeneral_Roll_Angle_Base_V
*    IGeneral_Roll_Angle_Base_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IGeneral_Roll_Angle_Base_V signal value of General_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_GENINIT_IGeneral_Roll_Angle_Base_V( GENINITIGeneralRollAngleBaseV * pIGeneral_Roll_Angle_Base_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   GENINITIGeneralRollAngleBaseV signal_value;
   
   if( pIGeneral_Roll_Angle_Base_V != C_NULL_P )
   {
      signal_value = EYEQMSG_GENINIT_ParamsApp_s.IGeneral_Roll_Angle_Base_V_b1;
      * pIGeneral_Roll_Angle_Base_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_GENINIT_IGeneral_Roll_Angle_Base
*
* FUNCTION ARGUMENTS:
*    float32 * pIGeneral_Roll_Angle_Base - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IGeneral_Roll_Angle_Base
*    IGeneral_Roll_Angle_Base returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IGeneral_Roll_Angle_Base signal value of General_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_GENINIT_IGeneral_Roll_Angle_Base( float32 * pIGeneral_Roll_Angle_Base )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float32SigDataType signal_value;
   
   if( pIGeneral_Roll_Angle_Base != C_NULL_P )
   {
      signal_value.u = EYEQMSG_GENINIT_ParamsApp_s.IGeneral_Roll_Angle_Base_sb32;
      * pIGeneral_Roll_Angle_Base = signal_value.f;
      if( (signal_value.f >= C_EYEQMSG_GENINIT_IGENERAL_ROLL_ANGLE_BASE_RMIN ) 
          && (signal_value.f <= C_EYEQMSG_GENINIT_IGENERAL_ROLL_ANGLE_BASE_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_GENINIT_IGeneral_CLB_DYN_AF_Pitch_V
*
* FUNCTION ARGUMENTS:
*    GENINITIGeneralCLBDYNAFPitchV * pIGeneral_CLB_DYN_AF_Pitch_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IGeneral_CLB_DYN_AF_Pitch_V
*    IGeneral_CLB_DYN_AF_Pitch_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IGeneral_CLB_DYN_AF_Pitch_V signal value of General_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_GENINIT_IGeneral_CLB_DYN_AF_Pitch_V( GENINITIGeneralCLBDYNAFPitchV * pIGeneral_CLB_DYN_AF_Pitch_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   GENINITIGeneralCLBDYNAFPitchV signal_value;
   
   if( pIGeneral_CLB_DYN_AF_Pitch_V != C_NULL_P )
   {
      signal_value = EYEQMSG_GENINIT_ParamsApp_s.IGeneral_CLB_DYN_AF_Pitch_V_b1;
      * pIGeneral_CLB_DYN_AF_Pitch_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_GENINIT_IGeneral_CLB_DYN_AF_Pitch
*
* FUNCTION ARGUMENTS:
*    uint16 * pIGeneral_CLB_DYN_AF_Pitch - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IGeneral_CLB_DYN_AF_Pitch
*    IGeneral_CLB_DYN_AF_Pitch returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IGeneral_CLB_DYN_AF_Pitch signal value of General_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_GENINIT_IGeneral_CLB_DYN_AF_Pitch( uint16 * pIGeneral_CLB_DYN_AF_Pitch )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pIGeneral_CLB_DYN_AF_Pitch != C_NULL_P )
   {
      signal_value = EYEQMSG_GENINIT_ParamsApp_s.IGeneral_CLB_DYN_AF_Pitch_b15;
      * pIGeneral_CLB_DYN_AF_Pitch = signal_value;
      if( signal_value <= C_EYEQMSG_GENINIT_IGENERAL_CLB_DYN_AF_PITCH_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_GENINIT_IGeneral_CLB_DYN_AF_Yaw_V
*
* FUNCTION ARGUMENTS:
*    GENINITIGeneralCLBDYNAFYawV * pIGeneral_CLB_DYN_AF_Yaw_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IGeneral_CLB_DYN_AF_Yaw_V
*    IGeneral_CLB_DYN_AF_Yaw_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IGeneral_CLB_DYN_AF_Yaw_V signal value of General_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_GENINIT_IGeneral_CLB_DYN_AF_Yaw_V( GENINITIGeneralCLBDYNAFYawV * pIGeneral_CLB_DYN_AF_Yaw_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   GENINITIGeneralCLBDYNAFYawV signal_value;
   
   if( pIGeneral_CLB_DYN_AF_Yaw_V != C_NULL_P )
   {
      signal_value = EYEQMSG_GENINIT_ParamsApp_s.IGeneral_CLB_DYN_AF_Yaw_V_b1;
      * pIGeneral_CLB_DYN_AF_Yaw_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_GENINIT_IGeneral_CLB_DYN_AF_Yaw
*
* FUNCTION ARGUMENTS:
*    uint16 * pIGeneral_CLB_DYN_AF_Yaw - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IGeneral_CLB_DYN_AF_Yaw
*    IGeneral_CLB_DYN_AF_Yaw returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IGeneral_CLB_DYN_AF_Yaw signal value of General_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_GENINIT_IGeneral_CLB_DYN_AF_Yaw( uint16 * pIGeneral_CLB_DYN_AF_Yaw )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pIGeneral_CLB_DYN_AF_Yaw != C_NULL_P )
   {
      signal_value = EYEQMSG_GENINIT_ParamsApp_s.IGeneral_CLB_DYN_AF_Yaw_b14;
      * pIGeneral_CLB_DYN_AF_Yaw = signal_value;
      if( signal_value <= C_EYEQMSG_GENINIT_IGENERAL_CLB_DYN_AF_YAW_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_GENINIT_IGeneral_CLB_DYN_AF_Roll_V
*
* FUNCTION ARGUMENTS:
*    GENINITIGeneralCLBDYNAFRollV * pIGeneral_CLB_DYN_AF_Roll_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IGeneral_CLB_DYN_AF_Roll_V
*    IGeneral_CLB_DYN_AF_Roll_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IGeneral_CLB_DYN_AF_Roll_V signal value of General_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_GENINIT_IGeneral_CLB_DYN_AF_Roll_V( GENINITIGeneralCLBDYNAFRollV * pIGeneral_CLB_DYN_AF_Roll_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   GENINITIGeneralCLBDYNAFRollV signal_value;
   
   if( pIGeneral_CLB_DYN_AF_Roll_V != C_NULL_P )
   {
      signal_value = EYEQMSG_GENINIT_ParamsApp_s.IGeneral_CLB_DYN_AF_Roll_V_b1;
      * pIGeneral_CLB_DYN_AF_Roll_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_GENINIT_IGeneral_CLB_DYN_AF_Roll
*
* FUNCTION ARGUMENTS:
*    float32 * pIGeneral_CLB_DYN_AF_Roll - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IGeneral_CLB_DYN_AF_Roll
*    IGeneral_CLB_DYN_AF_Roll returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IGeneral_CLB_DYN_AF_Roll signal value of General_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_GENINIT_IGeneral_CLB_DYN_AF_Roll( float32 * pIGeneral_CLB_DYN_AF_Roll )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float32SigDataType signal_value;
   
   if( pIGeneral_CLB_DYN_AF_Roll != C_NULL_P )
   {
      signal_value.u = EYEQMSG_GENINIT_ParamsApp_s.IGeneral_CLB_DYN_AF_Roll_sb32;
      * pIGeneral_CLB_DYN_AF_Roll = signal_value.f;
      if( (signal_value.f >= C_EYEQMSG_GENINIT_IGENERAL_CLB_DYN_AF_ROLL_RMIN ) 
          && (signal_value.f <= C_EYEQMSG_GENINIT_IGENERAL_CLB_DYN_AF_ROLL_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_GENINIT_IGeneral_Region_Code
*
* FUNCTION ARGUMENTS:
*    GENINITIGeneralRegionCode * pIGeneral_Region_Code - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IGeneral_Region_Code
*    IGeneral_Region_Code returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IGeneral_Region_Code signal value of General_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_GENINIT_IGeneral_Region_Code( GENINITIGeneralRegionCode * pIGeneral_Region_Code )
{
   Std_ReturnType status = C_SIG_INVALID;
   GENINITIGeneralRegionCode signal_value;
   
   if( pIGeneral_Region_Code != C_NULL_P )
   {
      signal_value = EYEQMSG_GENINIT_ParamsApp_s.IGeneral_Region_Code_b8;
      * pIGeneral_Region_Code = signal_value;
      if( signal_value <= C_EYEQMSG_GENINIT_IGENERAL_REGION_CODE_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_GENINIT_IGeneral_Driving_Side
*
* FUNCTION ARGUMENTS:
*    GENINITIGeneralDrivingSide * pIGeneral_Driving_Side - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IGeneral_Driving_Side
*    IGeneral_Driving_Side returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IGeneral_Driving_Side signal value of General_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_GENINIT_IGeneral_Driving_Side( GENINITIGeneralDrivingSide * pIGeneral_Driving_Side )
{
   Std_ReturnType status = C_SIG_INVALID;
   GENINITIGeneralDrivingSide signal_value;
   
   if( pIGeneral_Driving_Side != C_NULL_P )
   {
      signal_value = EYEQMSG_GENINIT_ParamsApp_s.IGeneral_Driving_Side_b2;
      * pIGeneral_Driving_Side = signal_value;
      if( signal_value <= C_EYEQMSG_GENINIT_IGENERAL_DRIVING_SIDE_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_GENINIT_IGeneral_HIL_Mode
*
* FUNCTION ARGUMENTS:
*    GENINITIGeneralHILMode * pIGeneral_HIL_Mode - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IGeneral_HIL_Mode
*    IGeneral_HIL_Mode returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IGeneral_HIL_Mode signal value of General_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_GENINIT_IGeneral_HIL_Mode( GENINITIGeneralHILMode * pIGeneral_HIL_Mode )
{
   Std_ReturnType status = C_SIG_INVALID;
   GENINITIGeneralHILMode signal_value;
   
   if( pIGeneral_HIL_Mode != C_NULL_P )
   {
      signal_value = EYEQMSG_GENINIT_ParamsApp_s.IGeneral_HIL_Mode_b1;
      * pIGeneral_HIL_Mode = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_GENINIT_IGeneral_Cam_Height_Full
*
* FUNCTION ARGUMENTS:
*    uint16 * pIGeneral_Cam_Height_Full - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IGeneral_Cam_Height_Full
*    IGeneral_Cam_Height_Full returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IGeneral_Cam_Height_Full signal value of General_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_GENINIT_IGeneral_Cam_Height_Full( uint16 * pIGeneral_Cam_Height_Full )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pIGeneral_Cam_Height_Full != C_NULL_P )
   {
      signal_value = EYEQMSG_GENINIT_ParamsApp_s.IGeneral_Cam_Height_Full_b16;
      * pIGeneral_Cam_Height_Full = signal_value;
      if( (signal_value >= C_EYEQMSG_GENINIT_IGENERAL_CAM_HEIGHT_FULL_RMIN ) 
          && (signal_value <= C_EYEQMSG_GENINIT_IGENERAL_CAM_HEIGHT_FULL_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_GENINIT_Reserved_1
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1
*    Reserved_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1 signal value of General_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_GENINIT_Reserved_1( uint8 * pReserved_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pReserved_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_GENINIT_ParamsApp_s.Reserved_1_b5;
      * pReserved_1 = signal_value;
      if( signal_value <= C_EYEQMSG_GENINIT_RESERVED_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_GENINIT_IGeneral_Pitch_Base
*
* FUNCTION ARGUMENTS:
*    uint16 * pIGeneral_Pitch_Base - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IGeneral_Pitch_Base
*    IGeneral_Pitch_Base returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IGeneral_Pitch_Base signal value of General_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_GENINIT_IGeneral_Pitch_Base( uint16 * pIGeneral_Pitch_Base )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pIGeneral_Pitch_Base != C_NULL_P )
   {
      signal_value = EYEQMSG_GENINIT_ParamsApp_s.IGeneral_Pitch_Base_b16;
      * pIGeneral_Pitch_Base = signal_value;
      if( signal_value <= C_EYEQMSG_GENINIT_IGENERAL_PITCH_BASE_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_GENINIT_IGeneral_Yaw_Base
*
* FUNCTION ARGUMENTS:
*    uint16 * pIGeneral_Yaw_Base - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IGeneral_Yaw_Base
*    IGeneral_Yaw_Base returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IGeneral_Yaw_Base signal value of General_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_GENINIT_IGeneral_Yaw_Base( uint16 * pIGeneral_Yaw_Base )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pIGeneral_Yaw_Base != C_NULL_P )
   {
      signal_value = EYEQMSG_GENINIT_ParamsApp_s.IGeneral_Yaw_Base_b16;
      * pIGeneral_Yaw_Base = signal_value;
      if( signal_value <= C_EYEQMSG_GENINIT_IGENERAL_YAW_BASE_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_GENINIT_IGeneral_Camera_Height_Base
*
* FUNCTION ARGUMENTS:
*    uint16 * pIGeneral_Camera_Height_Base - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IGeneral_Camera_Height_Base
*    IGeneral_Camera_Height_Base returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IGeneral_Camera_Height_Base signal value of General_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_GENINIT_IGeneral_Camera_Height_Base( uint16 * pIGeneral_Camera_Height_Base )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pIGeneral_Camera_Height_Base != C_NULL_P )
   {
      signal_value = EYEQMSG_GENINIT_ParamsApp_s.IGeneral_Camera_Height_Base_b16;
      * pIGeneral_Camera_Height_Base = signal_value;
      if( (signal_value >= C_EYEQMSG_GENINIT_IGENERAL_CAMERA_HEIGHT_BASE_RMIN ) 
          && (signal_value <= C_EYEQMSG_GENINIT_IGENERAL_CAMERA_HEIGHT_BASE_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_GENINIT_Reserved_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pReserved_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_2
*    Reserved_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_2 signal value of General_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_GENINIT_Reserved_2( uint16 * pReserved_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pReserved_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_GENINIT_ParamsApp_s.Reserved_2_b16;
      * pReserved_2 = signal_value;
      if( signal_value <= C_EYEQMSG_GENINIT_RESERVED_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

