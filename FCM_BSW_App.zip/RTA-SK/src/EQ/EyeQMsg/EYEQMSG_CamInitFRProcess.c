

/*****************************************************************************
                  Include files
*****************************************************************************/
/* The suggested include file order is: */
#include "EyeQ_defs.h"    /* EyeQ project common definitions file    */

#include "EYEQMSG_CamInitFRProcess.h"

/*****************************************************************************
                  Local symbolic constants
*****************************************************************************/
/*****************************************************************************
                  Local types, enums definitions
*****************************************************************************/
/*****************************************************************************
                  Local function prototypes
*****************************************************************************/
/*****************************************************************************
                  Local object definitions
*****************************************************************************/
/*****************************************************************************
                  Exported object definitions
*****************************************************************************/
EYEQMSG_CAMINITFR_Params_t   EYEQMSG_CAMINITFR_Params_s;
EYEQMSG_CAMINITFR_Params_t   EYEQMSG_CAMINITFR_ParamsApp_s;
/*****************************************************************************
                  Local function-like macros
*****************************************************************************/
/*****************************************************************************
                  Local defined macros
*****************************************************************************/
/*****************************************************************************
                  Function definitions
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_CAMINITFR_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_CAMINITFR_Params_t * pCamera_Init_frontCornerRight - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Camera_Init_frontCornerRight message 
*    Camera_Init_frontCornerRight message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Camera_Init_frontCornerRight message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_CAMINITFR_ParamsApp_MsgDataStruct( EYEQMSG_CAMINITFR_Params_t * pCamera_Init_frontCornerRight )
{
   Std_ReturnType status = C_SIG_INVALID;
   if( pCamera_Init_frontCornerRight != C_NULL_P )
   {
      status = C_SIG_VALID;
      * pCamera_Init_frontCornerRight = EYEQMSG_CAMINITFR_ParamsApp_s;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_Zero_Byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pINIT_Cam_Zero_Byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Zero_Byte
*    INIT_Cam_Zero_Byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Zero_Byte signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_Zero_Byte( uint8 * pINIT_Cam_Zero_Byte )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pINIT_Cam_Zero_Byte != C_NULL_P )
   {
      signal_value = EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_Zero_Byte_b8;
      * pINIT_Cam_Zero_Byte = signal_value;
      if( signal_value <= C_EYEQMSG_CAMINITFR_INIT_CAM_ZERO_BYTE_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pINIT_Cam_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Protocol_Version
*    INIT_Cam_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Protocol_Version signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_Protocol_Version( uint8 * pINIT_Cam_Protocol_Version )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pINIT_Cam_Protocol_Version != C_NULL_P )
   {
      signal_value = EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_Protocol_Version_b8;
      * pINIT_Cam_Protocol_Version = signal_value;
      if( (signal_value >= C_EYEQMSG_CAMINITFR_INIT_CAM_PROTOCOL_VERSION_RMIN ) 
          && (signal_value <= C_EYEQMSG_CAMINITFR_INIT_CAM_PROTOCOL_VERSION_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_Optional_Signals
*
* FUNCTION ARGUMENTS:
*    uint16 * pINIT_Cam_Optional_Signals - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Optional_Signals
*    INIT_Cam_Optional_Signals returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Optional_Signals signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_Optional_Signals( uint16 * pINIT_Cam_Optional_Signals )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pINIT_Cam_Optional_Signals != C_NULL_P )
   {
      signal_value = EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_Optional_Signals_b16;
      * pINIT_Cam_Optional_Signals = signal_value;
      if( (signal_value >= C_EYEQMSG_CAMINITFR_INIT_CAM_OPTIONAL_SIGNALS_RMIN ) 
          && (signal_value <= C_EYEQMSG_CAMINITFR_INIT_CAM_OPTIONAL_SIGNALS_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_Buffer_1_V
*
* FUNCTION ARGUMENTS:
*    boolean * pINIT_Cam_Buffer_1_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Buffer_1_V
*    INIT_Cam_Buffer_1_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Buffer_1_V signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_Buffer_1_V( boolean * pINIT_Cam_Buffer_1_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pINIT_Cam_Buffer_1_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_Buffer_1_V_b1;
      * pINIT_Cam_Buffer_1_V = signal_value;
      if( signal_value <= C_EYEQMSG_CAMINITFR_INIT_CAM_BUFFER_1_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_Buffer_1
*
* FUNCTION ARGUMENTS:
*    uint32 * pINIT_Cam_Buffer_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Buffer_1
*    INIT_Cam_Buffer_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Buffer_1 signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_Buffer_1( uint32 * pINIT_Cam_Buffer_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pINIT_Cam_Buffer_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_Buffer_1_b30;
      * pINIT_Cam_Buffer_1 = signal_value;
      if( signal_value <= C_EYEQMSG_CAMINITFR_INIT_CAM_BUFFER_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_Sensor_ID_P1_V
*
* FUNCTION ARGUMENTS:
*    CAMINITFRINITCamSensorIDP1V * pINIT_Cam_Sensor_ID_P1_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Sensor_ID_P1_V
*    INIT_Cam_Sensor_ID_P1_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Sensor_ID_P1_V signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_Sensor_ID_P1_V( CAMINITFRINITCamSensorIDP1V * pINIT_Cam_Sensor_ID_P1_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CAMINITFRINITCamSensorIDP1V signal_value;
   
   if( pINIT_Cam_Sensor_ID_P1_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_Sensor_ID_P1_V_b1;
      * pINIT_Cam_Sensor_ID_P1_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_Sensor_ID_P1
*
* FUNCTION ARGUMENTS:
*    uint64 * pINIT_Cam_Sensor_ID_P1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Sensor_ID_P1
*    INIT_Cam_Sensor_ID_P1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Sensor_ID_P1 signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_Sensor_ID_P1( uint64 * pINIT_Cam_Sensor_ID_P1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint64 signal_value;
   
   if( pINIT_Cam_Sensor_ID_P1 != C_NULL_P )
   {
      signal_value = (uint64) (EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_Sensor_ID_P1_1_b32|((uint64)EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_Sensor_ID_P1_2_b32<<32));
      * pINIT_Cam_Sensor_ID_P1 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_Buffer_2_V
*
* FUNCTION ARGUMENTS:
*    boolean * pINIT_Cam_Buffer_2_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Buffer_2_V
*    INIT_Cam_Buffer_2_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Buffer_2_V signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_Buffer_2_V( boolean * pINIT_Cam_Buffer_2_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pINIT_Cam_Buffer_2_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_Buffer_2_V_b1;
      * pINIT_Cam_Buffer_2_V = signal_value;
      if( signal_value <= C_EYEQMSG_CAMINITFR_INIT_CAM_BUFFER_2_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_Buffer_2
*
* FUNCTION ARGUMENTS:
*    uint32 * pINIT_Cam_Buffer_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Buffer_2
*    INIT_Cam_Buffer_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Buffer_2 signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_Buffer_2( uint32 * pINIT_Cam_Buffer_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pINIT_Cam_Buffer_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_Buffer_2_b30;
      * pINIT_Cam_Buffer_2 = signal_value;
      if( signal_value <= C_EYEQMSG_CAMINITFR_INIT_CAM_BUFFER_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_Sensor_ID_P2_V
*
* FUNCTION ARGUMENTS:
*    CAMINITFRINITCamSensorIDP2V * pINIT_Cam_Sensor_ID_P2_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Sensor_ID_P2_V
*    INIT_Cam_Sensor_ID_P2_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Sensor_ID_P2_V signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_Sensor_ID_P2_V( CAMINITFRINITCamSensorIDP2V * pINIT_Cam_Sensor_ID_P2_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CAMINITFRINITCamSensorIDP2V signal_value;
   
   if( pINIT_Cam_Sensor_ID_P2_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_Sensor_ID_P2_V_b1;
      * pINIT_Cam_Sensor_ID_P2_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_Sensor_ID_P2
*
* FUNCTION ARGUMENTS:
*    uint64 * pINIT_Cam_Sensor_ID_P2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Sensor_ID_P2
*    INIT_Cam_Sensor_ID_P2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Sensor_ID_P2 signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_Sensor_ID_P2( uint64 * pINIT_Cam_Sensor_ID_P2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint64 signal_value;
   
   if( pINIT_Cam_Sensor_ID_P2 != C_NULL_P )
   {
      signal_value = (uint64) (EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_Sensor_ID_P2_1_b32|((uint64)EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_Sensor_ID_P2_2_b32<<32));
      * pINIT_Cam_Sensor_ID_P2 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_Buffer_3_V
*
* FUNCTION ARGUMENTS:
*    boolean * pINIT_Cam_Buffer_3_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Buffer_3_V
*    INIT_Cam_Buffer_3_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Buffer_3_V signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_Buffer_3_V( boolean * pINIT_Cam_Buffer_3_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pINIT_Cam_Buffer_3_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_Buffer_3_V_b1;
      * pINIT_Cam_Buffer_3_V = signal_value;
      if( signal_value <= C_EYEQMSG_CAMINITFR_INIT_CAM_BUFFER_3_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_Buffer_3
*
* FUNCTION ARGUMENTS:
*    uint32 * pINIT_Cam_Buffer_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Buffer_3
*    INIT_Cam_Buffer_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Buffer_3 signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_Buffer_3( uint32 * pINIT_Cam_Buffer_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pINIT_Cam_Buffer_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_Buffer_3_b30;
      * pINIT_Cam_Buffer_3 = signal_value;
      if( signal_value <= C_EYEQMSG_CAMINITFR_INIT_CAM_BUFFER_3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_Sensor_ID_P3_V
*
* FUNCTION ARGUMENTS:
*    CAMINITFRINITCamSensorIDP3V * pINIT_Cam_Sensor_ID_P3_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Sensor_ID_P3_V
*    INIT_Cam_Sensor_ID_P3_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Sensor_ID_P3_V signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_Sensor_ID_P3_V( CAMINITFRINITCamSensorIDP3V * pINIT_Cam_Sensor_ID_P3_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CAMINITFRINITCamSensorIDP3V signal_value;
   
   if( pINIT_Cam_Sensor_ID_P3_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_Sensor_ID_P3_V_b1;
      * pINIT_Cam_Sensor_ID_P3_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_Sensor_ID_P3
*
* FUNCTION ARGUMENTS:
*    uint64 * pINIT_Cam_Sensor_ID_P3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Sensor_ID_P3
*    INIT_Cam_Sensor_ID_P3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Sensor_ID_P3 signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_Sensor_ID_P3( uint64 * pINIT_Cam_Sensor_ID_P3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint64 signal_value;
   
   if( pINIT_Cam_Sensor_ID_P3 != C_NULL_P )
   {
      signal_value = (uint64) (EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_Sensor_ID_P3_1_b32|((uint64)EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_Sensor_ID_P3_2_b32<<32));
      * pINIT_Cam_Sensor_ID_P3 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_Buffer_4_V
*
* FUNCTION ARGUMENTS:
*    boolean * pINIT_Cam_Buffer_4_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Buffer_4_V
*    INIT_Cam_Buffer_4_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Buffer_4_V signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_Buffer_4_V( boolean * pINIT_Cam_Buffer_4_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pINIT_Cam_Buffer_4_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_Buffer_4_V_b1;
      * pINIT_Cam_Buffer_4_V = signal_value;
      if( signal_value <= C_EYEQMSG_CAMINITFR_INIT_CAM_BUFFER_4_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_Buffer_4
*
* FUNCTION ARGUMENTS:
*    uint32 * pINIT_Cam_Buffer_4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Buffer_4
*    INIT_Cam_Buffer_4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Buffer_4 signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_Buffer_4( uint32 * pINIT_Cam_Buffer_4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pINIT_Cam_Buffer_4 != C_NULL_P )
   {
      signal_value = EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_Buffer_4_b30;
      * pINIT_Cam_Buffer_4 = signal_value;
      if( signal_value <= C_EYEQMSG_CAMINITFR_INIT_CAM_BUFFER_4_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_Sensor_ID_P4_V
*
* FUNCTION ARGUMENTS:
*    CAMINITFRINITCamSensorIDP4V * pINIT_Cam_Sensor_ID_P4_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Sensor_ID_P4_V
*    INIT_Cam_Sensor_ID_P4_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Sensor_ID_P4_V signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_Sensor_ID_P4_V( CAMINITFRINITCamSensorIDP4V * pINIT_Cam_Sensor_ID_P4_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CAMINITFRINITCamSensorIDP4V signal_value;
   
   if( pINIT_Cam_Sensor_ID_P4_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_Sensor_ID_P4_V_b1;
      * pINIT_Cam_Sensor_ID_P4_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_Sensor_ID_P4
*
* FUNCTION ARGUMENTS:
*    uint64 * pINIT_Cam_Sensor_ID_P4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Sensor_ID_P4
*    INIT_Cam_Sensor_ID_P4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Sensor_ID_P4 signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_Sensor_ID_P4( uint64 * pINIT_Cam_Sensor_ID_P4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint64 signal_value;
   
   if( pINIT_Cam_Sensor_ID_P4 != C_NULL_P )
   {
      signal_value = (uint64) (EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_Sensor_ID_P4_1_b32|((uint64)EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_Sensor_ID_P4_2_b32<<32));
      * pINIT_Cam_Sensor_ID_P4 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_Buffer_5_V
*
* FUNCTION ARGUMENTS:
*    boolean * pINIT_Cam_Buffer_5_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Buffer_5_V
*    INIT_Cam_Buffer_5_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Buffer_5_V signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_Buffer_5_V( boolean * pINIT_Cam_Buffer_5_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pINIT_Cam_Buffer_5_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_Buffer_5_V_b1;
      * pINIT_Cam_Buffer_5_V = signal_value;
      if( signal_value <= C_EYEQMSG_CAMINITFR_INIT_CAM_BUFFER_5_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_Buffer_5
*
* FUNCTION ARGUMENTS:
*    uint32 * pINIT_Cam_Buffer_5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Buffer_5
*    INIT_Cam_Buffer_5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Buffer_5 signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_Buffer_5( uint32 * pINIT_Cam_Buffer_5 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pINIT_Cam_Buffer_5 != C_NULL_P )
   {
      signal_value = EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_Buffer_5_b30;
      * pINIT_Cam_Buffer_5 = signal_value;
      if( signal_value <= C_EYEQMSG_CAMINITFR_INIT_CAM_BUFFER_5_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_Sensor_ID_P5_V
*
* FUNCTION ARGUMENTS:
*    CAMINITFRINITCamSensorIDP5V * pINIT_Cam_Sensor_ID_P5_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Sensor_ID_P5_V
*    INIT_Cam_Sensor_ID_P5_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Sensor_ID_P5_V signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_Sensor_ID_P5_V( CAMINITFRINITCamSensorIDP5V * pINIT_Cam_Sensor_ID_P5_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CAMINITFRINITCamSensorIDP5V signal_value;
   
   if( pINIT_Cam_Sensor_ID_P5_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_Sensor_ID_P5_V_b1;
      * pINIT_Cam_Sensor_ID_P5_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_Sensor_ID_P5
*
* FUNCTION ARGUMENTS:
*    uint64 * pINIT_Cam_Sensor_ID_P5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Sensor_ID_P5
*    INIT_Cam_Sensor_ID_P5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Sensor_ID_P5 signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_Sensor_ID_P5( uint64 * pINIT_Cam_Sensor_ID_P5 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint64 signal_value;
   
   if( pINIT_Cam_Sensor_ID_P5 != C_NULL_P )
   {
      signal_value = (uint64) (EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_Sensor_ID_P5_1_b32|((uint64)EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_Sensor_ID_P5_2_b32<<32));
      * pINIT_Cam_Sensor_ID_P5 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_Buffer_6_V
*
* FUNCTION ARGUMENTS:
*    boolean * pINIT_Cam_Buffer_6_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Buffer_6_V
*    INIT_Cam_Buffer_6_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Buffer_6_V signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_Buffer_6_V( boolean * pINIT_Cam_Buffer_6_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pINIT_Cam_Buffer_6_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_Buffer_6_V_b1;
      * pINIT_Cam_Buffer_6_V = signal_value;
      if( signal_value <= C_EYEQMSG_CAMINITFR_INIT_CAM_BUFFER_6_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_Buffer_6
*
* FUNCTION ARGUMENTS:
*    uint32 * pINIT_Cam_Buffer_6 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Buffer_6
*    INIT_Cam_Buffer_6 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Buffer_6 signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_Buffer_6( uint32 * pINIT_Cam_Buffer_6 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pINIT_Cam_Buffer_6 != C_NULL_P )
   {
      signal_value = EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_Buffer_6_b30;
      * pINIT_Cam_Buffer_6 = signal_value;
      if( signal_value <= C_EYEQMSG_CAMINITFR_INIT_CAM_BUFFER_6_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_Sensor_ID_P6_V
*
* FUNCTION ARGUMENTS:
*    CAMINITFRINITCamSensorIDP6V * pINIT_Cam_Sensor_ID_P6_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Sensor_ID_P6_V
*    INIT_Cam_Sensor_ID_P6_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Sensor_ID_P6_V signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_Sensor_ID_P6_V( CAMINITFRINITCamSensorIDP6V * pINIT_Cam_Sensor_ID_P6_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CAMINITFRINITCamSensorIDP6V signal_value;
   
   if( pINIT_Cam_Sensor_ID_P6_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_Sensor_ID_P6_V_b1;
      * pINIT_Cam_Sensor_ID_P6_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_Sensor_ID_P6
*
* FUNCTION ARGUMENTS:
*    uint64 * pINIT_Cam_Sensor_ID_P6 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Sensor_ID_P6
*    INIT_Cam_Sensor_ID_P6 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Sensor_ID_P6 signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_Sensor_ID_P6( uint64 * pINIT_Cam_Sensor_ID_P6 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint64 signal_value;
   
   if( pINIT_Cam_Sensor_ID_P6 != C_NULL_P )
   {
      signal_value = (uint64) (EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_Sensor_ID_P6_1_b32|((uint64)EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_Sensor_ID_P6_2_b32<<32));
      * pINIT_Cam_Sensor_ID_P6 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_Buffer_7_V
*
* FUNCTION ARGUMENTS:
*    boolean * pINIT_Cam_Buffer_7_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Buffer_7_V
*    INIT_Cam_Buffer_7_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Buffer_7_V signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_Buffer_7_V( boolean * pINIT_Cam_Buffer_7_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pINIT_Cam_Buffer_7_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_Buffer_7_V_b1;
      * pINIT_Cam_Buffer_7_V = signal_value;
      if( signal_value <= C_EYEQMSG_CAMINITFR_INIT_CAM_BUFFER_7_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_Buffer_7
*
* FUNCTION ARGUMENTS:
*    uint32 * pINIT_Cam_Buffer_7 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Buffer_7
*    INIT_Cam_Buffer_7 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Buffer_7 signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_Buffer_7( uint32 * pINIT_Cam_Buffer_7 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pINIT_Cam_Buffer_7 != C_NULL_P )
   {
      signal_value = EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_Buffer_7_b30;
      * pINIT_Cam_Buffer_7 = signal_value;
      if( signal_value <= C_EYEQMSG_CAMINITFR_INIT_CAM_BUFFER_7_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_Sensor_ID_P7_V
*
* FUNCTION ARGUMENTS:
*    CAMINITFRINITCamSensorIDP7V * pINIT_Cam_Sensor_ID_P7_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Sensor_ID_P7_V
*    INIT_Cam_Sensor_ID_P7_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Sensor_ID_P7_V signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_Sensor_ID_P7_V( CAMINITFRINITCamSensorIDP7V * pINIT_Cam_Sensor_ID_P7_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CAMINITFRINITCamSensorIDP7V signal_value;
   
   if( pINIT_Cam_Sensor_ID_P7_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_Sensor_ID_P7_V_b1;
      * pINIT_Cam_Sensor_ID_P7_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_Sensor_ID_P7
*
* FUNCTION ARGUMENTS:
*    uint64 * pINIT_Cam_Sensor_ID_P7 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Sensor_ID_P7
*    INIT_Cam_Sensor_ID_P7 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Sensor_ID_P7 signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_Sensor_ID_P7( uint64 * pINIT_Cam_Sensor_ID_P7 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint64 signal_value;
   
   if( pINIT_Cam_Sensor_ID_P7 != C_NULL_P )
   {
      signal_value = (uint64) (EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_Sensor_ID_P7_1_b32|((uint64)EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_Sensor_ID_P7_2_b32<<32));
      * pINIT_Cam_Sensor_ID_P7 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_Buffer_8_V
*
* FUNCTION ARGUMENTS:
*    boolean * pINIT_Cam_Buffer_8_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Buffer_8_V
*    INIT_Cam_Buffer_8_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Buffer_8_V signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_Buffer_8_V( boolean * pINIT_Cam_Buffer_8_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pINIT_Cam_Buffer_8_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_Buffer_8_V_b1;
      * pINIT_Cam_Buffer_8_V = signal_value;
      if( signal_value <= C_EYEQMSG_CAMINITFR_INIT_CAM_BUFFER_8_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_Buffer_8
*
* FUNCTION ARGUMENTS:
*    uint32 * pINIT_Cam_Buffer_8 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Buffer_8
*    INIT_Cam_Buffer_8 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Buffer_8 signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_Buffer_8( uint32 * pINIT_Cam_Buffer_8 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pINIT_Cam_Buffer_8 != C_NULL_P )
   {
      signal_value = EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_Buffer_8_b30;
      * pINIT_Cam_Buffer_8 = signal_value;
      if( signal_value <= C_EYEQMSG_CAMINITFR_INIT_CAM_BUFFER_8_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_Sensor_ID_P8_V
*
* FUNCTION ARGUMENTS:
*    CAMINITFRINITCamSensorIDP8V * pINIT_Cam_Sensor_ID_P8_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Sensor_ID_P8_V
*    INIT_Cam_Sensor_ID_P8_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Sensor_ID_P8_V signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_Sensor_ID_P8_V( CAMINITFRINITCamSensorIDP8V * pINIT_Cam_Sensor_ID_P8_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CAMINITFRINITCamSensorIDP8V signal_value;
   
   if( pINIT_Cam_Sensor_ID_P8_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_Sensor_ID_P8_V_b1;
      * pINIT_Cam_Sensor_ID_P8_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_Sensor_ID_P8
*
* FUNCTION ARGUMENTS:
*    uint64 * pINIT_Cam_Sensor_ID_P8 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Sensor_ID_P8
*    INIT_Cam_Sensor_ID_P8 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Sensor_ID_P8 signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_Sensor_ID_P8( uint64 * pINIT_Cam_Sensor_ID_P8 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint64 signal_value;
   
   if( pINIT_Cam_Sensor_ID_P8 != C_NULL_P )
   {
      signal_value = (uint64) (EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_Sensor_ID_P8_1_b32|((uint64)EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_Sensor_ID_P8_2_b32<<32));
      * pINIT_Cam_Sensor_ID_P8 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_Buffer_9_V
*
* FUNCTION ARGUMENTS:
*    boolean * pINIT_Cam_Buffer_9_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Buffer_9_V
*    INIT_Cam_Buffer_9_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Buffer_9_V signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_Buffer_9_V( boolean * pINIT_Cam_Buffer_9_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pINIT_Cam_Buffer_9_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_Buffer_9_V_b1;
      * pINIT_Cam_Buffer_9_V = signal_value;
      if( signal_value <= C_EYEQMSG_CAMINITFR_INIT_CAM_BUFFER_9_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_Buffer_9
*
* FUNCTION ARGUMENTS:
*    uint32 * pINIT_Cam_Buffer_9 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Buffer_9
*    INIT_Cam_Buffer_9 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Buffer_9 signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_Buffer_9( uint32 * pINIT_Cam_Buffer_9 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pINIT_Cam_Buffer_9 != C_NULL_P )
   {
      signal_value = EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_Buffer_9_b30;
      * pINIT_Cam_Buffer_9 = signal_value;
      if( signal_value <= C_EYEQMSG_CAMINITFR_INIT_CAM_BUFFER_9_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_EPROM_CRC_V
*
* FUNCTION ARGUMENTS:
*    CAMINITFRINITCamEPROMCRCV * pINIT_Cam_EPROM_CRC_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_EPROM_CRC_V
*    INIT_Cam_EPROM_CRC_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_EPROM_CRC_V signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_EPROM_CRC_V( CAMINITFRINITCamEPROMCRCV * pINIT_Cam_EPROM_CRC_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CAMINITFRINITCamEPROMCRCV signal_value;
   
   if( pINIT_Cam_EPROM_CRC_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_EPROM_CRC_V_b1;
      * pINIT_Cam_EPROM_CRC_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_EPROM_CRC
*
* FUNCTION ARGUMENTS:
*    uint32 * pINIT_Cam_EPROM_CRC - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_EPROM_CRC
*    INIT_Cam_EPROM_CRC returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_EPROM_CRC signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_EPROM_CRC( uint32 * pINIT_Cam_EPROM_CRC )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pINIT_Cam_EPROM_CRC != C_NULL_P )
   {
      signal_value = EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_EPROM_CRC_b32;
      * pINIT_Cam_EPROM_CRC = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_Type
*
* FUNCTION ARGUMENTS:
*    CAMINITFRINITCamType * pINIT_Cam_Type - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Type
*    INIT_Cam_Type returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Type signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_Type( CAMINITFRINITCamType * pINIT_Cam_Type )
{
   Std_ReturnType status = C_SIG_INVALID;
   CAMINITFRINITCamType signal_value;
   
   if( pINIT_Cam_Type != C_NULL_P )
   {
      signal_value = EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_Type_b8;
      * pINIT_Cam_Type = signal_value;
      if( signal_value <= C_EYEQMSG_CAMINITFR_INIT_CAM_TYPE_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_distortionModelType
*
* FUNCTION ARGUMENTS:
*    uint8 * pINIT_Cam_distortionModelType - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_distortionModelType
*    INIT_Cam_distortionModelType returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_distortionModelType signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_distortionModelType( uint8 * pINIT_Cam_distortionModelType )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pINIT_Cam_distortionModelType != C_NULL_P )
   {
      signal_value = EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_distortionModelType_b3;
      * pINIT_Cam_distortionModelType = signal_value;
      if( signal_value <= C_EYEQMSG_CAMINITFR_INIT_CAM_DISTORTIONMODELTYPE_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_Reserved_1
*
* FUNCTION ARGUMENTS:
*    uint32 * pReserved_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1
*    Reserved_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1 signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_Reserved_1( uint32 * pReserved_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pReserved_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_CAMINITFR_ParamsApp_s.Reserved_1_b21;
      * pReserved_1 = signal_value;
      if( signal_value <= C_EYEQMSG_CAMINITFR_RESERVED_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_CODX
*
* FUNCTION ARGUMENTS:
*    float64 * pINIT_Cam_CODX - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_CODX
*    INIT_Cam_CODX returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_CODX signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_CODX( float64 * pINIT_Cam_CODX )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float64SigDataType signal_value;
   
   if( pINIT_Cam_CODX != C_NULL_P )
   {
      signal_value.u = (uint64) (EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_CODX_1_sb32|((uint64)EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_CODX_2_sb32<<32));
      * pINIT_Cam_CODX = signal_value.f;
      if( (signal_value.f >= C_EYEQMSG_CAMINITFR_INIT_CAM_CODX_RMIN ) 
          && (signal_value.f <= C_EYEQMSG_CAMINITFR_INIT_CAM_CODX_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_CODY
*
* FUNCTION ARGUMENTS:
*    float64 * pINIT_Cam_CODY - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_CODY
*    INIT_Cam_CODY returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_CODY signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_CODY( float64 * pINIT_Cam_CODY )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float64SigDataType signal_value;
   
   if( pINIT_Cam_CODY != C_NULL_P )
   {
      signal_value.u = (uint64) (EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_CODY_1_sb32|((uint64)EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_CODY_2_sb32<<32));
      * pINIT_Cam_CODY = signal_value.f;
      if( (signal_value.f >= C_EYEQMSG_CAMINITFR_INIT_CAM_CODY_RMIN ) 
          && (signal_value.f <= C_EYEQMSG_CAMINITFR_INIT_CAM_CODY_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_distorParams0
*
* FUNCTION ARGUMENTS:
*    float64 * pINIT_Cam_distorParams0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_distorParams0
*    INIT_Cam_distorParams0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_distorParams0 signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_distorParams0( float64 * pINIT_Cam_distorParams0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float64SigDataType signal_value;
   
   if( pINIT_Cam_distorParams0 != C_NULL_P )
   {
      signal_value.u = (uint64) (EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_distorParams0_1_sb32|((uint64)EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_distorParams0_2_sb32<<32));
      * pINIT_Cam_distorParams0 = signal_value.f;
      if( (signal_value.f >= C_EYEQMSG_CAMINITFR_INIT_CAM_DISTORPARAMS0_RMIN ) 
          && (signal_value.f <= C_EYEQMSG_CAMINITFR_INIT_CAM_DISTORPARAMS0_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_distorParams1
*
* FUNCTION ARGUMENTS:
*    float64 * pINIT_Cam_distorParams1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_distorParams1
*    INIT_Cam_distorParams1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_distorParams1 signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_distorParams1( float64 * pINIT_Cam_distorParams1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float64SigDataType signal_value;
   
   if( pINIT_Cam_distorParams1 != C_NULL_P )
   {
      signal_value.u = (uint64) (EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_distorParams1_1_sb32|((uint64)EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_distorParams1_2_sb32<<32));
      * pINIT_Cam_distorParams1 = signal_value.f;
      if( (signal_value.f >= C_EYEQMSG_CAMINITFR_INIT_CAM_DISTORPARAMS1_RMIN ) 
          && (signal_value.f <= C_EYEQMSG_CAMINITFR_INIT_CAM_DISTORPARAMS1_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_distorParams2
*
* FUNCTION ARGUMENTS:
*    float64 * pINIT_Cam_distorParams2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_distorParams2
*    INIT_Cam_distorParams2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_distorParams2 signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_distorParams2( float64 * pINIT_Cam_distorParams2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float64SigDataType signal_value;
   
   if( pINIT_Cam_distorParams2 != C_NULL_P )
   {
      signal_value.u = (uint64) (EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_distorParams2_1_sb32|((uint64)EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_distorParams2_2_sb32<<32));
      * pINIT_Cam_distorParams2 = signal_value.f;
      if( (signal_value.f >= C_EYEQMSG_CAMINITFR_INIT_CAM_DISTORPARAMS2_RMIN ) 
          && (signal_value.f <= C_EYEQMSG_CAMINITFR_INIT_CAM_DISTORPARAMS2_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_distorParams3
*
* FUNCTION ARGUMENTS:
*    float64 * pINIT_Cam_distorParams3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_distorParams3
*    INIT_Cam_distorParams3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_distorParams3 signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_distorParams3( float64 * pINIT_Cam_distorParams3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float64SigDataType signal_value;
   
   if( pINIT_Cam_distorParams3 != C_NULL_P )
   {
      signal_value.u = (uint64) (EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_distorParams3_1_sb32|((uint64)EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_distorParams3_2_sb32<<32));
      * pINIT_Cam_distorParams3 = signal_value.f;
      if( (signal_value.f >= C_EYEQMSG_CAMINITFR_INIT_CAM_DISTORPARAMS3_RMIN ) 
          && (signal_value.f <= C_EYEQMSG_CAMINITFR_INIT_CAM_DISTORPARAMS3_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_distorParams4
*
* FUNCTION ARGUMENTS:
*    float64 * pINIT_Cam_distorParams4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_distorParams4
*    INIT_Cam_distorParams4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_distorParams4 signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_distorParams4( float64 * pINIT_Cam_distorParams4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float64SigDataType signal_value;
   
   if( pINIT_Cam_distorParams4 != C_NULL_P )
   {
      signal_value.u = (uint64) (EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_distorParams4_1_sb32|((uint64)EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_distorParams4_2_sb32<<32));
      * pINIT_Cam_distorParams4 = signal_value.f;
      if( (signal_value.f >= C_EYEQMSG_CAMINITFR_INIT_CAM_DISTORPARAMS4_RMIN ) 
          && (signal_value.f <= C_EYEQMSG_CAMINITFR_INIT_CAM_DISTORPARAMS4_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_distorParams5
*
* FUNCTION ARGUMENTS:
*    float64 * pINIT_Cam_distorParams5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_distorParams5
*    INIT_Cam_distorParams5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_distorParams5 signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_distorParams5( float64 * pINIT_Cam_distorParams5 )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float64SigDataType signal_value;
   
   if( pINIT_Cam_distorParams5 != C_NULL_P )
   {
      signal_value.u = (uint64) (EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_distorParams5_1_sb32|((uint64)EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_distorParams5_2_sb32<<32));
      * pINIT_Cam_distorParams5 = signal_value.f;
      if( (signal_value.f >= C_EYEQMSG_CAMINITFR_INIT_CAM_DISTORPARAMS5_RMIN ) 
          && (signal_value.f <= C_EYEQMSG_CAMINITFR_INIT_CAM_DISTORPARAMS5_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_distorParams6
*
* FUNCTION ARGUMENTS:
*    float64 * pINIT_Cam_distorParams6 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_distorParams6
*    INIT_Cam_distorParams6 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_distorParams6 signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_distorParams6( float64 * pINIT_Cam_distorParams6 )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float64SigDataType signal_value;
   
   if( pINIT_Cam_distorParams6 != C_NULL_P )
   {
      signal_value.u = (uint64) (EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_distorParams6_1_sb32|((uint64)EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_distorParams6_2_sb32<<32));
      * pINIT_Cam_distorParams6 = signal_value.f;
      if( (signal_value.f >= C_EYEQMSG_CAMINITFR_INIT_CAM_DISTORPARAMS6_RMIN ) 
          && (signal_value.f <= C_EYEQMSG_CAMINITFR_INIT_CAM_DISTORPARAMS6_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_distorParams7
*
* FUNCTION ARGUMENTS:
*    float64 * pINIT_Cam_distorParams7 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_distorParams7
*    INIT_Cam_distorParams7 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_distorParams7 signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_distorParams7( float64 * pINIT_Cam_distorParams7 )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float64SigDataType signal_value;
   
   if( pINIT_Cam_distorParams7 != C_NULL_P )
   {
      signal_value.u = (uint64) (EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_distorParams7_1_sb32|((uint64)EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_distorParams7_2_sb32<<32));
      * pINIT_Cam_distorParams7 = signal_value.f;
      if( (signal_value.f >= C_EYEQMSG_CAMINITFR_INIT_CAM_DISTORPARAMS7_RMIN ) 
          && (signal_value.f <= C_EYEQMSG_CAMINITFR_INIT_CAM_DISTORPARAMS7_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_distorParams8
*
* FUNCTION ARGUMENTS:
*    float64 * pINIT_Cam_distorParams8 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_distorParams8
*    INIT_Cam_distorParams8 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_distorParams8 signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_distorParams8( float64 * pINIT_Cam_distorParams8 )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float64SigDataType signal_value;
   
   if( pINIT_Cam_distorParams8 != C_NULL_P )
   {
      signal_value.u = (uint64) (EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_distorParams8_1_sb32|((uint64)EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_distorParams8_2_sb32<<32));
      * pINIT_Cam_distorParams8 = signal_value.f;
      if( (signal_value.f >= C_EYEQMSG_CAMINITFR_INIT_CAM_DISTORPARAMS8_RMIN ) 
          && (signal_value.f <= C_EYEQMSG_CAMINITFR_INIT_CAM_DISTORPARAMS8_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_distorParams9
*
* FUNCTION ARGUMENTS:
*    float64 * pINIT_Cam_distorParams9 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_distorParams9
*    INIT_Cam_distorParams9 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_distorParams9 signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_distorParams9( float64 * pINIT_Cam_distorParams9 )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float64SigDataType signal_value;
   
   if( pINIT_Cam_distorParams9 != C_NULL_P )
   {
      signal_value.u = (uint64) (EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_distorParams9_1_sb32|((uint64)EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_distorParams9_2_sb32<<32));
      * pINIT_Cam_distorParams9 = signal_value.f;
      if( (signal_value.f >= C_EYEQMSG_CAMINITFR_INIT_CAM_DISTORPARAMS9_RMIN ) 
          && (signal_value.f <= C_EYEQMSG_CAMINITFR_INIT_CAM_DISTORPARAMS9_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_distorParams10
*
* FUNCTION ARGUMENTS:
*    float64 * pINIT_Cam_distorParams10 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_distorParams10
*    INIT_Cam_distorParams10 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_distorParams10 signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_distorParams10( float64 * pINIT_Cam_distorParams10 )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float64SigDataType signal_value;
   
   if( pINIT_Cam_distorParams10 != C_NULL_P )
   {
      signal_value.u = (uint64) (EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_distorParams10_1_sb32|((uint64)EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_distorParams10_2_sb32<<32));
      * pINIT_Cam_distorParams10 = signal_value.f;
      if( (signal_value.f >= C_EYEQMSG_CAMINITFR_INIT_CAM_DISTORPARAMS10_RMIN ) 
          && (signal_value.f <= C_EYEQMSG_CAMINITFR_INIT_CAM_DISTORPARAMS10_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_distorParams11
*
* FUNCTION ARGUMENTS:
*    float64 * pINIT_Cam_distorParams11 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_distorParams11
*    INIT_Cam_distorParams11 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_distorParams11 signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_distorParams11( float64 * pINIT_Cam_distorParams11 )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float64SigDataType signal_value;
   
   if( pINIT_Cam_distorParams11 != C_NULL_P )
   {
      signal_value.u = (uint64) (EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_distorParams11_1_sb32|((uint64)EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_distorParams11_2_sb32<<32));
      * pINIT_Cam_distorParams11 = signal_value.f;
      if( (signal_value.f >= C_EYEQMSG_CAMINITFR_INIT_CAM_DISTORPARAMS11_RMIN ) 
          && (signal_value.f <= C_EYEQMSG_CAMINITFR_INIT_CAM_DISTORPARAMS11_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_distorParams12
*
* FUNCTION ARGUMENTS:
*    float64 * pINIT_Cam_distorParams12 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_distorParams12
*    INIT_Cam_distorParams12 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_distorParams12 signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_distorParams12( float64 * pINIT_Cam_distorParams12 )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float64SigDataType signal_value;
   
   if( pINIT_Cam_distorParams12 != C_NULL_P )
   {
      signal_value.u = (uint64) (EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_distorParams12_1_sb32|((uint64)EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_distorParams12_2_sb32<<32));
      * pINIT_Cam_distorParams12 = signal_value.f;
      if( (signal_value.f >= C_EYEQMSG_CAMINITFR_INIT_CAM_DISTORPARAMS12_RMIN ) 
          && (signal_value.f <= C_EYEQMSG_CAMINITFR_INIT_CAM_DISTORPARAMS12_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_distorParams13
*
* FUNCTION ARGUMENTS:
*    float64 * pINIT_Cam_distorParams13 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_distorParams13
*    INIT_Cam_distorParams13 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_distorParams13 signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_distorParams13( float64 * pINIT_Cam_distorParams13 )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float64SigDataType signal_value;
   
   if( pINIT_Cam_distorParams13 != C_NULL_P )
   {
      signal_value.u = (uint64) (EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_distorParams13_1_sb32|((uint64)EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_distorParams13_2_sb32<<32));
      * pINIT_Cam_distorParams13 = signal_value.f;
      if( (signal_value.f >= C_EYEQMSG_CAMINITFR_INIT_CAM_DISTORPARAMS13_RMIN ) 
          && (signal_value.f <= C_EYEQMSG_CAMINITFR_INIT_CAM_DISTORPARAMS13_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_distorParams14
*
* FUNCTION ARGUMENTS:
*    float64 * pINIT_Cam_distorParams14 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_distorParams14
*    INIT_Cam_distorParams14 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_distorParams14 signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_distorParams14( float64 * pINIT_Cam_distorParams14 )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float64SigDataType signal_value;
   
   if( pINIT_Cam_distorParams14 != C_NULL_P )
   {
      signal_value.u = (uint64) (EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_distorParams14_1_sb32|((uint64)EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_distorParams14_2_sb32<<32));
      * pINIT_Cam_distorParams14 = signal_value.f;
      if( (signal_value.f >= C_EYEQMSG_CAMINITFR_INIT_CAM_DISTORPARAMS14_RMIN ) 
          && (signal_value.f <= C_EYEQMSG_CAMINITFR_INIT_CAM_DISTORPARAMS14_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_distorParams15
*
* FUNCTION ARGUMENTS:
*    float64 * pINIT_Cam_distorParams15 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_distorParams15
*    INIT_Cam_distorParams15 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_distorParams15 signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_distorParams15( float64 * pINIT_Cam_distorParams15 )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float64SigDataType signal_value;
   
   if( pINIT_Cam_distorParams15 != C_NULL_P )
   {
      signal_value.u = (uint64) (EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_distorParams15_1_sb32|((uint64)EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_distorParams15_2_sb32<<32));
      * pINIT_Cam_distorParams15 = signal_value.f;
      if( (signal_value.f >= C_EYEQMSG_CAMINITFR_INIT_CAM_DISTORPARAMS15_RMIN ) 
          && (signal_value.f <= C_EYEQMSG_CAMINITFR_INIT_CAM_DISTORPARAMS15_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_FocalLengthX
*
* FUNCTION ARGUMENTS:
*    float64 * pINIT_Cam_FocalLengthX - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_FocalLengthX
*    INIT_Cam_FocalLengthX returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_FocalLengthX signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_FocalLengthX( float64 * pINIT_Cam_FocalLengthX )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float64SigDataType signal_value;
   
   if( pINIT_Cam_FocalLengthX != C_NULL_P )
   {
      signal_value.u = (uint64) (EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_FocalLengthX_1_sb32|((uint64)EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_FocalLengthX_2_sb32<<32));
      * pINIT_Cam_FocalLengthX = signal_value.f;
      if( (signal_value.f >= C_EYEQMSG_CAMINITFR_INIT_CAM_FOCALLENGTHX_RMIN ) 
          && (signal_value.f <= C_EYEQMSG_CAMINITFR_INIT_CAM_FOCALLENGTHX_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_FocalLengthY
*
* FUNCTION ARGUMENTS:
*    float64 * pINIT_Cam_FocalLengthY - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_FocalLengthY
*    INIT_Cam_FocalLengthY returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_FocalLengthY signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_FocalLengthY( float64 * pINIT_Cam_FocalLengthY )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float64SigDataType signal_value;
   
   if( pINIT_Cam_FocalLengthY != C_NULL_P )
   {
      signal_value.u = (uint64) (EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_FocalLengthY_1_sb32|((uint64)EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_FocalLengthY_2_sb32<<32));
      * pINIT_Cam_FocalLengthY = signal_value.f;
      if( (signal_value.f >= C_EYEQMSG_CAMINITFR_INIT_CAM_FOCALLENGTHY_RMIN ) 
          && (signal_value.f <= C_EYEQMSG_CAMINITFR_INIT_CAM_FOCALLENGTHY_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_Skew
*
* FUNCTION ARGUMENTS:
*    float64 * pINIT_Cam_Skew - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Skew
*    INIT_Cam_Skew returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Skew signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_Skew( float64 * pINIT_Cam_Skew )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float64SigDataType signal_value;
   
   if( pINIT_Cam_Skew != C_NULL_P )
   {
      signal_value.u = (uint64) (EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_Skew_1_sb32|((uint64)EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_Skew_2_sb32<<32));
      * pINIT_Cam_Skew = signal_value.f;
      if( (signal_value.f >= C_EYEQMSG_CAMINITFR_INIT_CAM_SKEW_RMIN ) 
          && (signal_value.f <= C_EYEQMSG_CAMINITFR_INIT_CAM_SKEW_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_PrincipalPointX
*
* FUNCTION ARGUMENTS:
*    float64 * pINIT_Cam_PrincipalPointX - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_PrincipalPointX
*    INIT_Cam_PrincipalPointX returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_PrincipalPointX signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_PrincipalPointX( float64 * pINIT_Cam_PrincipalPointX )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float64SigDataType signal_value;
   
   if( pINIT_Cam_PrincipalPointX != C_NULL_P )
   {
      signal_value.u = (uint64) (EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_PrincipalPointX_1_sb32|((uint64)EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_PrincipalPointX_2_sb32<<32));
      * pINIT_Cam_PrincipalPointX = signal_value.f;
      if( (signal_value.f >= C_EYEQMSG_CAMINITFR_INIT_CAM_PRINCIPALPOINTX_RMIN ) 
          && (signal_value.f <= C_EYEQMSG_CAMINITFR_INIT_CAM_PRINCIPALPOINTX_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITFR_INIT_Cam_PrincipalPointY
*
* FUNCTION ARGUMENTS:
*    float64 * pINIT_Cam_PrincipalPointY - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_PrincipalPointY
*    INIT_Cam_PrincipalPointY returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_PrincipalPointY signal value of Camera_Init_frontCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITFR_INIT_Cam_PrincipalPointY( float64 * pINIT_Cam_PrincipalPointY )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float64SigDataType signal_value;
   
   if( pINIT_Cam_PrincipalPointY != C_NULL_P )
   {
      signal_value.u = (uint64) (EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_PrincipalPointY_1_sb32|((uint64)EYEQMSG_CAMINITFR_ParamsApp_s.INIT_Cam_PrincipalPointY_2_sb32<<32));
      * pINIT_Cam_PrincipalPointY = signal_value.f;
      if( (signal_value.f >= C_EYEQMSG_CAMINITFR_INIT_CAM_PRINCIPALPOINTY_RMIN ) 
          && (signal_value.f <= C_EYEQMSG_CAMINITFR_INIT_CAM_PRINCIPALPOINTY_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

