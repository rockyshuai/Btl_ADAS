

/*****************************************************************************
                  Include files
*****************************************************************************/
/* The suggested include file order is: */
#include "EyeQ_defs.h"    /* EyeQ project common definitions file    */

#include "EYEQMSG_CoreTrafficSignProcess.h"

/*****************************************************************************
                  Local symbolic constants
*****************************************************************************/
/*****************************************************************************
                  Local types, enums definitions
*****************************************************************************/
/*****************************************************************************
                  Local function prototypes
*****************************************************************************/
/*****************************************************************************
                  Local object definitions
*****************************************************************************/
/*****************************************************************************
                  Exported object definitions
*****************************************************************************/
EYEQMSG_CORETRAFFICSIGN_Params_t   EYEQMSG_CORETRAFFICSIGN_Params_s;
EYEQMSG_CORETRAFFICSIGN_Params_t   EYEQMSG_CORETRAFFICSIGN_ParamsApp_s;
/*****************************************************************************
                  Local function-like macros
*****************************************************************************/
/*****************************************************************************
                  Local defined macros
*****************************************************************************/
/*****************************************************************************
                  Function definitions
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvH_TSR_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pTSR_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Zero_byte
*    TSR_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Zero_byte signal value of Virtual_HEADER_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvH_TSR_Zero_byte( uint8 * pTSR_Zero_byte )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pTSR_Zero_byte != C_NULL_P )
   {
      signal_value = EYEQMSG_CORETRAFFICSIGN_ParamsApp_s.EYEQMSG_CORETRAFFICSIGNvH_Params_s.TSR_Zero_byte_b8;
      * pTSR_Zero_byte = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvH_TSR_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pTSR_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Protocol_Version
*    TSR_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Protocol_Version signal value of Virtual_HEADER_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvH_TSR_Protocol_Version( uint8 * pTSR_Protocol_Version )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pTSR_Protocol_Version != C_NULL_P )
   {
      signal_value = EYEQMSG_CORETRAFFICSIGN_ParamsApp_s.EYEQMSG_CORETRAFFICSIGNvH_Params_s.TSR_Protocol_Version_b8;
      * pTSR_Protocol_Version = signal_value;
      if( (signal_value >= C_EYEQMSG_CORETRAFFICSIGNvH_TSR_PROTOCOL_VERSION_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORETRAFFICSIGNvH_TSR_PROTOCOL_VERSION_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvH_TSR_Sync_ID
*
* FUNCTION ARGUMENTS:
*    uint8 * pTSR_Sync_ID - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Sync_ID
*    TSR_Sync_ID returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Sync_ID signal value of Virtual_HEADER_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvH_TSR_Sync_ID( uint8 * pTSR_Sync_ID )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pTSR_Sync_ID != C_NULL_P )
   {
      signal_value = EYEQMSG_CORETRAFFICSIGN_ParamsApp_s.EYEQMSG_CORETRAFFICSIGNvH_Params_s.TSR_Sync_ID_b8;
      * pTSR_Sync_ID = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvH_TSR_Approved_Sign_Count
*
* FUNCTION ARGUMENTS:
*    uint8 * pTSR_Approved_Sign_Count - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Approved_Sign_Count
*    TSR_Approved_Sign_Count returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Approved_Sign_Count signal value of Virtual_HEADER_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvH_TSR_Approved_Sign_Count( uint8 * pTSR_Approved_Sign_Count )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pTSR_Approved_Sign_Count != C_NULL_P )
   {
      signal_value = EYEQMSG_CORETRAFFICSIGN_ParamsApp_s.EYEQMSG_CORETRAFFICSIGNvH_Params_s.TSR_Approved_Sign_Count_b5;
      * pTSR_Approved_Sign_Count = signal_value;
      if( signal_value <= C_EYEQMSG_CORETRAFFICSIGNvH_TSR_APPROVED_SIGN_COUNT_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvH_TSR_Filtered_Sign_Count
*
* FUNCTION ARGUMENTS:
*    uint8 * pTSR_Filtered_Sign_Count - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Filtered_Sign_Count
*    TSR_Filtered_Sign_Count returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Filtered_Sign_Count signal value of Virtual_HEADER_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvH_TSR_Filtered_Sign_Count( uint8 * pTSR_Filtered_Sign_Count )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pTSR_Filtered_Sign_Count != C_NULL_P )
   {
      signal_value = EYEQMSG_CORETRAFFICSIGN_ParamsApp_s.EYEQMSG_CORETRAFFICSIGNvH_Params_s.TSR_Filtered_Sign_Count_b3;
      * pTSR_Filtered_Sign_Count = signal_value;
      if( signal_value <= C_EYEQMSG_CORETRAFFICSIGNvH_TSR_FILTERED_SIGN_COUNT_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvH_TSR_UnderTracking_Sign_Count
*
* FUNCTION ARGUMENTS:
*    uint8 * pTSR_UnderTracking_Sign_Count - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_UnderTracking_Sign_Count
*    TSR_UnderTracking_Sign_Count returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_UnderTracking_Sign_Count signal value of Virtual_HEADER_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvH_TSR_UnderTracking_Sign_Count( uint8 * pTSR_UnderTracking_Sign_Count )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pTSR_UnderTracking_Sign_Count != C_NULL_P )
   {
      signal_value = EYEQMSG_CORETRAFFICSIGN_ParamsApp_s.EYEQMSG_CORETRAFFICSIGNvH_Params_s.TSR_UnderTracking_Sign_Count_b5;
      * pTSR_UnderTracking_Sign_Count = signal_value;
      if( signal_value <= C_EYEQMSG_CORETRAFFICSIGNvH_TSR_UNDERTRACKING_SIGN_COUNT_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvH_Reserved_1
*
* FUNCTION ARGUMENTS:
*    uint32 * pReserved_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1
*    Reserved_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1 signal value of Virtual_HEADER_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvH_Reserved_1( uint32 * pReserved_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pReserved_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORETRAFFICSIGN_ParamsApp_s.EYEQMSG_CORETRAFFICSIGNvH_Params_s.Reserved_1_b27;
      * pReserved_1 = signal_value;
      if( signal_value <= C_EYEQMSG_CORETRAFFICSIGNvH_RESERVED_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_ID_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pTSR_ID_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_ID_0
*    TSR_ID_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_ID_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_ID_0( uint8 objIndx_u8, uint8 * pTSR_ID_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Traffic_Signs_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORETRAFFICSIGNvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pTSR_ID_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORETRAFFICSIGN_ParamsApp_s.EYEQMSG_CORETRAFFICSIGNvO_Params_as[objIndx_u8].TSR_ID_0_b8;
         * pTSR_ID_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Camera_Source_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORETRAFFICSIGNvOTSRCameraSource0 * pTSR_Camera_Source_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Camera_Source_0
*    TSR_Camera_Source_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Camera_Source_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Camera_Source_0( uint8 objIndx_u8, CORETRAFFICSIGNvOTSRCameraSource0 * pTSR_Camera_Source_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORETRAFFICSIGNvOTSRCameraSource0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Traffic_Signs_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORETRAFFICSIGNvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pTSR_Camera_Source_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORETRAFFICSIGN_ParamsApp_s.EYEQMSG_CORETRAFFICSIGNvO_Params_as[objIndx_u8].TSR_Camera_Source_0_b8;
         * pTSR_Camera_Source_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Name_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pTSR_Sign_Name_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Sign_Name_0
*    TSR_Sign_Name_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Sign_Name_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Name_0( uint8 objIndx_u8, uint16 * pTSR_Sign_Name_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Traffic_Signs_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORETRAFFICSIGNvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pTSR_Sign_Name_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORETRAFFICSIGN_ParamsApp_s.EYEQMSG_CORETRAFFICSIGNvO_Params_as[objIndx_u8].TSR_Sign_Name_0_b10;
         * pTSR_Sign_Name_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Relevancy_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORETRAFFICSIGNvOTSRRelevancy0 * pTSR_Relevancy_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Relevancy_0
*    TSR_Relevancy_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Relevancy_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Relevancy_0( uint8 objIndx_u8, CORETRAFFICSIGNvOTSRRelevancy0 * pTSR_Relevancy_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORETRAFFICSIGNvOTSRRelevancy0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Traffic_Signs_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORETRAFFICSIGNvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pTSR_Relevancy_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORETRAFFICSIGN_ParamsApp_s.EYEQMSG_CORETRAFFICSIGNvO_Params_as[objIndx_u8].TSR_Relevancy_0_b5;
         * pTSR_Relevancy_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORETRAFFICSIGNvO_TSR_RELEVANCY_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_Reserved_2_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    boolean * pReserved_2_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_2_0
*    Reserved_2_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_2_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_Reserved_2_0( uint8 objIndx_u8, boolean * pReserved_2_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Traffic_Signs_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORETRAFFICSIGNvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_2_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORETRAFFICSIGN_ParamsApp_s.EYEQMSG_CORETRAFFICSIGNvO_Params_as[objIndx_u8].Reserved_2_0_b1;
         * pReserved_2_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_2_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Filter_Type_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORETRAFFICSIGNvOTSRFilterType0 * pTSR_Filter_Type_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Filter_Type_0
*    TSR_Filter_Type_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Filter_Type_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Filter_Type_0( uint8 objIndx_u8, CORETRAFFICSIGNvOTSRFilterType0 * pTSR_Filter_Type_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORETRAFFICSIGNvOTSRFilterType0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Traffic_Signs_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORETRAFFICSIGNvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pTSR_Filter_Type_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORETRAFFICSIGN_ParamsApp_s.EYEQMSG_CORETRAFFICSIGNvO_Params_as[objIndx_u8].TSR_Filter_Type_0_b4;
         * pTSR_Filter_Type_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORETRAFFICSIGNvO_TSR_FILTER_TYPE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sup1_SignName_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pTSR_Sup1_SignName_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Sup1_SignName_0
*    TSR_Sup1_SignName_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Sup1_SignName_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sup1_SignName_0( uint8 objIndx_u8, uint8 * pTSR_Sup1_SignName_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Traffic_Signs_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORETRAFFICSIGNvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pTSR_Sup1_SignName_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORETRAFFICSIGN_ParamsApp_s.EYEQMSG_CORETRAFFICSIGNvO_Params_as[objIndx_u8].TSR_Sup1_SignName_0_b8;
         * pTSR_Sup1_SignName_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sup1_Confidence_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pTSR_Sup1_Confidence_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Sup1_Confidence_0
*    TSR_Sup1_Confidence_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Sup1_Confidence_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sup1_Confidence_0( uint8 objIndx_u8, uint8 * pTSR_Sup1_Confidence_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Traffic_Signs_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORETRAFFICSIGNvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pTSR_Sup1_Confidence_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORETRAFFICSIGN_ParamsApp_s.EYEQMSG_CORETRAFFICSIGNvO_Params_as[objIndx_u8].TSR_Sup1_Confidence_0_b7;
         * pTSR_Sup1_Confidence_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SUP1_CONFIDENCE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sup1_Position_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORETRAFFICSIGNvOTSRSup1Position0 * pTSR_Sup1_Position_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Sup1_Position_0
*    TSR_Sup1_Position_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Sup1_Position_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sup1_Position_0( uint8 objIndx_u8, CORETRAFFICSIGNvOTSRSup1Position0 * pTSR_Sup1_Position_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORETRAFFICSIGNvOTSRSup1Position0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Traffic_Signs_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORETRAFFICSIGNvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pTSR_Sup1_Position_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORETRAFFICSIGN_ParamsApp_s.EYEQMSG_CORETRAFFICSIGNvO_Params_as[objIndx_u8].TSR_Sup1_Position_0_b3;
         * pTSR_Sup1_Position_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SUP1_POSITION_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sup2_SignName_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pTSR_Sup2_SignName_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Sup2_SignName_0
*    TSR_Sup2_SignName_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Sup2_SignName_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sup2_SignName_0( uint8 objIndx_u8, uint8 * pTSR_Sup2_SignName_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Traffic_Signs_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORETRAFFICSIGNvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pTSR_Sup2_SignName_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORETRAFFICSIGN_ParamsApp_s.EYEQMSG_CORETRAFFICSIGNvO_Params_as[objIndx_u8].TSR_Sup2_SignName_0_b8;
         * pTSR_Sup2_SignName_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_Reserved_3_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_3_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_3_0
*    Reserved_3_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_3_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_Reserved_3_0( uint8 objIndx_u8, uint8 * pReserved_3_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Traffic_Signs_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORETRAFFICSIGNvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_3_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORETRAFFICSIGN_ParamsApp_s.EYEQMSG_CORETRAFFICSIGNvO_Params_as[objIndx_u8].Reserved_3_0_b2;
         * pReserved_3_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_3_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sup2_Confidence_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pTSR_Sup2_Confidence_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Sup2_Confidence_0
*    TSR_Sup2_Confidence_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Sup2_Confidence_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sup2_Confidence_0( uint8 objIndx_u8, uint8 * pTSR_Sup2_Confidence_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Traffic_Signs_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORETRAFFICSIGNvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pTSR_Sup2_Confidence_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORETRAFFICSIGN_ParamsApp_s.EYEQMSG_CORETRAFFICSIGNvO_Params_as[objIndx_u8].TSR_Sup2_Confidence_0_b7;
         * pTSR_Sup2_Confidence_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SUP2_CONFIDENCE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sup2_Position_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORETRAFFICSIGNvOTSRSup2Position0 * pTSR_Sup2_Position_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Sup2_Position_0
*    TSR_Sup2_Position_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Sup2_Position_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sup2_Position_0( uint8 objIndx_u8, CORETRAFFICSIGNvOTSRSup2Position0 * pTSR_Sup2_Position_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORETRAFFICSIGNvOTSRSup2Position0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Traffic_Signs_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORETRAFFICSIGNvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pTSR_Sup2_Position_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORETRAFFICSIGN_ParamsApp_s.EYEQMSG_CORETRAFFICSIGNvO_Params_as[objIndx_u8].TSR_Sup2_Position_0_b3;
         * pTSR_Sup2_Position_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SUP2_POSITION_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Confidence_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pTSR_Confidence_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Confidence_0
*    TSR_Confidence_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Confidence_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Confidence_0( uint8 objIndx_u8, uint8 * pTSR_Confidence_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Traffic_Signs_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORETRAFFICSIGNvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pTSR_Confidence_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORETRAFFICSIGN_ParamsApp_s.EYEQMSG_CORETRAFFICSIGNvO_Params_as[objIndx_u8].TSR_Confidence_0_b7;
         * pTSR_Confidence_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORETRAFFICSIGNvO_TSR_CONFIDENCE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Shape_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORETRAFFICSIGNvOTSRSignShape0 * pTSR_Sign_Shape_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Sign_Shape_0
*    TSR_Sign_Shape_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Sign_Shape_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Shape_0( uint8 objIndx_u8, CORETRAFFICSIGNvOTSRSignShape0 * pTSR_Sign_Shape_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORETRAFFICSIGNvOTSRSignShape0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Traffic_Signs_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORETRAFFICSIGNvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pTSR_Sign_Shape_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORETRAFFICSIGN_ParamsApp_s.EYEQMSG_CORETRAFFICSIGNvO_Params_as[objIndx_u8].TSR_Sign_Shape_0_b4;
         * pTSR_Sign_Shape_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_SHAPE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Structure_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORETRAFFICSIGNvOTSRSignStructure0 * pTSR_Sign_Structure_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Sign_Structure_0
*    TSR_Sign_Structure_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Sign_Structure_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Structure_0( uint8 objIndx_u8, CORETRAFFICSIGNvOTSRSignStructure0 * pTSR_Sign_Structure_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORETRAFFICSIGNvOTSRSignStructure0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Traffic_Signs_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORETRAFFICSIGNvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pTSR_Sign_Structure_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORETRAFFICSIGN_ParamsApp_s.EYEQMSG_CORETRAFFICSIGNvO_Params_as[objIndx_u8].TSR_Sign_Structure_0_b3;
         * pTSR_Sign_Structure_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_STRUCTURE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_Reserved_4_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_4_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_4_0
*    Reserved_4_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_4_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_Reserved_4_0( uint8 objIndx_u8, uint8 * pReserved_4_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Traffic_Signs_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORETRAFFICSIGNvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_4_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORETRAFFICSIGN_ParamsApp_s.EYEQMSG_CORETRAFFICSIGNvO_Params_as[objIndx_u8].Reserved_4_0_b8;
         * pReserved_4_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_4_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Tracking_Age_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pTSR_Tracking_Age_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Tracking_Age_0
*    TSR_Tracking_Age_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Tracking_Age_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Tracking_Age_0( uint8 objIndx_u8, uint16 * pTSR_Tracking_Age_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Traffic_Signs_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORETRAFFICSIGNvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pTSR_Tracking_Age_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORETRAFFICSIGN_ParamsApp_s.EYEQMSG_CORETRAFFICSIGNvO_Params_as[objIndx_u8].TSR_Tracking_Age_0_b10;
         * pTSR_Tracking_Age_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORETRAFFICSIGNvO_TSR_TRACKING_AGE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Long_Distance_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pTSR_Sign_Long_Distance_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Sign_Long_Distance_0
*    TSR_Sign_Long_Distance_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Sign_Long_Distance_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Long_Distance_0( uint8 objIndx_u8, uint16 * pTSR_Sign_Long_Distance_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Traffic_Signs_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORETRAFFICSIGNvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pTSR_Sign_Long_Distance_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORETRAFFICSIGN_ParamsApp_s.EYEQMSG_CORETRAFFICSIGNvO_Params_as[objIndx_u8].TSR_Sign_Long_Distance_0_b15;
         * pTSR_Sign_Long_Distance_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_LONG_DISTANCE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_Reserved_5_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_5_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_5_0
*    Reserved_5_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_5_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_Reserved_5_0( uint8 objIndx_u8, uint8 * pReserved_5_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Traffic_Signs_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORETRAFFICSIGNvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_5_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORETRAFFICSIGN_ParamsApp_s.EYEQMSG_CORETRAFFICSIGNvO_Params_as[objIndx_u8].Reserved_5_0_b7;
         * pReserved_5_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_5_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Long_Distance_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pTSR_Sign_Long_Distance_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Sign_Long_Distance_STD_0
*    TSR_Sign_Long_Distance_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Sign_Long_Distance_STD_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Long_Distance_STD_0( uint8 objIndx_u8, uint16 * pTSR_Sign_Long_Distance_STD_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Traffic_Signs_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORETRAFFICSIGNvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pTSR_Sign_Long_Distance_STD_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORETRAFFICSIGN_ParamsApp_s.EYEQMSG_CORETRAFFICSIGNvO_Params_as[objIndx_u8].TSR_Sign_Long_Distance_STD_0_b15;
         * pTSR_Sign_Long_Distance_STD_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_LONG_DISTANCE_STD_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Lateral_Distance_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pTSR_Sign_Lateral_Distance_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Sign_Lateral_Distance_0
*    TSR_Sign_Lateral_Distance_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Sign_Lateral_Distance_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Lateral_Distance_0( uint8 objIndx_u8, uint16 * pTSR_Sign_Lateral_Distance_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Traffic_Signs_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORETRAFFICSIGNvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pTSR_Sign_Lateral_Distance_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORETRAFFICSIGN_ParamsApp_s.EYEQMSG_CORETRAFFICSIGNvO_Params_as[objIndx_u8].TSR_Sign_Lateral_Distance_0_b13;
         * pTSR_Sign_Lateral_Distance_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_LATERAL_DISTANCE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_Reserved_6_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_6_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_6_0
*    Reserved_6_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_6_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_Reserved_6_0( uint8 objIndx_u8, uint8 * pReserved_6_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Traffic_Signs_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORETRAFFICSIGNvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_6_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORETRAFFICSIGN_ParamsApp_s.EYEQMSG_CORETRAFFICSIGNvO_Params_as[objIndx_u8].Reserved_6_0_b4;
         * pReserved_6_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_6_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Lat_Distance_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pTSR_Sign_Lat_Distance_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Sign_Lat_Distance_STD_0
*    TSR_Sign_Lat_Distance_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Sign_Lat_Distance_STD_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Lat_Distance_STD_0( uint8 objIndx_u8, uint16 * pTSR_Sign_Lat_Distance_STD_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Traffic_Signs_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORETRAFFICSIGNvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pTSR_Sign_Lat_Distance_STD_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORETRAFFICSIGN_ParamsApp_s.EYEQMSG_CORETRAFFICSIGNvO_Params_as[objIndx_u8].TSR_Sign_Lat_Distance_STD_0_b13;
         * pTSR_Sign_Lat_Distance_STD_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_LAT_DISTANCE_STD_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Height_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pTSR_Sign_Height_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Sign_Height_0
*    TSR_Sign_Height_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Sign_Height_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Height_0( uint8 objIndx_u8, uint16 * pTSR_Sign_Height_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Traffic_Signs_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORETRAFFICSIGNvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pTSR_Sign_Height_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORETRAFFICSIGN_ParamsApp_s.EYEQMSG_CORETRAFFICSIGNvO_Params_as[objIndx_u8].TSR_Sign_Height_0_b15;
         * pTSR_Sign_Height_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_HEIGHT_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_Reserved_7_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_7_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_7_0
*    Reserved_7_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_7_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_Reserved_7_0( uint8 objIndx_u8, uint8 * pReserved_7_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Traffic_Signs_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORETRAFFICSIGNvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_7_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORETRAFFICSIGN_ParamsApp_s.EYEQMSG_CORETRAFFICSIGNvO_Params_as[objIndx_u8].Reserved_7_0_b4;
         * pReserved_7_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_7_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Panel_Height_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pTSR_Sign_Panel_Height_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Sign_Panel_Height_STD_0
*    TSR_Sign_Panel_Height_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Sign_Panel_Height_STD_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Panel_Height_STD_0( uint8 objIndx_u8, uint16 * pTSR_Sign_Panel_Height_STD_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Traffic_Signs_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORETRAFFICSIGNvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pTSR_Sign_Panel_Height_STD_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORETRAFFICSIGN_ParamsApp_s.EYEQMSG_CORETRAFFICSIGNvO_Params_as[objIndx_u8].TSR_Sign_Panel_Height_STD_0_b10;
         * pTSR_Sign_Panel_Height_STD_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_PANEL_HEIGHT_STD_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Height_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pTSR_Sign_Height_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Sign_Height_STD_0
*    TSR_Sign_Height_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Sign_Height_STD_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Height_STD_0( uint8 objIndx_u8, uint16 * pTSR_Sign_Height_STD_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Traffic_Signs_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORETRAFFICSIGNvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pTSR_Sign_Height_STD_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORETRAFFICSIGN_ParamsApp_s.EYEQMSG_CORETRAFFICSIGNvO_Params_as[objIndx_u8].TSR_Sign_Height_STD_0_b15;
         * pTSR_Sign_Height_STD_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_HEIGHT_STD_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_Reserved_8_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_8_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_8_0
*    Reserved_8_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_8_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_Reserved_8_0( uint8 objIndx_u8, uint8 * pReserved_8_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Traffic_Signs_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORETRAFFICSIGNvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_8_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORETRAFFICSIGN_ParamsApp_s.EYEQMSG_CORETRAFFICSIGNvO_Params_as[objIndx_u8].Reserved_8_0_b7;
         * pReserved_8_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_8_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Panel_Width_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pTSR_Sign_Panel_Width_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Sign_Panel_Width_0
*    TSR_Sign_Panel_Width_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Sign_Panel_Width_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Panel_Width_0( uint8 objIndx_u8, uint16 * pTSR_Sign_Panel_Width_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Traffic_Signs_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORETRAFFICSIGNvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pTSR_Sign_Panel_Width_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORETRAFFICSIGN_ParamsApp_s.EYEQMSG_CORETRAFFICSIGNvO_Params_as[objIndx_u8].TSR_Sign_Panel_Width_0_b10;
         * pTSR_Sign_Panel_Width_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_PANEL_WIDTH_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Panel_Height_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pTSR_Sign_Panel_Height_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Sign_Panel_Height_0
*    TSR_Sign_Panel_Height_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Sign_Panel_Height_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Panel_Height_0( uint8 objIndx_u8, uint16 * pTSR_Sign_Panel_Height_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Traffic_Signs_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORETRAFFICSIGNvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pTSR_Sign_Panel_Height_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORETRAFFICSIGN_ParamsApp_s.EYEQMSG_CORETRAFFICSIGNvO_Params_as[objIndx_u8].TSR_Sign_Panel_Height_0_b10;
         * pTSR_Sign_Panel_Height_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_PANEL_HEIGHT_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Panel_Width_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pTSR_Sign_Panel_Width_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Sign_Panel_Width_STD_0
*    TSR_Sign_Panel_Width_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Sign_Panel_Width_STD_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Panel_Width_STD_0( uint8 objIndx_u8, uint16 * pTSR_Sign_Panel_Width_STD_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Traffic_Signs_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORETRAFFICSIGNvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pTSR_Sign_Panel_Width_STD_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORETRAFFICSIGN_ParamsApp_s.EYEQMSG_CORETRAFFICSIGNvO_Params_as[objIndx_u8].TSR_Sign_Panel_Width_STD_0_b10;
         * pTSR_Sign_Panel_Width_STD_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_PANEL_WIDTH_STD_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_Reserved_9_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_9_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_9_0
*    Reserved_9_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_9_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_Reserved_9_0( uint8 objIndx_u8, uint8 * pReserved_9_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Traffic_Signs_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORETRAFFICSIGNvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_9_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORETRAFFICSIGN_ParamsApp_s.EYEQMSG_CORETRAFFICSIGNvO_Params_as[objIndx_u8].Reserved_9_0_b2;
         * pReserved_9_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_9_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Measurement_Status_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORETRAFFICSIGNvOTSRMeasurementStatus0 * pTSR_Measurement_Status_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Measurement_Status_0
*    TSR_Measurement_Status_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Measurement_Status_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Measurement_Status_0( uint8 objIndx_u8, CORETRAFFICSIGNvOTSRMeasurementStatus0 * pTSR_Measurement_Status_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORETRAFFICSIGNvOTSRMeasurementStatus0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Traffic_Signs_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORETRAFFICSIGNvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pTSR_Measurement_Status_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORETRAFFICSIGN_ParamsApp_s.EYEQMSG_CORETRAFFICSIGNvO_Params_as[objIndx_u8].TSR_Measurement_Status_0_b3;
         * pTSR_Measurement_Status_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORETRAFFICSIGNvO_TSR_MEASUREMENT_STATUS_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_AngleZ_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pTSR_AngleZ_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_AngleZ_0
*    TSR_AngleZ_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_AngleZ_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_AngleZ_0( uint8 objIndx_u8, uint16 * pTSR_AngleZ_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Traffic_Signs_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORETRAFFICSIGNvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pTSR_AngleZ_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORETRAFFICSIGN_ParamsApp_s.EYEQMSG_CORETRAFFICSIGNvO_Params_as[objIndx_u8].TSR_AngleZ_0_b10;
         * pTSR_AngleZ_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORETRAFFICSIGNvO_TSR_ANGLEZ_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Relevancy_Confidence_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pTSR_Relevancy_Confidence_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Relevancy_Confidence_0
*    TSR_Relevancy_Confidence_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Relevancy_Confidence_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Relevancy_Confidence_0( uint8 objIndx_u8, uint8 * pTSR_Relevancy_Confidence_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Traffic_Signs_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORETRAFFICSIGNvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pTSR_Relevancy_Confidence_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORETRAFFICSIGN_ParamsApp_s.EYEQMSG_CORETRAFFICSIGNvO_Params_as[objIndx_u8].TSR_Relevancy_Confidence_0_b7;
         * pTSR_Relevancy_Confidence_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORETRAFFICSIGNvO_TSR_RELEVANCY_CONFIDENCE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_Reserved_10_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pReserved_10_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_10_0
*    Reserved_10_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_10_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_Reserved_10_0( uint8 objIndx_u8, uint16 * pReserved_10_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Traffic_Signs_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORETRAFFICSIGNvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_10_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORETRAFFICSIGN_ParamsApp_s.EYEQMSG_CORETRAFFICSIGNvO_Params_as[objIndx_u8].Reserved_10_0_b12;
         * pReserved_10_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_10_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_CORETRAFFICSIGN_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_CORETRAFFICSIGN_Params_t * pCore_Traffic_Signs_protocol - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_Traffic_Signs_protocol message 
*    Core_Traffic_Signs_protocol message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_Traffic_Signs_protocol message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_CORETRAFFICSIGN_ParamsApp_MsgDataStruct( EYEQMSG_CORETRAFFICSIGN_Params_t * pCore_Traffic_Signs_protocol )
{
   Std_ReturnType status = C_SIG_INVALID;
   if( pCore_Traffic_Signs_protocol != C_NULL_P )
   {
      status = C_SIG_VALID;
      * pCore_Traffic_Signs_protocol = EYEQMSG_CORETRAFFICSIGN_ParamsApp_s;
   }
   return ( status );
}

