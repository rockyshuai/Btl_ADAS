

/*****************************************************************************
                  Include files
*****************************************************************************/
/* The suggested include file order is: */
#include "EyeQ_defs.h"    /* EyeQ project common definitions file    */

#include "EYEQMSG_CoreLightVCLProcess.h"

/*****************************************************************************
                  Local symbolic constants
*****************************************************************************/
/*****************************************************************************
                  Local types, enums definitions
*****************************************************************************/
/*****************************************************************************
                  Local function prototypes
*****************************************************************************/
/*****************************************************************************
                  Local object definitions
*****************************************************************************/
/*****************************************************************************
                  Exported object definitions
*****************************************************************************/
EYEQMSG_CORELIGHTVCL_Params_t   EYEQMSG_CORELIGHTVCL_Params_s;
EYEQMSG_CORELIGHTVCL_Params_t   EYEQMSG_CORELIGHTVCL_ParamsApp_s;
/*****************************************************************************
                  Local function-like macros
*****************************************************************************/
/*****************************************************************************
                  Local defined macros
*****************************************************************************/
/*****************************************************************************
                  Function definitions
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvH_LSV_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pLSV_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Zero_byte
*    LSV_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Zero_byte signal value of Virtual_HEADER_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvH_LSV_Zero_byte( uint8 * pLSV_Zero_byte )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pLSV_Zero_byte != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTVCL_ParamsApp_s.EYEQMSG_CORELIGHTVCLvH_Params_s.LSV_Zero_byte_b8;
      * pLSV_Zero_byte = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvH_LSV_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pLSV_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Protocol_Version
*    LSV_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Protocol_Version signal value of Virtual_HEADER_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvH_LSV_Protocol_Version( uint8 * pLSV_Protocol_Version )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pLSV_Protocol_Version != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTVCL_ParamsApp_s.EYEQMSG_CORELIGHTVCLvH_Params_s.LSV_Protocol_Version_b8;
      * pLSV_Protocol_Version = signal_value;
      if( (signal_value >= C_EYEQMSG_CORELIGHTVCLvH_LSV_PROTOCOL_VERSION_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORELIGHTVCLvH_LSV_PROTOCOL_VERSION_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvH_LSV_Sync_ID
*
* FUNCTION ARGUMENTS:
*    uint8 * pLSV_Sync_ID - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Sync_ID
*    LSV_Sync_ID returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Sync_ID signal value of Virtual_HEADER_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvH_LSV_Sync_ID( uint8 * pLSV_Sync_ID )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pLSV_Sync_ID != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTVCL_ParamsApp_s.EYEQMSG_CORELIGHTVCLvH_Params_s.LSV_Sync_ID_b8;
      * pLSV_Sync_ID = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvH_LSV_Running_Mode
*
* FUNCTION ARGUMENTS:
*    CORELIGHTVCLvHLSVRunningMode * pLSV_Running_Mode - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Running_Mode
*    LSV_Running_Mode returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Running_Mode signal value of Virtual_HEADER_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvH_LSV_Running_Mode( CORELIGHTVCLvHLSVRunningMode * pLSV_Running_Mode )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTVCLvHLSVRunningMode signal_value;
   
   if( pLSV_Running_Mode != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTVCL_ParamsApp_s.EYEQMSG_CORELIGHTVCLvH_Params_s.LSV_Running_Mode_b2;
      * pLSV_Running_Mode = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvH_LSV_Inactive_Reason
*
* FUNCTION ARGUMENTS:
*    CORELIGHTVCLvHLSVInactiveReason * pLSV_Inactive_Reason - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Inactive_Reason
*    LSV_Inactive_Reason returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Inactive_Reason signal value of Virtual_HEADER_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvH_LSV_Inactive_Reason( CORELIGHTVCLvHLSVInactiveReason * pLSV_Inactive_Reason )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTVCLvHLSVInactiveReason signal_value;
   
   if( pLSV_Inactive_Reason != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTVCL_ParamsApp_s.EYEQMSG_CORELIGHTVCLvH_Params_s.LSV_Inactive_Reason_b3;
      * pLSV_Inactive_Reason = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTVCLvH_LSV_INACTIVE_REASON_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvH_LSV_HLB_Decision
*
* FUNCTION ARGUMENTS:
*    CORELIGHTVCLvHLSVHLBDecision * pLSV_HLB_Decision - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_HLB_Decision
*    LSV_HLB_Decision returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_HLB_Decision signal value of Virtual_HEADER_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvH_LSV_HLB_Decision( CORELIGHTVCLvHLSVHLBDecision * pLSV_HLB_Decision )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTVCLvHLSVHLBDecision signal_value;
   
   if( pLSV_HLB_Decision != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTVCL_ParamsApp_s.EYEQMSG_CORELIGHTVCLvH_Params_s.LSV_HLB_Decision_b2;
      * pLSV_HLB_Decision = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTVCLvH_LSV_HLB_DECISION_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvH_LSV_HLB_Sensitivity_Mode
*
* FUNCTION ARGUMENTS:
*    CORELIGHTVCLvHLSVHLBSensitivityMode * pLSV_HLB_Sensitivity_Mode - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_HLB_Sensitivity_Mode
*    LSV_HLB_Sensitivity_Mode returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_HLB_Sensitivity_Mode signal value of Virtual_HEADER_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvH_LSV_HLB_Sensitivity_Mode( CORELIGHTVCLvHLSVHLBSensitivityMode * pLSV_HLB_Sensitivity_Mode )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTVCLvHLSVHLBSensitivityMode signal_value;
   
   if( pLSV_HLB_Sensitivity_Mode != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTVCL_ParamsApp_s.EYEQMSG_CORELIGHTVCLvH_Params_s.LSV_HLB_Sensitivity_Mode_b1;
      * pLSV_HLB_Sensitivity_Mode = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvH_LSV_HLB_Reason
*
* FUNCTION ARGUMENTS:
*    CORELIGHTVCLvHLSVHLBReason * pLSV_HLB_Reason - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_HLB_Reason
*    LSV_HLB_Reason returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_HLB_Reason signal value of Virtual_HEADER_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvH_LSV_HLB_Reason( CORELIGHTVCLvHLSVHLBReason * pLSV_HLB_Reason )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTVCLvHLSVHLBReason signal_value;
   
   if( pLSV_HLB_Reason != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTVCL_ParamsApp_s.EYEQMSG_CORELIGHTVCLvH_Params_s.LSV_HLB_Reason_b28;
      * pLSV_HLB_Reason = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTVCLvH_LSV_HLB_REASON_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvH_LSV_Vehicles_Count
*
* FUNCTION ARGUMENTS:
*    uint8 * pLSV_Vehicles_Count - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Vehicles_Count
*    LSV_Vehicles_Count returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Vehicles_Count signal value of Virtual_HEADER_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvH_LSV_Vehicles_Count( uint8 * pLSV_Vehicles_Count )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pLSV_Vehicles_Count != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTVCL_ParamsApp_s.EYEQMSG_CORELIGHTVCLvH_Params_s.LSV_Vehicles_Count_b4;
      * pLSV_Vehicles_Count = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvH_LSV_Brightness_Score
*
* FUNCTION ARGUMENTS:
*    uint32 * pLSV_Brightness_Score - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Brightness_Score
*    LSV_Brightness_Score returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Brightness_Score signal value of Virtual_HEADER_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvH_LSV_Brightness_Score( uint32 * pLSV_Brightness_Score )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pLSV_Brightness_Score != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTVCL_ParamsApp_s.EYEQMSG_CORELIGHTVCLvH_Params_s.LSV_Brightness_Score_b32;
      * pLSV_Brightness_Score = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTVCLvH_LSV_BRIGHTNESS_SCORE_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_LSV_ID_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLSV_ID_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_ID_0
*    LSV_ID_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_ID_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_LSV_ID_0( uint8 objIndx_u8, uint8 * pLSV_ID_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELIGHTVCLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLSV_ID_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELIGHTVCL_ParamsApp_s.EYEQMSG_CORELIGHTVCLvO_Params_as[objIndx_u8].LSV_ID_0_b8;
         * pLSV_ID_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_LSV_Type_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELIGHTVCLvOLSVType0 * pLSV_Type_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Type_0
*    LSV_Type_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Type_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_LSV_Type_0( uint8 objIndx_u8, CORELIGHTVCLvOLSVType0 * pLSV_Type_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTVCLvOLSVType0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELIGHTVCLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLSV_Type_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELIGHTVCL_ParamsApp_s.EYEQMSG_CORELIGHTVCLvO_Params_as[objIndx_u8].LSV_Type_0_b4;
         * pLSV_Type_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELIGHTVCLvO_LSV_TYPE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_LSV_Sub_Type_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELIGHTVCLvOLSVSubType0 * pLSV_Sub_Type_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Sub_Type_0
*    LSV_Sub_Type_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Sub_Type_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_LSV_Sub_Type_0( uint8 objIndx_u8, CORELIGHTVCLvOLSVSubType0 * pLSV_Sub_Type_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTVCLvOLSVSubType0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELIGHTVCLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLSV_Sub_Type_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELIGHTVCL_ParamsApp_s.EYEQMSG_CORELIGHTVCLvO_Params_as[objIndx_u8].LSV_Sub_Type_0_b6;
         * pLSV_Sub_Type_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_LSV_CL_Sub_Type_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELIGHTVCLvOLSVCLSubType0 * pLSV_CL_Sub_Type_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_CL_Sub_Type_0
*    LSV_CL_Sub_Type_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_CL_Sub_Type_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_LSV_CL_Sub_Type_0( uint8 objIndx_u8, CORELIGHTVCLvOLSVCLSubType0 * pLSV_CL_Sub_Type_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTVCLvOLSVCLSubType0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELIGHTVCLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLSV_CL_Sub_Type_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELIGHTVCL_ParamsApp_s.EYEQMSG_CORELIGHTVCLvO_Params_as[objIndx_u8].LSV_CL_Sub_Type_0_b4;
         * pLSV_CL_Sub_Type_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELIGHTVCLvO_LSV_CL_SUB_TYPE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_LSV_Consecutive_Detection_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLSV_Consecutive_Detection_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Consecutive_Detection_0
*    LSV_Consecutive_Detection_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Consecutive_Detection_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_LSV_Consecutive_Detection_0( uint8 objIndx_u8, uint8 * pLSV_Consecutive_Detection_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELIGHTVCLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLSV_Consecutive_Detection_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELIGHTVCL_ParamsApp_s.EYEQMSG_CORELIGHTVCLvO_Params_as[objIndx_u8].LSV_Consecutive_Detection_0_b7;
         * pLSV_Consecutive_Detection_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELIGHTVCLvO_LSV_CONSECUTIVE_DETECTION_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_Reserved_1_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_1_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1_0
*    Reserved_1_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_Reserved_1_0( uint8 objIndx_u8, uint8 * pReserved_1_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELIGHTVCLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_1_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELIGHTVCL_ParamsApp_s.EYEQMSG_CORELIGHTVCLvO_Params_as[objIndx_u8].Reserved_1_0_b3;
         * pReserved_1_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELIGHTVCLvO_RESERVED_1_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_LSV_Width_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLSV_Width_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Width_STD_0
*    LSV_Width_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Width_STD_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_LSV_Width_STD_0( uint8 objIndx_u8, uint16 * pLSV_Width_STD_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELIGHTVCLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLSV_Width_STD_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELIGHTVCL_ParamsApp_s.EYEQMSG_CORELIGHTVCLvO_Params_as[objIndx_u8].LSV_Width_STD_0_b9;
         * pLSV_Width_STD_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELIGHTVCLvO_LSV_WIDTH_STD_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_LSV_Confidence_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLSV_Confidence_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Confidence_0
*    LSV_Confidence_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Confidence_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_LSV_Confidence_0( uint8 objIndx_u8, uint8 * pLSV_Confidence_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELIGHTVCLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLSV_Confidence_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELIGHTVCL_ParamsApp_s.EYEQMSG_CORELIGHTVCLvO_Params_as[objIndx_u8].LSV_Confidence_0_b7;
         * pLSV_Confidence_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELIGHTVCLvO_LSV_CONFIDENCE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_LSV_Is_New_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELIGHTVCLvOLSVIsNew0 * pLSV_Is_New_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Is_New_0
*    LSV_Is_New_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Is_New_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_LSV_Is_New_0( uint8 objIndx_u8, CORELIGHTVCLvOLSVIsNew0 * pLSV_Is_New_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTVCLvOLSVIsNew0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELIGHTVCLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLSV_Is_New_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELIGHTVCL_ParamsApp_s.EYEQMSG_CORELIGHTVCLvO_Params_as[objIndx_u8].LSV_Is_New_0_b1;
         * pLSV_Is_New_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_LSV_VD_ID_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLSV_VD_ID_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_VD_ID_0
*    LSV_VD_ID_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_VD_ID_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_LSV_VD_ID_0( uint8 objIndx_u8, uint16 * pLSV_VD_ID_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELIGHTVCLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLSV_VD_ID_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELIGHTVCL_ParamsApp_s.EYEQMSG_CORELIGHTVCLvO_Params_as[objIndx_u8].LSV_VD_ID_0_b9;
         * pLSV_VD_ID_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELIGHTVCLvO_LSV_VD_ID_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_Reserved_2_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_2_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_2_0
*    Reserved_2_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_2_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_Reserved_2_0( uint8 objIndx_u8, uint8 * pReserved_2_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELIGHTVCLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_2_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELIGHTVCL_ParamsApp_s.EYEQMSG_CORELIGHTVCLvO_Params_as[objIndx_u8].Reserved_2_0_b6;
         * pReserved_2_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELIGHTVCLvO_RESERVED_2_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_LSV_Brightness_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint32 * pLSV_Brightness_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Brightness_0
*    LSV_Brightness_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Brightness_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_LSV_Brightness_0( uint8 objIndx_u8, uint32 * pLSV_Brightness_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELIGHTVCLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLSV_Brightness_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELIGHTVCL_ParamsApp_s.EYEQMSG_CORELIGHTVCLvO_Params_as[objIndx_u8].LSV_Brightness_0_b20;
         * pLSV_Brightness_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELIGHTVCLvO_LSV_BRIGHTNESS_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_LSV_Distance_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLSV_Distance_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Distance_0
*    LSV_Distance_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Distance_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_LSV_Distance_0( uint8 objIndx_u8, uint16 * pLSV_Distance_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELIGHTVCLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLSV_Distance_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELIGHTVCL_ParamsApp_s.EYEQMSG_CORELIGHTVCLvO_Params_as[objIndx_u8].LSV_Distance_0_b11;
         * pLSV_Distance_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELIGHTVCLvO_LSV_DISTANCE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_Reserved_3_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    boolean * pReserved_3_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_3_0
*    Reserved_3_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_3_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_Reserved_3_0( uint8 objIndx_u8, boolean * pReserved_3_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELIGHTVCLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_3_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELIGHTVCL_ParamsApp_s.EYEQMSG_CORELIGHTVCLvO_Params_as[objIndx_u8].Reserved_3_0_b1;
         * pReserved_3_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELIGHTVCLvO_RESERVED_3_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_LSV_Distance_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLSV_Distance_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Distance_STD_0
*    LSV_Distance_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Distance_STD_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_LSV_Distance_STD_0( uint8 objIndx_u8, uint8 * pLSV_Distance_STD_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELIGHTVCLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLSV_Distance_STD_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELIGHTVCL_ParamsApp_s.EYEQMSG_CORELIGHTVCLvO_Params_as[objIndx_u8].LSV_Distance_STD_0_b8;
         * pLSV_Distance_STD_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELIGHTVCLvO_LSV_DISTANCE_STD_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_LSV_CL_Distance_Right_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLSV_CL_Distance_Right_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_CL_Distance_Right_0
*    LSV_CL_Distance_Right_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_CL_Distance_Right_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_LSV_CL_Distance_Right_0( uint8 objIndx_u8, uint16 * pLSV_CL_Distance_Right_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELIGHTVCLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLSV_CL_Distance_Right_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELIGHTVCL_ParamsApp_s.EYEQMSG_CORELIGHTVCLvO_Params_as[objIndx_u8].LSV_CL_Distance_Right_0_b11;
         * pLSV_CL_Distance_Right_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELIGHTVCLvO_LSV_CL_DISTANCE_RIGHT_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_LSV_CL_Distance_Left_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLSV_CL_Distance_Left_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_CL_Distance_Left_0
*    LSV_CL_Distance_Left_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_CL_Distance_Left_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_LSV_CL_Distance_Left_0( uint8 objIndx_u8, uint16 * pLSV_CL_Distance_Left_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELIGHTVCLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLSV_CL_Distance_Left_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELIGHTVCL_ParamsApp_s.EYEQMSG_CORELIGHTVCLvO_Params_as[objIndx_u8].LSV_CL_Distance_Left_0_b11;
         * pLSV_CL_Distance_Left_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELIGHTVCLvO_LSV_CL_DISTANCE_LEFT_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_Reserved_4_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_4_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_4_0
*    Reserved_4_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_4_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_Reserved_4_0( uint8 objIndx_u8, uint8 * pReserved_4_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELIGHTVCLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_4_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELIGHTVCL_ParamsApp_s.EYEQMSG_CORELIGHTVCLvO_Params_as[objIndx_u8].Reserved_4_0_b2;
         * pReserved_4_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELIGHTVCLvO_RESERVED_4_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_LSV_Top_Angle_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLSV_Top_Angle_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Top_Angle_0
*    LSV_Top_Angle_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Top_Angle_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_LSV_Top_Angle_0( uint8 objIndx_u8, uint16 * pLSV_Top_Angle_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELIGHTVCLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLSV_Top_Angle_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELIGHTVCL_ParamsApp_s.EYEQMSG_CORELIGHTVCLvO_Params_as[objIndx_u8].LSV_Top_Angle_0_b12;
         * pLSV_Top_Angle_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELIGHTVCLvO_LSV_TOP_ANGLE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_LSV_Bottom_Angle_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLSV_Bottom_Angle_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Bottom_Angle_0
*    LSV_Bottom_Angle_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Bottom_Angle_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_LSV_Bottom_Angle_0( uint8 objIndx_u8, uint16 * pLSV_Bottom_Angle_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELIGHTVCLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLSV_Bottom_Angle_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELIGHTVCL_ParamsApp_s.EYEQMSG_CORELIGHTVCLvO_Params_as[objIndx_u8].LSV_Bottom_Angle_0_b12;
         * pLSV_Bottom_Angle_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELIGHTVCLvO_LSV_BOTTOM_ANGLE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_Reserved_5_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_5_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_5_0
*    Reserved_5_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_5_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_Reserved_5_0( uint8 objIndx_u8, uint8 * pReserved_5_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELIGHTVCLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_5_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELIGHTVCL_ParamsApp_s.EYEQMSG_CORELIGHTVCLvO_Params_as[objIndx_u8].Reserved_5_0_b8;
         * pReserved_5_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELIGHTVCLvO_RESERVED_5_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_LSV_Right_Angle_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLSV_Right_Angle_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Right_Angle_0
*    LSV_Right_Angle_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Right_Angle_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_LSV_Right_Angle_0( uint8 objIndx_u8, uint16 * pLSV_Right_Angle_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELIGHTVCLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLSV_Right_Angle_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELIGHTVCL_ParamsApp_s.EYEQMSG_CORELIGHTVCLvO_Params_as[objIndx_u8].LSV_Right_Angle_0_b13;
         * pLSV_Right_Angle_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELIGHTVCLvO_LSV_RIGHT_ANGLE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_LSV_Left_Angle_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLSV_Left_Angle_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Left_Angle_0
*    LSV_Left_Angle_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Left_Angle_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_LSV_Left_Angle_0( uint8 objIndx_u8, uint16 * pLSV_Left_Angle_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELIGHTVCLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLSV_Left_Angle_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELIGHTVCL_ParamsApp_s.EYEQMSG_CORELIGHTVCLvO_Params_as[objIndx_u8].LSV_Left_Angle_0_b13;
         * pLSV_Left_Angle_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELIGHTVCLvO_LSV_LEFT_ANGLE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_Reserved_6_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_6_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_6_0
*    Reserved_6_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_6_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_Reserved_6_0( uint8 objIndx_u8, uint8 * pReserved_6_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELIGHTVCLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_6_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELIGHTVCL_ParamsApp_s.EYEQMSG_CORELIGHTVCLvO_Params_as[objIndx_u8].Reserved_6_0_b6;
         * pReserved_6_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELIGHTVCLvO_RESERVED_6_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_LSV_Angular_Velocity_Right_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLSV_Angular_Velocity_Right_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Angular_Velocity_Right_0
*    LSV_Angular_Velocity_Right_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Angular_Velocity_Right_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_LSV_Angular_Velocity_Right_0( uint8 objIndx_u8, uint16 * pLSV_Angular_Velocity_Right_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELIGHTVCLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLSV_Angular_Velocity_Right_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELIGHTVCL_ParamsApp_s.EYEQMSG_CORELIGHTVCLvO_Params_as[objIndx_u8].LSV_Angular_Velocity_Right_0_b11;
         * pLSV_Angular_Velocity_Right_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_LSV_Angular_Velocity_Left_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLSV_Angular_Velocity_Left_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Angular_Velocity_Left_0
*    LSV_Angular_Velocity_Left_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Angular_Velocity_Left_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_LSV_Angular_Velocity_Left_0( uint8 objIndx_u8, uint16 * pLSV_Angular_Velocity_Left_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELIGHTVCLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLSV_Angular_Velocity_Left_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELIGHTVCL_ParamsApp_s.EYEQMSG_CORELIGHTVCLvO_Params_as[objIndx_u8].LSV_Angular_Velocity_Left_0_b11;
         * pLSV_Angular_Velocity_Left_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_Reserved_7_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pReserved_7_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_7_0
*    Reserved_7_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_7_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_Reserved_7_0( uint8 objIndx_u8, uint16 * pReserved_7_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELIGHTVCLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_7_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELIGHTVCL_ParamsApp_s.EYEQMSG_CORELIGHTVCLvO_Params_as[objIndx_u8].Reserved_7_0_b10;
         * pReserved_7_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELIGHTVCLvO_RESERVED_7_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_LSV_Atten_Cent_Angle_H_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLSV_Atten_Cent_Angle_H_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Atten_Cent_Angle_H_0
*    LSV_Atten_Cent_Angle_H_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Atten_Cent_Angle_H_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_LSV_Atten_Cent_Angle_H_0( uint8 objIndx_u8, uint16 * pLSV_Atten_Cent_Angle_H_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELIGHTVCLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLSV_Atten_Cent_Angle_H_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELIGHTVCL_ParamsApp_s.EYEQMSG_CORELIGHTVCLvO_Params_as[objIndx_u8].LSV_Atten_Cent_Angle_H_0_b13;
         * pLSV_Atten_Cent_Angle_H_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELIGHTVCLvO_LSV_ATTEN_CENT_ANGLE_H_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_LSV_Atten_Cent_Angle_Lat_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLSV_Atten_Cent_Angle_Lat_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Atten_Cent_Angle_Lat_0
*    LSV_Atten_Cent_Angle_Lat_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Atten_Cent_Angle_Lat_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_LSV_Atten_Cent_Angle_Lat_0( uint8 objIndx_u8, uint16 * pLSV_Atten_Cent_Angle_Lat_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELIGHTVCLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLSV_Atten_Cent_Angle_Lat_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELIGHTVCL_ParamsApp_s.EYEQMSG_CORELIGHTVCLvO_Params_as[objIndx_u8].LSV_Atten_Cent_Angle_Lat_0_b13;
         * pLSV_Atten_Cent_Angle_Lat_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELIGHTVCLvO_LSV_ATTEN_CENT_ANGLE_LAT_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_Reserved_8_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_8_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_8_0
*    Reserved_8_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_8_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_Reserved_8_0( uint8 objIndx_u8, uint8 * pReserved_8_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELIGHTVCLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_8_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELIGHTVCL_ParamsApp_s.EYEQMSG_CORELIGHTVCLvO_Params_as[objIndx_u8].Reserved_8_0_b6;
         * pReserved_8_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELIGHTVCLvO_RESERVED_8_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_LSV_Facade_Top_Angle_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLSV_Facade_Top_Angle_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Facade_Top_Angle_0
*    LSV_Facade_Top_Angle_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Facade_Top_Angle_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_LSV_Facade_Top_Angle_0( uint8 objIndx_u8, uint16 * pLSV_Facade_Top_Angle_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELIGHTVCLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLSV_Facade_Top_Angle_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELIGHTVCL_ParamsApp_s.EYEQMSG_CORELIGHTVCLvO_Params_as[objIndx_u8].LSV_Facade_Top_Angle_0_b12;
         * pLSV_Facade_Top_Angle_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELIGHTVCLvO_LSV_FACADE_TOP_ANGLE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_LSV_Facade_Right_Angle_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLSV_Facade_Right_Angle_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Facade_Right_Angle_0
*    LSV_Facade_Right_Angle_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Facade_Right_Angle_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_LSV_Facade_Right_Angle_0( uint8 objIndx_u8, uint16 * pLSV_Facade_Right_Angle_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELIGHTVCLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLSV_Facade_Right_Angle_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELIGHTVCL_ParamsApp_s.EYEQMSG_CORELIGHTVCLvO_Params_as[objIndx_u8].LSV_Facade_Right_Angle_0_b13;
         * pLSV_Facade_Right_Angle_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELIGHTVCLvO_LSV_FACADE_RIGHT_ANGLE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_Reserved_9_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_9_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_9_0
*    Reserved_9_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_9_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_Reserved_9_0( uint8 objIndx_u8, uint8 * pReserved_9_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELIGHTVCLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_9_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELIGHTVCL_ParamsApp_s.EYEQMSG_CORELIGHTVCLvO_Params_as[objIndx_u8].Reserved_9_0_b7;
         * pReserved_9_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELIGHTVCLvO_RESERVED_9_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_LSV_Facade_Left_Angle_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLSV_Facade_Left_Angle_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Facade_Left_Angle_0
*    LSV_Facade_Left_Angle_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Facade_Left_Angle_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_LSV_Facade_Left_Angle_0( uint8 objIndx_u8, uint16 * pLSV_Facade_Left_Angle_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELIGHTVCLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLSV_Facade_Left_Angle_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELIGHTVCL_ParamsApp_s.EYEQMSG_CORELIGHTVCLvO_Params_as[objIndx_u8].LSV_Facade_Left_Angle_0_b13;
         * pLSV_Facade_Left_Angle_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELIGHTVCLvO_LSV_FACADE_LEFT_ANGLE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_Reserved_10_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint32 * pReserved_10_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_10_0
*    Reserved_10_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_10_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_Reserved_10_0( uint8 objIndx_u8, uint32 * pReserved_10_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELIGHTVCLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_10_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELIGHTVCL_ParamsApp_s.EYEQMSG_CORELIGHTVCLvO_Params_as[objIndx_u8].Reserved_10_0_b19;
         * pReserved_10_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELIGHTVCLvO_RESERVED_10_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_CORELIGHTVCL_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_CORELIGHTVCL_Params_t * pCore_Light_Scene_VCL_protocol - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_Light_Scene_VCL_protocol message 
*    Core_Light_Scene_VCL_protocol message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_Light_Scene_VCL_protocol message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_CORELIGHTVCL_ParamsApp_MsgDataStruct( EYEQMSG_CORELIGHTVCL_Params_t * pCore_Light_Scene_VCL_protocol )
{
   Std_ReturnType status = C_SIG_INVALID;
   if( pCore_Light_Scene_VCL_protocol != C_NULL_P )
   {
      status = C_SIG_VALID;
      * pCore_Light_Scene_VCL_protocol = EYEQMSG_CORELIGHTVCL_ParamsApp_s;
   }
   return ( status );
}

