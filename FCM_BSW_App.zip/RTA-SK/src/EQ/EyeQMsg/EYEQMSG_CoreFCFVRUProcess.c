

/*****************************************************************************
                  Include files
*****************************************************************************/
/* The suggested include file order is: */
#include "EyeQ_defs.h"    /* EyeQ project common definitions file    */

#include "EYEQMSG_CoreFCFVRUProcess.h"

/*****************************************************************************
                  Local symbolic constants
*****************************************************************************/
/*****************************************************************************
                  Local types, enums definitions
*****************************************************************************/
/*****************************************************************************
                  Local function prototypes
*****************************************************************************/
/*****************************************************************************
                  Local object definitions
*****************************************************************************/
/*****************************************************************************
                  Exported object definitions
*****************************************************************************/
EYEQMSG_COREFCFVRU_Params_t   EYEQMSG_COREFCFVRU_Params_s;
EYEQMSG_COREFCFVRU_Params_t   EYEQMSG_COREFCFVRU_ParamsApp_s;
/*****************************************************************************
                  Local function-like macros
*****************************************************************************/
/*****************************************************************************
                  Local defined macros
*****************************************************************************/
/*****************************************************************************
                  Function definitions
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_COREFCFVRU_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_COREFCFVRU_Params_t * pCore_FCF_VRU_protocol - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_FCF_VRU_protocol message 
*    Core_FCF_VRU_protocol message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_FCF_VRU_protocol message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_COREFCFVRU_ParamsApp_MsgDataStruct( EYEQMSG_COREFCFVRU_Params_t * pCore_FCF_VRU_protocol )
{
   Std_ReturnType status = C_SIG_INVALID;
   if( pCore_FCF_VRU_protocol != C_NULL_P )
   {
      status = C_SIG_VALID;
      * pCore_FCF_VRU_protocol = EYEQMSG_COREFCFVRU_ParamsApp_s;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_VRU_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Zero_byte
*    FCF_VRU_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Zero_byte signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Zero_byte( uint8 * pFCF_VRU_Zero_byte )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_VRU_Zero_byte != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Zero_byte_b8;
      * pFCF_VRU_Zero_byte = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_VRU_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Protocol_Version
*    FCF_VRU_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Protocol_Version signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Protocol_Version( uint8 * pFCF_VRU_Protocol_Version )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_VRU_Protocol_Version != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Protocol_Version_b8;
      * pFCF_VRU_Protocol_Version = signal_value;
      if( (signal_value >= C_EYEQMSG_COREFCFVRU_FCF_VRU_PROTOCOL_VERSION_RMIN ) 
          && (signal_value <= C_EYEQMSG_COREFCFVRU_FCF_VRU_PROTOCOL_VERSION_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Sync_ID
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_VRU_Sync_ID - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Sync_ID
*    FCF_VRU_Sync_ID returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Sync_ID signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Sync_ID( uint8 * pFCF_VRU_Sync_ID )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_VRU_Sync_ID != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Sync_ID_b8;
      * pFCF_VRU_Sync_ID = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Brake_Decel_Req
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_VRU_Brake_Decel_Req - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Brake_Decel_Req
*    FCF_VRU_Brake_Decel_Req returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Brake_Decel_Req signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Brake_Decel_Req( uint8 * pFCF_VRU_Brake_Decel_Req )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_VRU_Brake_Decel_Req != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Brake_Decel_Req_b8;
      * pFCF_VRU_Brake_Decel_Req = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVRU_FCF_VRU_BRAKE_DECEL_REQ_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Header_Buffer
*
* FUNCTION ARGUMENTS:
*    uint32 * pFCF_VRU_Header_Buffer - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Header_Buffer
*    FCF_VRU_Header_Buffer returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Header_Buffer signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Header_Buffer( uint32 * pFCF_VRU_Header_Buffer )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pFCF_VRU_Header_Buffer != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Header_Buffer_b32;
      * pFCF_VRU_Header_Buffer = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVRU_FCF_VRU_HEADER_BUFFER_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_CRC_L1
*
* FUNCTION ARGUMENTS:
*    uint32 * pFCF_VRU_CRC_L1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_CRC_L1
*    FCF_VRU_CRC_L1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_CRC_L1 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_CRC_L1( uint32 * pFCF_VRU_CRC_L1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pFCF_VRU_CRC_L1 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_CRC_L1_b32;
      * pFCF_VRU_CRC_L1 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Alert_L1
*
* FUNCTION ARGUMENTS:
*    COREFCFVRUFCFVRUAlertL1 * pFCF_VRU_Alert_L1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Alert_L1
*    FCF_VRU_Alert_L1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Alert_L1 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Alert_L1( COREFCFVRUFCFVRUAlertL1 * pFCF_VRU_Alert_L1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVRUFCFVRUAlertL1 signal_value;
   
   if( pFCF_VRU_Alert_L1 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Alert_L1_b16;
      * pFCF_VRU_Alert_L1 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Brake_Decel_Req_L1
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_VRU_Brake_Decel_Req_L1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Brake_Decel_Req_L1
*    FCF_VRU_Brake_Decel_Req_L1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Brake_Decel_Req_L1 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Brake_Decel_Req_L1( uint8 * pFCF_VRU_Brake_Decel_Req_L1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_VRU_Brake_Decel_Req_L1 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Brake_Decel_Req_L1_b8;
      * pFCF_VRU_Brake_Decel_Req_L1 = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVRU_FCF_VRU_BRAKE_DECEL_REQ_L1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_PED_ID_L1
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_VRU_PED_ID_L1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_PED_ID_L1
*    FCF_VRU_PED_ID_L1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_PED_ID_L1 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_PED_ID_L1( uint8 * pFCF_VRU_PED_ID_L1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_VRU_PED_ID_L1 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_PED_ID_L1_b8;
      * pFCF_VRU_PED_ID_L1 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Suppress_L1
*
* FUNCTION ARGUMENTS:
*    COREFCFVRUFCFVRUSuppressL1 * pFCF_VRU_Suppress_L1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Suppress_L1
*    FCF_VRU_Suppress_L1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Suppress_L1 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Suppress_L1( COREFCFVRUFCFVRUSuppressL1 * pFCF_VRU_Suppress_L1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVRUFCFVRUSuppressL1 signal_value;
   
   if( pFCF_VRU_Suppress_L1 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Suppress_L1_b6;
      * pFCF_VRU_Suppress_L1 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Safety_Suppressed_L1
*
* FUNCTION ARGUMENTS:
*    COREFCFVRUFCFVRUSafetySuppressedL1 * pFCF_VRU_Safety_Suppressed_L1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Safety_Suppressed_L1
*    FCF_VRU_Safety_Suppressed_L1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Safety_Suppressed_L1 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Safety_Suppressed_L1( COREFCFVRUFCFVRUSafetySuppressedL1 * pFCF_VRU_Safety_Suppressed_L1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVRUFCFVRUSafetySuppressedL1 signal_value;
   
   if( pFCF_VRU_Safety_Suppressed_L1 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Safety_Suppressed_L1_b1;
      * pFCF_VRU_Safety_Suppressed_L1 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Set_Type_L1
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_VRU_Set_Type_L1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Set_Type_L1
*    FCF_VRU_Set_Type_L1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Set_Type_L1 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Set_Type_L1( uint8 * pFCF_VRU_Set_Type_L1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_VRU_Set_Type_L1 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Set_Type_L1_b2;
      * pFCF_VRU_Set_Type_L1 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Curr_In_Path_L1
*
* FUNCTION ARGUMENTS:
*    COREFCFVRUFCFVRUCurrInPathL1 * pFCF_VRU_Curr_In_Path_L1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Curr_In_Path_L1
*    FCF_VRU_Curr_In_Path_L1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Curr_In_Path_L1 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Curr_In_Path_L1( COREFCFVRUFCFVRUCurrInPathL1 * pFCF_VRU_Curr_In_Path_L1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVRUFCFVRUCurrInPathL1 signal_value;
   
   if( pFCF_VRU_Curr_In_Path_L1 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Curr_In_Path_L1_b1;
      * pFCF_VRU_Curr_In_Path_L1 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Pred_In_Path_L1
*
* FUNCTION ARGUMENTS:
*    COREFCFVRUFCFVRUPredInPathL1 * pFCF_VRU_Pred_In_Path_L1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Pred_In_Path_L1
*    FCF_VRU_Pred_In_Path_L1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Pred_In_Path_L1 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Pred_In_Path_L1( COREFCFVRUFCFVRUPredInPathL1 * pFCF_VRU_Pred_In_Path_L1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVRUFCFVRUPredInPathL1 signal_value;
   
   if( pFCF_VRU_Pred_In_Path_L1 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Pred_In_Path_L1_b1;
      * pFCF_VRU_Pred_In_Path_L1 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_TTC_L1
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCF_VRU_TTC_L1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_TTC_L1
*    FCF_VRU_TTC_L1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_TTC_L1 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_TTC_L1( uint16 * pFCF_VRU_TTC_L1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCF_VRU_TTC_L1 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_TTC_L1_b10;
      * pFCF_VRU_TTC_L1 = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVRU_FCF_VRU_TTC_L1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_TTC_Thresh_L1
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCF_VRU_TTC_Thresh_L1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_TTC_Thresh_L1
*    FCF_VRU_TTC_Thresh_L1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_TTC_Thresh_L1 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_TTC_Thresh_L1( uint16 * pFCF_VRU_TTC_Thresh_L1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCF_VRU_TTC_Thresh_L1 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_TTC_Thresh_L1_b10;
      * pFCF_VRU_TTC_Thresh_L1 = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVRU_FCF_VRU_TTC_THRESH_L1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Buffer_L1
*
* FUNCTION ARGUMENTS:
*    boolean * pFCF_VRU_Buffer_L1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Buffer_L1
*    FCF_VRU_Buffer_L1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Buffer_L1 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Buffer_L1( boolean * pFCF_VRU_Buffer_L1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pFCF_VRU_Buffer_L1 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Buffer_L1_b1;
      * pFCF_VRU_Buffer_L1 = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVRU_FCF_VRU_BUFFER_L1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_CRC_L2
*
* FUNCTION ARGUMENTS:
*    uint32 * pFCF_VRU_CRC_L2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_CRC_L2
*    FCF_VRU_CRC_L2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_CRC_L2 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_CRC_L2( uint32 * pFCF_VRU_CRC_L2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pFCF_VRU_CRC_L2 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_CRC_L2_b32;
      * pFCF_VRU_CRC_L2 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Alert_L2
*
* FUNCTION ARGUMENTS:
*    COREFCFVRUFCFVRUAlertL2 * pFCF_VRU_Alert_L2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Alert_L2
*    FCF_VRU_Alert_L2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Alert_L2 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Alert_L2( COREFCFVRUFCFVRUAlertL2 * pFCF_VRU_Alert_L2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVRUFCFVRUAlertL2 signal_value;
   
   if( pFCF_VRU_Alert_L2 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Alert_L2_b16;
      * pFCF_VRU_Alert_L2 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Brake_Decel_Req_L2
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_VRU_Brake_Decel_Req_L2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Brake_Decel_Req_L2
*    FCF_VRU_Brake_Decel_Req_L2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Brake_Decel_Req_L2 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Brake_Decel_Req_L2( uint8 * pFCF_VRU_Brake_Decel_Req_L2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_VRU_Brake_Decel_Req_L2 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Brake_Decel_Req_L2_b8;
      * pFCF_VRU_Brake_Decel_Req_L2 = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVRU_FCF_VRU_BRAKE_DECEL_REQ_L2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_PED_ID_L2
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_VRU_PED_ID_L2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_PED_ID_L2
*    FCF_VRU_PED_ID_L2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_PED_ID_L2 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_PED_ID_L2( uint8 * pFCF_VRU_PED_ID_L2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_VRU_PED_ID_L2 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_PED_ID_L2_b8;
      * pFCF_VRU_PED_ID_L2 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Suppress_L2
*
* FUNCTION ARGUMENTS:
*    COREFCFVRUFCFVRUSuppressL2 * pFCF_VRU_Suppress_L2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Suppress_L2
*    FCF_VRU_Suppress_L2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Suppress_L2 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Suppress_L2( COREFCFVRUFCFVRUSuppressL2 * pFCF_VRU_Suppress_L2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVRUFCFVRUSuppressL2 signal_value;
   
   if( pFCF_VRU_Suppress_L2 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Suppress_L2_b6;
      * pFCF_VRU_Suppress_L2 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Safety_Suppressed_L2
*
* FUNCTION ARGUMENTS:
*    COREFCFVRUFCFVRUSafetySuppressedL2 * pFCF_VRU_Safety_Suppressed_L2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Safety_Suppressed_L2
*    FCF_VRU_Safety_Suppressed_L2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Safety_Suppressed_L2 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Safety_Suppressed_L2( COREFCFVRUFCFVRUSafetySuppressedL2 * pFCF_VRU_Safety_Suppressed_L2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVRUFCFVRUSafetySuppressedL2 signal_value;
   
   if( pFCF_VRU_Safety_Suppressed_L2 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Safety_Suppressed_L2_b1;
      * pFCF_VRU_Safety_Suppressed_L2 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Set_Type_L2
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_VRU_Set_Type_L2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Set_Type_L2
*    FCF_VRU_Set_Type_L2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Set_Type_L2 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Set_Type_L2( uint8 * pFCF_VRU_Set_Type_L2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_VRU_Set_Type_L2 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Set_Type_L2_b2;
      * pFCF_VRU_Set_Type_L2 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Curr_In_Path_L2
*
* FUNCTION ARGUMENTS:
*    COREFCFVRUFCFVRUCurrInPathL2 * pFCF_VRU_Curr_In_Path_L2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Curr_In_Path_L2
*    FCF_VRU_Curr_In_Path_L2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Curr_In_Path_L2 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Curr_In_Path_L2( COREFCFVRUFCFVRUCurrInPathL2 * pFCF_VRU_Curr_In_Path_L2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVRUFCFVRUCurrInPathL2 signal_value;
   
   if( pFCF_VRU_Curr_In_Path_L2 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Curr_In_Path_L2_b1;
      * pFCF_VRU_Curr_In_Path_L2 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Pred_In_Path_L2
*
* FUNCTION ARGUMENTS:
*    COREFCFVRUFCFVRUPredInPathL2 * pFCF_VRU_Pred_In_Path_L2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Pred_In_Path_L2
*    FCF_VRU_Pred_In_Path_L2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Pred_In_Path_L2 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Pred_In_Path_L2( COREFCFVRUFCFVRUPredInPathL2 * pFCF_VRU_Pred_In_Path_L2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVRUFCFVRUPredInPathL2 signal_value;
   
   if( pFCF_VRU_Pred_In_Path_L2 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Pred_In_Path_L2_b1;
      * pFCF_VRU_Pred_In_Path_L2 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_TTC_L2
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCF_VRU_TTC_L2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_TTC_L2
*    FCF_VRU_TTC_L2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_TTC_L2 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_TTC_L2( uint16 * pFCF_VRU_TTC_L2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCF_VRU_TTC_L2 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_TTC_L2_b10;
      * pFCF_VRU_TTC_L2 = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVRU_FCF_VRU_TTC_L2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_TTC_Thresh_L2
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCF_VRU_TTC_Thresh_L2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_TTC_Thresh_L2
*    FCF_VRU_TTC_Thresh_L2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_TTC_Thresh_L2 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_TTC_Thresh_L2( uint16 * pFCF_VRU_TTC_Thresh_L2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCF_VRU_TTC_Thresh_L2 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_TTC_Thresh_L2_b10;
      * pFCF_VRU_TTC_Thresh_L2 = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVRU_FCF_VRU_TTC_THRESH_L2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Buffer_L2
*
* FUNCTION ARGUMENTS:
*    boolean * pFCF_VRU_Buffer_L2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Buffer_L2
*    FCF_VRU_Buffer_L2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Buffer_L2 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Buffer_L2( boolean * pFCF_VRU_Buffer_L2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pFCF_VRU_Buffer_L2 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Buffer_L2_b1;
      * pFCF_VRU_Buffer_L2 = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVRU_FCF_VRU_BUFFER_L2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_CRC_L3
*
* FUNCTION ARGUMENTS:
*    uint32 * pFCF_VRU_CRC_L3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_CRC_L3
*    FCF_VRU_CRC_L3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_CRC_L3 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_CRC_L3( uint32 * pFCF_VRU_CRC_L3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pFCF_VRU_CRC_L3 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_CRC_L3_b32;
      * pFCF_VRU_CRC_L3 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Alert_L3
*
* FUNCTION ARGUMENTS:
*    COREFCFVRUFCFVRUAlertL3 * pFCF_VRU_Alert_L3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Alert_L3
*    FCF_VRU_Alert_L3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Alert_L3 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Alert_L3( COREFCFVRUFCFVRUAlertL3 * pFCF_VRU_Alert_L3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVRUFCFVRUAlertL3 signal_value;
   
   if( pFCF_VRU_Alert_L3 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Alert_L3_b16;
      * pFCF_VRU_Alert_L3 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Brake_Decel_Req_L3
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_VRU_Brake_Decel_Req_L3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Brake_Decel_Req_L3
*    FCF_VRU_Brake_Decel_Req_L3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Brake_Decel_Req_L3 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Brake_Decel_Req_L3( uint8 * pFCF_VRU_Brake_Decel_Req_L3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_VRU_Brake_Decel_Req_L3 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Brake_Decel_Req_L3_b8;
      * pFCF_VRU_Brake_Decel_Req_L3 = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVRU_FCF_VRU_BRAKE_DECEL_REQ_L3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_PED_ID_L3
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_VRU_PED_ID_L3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_PED_ID_L3
*    FCF_VRU_PED_ID_L3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_PED_ID_L3 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_PED_ID_L3( uint8 * pFCF_VRU_PED_ID_L3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_VRU_PED_ID_L3 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_PED_ID_L3_b8;
      * pFCF_VRU_PED_ID_L3 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Suppress_L3
*
* FUNCTION ARGUMENTS:
*    COREFCFVRUFCFVRUSuppressL3 * pFCF_VRU_Suppress_L3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Suppress_L3
*    FCF_VRU_Suppress_L3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Suppress_L3 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Suppress_L3( COREFCFVRUFCFVRUSuppressL3 * pFCF_VRU_Suppress_L3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVRUFCFVRUSuppressL3 signal_value;
   
   if( pFCF_VRU_Suppress_L3 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Suppress_L3_b6;
      * pFCF_VRU_Suppress_L3 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Safety_Suppressed_L3
*
* FUNCTION ARGUMENTS:
*    COREFCFVRUFCFVRUSafetySuppressedL3 * pFCF_VRU_Safety_Suppressed_L3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Safety_Suppressed_L3
*    FCF_VRU_Safety_Suppressed_L3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Safety_Suppressed_L3 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Safety_Suppressed_L3( COREFCFVRUFCFVRUSafetySuppressedL3 * pFCF_VRU_Safety_Suppressed_L3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVRUFCFVRUSafetySuppressedL3 signal_value;
   
   if( pFCF_VRU_Safety_Suppressed_L3 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Safety_Suppressed_L3_b1;
      * pFCF_VRU_Safety_Suppressed_L3 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Set_Type_L3
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_VRU_Set_Type_L3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Set_Type_L3
*    FCF_VRU_Set_Type_L3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Set_Type_L3 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Set_Type_L3( uint8 * pFCF_VRU_Set_Type_L3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_VRU_Set_Type_L3 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Set_Type_L3_b2;
      * pFCF_VRU_Set_Type_L3 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Curr_In_Path_L3
*
* FUNCTION ARGUMENTS:
*    COREFCFVRUFCFVRUCurrInPathL3 * pFCF_VRU_Curr_In_Path_L3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Curr_In_Path_L3
*    FCF_VRU_Curr_In_Path_L3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Curr_In_Path_L3 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Curr_In_Path_L3( COREFCFVRUFCFVRUCurrInPathL3 * pFCF_VRU_Curr_In_Path_L3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVRUFCFVRUCurrInPathL3 signal_value;
   
   if( pFCF_VRU_Curr_In_Path_L3 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Curr_In_Path_L3_b1;
      * pFCF_VRU_Curr_In_Path_L3 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Pred_In_Path_L3
*
* FUNCTION ARGUMENTS:
*    COREFCFVRUFCFVRUPredInPathL3 * pFCF_VRU_Pred_In_Path_L3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Pred_In_Path_L3
*    FCF_VRU_Pred_In_Path_L3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Pred_In_Path_L3 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Pred_In_Path_L3( COREFCFVRUFCFVRUPredInPathL3 * pFCF_VRU_Pred_In_Path_L3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVRUFCFVRUPredInPathL3 signal_value;
   
   if( pFCF_VRU_Pred_In_Path_L3 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Pred_In_Path_L3_b1;
      * pFCF_VRU_Pred_In_Path_L3 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_TTC_L3
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCF_VRU_TTC_L3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_TTC_L3
*    FCF_VRU_TTC_L3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_TTC_L3 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_TTC_L3( uint16 * pFCF_VRU_TTC_L3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCF_VRU_TTC_L3 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_TTC_L3_b10;
      * pFCF_VRU_TTC_L3 = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVRU_FCF_VRU_TTC_L3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_TTC_Thresh_L3
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCF_VRU_TTC_Thresh_L3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_TTC_Thresh_L3
*    FCF_VRU_TTC_Thresh_L3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_TTC_Thresh_L3 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_TTC_Thresh_L3( uint16 * pFCF_VRU_TTC_Thresh_L3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCF_VRU_TTC_Thresh_L3 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_TTC_Thresh_L3_b10;
      * pFCF_VRU_TTC_Thresh_L3 = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVRU_FCF_VRU_TTC_THRESH_L3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Buffer_L3
*
* FUNCTION ARGUMENTS:
*    boolean * pFCF_VRU_Buffer_L3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Buffer_L3
*    FCF_VRU_Buffer_L3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Buffer_L3 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Buffer_L3( boolean * pFCF_VRU_Buffer_L3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pFCF_VRU_Buffer_L3 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Buffer_L3_b1;
      * pFCF_VRU_Buffer_L3 = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVRU_FCF_VRU_BUFFER_L3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_CRC_L4
*
* FUNCTION ARGUMENTS:
*    uint32 * pFCF_VRU_CRC_L4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_CRC_L4
*    FCF_VRU_CRC_L4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_CRC_L4 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_CRC_L4( uint32 * pFCF_VRU_CRC_L4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pFCF_VRU_CRC_L4 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_CRC_L4_b32;
      * pFCF_VRU_CRC_L4 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Alert_L4
*
* FUNCTION ARGUMENTS:
*    COREFCFVRUFCFVRUAlertL4 * pFCF_VRU_Alert_L4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Alert_L4
*    FCF_VRU_Alert_L4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Alert_L4 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Alert_L4( COREFCFVRUFCFVRUAlertL4 * pFCF_VRU_Alert_L4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVRUFCFVRUAlertL4 signal_value;
   
   if( pFCF_VRU_Alert_L4 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Alert_L4_b16;
      * pFCF_VRU_Alert_L4 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Brake_Decel_Req_L4
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_VRU_Brake_Decel_Req_L4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Brake_Decel_Req_L4
*    FCF_VRU_Brake_Decel_Req_L4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Brake_Decel_Req_L4 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Brake_Decel_Req_L4( uint8 * pFCF_VRU_Brake_Decel_Req_L4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_VRU_Brake_Decel_Req_L4 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Brake_Decel_Req_L4_b8;
      * pFCF_VRU_Brake_Decel_Req_L4 = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVRU_FCF_VRU_BRAKE_DECEL_REQ_L4_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_PED_ID_L4
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_VRU_PED_ID_L4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_PED_ID_L4
*    FCF_VRU_PED_ID_L4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_PED_ID_L4 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_PED_ID_L4( uint8 * pFCF_VRU_PED_ID_L4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_VRU_PED_ID_L4 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_PED_ID_L4_b8;
      * pFCF_VRU_PED_ID_L4 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Suppress_L4
*
* FUNCTION ARGUMENTS:
*    COREFCFVRUFCFVRUSuppressL4 * pFCF_VRU_Suppress_L4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Suppress_L4
*    FCF_VRU_Suppress_L4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Suppress_L4 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Suppress_L4( COREFCFVRUFCFVRUSuppressL4 * pFCF_VRU_Suppress_L4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVRUFCFVRUSuppressL4 signal_value;
   
   if( pFCF_VRU_Suppress_L4 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Suppress_L4_b6;
      * pFCF_VRU_Suppress_L4 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Safety_Suppressed_L4
*
* FUNCTION ARGUMENTS:
*    COREFCFVRUFCFVRUSafetySuppressedL4 * pFCF_VRU_Safety_Suppressed_L4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Safety_Suppressed_L4
*    FCF_VRU_Safety_Suppressed_L4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Safety_Suppressed_L4 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Safety_Suppressed_L4( COREFCFVRUFCFVRUSafetySuppressedL4 * pFCF_VRU_Safety_Suppressed_L4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVRUFCFVRUSafetySuppressedL4 signal_value;
   
   if( pFCF_VRU_Safety_Suppressed_L4 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Safety_Suppressed_L4_b1;
      * pFCF_VRU_Safety_Suppressed_L4 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Set_Type_L4
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_VRU_Set_Type_L4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Set_Type_L4
*    FCF_VRU_Set_Type_L4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Set_Type_L4 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Set_Type_L4( uint8 * pFCF_VRU_Set_Type_L4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_VRU_Set_Type_L4 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Set_Type_L4_b2;
      * pFCF_VRU_Set_Type_L4 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Curr_In_Path_L4
*
* FUNCTION ARGUMENTS:
*    COREFCFVRUFCFVRUCurrInPathL4 * pFCF_VRU_Curr_In_Path_L4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Curr_In_Path_L4
*    FCF_VRU_Curr_In_Path_L4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Curr_In_Path_L4 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Curr_In_Path_L4( COREFCFVRUFCFVRUCurrInPathL4 * pFCF_VRU_Curr_In_Path_L4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVRUFCFVRUCurrInPathL4 signal_value;
   
   if( pFCF_VRU_Curr_In_Path_L4 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Curr_In_Path_L4_b1;
      * pFCF_VRU_Curr_In_Path_L4 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Pred_In_Path_L4
*
* FUNCTION ARGUMENTS:
*    COREFCFVRUFCFVRUPredInPathL4 * pFCF_VRU_Pred_In_Path_L4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Pred_In_Path_L4
*    FCF_VRU_Pred_In_Path_L4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Pred_In_Path_L4 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Pred_In_Path_L4( COREFCFVRUFCFVRUPredInPathL4 * pFCF_VRU_Pred_In_Path_L4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVRUFCFVRUPredInPathL4 signal_value;
   
   if( pFCF_VRU_Pred_In_Path_L4 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Pred_In_Path_L4_b1;
      * pFCF_VRU_Pred_In_Path_L4 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_TTC_L4
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCF_VRU_TTC_L4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_TTC_L4
*    FCF_VRU_TTC_L4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_TTC_L4 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_TTC_L4( uint16 * pFCF_VRU_TTC_L4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCF_VRU_TTC_L4 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_TTC_L4_b10;
      * pFCF_VRU_TTC_L4 = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVRU_FCF_VRU_TTC_L4_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_TTC_Thresh_L4
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCF_VRU_TTC_Thresh_L4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_TTC_Thresh_L4
*    FCF_VRU_TTC_Thresh_L4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_TTC_Thresh_L4 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_TTC_Thresh_L4( uint16 * pFCF_VRU_TTC_Thresh_L4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCF_VRU_TTC_Thresh_L4 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_TTC_Thresh_L4_b10;
      * pFCF_VRU_TTC_Thresh_L4 = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVRU_FCF_VRU_TTC_THRESH_L4_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Buffer_L4
*
* FUNCTION ARGUMENTS:
*    boolean * pFCF_VRU_Buffer_L4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Buffer_L4
*    FCF_VRU_Buffer_L4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Buffer_L4 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Buffer_L4( boolean * pFCF_VRU_Buffer_L4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pFCF_VRU_Buffer_L4 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Buffer_L4_b1;
      * pFCF_VRU_Buffer_L4 = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVRU_FCF_VRU_BUFFER_L4_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_CRC_L5
*
* FUNCTION ARGUMENTS:
*    uint32 * pFCF_VRU_CRC_L5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_CRC_L5
*    FCF_VRU_CRC_L5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_CRC_L5 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_CRC_L5( uint32 * pFCF_VRU_CRC_L5 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pFCF_VRU_CRC_L5 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_CRC_L5_b32;
      * pFCF_VRU_CRC_L5 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Alert_L5
*
* FUNCTION ARGUMENTS:
*    COREFCFVRUFCFVRUAlertL5 * pFCF_VRU_Alert_L5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Alert_L5
*    FCF_VRU_Alert_L5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Alert_L5 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Alert_L5( COREFCFVRUFCFVRUAlertL5 * pFCF_VRU_Alert_L5 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVRUFCFVRUAlertL5 signal_value;
   
   if( pFCF_VRU_Alert_L5 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Alert_L5_b16;
      * pFCF_VRU_Alert_L5 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Brake_Decel_Req_L5
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_VRU_Brake_Decel_Req_L5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Brake_Decel_Req_L5
*    FCF_VRU_Brake_Decel_Req_L5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Brake_Decel_Req_L5 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Brake_Decel_Req_L5( uint8 * pFCF_VRU_Brake_Decel_Req_L5 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_VRU_Brake_Decel_Req_L5 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Brake_Decel_Req_L5_b8;
      * pFCF_VRU_Brake_Decel_Req_L5 = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVRU_FCF_VRU_BRAKE_DECEL_REQ_L5_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_PED_ID_L5
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_VRU_PED_ID_L5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_PED_ID_L5
*    FCF_VRU_PED_ID_L5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_PED_ID_L5 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_PED_ID_L5( uint8 * pFCF_VRU_PED_ID_L5 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_VRU_PED_ID_L5 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_PED_ID_L5_b8;
      * pFCF_VRU_PED_ID_L5 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Suppress_L5
*
* FUNCTION ARGUMENTS:
*    COREFCFVRUFCFVRUSuppressL5 * pFCF_VRU_Suppress_L5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Suppress_L5
*    FCF_VRU_Suppress_L5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Suppress_L5 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Suppress_L5( COREFCFVRUFCFVRUSuppressL5 * pFCF_VRU_Suppress_L5 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVRUFCFVRUSuppressL5 signal_value;
   
   if( pFCF_VRU_Suppress_L5 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Suppress_L5_b6;
      * pFCF_VRU_Suppress_L5 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Safety_Suppressed_L5
*
* FUNCTION ARGUMENTS:
*    COREFCFVRUFCFVRUSafetySuppressedL5 * pFCF_VRU_Safety_Suppressed_L5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Safety_Suppressed_L5
*    FCF_VRU_Safety_Suppressed_L5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Safety_Suppressed_L5 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Safety_Suppressed_L5( COREFCFVRUFCFVRUSafetySuppressedL5 * pFCF_VRU_Safety_Suppressed_L5 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVRUFCFVRUSafetySuppressedL5 signal_value;
   
   if( pFCF_VRU_Safety_Suppressed_L5 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Safety_Suppressed_L5_b1;
      * pFCF_VRU_Safety_Suppressed_L5 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Set_Type_L5
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_VRU_Set_Type_L5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Set_Type_L5
*    FCF_VRU_Set_Type_L5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Set_Type_L5 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Set_Type_L5( uint8 * pFCF_VRU_Set_Type_L5 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_VRU_Set_Type_L5 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Set_Type_L5_b2;
      * pFCF_VRU_Set_Type_L5 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Curr_In_Path_L5
*
* FUNCTION ARGUMENTS:
*    COREFCFVRUFCFVRUCurrInPathL5 * pFCF_VRU_Curr_In_Path_L5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Curr_In_Path_L5
*    FCF_VRU_Curr_In_Path_L5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Curr_In_Path_L5 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Curr_In_Path_L5( COREFCFVRUFCFVRUCurrInPathL5 * pFCF_VRU_Curr_In_Path_L5 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVRUFCFVRUCurrInPathL5 signal_value;
   
   if( pFCF_VRU_Curr_In_Path_L5 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Curr_In_Path_L5_b1;
      * pFCF_VRU_Curr_In_Path_L5 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Pred_In_Path_L5
*
* FUNCTION ARGUMENTS:
*    COREFCFVRUFCFVRUPredInPathL5 * pFCF_VRU_Pred_In_Path_L5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Pred_In_Path_L5
*    FCF_VRU_Pred_In_Path_L5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Pred_In_Path_L5 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Pred_In_Path_L5( COREFCFVRUFCFVRUPredInPathL5 * pFCF_VRU_Pred_In_Path_L5 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVRUFCFVRUPredInPathL5 signal_value;
   
   if( pFCF_VRU_Pred_In_Path_L5 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Pred_In_Path_L5_b1;
      * pFCF_VRU_Pred_In_Path_L5 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_TTC_L5
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCF_VRU_TTC_L5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_TTC_L5
*    FCF_VRU_TTC_L5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_TTC_L5 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_TTC_L5( uint16 * pFCF_VRU_TTC_L5 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCF_VRU_TTC_L5 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_TTC_L5_b10;
      * pFCF_VRU_TTC_L5 = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVRU_FCF_VRU_TTC_L5_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_TTC_Thresh_L5
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCF_VRU_TTC_Thresh_L5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_TTC_Thresh_L5
*    FCF_VRU_TTC_Thresh_L5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_TTC_Thresh_L5 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_TTC_Thresh_L5( uint16 * pFCF_VRU_TTC_Thresh_L5 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCF_VRU_TTC_Thresh_L5 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_TTC_Thresh_L5_b10;
      * pFCF_VRU_TTC_Thresh_L5 = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVRU_FCF_VRU_TTC_THRESH_L5_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Buffer_L5
*
* FUNCTION ARGUMENTS:
*    boolean * pFCF_VRU_Buffer_L5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Buffer_L5
*    FCF_VRU_Buffer_L5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Buffer_L5 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Buffer_L5( boolean * pFCF_VRU_Buffer_L5 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pFCF_VRU_Buffer_L5 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Buffer_L5_b1;
      * pFCF_VRU_Buffer_L5 = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVRU_FCF_VRU_BUFFER_L5_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_CRC_L6
*
* FUNCTION ARGUMENTS:
*    uint32 * pFCF_VRU_CRC_L6 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_CRC_L6
*    FCF_VRU_CRC_L6 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_CRC_L6 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_CRC_L6( uint32 * pFCF_VRU_CRC_L6 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pFCF_VRU_CRC_L6 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_CRC_L6_b32;
      * pFCF_VRU_CRC_L6 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Alert_L6
*
* FUNCTION ARGUMENTS:
*    COREFCFVRUFCFVRUAlertL6 * pFCF_VRU_Alert_L6 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Alert_L6
*    FCF_VRU_Alert_L6 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Alert_L6 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Alert_L6( COREFCFVRUFCFVRUAlertL6 * pFCF_VRU_Alert_L6 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVRUFCFVRUAlertL6 signal_value;
   
   if( pFCF_VRU_Alert_L6 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Alert_L6_b16;
      * pFCF_VRU_Alert_L6 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Brake_Decel_Req_L6
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_VRU_Brake_Decel_Req_L6 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Brake_Decel_Req_L6
*    FCF_VRU_Brake_Decel_Req_L6 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Brake_Decel_Req_L6 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Brake_Decel_Req_L6( uint8 * pFCF_VRU_Brake_Decel_Req_L6 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_VRU_Brake_Decel_Req_L6 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Brake_Decel_Req_L6_b8;
      * pFCF_VRU_Brake_Decel_Req_L6 = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVRU_FCF_VRU_BRAKE_DECEL_REQ_L6_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_PED_ID_L6
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_VRU_PED_ID_L6 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_PED_ID_L6
*    FCF_VRU_PED_ID_L6 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_PED_ID_L6 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_PED_ID_L6( uint8 * pFCF_VRU_PED_ID_L6 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_VRU_PED_ID_L6 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_PED_ID_L6_b8;
      * pFCF_VRU_PED_ID_L6 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Suppress_L6
*
* FUNCTION ARGUMENTS:
*    COREFCFVRUFCFVRUSuppressL6 * pFCF_VRU_Suppress_L6 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Suppress_L6
*    FCF_VRU_Suppress_L6 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Suppress_L6 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Suppress_L6( COREFCFVRUFCFVRUSuppressL6 * pFCF_VRU_Suppress_L6 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVRUFCFVRUSuppressL6 signal_value;
   
   if( pFCF_VRU_Suppress_L6 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Suppress_L6_b6;
      * pFCF_VRU_Suppress_L6 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Safety_Suppressed_L6
*
* FUNCTION ARGUMENTS:
*    COREFCFVRUFCFVRUSafetySuppressedL6 * pFCF_VRU_Safety_Suppressed_L6 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Safety_Suppressed_L6
*    FCF_VRU_Safety_Suppressed_L6 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Safety_Suppressed_L6 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Safety_Suppressed_L6( COREFCFVRUFCFVRUSafetySuppressedL6 * pFCF_VRU_Safety_Suppressed_L6 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVRUFCFVRUSafetySuppressedL6 signal_value;
   
   if( pFCF_VRU_Safety_Suppressed_L6 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Safety_Suppressed_L6_b1;
      * pFCF_VRU_Safety_Suppressed_L6 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Set_Type_L6
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_VRU_Set_Type_L6 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Set_Type_L6
*    FCF_VRU_Set_Type_L6 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Set_Type_L6 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Set_Type_L6( uint8 * pFCF_VRU_Set_Type_L6 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_VRU_Set_Type_L6 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Set_Type_L6_b2;
      * pFCF_VRU_Set_Type_L6 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Curr_In_Path_L6
*
* FUNCTION ARGUMENTS:
*    COREFCFVRUFCFVRUCurrInPathL6 * pFCF_VRU_Curr_In_Path_L6 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Curr_In_Path_L6
*    FCF_VRU_Curr_In_Path_L6 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Curr_In_Path_L6 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Curr_In_Path_L6( COREFCFVRUFCFVRUCurrInPathL6 * pFCF_VRU_Curr_In_Path_L6 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVRUFCFVRUCurrInPathL6 signal_value;
   
   if( pFCF_VRU_Curr_In_Path_L6 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Curr_In_Path_L6_b1;
      * pFCF_VRU_Curr_In_Path_L6 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Pred_In_Path_L6
*
* FUNCTION ARGUMENTS:
*    COREFCFVRUFCFVRUPredInPathL6 * pFCF_VRU_Pred_In_Path_L6 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Pred_In_Path_L6
*    FCF_VRU_Pred_In_Path_L6 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Pred_In_Path_L6 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Pred_In_Path_L6( COREFCFVRUFCFVRUPredInPathL6 * pFCF_VRU_Pred_In_Path_L6 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVRUFCFVRUPredInPathL6 signal_value;
   
   if( pFCF_VRU_Pred_In_Path_L6 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Pred_In_Path_L6_b1;
      * pFCF_VRU_Pred_In_Path_L6 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_TTC_L6
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCF_VRU_TTC_L6 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_TTC_L6
*    FCF_VRU_TTC_L6 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_TTC_L6 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_TTC_L6( uint16 * pFCF_VRU_TTC_L6 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCF_VRU_TTC_L6 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_TTC_L6_b10;
      * pFCF_VRU_TTC_L6 = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVRU_FCF_VRU_TTC_L6_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_TTC_Thresh_L6
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCF_VRU_TTC_Thresh_L6 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_TTC_Thresh_L6
*    FCF_VRU_TTC_Thresh_L6 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_TTC_Thresh_L6 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_TTC_Thresh_L6( uint16 * pFCF_VRU_TTC_Thresh_L6 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCF_VRU_TTC_Thresh_L6 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_TTC_Thresh_L6_b10;
      * pFCF_VRU_TTC_Thresh_L6 = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVRU_FCF_VRU_TTC_THRESH_L6_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Buffer_L6
*
* FUNCTION ARGUMENTS:
*    boolean * pFCF_VRU_Buffer_L6 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Buffer_L6
*    FCF_VRU_Buffer_L6 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Buffer_L6 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Buffer_L6( boolean * pFCF_VRU_Buffer_L6 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pFCF_VRU_Buffer_L6 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Buffer_L6_b1;
      * pFCF_VRU_Buffer_L6 = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVRU_FCF_VRU_BUFFER_L6_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_CRC_L7
*
* FUNCTION ARGUMENTS:
*    uint32 * pFCF_VRU_CRC_L7 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_CRC_L7
*    FCF_VRU_CRC_L7 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_CRC_L7 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_CRC_L7( uint32 * pFCF_VRU_CRC_L7 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pFCF_VRU_CRC_L7 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_CRC_L7_b32;
      * pFCF_VRU_CRC_L7 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Alert_L7
*
* FUNCTION ARGUMENTS:
*    COREFCFVRUFCFVRUAlertL7 * pFCF_VRU_Alert_L7 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Alert_L7
*    FCF_VRU_Alert_L7 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Alert_L7 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Alert_L7( COREFCFVRUFCFVRUAlertL7 * pFCF_VRU_Alert_L7 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVRUFCFVRUAlertL7 signal_value;
   
   if( pFCF_VRU_Alert_L7 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Alert_L7_b16;
      * pFCF_VRU_Alert_L7 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Brake_Decel_Req_L7
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_VRU_Brake_Decel_Req_L7 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Brake_Decel_Req_L7
*    FCF_VRU_Brake_Decel_Req_L7 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Brake_Decel_Req_L7 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Brake_Decel_Req_L7( uint8 * pFCF_VRU_Brake_Decel_Req_L7 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_VRU_Brake_Decel_Req_L7 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Brake_Decel_Req_L7_b8;
      * pFCF_VRU_Brake_Decel_Req_L7 = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVRU_FCF_VRU_BRAKE_DECEL_REQ_L7_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_PED_ID_L7
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_VRU_PED_ID_L7 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_PED_ID_L7
*    FCF_VRU_PED_ID_L7 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_PED_ID_L7 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_PED_ID_L7( uint8 * pFCF_VRU_PED_ID_L7 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_VRU_PED_ID_L7 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_PED_ID_L7_b8;
      * pFCF_VRU_PED_ID_L7 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Suppress_L7
*
* FUNCTION ARGUMENTS:
*    COREFCFVRUFCFVRUSuppressL7 * pFCF_VRU_Suppress_L7 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Suppress_L7
*    FCF_VRU_Suppress_L7 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Suppress_L7 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Suppress_L7( COREFCFVRUFCFVRUSuppressL7 * pFCF_VRU_Suppress_L7 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVRUFCFVRUSuppressL7 signal_value;
   
   if( pFCF_VRU_Suppress_L7 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Suppress_L7_b6;
      * pFCF_VRU_Suppress_L7 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Safety_Suppressed_L7
*
* FUNCTION ARGUMENTS:
*    COREFCFVRUFCFVRUSafetySuppressedL7 * pFCF_VRU_Safety_Suppressed_L7 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Safety_Suppressed_L7
*    FCF_VRU_Safety_Suppressed_L7 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Safety_Suppressed_L7 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Safety_Suppressed_L7( COREFCFVRUFCFVRUSafetySuppressedL7 * pFCF_VRU_Safety_Suppressed_L7 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVRUFCFVRUSafetySuppressedL7 signal_value;
   
   if( pFCF_VRU_Safety_Suppressed_L7 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Safety_Suppressed_L7_b1;
      * pFCF_VRU_Safety_Suppressed_L7 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Set_Type_L7
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_VRU_Set_Type_L7 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Set_Type_L7
*    FCF_VRU_Set_Type_L7 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Set_Type_L7 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Set_Type_L7( uint8 * pFCF_VRU_Set_Type_L7 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_VRU_Set_Type_L7 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Set_Type_L7_b2;
      * pFCF_VRU_Set_Type_L7 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Curr_In_Path_L7
*
* FUNCTION ARGUMENTS:
*    COREFCFVRUFCFVRUCurrInPathL7 * pFCF_VRU_Curr_In_Path_L7 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Curr_In_Path_L7
*    FCF_VRU_Curr_In_Path_L7 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Curr_In_Path_L7 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Curr_In_Path_L7( COREFCFVRUFCFVRUCurrInPathL7 * pFCF_VRU_Curr_In_Path_L7 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVRUFCFVRUCurrInPathL7 signal_value;
   
   if( pFCF_VRU_Curr_In_Path_L7 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Curr_In_Path_L7_b1;
      * pFCF_VRU_Curr_In_Path_L7 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Pred_In_Path_L7
*
* FUNCTION ARGUMENTS:
*    COREFCFVRUFCFVRUPredInPathL7 * pFCF_VRU_Pred_In_Path_L7 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Pred_In_Path_L7
*    FCF_VRU_Pred_In_Path_L7 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Pred_In_Path_L7 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Pred_In_Path_L7( COREFCFVRUFCFVRUPredInPathL7 * pFCF_VRU_Pred_In_Path_L7 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVRUFCFVRUPredInPathL7 signal_value;
   
   if( pFCF_VRU_Pred_In_Path_L7 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Pred_In_Path_L7_b1;
      * pFCF_VRU_Pred_In_Path_L7 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_TTC_L7
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCF_VRU_TTC_L7 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_TTC_L7
*    FCF_VRU_TTC_L7 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_TTC_L7 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_TTC_L7( uint16 * pFCF_VRU_TTC_L7 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCF_VRU_TTC_L7 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_TTC_L7_b10;
      * pFCF_VRU_TTC_L7 = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVRU_FCF_VRU_TTC_L7_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_TTC_Thresh_L7
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCF_VRU_TTC_Thresh_L7 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_TTC_Thresh_L7
*    FCF_VRU_TTC_Thresh_L7 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_TTC_Thresh_L7 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_TTC_Thresh_L7( uint16 * pFCF_VRU_TTC_Thresh_L7 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCF_VRU_TTC_Thresh_L7 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_TTC_Thresh_L7_b10;
      * pFCF_VRU_TTC_Thresh_L7 = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVRU_FCF_VRU_TTC_THRESH_L7_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Buffer_L7
*
* FUNCTION ARGUMENTS:
*    boolean * pFCF_VRU_Buffer_L7 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Buffer_L7
*    FCF_VRU_Buffer_L7 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Buffer_L7 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Buffer_L7( boolean * pFCF_VRU_Buffer_L7 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pFCF_VRU_Buffer_L7 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Buffer_L7_b1;
      * pFCF_VRU_Buffer_L7 = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVRU_FCF_VRU_BUFFER_L7_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_CRC_L8
*
* FUNCTION ARGUMENTS:
*    uint32 * pFCF_VRU_CRC_L8 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_CRC_L8
*    FCF_VRU_CRC_L8 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_CRC_L8 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_CRC_L8( uint32 * pFCF_VRU_CRC_L8 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pFCF_VRU_CRC_L8 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_CRC_L8_b32;
      * pFCF_VRU_CRC_L8 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Alert_L8
*
* FUNCTION ARGUMENTS:
*    COREFCFVRUFCFVRUAlertL8 * pFCF_VRU_Alert_L8 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Alert_L8
*    FCF_VRU_Alert_L8 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Alert_L8 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Alert_L8( COREFCFVRUFCFVRUAlertL8 * pFCF_VRU_Alert_L8 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVRUFCFVRUAlertL8 signal_value;
   
   if( pFCF_VRU_Alert_L8 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Alert_L8_b16;
      * pFCF_VRU_Alert_L8 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Brake_Decel_Req_L8
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_VRU_Brake_Decel_Req_L8 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Brake_Decel_Req_L8
*    FCF_VRU_Brake_Decel_Req_L8 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Brake_Decel_Req_L8 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Brake_Decel_Req_L8( uint8 * pFCF_VRU_Brake_Decel_Req_L8 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_VRU_Brake_Decel_Req_L8 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Brake_Decel_Req_L8_b8;
      * pFCF_VRU_Brake_Decel_Req_L8 = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVRU_FCF_VRU_BRAKE_DECEL_REQ_L8_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_PED_ID_L8
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_VRU_PED_ID_L8 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_PED_ID_L8
*    FCF_VRU_PED_ID_L8 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_PED_ID_L8 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_PED_ID_L8( uint8 * pFCF_VRU_PED_ID_L8 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_VRU_PED_ID_L8 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_PED_ID_L8_b8;
      * pFCF_VRU_PED_ID_L8 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Suppress_L8
*
* FUNCTION ARGUMENTS:
*    COREFCFVRUFCFVRUSuppressL8 * pFCF_VRU_Suppress_L8 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Suppress_L8
*    FCF_VRU_Suppress_L8 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Suppress_L8 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Suppress_L8( COREFCFVRUFCFVRUSuppressL8 * pFCF_VRU_Suppress_L8 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVRUFCFVRUSuppressL8 signal_value;
   
   if( pFCF_VRU_Suppress_L8 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Suppress_L8_b6;
      * pFCF_VRU_Suppress_L8 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Safety_Suppressed_L8
*
* FUNCTION ARGUMENTS:
*    COREFCFVRUFCFVRUSafetySuppressedL8 * pFCF_VRU_Safety_Suppressed_L8 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Safety_Suppressed_L8
*    FCF_VRU_Safety_Suppressed_L8 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Safety_Suppressed_L8 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Safety_Suppressed_L8( COREFCFVRUFCFVRUSafetySuppressedL8 * pFCF_VRU_Safety_Suppressed_L8 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVRUFCFVRUSafetySuppressedL8 signal_value;
   
   if( pFCF_VRU_Safety_Suppressed_L8 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Safety_Suppressed_L8_b1;
      * pFCF_VRU_Safety_Suppressed_L8 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Set_Type_L8
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_VRU_Set_Type_L8 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Set_Type_L8
*    FCF_VRU_Set_Type_L8 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Set_Type_L8 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Set_Type_L8( uint8 * pFCF_VRU_Set_Type_L8 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_VRU_Set_Type_L8 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Set_Type_L8_b2;
      * pFCF_VRU_Set_Type_L8 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Curr_In_Path_L8
*
* FUNCTION ARGUMENTS:
*    COREFCFVRUFCFVRUCurrInPathL8 * pFCF_VRU_Curr_In_Path_L8 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Curr_In_Path_L8
*    FCF_VRU_Curr_In_Path_L8 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Curr_In_Path_L8 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Curr_In_Path_L8( COREFCFVRUFCFVRUCurrInPathL8 * pFCF_VRU_Curr_In_Path_L8 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVRUFCFVRUCurrInPathL8 signal_value;
   
   if( pFCF_VRU_Curr_In_Path_L8 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Curr_In_Path_L8_b1;
      * pFCF_VRU_Curr_In_Path_L8 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Pred_In_Path_L8
*
* FUNCTION ARGUMENTS:
*    COREFCFVRUFCFVRUPredInPathL8 * pFCF_VRU_Pred_In_Path_L8 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Pred_In_Path_L8
*    FCF_VRU_Pred_In_Path_L8 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Pred_In_Path_L8 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Pred_In_Path_L8( COREFCFVRUFCFVRUPredInPathL8 * pFCF_VRU_Pred_In_Path_L8 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVRUFCFVRUPredInPathL8 signal_value;
   
   if( pFCF_VRU_Pred_In_Path_L8 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Pred_In_Path_L8_b1;
      * pFCF_VRU_Pred_In_Path_L8 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_TTC_L8
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCF_VRU_TTC_L8 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_TTC_L8
*    FCF_VRU_TTC_L8 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_TTC_L8 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_TTC_L8( uint16 * pFCF_VRU_TTC_L8 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCF_VRU_TTC_L8 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_TTC_L8_b10;
      * pFCF_VRU_TTC_L8 = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVRU_FCF_VRU_TTC_L8_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_TTC_Thresh_L8
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCF_VRU_TTC_Thresh_L8 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_TTC_Thresh_L8
*    FCF_VRU_TTC_Thresh_L8 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_TTC_Thresh_L8 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_TTC_Thresh_L8( uint16 * pFCF_VRU_TTC_Thresh_L8 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCF_VRU_TTC_Thresh_L8 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_TTC_Thresh_L8_b10;
      * pFCF_VRU_TTC_Thresh_L8 = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVRU_FCF_VRU_TTC_THRESH_L8_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVRU_FCF_VRU_Buffer_L8
*
* FUNCTION ARGUMENTS:
*    boolean * pFCF_VRU_Buffer_L8 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VRU_Buffer_L8
*    FCF_VRU_Buffer_L8 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VRU_Buffer_L8 signal value of Core_FCF_VRU_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVRU_FCF_VRU_Buffer_L8( boolean * pFCF_VRU_Buffer_L8 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pFCF_VRU_Buffer_L8 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVRU_ParamsApp_s.FCF_VRU_Buffer_L8_b1;
      * pFCF_VRU_Buffer_L8 = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVRU_FCF_VRU_BUFFER_L8_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

