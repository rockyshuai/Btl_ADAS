#ifndef _EYEQMSG_CORECALSPCPROCESS_H_
#define _EYEQMSG_CORECALSPCPROCESS_H_

/*****************************************************************************
                  Included header files
*****************************************************************************/
#include <Std_Types.h>

/*****************************************************************************
                  Include files
*****************************************************************************/
/*****************************************************************************
                  Exported symbolic constants
*****************************************************************************/

/* Datagram message ID */
#define C_EYEQMSG_CORECALSPC_MSG_ID                           ( 0x65U )

/* Datagram message lengths */
#define C_EYEQMSG_CORECALSPC_MSG_LEN                          ( sizeof(EYEQMSG_CORECALSPC_Params_t) )

/* Protocol ENUMs */

/* MCU output messages */

/* Core_Calibration_SPC_protocol Enums */
/* CLB_SPC_Baseline_Roll_sb32 signal Min & Max range limits */
#define C_EYEQMSG_CORECALSPC_CLB_SPC_BASELINE_ROLL_RMIN       ( -0.05 )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_BASELINE_ROLL_RMAX       ( 0.05 )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_BASELINE_ROLL_NUMR       ( 1 )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_BASELINE_ROLL_DEMNR      ( 1 )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_BASELINE_ROLL_OFFSET     ( 0U )

/* CLB_SPC_Baseline_Height_b16 signal Min & Max range limits */
#define C_EYEQMSG_CORECALSPC_CLB_SPC_BASELINE_HEIGHT_RMIN     ( 50U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_BASELINE_HEIGHT_RMAX     ( 300U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_BASELINE_HEIGHT_NUMR     ( 1U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_BASELINE_HEIGHT_DEMNR    ( 100U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_BASELINE_HEIGHT_OFFSET   ( 0U )

/* CLB_SPC_Baseline_Pitch_b16 signal Min & Max range limits */
#define C_EYEQMSG_CORECALSPC_CLB_SPC_BASELINE_PITCH_RMIN      ( 0U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_BASELINE_PITCH_RMAX      ( 1000U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_BASELINE_PITCH_NUMR      ( 1 )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_BASELINE_PITCH_DEMNR     ( 1 )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_BASELINE_PITCH_OFFSET    ( -500 )

/* CLB_SPC_Baseline_Yaw_b16 signal Min & Max range limits */
#define C_EYEQMSG_CORECALSPC_CLB_SPC_BASELINE_YAW_RMIN        ( 0U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_BASELINE_YAW_RMAX        ( 1000U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_BASELINE_YAW_NUMR        ( 1 )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_BASELINE_YAW_DEMNR       ( 1 )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_BASELINE_YAW_OFFSET      ( -500 )

/* CLB_SPC_Invalid_Reason_b8 signal Enums */
typedef uint8 CORECALSPCCLBSPCInvalidReason;
#define C_EYEQMSG_CORECALSPC_CLB_SPC_INVALID_REASON_MIN_SPEED ( CORECALSPCCLBSPCInvalidReason ) ( 0U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_INVALID_REASON_MAX_SPEED ( CORECALSPCCLBSPCInvalidReason ) ( 1U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_INVALID_REASON_MAX_ACCELERATION ( CORECALSPCCLBSPCInvalidReason ) ( 2U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_INVALID_REASON_MAX_YAWRATE ( CORECALSPCCLBSPCInvalidReason ) ( 3U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_INVALID_REASON_MIN_RADIUS ( CORECALSPCCLBSPCInvalidReason ) ( 4U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_INVALID_REASON_INTERNAL  ( CORECALSPCCLBSPCInvalidReason ) ( 5U )

/* CLB_SPC_Invalid_Reason_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORECALSPC_CLB_SPC_INVALID_REASON_RMIN      ( 0U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_INVALID_REASON_RMAX      ( 255U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_INVALID_REASON_NUMR      ( 1U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_INVALID_REASON_DEMNR     ( 1U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_INVALID_REASON_OFFSET    ( 0U )

/* CLB_SPC_Invalid_Signal_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORECALSPC_CLB_SPC_INVALID_SIGNAL_RMIN      ( 0U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_INVALID_SIGNAL_RMAX      ( 255U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_INVALID_SIGNAL_NUMR      ( 1U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_INVALID_SIGNAL_DEMNR     ( 1U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_INVALID_SIGNAL_OFFSET    ( 0U )

/* Reserved_2_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORECALSPC_RESERVED_2_RMIN                  ( 0U )
#define C_EYEQMSG_CORECALSPC_RESERVED_2_RMAX                  ( 0U )
#define C_EYEQMSG_CORECALSPC_RESERVED_2_NUMR                  ( 1U )
#define C_EYEQMSG_CORECALSPC_RESERVED_2_DEMNR                 ( 1U )
#define C_EYEQMSG_CORECALSPC_RESERVED_2_OFFSET                ( 0U )

/* CLB_SPC_Frame_Valid_b1 signal Enums */
typedef boolean CORECALSPCCLBSPCFrameValid;
#define C_EYEQMSG_CORECALSPC_CLB_SPC_FRAME_VALID_FALSE        ( CORECALSPCCLBSPCFrameValid ) ( 0U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_FRAME_VALID_TRUE         ( CORECALSPCCLBSPCFrameValid ) ( 1U )

/* CLB_SPC_Frame_Valid_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORECALSPC_CLB_SPC_FRAME_VALID_RMIN         ( 0U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_FRAME_VALID_RMAX         ( 1U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_FRAME_VALID_NUMR         ( 1U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_FRAME_VALID_DEMNR        ( 1U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_FRAME_VALID_OFFSET       ( 0U )

/* CLB_SPC_Session_Number_b3 signal Min & Max range limits */
#define C_EYEQMSG_CORECALSPC_CLB_SPC_SESSION_NUMBER_RMIN      ( 0U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_SESSION_NUMBER_RMAX      ( 4U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_SESSION_NUMBER_NUMR      ( 1U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_SESSION_NUMBER_DEMNR     ( 1U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_SESSION_NUMBER_OFFSET    ( 0U )

/* CLB_SPC_Error_b2 signal Enums */
typedef uint8 CORECALSPCCLBSPCError;
#define C_EYEQMSG_CORECALSPC_CLB_SPC_ERROR_NONE               ( CORECALSPCCLBSPCError ) ( 0U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_ERROR_TIMEOUT            ( CORECALSPCCLBSPCError ) ( 1U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_ERROR_OOR                ( CORECALSPCCLBSPCError ) ( 2U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_ERROR_INTERNAL           ( CORECALSPCCLBSPCError ) ( 3U )

/* CLB_SPC_Error_b2 signal Min & Max range limits */
#define C_EYEQMSG_CORECALSPC_CLB_SPC_ERROR_RMIN               ( 0U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_ERROR_RMAX               ( 3U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_ERROR_NUMR               ( 1U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_ERROR_DEMNR              ( 1U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_ERROR_OFFSET             ( 0U )

/* CLB_SPC_Progress_b7 signal Min & Max range limits */
#define C_EYEQMSG_CORECALSPC_CLB_SPC_PROGRESS_RMIN            ( 0U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_PROGRESS_RMAX            ( 100U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_PROGRESS_NUMR            ( 1U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_PROGRESS_DEMNR           ( 1U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_PROGRESS_OFFSET          ( 0U )

/* CLB_SPC_Status_b2 signal Enums */
typedef uint8 CORECALSPCCLBSPCStatus;
#define C_EYEQMSG_CORECALSPC_CLB_SPC_STATUS_NOT_AVAILABLE     ( CORECALSPCCLBSPCStatus ) ( 0U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_STATUS_RUNNING           ( CORECALSPCCLBSPCStatus ) ( 1U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_STATUS_CONVERGED         ( CORECALSPCCLBSPCStatus ) ( 2U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_STATUS_ERROR             ( CORECALSPCCLBSPCStatus ) ( 3U )

/* CLB_SPC_Status_b2 signal Min & Max range limits */
#define C_EYEQMSG_CORECALSPC_CLB_SPC_STATUS_RMIN              ( 0U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_STATUS_RMAX              ( 3U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_STATUS_NUMR              ( 1U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_STATUS_DEMNR             ( 1U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_STATUS_OFFSET            ( 0U )

/* CLB_SPC_Sync_ID_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORECALSPC_CLB_SPC_SYNC_ID_RMIN             ( 0U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_SYNC_ID_RMAX             ( 255U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_SYNC_ID_NUMR             ( 1U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_SYNC_ID_DEMNR            ( 1U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_SYNC_ID_OFFSET           ( 0U )

/* CLB_SPC_Protocol_Version_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORECALSPC_CLB_SPC_PROTOCOL_VERSION_RMIN    ( 3U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_PROTOCOL_VERSION_RMAX    ( 3U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_PROTOCOL_VERSION_NUMR    ( 1U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_PROTOCOL_VERSION_DEMNR   ( 1U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_PROTOCOL_VERSION_OFFSET  ( 0U )

/* CLB_SPC_Header_CRC_b32 signal Min & Max range limits */
#define C_EYEQMSG_CORECALSPC_CLB_SPC_HEADER_CRC_RMIN          ( 0U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_HEADER_CRC_RMAX          ( 4294967295U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_HEADER_CRC_NUMR          ( 1U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_HEADER_CRC_DEMNR         ( 1U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_HEADER_CRC_OFFSET        ( 0U )

/* Reserved_1_b24 signal Min & Max range limits */
#define C_EYEQMSG_CORECALSPC_RESERVED_1_RMIN                  ( 0U )
#define C_EYEQMSG_CORECALSPC_RESERVED_1_RMAX                  ( 0U )
#define C_EYEQMSG_CORECALSPC_RESERVED_1_NUMR                  ( 1U )
#define C_EYEQMSG_CORECALSPC_RESERVED_1_DEMNR                 ( 1U )
#define C_EYEQMSG_CORECALSPC_RESERVED_1_OFFSET                ( 0U )

/* CLB_SPC_Zero_byte_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORECALSPC_CLB_SPC_ZERO_BYTE_RMIN           ( 0U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_ZERO_BYTE_RMAX           ( 255U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_ZERO_BYTE_NUMR           ( 1U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_ZERO_BYTE_DEMNR          ( 1U )
#define C_EYEQMSG_CORECALSPC_CLB_SPC_ZERO_BYTE_OFFSET         ( 0U )


/*****************************************************************************
                  Exported function-like macros
*****************************************************************************/
/*****************************************************************************
                  Exported defined macros
*****************************************************************************/
/*****************************************************************************
                  Exported types, enums definitions
*****************************************************************************/
typedef struct
{
   #if ENABLE_BIG_ENDIAN_FORMAT
      uint32        CLB_SPC_Zero_byte_b8                         : 8U;
      
      uint32        Reserved_1_1_b8                              : 8U;
      
      uint32        Reserved_1_2_b8                              : 8U;
      
      uint32        Reserved_1_3_b8                              : 8U;
      
      uint32        CLB_SPC_Header_CRC_1_b8                      : 8U;
      
      uint32        CLB_SPC_Header_CRC_2_b8                      : 8U;
      
      uint32        CLB_SPC_Header_CRC_3_b8                      : 8U;
      
      uint32        CLB_SPC_Header_CRC_4_b8                      : 8U;
      
      uint32        CLB_SPC_Protocol_Version_b8                  : 8U;
      
      uint32        CLB_SPC_Sync_ID_b8                           : 8U;
      
      uint32        unused1_b6                                   : 6;
      uint32        CLB_SPC_Status_b2                            : 2U;
      
      uint32        CLB_SPC_Progress_1_b6                        : 6U;
      
      uint32        unused2_b1                                   : 1;
      uint32        CLB_SPC_Progress_2_b1                        : 1U;
      
      uint32        CLB_SPC_Error_b2                             : 2U;
      
      uint32        CLB_SPC_Session_Number_b3                    : 3U;
      
      uint32        CLB_SPC_Frame_Valid_b1                       : 1U;
      
      uint32        Reserved_2_b1                                : 1U;
      
      uint32        CLB_SPC_Invalid_Signal_b8                    : 8U;
      
      uint32        CLB_SPC_Invalid_Reason_b8                    : 8U;
      
      uint32        CLB_SPC_Baseline_Yaw_1_b8                    : 8U;
      
      uint32        CLB_SPC_Baseline_Yaw_2_b8                    : 8U;
      
      uint32        CLB_SPC_Baseline_Pitch_1_b8                  : 8U;
      
      uint32        CLB_SPC_Baseline_Pitch_2_b8                  : 8U;
      
      uint32        CLB_SPC_Baseline_Height_1_b8                 : 8U;
      
      uint32        CLB_SPC_Baseline_Height_2_b8                 : 8U;
      
      uint32        CLB_SPC_Baseline_Roll_1_sb8                  : 8U;
      
      uint32        CLB_SPC_Baseline_Roll_2_sb8                  : 8U;
      
      uint32        CLB_SPC_Baseline_Roll_3_sb8                  : 8U;
      
      uint32        CLB_SPC_Baseline_Roll_4_sb8                  : 8U;
      
   #else
      uint32        CLB_SPC_Zero_byte_b8                         : 8U;
      
      uint32        Reserved_1_b24                               : 24U;
      
      uint32        CLB_SPC_Header_CRC_b32                       : 32U;
      
      uint32        CLB_SPC_Protocol_Version_b8                  : 8U;
      
      uint32        CLB_SPC_Sync_ID_b8                           : 8U;
      
      uint32        CLB_SPC_Status_b2                            : 2U;
      
      uint32        CLB_SPC_Progress_b7                          : 7U;
      
      uint32        CLB_SPC_Error_b2                             : 2U;
      
      uint32        CLB_SPC_Session_Number_b3                    : 3U;
      
      uint32        CLB_SPC_Frame_Valid_b1                       : 1U;
      
      uint32        Reserved_2_b1                                : 1U;
      
      uint32        CLB_SPC_Invalid_Signal_b8                    : 8U;
      
      uint32        CLB_SPC_Invalid_Reason_b8                    : 8U;
      
      uint32        CLB_SPC_Baseline_Yaw_b16                     : 16U;
      
      uint32        CLB_SPC_Baseline_Pitch_b16                   : 16U;
      
      uint32        CLB_SPC_Baseline_Height_b16                  : 16U;
      
      sint32        CLB_SPC_Baseline_Roll_sb32                   : 32;
      
   #endif
} EYEQMSG_CORECALSPC_Params_t;


/*****************************************************************************
                  Exported function prototypes
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_CORECALSPC_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_CORECALSPC_Params_t * pCore_Calibration_SPC_protocol - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_Calibration_SPC_protocol message 
*    Core_Calibration_SPC_protocol message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_Calibration_SPC_protocol message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_CORECALSPC_ParamsApp_MsgDataStruct( EYEQMSG_CORECALSPC_Params_t * pCore_Calibration_SPC_protocol );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSPC_CLB_SPC_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pCLB_SPC_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_SPC_Zero_byte
*    CLB_SPC_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_SPC_Zero_byte signal value of Core_Calibration_SPC_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSPC_CLB_SPC_Zero_byte( uint8 * pCLB_SPC_Zero_byte );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSPC_Reserved_1
*
* FUNCTION ARGUMENTS:
*    uint32 * pReserved_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1
*    Reserved_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1 signal value of Core_Calibration_SPC_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSPC_Reserved_1( uint32 * pReserved_1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSPC_CLB_SPC_Header_CRC
*
* FUNCTION ARGUMENTS:
*    uint32 * pCLB_SPC_Header_CRC - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_SPC_Header_CRC
*    CLB_SPC_Header_CRC returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_SPC_Header_CRC signal value of Core_Calibration_SPC_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSPC_CLB_SPC_Header_CRC( uint32 * pCLB_SPC_Header_CRC );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSPC_CLB_SPC_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pCLB_SPC_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_SPC_Protocol_Version
*    CLB_SPC_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_SPC_Protocol_Version signal value of Core_Calibration_SPC_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSPC_CLB_SPC_Protocol_Version( uint8 * pCLB_SPC_Protocol_Version );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSPC_CLB_SPC_Sync_ID
*
* FUNCTION ARGUMENTS:
*    uint8 * pCLB_SPC_Sync_ID - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_SPC_Sync_ID
*    CLB_SPC_Sync_ID returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_SPC_Sync_ID signal value of Core_Calibration_SPC_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSPC_CLB_SPC_Sync_ID( uint8 * pCLB_SPC_Sync_ID );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSPC_CLB_SPC_Status
*
* FUNCTION ARGUMENTS:
*    CORECALSPCCLBSPCStatus * pCLB_SPC_Status - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_SPC_Status
*    CLB_SPC_Status returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_SPC_Status signal value of Core_Calibration_SPC_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSPC_CLB_SPC_Status( CORECALSPCCLBSPCStatus * pCLB_SPC_Status );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSPC_CLB_SPC_Progress
*
* FUNCTION ARGUMENTS:
*    uint8 * pCLB_SPC_Progress - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_SPC_Progress
*    CLB_SPC_Progress returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_SPC_Progress signal value of Core_Calibration_SPC_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSPC_CLB_SPC_Progress( uint8 * pCLB_SPC_Progress );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSPC_CLB_SPC_Error
*
* FUNCTION ARGUMENTS:
*    CORECALSPCCLBSPCError * pCLB_SPC_Error - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_SPC_Error
*    CLB_SPC_Error returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_SPC_Error signal value of Core_Calibration_SPC_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSPC_CLB_SPC_Error( CORECALSPCCLBSPCError * pCLB_SPC_Error );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSPC_CLB_SPC_Session_Number
*
* FUNCTION ARGUMENTS:
*    uint8 * pCLB_SPC_Session_Number - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_SPC_Session_Number
*    CLB_SPC_Session_Number returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_SPC_Session_Number signal value of Core_Calibration_SPC_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSPC_CLB_SPC_Session_Number( uint8 * pCLB_SPC_Session_Number );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSPC_CLB_SPC_Frame_Valid
*
* FUNCTION ARGUMENTS:
*    CORECALSPCCLBSPCFrameValid * pCLB_SPC_Frame_Valid - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_SPC_Frame_Valid
*    CLB_SPC_Frame_Valid returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_SPC_Frame_Valid signal value of Core_Calibration_SPC_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSPC_CLB_SPC_Frame_Valid( CORECALSPCCLBSPCFrameValid * pCLB_SPC_Frame_Valid );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSPC_Reserved_2
*
* FUNCTION ARGUMENTS:
*    boolean * pReserved_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_2
*    Reserved_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_2 signal value of Core_Calibration_SPC_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSPC_Reserved_2( boolean * pReserved_2 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSPC_CLB_SPC_Invalid_Signal
*
* FUNCTION ARGUMENTS:
*    uint8 * pCLB_SPC_Invalid_Signal - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_SPC_Invalid_Signal
*    CLB_SPC_Invalid_Signal returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_SPC_Invalid_Signal signal value of Core_Calibration_SPC_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSPC_CLB_SPC_Invalid_Signal( uint8 * pCLB_SPC_Invalid_Signal );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSPC_CLB_SPC_Invalid_Reason
*
* FUNCTION ARGUMENTS:
*    CORECALSPCCLBSPCInvalidReason * pCLB_SPC_Invalid_Reason - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_SPC_Invalid_Reason
*    CLB_SPC_Invalid_Reason returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_SPC_Invalid_Reason signal value of Core_Calibration_SPC_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSPC_CLB_SPC_Invalid_Reason( CORECALSPCCLBSPCInvalidReason * pCLB_SPC_Invalid_Reason );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSPC_CLB_SPC_Baseline_Yaw
*
* FUNCTION ARGUMENTS:
*    uint16 * pCLB_SPC_Baseline_Yaw - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_SPC_Baseline_Yaw
*    CLB_SPC_Baseline_Yaw returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_SPC_Baseline_Yaw signal value of Core_Calibration_SPC_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSPC_CLB_SPC_Baseline_Yaw( uint16 * pCLB_SPC_Baseline_Yaw );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSPC_CLB_SPC_Baseline_Pitch
*
* FUNCTION ARGUMENTS:
*    uint16 * pCLB_SPC_Baseline_Pitch - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_SPC_Baseline_Pitch
*    CLB_SPC_Baseline_Pitch returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_SPC_Baseline_Pitch signal value of Core_Calibration_SPC_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSPC_CLB_SPC_Baseline_Pitch( uint16 * pCLB_SPC_Baseline_Pitch );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSPC_CLB_SPC_Baseline_Height
*
* FUNCTION ARGUMENTS:
*    uint16 * pCLB_SPC_Baseline_Height - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_SPC_Baseline_Height
*    CLB_SPC_Baseline_Height returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_SPC_Baseline_Height signal value of Core_Calibration_SPC_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSPC_CLB_SPC_Baseline_Height( uint16 * pCLB_SPC_Baseline_Height );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSPC_CLB_SPC_Baseline_Roll
*
* FUNCTION ARGUMENTS:
*    float32 * pCLB_SPC_Baseline_Roll - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_SPC_Baseline_Roll
*    CLB_SPC_Baseline_Roll returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_SPC_Baseline_Roll signal value of Core_Calibration_SPC_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSPC_CLB_SPC_Baseline_Roll( float32 * pCLB_SPC_Baseline_Roll );
/*****************************************************************************
                  Exported object declarations
*****************************************************************************/
extern EYEQMSG_CORECALSPC_Params_t   EYEQMSG_CORECALSPC_Params_s;
extern EYEQMSG_CORECALSPC_Params_t   EYEQMSG_CORECALSPC_ParamsApp_s;
/****************************************************************************/
#endif /* _EYEQMSG_CORECALSPCPROCESS_H_ */


