#ifndef _EYEQMSG_CORETAC2INITPROCESS_H_
#define _EYEQMSG_CORETAC2INITPROCESS_H_

/*****************************************************************************
                  Included header files
*****************************************************************************/
#include <Std_Types.h>

/*****************************************************************************
                  Include files
*****************************************************************************/
/*****************************************************************************
                  Exported symbolic constants
*****************************************************************************/

/* Datagram message ID */
#define C_EYEQMSG_CORETAC2INIT_MSG_ID                         ( 0x85U )

/* Datagram message lengths */
#define C_EYEQMSG_CORETAC2INIT_MSG_LEN                        ( sizeof(EYEQMSG_CORETAC2INIT_Params_t) )

/* Protocol ENUMs */

/* MCU output messages */

/* Core_TAC2_Init Enums */
/* Reserved_3_b13 signal Min & Max range limits */
#define C_EYEQMSG_CORETAC2INIT_RESERVED_3_RMIN                ( 0U )
#define C_EYEQMSG_CORETAC2INIT_RESERVED_3_RMAX                ( 0U )
#define C_EYEQMSG_CORETAC2INIT_RESERVED_3_NUMR                ( 1U )
#define C_EYEQMSG_CORETAC2INIT_RESERVED_3_DEMNR               ( 1U )
#define C_EYEQMSG_CORETAC2INIT_RESERVED_3_OFFSET              ( 0U )

/* TAC_Targets_Num_b2 signal Min & Max range limits */
#define C_EYEQMSG_CORETAC2INIT_TAC_TARGETS_NUM_RMIN           ( 0U )
#define C_EYEQMSG_CORETAC2INIT_TAC_TARGETS_NUM_RMAX           ( 3U )
#define C_EYEQMSG_CORETAC2INIT_TAC_TARGETS_NUM_NUMR           ( 1U )
#define C_EYEQMSG_CORETAC2INIT_TAC_TARGETS_NUM_DEMNR          ( 1U )
#define C_EYEQMSG_CORETAC2INIT_TAC_TARGETS_NUM_OFFSET         ( 0U )

/* TAC_Bottom_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORETAC2INIT_TAC_BOTTOM_RMIN                ( 0U )
#define C_EYEQMSG_CORETAC2INIT_TAC_BOTTOM_RMAX                ( 240U )
#define C_EYEQMSG_CORETAC2INIT_TAC_BOTTOM_NUMR                ( 1 )
#define C_EYEQMSG_CORETAC2INIT_TAC_BOTTOM_DEMNR               ( 1 )
#define C_EYEQMSG_CORETAC2INIT_TAC_BOTTOM_OFFSET              ( -120 )

/* TAC_SquareSideSize_b9 signal Min & Max range limits */
#define C_EYEQMSG_CORETAC2INIT_TAC_SQUARESIDESIZE_RMIN        ( 0U )
#define C_EYEQMSG_CORETAC2INIT_TAC_SQUARESIDESIZE_RMAX        ( 500U )
#define C_EYEQMSG_CORETAC2INIT_TAC_SQUARESIDESIZE_NUMR        ( 1U )
#define C_EYEQMSG_CORETAC2INIT_TAC_SQUARESIDESIZE_DEMNR       ( 1000U )
#define C_EYEQMSG_CORETAC2INIT_TAC_SQUARESIDESIZE_OFFSET      ( 0U )

/* Reserved_2_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORETAC2INIT_RESERVED_2_RMIN                ( 0U )
#define C_EYEQMSG_CORETAC2INIT_RESERVED_2_RMAX                ( 0U )
#define C_EYEQMSG_CORETAC2INIT_RESERVED_2_NUMR                ( 1U )
#define C_EYEQMSG_CORETAC2INIT_RESERVED_2_DEMNR               ( 1U )
#define C_EYEQMSG_CORETAC2INIT_RESERVED_2_OFFSET              ( 0U )

/* TAC_Max_RollAngle_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORETAC2INIT_TAC_MAX_ROLLANGLE_RMIN         ( 0U )
#define C_EYEQMSG_CORETAC2INIT_TAC_MAX_ROLLANGLE_RMAX         ( 55U )
#define C_EYEQMSG_CORETAC2INIT_TAC_MAX_ROLLANGLE_NUMR         ( 1U )
#define C_EYEQMSG_CORETAC2INIT_TAC_MAX_ROLLANGLE_DEMNR        ( 1000U )
#define C_EYEQMSG_CORETAC2INIT_TAC_MAX_ROLLANGLE_OFFSET       ( 0U )

/* TAC_Min_Yaw_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORETAC2INIT_TAC_MIN_YAW_RMIN               ( 0U )
#define C_EYEQMSG_CORETAC2INIT_TAC_MIN_YAW_RMAX               ( 25U )
#define C_EYEQMSG_CORETAC2INIT_TAC_MIN_YAW_NUMR               ( 1 )
#define C_EYEQMSG_CORETAC2INIT_TAC_MIN_YAW_DEMNR              ( 1 )
#define C_EYEQMSG_CORETAC2INIT_TAC_MIN_YAW_OFFSET             ( -25 )

/* TAC_Max_Yaw_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORETAC2INIT_TAC_MAX_YAW_RMIN               ( 0U )
#define C_EYEQMSG_CORETAC2INIT_TAC_MAX_YAW_RMAX               ( 25U )
#define C_EYEQMSG_CORETAC2INIT_TAC_MAX_YAW_NUMR               ( 1U )
#define C_EYEQMSG_CORETAC2INIT_TAC_MAX_YAW_DEMNR              ( 1U )
#define C_EYEQMSG_CORETAC2INIT_TAC_MAX_YAW_OFFSET             ( 0U )

/* TAC_Min_Horizon_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORETAC2INIT_TAC_MIN_HORIZON_RMIN           ( 0U )
#define C_EYEQMSG_CORETAC2INIT_TAC_MIN_HORIZON_RMAX           ( 75U )
#define C_EYEQMSG_CORETAC2INIT_TAC_MIN_HORIZON_NUMR           ( 1 )
#define C_EYEQMSG_CORETAC2INIT_TAC_MIN_HORIZON_DEMNR          ( 1 )
#define C_EYEQMSG_CORETAC2INIT_TAC_MIN_HORIZON_OFFSET         ( -85 )

/* TAC_Max_Horizon_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORETAC2INIT_TAC_MAX_HORIZON_RMIN           ( 0U )
#define C_EYEQMSG_CORETAC2INIT_TAC_MAX_HORIZON_RMAX           ( 55U )
#define C_EYEQMSG_CORETAC2INIT_TAC_MAX_HORIZON_NUMR           ( 1 )
#define C_EYEQMSG_CORETAC2INIT_TAC_MAX_HORIZON_DEMNR          ( 1 )
#define C_EYEQMSG_CORETAC2INIT_TAC_MAX_HORIZON_OFFSET         ( -35 )

/* TAC_Camera_Z_b16 signal Min & Max range limits */
#define C_EYEQMSG_CORETAC2INIT_TAC_CAMERA_Z_RMIN              ( 0U )
#define C_EYEQMSG_CORETAC2INIT_TAC_CAMERA_Z_RMAX              ( 10000U )
#define C_EYEQMSG_CORETAC2INIT_TAC_CAMERA_Z_NUMR              ( 1U )
#define C_EYEQMSG_CORETAC2INIT_TAC_CAMERA_Z_DEMNR             ( 1000U )
#define C_EYEQMSG_CORETAC2INIT_TAC_CAMERA_Z_OFFSET            ( 0U )

/* TAC_Camera_Height_b16 signal Min & Max range limits */
#define C_EYEQMSG_CORETAC2INIT_TAC_CAMERA_HEIGHT_RMIN         ( 50U )
#define C_EYEQMSG_CORETAC2INIT_TAC_CAMERA_HEIGHT_RMAX         ( 300U )
#define C_EYEQMSG_CORETAC2INIT_TAC_CAMERA_HEIGHT_NUMR         ( 1U )
#define C_EYEQMSG_CORETAC2INIT_TAC_CAMERA_HEIGHT_DEMNR        ( 100U )
#define C_EYEQMSG_CORETAC2INIT_TAC_CAMERA_HEIGHT_OFFSET       ( 0U )

/* TAC_TargetInfo_Height_2_b16 signal Min & Max range limits */
#define C_EYEQMSG_CORETAC2INIT_TAC_TARGETINFO_HEIGHT_2_RMIN   ( 0U )
#define C_EYEQMSG_CORETAC2INIT_TAC_TARGETINFO_HEIGHT_2_RMAX   ( 500U )
#define C_EYEQMSG_CORETAC2INIT_TAC_TARGETINFO_HEIGHT_2_NUMR   ( 1U )
#define C_EYEQMSG_CORETAC2INIT_TAC_TARGETINFO_HEIGHT_2_DEMNR  ( 100U )
#define C_EYEQMSG_CORETAC2INIT_TAC_TARGETINFO_HEIGHT_2_OFFSET ( 0U )

/* TAC_TargetInfo_Height_1_b16 signal Min & Max range limits */
#define C_EYEQMSG_CORETAC2INIT_TAC_TARGETINFO_HEIGHT_1_RMIN   ( 0U )
#define C_EYEQMSG_CORETAC2INIT_TAC_TARGETINFO_HEIGHT_1_RMAX   ( 500U )
#define C_EYEQMSG_CORETAC2INIT_TAC_TARGETINFO_HEIGHT_1_NUMR   ( 1U )
#define C_EYEQMSG_CORETAC2INIT_TAC_TARGETINFO_HEIGHT_1_DEMNR  ( 100U )
#define C_EYEQMSG_CORETAC2INIT_TAC_TARGETINFO_HEIGHT_1_OFFSET ( 0U )

/* TAC_TargetInfo_Height_0_b16 signal Min & Max range limits */
#define C_EYEQMSG_CORETAC2INIT_TAC_TARGETINFO_HEIGHT_0_RMIN   ( 0U )
#define C_EYEQMSG_CORETAC2INIT_TAC_TARGETINFO_HEIGHT_0_RMAX   ( 500U )
#define C_EYEQMSG_CORETAC2INIT_TAC_TARGETINFO_HEIGHT_0_NUMR   ( 1U )
#define C_EYEQMSG_CORETAC2INIT_TAC_TARGETINFO_HEIGHT_0_DEMNR  ( 100U )
#define C_EYEQMSG_CORETAC2INIT_TAC_TARGETINFO_HEIGHT_0_OFFSET ( 0U )

/* TAC_TargetInfo_Lat_Distance_2_b16 signal Min & Max range limits */
#define C_EYEQMSG_CORETAC2INIT_TAC_TARGETINFO_LAT_DISTANCE_2_RMIN ( 0U )
#define C_EYEQMSG_CORETAC2INIT_TAC_TARGETINFO_LAT_DISTANCE_2_RMAX ( 1000U )
#define C_EYEQMSG_CORETAC2INIT_TAC_TARGETINFO_LAT_DISTANCE_2_NUMR ( 1 )
#define C_EYEQMSG_CORETAC2INIT_TAC_TARGETINFO_LAT_DISTANCE_2_DEMNR ( 100 )
#define C_EYEQMSG_CORETAC2INIT_TAC_TARGETINFO_LAT_DISTANCE_2_OFFSET ( -5 )

/* TAC_TargetInfo_Lat_Distance_1_b16 signal Min & Max range limits */
#define C_EYEQMSG_CORETAC2INIT_TAC_TARGETINFO_LAT_DISTANCE_1_RMIN ( 0U )
#define C_EYEQMSG_CORETAC2INIT_TAC_TARGETINFO_LAT_DISTANCE_1_RMAX ( 1000U )
#define C_EYEQMSG_CORETAC2INIT_TAC_TARGETINFO_LAT_DISTANCE_1_NUMR ( 1 )
#define C_EYEQMSG_CORETAC2INIT_TAC_TARGETINFO_LAT_DISTANCE_1_DEMNR ( 100 )
#define C_EYEQMSG_CORETAC2INIT_TAC_TARGETINFO_LAT_DISTANCE_1_OFFSET ( -5 )

/* Reserved_1_b2 signal Min & Max range limits */
#define C_EYEQMSG_CORETAC2INIT_RESERVED_1_RMIN                ( 0U )
#define C_EYEQMSG_CORETAC2INIT_RESERVED_1_RMAX                ( 0U )
#define C_EYEQMSG_CORETAC2INIT_RESERVED_1_NUMR                ( 1U )
#define C_EYEQMSG_CORETAC2INIT_RESERVED_1_DEMNR               ( 1U )
#define C_EYEQMSG_CORETAC2INIT_RESERVED_1_OFFSET              ( 0U )

/* TAC_TargetInfo_Lat_Distance_0_b16 signal Min & Max range limits */
#define C_EYEQMSG_CORETAC2INIT_TAC_TARGETINFO_LAT_DISTANCE_0_RMIN ( 0U )
#define C_EYEQMSG_CORETAC2INIT_TAC_TARGETINFO_LAT_DISTANCE_0_RMAX ( 1000U )
#define C_EYEQMSG_CORETAC2INIT_TAC_TARGETINFO_LAT_DISTANCE_0_NUMR ( 1 )
#define C_EYEQMSG_CORETAC2INIT_TAC_TARGETINFO_LAT_DISTANCE_0_DEMNR ( 100 )
#define C_EYEQMSG_CORETAC2INIT_TAC_TARGETINFO_LAT_DISTANCE_0_OFFSET ( -5 )

/* TAC_BottomLeftSquare_2_b2 signal Min & Max range limits */
#define C_EYEQMSG_CORETAC2INIT_TAC_BOTTOMLEFTSQUARE_2_RMIN    ( 0U )
#define C_EYEQMSG_CORETAC2INIT_TAC_BOTTOMLEFTSQUARE_2_RMAX    ( 1U )
#define C_EYEQMSG_CORETAC2INIT_TAC_BOTTOMLEFTSQUARE_2_NUMR    ( 1U )
#define C_EYEQMSG_CORETAC2INIT_TAC_BOTTOMLEFTSQUARE_2_DEMNR   ( 1U )
#define C_EYEQMSG_CORETAC2INIT_TAC_BOTTOMLEFTSQUARE_2_OFFSET  ( 0U )

/* TAC_BottomLeftSquare_1_b2 signal Min & Max range limits */
#define C_EYEQMSG_CORETAC2INIT_TAC_BOTTOMLEFTSQUARE_1_RMIN    ( 0U )
#define C_EYEQMSG_CORETAC2INIT_TAC_BOTTOMLEFTSQUARE_1_RMAX    ( 1U )
#define C_EYEQMSG_CORETAC2INIT_TAC_BOTTOMLEFTSQUARE_1_NUMR    ( 1U )
#define C_EYEQMSG_CORETAC2INIT_TAC_BOTTOMLEFTSQUARE_1_DEMNR   ( 1U )
#define C_EYEQMSG_CORETAC2INIT_TAC_BOTTOMLEFTSQUARE_1_OFFSET  ( 0U )

/* TAC_BottomLeftSquare_0_b2 signal Min & Max range limits */
#define C_EYEQMSG_CORETAC2INIT_TAC_BOTTOMLEFTSQUARE_0_RMIN    ( 0U )
#define C_EYEQMSG_CORETAC2INIT_TAC_BOTTOMLEFTSQUARE_0_RMAX    ( 1U )
#define C_EYEQMSG_CORETAC2INIT_TAC_BOTTOMLEFTSQUARE_0_NUMR    ( 1U )
#define C_EYEQMSG_CORETAC2INIT_TAC_BOTTOMLEFTSQUARE_0_DEMNR   ( 1U )
#define C_EYEQMSG_CORETAC2INIT_TAC_BOTTOMLEFTSQUARE_0_OFFSET  ( 0U )

/* TAC_Mode_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORETAC2INIT_TAC_MODE_RMIN                  ( 0U )
#define C_EYEQMSG_CORETAC2INIT_TAC_MODE_RMAX                  ( 4U )
#define C_EYEQMSG_CORETAC2INIT_TAC_MODE_NUMR                  ( 1U )
#define C_EYEQMSG_CORETAC2INIT_TAC_MODE_DEMNR                 ( 1U )
#define C_EYEQMSG_CORETAC2INIT_TAC_MODE_OFFSET                ( 0U )

/* TAC_Optional_Signals_b16 signal Min & Max range limits */
#define C_EYEQMSG_CORETAC2INIT_TAC_OPTIONAL_SIGNALS_RMIN      ( 0U )
#define C_EYEQMSG_CORETAC2INIT_TAC_OPTIONAL_SIGNALS_RMAX      ( 0U )
#define C_EYEQMSG_CORETAC2INIT_TAC_OPTIONAL_SIGNALS_NUMR      ( 1U )
#define C_EYEQMSG_CORETAC2INIT_TAC_OPTIONAL_SIGNALS_DEMNR     ( 1U )
#define C_EYEQMSG_CORETAC2INIT_TAC_OPTIONAL_SIGNALS_OFFSET    ( 0U )

/* TAC_Protocol_Version_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORETAC2INIT_TAC_PROTOCOL_VERSION_RMIN      ( 6U )
#define C_EYEQMSG_CORETAC2INIT_TAC_PROTOCOL_VERSION_RMAX      ( 6U )
#define C_EYEQMSG_CORETAC2INIT_TAC_PROTOCOL_VERSION_NUMR      ( 1U )
#define C_EYEQMSG_CORETAC2INIT_TAC_PROTOCOL_VERSION_DEMNR     ( 1U )
#define C_EYEQMSG_CORETAC2INIT_TAC_PROTOCOL_VERSION_OFFSET    ( 0U )

/* TAC_Zero_byte_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORETAC2INIT_TAC_ZERO_BYTE_RMIN             ( 0U )
#define C_EYEQMSG_CORETAC2INIT_TAC_ZERO_BYTE_RMAX             ( 0U )
#define C_EYEQMSG_CORETAC2INIT_TAC_ZERO_BYTE_NUMR             ( 1U )
#define C_EYEQMSG_CORETAC2INIT_TAC_ZERO_BYTE_DEMNR            ( 1U )
#define C_EYEQMSG_CORETAC2INIT_TAC_ZERO_BYTE_OFFSET           ( 0U )


/*****************************************************************************
                  Exported function-like macros
*****************************************************************************/
/*****************************************************************************
                  Exported defined macros
*****************************************************************************/
/*****************************************************************************
                  Exported types, enums definitions
*****************************************************************************/
typedef struct
{
   #if ENABLE_BIG_ENDIAN_FORMAT
      uint32        TAC_Zero_byte_b8                             : 8U;
      
      uint32        TAC_Protocol_Version_b8                      : 8U;
      
      uint32        TAC_Optional_Signals_1_b8                    : 8U;
      
      uint32        TAC_Optional_Signals_2_b8                    : 8U;
      
      uint32        TAC_Mode_b8                                  : 8U;
      
      uint32        unused1_b6                                   : 6;
      uint32        TAC_BottomLeftSquare_0_b2                    : 2U;
      
      uint32        TAC_BottomLeftSquare_1_b2                    : 2U;
      
      uint32        TAC_BottomLeftSquare_2_b2                    : 2U;
      
      uint32        TAC_TargetInfo_Lat_Distance_0_1_b2           : 2U;
      
      uint32        TAC_TargetInfo_Lat_Distance_0_2_b8           : 8U;
      
      uint32        TAC_TargetInfo_Lat_Distance_0_3_b6           : 6U;
      
      uint32        Reserved_1_b2                                : 2U;
      
      uint32        TAC_TargetInfo_Lat_Distance_1_1_b8           : 8U;
      
      uint32        TAC_TargetInfo_Lat_Distance_1_2_b8           : 8U;
      
      uint32        TAC_TargetInfo_Lat_Distance_2_1_b8           : 8U;
      
      uint32        TAC_TargetInfo_Lat_Distance_2_2_b8           : 8U;
      
      uint32        TAC_TargetInfo_Height_0_1_b8                 : 8U;
      
      uint32        TAC_TargetInfo_Height_0_2_b8                 : 8U;
      
      uint32        TAC_TargetInfo_Height_1_1_b8                 : 8U;
      
      uint32        TAC_TargetInfo_Height_1_2_b8                 : 8U;
      
      uint32        TAC_TargetInfo_Height_2_1_b8                 : 8U;
      
      uint32        TAC_TargetInfo_Height_2_2_b8                 : 8U;
      
      uint32        TAC_Camera_Height_1_b8                       : 8U;
      
      uint32        TAC_Camera_Height_2_b8                       : 8U;
      
      uint32        TAC_Camera_Z_1_b8                            : 8U;
      
      uint32        TAC_Camera_Z_2_b8                            : 8U;
      
      uint32        TAC_Max_Horizon_b8                           : 8U;
      
      uint32        TAC_Min_Horizon_b8                           : 8U;
      
      uint32        TAC_Max_Yaw_b8                               : 8U;
      
      uint32        TAC_Min_Yaw_b8                               : 8U;
      
      uint32        TAC_Max_RollAngle_b8                         : 8U;
      
      uint32        Reserved_2_b8                                : 8U;
      
      uint32        TAC_SquareSideSize_1_b8                      : 8U;
      
      uint32        unused2_b1                                   : 1;
      uint32        TAC_SquareSideSize_2_b1                      : 1U;
      
      uint32        TAC_Bottom_1_b7                              : 7U;
      
      uint32        TAC_Bottom_2_b1                              : 1U;
      
      uint32        TAC_Targets_Num_b2                           : 2U;
      
      uint32        Reserved_3_1_b5                              : 5U;
      
      uint32        Reserved_3_2_b8                              : 8U;
      
   #else
      uint32        TAC_Zero_byte_b8                             : 8U;
      
      uint32        TAC_Protocol_Version_b8                      : 8U;
      
      uint32        TAC_Optional_Signals_b16                     : 16U;
      
      uint32        TAC_Mode_b8                                  : 8U;
      
      uint32        TAC_BottomLeftSquare_0_b2                    : 2U;
      
      uint32        TAC_BottomLeftSquare_1_b2                    : 2U;
      
      uint32        TAC_BottomLeftSquare_2_b2                    : 2U;
      
      uint32        TAC_TargetInfo_Lat_Distance_0_b16            : 16U;
      
      uint32        Reserved_1_b2                                : 2U;
      
      uint32        TAC_TargetInfo_Lat_Distance_1_b16            : 16U;
      
      uint32        TAC_TargetInfo_Lat_Distance_2_b16            : 16U;
      
      uint32        TAC_TargetInfo_Height_0_b16                  : 16U;
      
      uint32        TAC_TargetInfo_Height_1_b16                  : 16U;
      
      uint32        TAC_TargetInfo_Height_2_b16                  : 16U;
      
      uint32        TAC_Camera_Height_b16                        : 16U;
      
      uint32        TAC_Camera_Z_b16                             : 16U;
      
      uint32        TAC_Max_Horizon_b8                           : 8U;
      
      uint32        TAC_Min_Horizon_b8                           : 8U;
      
      uint32        TAC_Max_Yaw_b8                               : 8U;
      
      uint32        TAC_Min_Yaw_b8                               : 8U;
      
      uint32        TAC_Max_RollAngle_b8                         : 8U;
      
      uint32        Reserved_2_b8                                : 8U;
      
      uint32        TAC_SquareSideSize_b9                        : 9U;
      
      uint32        TAC_Bottom_b8                                : 8U;
      
      uint32        TAC_Targets_Num_b2                           : 2U;
      
      uint32        Reserved_3_b13                               : 13U;
      
   #endif
} EYEQMSG_CORETAC2INIT_Params_t;


/*****************************************************************************
                  Exported function prototypes
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_CORETAC2INIT_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_CORETAC2INIT_Params_t * pCore_TAC2_Init - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_TAC2_Init message 
*    Core_TAC2_Init message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_TAC2_Init message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_CORETAC2INIT_ParamsApp_MsgDataStruct( EYEQMSG_CORETAC2INIT_Params_t * pCore_TAC2_Init );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_TAC_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pTAC_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TAC_Zero_byte
*    TAC_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TAC_Zero_byte signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_TAC_Zero_byte( uint8 * pTAC_Zero_byte );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_TAC_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pTAC_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TAC_Protocol_Version
*    TAC_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TAC_Protocol_Version signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_TAC_Protocol_Version( uint8 * pTAC_Protocol_Version );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_TAC_Optional_Signals
*
* FUNCTION ARGUMENTS:
*    uint16 * pTAC_Optional_Signals - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TAC_Optional_Signals
*    TAC_Optional_Signals returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TAC_Optional_Signals signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_TAC_Optional_Signals( uint16 * pTAC_Optional_Signals );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_TAC_Mode
*
* FUNCTION ARGUMENTS:
*    uint8 * pTAC_Mode - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TAC_Mode
*    TAC_Mode returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TAC_Mode signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_TAC_Mode( uint8 * pTAC_Mode );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_TAC_BottomLeftSquare_0
*
* FUNCTION ARGUMENTS:
*    uint8 * pTAC_BottomLeftSquare_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TAC_BottomLeftSquare_0
*    TAC_BottomLeftSquare_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TAC_BottomLeftSquare_0 signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_TAC_BottomLeftSquare_0( uint8 * pTAC_BottomLeftSquare_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_TAC_BottomLeftSquare_1
*
* FUNCTION ARGUMENTS:
*    uint8 * pTAC_BottomLeftSquare_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TAC_BottomLeftSquare_1
*    TAC_BottomLeftSquare_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TAC_BottomLeftSquare_1 signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_TAC_BottomLeftSquare_1( uint8 * pTAC_BottomLeftSquare_1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_TAC_BottomLeftSquare_2
*
* FUNCTION ARGUMENTS:
*    uint8 * pTAC_BottomLeftSquare_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TAC_BottomLeftSquare_2
*    TAC_BottomLeftSquare_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TAC_BottomLeftSquare_2 signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_TAC_BottomLeftSquare_2( uint8 * pTAC_BottomLeftSquare_2 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_TAC_TargetInfo_Lat_Distance_0
*
* FUNCTION ARGUMENTS:
*    uint16 * pTAC_TargetInfo_Lat_Distance_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TAC_TargetInfo_Lat_Distance_0
*    TAC_TargetInfo_Lat_Distance_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TAC_TargetInfo_Lat_Distance_0 signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_TAC_TargetInfo_Lat_Distance_0( uint16 * pTAC_TargetInfo_Lat_Distance_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_Reserved_1
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1
*    Reserved_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1 signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_Reserved_1( uint8 * pReserved_1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_TAC_TargetInfo_Lat_Distance_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pTAC_TargetInfo_Lat_Distance_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TAC_TargetInfo_Lat_Distance_1
*    TAC_TargetInfo_Lat_Distance_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TAC_TargetInfo_Lat_Distance_1 signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_TAC_TargetInfo_Lat_Distance_1( uint16 * pTAC_TargetInfo_Lat_Distance_1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_TAC_TargetInfo_Lat_Distance_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pTAC_TargetInfo_Lat_Distance_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TAC_TargetInfo_Lat_Distance_2
*    TAC_TargetInfo_Lat_Distance_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TAC_TargetInfo_Lat_Distance_2 signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_TAC_TargetInfo_Lat_Distance_2( uint16 * pTAC_TargetInfo_Lat_Distance_2 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_TAC_TargetInfo_Height_0
*
* FUNCTION ARGUMENTS:
*    uint16 * pTAC_TargetInfo_Height_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TAC_TargetInfo_Height_0
*    TAC_TargetInfo_Height_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TAC_TargetInfo_Height_0 signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_TAC_TargetInfo_Height_0( uint16 * pTAC_TargetInfo_Height_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_TAC_TargetInfo_Height_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pTAC_TargetInfo_Height_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TAC_TargetInfo_Height_1
*    TAC_TargetInfo_Height_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TAC_TargetInfo_Height_1 signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_TAC_TargetInfo_Height_1( uint16 * pTAC_TargetInfo_Height_1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_TAC_TargetInfo_Height_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pTAC_TargetInfo_Height_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TAC_TargetInfo_Height_2
*    TAC_TargetInfo_Height_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TAC_TargetInfo_Height_2 signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_TAC_TargetInfo_Height_2( uint16 * pTAC_TargetInfo_Height_2 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_TAC_Camera_Height
*
* FUNCTION ARGUMENTS:
*    uint16 * pTAC_Camera_Height - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TAC_Camera_Height
*    TAC_Camera_Height returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TAC_Camera_Height signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_TAC_Camera_Height( uint16 * pTAC_Camera_Height );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_TAC_Camera_Z
*
* FUNCTION ARGUMENTS:
*    uint16 * pTAC_Camera_Z - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TAC_Camera_Z
*    TAC_Camera_Z returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TAC_Camera_Z signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_TAC_Camera_Z( uint16 * pTAC_Camera_Z );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_TAC_Max_Horizon
*
* FUNCTION ARGUMENTS:
*    uint8 * pTAC_Max_Horizon - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TAC_Max_Horizon
*    TAC_Max_Horizon returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TAC_Max_Horizon signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_TAC_Max_Horizon( uint8 * pTAC_Max_Horizon );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_TAC_Min_Horizon
*
* FUNCTION ARGUMENTS:
*    uint8 * pTAC_Min_Horizon - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TAC_Min_Horizon
*    TAC_Min_Horizon returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TAC_Min_Horizon signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_TAC_Min_Horizon( uint8 * pTAC_Min_Horizon );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_TAC_Max_Yaw
*
* FUNCTION ARGUMENTS:
*    uint8 * pTAC_Max_Yaw - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TAC_Max_Yaw
*    TAC_Max_Yaw returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TAC_Max_Yaw signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_TAC_Max_Yaw( uint8 * pTAC_Max_Yaw );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_TAC_Min_Yaw
*
* FUNCTION ARGUMENTS:
*    uint8 * pTAC_Min_Yaw - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TAC_Min_Yaw
*    TAC_Min_Yaw returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TAC_Min_Yaw signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_TAC_Min_Yaw( uint8 * pTAC_Min_Yaw );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_TAC_Max_RollAngle
*
* FUNCTION ARGUMENTS:
*    uint8 * pTAC_Max_RollAngle - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TAC_Max_RollAngle
*    TAC_Max_RollAngle returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TAC_Max_RollAngle signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_TAC_Max_RollAngle( uint8 * pTAC_Max_RollAngle );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_Reserved_2
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_2
*    Reserved_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_2 signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_Reserved_2( uint8 * pReserved_2 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_TAC_SquareSideSize
*
* FUNCTION ARGUMENTS:
*    uint16 * pTAC_SquareSideSize - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TAC_SquareSideSize
*    TAC_SquareSideSize returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TAC_SquareSideSize signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_TAC_SquareSideSize( uint16 * pTAC_SquareSideSize );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_TAC_Bottom
*
* FUNCTION ARGUMENTS:
*    uint8 * pTAC_Bottom - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TAC_Bottom
*    TAC_Bottom returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TAC_Bottom signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_TAC_Bottom( uint8 * pTAC_Bottom );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_TAC_Targets_Num
*
* FUNCTION ARGUMENTS:
*    uint8 * pTAC_Targets_Num - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TAC_Targets_Num
*    TAC_Targets_Num returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TAC_Targets_Num signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_TAC_Targets_Num( uint8 * pTAC_Targets_Num );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_Reserved_3
*
* FUNCTION ARGUMENTS:
*    uint16 * pReserved_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_3
*    Reserved_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_3 signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_Reserved_3( uint16 * pReserved_3 );
/*****************************************************************************
                  Exported object declarations
*****************************************************************************/
extern EYEQMSG_CORETAC2INIT_Params_t   EYEQMSG_CORETAC2INIT_Params_s;
extern EYEQMSG_CORETAC2INIT_Params_t   EYEQMSG_CORETAC2INIT_ParamsApp_s;
/****************************************************************************/
#endif /* _EYEQMSG_CORETAC2INITPROCESS_H_ */


