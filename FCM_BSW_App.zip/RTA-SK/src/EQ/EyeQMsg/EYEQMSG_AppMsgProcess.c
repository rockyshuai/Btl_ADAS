

/*****************************************************************************
                  Include files
*****************************************************************************/
/* The suggested include file order is: */
#include "EyeQ_defs.h"    /* EyeQ project common definitions file    */

#include "EYEQMSG_AppMsgProcess.h"

/*****************************************************************************
                  Local symbolic constants
*****************************************************************************/
/*****************************************************************************
                  Local types, enums definitions
*****************************************************************************/
/*****************************************************************************
                  Local function prototypes
*****************************************************************************/
/*****************************************************************************
                  Local object definitions
*****************************************************************************/
/*****************************************************************************
                  Exported object definitions
*****************************************************************************/
EYEQMSG_APPMSG_Params_t   EYEQMSG_APPMSG_Params_s;
EYEQMSG_APPMSG_Params_t   EYEQMSG_APPMSG_ParamsApp_s;
/*****************************************************************************
                  Local function-like macros
*****************************************************************************/
/*****************************************************************************
                  Local defined macros
*****************************************************************************/
/*****************************************************************************
                  Function definitions
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_APPMSG_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_APPMSG_Params_t * pCore_Application_Message_protocol - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_Application_Message_protocol message 
*    Core_Application_Message_protocol message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_Application_Message_protocol message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_APPMSG_ParamsApp_MsgDataStruct( EYEQMSG_APPMSG_Params_t * pCore_Application_Message_protocol )
{
   Std_ReturnType status = C_SIG_INVALID;
   if( pCore_Application_Message_protocol != C_NULL_P )
   {
      status = C_SIG_VALID;
      * pCore_Application_Message_protocol = EYEQMSG_APPMSG_ParamsApp_s;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Zero_Byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pAPP_Zero_Byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Zero_Byte
*    APP_Zero_Byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Zero_Byte signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Zero_Byte( uint8 * pAPP_Zero_Byte )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pAPP_Zero_Byte != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.APP_Zero_Byte_b8;
      * pAPP_Zero_Byte = signal_value;
      if( signal_value <= C_EYEQMSG_APPMSG_APP_ZERO_BYTE_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_Application_Message_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pApplication_Message_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Application_Message_Version
*    Application_Message_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Application_Message_Version signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_Application_Message_Version( uint8 * pApplication_Message_Version )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pApplication_Message_Version != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.Application_Message_Version_b8;
      * pApplication_Message_Version = signal_value;
      if( (signal_value >= C_EYEQMSG_APPMSG_APPLICATION_MESSAGE_VERSION_RMIN ) 
          && (signal_value <= C_EYEQMSG_APPMSG_APPLICATION_MESSAGE_VERSION_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Main_State
*
* FUNCTION ARGUMENTS:
*    uint8 * pAPP_Main_State - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Main_State
*    APP_Main_State returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Main_State signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Main_State( uint8 * pAPP_Main_State )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pAPP_Main_State != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.APP_Main_State_b8;
      * pAPP_Main_State = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Sub_State
*
* FUNCTION ARGUMENTS:
*    uint8 * pAPP_Sub_State - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Sub_State
*    APP_Sub_State returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Sub_State signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Sub_State( uint8 * pAPP_Sub_State )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pAPP_Sub_State != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.APP_Sub_State_b8;
      * pAPP_Sub_State = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_EyeQ_Process_Index
*
* FUNCTION ARGUMENTS:
*    uint32 * pAPP_EyeQ_Process_Index - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_EyeQ_Process_Index
*    APP_EyeQ_Process_Index returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_EyeQ_Process_Index signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_EyeQ_Process_Index( uint32 * pAPP_EyeQ_Process_Index )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pAPP_EyeQ_Process_Index != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.APP_EyeQ_Process_Index_b32;
      * pAPP_EyeQ_Process_Index = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_EyeQ_Timestamp
*
* FUNCTION ARGUMENTS:
*    uint32 * pAPP_EyeQ_Timestamp - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_EyeQ_Timestamp
*    APP_EyeQ_Timestamp returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_EyeQ_Timestamp signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_EyeQ_Timestamp( uint32 * pAPP_EyeQ_Timestamp )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pAPP_EyeQ_Timestamp != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.APP_EyeQ_Timestamp_b32;
      * pAPP_EyeQ_Timestamp = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_EyeQ_Current_Timestamp
*
* FUNCTION ARGUMENTS:
*    uint32 * pAPP_EyeQ_Current_Timestamp - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_EyeQ_Current_Timestamp
*    APP_EyeQ_Current_Timestamp returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_EyeQ_Current_Timestamp signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_EyeQ_Current_Timestamp( uint32 * pAPP_EyeQ_Current_Timestamp )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pAPP_EyeQ_Current_Timestamp != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.APP_EyeQ_Current_Timestamp_b32;
      * pAPP_EyeQ_Current_Timestamp = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Diagnostics_part_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pAPP_Diagnostics_part_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Diagnostics_part_1
*    APP_Diagnostics_part_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Diagnostics_part_1 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Diagnostics_part_1( uint16 * pAPP_Diagnostics_part_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pAPP_Diagnostics_part_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.APP_Diagnostics_part_1_b16;
      * pAPP_Diagnostics_part_1 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Diagnostics_part_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pAPP_Diagnostics_part_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Diagnostics_part_2
*    APP_Diagnostics_part_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Diagnostics_part_2 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Diagnostics_part_2( uint16 * pAPP_Diagnostics_part_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pAPP_Diagnostics_part_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.APP_Diagnostics_part_2_b16;
      * pAPP_Diagnostics_part_2 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Fatal_Error
*
* FUNCTION ARGUMENTS:
*    APPMSGAPPFatalError * pAPP_Fatal_Error - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Fatal_Error
*    APP_Fatal_Error returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Fatal_Error signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Fatal_Error( APPMSGAPPFatalError * pAPP_Fatal_Error )
{
   Std_ReturnType status = C_SIG_INVALID;
   APPMSGAPPFatalError signal_value;
   
   if( pAPP_Fatal_Error != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.APP_Fatal_Error_b8;
      * pAPP_Fatal_Error = signal_value;
      if( signal_value <= C_EYEQMSG_APPMSG_APP_FATAL_ERROR_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_App_RSRV_1
*
* FUNCTION ARGUMENTS:
*    uint8 * pApp_RSRV_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of App_RSRV_1
*    App_RSRV_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns App_RSRV_1 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_App_RSRV_1( uint8 * pApp_RSRV_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pApp_RSRV_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.App_RSRV_1_b8;
      * pApp_RSRV_1 = signal_value;
      if( signal_value <= C_EYEQMSG_APPMSG_APP_RSRV_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Minor_Error
*
* FUNCTION ARGUMENTS:
*    APPMSGAPPMinorError * pAPP_Minor_Error - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Minor_Error
*    APP_Minor_Error returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Minor_Error signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Minor_Error( APPMSGAPPMinorError * pAPP_Minor_Error )
{
   Std_ReturnType status = C_SIG_INVALID;
   APPMSGAPPMinorError signal_value;
   
   if( pAPP_Minor_Error != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.APP_Minor_Error_b16;
      * pAPP_Minor_Error = signal_value;
      if( signal_value <= C_EYEQMSG_APPMSG_APP_MINOR_ERROR_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_EyeQTemperature1
*
* FUNCTION ARGUMENTS:
*    sint16 * pAPP_EyeQTemperature1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_EyeQTemperature1
*    APP_EyeQTemperature1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_EyeQTemperature1 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_EyeQTemperature1( sint16 * pAPP_EyeQTemperature1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   sint16 signal_value;
   
   if( pAPP_EyeQTemperature1 != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.APP_EyeQTemperature1_sb16;
      * pAPP_EyeQTemperature1 = signal_value;
      if( (signal_value >= C_EYEQMSG_APPMSG_APP_EYEQTEMPERATURE1_RMIN ) 
          && (signal_value <= C_EYEQMSG_APPMSG_APP_EYEQTEMPERATURE1_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_EyeQTemperature2
*
* FUNCTION ARGUMENTS:
*    sint16 * pAPP_EyeQTemperature2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_EyeQTemperature2
*    APP_EyeQTemperature2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_EyeQTemperature2 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_EyeQTemperature2( sint16 * pAPP_EyeQTemperature2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   sint16 signal_value;
   
   if( pAPP_EyeQTemperature2 != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.APP_EyeQTemperature2_sb16;
      * pAPP_EyeQTemperature2 = signal_value;
      if( (signal_value >= C_EYEQMSG_APPMSG_APP_EYEQTEMPERATURE2_RMIN ) 
          && (signal_value <= C_EYEQMSG_APPMSG_APP_EYEQTEMPERATURE2_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Temperature_DDR
*
* FUNCTION ARGUMENTS:
*    APPMSGAPPTemperatureDDR * pAPP_Temperature_DDR - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Temperature_DDR
*    APP_Temperature_DDR returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Temperature_DDR signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Temperature_DDR( APPMSGAPPTemperatureDDR * pAPP_Temperature_DDR )
{
   Std_ReturnType status = C_SIG_INVALID;
   APPMSGAPPTemperatureDDR signal_value;
   
   if( pAPP_Temperature_DDR != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.APP_Temperature_DDR_sb8;
      * pAPP_Temperature_DDR = signal_value;
      if( (signal_value >= C_EYEQMSG_APPMSG_APP_TEMPERATURE_DDR_RMIN ) 
          && (signal_value <= C_EYEQMSG_APPMSG_APP_TEMPERATURE_DDR_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_App_RSRV_2
*
* FUNCTION ARGUMENTS:
*    uint8 * pApp_RSRV_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of App_RSRV_2
*    App_RSRV_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns App_RSRV_2 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_App_RSRV_2( uint8 * pApp_RSRV_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pApp_RSRV_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.App_RSRV_2_b8;
      * pApp_RSRV_2 = signal_value;
      if( signal_value <= C_EYEQMSG_APPMSG_APP_RSRV_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_App_RSRV_3
*
* FUNCTION ARGUMENTS:
*    uint16 * pApp_RSRV_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of App_RSRV_3
*    App_RSRV_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns App_RSRV_3 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_App_RSRV_3( uint16 * pApp_RSRV_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pApp_RSRV_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.App_RSRV_3_b16;
      * pApp_RSRV_3 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_App_RSRV_4
*
* FUNCTION ARGUMENTS:
*    uint8 * pApp_RSRV_4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of App_RSRV_4
*    App_RSRV_4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns App_RSRV_4 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_App_RSRV_4( uint8 * pApp_RSRV_4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pApp_RSRV_4 != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.App_RSRV_4_b8;
      * pApp_RSRV_4 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_spiErrors
*
* FUNCTION ARGUMENTS:
*    APPMSGAPPSpiErrors * pAPP_spiErrors - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_spiErrors
*    APP_spiErrors returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_spiErrors signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_spiErrors( APPMSGAPPSpiErrors * pAPP_spiErrors )
{
   Std_ReturnType status = C_SIG_INVALID;
   APPMSGAPPSpiErrors signal_value;
   
   if( pAPP_spiErrors != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.APP_spiErrors_b8;
      * pAPP_spiErrors = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Valid_second_cam_temp_info
*
* FUNCTION ARGUMENTS:
*    APPMSGAPPValidSecondCamTempInfo * pAPP_Valid_second_cam_temp_info - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Valid_second_cam_temp_info
*    APP_Valid_second_cam_temp_info returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Valid_second_cam_temp_info signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Valid_second_cam_temp_info( APPMSGAPPValidSecondCamTempInfo * pAPP_Valid_second_cam_temp_info )
{
   Std_ReturnType status = C_SIG_INVALID;
   APPMSGAPPValidSecondCamTempInfo signal_value;
   
   if( pAPP_Valid_second_cam_temp_info != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.APP_Valid_second_cam_temp_info_b8;
      * pAPP_Valid_second_cam_temp_info = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Valid_cameras_information
*
* FUNCTION ARGUMENTS:
*    APPMSGAPPValidCamerasInformation * pAPP_Valid_cameras_information - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Valid_cameras_information
*    APP_Valid_cameras_information returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Valid_cameras_information signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Valid_cameras_information( APPMSGAPPValidCamerasInformation * pAPP_Valid_cameras_information )
{
   Std_ReturnType status = C_SIG_INVALID;
   APPMSGAPPValidCamerasInformation signal_value;
   
   if( pAPP_Valid_cameras_information != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.APP_Valid_cameras_information_b8;
      * pAPP_Valid_cameras_information = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Camera1_temperature_1
*
* FUNCTION ARGUMENTS:
*    sint8 * pAPP_Camera1_temperature_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Camera1_temperature_1
*    APP_Camera1_temperature_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Camera1_temperature_1 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Camera1_temperature_1( sint8 * pAPP_Camera1_temperature_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   sint8 signal_value;
   
   if( pAPP_Camera1_temperature_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.APP_Camera1_temperature_1_sb8;
      * pAPP_Camera1_temperature_1 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Camera2_temperature_1
*
* FUNCTION ARGUMENTS:
*    sint8 * pAPP_Camera2_temperature_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Camera2_temperature_1
*    APP_Camera2_temperature_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Camera2_temperature_1 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Camera2_temperature_1( sint8 * pAPP_Camera2_temperature_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   sint8 signal_value;
   
   if( pAPP_Camera2_temperature_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.APP_Camera2_temperature_1_sb8;
      * pAPP_Camera2_temperature_1 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Camera3_temperature_1
*
* FUNCTION ARGUMENTS:
*    sint8 * pAPP_Camera3_temperature_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Camera3_temperature_1
*    APP_Camera3_temperature_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Camera3_temperature_1 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Camera3_temperature_1( sint8 * pAPP_Camera3_temperature_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   sint8 signal_value;
   
   if( pAPP_Camera3_temperature_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.APP_Camera3_temperature_1_sb8;
      * pAPP_Camera3_temperature_1 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Camera1_temperature_2
*
* FUNCTION ARGUMENTS:
*    sint8 * pAPP_Camera1_temperature_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Camera1_temperature_2
*    APP_Camera1_temperature_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Camera1_temperature_2 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Camera1_temperature_2( sint8 * pAPP_Camera1_temperature_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   sint8 signal_value;
   
   if( pAPP_Camera1_temperature_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.APP_Camera1_temperature_2_sb8;
      * pAPP_Camera1_temperature_2 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Camera2_temperature_2
*
* FUNCTION ARGUMENTS:
*    sint8 * pAPP_Camera2_temperature_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Camera2_temperature_2
*    APP_Camera2_temperature_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Camera2_temperature_2 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Camera2_temperature_2( sint8 * pAPP_Camera2_temperature_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   sint8 signal_value;
   
   if( pAPP_Camera2_temperature_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.APP_Camera2_temperature_2_sb8;
      * pAPP_Camera2_temperature_2 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Camera3_temperature_2
*
* FUNCTION ARGUMENTS:
*    sint8 * pAPP_Camera3_temperature_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Camera3_temperature_2
*    APP_Camera3_temperature_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Camera3_temperature_2 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Camera3_temperature_2( sint8 * pAPP_Camera3_temperature_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   sint8 signal_value;
   
   if( pAPP_Camera3_temperature_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.APP_Camera3_temperature_2_sb8;
      * pAPP_Camera3_temperature_2 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_App_RSRV_5
*
* FUNCTION ARGUMENTS:
*    sint8 * pApp_RSRV_5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of App_RSRV_5
*    App_RSRV_5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns App_RSRV_5 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_App_RSRV_5( sint8 * pApp_RSRV_5 )
{
   Std_ReturnType status = C_SIG_INVALID;
   sint8 signal_value;
   
   if( pApp_RSRV_5 != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.App_RSRV_5_sb8;
      * pApp_RSRV_5 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_App_RSRV_6
*
* FUNCTION ARGUMENTS:
*    sint8 * pApp_RSRV_6 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of App_RSRV_6
*    App_RSRV_6 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns App_RSRV_6 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_App_RSRV_6( sint8 * pApp_RSRV_6 )
{
   Std_ReturnType status = C_SIG_INVALID;
   sint8 signal_value;
   
   if( pApp_RSRV_6 != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.App_RSRV_6_sb8;
      * pApp_RSRV_6 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Camera1_VideoErrorRange
*
* FUNCTION ARGUMENTS:
*    APPMSGAPPCamera1VideoErrorRange * pAPP_Camera1_VideoErrorRange - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Camera1_VideoErrorRange
*    APP_Camera1_VideoErrorRange returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Camera1_VideoErrorRange signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Camera1_VideoErrorRange( APPMSGAPPCamera1VideoErrorRange * pAPP_Camera1_VideoErrorRange )
{
   Std_ReturnType status = C_SIG_INVALID;
   APPMSGAPPCamera1VideoErrorRange signal_value;
   
   if( pAPP_Camera1_VideoErrorRange != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.APP_Camera1_VideoErrorRange_b8;
      * pAPP_Camera1_VideoErrorRange = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Camera2_VideoErrorRange
*
* FUNCTION ARGUMENTS:
*    APPMSGAPPCamera2VideoErrorRange * pAPP_Camera2_VideoErrorRange - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Camera2_VideoErrorRange
*    APP_Camera2_VideoErrorRange returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Camera2_VideoErrorRange signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Camera2_VideoErrorRange( APPMSGAPPCamera2VideoErrorRange * pAPP_Camera2_VideoErrorRange )
{
   Std_ReturnType status = C_SIG_INVALID;
   APPMSGAPPCamera2VideoErrorRange signal_value;
   
   if( pAPP_Camera2_VideoErrorRange != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.APP_Camera2_VideoErrorRange_b8;
      * pAPP_Camera2_VideoErrorRange = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Camera3_VideoErrorRange
*
* FUNCTION ARGUMENTS:
*    APPMSGAPPCamera3VideoErrorRange * pAPP_Camera3_VideoErrorRange - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Camera3_VideoErrorRange
*    APP_Camera3_VideoErrorRange returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Camera3_VideoErrorRange signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Camera3_VideoErrorRange( APPMSGAPPCamera3VideoErrorRange * pAPP_Camera3_VideoErrorRange )
{
   Std_ReturnType status = C_SIG_INVALID;
   APPMSGAPPCamera3VideoErrorRange signal_value;
   
   if( pAPP_Camera3_VideoErrorRange != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.APP_Camera3_VideoErrorRange_b8;
      * pAPP_Camera3_VideoErrorRange = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_App_RSRV_7
*
* FUNCTION ARGUMENTS:
*    uint8 * pApp_RSRV_7 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of App_RSRV_7
*    App_RSRV_7 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns App_RSRV_7 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_App_RSRV_7( uint8 * pApp_RSRV_7 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pApp_RSRV_7 != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.App_RSRV_7_b8;
      * pApp_RSRV_7 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_App_RSRV_8
*
* FUNCTION ARGUMENTS:
*    uint8 * pApp_RSRV_8 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of App_RSRV_8
*    App_RSRV_8 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns App_RSRV_8 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_App_RSRV_8( uint8 * pApp_RSRV_8 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pApp_RSRV_8 != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.App_RSRV_8_b8;
      * pApp_RSRV_8 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_App_RSRV_9
*
* FUNCTION ARGUMENTS:
*    uint8 * pApp_RSRV_9 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of App_RSRV_9
*    App_RSRV_9 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns App_RSRV_9 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_App_RSRV_9( uint8 * pApp_RSRV_9 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pApp_RSRV_9 != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.App_RSRV_9_b8;
      * pApp_RSRV_9 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_App_RSRV_10
*
* FUNCTION ARGUMENTS:
*    uint8 * pApp_RSRV_10 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of App_RSRV_10
*    App_RSRV_10 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns App_RSRV_10 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_App_RSRV_10( uint8 * pApp_RSRV_10 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pApp_RSRV_10 != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.App_RSRV_10_b8;
      * pApp_RSRV_10 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_App_RSRV_11
*
* FUNCTION ARGUMENTS:
*    uint8 * pApp_RSRV_11 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of App_RSRV_11
*    App_RSRV_11 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns App_RSRV_11 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_App_RSRV_11( uint8 * pApp_RSRV_11 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pApp_RSRV_11 != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.App_RSRV_11_b8;
      * pApp_RSRV_11 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Camera1_VideoErrorFlags_pt1
*
* FUNCTION ARGUMENTS:
*    uint32 * pAPP_Camera1_VideoErrorFlags_pt1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Camera1_VideoErrorFlags_pt1
*    APP_Camera1_VideoErrorFlags_pt1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Camera1_VideoErrorFlags_pt1 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Camera1_VideoErrorFlags_pt1( uint32 * pAPP_Camera1_VideoErrorFlags_pt1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pAPP_Camera1_VideoErrorFlags_pt1 != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.APP_Camera1_VideoErrorFlags_pt1_b32;
      * pAPP_Camera1_VideoErrorFlags_pt1 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Camera2_VideoErrorFlags_pt1
*
* FUNCTION ARGUMENTS:
*    uint32 * pAPP_Camera2_VideoErrorFlags_pt1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Camera2_VideoErrorFlags_pt1
*    APP_Camera2_VideoErrorFlags_pt1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Camera2_VideoErrorFlags_pt1 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Camera2_VideoErrorFlags_pt1( uint32 * pAPP_Camera2_VideoErrorFlags_pt1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pAPP_Camera2_VideoErrorFlags_pt1 != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.APP_Camera2_VideoErrorFlags_pt1_b32;
      * pAPP_Camera2_VideoErrorFlags_pt1 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Camera3_VideoErrorFlags_pt1
*
* FUNCTION ARGUMENTS:
*    uint32 * pAPP_Camera3_VideoErrorFlags_pt1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Camera3_VideoErrorFlags_pt1
*    APP_Camera3_VideoErrorFlags_pt1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Camera3_VideoErrorFlags_pt1 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Camera3_VideoErrorFlags_pt1( uint32 * pAPP_Camera3_VideoErrorFlags_pt1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pAPP_Camera3_VideoErrorFlags_pt1 != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.APP_Camera3_VideoErrorFlags_pt1_b32;
      * pAPP_Camera3_VideoErrorFlags_pt1 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Brain_drops_counter
*
* FUNCTION ARGUMENTS:
*    uint32 * pAPP_Brain_drops_counter - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Brain_drops_counter
*    APP_Brain_drops_counter returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Brain_drops_counter signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Brain_drops_counter( uint32 * pAPP_Brain_drops_counter )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pAPP_Brain_drops_counter != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.APP_Brain_drops_counter_b32;
      * pAPP_Brain_drops_counter = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_appMode
*
* FUNCTION ARGUMENTS:
*    uint32 * pAPP_appMode - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_appMode
*    APP_appMode returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_appMode signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_appMode( uint32 * pAPP_appMode )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pAPP_appMode != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.APP_appMode_b32;
      * pAPP_appMode = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Application_ver
*
* FUNCTION ARGUMENTS:
*    uint32 * pAPP_Application_ver - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Application_ver
*    APP_Application_ver returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Application_ver signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Application_ver( uint32 * pAPP_Application_ver )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pAPP_Application_ver != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.APP_Application_ver_b32;
      * pAPP_Application_ver = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_App_RSRV_12
*
* FUNCTION ARGUMENTS:
*    uint32 * pApp_RSRV_12 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of App_RSRV_12
*    App_RSRV_12 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns App_RSRV_12 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_App_RSRV_12( uint32 * pApp_RSRV_12 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pApp_RSRV_12 != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.App_RSRV_12_b32;
      * pApp_RSRV_12 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_App_RSRV_13
*
* FUNCTION ARGUMENTS:
*    uint32 * pApp_RSRV_13 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of App_RSRV_13
*    App_RSRV_13 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns App_RSRV_13 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_App_RSRV_13( uint32 * pApp_RSRV_13 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pApp_RSRV_13 != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.App_RSRV_13_b32;
      * pApp_RSRV_13 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Camera1_VideoErrorFlags_pt2
*
* FUNCTION ARGUMENTS:
*    uint32 * pAPP_Camera1_VideoErrorFlags_pt2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Camera1_VideoErrorFlags_pt2
*    APP_Camera1_VideoErrorFlags_pt2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Camera1_VideoErrorFlags_pt2 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Camera1_VideoErrorFlags_pt2( uint32 * pAPP_Camera1_VideoErrorFlags_pt2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pAPP_Camera1_VideoErrorFlags_pt2 != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.APP_Camera1_VideoErrorFlags_pt2_b32;
      * pAPP_Camera1_VideoErrorFlags_pt2 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Camera2_VideoErrorFlags_pt2
*
* FUNCTION ARGUMENTS:
*    uint32 * pAPP_Camera2_VideoErrorFlags_pt2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Camera2_VideoErrorFlags_pt2
*    APP_Camera2_VideoErrorFlags_pt2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Camera2_VideoErrorFlags_pt2 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Camera2_VideoErrorFlags_pt2( uint32 * pAPP_Camera2_VideoErrorFlags_pt2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pAPP_Camera2_VideoErrorFlags_pt2 != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.APP_Camera2_VideoErrorFlags_pt2_b32;
      * pAPP_Camera2_VideoErrorFlags_pt2 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Camera3_VideoErrorFlags_pt2
*
* FUNCTION ARGUMENTS:
*    uint32 * pAPP_Camera3_VideoErrorFlags_pt2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Camera3_VideoErrorFlags_pt2
*    APP_Camera3_VideoErrorFlags_pt2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Camera3_VideoErrorFlags_pt2 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Camera3_VideoErrorFlags_pt2( uint32 * pAPP_Camera3_VideoErrorFlags_pt2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pAPP_Camera3_VideoErrorFlags_pt2 != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.APP_Camera3_VideoErrorFlags_pt2_b32;
      * pAPP_Camera3_VideoErrorFlags_pt2 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_SPI_Bus_Load_Tx
*
* FUNCTION ARGUMENTS:
*    uint32 * pAPP_SPI_Bus_Load_Tx - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_SPI_Bus_Load_Tx
*    APP_SPI_Bus_Load_Tx returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_SPI_Bus_Load_Tx signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_SPI_Bus_Load_Tx( uint32 * pAPP_SPI_Bus_Load_Tx )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pAPP_SPI_Bus_Load_Tx != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.APP_SPI_Bus_Load_Tx_b32;
      * pAPP_SPI_Bus_Load_Tx = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_SPI_Bus_Load_Rx
*
* FUNCTION ARGUMENTS:
*    uint32 * pAPP_SPI_Bus_Load_Rx - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_SPI_Bus_Load_Rx
*    APP_SPI_Bus_Load_Rx returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_SPI_Bus_Load_Rx signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_SPI_Bus_Load_Rx( uint32 * pAPP_SPI_Bus_Load_Rx )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pAPP_SPI_Bus_Load_Rx != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.APP_SPI_Bus_Load_Rx_b32;
      * pAPP_SPI_Bus_Load_Rx = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_SPI_Retransmit_Tx
*
* FUNCTION ARGUMENTS:
*    uint32 * pAPP_SPI_Retransmit_Tx - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_SPI_Retransmit_Tx
*    APP_SPI_Retransmit_Tx returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_SPI_Retransmit_Tx signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_SPI_Retransmit_Tx( uint32 * pAPP_SPI_Retransmit_Tx )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pAPP_SPI_Retransmit_Tx != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.APP_SPI_Retransmit_Tx_b32;
      * pAPP_SPI_Retransmit_Tx = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_App_RSRV_14
*
* FUNCTION ARGUMENTS:
*    uint32 * pApp_RSRV_14 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of App_RSRV_14
*    App_RSRV_14 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns App_RSRV_14 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_App_RSRV_14( uint32 * pApp_RSRV_14 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pApp_RSRV_14 != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.App_RSRV_14_b32;
      * pApp_RSRV_14 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_App_CRC32
*
* FUNCTION ARGUMENTS:
*    uint32 * pApp_CRC32 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of App_CRC32
*    App_CRC32 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns App_CRC32 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_App_CRC32( uint32 * pApp_CRC32 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pApp_CRC32 != C_NULL_P )
   {
      signal_value = EYEQMSG_APPMSG_ParamsApp_s.App_CRC32_b32;
      * pApp_CRC32 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

