

/*****************************************************************************
                  Include files
*****************************************************************************/
/* The suggested include file order is: */
#include "EyeQ_defs.h"    /* EyeQ project common definitions file    */

#include "EYEQMSG_CoreLaneAdjProcess.h"

/*****************************************************************************
                  Local symbolic constants
*****************************************************************************/
/*****************************************************************************
                  Local types, enums definitions
*****************************************************************************/
/*****************************************************************************
                  Local function prototypes
*****************************************************************************/
/*****************************************************************************
                  Local object definitions
*****************************************************************************/
/*****************************************************************************
                  Exported object definitions
*****************************************************************************/
EYEQMSG_CORELANEADJ_Params_t   EYEQMSG_CORELANEADJ_Params_s;
EYEQMSG_CORELANEADJ_Params_t   EYEQMSG_CORELANEADJ_ParamsApp_s;
/*****************************************************************************
                  Local function-like macros
*****************************************************************************/
/*****************************************************************************
                  Local defined macros
*****************************************************************************/
/*****************************************************************************
                  Function definitions
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvH_LA_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pLA_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LA_Zero_byte
*    LA_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LA_Zero_byte signal value of Virtual_HEADER_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvH_LA_Zero_byte( uint8 * pLA_Zero_byte )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pLA_Zero_byte != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELANEADJ_ParamsApp_s.EYEQMSG_CORELANEADJvH_Params_s.LA_Zero_byte_b8;
      * pLA_Zero_byte = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvH_LA_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pLA_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LA_Protocol_Version
*    LA_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LA_Protocol_Version signal value of Virtual_HEADER_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvH_LA_Protocol_Version( uint8 * pLA_Protocol_Version )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pLA_Protocol_Version != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELANEADJ_ParamsApp_s.EYEQMSG_CORELANEADJvH_Params_s.LA_Protocol_Version_b8;
      * pLA_Protocol_Version = signal_value;
      if( (signal_value >= C_EYEQMSG_CORELANEADJvH_LA_PROTOCOL_VERSION_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORELANEADJvH_LA_PROTOCOL_VERSION_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvH_LA_Sync_ID
*
* FUNCTION ARGUMENTS:
*    uint8 * pLA_Sync_ID - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LA_Sync_ID
*    LA_Sync_ID returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LA_Sync_ID signal value of Virtual_HEADER_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvH_LA_Sync_ID( uint8 * pLA_Sync_ID )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pLA_Sync_ID != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELANEADJ_ParamsApp_s.EYEQMSG_CORELANEADJvH_Params_s.LA_Sync_ID_b8;
      * pLA_Sync_ID = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvH_LA_Adjacent_Count
*
* FUNCTION ARGUMENTS:
*    uint8 * pLA_Adjacent_Count - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LA_Adjacent_Count
*    LA_Adjacent_Count returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LA_Adjacent_Count signal value of Virtual_HEADER_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvH_LA_Adjacent_Count( uint8 * pLA_Adjacent_Count )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pLA_Adjacent_Count != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELANEADJ_ParamsApp_s.EYEQMSG_CORELANEADJvH_Params_s.LA_Adjacent_Count_b4;
      * pLA_Adjacent_Count = signal_value;
      if( signal_value <= C_EYEQMSG_CORELANEADJvH_LA_ADJACENT_COUNT_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvH_Reserved_1
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1
*    Reserved_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1 signal value of Virtual_HEADER_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvH_Reserved_1( uint8 * pReserved_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pReserved_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELANEADJ_ParamsApp_s.EYEQMSG_CORELANEADJvH_Params_s.Reserved_1_b4;
      * pReserved_1 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELANEADJvH_RESERVED_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_LA_Lane_Track_ID_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLA_Lane_Track_ID_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LA_Lane_Track_ID_0
*    LA_Lane_Track_ID_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LA_Lane_Track_ID_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_LA_Lane_Track_ID_0( uint8 objIndx_u8, uint8 * pLA_Lane_Track_ID_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEADJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLA_Lane_Track_ID_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEADJ_ParamsApp_s.EYEQMSG_CORELANEADJvO_Params_as[objIndx_u8].LA_Lane_Track_ID_0_b8;
         * pLA_Lane_Track_ID_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_LA_Age_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLA_Age_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LA_Age_0
*    LA_Age_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LA_Age_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_LA_Age_0( uint8 objIndx_u8, uint8 * pLA_Age_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEADJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLA_Age_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEADJ_ParamsApp_s.EYEQMSG_CORELANEADJvO_Params_as[objIndx_u8].LA_Age_0_b8;
         * pLA_Age_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_LA_Confidence_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLA_Confidence_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LA_Confidence_0
*    LA_Confidence_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LA_Confidence_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_LA_Confidence_0( uint8 objIndx_u8, uint8 * pLA_Confidence_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEADJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLA_Confidence_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEADJ_ParamsApp_s.EYEQMSG_CORELANEADJvO_Params_as[objIndx_u8].LA_Confidence_0_b7;
         * pLA_Confidence_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEADJvO_LA_CONFIDENCE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_LA_Color_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANEADJvOLAColor0 * pLA_Color_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LA_Color_0
*    LA_Color_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LA_Color_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_LA_Color_0( uint8 objIndx_u8, CORELANEADJvOLAColor0 * pLA_Color_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELANEADJvOLAColor0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEADJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLA_Color_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEADJ_ParamsApp_s.EYEQMSG_CORELANEADJvO_Params_as[objIndx_u8].LA_Color_0_b2;
         * pLA_Color_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_LA_Color_Conf_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLA_Color_Conf_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LA_Color_Conf_0
*    LA_Color_Conf_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LA_Color_Conf_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_LA_Color_Conf_0( uint8 objIndx_u8, uint8 * pLA_Color_Conf_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEADJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLA_Color_Conf_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEADJ_ParamsApp_s.EYEQMSG_CORELANEADJvO_Params_as[objIndx_u8].LA_Color_Conf_0_b7;
         * pLA_Color_Conf_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEADJvO_LA_COLOR_CONF_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_LA_Prediction_Reason_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANEADJvOLAPredictionReason0 * pLA_Prediction_Reason_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LA_Prediction_Reason_0
*    LA_Prediction_Reason_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LA_Prediction_Reason_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_LA_Prediction_Reason_0( uint8 objIndx_u8, CORELANEADJvOLAPredictionReason0 * pLA_Prediction_Reason_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELANEADJvOLAPredictionReason0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEADJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLA_Prediction_Reason_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEADJ_ParamsApp_s.EYEQMSG_CORELANEADJvO_Params_as[objIndx_u8].LA_Prediction_Reason_0_b6;
         * pLA_Prediction_Reason_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_LA_Availability_State_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANEADJvOLAAvailabilityState0 * pLA_Availability_State_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LA_Availability_State_0
*    LA_Availability_State_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LA_Availability_State_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_LA_Availability_State_0( uint8 objIndx_u8, CORELANEADJvOLAAvailabilityState0 * pLA_Availability_State_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELANEADJvOLAAvailabilityState0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEADJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLA_Availability_State_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEADJ_ParamsApp_s.EYEQMSG_CORELANEADJvO_Params_as[objIndx_u8].LA_Availability_State_0_b2;
         * pLA_Availability_State_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEADJvO_LA_AVAILABILITY_STATE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_LA_View_Range_Start_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLA_View_Range_Start_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LA_View_Range_Start_0
*    LA_View_Range_Start_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LA_View_Range_Start_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_LA_View_Range_Start_0( uint8 objIndx_u8, uint16 * pLA_View_Range_Start_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEADJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLA_View_Range_Start_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEADJ_ParamsApp_s.EYEQMSG_CORELANEADJvO_Params_as[objIndx_u8].LA_View_Range_Start_0_b15;
         * pLA_View_Range_Start_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEADJvO_LA_VIEW_RANGE_START_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_Reserved_2_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pReserved_2_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_2_0
*    Reserved_2_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_2_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_Reserved_2_0( uint8 objIndx_u8, uint16 * pReserved_2_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEADJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_2_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEADJ_ParamsApp_s.EYEQMSG_CORELANEADJvO_Params_as[objIndx_u8].Reserved_2_0_b9;
         * pReserved_2_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEADJvO_RESERVED_2_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_LA_View_Range_End_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLA_View_Range_End_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LA_View_Range_End_0
*    LA_View_Range_End_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LA_View_Range_End_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_LA_View_Range_End_0( uint8 objIndx_u8, uint16 * pLA_View_Range_End_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEADJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLA_View_Range_End_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEADJ_ParamsApp_s.EYEQMSG_CORELANEADJvO_Params_as[objIndx_u8].LA_View_Range_End_0_b15;
         * pLA_View_Range_End_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEADJvO_LA_VIEW_RANGE_END_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_LA_Measured_VR_End_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLA_Measured_VR_End_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LA_Measured_VR_End_0
*    LA_Measured_VR_End_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LA_Measured_VR_End_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_LA_Measured_VR_End_0( uint8 objIndx_u8, uint16 * pLA_Measured_VR_End_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEADJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLA_Measured_VR_End_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEADJ_ParamsApp_s.EYEQMSG_CORELANEADJvO_Params_as[objIndx_u8].LA_Measured_VR_End_0_b15;
         * pLA_Measured_VR_End_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEADJvO_LA_MEASURED_VR_END_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_Reserved_3_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_3_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_3_0
*    Reserved_3_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_3_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_Reserved_3_0( uint8 objIndx_u8, uint8 * pReserved_3_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEADJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_3_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEADJ_ParamsApp_s.EYEQMSG_CORELANEADJvO_Params_as[objIndx_u8].Reserved_3_0_b2;
         * pReserved_3_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEADJvO_RESERVED_3_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_LA_Lanemark_Type_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANEADJvOLALanemarkType0 * pLA_Lanemark_Type_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LA_Lanemark_Type_0
*    LA_Lanemark_Type_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LA_Lanemark_Type_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_LA_Lanemark_Type_0( uint8 objIndx_u8, CORELANEADJvOLALanemarkType0 * pLA_Lanemark_Type_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELANEADJvOLALanemarkType0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEADJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLA_Lanemark_Type_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEADJ_ParamsApp_s.EYEQMSG_CORELANEADJvO_Params_as[objIndx_u8].LA_Lanemark_Type_0_b4;
         * pLA_Lanemark_Type_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEADJvO_LA_LANEMARK_TYPE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_LA_DLM_Type_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANEADJvOLADLMType0 * pLA_DLM_Type_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LA_DLM_Type_0
*    LA_DLM_Type_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LA_DLM_Type_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_LA_DLM_Type_0( uint8 objIndx_u8, CORELANEADJvOLADLMType0 * pLA_DLM_Type_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELANEADJvOLADLMType0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEADJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLA_DLM_Type_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEADJ_ParamsApp_s.EYEQMSG_CORELANEADJvO_Params_as[objIndx_u8].LA_DLM_Type_0_b3;
         * pLA_DLM_Type_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEADJvO_LA_DLM_TYPE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_LA_Lanemark_Type_Conf_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLA_Lanemark_Type_Conf_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LA_Lanemark_Type_Conf_0
*    LA_Lanemark_Type_Conf_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LA_Lanemark_Type_Conf_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_LA_Lanemark_Type_Conf_0( uint8 objIndx_u8, uint8 * pLA_Lanemark_Type_Conf_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEADJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLA_Lanemark_Type_Conf_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEADJ_ParamsApp_s.EYEQMSG_CORELANEADJvO_Params_as[objIndx_u8].LA_Lanemark_Type_Conf_0_b7;
         * pLA_Lanemark_Type_Conf_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEADJvO_LA_LANEMARK_TYPE_CONF_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_LA_Line_Side_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANEADJvOLALineSide0 * pLA_Line_Side_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LA_Line_Side_0
*    LA_Line_Side_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LA_Line_Side_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_LA_Line_Side_0( uint8 objIndx_u8, CORELANEADJvOLALineSide0 * pLA_Line_Side_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELANEADJvOLALineSide0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEADJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLA_Line_Side_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEADJ_ParamsApp_s.EYEQMSG_CORELANEADJvO_Params_as[objIndx_u8].LA_Line_Side_0_b4;
         * pLA_Line_Side_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEADJvO_LA_LINE_SIDE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_LA_Marker_Width_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLA_Marker_Width_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LA_Marker_Width_0
*    LA_Marker_Width_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LA_Marker_Width_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_LA_Marker_Width_0( uint8 objIndx_u8, uint8 * pLA_Marker_Width_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEADJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLA_Marker_Width_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEADJ_ParamsApp_s.EYEQMSG_CORELANEADJvO_Params_as[objIndx_u8].LA_Marker_Width_0_b8;
         * pLA_Marker_Width_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEADJvO_LA_MARKER_WIDTH_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_Reserved_4_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_4_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_4_0
*    Reserved_4_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_4_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_Reserved_4_0( uint8 objIndx_u8, uint8 * pReserved_4_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEADJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_4_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEADJ_ParamsApp_s.EYEQMSG_CORELANEADJvO_Params_as[objIndx_u8].Reserved_4_0_b6;
         * pReserved_4_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEADJvO_RESERVED_4_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_LA_Marker_Width_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLA_Marker_Width_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LA_Marker_Width_STD_0
*    LA_Marker_Width_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LA_Marker_Width_STD_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_LA_Marker_Width_STD_0( uint8 objIndx_u8, uint8 * pLA_Marker_Width_STD_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEADJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLA_Marker_Width_STD_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEADJ_ParamsApp_s.EYEQMSG_CORELANEADJvO_Params_as[objIndx_u8].LA_Marker_Width_STD_0_b7;
         * pLA_Marker_Width_STD_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEADJvO_LA_MARKER_WIDTH_STD_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_Reserved_5_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint32 * pReserved_5_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_5_0
*    Reserved_5_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_5_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_Reserved_5_0( uint8 objIndx_u8, uint32 * pReserved_5_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEADJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_5_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEADJ_ParamsApp_s.EYEQMSG_CORELANEADJvO_Params_as[objIndx_u8].Reserved_5_0_b25;
         * pReserved_5_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEADJvO_RESERVED_5_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_LA_Line_C3_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    float32 * pLA_Line_C3_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LA_Line_C3_0
*    LA_Line_C3_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LA_Line_C3_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_LA_Line_C3_0( uint8 objIndx_u8, float32 * pLA_Line_C3_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float32SigDataType signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEADJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLA_Line_C3_0 != C_NULL_P )
      {
         signal_value.u = EYEQMSG_CORELANEADJ_ParamsApp_s.EYEQMSG_CORELANEADJvO_Params_as[objIndx_u8].LA_Line_C3_0_sb32;
         * pLA_Line_C3_0 = signal_value.f;
         if( (signal_value.f >= C_EYEQMSG_CORELANEADJvO_LA_LINE_C3_0_RMIN ) 
             && (signal_value.f <= C_EYEQMSG_CORELANEADJvO_LA_LINE_C3_0_RMAX ) )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_LA_Line_C2_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    float32 * pLA_Line_C2_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LA_Line_C2_0
*    LA_Line_C2_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LA_Line_C2_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_LA_Line_C2_0( uint8 objIndx_u8, float32 * pLA_Line_C2_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float32SigDataType signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEADJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLA_Line_C2_0 != C_NULL_P )
      {
         signal_value.u = EYEQMSG_CORELANEADJ_ParamsApp_s.EYEQMSG_CORELANEADJvO_Params_as[objIndx_u8].LA_Line_C2_0_sb32;
         * pLA_Line_C2_0 = signal_value.f;
         if( (signal_value.f >= C_EYEQMSG_CORELANEADJvO_LA_LINE_C2_0_RMIN ) 
             && (signal_value.f <= C_EYEQMSG_CORELANEADJvO_LA_LINE_C2_0_RMAX ) )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_LA_Line_C1_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    float32 * pLA_Line_C1_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LA_Line_C1_0
*    LA_Line_C1_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LA_Line_C1_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_LA_Line_C1_0( uint8 objIndx_u8, float32 * pLA_Line_C1_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float32SigDataType signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEADJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLA_Line_C1_0 != C_NULL_P )
      {
         signal_value.u = EYEQMSG_CORELANEADJ_ParamsApp_s.EYEQMSG_CORELANEADJvO_Params_as[objIndx_u8].LA_Line_C1_0_sb32;
         * pLA_Line_C1_0 = signal_value.f;
         if( (signal_value.f >= C_EYEQMSG_CORELANEADJvO_LA_LINE_C1_0_RMIN ) 
             && (signal_value.f <= C_EYEQMSG_CORELANEADJvO_LA_LINE_C1_0_RMAX ) )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_LA_Line_C0_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    float32 * pLA_Line_C0_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LA_Line_C0_0
*    LA_Line_C0_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LA_Line_C0_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_LA_Line_C0_0( uint8 objIndx_u8, float32 * pLA_Line_C0_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float32SigDataType signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEADJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLA_Line_C0_0 != C_NULL_P )
      {
         signal_value.u = EYEQMSG_CORELANEADJ_ParamsApp_s.EYEQMSG_CORELANEADJvO_Params_as[objIndx_u8].LA_Line_C0_0_sb32;
         * pLA_Line_C0_0 = signal_value.f;
         if( (signal_value.f >= C_EYEQMSG_CORELANEADJvO_LA_LINE_C0_0_RMIN ) 
             && (signal_value.f <= C_EYEQMSG_CORELANEADJvO_LA_LINE_C0_0_RMAX ) )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_LA_Detection_Source_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANEADJvOLADetectionSource0 * pLA_Detection_Source_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LA_Detection_Source_0
*    LA_Detection_Source_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LA_Detection_Source_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_LA_Detection_Source_0( uint8 objIndx_u8, CORELANEADJvOLADetectionSource0 * pLA_Detection_Source_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELANEADJvOLADetectionSource0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEADJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLA_Detection_Source_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEADJ_ParamsApp_s.EYEQMSG_CORELANEADJvO_Params_as[objIndx_u8].LA_Detection_Source_0_b2;
         * pLA_Detection_Source_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_Reserved_6_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint32 * pReserved_6_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_6_0
*    Reserved_6_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_6_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_Reserved_6_0( uint8 objIndx_u8, uint32 * pReserved_6_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEADJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_6_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEADJ_ParamsApp_s.EYEQMSG_CORELANEADJvO_Params_as[objIndx_u8].Reserved_6_0_b30;
         * pReserved_6_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEADJvO_RESERVED_6_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_CORELANEADJ_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_CORELANEADJ_Params_t * pCore_Lanes_Adjacent_protocol - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_Lanes_Adjacent_protocol message 
*    Core_Lanes_Adjacent_protocol message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_Lanes_Adjacent_protocol message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_CORELANEADJ_ParamsApp_MsgDataStruct( EYEQMSG_CORELANEADJ_Params_t * pCore_Lanes_Adjacent_protocol )
{
   Std_ReturnType status = C_SIG_INVALID;
   if( pCore_Lanes_Adjacent_protocol != C_NULL_P )
   {
      status = C_SIG_VALID;
      * pCore_Lanes_Adjacent_protocol = EYEQMSG_CORELANEADJ_ParamsApp_s;
   }
   return ( status );
}

