

/*****************************************************************************
                  Include files
*****************************************************************************/
/* The suggested include file order is: */
#include "EyeQ_defs.h"    /* EyeQ project common definitions file    */

#include "EYEQMSG_BootDiagMsgProcess.h"

/*****************************************************************************
                  Local symbolic constants
*****************************************************************************/
/*****************************************************************************
                  Local types, enums definitions
*****************************************************************************/
/*****************************************************************************
                  Local function prototypes
*****************************************************************************/
/*****************************************************************************
                  Local object definitions
*****************************************************************************/
/*****************************************************************************
                  Exported object definitions
*****************************************************************************/
EYEQMSG_BOOTDIAGMSG_Params_t   EYEQMSG_BOOTDIAGMSG_Params_s;
EYEQMSG_BOOTDIAGMSG_Params_t   EYEQMSG_BOOTDIAGMSG_ParamsApp_s;
/*****************************************************************************
                  Local function-like macros
*****************************************************************************/
/*****************************************************************************
                  Local defined macros
*****************************************************************************/
/*****************************************************************************
                  Function definitions
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_BOOTDIAGMSG_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_BOOTDIAGMSG_Params_t * pCore_Boot_Diagnostics_Message_protocol - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_Boot_Diagnostics_Message_protocol message 
*    Core_Boot_Diagnostics_Message_protocol message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_Boot_Diagnostics_Message_protocol message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_BOOTDIAGMSG_ParamsApp_MsgDataStruct( EYEQMSG_BOOTDIAGMSG_Params_t * pCore_Boot_Diagnostics_Message_protocol )
{
   Std_ReturnType status = C_SIG_INVALID;
   if( pCore_Boot_Diagnostics_Message_protocol != C_NULL_P )
   {
      status = C_SIG_VALID;
      * pCore_Boot_Diagnostics_Message_protocol = EYEQMSG_BOOTDIAGMSG_ParamsApp_s;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BOOT_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pBOOT_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BOOT_Zero_byte
*    BOOT_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BOOT_Zero_byte signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BOOT_Zero_byte( uint8 * pBOOT_Zero_byte )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pBOOT_Zero_byte != C_NULL_P )
   {
      signal_value = EYEQMSG_BOOTDIAGMSG_ParamsApp_s.BOOT_Zero_byte_b8;
      * pBOOT_Zero_byte = signal_value;
      if( signal_value <= C_EYEQMSG_BOOTDIAGMSG_BOOT_ZERO_BYTE_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BootMsg_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pBootMsg_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BootMsg_Protocol_Version
*    BootMsg_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BootMsg_Protocol_Version signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BootMsg_Protocol_Version( uint8 * pBootMsg_Protocol_Version )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pBootMsg_Protocol_Version != C_NULL_P )
   {
      signal_value = EYEQMSG_BOOTDIAGMSG_ParamsApp_s.BootMsg_Protocol_Version_b8;
      * pBootMsg_Protocol_Version = signal_value;
      if( (signal_value >= C_EYEQMSG_BOOTDIAGMSG_BOOTMSG_PROTOCOL_VERSION_RMIN ) 
          && (signal_value <= C_EYEQMSG_BOOTDIAGMSG_BOOTMSG_PROTOCOL_VERSION_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_Reserved_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pReserved_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1
*    Reserved_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1 signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_Reserved_1( uint16 * pReserved_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pReserved_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_BOOTDIAGMSG_ParamsApp_s.Reserved_1_b16;
      * pReserved_1 = signal_value;
      if( signal_value <= C_EYEQMSG_BOOTDIAGMSG_RESERVED_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BOOT_Test_results
*
* FUNCTION ARGUMENTS:
*    BOOTDIAGMSGBOOTTestResults * pBOOT_Test_results - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BOOT_Test_results
*    BOOT_Test_results returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BOOT_Test_results signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BOOT_Test_results( BOOTDIAGMSGBOOTTestResults * pBOOT_Test_results )
{
   Std_ReturnType status = C_SIG_INVALID;
   BOOTDIAGMSGBOOTTestResults signal_value;
   
   if( pBOOT_Test_results != C_NULL_P )
   {
      signal_value = EYEQMSG_BOOTDIAGMSG_ParamsApp_s.BOOT_Test_results_b16;
      * pBOOT_Test_results = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BOOT_Board_project_code
*
* FUNCTION ARGUMENTS:
*    uint8 * pBOOT_Board_project_code - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BOOT_Board_project_code
*    BOOT_Board_project_code returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BOOT_Board_project_code signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BOOT_Board_project_code( uint8 * pBOOT_Board_project_code )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pBOOT_Board_project_code != C_NULL_P )
   {
      signal_value = EYEQMSG_BOOTDIAGMSG_ParamsApp_s.BOOT_Board_project_code_b8;
      * pBOOT_Board_project_code = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BOOT_Board_revision
*
* FUNCTION ARGUMENTS:
*    uint8 * pBOOT_Board_revision - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BOOT_Board_revision
*    BOOT_Board_revision returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BOOT_Board_revision signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BOOT_Board_revision( uint8 * pBOOT_Board_revision )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pBOOT_Board_revision != C_NULL_P )
   {
      signal_value = EYEQMSG_BOOTDIAGMSG_ParamsApp_s.BOOT_Board_revision_b8;
      * pBOOT_Board_revision = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BOOT_Ver
*
* FUNCTION ARGUMENTS:
*    uint32 * pBOOT_Ver - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BOOT_Ver
*    BOOT_Ver returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BOOT_Ver signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BOOT_Ver( uint32 * pBOOT_Ver )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pBOOT_Ver != C_NULL_P )
   {
      signal_value = EYEQMSG_BOOTDIAGMSG_ParamsApp_s.BOOT_Ver_b32;
      * pBOOT_Ver = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BOOT_Application_ver
*
* FUNCTION ARGUMENTS:
*    uint32 * pBOOT_Application_ver - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BOOT_Application_ver
*    BOOT_Application_ver returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BOOT_Application_ver signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BOOT_Application_ver( uint32 * pBOOT_Application_ver )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pBOOT_Application_ver != C_NULL_P )
   {
      signal_value = EYEQMSG_BOOTDIAGMSG_ParamsApp_s.BOOT_Application_ver_b32;
      * pBOOT_Application_ver = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BOOT_EyeQ_Type
*
* FUNCTION ARGUMENTS:
*    uint32 * pBOOT_EyeQ_Type - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BOOT_EyeQ_Type
*    BOOT_EyeQ_Type returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BOOT_EyeQ_Type signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BOOT_EyeQ_Type( uint32 * pBOOT_EyeQ_Type )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pBOOT_EyeQ_Type != C_NULL_P )
   {
      signal_value = EYEQMSG_BOOTDIAGMSG_ParamsApp_s.BOOT_EyeQ_Type_b32;
      * pBOOT_EyeQ_Type = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BOOT_EyeQ_ID
*
* FUNCTION ARGUMENTS:
*    uint32 * pBOOT_EyeQ_ID - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BOOT_EyeQ_ID
*    BOOT_EyeQ_ID returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BOOT_EyeQ_ID signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BOOT_EyeQ_ID( uint32 * pBOOT_EyeQ_ID )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pBOOT_EyeQ_ID != C_NULL_P )
   {
      signal_value = EYEQMSG_BOOTDIAGMSG_ParamsApp_s.BOOT_EyeQ_ID_b32;
      * pBOOT_EyeQ_ID = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BOOT_DDR_manufacturer_code
*
* FUNCTION ARGUMENTS:
*    uint8 * pBOOT_DDR_manufacturer_code - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BOOT_DDR_manufacturer_code
*    BOOT_DDR_manufacturer_code returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BOOT_DDR_manufacturer_code signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BOOT_DDR_manufacturer_code( uint8 * pBOOT_DDR_manufacturer_code )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pBOOT_DDR_manufacturer_code != C_NULL_P )
   {
      signal_value = EYEQMSG_BOOTDIAGMSG_ParamsApp_s.BOOT_DDR_manufacturer_code_b8;
      * pBOOT_DDR_manufacturer_code = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BOOT_DDR_Size
*
* FUNCTION ARGUMENTS:
*    uint32 * pBOOT_DDR_Size - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BOOT_DDR_Size
*    BOOT_DDR_Size returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BOOT_DDR_Size signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BOOT_DDR_Size( uint32 * pBOOT_DDR_Size )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pBOOT_DDR_Size != C_NULL_P )
   {
      signal_value = EYEQMSG_BOOTDIAGMSG_ParamsApp_s.BOOT_DDR_Size_b24;
      * pBOOT_DDR_Size = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BOOT_Flash_Man_Code
*
* FUNCTION ARGUMENTS:
*    uint8 * pBOOT_Flash_Man_Code - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BOOT_Flash_Man_Code
*    BOOT_Flash_Man_Code returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BOOT_Flash_Man_Code signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BOOT_Flash_Man_Code( uint8 * pBOOT_Flash_Man_Code )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pBOOT_Flash_Man_Code != C_NULL_P )
   {
      signal_value = EYEQMSG_BOOTDIAGMSG_ParamsApp_s.BOOT_Flash_Man_Code_b8;
      * pBOOT_Flash_Man_Code = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BOOT_Flash_Size
*
* FUNCTION ARGUMENTS:
*    uint32 * pBOOT_Flash_Size - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BOOT_Flash_Size
*    BOOT_Flash_Size returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BOOT_Flash_Size signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BOOT_Flash_Size( uint32 * pBOOT_Flash_Size )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pBOOT_Flash_Size != C_NULL_P )
   {
      signal_value = EYEQMSG_BOOTDIAGMSG_ParamsApp_s.BOOT_Flash_Size_b24;
      * pBOOT_Flash_Size = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BOOT_CPU_Temperature
*
* FUNCTION ARGUMENTS:
*    sint8 * pBOOT_CPU_Temperature - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BOOT_CPU_Temperature
*    BOOT_CPU_Temperature returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BOOT_CPU_Temperature signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BOOT_CPU_Temperature( sint8 * pBOOT_CPU_Temperature )
{
   Std_ReturnType status = C_SIG_INVALID;
   sint8 signal_value;
   
   if( pBOOT_CPU_Temperature != C_NULL_P )
   {
      signal_value = EYEQMSG_BOOTDIAGMSG_ParamsApp_s.BOOT_CPU_Temperature_sb8;
      * pBOOT_CPU_Temperature = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BOOT_VMP_Temperature
*
* FUNCTION ARGUMENTS:
*    sint8 * pBOOT_VMP_Temperature - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BOOT_VMP_Temperature
*    BOOT_VMP_Temperature returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BOOT_VMP_Temperature signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BOOT_VMP_Temperature( sint8 * pBOOT_VMP_Temperature )
{
   Std_ReturnType status = C_SIG_INVALID;
   sint8 signal_value;
   
   if( pBOOT_VMP_Temperature != C_NULL_P )
   {
      signal_value = EYEQMSG_BOOTDIAGMSG_ParamsApp_s.BOOT_VMP_Temperature_sb8;
      * pBOOT_VMP_Temperature = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BOOT_LPDDR4_Temperature_Status
*
* FUNCTION ARGUMENTS:
*    BOOTDIAGMSGBOOTLPDDR4TemperatureStatus * pBOOT_LPDDR4_Temperature_Status - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BOOT_LPDDR4_Temperature_Status
*    BOOT_LPDDR4_Temperature_Status returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BOOT_LPDDR4_Temperature_Status signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BOOT_LPDDR4_Temperature_Status( BOOTDIAGMSGBOOTLPDDR4TemperatureStatus * pBOOT_LPDDR4_Temperature_Status )
{
   Std_ReturnType status = C_SIG_INVALID;
   BOOTDIAGMSGBOOTLPDDR4TemperatureStatus signal_value;
   
   if( pBOOT_LPDDR4_Temperature_Status != C_NULL_P )
   {
      signal_value = EYEQMSG_BOOTDIAGMSG_ParamsApp_s.BOOT_LPDDR4_Temperature_Status_b8;
      * pBOOT_LPDDR4_Temperature_Status = signal_value;
      if( signal_value <= C_EYEQMSG_BOOTDIAGMSG_BOOT_LPDDR4_TEMPERATURE_STATUS_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_Reserved_2
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_2
*    Reserved_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_2 signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_Reserved_2( uint8 * pReserved_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pReserved_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_BOOTDIAGMSG_ParamsApp_s.Reserved_2_b8;
      * pReserved_2 = signal_value;
      if( signal_value <= C_EYEQMSG_BOOTDIAGMSG_RESERVED_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BOOT_Flash2_Man_Code
*
* FUNCTION ARGUMENTS:
*    uint8 * pBOOT_Flash2_Man_Code - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BOOT_Flash2_Man_Code
*    BOOT_Flash2_Man_Code returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BOOT_Flash2_Man_Code signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BOOT_Flash2_Man_Code( uint8 * pBOOT_Flash2_Man_Code )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pBOOT_Flash2_Man_Code != C_NULL_P )
   {
      signal_value = EYEQMSG_BOOTDIAGMSG_ParamsApp_s.BOOT_Flash2_Man_Code_b8;
      * pBOOT_Flash2_Man_Code = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BOOT_Flash_2_Size
*
* FUNCTION ARGUMENTS:
*    uint32 * pBOOT_Flash_2_Size - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BOOT_Flash_2_Size
*    BOOT_Flash_2_Size returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BOOT_Flash_2_Size signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BOOT_Flash_2_Size( uint32 * pBOOT_Flash_2_Size )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pBOOT_Flash_2_Size != C_NULL_P )
   {
      signal_value = EYEQMSG_BOOTDIAGMSG_ParamsApp_s.BOOT_Flash_2_Size_b24;
      * pBOOT_Flash_2_Size = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_Boot_Stage
*
* FUNCTION ARGUMENTS:
*    BOOTDIAGMSGBootStage * pBoot_Stage - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Boot_Stage
*    Boot_Stage returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Boot_Stage signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_Boot_Stage( BOOTDIAGMSGBootStage * pBoot_Stage )
{
   Std_ReturnType status = C_SIG_INVALID;
   BOOTDIAGMSGBootStage signal_value;
   
   if( pBoot_Stage != C_NULL_P )
   {
      signal_value = EYEQMSG_BOOTDIAGMSG_ParamsApp_s.Boot_Stage_b8;
      * pBoot_Stage = signal_value;
      if( signal_value <= C_EYEQMSG_BOOTDIAGMSG_BOOT_STAGE_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BOOT_Failure_info_0
*
* FUNCTION ARGUMENTS:
*    uint32 * pBOOT_Failure_info_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BOOT_Failure_info_0
*    BOOT_Failure_info_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BOOT_Failure_info_0 signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BOOT_Failure_info_0( uint32 * pBOOT_Failure_info_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pBOOT_Failure_info_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_BOOTDIAGMSG_ParamsApp_s.BOOT_Failure_info_0_b24;
      * pBOOT_Failure_info_0 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BOOT_Failure_info_1
*
* FUNCTION ARGUMENTS:
*    uint32 * pBOOT_Failure_info_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BOOT_Failure_info_1
*    BOOT_Failure_info_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BOOT_Failure_info_1 signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BOOT_Failure_info_1( uint32 * pBOOT_Failure_info_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pBOOT_Failure_info_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_BOOTDIAGMSG_ParamsApp_s.BOOT_Failure_info_1_b32;
      * pBOOT_Failure_info_1 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BOOT_Failure_info_2
*
* FUNCTION ARGUMENTS:
*    uint32 * pBOOT_Failure_info_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BOOT_Failure_info_2
*    BOOT_Failure_info_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BOOT_Failure_info_2 signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BOOT_Failure_info_2( uint32 * pBOOT_Failure_info_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pBOOT_Failure_info_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_BOOTDIAGMSG_ParamsApp_s.BOOT_Failure_info_2_b32;
      * pBOOT_Failure_info_2 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BOOT_Failure_info_3
*
* FUNCTION ARGUMENTS:
*    uint32 * pBOOT_Failure_info_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BOOT_Failure_info_3
*    BOOT_Failure_info_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BOOT_Failure_info_3 signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BOOT_Failure_info_3( uint32 * pBOOT_Failure_info_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pBOOT_Failure_info_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_BOOTDIAGMSG_ParamsApp_s.BOOT_Failure_info_3_b32;
      * pBOOT_Failure_info_3 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BOOT_Failure_info_4
*
* FUNCTION ARGUMENTS:
*    uint32 * pBOOT_Failure_info_4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BOOT_Failure_info_4
*    BOOT_Failure_info_4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BOOT_Failure_info_4 signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BOOT_Failure_info_4( uint32 * pBOOT_Failure_info_4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pBOOT_Failure_info_4 != C_NULL_P )
   {
      signal_value = EYEQMSG_BOOTDIAGMSG_ParamsApp_s.BOOT_Failure_info_4_b32;
      * pBOOT_Failure_info_4 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BOOT_Failure_info_5
*
* FUNCTION ARGUMENTS:
*    uint32 * pBOOT_Failure_info_5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BOOT_Failure_info_5
*    BOOT_Failure_info_5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BOOT_Failure_info_5 signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BOOT_Failure_info_5( uint32 * pBOOT_Failure_info_5 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pBOOT_Failure_info_5 != C_NULL_P )
   {
      signal_value = EYEQMSG_BOOTDIAGMSG_ParamsApp_s.BOOT_Failure_info_5_b32;
      * pBOOT_Failure_info_5 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BOOT_Failure_info_6
*
* FUNCTION ARGUMENTS:
*    uint32 * pBOOT_Failure_info_6 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BOOT_Failure_info_6
*    BOOT_Failure_info_6 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BOOT_Failure_info_6 signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BOOT_Failure_info_6( uint32 * pBOOT_Failure_info_6 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pBOOT_Failure_info_6 != C_NULL_P )
   {
      signal_value = EYEQMSG_BOOTDIAGMSG_ParamsApp_s.BOOT_Failure_info_6_b32;
      * pBOOT_Failure_info_6 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BOOT_Failure_info_7
*
* FUNCTION ARGUMENTS:
*    uint32 * pBOOT_Failure_info_7 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BOOT_Failure_info_7
*    BOOT_Failure_info_7 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BOOT_Failure_info_7 signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BOOT_Failure_info_7( uint32 * pBOOT_Failure_info_7 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pBOOT_Failure_info_7 != C_NULL_P )
   {
      signal_value = EYEQMSG_BOOTDIAGMSG_ParamsApp_s.BOOT_Failure_info_7_b32;
      * pBOOT_Failure_info_7 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

