

/*****************************************************************************
                  Include files
*****************************************************************************/
/* The suggested include file order is: */
#include "EyeQ_defs.h"    /* EyeQ project common definitions file    */

#include "EYEQMSG_LDWInitProcess.h"

/*****************************************************************************
                  Local symbolic constants
*****************************************************************************/
/*****************************************************************************
                  Local types, enums definitions
*****************************************************************************/
/*****************************************************************************
                  Local function prototypes
*****************************************************************************/
/*****************************************************************************
                  Local object definitions
*****************************************************************************/
/*****************************************************************************
                  Exported object definitions
*****************************************************************************/
EYEQMSG_LDWINIT_Params_t   EYEQMSG_LDWINIT_Params_s;
EYEQMSG_LDWINIT_Params_t   EYEQMSG_LDWINIT_ParamsApp_s;
/*****************************************************************************
                  Local function-like macros
*****************************************************************************/
/*****************************************************************************
                  Local defined macros
*****************************************************************************/
/*****************************************************************************
                  Function definitions
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_LDWINIT_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_LDWINIT_Params_t * pLDW_Init - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LDW_Init message 
*    LDW_Init message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LDW_Init message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_LDWINIT_ParamsApp_MsgDataStruct( EYEQMSG_LDWINIT_Params_t * pLDW_Init )
{
   Std_ReturnType status = C_SIG_INVALID;
   if( pLDW_Init != C_NULL_P )
   {
      status = C_SIG_VALID;
      * pLDW_Init = EYEQMSG_LDWINIT_ParamsApp_s;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_ILDW_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pILDW_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILDW_Zero_byte
*    ILDW_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILDW_Zero_byte signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_ILDW_Zero_byte( uint8 * pILDW_Zero_byte )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pILDW_Zero_byte != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.ILDW_Zero_byte_b8;
      * pILDW_Zero_byte = signal_value;
      if( signal_value <= C_EYEQMSG_LDWINIT_ILDW_ZERO_BYTE_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_ILDW_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pILDW_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILDW_Protocol_Version
*    ILDW_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILDW_Protocol_Version signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_ILDW_Protocol_Version( uint8 * pILDW_Protocol_Version )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pILDW_Protocol_Version != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.ILDW_Protocol_Version_b8;
      * pILDW_Protocol_Version = signal_value;
      if( (signal_value >= C_EYEQMSG_LDWINIT_ILDW_PROTOCOL_VERSION_RMIN ) 
          && (signal_value <= C_EYEQMSG_LDWINIT_ILDW_PROTOCOL_VERSION_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_ILDW_Optional_Signals
*
* FUNCTION ARGUMENTS:
*    boolean * pILDW_Optional_Signals - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILDW_Optional_Signals
*    ILDW_Optional_Signals returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILDW_Optional_Signals signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_ILDW_Optional_Signals( boolean * pILDW_Optional_Signals )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pILDW_Optional_Signals != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.ILDW_Optional_Signals_b1;
      * pILDW_Optional_Signals = signal_value;
      if( signal_value <= C_EYEQMSG_LDWINIT_ILDW_OPTIONAL_SIGNALS_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_ILDW_Header_Buffer
*
* FUNCTION ARGUMENTS:
*    uint16 * pILDW_Header_Buffer - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILDW_Header_Buffer
*    ILDW_Header_Buffer returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILDW_Header_Buffer signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_ILDW_Header_Buffer( uint16 * pILDW_Header_Buffer )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pILDW_Header_Buffer != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.ILDW_Header_Buffer_b15;
      * pILDW_Header_Buffer = signal_value;
      if( signal_value <= C_EYEQMSG_LDWINIT_ILDW_HEADER_BUFFER_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_LDW_Set_Enable_0
*
* FUNCTION ARGUMENTS:
*    LDWINITLDWSetEnable0 * pLDW_Set_Enable_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LDW_Set_Enable_0
*    LDW_Set_Enable_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LDW_Set_Enable_0 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_LDW_Set_Enable_0( LDWINITLDWSetEnable0 * pLDW_Set_Enable_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   LDWINITLDWSetEnable0 signal_value;
   
   if( pLDW_Set_Enable_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.LDW_Set_Enable_0_b1;
      * pLDW_Set_Enable_0 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_LDW_Set_Enable_1
*
* FUNCTION ARGUMENTS:
*    LDWINITLDWSetEnable1 * pLDW_Set_Enable_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LDW_Set_Enable_1
*    LDW_Set_Enable_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LDW_Set_Enable_1 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_LDW_Set_Enable_1( LDWINITLDWSetEnable1 * pLDW_Set_Enable_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   LDWINITLDWSetEnable1 signal_value;
   
   if( pLDW_Set_Enable_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.LDW_Set_Enable_1_b1;
      * pLDW_Set_Enable_1 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_LDW_Set_Enable_2
*
* FUNCTION ARGUMENTS:
*    LDWINITLDWSetEnable2 * pLDW_Set_Enable_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LDW_Set_Enable_2
*    LDW_Set_Enable_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LDW_Set_Enable_2 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_LDW_Set_Enable_2( LDWINITLDWSetEnable2 * pLDW_Set_Enable_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   LDWINITLDWSetEnable2 signal_value;
   
   if( pLDW_Set_Enable_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.LDW_Set_Enable_2_b1;
      * pLDW_Set_Enable_2 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_LDW_Set_Enable_3
*
* FUNCTION ARGUMENTS:
*    LDWINITLDWSetEnable3 * pLDW_Set_Enable_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LDW_Set_Enable_3
*    LDW_Set_Enable_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LDW_Set_Enable_3 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_LDW_Set_Enable_3( LDWINITLDWSetEnable3 * pLDW_Set_Enable_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   LDWINITLDWSetEnable3 signal_value;
   
   if( pLDW_Set_Enable_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.LDW_Set_Enable_3_b1;
      * pLDW_Set_Enable_3 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_min_lane_width_0
*
* FUNCTION ARGUMENTS:
*    uint16 * pmin_lane_width_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of min_lane_width_0
*    min_lane_width_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns min_lane_width_0 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_min_lane_width_0( uint16 * pmin_lane_width_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pmin_lane_width_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.min_lane_width_0_b9;
      * pmin_lane_width_0 = signal_value;
      if( (signal_value >= C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_0_RMIN ) 
          && (signal_value <= C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_0_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_min_lane_width_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pmin_lane_width_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of min_lane_width_1
*    min_lane_width_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns min_lane_width_1 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_min_lane_width_1( uint16 * pmin_lane_width_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pmin_lane_width_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.min_lane_width_1_b9;
      * pmin_lane_width_1 = signal_value;
      if( (signal_value >= C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_1_RMIN ) 
          && (signal_value <= C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_1_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_min_lane_width_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pmin_lane_width_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of min_lane_width_2
*    min_lane_width_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns min_lane_width_2 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_min_lane_width_2( uint16 * pmin_lane_width_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pmin_lane_width_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.min_lane_width_2_b9;
      * pmin_lane_width_2 = signal_value;
      if( (signal_value >= C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_2_RMIN ) 
          && (signal_value <= C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_2_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_Reserved_1
*
* FUNCTION ARGUMENTS:
*    boolean * pReserved_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1
*    Reserved_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_Reserved_1( boolean * pReserved_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pReserved_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.Reserved_1_b1;
      * pReserved_1 = signal_value;
      if( signal_value <= C_EYEQMSG_LDWINIT_RESERVED_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_min_lane_width_3
*
* FUNCTION ARGUMENTS:
*    uint16 * pmin_lane_width_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of min_lane_width_3
*    min_lane_width_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns min_lane_width_3 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_min_lane_width_3( uint16 * pmin_lane_width_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pmin_lane_width_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.min_lane_width_3_b9;
      * pmin_lane_width_3 = signal_value;
      if( (signal_value >= C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_3_RMIN ) 
          && (signal_value <= C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_3_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_ind_min_wrn_disable_0
*
* FUNCTION ARGUMENTS:
*    LDWINITIndMinWrnDisable0 * pind_min_wrn_disable_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ind_min_wrn_disable_0
*    ind_min_wrn_disable_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ind_min_wrn_disable_0 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_ind_min_wrn_disable_0( LDWINITIndMinWrnDisable0 * pind_min_wrn_disable_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   LDWINITIndMinWrnDisable0 signal_value;
   
   if( pind_min_wrn_disable_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.ind_min_wrn_disable_0_b1;
      * pind_min_wrn_disable_0 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_ind_min_wrn_disable_1
*
* FUNCTION ARGUMENTS:
*    LDWINITIndMinWrnDisable1 * pind_min_wrn_disable_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ind_min_wrn_disable_1
*    ind_min_wrn_disable_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ind_min_wrn_disable_1 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_ind_min_wrn_disable_1( LDWINITIndMinWrnDisable1 * pind_min_wrn_disable_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   LDWINITIndMinWrnDisable1 signal_value;
   
   if( pind_min_wrn_disable_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.ind_min_wrn_disable_1_b1;
      * pind_min_wrn_disable_1 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_ind_min_wrn_disable_2
*
* FUNCTION ARGUMENTS:
*    LDWINITIndMinWrnDisable2 * pind_min_wrn_disable_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ind_min_wrn_disable_2
*    ind_min_wrn_disable_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ind_min_wrn_disable_2 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_ind_min_wrn_disable_2( LDWINITIndMinWrnDisable2 * pind_min_wrn_disable_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   LDWINITIndMinWrnDisable2 signal_value;
   
   if( pind_min_wrn_disable_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.ind_min_wrn_disable_2_b1;
      * pind_min_wrn_disable_2 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_ind_min_wrn_disable_3
*
* FUNCTION ARGUMENTS:
*    LDWINITIndMinWrnDisable3 * pind_min_wrn_disable_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ind_min_wrn_disable_3
*    ind_min_wrn_disable_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ind_min_wrn_disable_3 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_ind_min_wrn_disable_3( LDWINITIndMinWrnDisable3 * pind_min_wrn_disable_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   LDWINITIndMinWrnDisable3 signal_value;
   
   if( pind_min_wrn_disable_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.ind_min_wrn_disable_3_b1;
      * pind_min_wrn_disable_3 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_min_lane_width_hysteresis_0
*
* FUNCTION ARGUMENTS:
*    uint8 * pmin_lane_width_hysteresis_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of min_lane_width_hysteresis_0
*    min_lane_width_hysteresis_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns min_lane_width_hysteresis_0 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_min_lane_width_hysteresis_0( uint8 * pmin_lane_width_hysteresis_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pmin_lane_width_hysteresis_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.min_lane_width_hysteresis_0_b8;
      * pmin_lane_width_hysteresis_0 = signal_value;
      if( signal_value <= C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_HYSTERESIS_0_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_min_lane_width_hysteresis_1
*
* FUNCTION ARGUMENTS:
*    uint8 * pmin_lane_width_hysteresis_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of min_lane_width_hysteresis_1
*    min_lane_width_hysteresis_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns min_lane_width_hysteresis_1 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_min_lane_width_hysteresis_1( uint8 * pmin_lane_width_hysteresis_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pmin_lane_width_hysteresis_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.min_lane_width_hysteresis_1_b8;
      * pmin_lane_width_hysteresis_1 = signal_value;
      if( signal_value <= C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_HYSTERESIS_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_Reserved_2
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_2
*    Reserved_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_2 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_Reserved_2( uint8 * pReserved_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pReserved_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.Reserved_2_b3;
      * pReserved_2 = signal_value;
      if( signal_value <= C_EYEQMSG_LDWINIT_RESERVED_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_min_lane_width_hysteresis_2
*
* FUNCTION ARGUMENTS:
*    uint8 * pmin_lane_width_hysteresis_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of min_lane_width_hysteresis_2
*    min_lane_width_hysteresis_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns min_lane_width_hysteresis_2 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_min_lane_width_hysteresis_2( uint8 * pmin_lane_width_hysteresis_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pmin_lane_width_hysteresis_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.min_lane_width_hysteresis_2_b8;
      * pmin_lane_width_hysteresis_2 = signal_value;
      if( signal_value <= C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_HYSTERESIS_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_min_lane_width_hysteresis_3
*
* FUNCTION ARGUMENTS:
*    uint8 * pmin_lane_width_hysteresis_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of min_lane_width_hysteresis_3
*    min_lane_width_hysteresis_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns min_lane_width_hysteresis_3 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_min_lane_width_hysteresis_3( uint8 * pmin_lane_width_hysteresis_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pmin_lane_width_hysteresis_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.min_lane_width_hysteresis_3_b8;
      * pmin_lane_width_hysteresis_3 = signal_value;
      if( signal_value <= C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_HYSTERESIS_3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_narrow_lane_width_0
*
* FUNCTION ARGUMENTS:
*    uint16 * pnarrow_lane_width_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of narrow_lane_width_0
*    narrow_lane_width_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns narrow_lane_width_0 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_narrow_lane_width_0( uint16 * pnarrow_lane_width_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pnarrow_lane_width_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.narrow_lane_width_0_b9;
      * pnarrow_lane_width_0 = signal_value;
      if( (signal_value >= C_EYEQMSG_LDWINIT_NARROW_LANE_WIDTH_0_RMIN ) 
          && (signal_value <= C_EYEQMSG_LDWINIT_NARROW_LANE_WIDTH_0_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_Reserved_3
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_3
*    Reserved_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_3 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_Reserved_3( uint8 * pReserved_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pReserved_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.Reserved_3_b7;
      * pReserved_3 = signal_value;
      if( signal_value <= C_EYEQMSG_LDWINIT_RESERVED_3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_narrow_lane_width_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pnarrow_lane_width_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of narrow_lane_width_1
*    narrow_lane_width_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns narrow_lane_width_1 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_narrow_lane_width_1( uint16 * pnarrow_lane_width_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pnarrow_lane_width_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.narrow_lane_width_1_b9;
      * pnarrow_lane_width_1 = signal_value;
      if( (signal_value >= C_EYEQMSG_LDWINIT_NARROW_LANE_WIDTH_1_RMIN ) 
          && (signal_value <= C_EYEQMSG_LDWINIT_NARROW_LANE_WIDTH_1_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_narrow_lane_width_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pnarrow_lane_width_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of narrow_lane_width_2
*    narrow_lane_width_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns narrow_lane_width_2 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_narrow_lane_width_2( uint16 * pnarrow_lane_width_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pnarrow_lane_width_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.narrow_lane_width_2_b9;
      * pnarrow_lane_width_2 = signal_value;
      if( (signal_value >= C_EYEQMSG_LDWINIT_NARROW_LANE_WIDTH_2_RMIN ) 
          && (signal_value <= C_EYEQMSG_LDWINIT_NARROW_LANE_WIDTH_2_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_narrow_lane_width_3
*
* FUNCTION ARGUMENTS:
*    uint16 * pnarrow_lane_width_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of narrow_lane_width_3
*    narrow_lane_width_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns narrow_lane_width_3 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_narrow_lane_width_3( uint16 * pnarrow_lane_width_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pnarrow_lane_width_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.narrow_lane_width_3_b9;
      * pnarrow_lane_width_3 = signal_value;
      if( (signal_value >= C_EYEQMSG_LDWINIT_NARROW_LANE_WIDTH_3_RMIN ) 
          && (signal_value <= C_EYEQMSG_LDWINIT_NARROW_LANE_WIDTH_3_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_Reserved_4
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_4
*    Reserved_4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_4 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_Reserved_4( uint8 * pReserved_4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pReserved_4 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.Reserved_4_b5;
      * pReserved_4 = signal_value;
      if( signal_value <= C_EYEQMSG_LDWINIT_RESERVED_4_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_tlc_0
*
* FUNCTION ARGUMENTS:
*    uint8 * ptlc_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of tlc_0
*    tlc_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns tlc_0 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_tlc_0( uint8 * ptlc_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( ptlc_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.tlc_0_b8;
      * ptlc_0 = signal_value;
      if( signal_value <= C_EYEQMSG_LDWINIT_TLC_0_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_tlc_1
*
* FUNCTION ARGUMENTS:
*    uint8 * ptlc_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of tlc_1
*    tlc_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns tlc_1 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_tlc_1( uint8 * ptlc_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( ptlc_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.tlc_1_b8;
      * ptlc_1 = signal_value;
      if( signal_value <= C_EYEQMSG_LDWINIT_TLC_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_tlc_2
*
* FUNCTION ARGUMENTS:
*    uint8 * ptlc_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of tlc_2
*    tlc_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns tlc_2 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_tlc_2( uint8 * ptlc_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( ptlc_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.tlc_2_b8;
      * ptlc_2 = signal_value;
      if( signal_value <= C_EYEQMSG_LDWINIT_TLC_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_tlc_3
*
* FUNCTION ARGUMENTS:
*    uint8 * ptlc_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of tlc_3
*    tlc_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns tlc_3 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_tlc_3( uint8 * ptlc_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( ptlc_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.tlc_3_b8;
      * ptlc_3 = signal_value;
      if( signal_value <= C_EYEQMSG_LDWINIT_TLC_3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_warning_line_tlc_0
*
* FUNCTION ARGUMENTS:
*    uint8 * pwarning_line_tlc_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of warning_line_tlc_0
*    warning_line_tlc_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns warning_line_tlc_0 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_warning_line_tlc_0( uint8 * pwarning_line_tlc_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pwarning_line_tlc_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.warning_line_tlc_0_b8;
      * pwarning_line_tlc_0 = signal_value;
      if( signal_value <= C_EYEQMSG_LDWINIT_WARNING_LINE_TLC_0_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_warning_line_tlc_1
*
* FUNCTION ARGUMENTS:
*    uint8 * pwarning_line_tlc_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of warning_line_tlc_1
*    warning_line_tlc_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns warning_line_tlc_1 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_warning_line_tlc_1( uint8 * pwarning_line_tlc_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pwarning_line_tlc_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.warning_line_tlc_1_b8;
      * pwarning_line_tlc_1 = signal_value;
      if( signal_value <= C_EYEQMSG_LDWINIT_WARNING_LINE_TLC_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_warning_line_tlc_2
*
* FUNCTION ARGUMENTS:
*    uint8 * pwarning_line_tlc_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of warning_line_tlc_2
*    warning_line_tlc_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns warning_line_tlc_2 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_warning_line_tlc_2( uint8 * pwarning_line_tlc_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pwarning_line_tlc_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.warning_line_tlc_2_b8;
      * pwarning_line_tlc_2 = signal_value;
      if( signal_value <= C_EYEQMSG_LDWINIT_WARNING_LINE_TLC_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_warning_line_tlc_3
*
* FUNCTION ARGUMENTS:
*    uint8 * pwarning_line_tlc_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of warning_line_tlc_3
*    warning_line_tlc_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns warning_line_tlc_3 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_warning_line_tlc_3( uint8 * pwarning_line_tlc_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pwarning_line_tlc_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.warning_line_tlc_3_b8;
      * pwarning_line_tlc_3 = signal_value;
      if( signal_value <= C_EYEQMSG_LDWINIT_WARNING_LINE_TLC_3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_position_warning_dist_thresh_0
*
* FUNCTION ARGUMENTS:
*    uint8 * pposition_warning_dist_thresh_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of position_warning_dist_thresh_0
*    position_warning_dist_thresh_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns position_warning_dist_thresh_0 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_position_warning_dist_thresh_0( uint8 * pposition_warning_dist_thresh_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pposition_warning_dist_thresh_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.position_warning_dist_thresh_0_b8;
      * pposition_warning_dist_thresh_0 = signal_value;
      if( signal_value <= C_EYEQMSG_LDWINIT_POSITION_WARNING_DIST_THRESH_0_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_position_warning_dist_thresh_1
*
* FUNCTION ARGUMENTS:
*    uint8 * pposition_warning_dist_thresh_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of position_warning_dist_thresh_1
*    position_warning_dist_thresh_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns position_warning_dist_thresh_1 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_position_warning_dist_thresh_1( uint8 * pposition_warning_dist_thresh_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pposition_warning_dist_thresh_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.position_warning_dist_thresh_1_b8;
      * pposition_warning_dist_thresh_1 = signal_value;
      if( signal_value <= C_EYEQMSG_LDWINIT_POSITION_WARNING_DIST_THRESH_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_position_warning_dist_thresh_2
*
* FUNCTION ARGUMENTS:
*    uint8 * pposition_warning_dist_thresh_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of position_warning_dist_thresh_2
*    position_warning_dist_thresh_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns position_warning_dist_thresh_2 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_position_warning_dist_thresh_2( uint8 * pposition_warning_dist_thresh_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pposition_warning_dist_thresh_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.position_warning_dist_thresh_2_b8;
      * pposition_warning_dist_thresh_2 = signal_value;
      if( signal_value <= C_EYEQMSG_LDWINIT_POSITION_WARNING_DIST_THRESH_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_position_warning_dist_thresh_3
*
* FUNCTION ARGUMENTS:
*    uint8 * pposition_warning_dist_thresh_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of position_warning_dist_thresh_3
*    position_warning_dist_thresh_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns position_warning_dist_thresh_3 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_position_warning_dist_thresh_3( uint8 * pposition_warning_dist_thresh_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pposition_warning_dist_thresh_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.position_warning_dist_thresh_3_b8;
      * pposition_warning_dist_thresh_3 = signal_value;
      if( signal_value <= C_EYEQMSG_LDWINIT_POSITION_WARNING_DIST_THRESH_3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_outer_dist_to_terminate_war_0
*
* FUNCTION ARGUMENTS:
*    uint8 * pouter_dist_to_terminate_war_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of outer_dist_to_terminate_war_0
*    outer_dist_to_terminate_war_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns outer_dist_to_terminate_war_0 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_outer_dist_to_terminate_war_0( uint8 * pouter_dist_to_terminate_war_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pouter_dist_to_terminate_war_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.outer_dist_to_terminate_war_0_b8;
      * pouter_dist_to_terminate_war_0 = signal_value;
      if( signal_value <= C_EYEQMSG_LDWINIT_OUTER_DIST_TO_TERMINATE_WAR_0_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_outer_dist_to_terminate_war_1
*
* FUNCTION ARGUMENTS:
*    uint8 * pouter_dist_to_terminate_war_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of outer_dist_to_terminate_war_1
*    outer_dist_to_terminate_war_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns outer_dist_to_terminate_war_1 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_outer_dist_to_terminate_war_1( uint8 * pouter_dist_to_terminate_war_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pouter_dist_to_terminate_war_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.outer_dist_to_terminate_war_1_b8;
      * pouter_dist_to_terminate_war_1 = signal_value;
      if( signal_value <= C_EYEQMSG_LDWINIT_OUTER_DIST_TO_TERMINATE_WAR_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_outer_dist_to_terminate_war_2
*
* FUNCTION ARGUMENTS:
*    uint8 * pouter_dist_to_terminate_war_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of outer_dist_to_terminate_war_2
*    outer_dist_to_terminate_war_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns outer_dist_to_terminate_war_2 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_outer_dist_to_terminate_war_2( uint8 * pouter_dist_to_terminate_war_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pouter_dist_to_terminate_war_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.outer_dist_to_terminate_war_2_b8;
      * pouter_dist_to_terminate_war_2 = signal_value;
      if( signal_value <= C_EYEQMSG_LDWINIT_OUTER_DIST_TO_TERMINATE_WAR_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_outer_dist_to_terminate_war_3
*
* FUNCTION ARGUMENTS:
*    uint8 * pouter_dist_to_terminate_war_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of outer_dist_to_terminate_war_3
*    outer_dist_to_terminate_war_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns outer_dist_to_terminate_war_3 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_outer_dist_to_terminate_war_3( uint8 * pouter_dist_to_terminate_war_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pouter_dist_to_terminate_war_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.outer_dist_to_terminate_war_3_b8;
      * pouter_dist_to_terminate_war_3 = signal_value;
      if( signal_value <= C_EYEQMSG_LDWINIT_OUTER_DIST_TO_TERMINATE_WAR_3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_inner_reset_offset_0
*
* FUNCTION ARGUMENTS:
*    uint16 * pinner_reset_offset_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of inner_reset_offset_0
*    inner_reset_offset_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns inner_reset_offset_0 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_inner_reset_offset_0( uint16 * pinner_reset_offset_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pinner_reset_offset_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.inner_reset_offset_0_b9;
      * pinner_reset_offset_0 = signal_value;
      if( signal_value <= C_EYEQMSG_LDWINIT_INNER_RESET_OFFSET_0_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_inner_reset_offset_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pinner_reset_offset_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of inner_reset_offset_1
*    inner_reset_offset_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns inner_reset_offset_1 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_inner_reset_offset_1( uint16 * pinner_reset_offset_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pinner_reset_offset_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.inner_reset_offset_1_b9;
      * pinner_reset_offset_1 = signal_value;
      if( signal_value <= C_EYEQMSG_LDWINIT_INNER_RESET_OFFSET_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_inner_reset_offset_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pinner_reset_offset_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of inner_reset_offset_2
*    inner_reset_offset_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns inner_reset_offset_2 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_inner_reset_offset_2( uint16 * pinner_reset_offset_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pinner_reset_offset_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.inner_reset_offset_2_b9;
      * pinner_reset_offset_2 = signal_value;
      if( signal_value <= C_EYEQMSG_LDWINIT_INNER_RESET_OFFSET_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_Reserved_5
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_5
*    Reserved_5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_5 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_Reserved_5( uint8 * pReserved_5 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pReserved_5 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.Reserved_5_b5;
      * pReserved_5 = signal_value;
      if( signal_value <= C_EYEQMSG_LDWINIT_RESERVED_5_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_inner_reset_offset_3
*
* FUNCTION ARGUMENTS:
*    uint16 * pinner_reset_offset_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of inner_reset_offset_3
*    inner_reset_offset_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns inner_reset_offset_3 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_inner_reset_offset_3( uint16 * pinner_reset_offset_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pinner_reset_offset_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.inner_reset_offset_3_b9;
      * pinner_reset_offset_3 = signal_value;
      if( signal_value <= C_EYEQMSG_LDWINIT_INNER_RESET_OFFSET_3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_corridor_outer_boundary_0
*
* FUNCTION ARGUMENTS:
*    uint16 * pcorridor_outer_boundary_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of corridor_outer_boundary_0
*    corridor_outer_boundary_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns corridor_outer_boundary_0 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_corridor_outer_boundary_0( uint16 * pcorridor_outer_boundary_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pcorridor_outer_boundary_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.corridor_outer_boundary_0_b9;
      * pcorridor_outer_boundary_0 = signal_value;
      if( signal_value <= C_EYEQMSG_LDWINIT_CORRIDOR_OUTER_BOUNDARY_0_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_corridor_outer_boundary_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pcorridor_outer_boundary_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of corridor_outer_boundary_1
*    corridor_outer_boundary_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns corridor_outer_boundary_1 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_corridor_outer_boundary_1( uint16 * pcorridor_outer_boundary_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pcorridor_outer_boundary_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.corridor_outer_boundary_1_b9;
      * pcorridor_outer_boundary_1 = signal_value;
      if( signal_value <= C_EYEQMSG_LDWINIT_CORRIDOR_OUTER_BOUNDARY_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_Reserved_6
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_6 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_6
*    Reserved_6 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_6 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_Reserved_6( uint8 * pReserved_6 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pReserved_6 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.Reserved_6_b5;
      * pReserved_6 = signal_value;
      if( signal_value <= C_EYEQMSG_LDWINIT_RESERVED_6_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_corridor_outer_boundary_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pcorridor_outer_boundary_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of corridor_outer_boundary_2
*    corridor_outer_boundary_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns corridor_outer_boundary_2 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_corridor_outer_boundary_2( uint16 * pcorridor_outer_boundary_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pcorridor_outer_boundary_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.corridor_outer_boundary_2_b9;
      * pcorridor_outer_boundary_2 = signal_value;
      if( signal_value <= C_EYEQMSG_LDWINIT_CORRIDOR_OUTER_BOUNDARY_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_corridor_outer_boundary_3
*
* FUNCTION ARGUMENTS:
*    uint16 * pcorridor_outer_boundary_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of corridor_outer_boundary_3
*    corridor_outer_boundary_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns corridor_outer_boundary_3 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_corridor_outer_boundary_3( uint16 * pcorridor_outer_boundary_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pcorridor_outer_boundary_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.corridor_outer_boundary_3_b9;
      * pcorridor_outer_boundary_3 = signal_value;
      if( signal_value <= C_EYEQMSG_LDWINIT_CORRIDOR_OUTER_BOUNDARY_3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_inner_curve_tlc_reduced_0
*
* FUNCTION ARGUMENTS:
*    uint16 * pinner_curve_tlc_reduced_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of inner_curve_tlc_reduced_0
*    inner_curve_tlc_reduced_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns inner_curve_tlc_reduced_0 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_inner_curve_tlc_reduced_0( uint16 * pinner_curve_tlc_reduced_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pinner_curve_tlc_reduced_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.inner_curve_tlc_reduced_0_b9;
      * pinner_curve_tlc_reduced_0 = signal_value;
      if( signal_value <= C_EYEQMSG_LDWINIT_INNER_CURVE_TLC_REDUCED_0_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_Reserved_7
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_7 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_7
*    Reserved_7 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_7 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_Reserved_7( uint8 * pReserved_7 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pReserved_7 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.Reserved_7_b5;
      * pReserved_7 = signal_value;
      if( signal_value <= C_EYEQMSG_LDWINIT_RESERVED_7_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_inner_curve_tlc_reduced_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pinner_curve_tlc_reduced_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of inner_curve_tlc_reduced_1
*    inner_curve_tlc_reduced_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns inner_curve_tlc_reduced_1 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_inner_curve_tlc_reduced_1( uint16 * pinner_curve_tlc_reduced_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pinner_curve_tlc_reduced_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.inner_curve_tlc_reduced_1_b9;
      * pinner_curve_tlc_reduced_1 = signal_value;
      if( signal_value <= C_EYEQMSG_LDWINIT_INNER_CURVE_TLC_REDUCED_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_inner_curve_tlc_reduced_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pinner_curve_tlc_reduced_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of inner_curve_tlc_reduced_2
*    inner_curve_tlc_reduced_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns inner_curve_tlc_reduced_2 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_inner_curve_tlc_reduced_2( uint16 * pinner_curve_tlc_reduced_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pinner_curve_tlc_reduced_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.inner_curve_tlc_reduced_2_b9;
      * pinner_curve_tlc_reduced_2 = signal_value;
      if( signal_value <= C_EYEQMSG_LDWINIT_INNER_CURVE_TLC_REDUCED_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_inner_curve_tlc_reduced_3
*
* FUNCTION ARGUMENTS:
*    uint16 * pinner_curve_tlc_reduced_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of inner_curve_tlc_reduced_3
*    inner_curve_tlc_reduced_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns inner_curve_tlc_reduced_3 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_inner_curve_tlc_reduced_3( uint16 * pinner_curve_tlc_reduced_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pinner_curve_tlc_reduced_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.inner_curve_tlc_reduced_3_b9;
      * pinner_curve_tlc_reduced_3 = signal_value;
      if( signal_value <= C_EYEQMSG_LDWINIT_INNER_CURVE_TLC_REDUCED_3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_Reserved_8
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_8 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_8
*    Reserved_8 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_8 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_Reserved_8( uint8 * pReserved_8 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pReserved_8 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.Reserved_8_b5;
      * pReserved_8 = signal_value;
      if( signal_value <= C_EYEQMSG_LDWINIT_RESERVED_8_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_inner_curve_tlc_shift_thresh_0
*
* FUNCTION ARGUMENTS:
*    uint16 * pinner_curve_tlc_shift_thresh_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of inner_curve_tlc_shift_thresh_0
*    inner_curve_tlc_shift_thresh_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns inner_curve_tlc_shift_thresh_0 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_inner_curve_tlc_shift_thresh_0( uint16 * pinner_curve_tlc_shift_thresh_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pinner_curve_tlc_shift_thresh_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.inner_curve_tlc_shift_thresh_0_b11;
      * pinner_curve_tlc_shift_thresh_0 = signal_value;
      if( signal_value <= C_EYEQMSG_LDWINIT_INNER_CURVE_TLC_SHIFT_THRESH_0_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_inner_curve_tlc_shift_thresh_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pinner_curve_tlc_shift_thresh_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of inner_curve_tlc_shift_thresh_1
*    inner_curve_tlc_shift_thresh_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns inner_curve_tlc_shift_thresh_1 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_inner_curve_tlc_shift_thresh_1( uint16 * pinner_curve_tlc_shift_thresh_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pinner_curve_tlc_shift_thresh_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.inner_curve_tlc_shift_thresh_1_b11;
      * pinner_curve_tlc_shift_thresh_1 = signal_value;
      if( signal_value <= C_EYEQMSG_LDWINIT_INNER_CURVE_TLC_SHIFT_THRESH_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_Reserved_9
*
* FUNCTION ARGUMENTS:
*    uint16 * pReserved_9 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_9
*    Reserved_9 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_9 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_Reserved_9( uint16 * pReserved_9 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pReserved_9 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.Reserved_9_b10;
      * pReserved_9 = signal_value;
      if( signal_value <= C_EYEQMSG_LDWINIT_RESERVED_9_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_inner_curve_tlc_shift_thresh_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pinner_curve_tlc_shift_thresh_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of inner_curve_tlc_shift_thresh_2
*    inner_curve_tlc_shift_thresh_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns inner_curve_tlc_shift_thresh_2 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_inner_curve_tlc_shift_thresh_2( uint16 * pinner_curve_tlc_shift_thresh_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pinner_curve_tlc_shift_thresh_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.inner_curve_tlc_shift_thresh_2_b11;
      * pinner_curve_tlc_shift_thresh_2 = signal_value;
      if( signal_value <= C_EYEQMSG_LDWINIT_INNER_CURVE_TLC_SHIFT_THRESH_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_inner_curve_tlc_shift_thresh_3
*
* FUNCTION ARGUMENTS:
*    uint16 * pinner_curve_tlc_shift_thresh_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of inner_curve_tlc_shift_thresh_3
*    inner_curve_tlc_shift_thresh_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns inner_curve_tlc_shift_thresh_3 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_inner_curve_tlc_shift_thresh_3( uint16 * pinner_curve_tlc_shift_thresh_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pinner_curve_tlc_shift_thresh_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.inner_curve_tlc_shift_thresh_3_b11;
      * pinner_curve_tlc_shift_thresh_3 = signal_value;
      if( signal_value <= C_EYEQMSG_LDWINIT_INNER_CURVE_TLC_SHIFT_THRESH_3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_Reserved_10
*
* FUNCTION ARGUMENTS:
*    uint16 * pReserved_10 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_10
*    Reserved_10 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_10 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_Reserved_10( uint16 * pReserved_10 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pReserved_10 != C_NULL_P )
   {
      signal_value = EYEQMSG_LDWINIT_ParamsApp_s.Reserved_10_b10;
      * pReserved_10 = signal_value;
      if( signal_value <= C_EYEQMSG_LDWINIT_RESERVED_10_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

