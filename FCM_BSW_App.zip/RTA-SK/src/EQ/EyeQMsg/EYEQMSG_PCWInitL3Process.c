

/*****************************************************************************
                  Include files
*****************************************************************************/
/* The suggested include file order is: */
#include "EyeQ_defs.h"    /* EyeQ project common definitions file    */

#include "EYEQMSG_PCWInitL3Process.h"

/*****************************************************************************
                  Local symbolic constants
*****************************************************************************/
/*****************************************************************************
                  Local types, enums definitions
*****************************************************************************/
/*****************************************************************************
                  Local function prototypes
*****************************************************************************/
/*****************************************************************************
                  Local object definitions
*****************************************************************************/
/*****************************************************************************
                  Exported object definitions
*****************************************************************************/
EYEQMSG_PCWINITL3_Params_t   EYEQMSG_PCWINITL3_Params_s;
EYEQMSG_PCWINITL3_Params_t   EYEQMSG_PCWINITL3_ParamsApp_s;
/*****************************************************************************
                  Local function-like macros
*****************************************************************************/
/*****************************************************************************
                  Local defined macros
*****************************************************************************/
/*****************************************************************************
                  Function definitions
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_PCWINITL3_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_PCWINITL3_Params_t * pPCW_Init_L3 - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Init_L3 message 
*    PCW_Init_L3 message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Init_L3 message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_PCWINITL3_ParamsApp_MsgDataStruct( EYEQMSG_PCWINITL3_Params_t * pPCW_Init_L3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   if( pPCW_Init_L3 != C_NULL_P )
   {
      status = C_SIG_VALID;
      * pPCW_Init_L3 = EYEQMSG_PCWINITL3_ParamsApp_s;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_IPCW_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pIPCW_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IPCW_Zero_byte
*    IPCW_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IPCW_Zero_byte signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_IPCW_Zero_byte( uint8 * pIPCW_Zero_byte )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pIPCW_Zero_byte != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.IPCW_Zero_byte_b8;
      * pIPCW_Zero_byte = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_IPCW_ZERO_BYTE_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_IPCW_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pIPCW_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IPCW_Protocol_Version
*    IPCW_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IPCW_Protocol_Version signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_IPCW_Protocol_Version( uint8 * pIPCW_Protocol_Version )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pIPCW_Protocol_Version != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.IPCW_Protocol_Version_b8;
      * pIPCW_Protocol_Version = signal_value;
      if( (signal_value >= C_EYEQMSG_PCWINITL3_IPCW_PROTOCOL_VERSION_RMIN ) 
          && (signal_value <= C_EYEQMSG_PCWINITL3_IPCW_PROTOCOL_VERSION_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_IPCW_Optional_Signals
*
* FUNCTION ARGUMENTS:
*    uint8 * pIPCW_Optional_Signals - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IPCW_Optional_Signals
*    IPCW_Optional_Signals returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IPCW_Optional_Signals signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_IPCW_Optional_Signals( uint8 * pIPCW_Optional_Signals )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pIPCW_Optional_Signals != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.IPCW_Optional_Signals_b8;
      * pIPCW_Optional_Signals = signal_value;
      if( (signal_value >= C_EYEQMSG_PCWINITL3_IPCW_OPTIONAL_SIGNALS_RMIN ) 
          && (signal_value <= C_EYEQMSG_PCWINITL3_IPCW_OPTIONAL_SIGNALS_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCA_Ignition_default_state_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCAIgnitionDefaultStateV * pPCA_Ignition_default_state_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCA_Ignition_default_state_V
*    PCA_Ignition_default_state_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCA_Ignition_default_state_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCA_Ignition_default_state_V( PCWINITL3PCAIgnitionDefaultStateV * pPCA_Ignition_default_state_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCAIgnitionDefaultStateV signal_value;
   
   if( pPCA_Ignition_default_state_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCA_Ignition_default_state_V_b1;
      * pPCA_Ignition_default_state_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCA_Ignition_default_state
*
* FUNCTION ARGUMENTS:
*    uint8 * pPCA_Ignition_default_state - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCA_Ignition_default_state
*    PCA_Ignition_default_state returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCA_Ignition_default_state signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCA_Ignition_default_state( uint8 * pPCA_Ignition_default_state )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pPCA_Ignition_default_state != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCA_Ignition_default_state_b3;
      * pPCA_Ignition_default_state = signal_value;
      if( (signal_value >= C_EYEQMSG_PCWINITL3_PCA_IGNITION_DEFAULT_STATE_RMIN ) 
          && (signal_value <= C_EYEQMSG_PCWINITL3_PCA_IGNITION_DEFAULT_STATE_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_1_V
*
* FUNCTION ARGUMENTS:
*    boolean * pPCW_Buffer_1_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_1_V
*    PCW_Buffer_1_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_1_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_1_V( boolean * pPCW_Buffer_1_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pPCW_Buffer_1_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_1_V_b1;
      * pPCW_Buffer_1_V = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_1_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_1
*
* FUNCTION ARGUMENTS:
*    uint8 * pPCW_Buffer_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_1
*    PCW_Buffer_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_1 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_1( uint8 * pPCW_Buffer_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pPCW_Buffer_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_1_b2;
      * pPCW_Buffer_1 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_FCV_MediumTTCAddition_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWFCVMediumTTCAdditionV * pPCW_FCV_MediumTTCAddition_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_FCV_MediumTTCAddition_V
*    PCW_FCV_MediumTTCAddition_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_FCV_MediumTTCAddition_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_FCV_MediumTTCAddition_V( PCWINITL3PCWFCVMediumTTCAdditionV * pPCW_FCV_MediumTTCAddition_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWFCVMediumTTCAdditionV signal_value;
   
   if( pPCW_FCV_MediumTTCAddition_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_FCV_MediumTTCAddition_V_b1;
      * pPCW_FCV_MediumTTCAddition_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_FCV_MediumTTCAddition
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_FCV_MediumTTCAddition - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_FCV_MediumTTCAddition
*    PCW_FCV_MediumTTCAddition returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_FCV_MediumTTCAddition signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_FCV_MediumTTCAddition( uint16 * pPCW_FCV_MediumTTCAddition )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_FCV_MediumTTCAddition != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_FCV_MediumTTCAddition_b9;
      * pPCW_FCV_MediumTTCAddition = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_FCV_MEDIUMTTCADDITION_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kneePoints_warn_0_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXTTCKneePointsWarn0V * pPCW_LX_TTC_kneePoints_warn_0_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kneePoints_warn_0_V
*    PCW_LX_TTC_kneePoints_warn_0_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kneePoints_warn_0_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kneePoints_warn_0_V( PCWINITL3PCWLXTTCKneePointsWarn0V * pPCW_LX_TTC_kneePoints_warn_0_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXTTCKneePointsWarn0V signal_value;
   
   if( pPCW_LX_TTC_kneePoints_warn_0_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kneePoints_warn_0_V_b1;
      * pPCW_LX_TTC_kneePoints_warn_0_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kneePoints_warn_0
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_TTC_kneePoints_warn_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kneePoints_warn_0
*    PCW_LX_TTC_kneePoints_warn_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kneePoints_warn_0 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kneePoints_warn_0( uint16 * pPCW_LX_TTC_kneePoints_warn_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_TTC_kneePoints_warn_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kneePoints_warn_0_b9;
      * pPCW_LX_TTC_kneePoints_warn_0 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_TTC_KNEEPOINTS_WARN_0_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kneePoints_warn_1_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXTTCKneePointsWarn1V * pPCW_LX_TTC_kneePoints_warn_1_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kneePoints_warn_1_V
*    PCW_LX_TTC_kneePoints_warn_1_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kneePoints_warn_1_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kneePoints_warn_1_V( PCWINITL3PCWLXTTCKneePointsWarn1V * pPCW_LX_TTC_kneePoints_warn_1_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXTTCKneePointsWarn1V signal_value;
   
   if( pPCW_LX_TTC_kneePoints_warn_1_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kneePoints_warn_1_V_b1;
      * pPCW_LX_TTC_kneePoints_warn_1_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kneePoints_warn_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_TTC_kneePoints_warn_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kneePoints_warn_1
*    PCW_LX_TTC_kneePoints_warn_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kneePoints_warn_1 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kneePoints_warn_1( uint16 * pPCW_LX_TTC_kneePoints_warn_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_TTC_kneePoints_warn_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kneePoints_warn_1_b9;
      * pPCW_LX_TTC_kneePoints_warn_1 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_TTC_KNEEPOINTS_WARN_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_2_V
*
* FUNCTION ARGUMENTS:
*    boolean * pPCW_Buffer_2_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_2_V
*    PCW_Buffer_2_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_2_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_2_V( boolean * pPCW_Buffer_2_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pPCW_Buffer_2_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_2_V_b1;
      * pPCW_Buffer_2_V = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_2_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_2
*
* FUNCTION ARGUMENTS:
*    boolean * pPCW_Buffer_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_2
*    PCW_Buffer_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_2 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_2( boolean * pPCW_Buffer_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pPCW_Buffer_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_2_b1;
      * pPCW_Buffer_2 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kneePoints_warn_2_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXTTCKneePointsWarn2V * pPCW_LX_TTC_kneePoints_warn_2_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kneePoints_warn_2_V
*    PCW_LX_TTC_kneePoints_warn_2_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kneePoints_warn_2_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kneePoints_warn_2_V( PCWINITL3PCWLXTTCKneePointsWarn2V * pPCW_LX_TTC_kneePoints_warn_2_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXTTCKneePointsWarn2V signal_value;
   
   if( pPCW_LX_TTC_kneePoints_warn_2_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kneePoints_warn_2_V_b1;
      * pPCW_LX_TTC_kneePoints_warn_2_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kneePoints_warn_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_TTC_kneePoints_warn_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kneePoints_warn_2
*    PCW_LX_TTC_kneePoints_warn_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kneePoints_warn_2 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kneePoints_warn_2( uint16 * pPCW_LX_TTC_kneePoints_warn_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_TTC_kneePoints_warn_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kneePoints_warn_2_b9;
      * pPCW_LX_TTC_kneePoints_warn_2 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_TTC_KNEEPOINTS_WARN_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kneePoints_warn_3_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXTTCKneePointsWarn3V * pPCW_LX_TTC_kneePoints_warn_3_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kneePoints_warn_3_V
*    PCW_LX_TTC_kneePoints_warn_3_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kneePoints_warn_3_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kneePoints_warn_3_V( PCWINITL3PCWLXTTCKneePointsWarn3V * pPCW_LX_TTC_kneePoints_warn_3_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXTTCKneePointsWarn3V signal_value;
   
   if( pPCW_LX_TTC_kneePoints_warn_3_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kneePoints_warn_3_V_b1;
      * pPCW_LX_TTC_kneePoints_warn_3_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kneePoints_warn_3
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_TTC_kneePoints_warn_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kneePoints_warn_3
*    PCW_LX_TTC_kneePoints_warn_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kneePoints_warn_3 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kneePoints_warn_3( uint16 * pPCW_LX_TTC_kneePoints_warn_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_TTC_kneePoints_warn_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kneePoints_warn_3_b9;
      * pPCW_LX_TTC_kneePoints_warn_3 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_TTC_KNEEPOINTS_WARN_3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kneePoints_warn_4_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXTTCKneePointsWarn4V * pPCW_LX_TTC_kneePoints_warn_4_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kneePoints_warn_4_V
*    PCW_LX_TTC_kneePoints_warn_4_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kneePoints_warn_4_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kneePoints_warn_4_V( PCWINITL3PCWLXTTCKneePointsWarn4V * pPCW_LX_TTC_kneePoints_warn_4_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXTTCKneePointsWarn4V signal_value;
   
   if( pPCW_LX_TTC_kneePoints_warn_4_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kneePoints_warn_4_V_b1;
      * pPCW_LX_TTC_kneePoints_warn_4_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kneePoints_warn_4
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_TTC_kneePoints_warn_4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kneePoints_warn_4
*    PCW_LX_TTC_kneePoints_warn_4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kneePoints_warn_4 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kneePoints_warn_4( uint16 * pPCW_LX_TTC_kneePoints_warn_4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_TTC_kneePoints_warn_4 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kneePoints_warn_4_b9;
      * pPCW_LX_TTC_kneePoints_warn_4 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_TTC_KNEEPOINTS_WARN_4_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_3_V
*
* FUNCTION ARGUMENTS:
*    boolean * pPCW_Buffer_3_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_3_V
*    PCW_Buffer_3_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_3_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_3_V( boolean * pPCW_Buffer_3_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pPCW_Buffer_3_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_3_V_b1;
      * pPCW_Buffer_3_V = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_3_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_3
*
* FUNCTION ARGUMENTS:
*    boolean * pPCW_Buffer_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_3
*    PCW_Buffer_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_3 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_3( boolean * pPCW_Buffer_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pPCW_Buffer_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_3_b1;
      * pPCW_Buffer_3 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kneePoints_warn_5_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXTTCKneePointsWarn5V * pPCW_LX_TTC_kneePoints_warn_5_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kneePoints_warn_5_V
*    PCW_LX_TTC_kneePoints_warn_5_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kneePoints_warn_5_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kneePoints_warn_5_V( PCWINITL3PCWLXTTCKneePointsWarn5V * pPCW_LX_TTC_kneePoints_warn_5_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXTTCKneePointsWarn5V signal_value;
   
   if( pPCW_LX_TTC_kneePoints_warn_5_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kneePoints_warn_5_V_b1;
      * pPCW_LX_TTC_kneePoints_warn_5_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kneePoints_warn_5
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_TTC_kneePoints_warn_5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kneePoints_warn_5
*    PCW_LX_TTC_kneePoints_warn_5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kneePoints_warn_5 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kneePoints_warn_5( uint16 * pPCW_LX_TTC_kneePoints_warn_5 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_TTC_kneePoints_warn_5 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kneePoints_warn_5_b9;
      * pPCW_LX_TTC_kneePoints_warn_5 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_TTC_KNEEPOINTS_WARN_5_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kneePoints_night_0_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXTTCKneePointsNight0V * pPCW_LX_TTC_kneePoints_night_0_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kneePoints_night_0_V
*    PCW_LX_TTC_kneePoints_night_0_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kneePoints_night_0_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kneePoints_night_0_V( PCWINITL3PCWLXTTCKneePointsNight0V * pPCW_LX_TTC_kneePoints_night_0_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXTTCKneePointsNight0V signal_value;
   
   if( pPCW_LX_TTC_kneePoints_night_0_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kneePoints_night_0_V_b1;
      * pPCW_LX_TTC_kneePoints_night_0_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kneePoints_night_0
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_TTC_kneePoints_night_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kneePoints_night_0
*    PCW_LX_TTC_kneePoints_night_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kneePoints_night_0 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kneePoints_night_0( uint16 * pPCW_LX_TTC_kneePoints_night_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_TTC_kneePoints_night_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kneePoints_night_0_b9;
      * pPCW_LX_TTC_kneePoints_night_0 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_TTC_KNEEPOINTS_NIGHT_0_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kneePoints_night_1_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXTTCKneePointsNight1V * pPCW_LX_TTC_kneePoints_night_1_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kneePoints_night_1_V
*    PCW_LX_TTC_kneePoints_night_1_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kneePoints_night_1_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kneePoints_night_1_V( PCWINITL3PCWLXTTCKneePointsNight1V * pPCW_LX_TTC_kneePoints_night_1_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXTTCKneePointsNight1V signal_value;
   
   if( pPCW_LX_TTC_kneePoints_night_1_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kneePoints_night_1_V_b1;
      * pPCW_LX_TTC_kneePoints_night_1_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kneePoints_night_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_TTC_kneePoints_night_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kneePoints_night_1
*    PCW_LX_TTC_kneePoints_night_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kneePoints_night_1 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kneePoints_night_1( uint16 * pPCW_LX_TTC_kneePoints_night_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_TTC_kneePoints_night_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kneePoints_night_1_b9;
      * pPCW_LX_TTC_kneePoints_night_1 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_TTC_KNEEPOINTS_NIGHT_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_4_V
*
* FUNCTION ARGUMENTS:
*    boolean * pPCW_Buffer_4_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_4_V
*    PCW_Buffer_4_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_4_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_4_V( boolean * pPCW_Buffer_4_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pPCW_Buffer_4_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_4_V_b1;
      * pPCW_Buffer_4_V = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_4_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_4
*
* FUNCTION ARGUMENTS:
*    boolean * pPCW_Buffer_4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_4
*    PCW_Buffer_4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_4 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_4( boolean * pPCW_Buffer_4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pPCW_Buffer_4 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_4_b1;
      * pPCW_Buffer_4 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_4_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kneePoints_night_2_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXTTCKneePointsNight2V * pPCW_LX_TTC_kneePoints_night_2_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kneePoints_night_2_V
*    PCW_LX_TTC_kneePoints_night_2_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kneePoints_night_2_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kneePoints_night_2_V( PCWINITL3PCWLXTTCKneePointsNight2V * pPCW_LX_TTC_kneePoints_night_2_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXTTCKneePointsNight2V signal_value;
   
   if( pPCW_LX_TTC_kneePoints_night_2_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kneePoints_night_2_V_b1;
      * pPCW_LX_TTC_kneePoints_night_2_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kneePoints_night_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_TTC_kneePoints_night_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kneePoints_night_2
*    PCW_LX_TTC_kneePoints_night_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kneePoints_night_2 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kneePoints_night_2( uint16 * pPCW_LX_TTC_kneePoints_night_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_TTC_kneePoints_night_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kneePoints_night_2_b9;
      * pPCW_LX_TTC_kneePoints_night_2 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_TTC_KNEEPOINTS_NIGHT_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kneePoints_night_3_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXTTCKneePointsNight3V * pPCW_LX_TTC_kneePoints_night_3_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kneePoints_night_3_V
*    PCW_LX_TTC_kneePoints_night_3_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kneePoints_night_3_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kneePoints_night_3_V( PCWINITL3PCWLXTTCKneePointsNight3V * pPCW_LX_TTC_kneePoints_night_3_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXTTCKneePointsNight3V signal_value;
   
   if( pPCW_LX_TTC_kneePoints_night_3_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kneePoints_night_3_V_b1;
      * pPCW_LX_TTC_kneePoints_night_3_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kneePoints_night_3
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_TTC_kneePoints_night_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kneePoints_night_3
*    PCW_LX_TTC_kneePoints_night_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kneePoints_night_3 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kneePoints_night_3( uint16 * pPCW_LX_TTC_kneePoints_night_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_TTC_kneePoints_night_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kneePoints_night_3_b9;
      * pPCW_LX_TTC_kneePoints_night_3 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_TTC_KNEEPOINTS_NIGHT_3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kneePoints_night_4_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXTTCKneePointsNight4V * pPCW_LX_TTC_kneePoints_night_4_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kneePoints_night_4_V
*    PCW_LX_TTC_kneePoints_night_4_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kneePoints_night_4_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kneePoints_night_4_V( PCWINITL3PCWLXTTCKneePointsNight4V * pPCW_LX_TTC_kneePoints_night_4_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXTTCKneePointsNight4V signal_value;
   
   if( pPCW_LX_TTC_kneePoints_night_4_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kneePoints_night_4_V_b1;
      * pPCW_LX_TTC_kneePoints_night_4_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kneePoints_night_4
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_TTC_kneePoints_night_4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kneePoints_night_4
*    PCW_LX_TTC_kneePoints_night_4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kneePoints_night_4 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kneePoints_night_4( uint16 * pPCW_LX_TTC_kneePoints_night_4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_TTC_kneePoints_night_4 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kneePoints_night_4_b9;
      * pPCW_LX_TTC_kneePoints_night_4 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_TTC_KNEEPOINTS_NIGHT_4_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_5_V
*
* FUNCTION ARGUMENTS:
*    boolean * pPCW_Buffer_5_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_5_V
*    PCW_Buffer_5_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_5_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_5_V( boolean * pPCW_Buffer_5_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pPCW_Buffer_5_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_5_V_b1;
      * pPCW_Buffer_5_V = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_5_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_5
*
* FUNCTION ARGUMENTS:
*    boolean * pPCW_Buffer_5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_5
*    PCW_Buffer_5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_5 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_5( boolean * pPCW_Buffer_5 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pPCW_Buffer_5 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_5_b1;
      * pPCW_Buffer_5 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_5_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kneePoints_night_5_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXTTCKneePointsNight5V * pPCW_LX_TTC_kneePoints_night_5_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kneePoints_night_5_V
*    PCW_LX_TTC_kneePoints_night_5_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kneePoints_night_5_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kneePoints_night_5_V( PCWINITL3PCWLXTTCKneePointsNight5V * pPCW_LX_TTC_kneePoints_night_5_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXTTCKneePointsNight5V signal_value;
   
   if( pPCW_LX_TTC_kneePoints_night_5_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kneePoints_night_5_V_b1;
      * pPCW_LX_TTC_kneePoints_night_5_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kneePoints_night_5
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_TTC_kneePoints_night_5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kneePoints_night_5
*    PCW_LX_TTC_kneePoints_night_5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kneePoints_night_5 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kneePoints_night_5( uint16 * pPCW_LX_TTC_kneePoints_night_5 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_TTC_kneePoints_night_5 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kneePoints_night_5_b9;
      * pPCW_LX_TTC_kneePoints_night_5 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_TTC_KNEEPOINTS_NIGHT_5_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bicycle_0_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXTTCKPointsBicycle0V * pPCW_LX_TTC_kPoints_bicycle_0_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_bicycle_0_V
*    PCW_LX_TTC_kPoints_bicycle_0_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_bicycle_0_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bicycle_0_V( PCWINITL3PCWLXTTCKPointsBicycle0V * pPCW_LX_TTC_kPoints_bicycle_0_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXTTCKPointsBicycle0V signal_value;
   
   if( pPCW_LX_TTC_kPoints_bicycle_0_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_bicycle_0_V_b1;
      * pPCW_LX_TTC_kPoints_bicycle_0_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bicycle_0
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_TTC_kPoints_bicycle_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_bicycle_0
*    PCW_LX_TTC_kPoints_bicycle_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_bicycle_0 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bicycle_0( uint16 * pPCW_LX_TTC_kPoints_bicycle_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_TTC_kPoints_bicycle_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_bicycle_0_b9;
      * pPCW_LX_TTC_kPoints_bicycle_0 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_TTC_KPOINTS_BICYCLE_0_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bicycle_1_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXTTCKPointsBicycle1V * pPCW_LX_TTC_kPoints_bicycle_1_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_bicycle_1_V
*    PCW_LX_TTC_kPoints_bicycle_1_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_bicycle_1_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bicycle_1_V( PCWINITL3PCWLXTTCKPointsBicycle1V * pPCW_LX_TTC_kPoints_bicycle_1_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXTTCKPointsBicycle1V signal_value;
   
   if( pPCW_LX_TTC_kPoints_bicycle_1_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_bicycle_1_V_b1;
      * pPCW_LX_TTC_kPoints_bicycle_1_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bicycle_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_TTC_kPoints_bicycle_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_bicycle_1
*    PCW_LX_TTC_kPoints_bicycle_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_bicycle_1 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bicycle_1( uint16 * pPCW_LX_TTC_kPoints_bicycle_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_TTC_kPoints_bicycle_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_bicycle_1_b9;
      * pPCW_LX_TTC_kPoints_bicycle_1 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_TTC_KPOINTS_BICYCLE_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_6_V
*
* FUNCTION ARGUMENTS:
*    boolean * pPCW_Buffer_6_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_6_V
*    PCW_Buffer_6_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_6_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_6_V( boolean * pPCW_Buffer_6_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pPCW_Buffer_6_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_6_V_b1;
      * pPCW_Buffer_6_V = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_6_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_6
*
* FUNCTION ARGUMENTS:
*    boolean * pPCW_Buffer_6 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_6
*    PCW_Buffer_6 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_6 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_6( boolean * pPCW_Buffer_6 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pPCW_Buffer_6 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_6_b1;
      * pPCW_Buffer_6 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_6_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bicycle_2_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXTTCKPointsBicycle2V * pPCW_LX_TTC_kPoints_bicycle_2_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_bicycle_2_V
*    PCW_LX_TTC_kPoints_bicycle_2_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_bicycle_2_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bicycle_2_V( PCWINITL3PCWLXTTCKPointsBicycle2V * pPCW_LX_TTC_kPoints_bicycle_2_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXTTCKPointsBicycle2V signal_value;
   
   if( pPCW_LX_TTC_kPoints_bicycle_2_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_bicycle_2_V_b1;
      * pPCW_LX_TTC_kPoints_bicycle_2_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bicycle_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_TTC_kPoints_bicycle_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_bicycle_2
*    PCW_LX_TTC_kPoints_bicycle_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_bicycle_2 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bicycle_2( uint16 * pPCW_LX_TTC_kPoints_bicycle_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_TTC_kPoints_bicycle_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_bicycle_2_b9;
      * pPCW_LX_TTC_kPoints_bicycle_2 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_TTC_KPOINTS_BICYCLE_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bicycle_3_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXTTCKPointsBicycle3V * pPCW_LX_TTC_kPoints_bicycle_3_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_bicycle_3_V
*    PCW_LX_TTC_kPoints_bicycle_3_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_bicycle_3_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bicycle_3_V( PCWINITL3PCWLXTTCKPointsBicycle3V * pPCW_LX_TTC_kPoints_bicycle_3_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXTTCKPointsBicycle3V signal_value;
   
   if( pPCW_LX_TTC_kPoints_bicycle_3_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_bicycle_3_V_b1;
      * pPCW_LX_TTC_kPoints_bicycle_3_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bicycle_3
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_TTC_kPoints_bicycle_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_bicycle_3
*    PCW_LX_TTC_kPoints_bicycle_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_bicycle_3 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bicycle_3( uint16 * pPCW_LX_TTC_kPoints_bicycle_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_TTC_kPoints_bicycle_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_bicycle_3_b9;
      * pPCW_LX_TTC_kPoints_bicycle_3 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_TTC_KPOINTS_BICYCLE_3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bicycle_4_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXTTCKPointsBicycle4V * pPCW_LX_TTC_kPoints_bicycle_4_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_bicycle_4_V
*    PCW_LX_TTC_kPoints_bicycle_4_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_bicycle_4_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bicycle_4_V( PCWINITL3PCWLXTTCKPointsBicycle4V * pPCW_LX_TTC_kPoints_bicycle_4_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXTTCKPointsBicycle4V signal_value;
   
   if( pPCW_LX_TTC_kPoints_bicycle_4_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_bicycle_4_V_b1;
      * pPCW_LX_TTC_kPoints_bicycle_4_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bicycle_4
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_TTC_kPoints_bicycle_4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_bicycle_4
*    PCW_LX_TTC_kPoints_bicycle_4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_bicycle_4 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bicycle_4( uint16 * pPCW_LX_TTC_kPoints_bicycle_4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_TTC_kPoints_bicycle_4 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_bicycle_4_b9;
      * pPCW_LX_TTC_kPoints_bicycle_4 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_TTC_KPOINTS_BICYCLE_4_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_7_V
*
* FUNCTION ARGUMENTS:
*    boolean * pPCW_Buffer_7_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_7_V
*    PCW_Buffer_7_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_7_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_7_V( boolean * pPCW_Buffer_7_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pPCW_Buffer_7_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_7_V_b1;
      * pPCW_Buffer_7_V = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_7_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_7
*
* FUNCTION ARGUMENTS:
*    boolean * pPCW_Buffer_7 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_7
*    PCW_Buffer_7 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_7 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_7( boolean * pPCW_Buffer_7 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pPCW_Buffer_7 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_7_b1;
      * pPCW_Buffer_7 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_7_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bicycle_5_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXTTCKPointsBicycle5V * pPCW_LX_TTC_kPoints_bicycle_5_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_bicycle_5_V
*    PCW_LX_TTC_kPoints_bicycle_5_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_bicycle_5_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bicycle_5_V( PCWINITL3PCWLXTTCKPointsBicycle5V * pPCW_LX_TTC_kPoints_bicycle_5_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXTTCKPointsBicycle5V signal_value;
   
   if( pPCW_LX_TTC_kPoints_bicycle_5_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_bicycle_5_V_b1;
      * pPCW_LX_TTC_kPoints_bicycle_5_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bicycle_5
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_TTC_kPoints_bicycle_5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_bicycle_5
*    PCW_LX_TTC_kPoints_bicycle_5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_bicycle_5 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bicycle_5( uint16 * pPCW_LX_TTC_kPoints_bicycle_5 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_TTC_kPoints_bicycle_5 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_bicycle_5_b9;
      * pPCW_LX_TTC_kPoints_bicycle_5 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_TTC_KPOINTS_BICYCLE_5_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bicy_N_0_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXTTCKPointsBicyN0V * pPCW_LX_TTC_kPoints_bicy_N_0_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_bicy_N_0_V
*    PCW_LX_TTC_kPoints_bicy_N_0_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_bicy_N_0_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bicy_N_0_V( PCWINITL3PCWLXTTCKPointsBicyN0V * pPCW_LX_TTC_kPoints_bicy_N_0_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXTTCKPointsBicyN0V signal_value;
   
   if( pPCW_LX_TTC_kPoints_bicy_N_0_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_bicy_N_0_V_b1;
      * pPCW_LX_TTC_kPoints_bicy_N_0_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bicy_N_0
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_TTC_kPoints_bicy_N_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_bicy_N_0
*    PCW_LX_TTC_kPoints_bicy_N_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_bicy_N_0 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bicy_N_0( uint16 * pPCW_LX_TTC_kPoints_bicy_N_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_TTC_kPoints_bicy_N_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_bicy_N_0_b9;
      * pPCW_LX_TTC_kPoints_bicy_N_0 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_TTC_KPOINTS_BICY_N_0_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bicy_N_1_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXTTCKPointsBicyN1V * pPCW_LX_TTC_kPoints_bicy_N_1_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_bicy_N_1_V
*    PCW_LX_TTC_kPoints_bicy_N_1_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_bicy_N_1_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bicy_N_1_V( PCWINITL3PCWLXTTCKPointsBicyN1V * pPCW_LX_TTC_kPoints_bicy_N_1_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXTTCKPointsBicyN1V signal_value;
   
   if( pPCW_LX_TTC_kPoints_bicy_N_1_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_bicy_N_1_V_b1;
      * pPCW_LX_TTC_kPoints_bicy_N_1_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bicy_N_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_TTC_kPoints_bicy_N_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_bicy_N_1
*    PCW_LX_TTC_kPoints_bicy_N_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_bicy_N_1 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bicy_N_1( uint16 * pPCW_LX_TTC_kPoints_bicy_N_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_TTC_kPoints_bicy_N_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_bicy_N_1_b9;
      * pPCW_LX_TTC_kPoints_bicy_N_1 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_TTC_KPOINTS_BICY_N_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_8_V
*
* FUNCTION ARGUMENTS:
*    boolean * pPCW_Buffer_8_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_8_V
*    PCW_Buffer_8_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_8_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_8_V( boolean * pPCW_Buffer_8_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pPCW_Buffer_8_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_8_V_b1;
      * pPCW_Buffer_8_V = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_8_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_8
*
* FUNCTION ARGUMENTS:
*    boolean * pPCW_Buffer_8 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_8
*    PCW_Buffer_8 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_8 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_8( boolean * pPCW_Buffer_8 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pPCW_Buffer_8 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_8_b1;
      * pPCW_Buffer_8 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_8_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bicy_N_2_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXTTCKPointsBicyN2V * pPCW_LX_TTC_kPoints_bicy_N_2_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_bicy_N_2_V
*    PCW_LX_TTC_kPoints_bicy_N_2_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_bicy_N_2_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bicy_N_2_V( PCWINITL3PCWLXTTCKPointsBicyN2V * pPCW_LX_TTC_kPoints_bicy_N_2_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXTTCKPointsBicyN2V signal_value;
   
   if( pPCW_LX_TTC_kPoints_bicy_N_2_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_bicy_N_2_V_b1;
      * pPCW_LX_TTC_kPoints_bicy_N_2_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bicy_N_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_TTC_kPoints_bicy_N_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_bicy_N_2
*    PCW_LX_TTC_kPoints_bicy_N_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_bicy_N_2 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bicy_N_2( uint16 * pPCW_LX_TTC_kPoints_bicy_N_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_TTC_kPoints_bicy_N_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_bicy_N_2_b9;
      * pPCW_LX_TTC_kPoints_bicy_N_2 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_TTC_KPOINTS_BICY_N_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bicy_N_3_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXTTCKPointsBicyN3V * pPCW_LX_TTC_kPoints_bicy_N_3_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_bicy_N_3_V
*    PCW_LX_TTC_kPoints_bicy_N_3_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_bicy_N_3_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bicy_N_3_V( PCWINITL3PCWLXTTCKPointsBicyN3V * pPCW_LX_TTC_kPoints_bicy_N_3_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXTTCKPointsBicyN3V signal_value;
   
   if( pPCW_LX_TTC_kPoints_bicy_N_3_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_bicy_N_3_V_b1;
      * pPCW_LX_TTC_kPoints_bicy_N_3_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bicy_N_3
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_TTC_kPoints_bicy_N_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_bicy_N_3
*    PCW_LX_TTC_kPoints_bicy_N_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_bicy_N_3 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bicy_N_3( uint16 * pPCW_LX_TTC_kPoints_bicy_N_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_TTC_kPoints_bicy_N_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_bicy_N_3_b9;
      * pPCW_LX_TTC_kPoints_bicy_N_3 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_TTC_KPOINTS_BICY_N_3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bicy_N_4_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXTTCKPointsBicyN4V * pPCW_LX_TTC_kPoints_bicy_N_4_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_bicy_N_4_V
*    PCW_LX_TTC_kPoints_bicy_N_4_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_bicy_N_4_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bicy_N_4_V( PCWINITL3PCWLXTTCKPointsBicyN4V * pPCW_LX_TTC_kPoints_bicy_N_4_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXTTCKPointsBicyN4V signal_value;
   
   if( pPCW_LX_TTC_kPoints_bicy_N_4_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_bicy_N_4_V_b1;
      * pPCW_LX_TTC_kPoints_bicy_N_4_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bicy_N_4
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_TTC_kPoints_bicy_N_4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_bicy_N_4
*    PCW_LX_TTC_kPoints_bicy_N_4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_bicy_N_4 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bicy_N_4( uint16 * pPCW_LX_TTC_kPoints_bicy_N_4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_TTC_kPoints_bicy_N_4 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_bicy_N_4_b9;
      * pPCW_LX_TTC_kPoints_bicy_N_4 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_TTC_KPOINTS_BICY_N_4_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_9_V
*
* FUNCTION ARGUMENTS:
*    boolean * pPCW_Buffer_9_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_9_V
*    PCW_Buffer_9_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_9_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_9_V( boolean * pPCW_Buffer_9_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pPCW_Buffer_9_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_9_V_b1;
      * pPCW_Buffer_9_V = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_9_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_9
*
* FUNCTION ARGUMENTS:
*    boolean * pPCW_Buffer_9 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_9
*    PCW_Buffer_9 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_9 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_9( boolean * pPCW_Buffer_9 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pPCW_Buffer_9 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_9_b1;
      * pPCW_Buffer_9 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_9_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bicy_N_5_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXTTCKPointsBicyN5V * pPCW_LX_TTC_kPoints_bicy_N_5_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_bicy_N_5_V
*    PCW_LX_TTC_kPoints_bicy_N_5_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_bicy_N_5_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bicy_N_5_V( PCWINITL3PCWLXTTCKPointsBicyN5V * pPCW_LX_TTC_kPoints_bicy_N_5_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXTTCKPointsBicyN5V signal_value;
   
   if( pPCW_LX_TTC_kPoints_bicy_N_5_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_bicy_N_5_V_b1;
      * pPCW_LX_TTC_kPoints_bicy_N_5_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bicy_N_5
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_TTC_kPoints_bicy_N_5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_bicy_N_5
*    PCW_LX_TTC_kPoints_bicy_N_5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_bicy_N_5 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bicy_N_5( uint16 * pPCW_LX_TTC_kPoints_bicy_N_5 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_TTC_kPoints_bicy_N_5 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_bicy_N_5_b9;
      * pPCW_LX_TTC_kPoints_bicy_N_5 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_TTC_KPOINTS_BICY_N_5_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_speed_kneePoints_0_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXSpeedKneePoints0V * pPCW_LX_speed_kneePoints_0_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_speed_kneePoints_0_V
*    PCW_LX_speed_kneePoints_0_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_speed_kneePoints_0_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_speed_kneePoints_0_V( PCWINITL3PCWLXSpeedKneePoints0V * pPCW_LX_speed_kneePoints_0_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXSpeedKneePoints0V signal_value;
   
   if( pPCW_LX_speed_kneePoints_0_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_speed_kneePoints_0_V_b1;
      * pPCW_LX_speed_kneePoints_0_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_speed_kneePoints_0
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_speed_kneePoints_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_speed_kneePoints_0
*    PCW_LX_speed_kneePoints_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_speed_kneePoints_0 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_speed_kneePoints_0( uint16 * pPCW_LX_speed_kneePoints_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_speed_kneePoints_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_speed_kneePoints_0_b12;
      * pPCW_LX_speed_kneePoints_0 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_SPEED_KNEEPOINTS_0_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_10_V
*
* FUNCTION ARGUMENTS:
*    boolean * pPCW_Buffer_10_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_10_V
*    PCW_Buffer_10_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_10_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_10_V( boolean * pPCW_Buffer_10_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pPCW_Buffer_10_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_10_V_b1;
      * pPCW_Buffer_10_V = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_10_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_10
*
* FUNCTION ARGUMENTS:
*    uint8 * pPCW_Buffer_10 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_10
*    PCW_Buffer_10 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_10 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_10( uint8 * pPCW_Buffer_10 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pPCW_Buffer_10 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_10_b8;
      * pPCW_Buffer_10 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_10_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_speed_kneePoints_1_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXSpeedKneePoints1V * pPCW_LX_speed_kneePoints_1_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_speed_kneePoints_1_V
*    PCW_LX_speed_kneePoints_1_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_speed_kneePoints_1_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_speed_kneePoints_1_V( PCWINITL3PCWLXSpeedKneePoints1V * pPCW_LX_speed_kneePoints_1_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXSpeedKneePoints1V signal_value;
   
   if( pPCW_LX_speed_kneePoints_1_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_speed_kneePoints_1_V_b1;
      * pPCW_LX_speed_kneePoints_1_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_speed_kneePoints_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_speed_kneePoints_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_speed_kneePoints_1
*    PCW_LX_speed_kneePoints_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_speed_kneePoints_1 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_speed_kneePoints_1( uint16 * pPCW_LX_speed_kneePoints_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_speed_kneePoints_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_speed_kneePoints_1_b12;
      * pPCW_LX_speed_kneePoints_1 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_SPEED_KNEEPOINTS_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_speed_kneePoints_2_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXSpeedKneePoints2V * pPCW_LX_speed_kneePoints_2_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_speed_kneePoints_2_V
*    PCW_LX_speed_kneePoints_2_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_speed_kneePoints_2_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_speed_kneePoints_2_V( PCWINITL3PCWLXSpeedKneePoints2V * pPCW_LX_speed_kneePoints_2_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXSpeedKneePoints2V signal_value;
   
   if( pPCW_LX_speed_kneePoints_2_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_speed_kneePoints_2_V_b1;
      * pPCW_LX_speed_kneePoints_2_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_speed_kneePoints_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_speed_kneePoints_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_speed_kneePoints_2
*    PCW_LX_speed_kneePoints_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_speed_kneePoints_2 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_speed_kneePoints_2( uint16 * pPCW_LX_speed_kneePoints_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_speed_kneePoints_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_speed_kneePoints_2_b12;
      * pPCW_LX_speed_kneePoints_2 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_SPEED_KNEEPOINTS_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_11_V
*
* FUNCTION ARGUMENTS:
*    boolean * pPCW_Buffer_11_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_11_V
*    PCW_Buffer_11_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_11_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_11_V( boolean * pPCW_Buffer_11_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pPCW_Buffer_11_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_11_V_b1;
      * pPCW_Buffer_11_V = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_11_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_11
*
* FUNCTION ARGUMENTS:
*    uint8 * pPCW_Buffer_11 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_11
*    PCW_Buffer_11 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_11 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_11( uint8 * pPCW_Buffer_11 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pPCW_Buffer_11 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_11_b5;
      * pPCW_Buffer_11 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_11_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_speed_kneePoints_3_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXSpeedKneePoints3V * pPCW_LX_speed_kneePoints_3_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_speed_kneePoints_3_V
*    PCW_LX_speed_kneePoints_3_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_speed_kneePoints_3_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_speed_kneePoints_3_V( PCWINITL3PCWLXSpeedKneePoints3V * pPCW_LX_speed_kneePoints_3_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXSpeedKneePoints3V signal_value;
   
   if( pPCW_LX_speed_kneePoints_3_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_speed_kneePoints_3_V_b1;
      * pPCW_LX_speed_kneePoints_3_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_speed_kneePoints_3
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_speed_kneePoints_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_speed_kneePoints_3
*    PCW_LX_speed_kneePoints_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_speed_kneePoints_3 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_speed_kneePoints_3( uint16 * pPCW_LX_speed_kneePoints_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_speed_kneePoints_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_speed_kneePoints_3_b12;
      * pPCW_LX_speed_kneePoints_3 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_SPEED_KNEEPOINTS_3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_speed_kneePoints_4_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXSpeedKneePoints4V * pPCW_LX_speed_kneePoints_4_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_speed_kneePoints_4_V
*    PCW_LX_speed_kneePoints_4_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_speed_kneePoints_4_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_speed_kneePoints_4_V( PCWINITL3PCWLXSpeedKneePoints4V * pPCW_LX_speed_kneePoints_4_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXSpeedKneePoints4V signal_value;
   
   if( pPCW_LX_speed_kneePoints_4_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_speed_kneePoints_4_V_b1;
      * pPCW_LX_speed_kneePoints_4_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_speed_kneePoints_4
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_speed_kneePoints_4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_speed_kneePoints_4
*    PCW_LX_speed_kneePoints_4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_speed_kneePoints_4 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_speed_kneePoints_4( uint16 * pPCW_LX_speed_kneePoints_4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_speed_kneePoints_4 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_speed_kneePoints_4_b12;
      * pPCW_LX_speed_kneePoints_4 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_SPEED_KNEEPOINTS_4_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_12_V
*
* FUNCTION ARGUMENTS:
*    boolean * pPCW_Buffer_12_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_12_V
*    PCW_Buffer_12_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_12_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_12_V( boolean * pPCW_Buffer_12_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pPCW_Buffer_12_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_12_V_b1;
      * pPCW_Buffer_12_V = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_12_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_12
*
* FUNCTION ARGUMENTS:
*    uint8 * pPCW_Buffer_12 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_12
*    PCW_Buffer_12 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_12 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_12( uint8 * pPCW_Buffer_12 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pPCW_Buffer_12 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_12_b5;
      * pPCW_Buffer_12 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_12_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_speed_kneePoints_5_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXSpeedKneePoints5V * pPCW_LX_speed_kneePoints_5_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_speed_kneePoints_5_V
*    PCW_LX_speed_kneePoints_5_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_speed_kneePoints_5_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_speed_kneePoints_5_V( PCWINITL3PCWLXSpeedKneePoints5V * pPCW_LX_speed_kneePoints_5_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXSpeedKneePoints5V signal_value;
   
   if( pPCW_LX_speed_kneePoints_5_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_speed_kneePoints_5_V_b1;
      * pPCW_LX_speed_kneePoints_5_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_speed_kneePoints_5
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_speed_kneePoints_5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_speed_kneePoints_5
*    PCW_LX_speed_kneePoints_5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_speed_kneePoints_5 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_speed_kneePoints_5( uint16 * pPCW_LX_speed_kneePoints_5 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_speed_kneePoints_5 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_speed_kneePoints_5_b12;
      * pPCW_LX_speed_kneePoints_5 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_SPEED_KNEEPOINTS_5_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_speed_kPoint_bicycles_0_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXSpeedKPointBicycles0V * pPCW_LX_speed_kPoint_bicycles_0_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_speed_kPoint_bicycles_0_V
*    PCW_LX_speed_kPoint_bicycles_0_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_speed_kPoint_bicycles_0_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_speed_kPoint_bicycles_0_V( PCWINITL3PCWLXSpeedKPointBicycles0V * pPCW_LX_speed_kPoint_bicycles_0_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXSpeedKPointBicycles0V signal_value;
   
   if( pPCW_LX_speed_kPoint_bicycles_0_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_speed_kPoint_bicycles_0_V_b1;
      * pPCW_LX_speed_kPoint_bicycles_0_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_speed_kPoint_bicycles_0
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_speed_kPoint_bicycles_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_speed_kPoint_bicycles_0
*    PCW_LX_speed_kPoint_bicycles_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_speed_kPoint_bicycles_0 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_speed_kPoint_bicycles_0( uint16 * pPCW_LX_speed_kPoint_bicycles_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_speed_kPoint_bicycles_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_speed_kPoint_bicycles_0_b12;
      * pPCW_LX_speed_kPoint_bicycles_0 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_SPEED_KPOINT_BICYCLES_0_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_13_V
*
* FUNCTION ARGUMENTS:
*    boolean * pPCW_Buffer_13_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_13_V
*    PCW_Buffer_13_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_13_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_13_V( boolean * pPCW_Buffer_13_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pPCW_Buffer_13_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_13_V_b1;
      * pPCW_Buffer_13_V = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_13_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_13
*
* FUNCTION ARGUMENTS:
*    uint8 * pPCW_Buffer_13 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_13
*    PCW_Buffer_13 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_13 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_13( uint8 * pPCW_Buffer_13 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pPCW_Buffer_13 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_13_b5;
      * pPCW_Buffer_13 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_13_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_speed_kPoint_bicycles_1_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXSpeedKPointBicycles1V * pPCW_LX_speed_kPoint_bicycles_1_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_speed_kPoint_bicycles_1_V
*    PCW_LX_speed_kPoint_bicycles_1_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_speed_kPoint_bicycles_1_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_speed_kPoint_bicycles_1_V( PCWINITL3PCWLXSpeedKPointBicycles1V * pPCW_LX_speed_kPoint_bicycles_1_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXSpeedKPointBicycles1V signal_value;
   
   if( pPCW_LX_speed_kPoint_bicycles_1_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_speed_kPoint_bicycles_1_V_b1;
      * pPCW_LX_speed_kPoint_bicycles_1_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_speed_kPoint_bicycles_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_speed_kPoint_bicycles_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_speed_kPoint_bicycles_1
*    PCW_LX_speed_kPoint_bicycles_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_speed_kPoint_bicycles_1 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_speed_kPoint_bicycles_1( uint16 * pPCW_LX_speed_kPoint_bicycles_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_speed_kPoint_bicycles_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_speed_kPoint_bicycles_1_b12;
      * pPCW_LX_speed_kPoint_bicycles_1 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_SPEED_KPOINT_BICYCLES_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_speed_kPoint_bicycles_2_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXSpeedKPointBicycles2V * pPCW_LX_speed_kPoint_bicycles_2_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_speed_kPoint_bicycles_2_V
*    PCW_LX_speed_kPoint_bicycles_2_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_speed_kPoint_bicycles_2_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_speed_kPoint_bicycles_2_V( PCWINITL3PCWLXSpeedKPointBicycles2V * pPCW_LX_speed_kPoint_bicycles_2_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXSpeedKPointBicycles2V signal_value;
   
   if( pPCW_LX_speed_kPoint_bicycles_2_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_speed_kPoint_bicycles_2_V_b1;
      * pPCW_LX_speed_kPoint_bicycles_2_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_speed_kPoint_bicycles_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_speed_kPoint_bicycles_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_speed_kPoint_bicycles_2
*    PCW_LX_speed_kPoint_bicycles_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_speed_kPoint_bicycles_2 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_speed_kPoint_bicycles_2( uint16 * pPCW_LX_speed_kPoint_bicycles_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_speed_kPoint_bicycles_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_speed_kPoint_bicycles_2_b12;
      * pPCW_LX_speed_kPoint_bicycles_2 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_SPEED_KPOINT_BICYCLES_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_14_V
*
* FUNCTION ARGUMENTS:
*    boolean * pPCW_Buffer_14_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_14_V
*    PCW_Buffer_14_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_14_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_14_V( boolean * pPCW_Buffer_14_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pPCW_Buffer_14_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_14_V_b1;
      * pPCW_Buffer_14_V = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_14_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_14
*
* FUNCTION ARGUMENTS:
*    uint8 * pPCW_Buffer_14 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_14
*    PCW_Buffer_14 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_14 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_14( uint8 * pPCW_Buffer_14 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pPCW_Buffer_14 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_14_b5;
      * pPCW_Buffer_14 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_14_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_speed_kPoint_bicycles_3_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXSpeedKPointBicycles3V * pPCW_LX_speed_kPoint_bicycles_3_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_speed_kPoint_bicycles_3_V
*    PCW_LX_speed_kPoint_bicycles_3_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_speed_kPoint_bicycles_3_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_speed_kPoint_bicycles_3_V( PCWINITL3PCWLXSpeedKPointBicycles3V * pPCW_LX_speed_kPoint_bicycles_3_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXSpeedKPointBicycles3V signal_value;
   
   if( pPCW_LX_speed_kPoint_bicycles_3_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_speed_kPoint_bicycles_3_V_b1;
      * pPCW_LX_speed_kPoint_bicycles_3_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_speed_kPoint_bicycles_3
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_speed_kPoint_bicycles_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_speed_kPoint_bicycles_3
*    PCW_LX_speed_kPoint_bicycles_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_speed_kPoint_bicycles_3 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_speed_kPoint_bicycles_3( uint16 * pPCW_LX_speed_kPoint_bicycles_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_speed_kPoint_bicycles_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_speed_kPoint_bicycles_3_b12;
      * pPCW_LX_speed_kPoint_bicycles_3 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_SPEED_KPOINT_BICYCLES_3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_speed_kPoint_bicycles_4_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXSpeedKPointBicycles4V * pPCW_LX_speed_kPoint_bicycles_4_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_speed_kPoint_bicycles_4_V
*    PCW_LX_speed_kPoint_bicycles_4_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_speed_kPoint_bicycles_4_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_speed_kPoint_bicycles_4_V( PCWINITL3PCWLXSpeedKPointBicycles4V * pPCW_LX_speed_kPoint_bicycles_4_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXSpeedKPointBicycles4V signal_value;
   
   if( pPCW_LX_speed_kPoint_bicycles_4_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_speed_kPoint_bicycles_4_V_b1;
      * pPCW_LX_speed_kPoint_bicycles_4_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_speed_kPoint_bicycles_4
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_speed_kPoint_bicycles_4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_speed_kPoint_bicycles_4
*    PCW_LX_speed_kPoint_bicycles_4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_speed_kPoint_bicycles_4 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_speed_kPoint_bicycles_4( uint16 * pPCW_LX_speed_kPoint_bicycles_4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_speed_kPoint_bicycles_4 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_speed_kPoint_bicycles_4_b12;
      * pPCW_LX_speed_kPoint_bicycles_4 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_SPEED_KPOINT_BICYCLES_4_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_15_V
*
* FUNCTION ARGUMENTS:
*    boolean * pPCW_Buffer_15_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_15_V
*    PCW_Buffer_15_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_15_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_15_V( boolean * pPCW_Buffer_15_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pPCW_Buffer_15_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_15_V_b1;
      * pPCW_Buffer_15_V = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_15_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_15
*
* FUNCTION ARGUMENTS:
*    uint8 * pPCW_Buffer_15 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_15
*    PCW_Buffer_15 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_15 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_15( uint8 * pPCW_Buffer_15 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pPCW_Buffer_15 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_15_b5;
      * pPCW_Buffer_15 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_15_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_speed_kPoint_bicycles_5_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXSpeedKPointBicycles5V * pPCW_LX_speed_kPoint_bicycles_5_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_speed_kPoint_bicycles_5_V
*    PCW_LX_speed_kPoint_bicycles_5_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_speed_kPoint_bicycles_5_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_speed_kPoint_bicycles_5_V( PCWINITL3PCWLXSpeedKPointBicycles5V * pPCW_LX_speed_kPoint_bicycles_5_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXSpeedKPointBicycles5V signal_value;
   
   if( pPCW_LX_speed_kPoint_bicycles_5_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_speed_kPoint_bicycles_5_V_b1;
      * pPCW_LX_speed_kPoint_bicycles_5_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_speed_kPoint_bicycles_5
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_speed_kPoint_bicycles_5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_speed_kPoint_bicycles_5
*    PCW_LX_speed_kPoint_bicycles_5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_speed_kPoint_bicycles_5 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_speed_kPoint_bicycles_5( uint16 * pPCW_LX_speed_kPoint_bicycles_5 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_speed_kPoint_bicycles_5 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_speed_kPoint_bicycles_5_b12;
      * pPCW_LX_speed_kPoint_bicycles_5 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_SPEED_KPOINT_BICYCLES_5_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_speedParams_0_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXSpeedParams0V * pPCW_LX_speedParams_0_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_speedParams_0_V
*    PCW_LX_speedParams_0_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_speedParams_0_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_speedParams_0_V( PCWINITL3PCWLXSpeedParams0V * pPCW_LX_speedParams_0_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXSpeedParams0V signal_value;
   
   if( pPCW_LX_speedParams_0_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_speedParams_0_V_b1;
      * pPCW_LX_speedParams_0_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_speedParams_0
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_speedParams_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_speedParams_0
*    PCW_LX_speedParams_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_speedParams_0 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_speedParams_0( uint16 * pPCW_LX_speedParams_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_speedParams_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_speedParams_0_b14;
      * pPCW_LX_speedParams_0 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_SPEEDPARAMS_0_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_16_V
*
* FUNCTION ARGUMENTS:
*    boolean * pPCW_Buffer_16_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_16_V
*    PCW_Buffer_16_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_16_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_16_V( boolean * pPCW_Buffer_16_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pPCW_Buffer_16_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_16_V_b1;
      * pPCW_Buffer_16_V = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_16_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_16
*
* FUNCTION ARGUMENTS:
*    uint8 * pPCW_Buffer_16 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_16
*    PCW_Buffer_16 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_16 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_16( uint8 * pPCW_Buffer_16 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pPCW_Buffer_16 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_16_b3;
      * pPCW_Buffer_16 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_16_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_speedParams_1_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXSpeedParams1V * pPCW_LX_speedParams_1_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_speedParams_1_V
*    PCW_LX_speedParams_1_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_speedParams_1_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_speedParams_1_V( PCWINITL3PCWLXSpeedParams1V * pPCW_LX_speedParams_1_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXSpeedParams1V signal_value;
   
   if( pPCW_LX_speedParams_1_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_speedParams_1_V_b1;
      * pPCW_LX_speedParams_1_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_speedParams_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_speedParams_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_speedParams_1
*    PCW_LX_speedParams_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_speedParams_1 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_speedParams_1( uint16 * pPCW_LX_speedParams_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_speedParams_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_speedParams_1_b14;
      * pPCW_LX_speedParams_1 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_SPEEDPARAMS_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_speedParams_2_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXSpeedParams2V * pPCW_LX_speedParams_2_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_speedParams_2_V
*    PCW_LX_speedParams_2_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_speedParams_2_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_speedParams_2_V( PCWINITL3PCWLXSpeedParams2V * pPCW_LX_speedParams_2_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXSpeedParams2V signal_value;
   
   if( pPCW_LX_speedParams_2_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_speedParams_2_V_b1;
      * pPCW_LX_speedParams_2_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_speedParams_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_speedParams_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_speedParams_2
*    PCW_LX_speedParams_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_speedParams_2 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_speedParams_2( uint16 * pPCW_LX_speedParams_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_speedParams_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_speedParams_2_b14;
      * pPCW_LX_speedParams_2 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_SPEEDPARAMS_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_17_V
*
* FUNCTION ARGUMENTS:
*    boolean * pPCW_Buffer_17_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_17_V
*    PCW_Buffer_17_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_17_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_17_V( boolean * pPCW_Buffer_17_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pPCW_Buffer_17_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_17_V_b1;
      * pPCW_Buffer_17_V = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_17_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_17
*
* FUNCTION ARGUMENTS:
*    boolean * pPCW_Buffer_17 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_17
*    PCW_Buffer_17 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_17 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_17( boolean * pPCW_Buffer_17 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pPCW_Buffer_17 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_17_b1;
      * pPCW_Buffer_17 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_17_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_speedParams_3_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXSpeedParams3V * pPCW_LX_speedParams_3_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_speedParams_3_V
*    PCW_LX_speedParams_3_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_speedParams_3_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_speedParams_3_V( PCWINITL3PCWLXSpeedParams3V * pPCW_LX_speedParams_3_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXSpeedParams3V signal_value;
   
   if( pPCW_LX_speedParams_3_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_speedParams_3_V_b1;
      * pPCW_LX_speedParams_3_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_speedParams_3
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_speedParams_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_speedParams_3
*    PCW_LX_speedParams_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_speedParams_3 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_speedParams_3( uint16 * pPCW_LX_speedParams_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_speedParams_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_speedParams_3_b14;
      * pPCW_LX_speedParams_3 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_SPEEDPARAMS_3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_currSide_0_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXCurrSide0V * pPCW_LX_currSide_0_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_currSide_0_V
*    PCW_LX_currSide_0_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_currSide_0_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_currSide_0_V( PCWINITL3PCWLXCurrSide0V * pPCW_LX_currSide_0_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXCurrSide0V signal_value;
   
   if( pPCW_LX_currSide_0_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_currSide_0_V_b1;
      * pPCW_LX_currSide_0_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_currSide_0
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_currSide_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_currSide_0
*    PCW_LX_currSide_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_currSide_0 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_currSide_0( uint16 * pPCW_LX_currSide_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_currSide_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_currSide_0_b10;
      * pPCW_LX_currSide_0 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_CURRSIDE_0_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_18_V
*
* FUNCTION ARGUMENTS:
*    boolean * pPCW_Buffer_18_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_18_V
*    PCW_Buffer_18_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_18_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_18_V( boolean * pPCW_Buffer_18_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pPCW_Buffer_18_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_18_V_b1;
      * pPCW_Buffer_18_V = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_18_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_18
*
* FUNCTION ARGUMENTS:
*    uint8 * pPCW_Buffer_18 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_18
*    PCW_Buffer_18 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_18 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_18( uint8 * pPCW_Buffer_18 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pPCW_Buffer_18 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_18_b5;
      * pPCW_Buffer_18 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_18_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_currSide_1_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXCurrSide1V * pPCW_LX_currSide_1_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_currSide_1_V
*    PCW_LX_currSide_1_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_currSide_1_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_currSide_1_V( PCWINITL3PCWLXCurrSide1V * pPCW_LX_currSide_1_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXCurrSide1V signal_value;
   
   if( pPCW_LX_currSide_1_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_currSide_1_V_b1;
      * pPCW_LX_currSide_1_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_currSide_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_currSide_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_currSide_1
*    PCW_LX_currSide_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_currSide_1 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_currSide_1( uint16 * pPCW_LX_currSide_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_currSide_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_currSide_1_b10;
      * pPCW_LX_currSide_1 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_CURRSIDE_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_currSide_2_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXCurrSide2V * pPCW_LX_currSide_2_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_currSide_2_V
*    PCW_LX_currSide_2_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_currSide_2_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_currSide_2_V( PCWINITL3PCWLXCurrSide2V * pPCW_LX_currSide_2_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXCurrSide2V signal_value;
   
   if( pPCW_LX_currSide_2_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_currSide_2_V_b1;
      * pPCW_LX_currSide_2_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_currSide_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_currSide_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_currSide_2
*    PCW_LX_currSide_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_currSide_2 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_currSide_2( uint16 * pPCW_LX_currSide_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_currSide_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_currSide_2_b10;
      * pPCW_LX_currSide_2 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_CURRSIDE_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_currSide_3_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXCurrSide3V * pPCW_LX_currSide_3_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_currSide_3_V
*    PCW_LX_currSide_3_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_currSide_3_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_currSide_3_V( PCWINITL3PCWLXCurrSide3V * pPCW_LX_currSide_3_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXCurrSide3V signal_value;
   
   if( pPCW_LX_currSide_3_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_currSide_3_V_b1;
      * pPCW_LX_currSide_3_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_currSide_3
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_currSide_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_currSide_3
*    PCW_LX_currSide_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_currSide_3 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_currSide_3( uint16 * pPCW_LX_currSide_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_currSide_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_currSide_3_b10;
      * pPCW_LX_currSide_3 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_CURRSIDE_3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_crossingExpand_0_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXCrossingExpand0V * pPCW_LX_crossingExpand_0_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_crossingExpand_0_V
*    PCW_LX_crossingExpand_0_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_crossingExpand_0_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_crossingExpand_0_V( PCWINITL3PCWLXCrossingExpand0V * pPCW_LX_crossingExpand_0_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXCrossingExpand0V signal_value;
   
   if( pPCW_LX_crossingExpand_0_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_crossingExpand_0_V_b1;
      * pPCW_LX_crossingExpand_0_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_crossingExpand_0
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_crossingExpand_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_crossingExpand_0
*    PCW_LX_crossingExpand_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_crossingExpand_0 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_crossingExpand_0( uint16 * pPCW_LX_crossingExpand_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_crossingExpand_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_crossingExpand_0_b10;
      * pPCW_LX_crossingExpand_0 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_CROSSINGEXPAND_0_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_crossingExpand_1_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXCrossingExpand1V * pPCW_LX_crossingExpand_1_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_crossingExpand_1_V
*    PCW_LX_crossingExpand_1_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_crossingExpand_1_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_crossingExpand_1_V( PCWINITL3PCWLXCrossingExpand1V * pPCW_LX_crossingExpand_1_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXCrossingExpand1V signal_value;
   
   if( pPCW_LX_crossingExpand_1_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_crossingExpand_1_V_b1;
      * pPCW_LX_crossingExpand_1_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_crossingExpand_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_crossingExpand_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_crossingExpand_1
*    PCW_LX_crossingExpand_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_crossingExpand_1 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_crossingExpand_1( uint16 * pPCW_LX_crossingExpand_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_crossingExpand_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_crossingExpand_1_b10;
      * pPCW_LX_crossingExpand_1 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_CROSSINGEXPAND_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_19_V
*
* FUNCTION ARGUMENTS:
*    boolean * pPCW_Buffer_19_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_19_V
*    PCW_Buffer_19_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_19_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_19_V( boolean * pPCW_Buffer_19_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pPCW_Buffer_19_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_19_V_b1;
      * pPCW_Buffer_19_V = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_19_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_19
*
* FUNCTION ARGUMENTS:
*    uint8 * pPCW_Buffer_19 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_19
*    PCW_Buffer_19 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_19 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_19( uint8 * pPCW_Buffer_19 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pPCW_Buffer_19 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_19_b8;
      * pPCW_Buffer_19 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_19_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_crossingExpand_2_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXCrossingExpand2V * pPCW_LX_crossingExpand_2_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_crossingExpand_2_V
*    PCW_LX_crossingExpand_2_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_crossingExpand_2_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_crossingExpand_2_V( PCWINITL3PCWLXCrossingExpand2V * pPCW_LX_crossingExpand_2_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXCrossingExpand2V signal_value;
   
   if( pPCW_LX_crossingExpand_2_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_crossingExpand_2_V_b1;
      * pPCW_LX_crossingExpand_2_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_crossingExpand_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_crossingExpand_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_crossingExpand_2
*    PCW_LX_crossingExpand_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_crossingExpand_2 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_crossingExpand_2( uint16 * pPCW_LX_crossingExpand_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_crossingExpand_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_crossingExpand_2_b10;
      * pPCW_LX_crossingExpand_2 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_CROSSINGEXPAND_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_crossingExpand_3_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXCrossingExpand3V * pPCW_LX_crossingExpand_3_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_crossingExpand_3_V
*    PCW_LX_crossingExpand_3_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_crossingExpand_3_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_crossingExpand_3_V( PCWINITL3PCWLXCrossingExpand3V * pPCW_LX_crossingExpand_3_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXCrossingExpand3V signal_value;
   
   if( pPCW_LX_crossingExpand_3_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_crossingExpand_3_V_b1;
      * pPCW_LX_crossingExpand_3_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_crossingExpand_3
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_crossingExpand_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_crossingExpand_3
*    PCW_LX_crossingExpand_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_crossingExpand_3 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_crossingExpand_3( uint16 * pPCW_LX_crossingExpand_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_crossingExpand_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_crossingExpand_3_b10;
      * pPCW_LX_crossingExpand_3 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_CROSSINGEXPAND_3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_crossingBicycleExp_0_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXCrossingBicycleExp0V * pPCW_LX_crossingBicycleExp_0_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_crossingBicycleExp_0_V
*    PCW_LX_crossingBicycleExp_0_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_crossingBicycleExp_0_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_crossingBicycleExp_0_V( PCWINITL3PCWLXCrossingBicycleExp0V * pPCW_LX_crossingBicycleExp_0_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXCrossingBicycleExp0V signal_value;
   
   if( pPCW_LX_crossingBicycleExp_0_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_crossingBicycleExp_0_V_b1;
      * pPCW_LX_crossingBicycleExp_0_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_crossingBicycleExp_0
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_crossingBicycleExp_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_crossingBicycleExp_0
*    PCW_LX_crossingBicycleExp_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_crossingBicycleExp_0 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_crossingBicycleExp_0( uint16 * pPCW_LX_crossingBicycleExp_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_crossingBicycleExp_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_crossingBicycleExp_0_b10;
      * pPCW_LX_crossingBicycleExp_0 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_CROSSINGBICYCLEEXP_0_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_crossingBicycleExp_1_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXCrossingBicycleExp1V * pPCW_LX_crossingBicycleExp_1_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_crossingBicycleExp_1_V
*    PCW_LX_crossingBicycleExp_1_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_crossingBicycleExp_1_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_crossingBicycleExp_1_V( PCWINITL3PCWLXCrossingBicycleExp1V * pPCW_LX_crossingBicycleExp_1_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXCrossingBicycleExp1V signal_value;
   
   if( pPCW_LX_crossingBicycleExp_1_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_crossingBicycleExp_1_V_b1;
      * pPCW_LX_crossingBicycleExp_1_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_crossingBicycleExp_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_crossingBicycleExp_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_crossingBicycleExp_1
*    PCW_LX_crossingBicycleExp_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_crossingBicycleExp_1 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_crossingBicycleExp_1( uint16 * pPCW_LX_crossingBicycleExp_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_crossingBicycleExp_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_crossingBicycleExp_1_b10;
      * pPCW_LX_crossingBicycleExp_1 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_CROSSINGBICYCLEEXP_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_crossingBicycleExp_2_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXCrossingBicycleExp2V * pPCW_LX_crossingBicycleExp_2_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_crossingBicycleExp_2_V
*    PCW_LX_crossingBicycleExp_2_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_crossingBicycleExp_2_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_crossingBicycleExp_2_V( PCWINITL3PCWLXCrossingBicycleExp2V * pPCW_LX_crossingBicycleExp_2_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXCrossingBicycleExp2V signal_value;
   
   if( pPCW_LX_crossingBicycleExp_2_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_crossingBicycleExp_2_V_b1;
      * pPCW_LX_crossingBicycleExp_2_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_crossingBicycleExp_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_crossingBicycleExp_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_crossingBicycleExp_2
*    PCW_LX_crossingBicycleExp_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_crossingBicycleExp_2 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_crossingBicycleExp_2( uint16 * pPCW_LX_crossingBicycleExp_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_crossingBicycleExp_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_crossingBicycleExp_2_b10;
      * pPCW_LX_crossingBicycleExp_2 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_CROSSINGBICYCLEEXP_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_20_V
*
* FUNCTION ARGUMENTS:
*    boolean * pPCW_Buffer_20_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_20_V
*    PCW_Buffer_20_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_20_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_20_V( boolean * pPCW_Buffer_20_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pPCW_Buffer_20_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_20_V_b1;
      * pPCW_Buffer_20_V = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_20_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_20
*
* FUNCTION ARGUMENTS:
*    uint8 * pPCW_Buffer_20 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_20
*    PCW_Buffer_20 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_20 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_20( uint8 * pPCW_Buffer_20 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pPCW_Buffer_20 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_20_b8;
      * pPCW_Buffer_20 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_20_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_crossingBicycleExp_3_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXCrossingBicycleExp3V * pPCW_LX_crossingBicycleExp_3_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_crossingBicycleExp_3_V
*    PCW_LX_crossingBicycleExp_3_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_crossingBicycleExp_3_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_crossingBicycleExp_3_V( PCWINITL3PCWLXCrossingBicycleExp3V * pPCW_LX_crossingBicycleExp_3_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXCrossingBicycleExp3V signal_value;
   
   if( pPCW_LX_crossingBicycleExp_3_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_crossingBicycleExp_3_V_b1;
      * pPCW_LX_crossingBicycleExp_3_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_crossingBicycleExp_3
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_crossingBicycleExp_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_crossingBicycleExp_3
*    PCW_LX_crossingBicycleExp_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_crossingBicycleExp_3 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_crossingBicycleExp_3( uint16 * pPCW_LX_crossingBicycleExp_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_crossingBicycleExp_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_crossingBicycleExp_3_b10;
      * pPCW_LX_crossingBicycleExp_3 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_CROSSINGBICYCLEEXP_3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_predSide_0_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXPredSide0V * pPCW_LX_predSide_0_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_predSide_0_V
*    PCW_LX_predSide_0_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_predSide_0_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_predSide_0_V( PCWINITL3PCWLXPredSide0V * pPCW_LX_predSide_0_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXPredSide0V signal_value;
   
   if( pPCW_LX_predSide_0_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_predSide_0_V_b1;
      * pPCW_LX_predSide_0_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_predSide_0
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_predSide_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_predSide_0
*    PCW_LX_predSide_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_predSide_0 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_predSide_0( uint16 * pPCW_LX_predSide_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_predSide_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_predSide_0_b10;
      * pPCW_LX_predSide_0 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_PREDSIDE_0_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_predSide_1_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXPredSide1V * pPCW_LX_predSide_1_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_predSide_1_V
*    PCW_LX_predSide_1_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_predSide_1_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_predSide_1_V( PCWINITL3PCWLXPredSide1V * pPCW_LX_predSide_1_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXPredSide1V signal_value;
   
   if( pPCW_LX_predSide_1_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_predSide_1_V_b1;
      * pPCW_LX_predSide_1_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_predSide_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_predSide_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_predSide_1
*    PCW_LX_predSide_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_predSide_1 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_predSide_1( uint16 * pPCW_LX_predSide_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_predSide_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_predSide_1_b10;
      * pPCW_LX_predSide_1 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_PREDSIDE_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_predSide_2_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXPredSide2V * pPCW_LX_predSide_2_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_predSide_2_V
*    PCW_LX_predSide_2_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_predSide_2_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_predSide_2_V( PCWINITL3PCWLXPredSide2V * pPCW_LX_predSide_2_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXPredSide2V signal_value;
   
   if( pPCW_LX_predSide_2_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_predSide_2_V_b1;
      * pPCW_LX_predSide_2_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_predSide_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_predSide_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_predSide_2
*    PCW_LX_predSide_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_predSide_2 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_predSide_2( uint16 * pPCW_LX_predSide_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_predSide_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_predSide_2_b10;
      * pPCW_LX_predSide_2 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_PREDSIDE_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_predSide_3_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXPredSide3V * pPCW_LX_predSide_3_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_predSide_3_V
*    PCW_LX_predSide_3_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_predSide_3_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_predSide_3_V( PCWINITL3PCWLXPredSide3V * pPCW_LX_predSide_3_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXPredSide3V signal_value;
   
   if( pPCW_LX_predSide_3_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_predSide_3_V_b1;
      * pPCW_LX_predSide_3_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_predSide_3
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_predSide_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_predSide_3
*    PCW_LX_predSide_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_predSide_3 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_predSide_3( uint16 * pPCW_LX_predSide_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_predSide_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_predSide_3_b10;
      * pPCW_LX_predSide_3 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_PREDSIDE_3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_21_V
*
* FUNCTION ARGUMENTS:
*    boolean * pPCW_Buffer_21_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_21_V
*    PCW_Buffer_21_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_21_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_21_V( boolean * pPCW_Buffer_21_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pPCW_Buffer_21_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_21_V_b1;
      * pPCW_Buffer_21_V = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_21_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_21
*
* FUNCTION ARGUMENTS:
*    uint8 * pPCW_Buffer_21 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_21
*    PCW_Buffer_21 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_21 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_21( uint8 * pPCW_Buffer_21 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pPCW_Buffer_21 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_21_b8;
      * pPCW_Buffer_21 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_21_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_bicycleSide_0_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXBicycleSide0V * pPCW_LX_bicycleSide_0_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_bicycleSide_0_V
*    PCW_LX_bicycleSide_0_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_bicycleSide_0_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_bicycleSide_0_V( PCWINITL3PCWLXBicycleSide0V * pPCW_LX_bicycleSide_0_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXBicycleSide0V signal_value;
   
   if( pPCW_LX_bicycleSide_0_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_bicycleSide_0_V_b1;
      * pPCW_LX_bicycleSide_0_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_bicycleSide_0
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_bicycleSide_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_bicycleSide_0
*    PCW_LX_bicycleSide_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_bicycleSide_0 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_bicycleSide_0( uint16 * pPCW_LX_bicycleSide_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_bicycleSide_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_bicycleSide_0_b10;
      * pPCW_LX_bicycleSide_0 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_BICYCLESIDE_0_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_bicycleSide_1_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXBicycleSide1V * pPCW_LX_bicycleSide_1_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_bicycleSide_1_V
*    PCW_LX_bicycleSide_1_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_bicycleSide_1_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_bicycleSide_1_V( PCWINITL3PCWLXBicycleSide1V * pPCW_LX_bicycleSide_1_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXBicycleSide1V signal_value;
   
   if( pPCW_LX_bicycleSide_1_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_bicycleSide_1_V_b1;
      * pPCW_LX_bicycleSide_1_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_bicycleSide_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_bicycleSide_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_bicycleSide_1
*    PCW_LX_bicycleSide_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_bicycleSide_1 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_bicycleSide_1( uint16 * pPCW_LX_bicycleSide_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_bicycleSide_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_bicycleSide_1_b10;
      * pPCW_LX_bicycleSide_1 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_BICYCLESIDE_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_bicycleSide_2_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXBicycleSide2V * pPCW_LX_bicycleSide_2_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_bicycleSide_2_V
*    PCW_LX_bicycleSide_2_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_bicycleSide_2_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_bicycleSide_2_V( PCWINITL3PCWLXBicycleSide2V * pPCW_LX_bicycleSide_2_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXBicycleSide2V signal_value;
   
   if( pPCW_LX_bicycleSide_2_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_bicycleSide_2_V_b1;
      * pPCW_LX_bicycleSide_2_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_bicycleSide_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_bicycleSide_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_bicycleSide_2
*    PCW_LX_bicycleSide_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_bicycleSide_2 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_bicycleSide_2( uint16 * pPCW_LX_bicycleSide_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_bicycleSide_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_bicycleSide_2_b10;
      * pPCW_LX_bicycleSide_2 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_BICYCLESIDE_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_bicycleSide_3_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXBicycleSide3V * pPCW_LX_bicycleSide_3_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_bicycleSide_3_V
*    PCW_LX_bicycleSide_3_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_bicycleSide_3_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_bicycleSide_3_V( PCWINITL3PCWLXBicycleSide3V * pPCW_LX_bicycleSide_3_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXBicycleSide3V signal_value;
   
   if( pPCW_LX_bicycleSide_3_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_bicycleSide_3_V_b1;
      * pPCW_LX_bicycleSide_3_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_bicycleSide_3
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_bicycleSide_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_bicycleSide_3
*    PCW_LX_bicycleSide_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_bicycleSide_3 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_bicycleSide_3( uint16 * pPCW_LX_bicycleSide_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_bicycleSide_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_bicycleSide_3_b10;
      * pPCW_LX_bicycleSide_3 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_BICYCLESIDE_3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_MinPauseAfterWarn_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXMinPauseAfterWarnV * pPCW_LX_MinPauseAfterWarn_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_MinPauseAfterWarn_V
*    PCW_LX_MinPauseAfterWarn_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_MinPauseAfterWarn_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_MinPauseAfterWarn_V( PCWINITL3PCWLXMinPauseAfterWarnV * pPCW_LX_MinPauseAfterWarn_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXMinPauseAfterWarnV signal_value;
   
   if( pPCW_LX_MinPauseAfterWarn_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_MinPauseAfterWarn_V_b1;
      * pPCW_LX_MinPauseAfterWarn_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_MinPauseAfterWarn
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_MinPauseAfterWarn - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_MinPauseAfterWarn
*    PCW_LX_MinPauseAfterWarn returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_MinPauseAfterWarn signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_MinPauseAfterWarn( uint16 * pPCW_LX_MinPauseAfterWarn )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_MinPauseAfterWarn != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_MinPauseAfterWarn_b10;
      * pPCW_LX_MinPauseAfterWarn = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_MINPAUSEAFTERWARN_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_22_V
*
* FUNCTION ARGUMENTS:
*    boolean * pPCW_Buffer_22_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_22_V
*    PCW_Buffer_22_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_22_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_22_V( boolean * pPCW_Buffer_22_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pPCW_Buffer_22_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_22_V_b1;
      * pPCW_Buffer_22_V = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_22_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_22
*
* FUNCTION ARGUMENTS:
*    uint8 * pPCW_Buffer_22 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_22
*    PCW_Buffer_22 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_22 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_22( uint8 * pPCW_Buffer_22 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pPCW_Buffer_22 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_22_b8;
      * pPCW_Buffer_22 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_22_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_MinSpeedForWarn_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXMinSpeedForWarnV * pPCW_LX_MinSpeedForWarn_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_MinSpeedForWarn_V
*    PCW_LX_MinSpeedForWarn_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_MinSpeedForWarn_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_MinSpeedForWarn_V( PCWINITL3PCWLXMinSpeedForWarnV * pPCW_LX_MinSpeedForWarn_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXMinSpeedForWarnV signal_value;
   
   if( pPCW_LX_MinSpeedForWarn_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_MinSpeedForWarn_V_b1;
      * pPCW_LX_MinSpeedForWarn_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_MinSpeedForWarn
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_MinSpeedForWarn - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_MinSpeedForWarn
*    PCW_LX_MinSpeedForWarn returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_MinSpeedForWarn signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_MinSpeedForWarn( uint16 * pPCW_LX_MinSpeedForWarn )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_MinSpeedForWarn != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_MinSpeedForWarn_b14;
      * pPCW_LX_MinSpeedForWarn = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_MINSPEEDFORWARN_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_MaxSpeedForWarn_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXMaxSpeedForWarnV * pPCW_LX_MaxSpeedForWarn_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_MaxSpeedForWarn_V
*    PCW_LX_MaxSpeedForWarn_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_MaxSpeedForWarn_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_MaxSpeedForWarn_V( PCWINITL3PCWLXMaxSpeedForWarnV * pPCW_LX_MaxSpeedForWarn_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXMaxSpeedForWarnV signal_value;
   
   if( pPCW_LX_MaxSpeedForWarn_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_MaxSpeedForWarn_V_b1;
      * pPCW_LX_MaxSpeedForWarn_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_MaxSpeedForWarn
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_MaxSpeedForWarn - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_MaxSpeedForWarn
*    PCW_LX_MaxSpeedForWarn returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_MaxSpeedForWarn signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_MaxSpeedForWarn( uint16 * pPCW_LX_MaxSpeedForWarn )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_MaxSpeedForWarn != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_MaxSpeedForWarn_b14;
      * pPCW_LX_MaxSpeedForWarn = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_MAXSPEEDFORWARN_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_23_V
*
* FUNCTION ARGUMENTS:
*    boolean * pPCW_Buffer_23_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_23_V
*    PCW_Buffer_23_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_23_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_23_V( boolean * pPCW_Buffer_23_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pPCW_Buffer_23_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_23_V_b1;
      * pPCW_Buffer_23_V = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_23_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_23
*
* FUNCTION ARGUMENTS:
*    boolean * pPCW_Buffer_23 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_23
*    PCW_Buffer_23 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_23 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_23( boolean * pPCW_Buffer_23 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pPCW_Buffer_23 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_23_b1;
      * pPCW_Buffer_23 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_23_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_brakingTTCReduction_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXBrakingTTCReductionV * pPCW_LX_brakingTTCReduction_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_brakingTTCReduction_V
*    PCW_LX_brakingTTCReduction_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_brakingTTCReduction_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_brakingTTCReduction_V( PCWINITL3PCWLXBrakingTTCReductionV * pPCW_LX_brakingTTCReduction_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXBrakingTTCReductionV signal_value;
   
   if( pPCW_LX_brakingTTCReduction_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_brakingTTCReduction_V_b1;
      * pPCW_LX_brakingTTCReduction_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_brakingTTCReduction
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_brakingTTCReduction - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_brakingTTCReduction
*    PCW_LX_brakingTTCReduction returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_brakingTTCReduction signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_brakingTTCReduction( uint16 * pPCW_LX_brakingTTCReduction )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_brakingTTCReduction != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_brakingTTCReduction_b9;
      * pPCW_LX_brakingTTCReduction = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_BRAKINGTTCREDUCTION_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_maxYawRadPerSec_warn_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXMaxYawRadPerSecWarnV * pPCW_LX_maxYawRadPerSec_warn_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_maxYawRadPerSec_warn_V
*    PCW_LX_maxYawRadPerSec_warn_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_maxYawRadPerSec_warn_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_maxYawRadPerSec_warn_V( PCWINITL3PCWLXMaxYawRadPerSecWarnV * pPCW_LX_maxYawRadPerSec_warn_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXMaxYawRadPerSecWarnV signal_value;
   
   if( pPCW_LX_maxYawRadPerSec_warn_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_maxYawRadPerSec_warn_V_b1;
      * pPCW_LX_maxYawRadPerSec_warn_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_maxYawRadPerSec_warn
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_maxYawRadPerSec_warn - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_maxYawRadPerSec_warn
*    PCW_LX_maxYawRadPerSec_warn returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_maxYawRadPerSec_warn signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_maxYawRadPerSec_warn( uint16 * pPCW_LX_maxYawRadPerSec_warn )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_maxYawRadPerSec_warn != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_maxYawRadPerSec_warn_b9;
      * pPCW_LX_maxYawRadPerSec_warn = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_MAXYAWRADPERSEC_WARN_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_maxWheelAngle_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXMaxWheelAngleV * pPCW_LX_maxWheelAngle_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_maxWheelAngle_V
*    PCW_LX_maxWheelAngle_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_maxWheelAngle_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_maxWheelAngle_V( PCWINITL3PCWLXMaxWheelAngleV * pPCW_LX_maxWheelAngle_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXMaxWheelAngleV signal_value;
   
   if( pPCW_LX_maxWheelAngle_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_maxWheelAngle_V_b1;
      * pPCW_LX_maxWheelAngle_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_maxWheelAngle
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_maxWheelAngle - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_maxWheelAngle
*    PCW_LX_maxWheelAngle returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_maxWheelAngle signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_maxWheelAngle( uint16 * pPCW_LX_maxWheelAngle )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_maxWheelAngle != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_maxWheelAngle_b9;
      * pPCW_LX_maxWheelAngle = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_MAXWHEELANGLE_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_24_V
*
* FUNCTION ARGUMENTS:
*    boolean * pPCW_Buffer_24_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_24_V
*    PCW_Buffer_24_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_24_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_24_V( boolean * pPCW_Buffer_24_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pPCW_Buffer_24_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_24_V_b1;
      * pPCW_Buffer_24_V = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_24_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_24
*
* FUNCTION ARGUMENTS:
*    boolean * pPCW_Buffer_24 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_24
*    PCW_Buffer_24 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_24 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_24( boolean * pPCW_Buffer_24 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pPCW_Buffer_24 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_24_b1;
      * pPCW_Buffer_24 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_24_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_warn_far_0_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXTTCKPointsWarnFar0V * pPCW_LX_TTC_kPoints_warn_far_0_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_warn_far_0_V
*    PCW_LX_TTC_kPoints_warn_far_0_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_warn_far_0_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_warn_far_0_V( PCWINITL3PCWLXTTCKPointsWarnFar0V * pPCW_LX_TTC_kPoints_warn_far_0_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXTTCKPointsWarnFar0V signal_value;
   
   if( pPCW_LX_TTC_kPoints_warn_far_0_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_warn_far_0_V_b1;
      * pPCW_LX_TTC_kPoints_warn_far_0_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_warn_far_0
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_TTC_kPoints_warn_far_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_warn_far_0
*    PCW_LX_TTC_kPoints_warn_far_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_warn_far_0 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_warn_far_0( uint16 * pPCW_LX_TTC_kPoints_warn_far_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_TTC_kPoints_warn_far_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_warn_far_0_b9;
      * pPCW_LX_TTC_kPoints_warn_far_0 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_TTC_KPOINTS_WARN_FAR_0_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_warn_far_1_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXTTCKPointsWarnFar1V * pPCW_LX_TTC_kPoints_warn_far_1_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_warn_far_1_V
*    PCW_LX_TTC_kPoints_warn_far_1_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_warn_far_1_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_warn_far_1_V( PCWINITL3PCWLXTTCKPointsWarnFar1V * pPCW_LX_TTC_kPoints_warn_far_1_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXTTCKPointsWarnFar1V signal_value;
   
   if( pPCW_LX_TTC_kPoints_warn_far_1_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_warn_far_1_V_b1;
      * pPCW_LX_TTC_kPoints_warn_far_1_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_warn_far_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_TTC_kPoints_warn_far_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_warn_far_1
*    PCW_LX_TTC_kPoints_warn_far_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_warn_far_1 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_warn_far_1( uint16 * pPCW_LX_TTC_kPoints_warn_far_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_TTC_kPoints_warn_far_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_warn_far_1_b9;
      * pPCW_LX_TTC_kPoints_warn_far_1 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_TTC_KPOINTS_WARN_FAR_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_warn_far_2_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXTTCKPointsWarnFar2V * pPCW_LX_TTC_kPoints_warn_far_2_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_warn_far_2_V
*    PCW_LX_TTC_kPoints_warn_far_2_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_warn_far_2_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_warn_far_2_V( PCWINITL3PCWLXTTCKPointsWarnFar2V * pPCW_LX_TTC_kPoints_warn_far_2_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXTTCKPointsWarnFar2V signal_value;
   
   if( pPCW_LX_TTC_kPoints_warn_far_2_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_warn_far_2_V_b1;
      * pPCW_LX_TTC_kPoints_warn_far_2_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_warn_far_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_TTC_kPoints_warn_far_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_warn_far_2
*    PCW_LX_TTC_kPoints_warn_far_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_warn_far_2 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_warn_far_2( uint16 * pPCW_LX_TTC_kPoints_warn_far_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_TTC_kPoints_warn_far_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_warn_far_2_b9;
      * pPCW_LX_TTC_kPoints_warn_far_2 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_TTC_KPOINTS_WARN_FAR_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_25_V
*
* FUNCTION ARGUMENTS:
*    boolean * pPCW_Buffer_25_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_25_V
*    PCW_Buffer_25_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_25_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_25_V( boolean * pPCW_Buffer_25_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pPCW_Buffer_25_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_25_V_b1;
      * pPCW_Buffer_25_V = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_25_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_25
*
* FUNCTION ARGUMENTS:
*    boolean * pPCW_Buffer_25 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_25
*    PCW_Buffer_25 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_25 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_25( boolean * pPCW_Buffer_25 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pPCW_Buffer_25 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_25_b1;
      * pPCW_Buffer_25 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_25_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_warn_far_3_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXTTCKPointsWarnFar3V * pPCW_LX_TTC_kPoints_warn_far_3_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_warn_far_3_V
*    PCW_LX_TTC_kPoints_warn_far_3_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_warn_far_3_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_warn_far_3_V( PCWINITL3PCWLXTTCKPointsWarnFar3V * pPCW_LX_TTC_kPoints_warn_far_3_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXTTCKPointsWarnFar3V signal_value;
   
   if( pPCW_LX_TTC_kPoints_warn_far_3_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_warn_far_3_V_b1;
      * pPCW_LX_TTC_kPoints_warn_far_3_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_warn_far_3
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_TTC_kPoints_warn_far_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_warn_far_3
*    PCW_LX_TTC_kPoints_warn_far_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_warn_far_3 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_warn_far_3( uint16 * pPCW_LX_TTC_kPoints_warn_far_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_TTC_kPoints_warn_far_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_warn_far_3_b9;
      * pPCW_LX_TTC_kPoints_warn_far_3 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_TTC_KPOINTS_WARN_FAR_3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_warn_far_4_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXTTCKPointsWarnFar4V * pPCW_LX_TTC_kPoints_warn_far_4_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_warn_far_4_V
*    PCW_LX_TTC_kPoints_warn_far_4_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_warn_far_4_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_warn_far_4_V( PCWINITL3PCWLXTTCKPointsWarnFar4V * pPCW_LX_TTC_kPoints_warn_far_4_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXTTCKPointsWarnFar4V signal_value;
   
   if( pPCW_LX_TTC_kPoints_warn_far_4_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_warn_far_4_V_b1;
      * pPCW_LX_TTC_kPoints_warn_far_4_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_warn_far_4
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_TTC_kPoints_warn_far_4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_warn_far_4
*    PCW_LX_TTC_kPoints_warn_far_4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_warn_far_4 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_warn_far_4( uint16 * pPCW_LX_TTC_kPoints_warn_far_4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_TTC_kPoints_warn_far_4 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_warn_far_4_b9;
      * pPCW_LX_TTC_kPoints_warn_far_4 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_TTC_KPOINTS_WARN_FAR_4_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_warn_far_5_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXTTCKPointsWarnFar5V * pPCW_LX_TTC_kPoints_warn_far_5_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_warn_far_5_V
*    PCW_LX_TTC_kPoints_warn_far_5_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_warn_far_5_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_warn_far_5_V( PCWINITL3PCWLXTTCKPointsWarnFar5V * pPCW_LX_TTC_kPoints_warn_far_5_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXTTCKPointsWarnFar5V signal_value;
   
   if( pPCW_LX_TTC_kPoints_warn_far_5_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_warn_far_5_V_b1;
      * pPCW_LX_TTC_kPoints_warn_far_5_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_warn_far_5
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_TTC_kPoints_warn_far_5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_warn_far_5
*    PCW_LX_TTC_kPoints_warn_far_5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_warn_far_5 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_warn_far_5( uint16 * pPCW_LX_TTC_kPoints_warn_far_5 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_TTC_kPoints_warn_far_5 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_warn_far_5_b9;
      * pPCW_LX_TTC_kPoints_warn_far_5 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_TTC_KPOINTS_WARN_FAR_5_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_26_V
*
* FUNCTION ARGUMENTS:
*    boolean * pPCW_Buffer_26_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_26_V
*    PCW_Buffer_26_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_26_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_26_V( boolean * pPCW_Buffer_26_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pPCW_Buffer_26_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_26_V_b1;
      * pPCW_Buffer_26_V = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_26_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_26
*
* FUNCTION ARGUMENTS:
*    boolean * pPCW_Buffer_26 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_26
*    PCW_Buffer_26 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_26 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_26( boolean * pPCW_Buffer_26 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pPCW_Buffer_26 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_26_b1;
      * pPCW_Buffer_26 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_26_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_warn_n_0_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXTTCKPointsWarnN0V * pPCW_LX_TTC_kPoints_warn_n_0_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_warn_n_0_V
*    PCW_LX_TTC_kPoints_warn_n_0_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_warn_n_0_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_warn_n_0_V( PCWINITL3PCWLXTTCKPointsWarnN0V * pPCW_LX_TTC_kPoints_warn_n_0_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXTTCKPointsWarnN0V signal_value;
   
   if( pPCW_LX_TTC_kPoints_warn_n_0_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_warn_n_0_V_b1;
      * pPCW_LX_TTC_kPoints_warn_n_0_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_warn_n_0
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_TTC_kPoints_warn_n_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_warn_n_0
*    PCW_LX_TTC_kPoints_warn_n_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_warn_n_0 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_warn_n_0( uint16 * pPCW_LX_TTC_kPoints_warn_n_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_TTC_kPoints_warn_n_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_warn_n_0_b9;
      * pPCW_LX_TTC_kPoints_warn_n_0 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_TTC_KPOINTS_WARN_N_0_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_warn_n_1_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXTTCKPointsWarnN1V * pPCW_LX_TTC_kPoints_warn_n_1_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_warn_n_1_V
*    PCW_LX_TTC_kPoints_warn_n_1_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_warn_n_1_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_warn_n_1_V( PCWINITL3PCWLXTTCKPointsWarnN1V * pPCW_LX_TTC_kPoints_warn_n_1_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXTTCKPointsWarnN1V signal_value;
   
   if( pPCW_LX_TTC_kPoints_warn_n_1_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_warn_n_1_V_b1;
      * pPCW_LX_TTC_kPoints_warn_n_1_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_warn_n_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_TTC_kPoints_warn_n_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_warn_n_1
*    PCW_LX_TTC_kPoints_warn_n_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_warn_n_1 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_warn_n_1( uint16 * pPCW_LX_TTC_kPoints_warn_n_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_TTC_kPoints_warn_n_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_warn_n_1_b9;
      * pPCW_LX_TTC_kPoints_warn_n_1 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_TTC_KPOINTS_WARN_N_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_warn_n_2_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXTTCKPointsWarnN2V * pPCW_LX_TTC_kPoints_warn_n_2_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_warn_n_2_V
*    PCW_LX_TTC_kPoints_warn_n_2_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_warn_n_2_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_warn_n_2_V( PCWINITL3PCWLXTTCKPointsWarnN2V * pPCW_LX_TTC_kPoints_warn_n_2_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXTTCKPointsWarnN2V signal_value;
   
   if( pPCW_LX_TTC_kPoints_warn_n_2_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_warn_n_2_V_b1;
      * pPCW_LX_TTC_kPoints_warn_n_2_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_warn_n_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_TTC_kPoints_warn_n_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_warn_n_2
*    PCW_LX_TTC_kPoints_warn_n_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_warn_n_2 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_warn_n_2( uint16 * pPCW_LX_TTC_kPoints_warn_n_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_TTC_kPoints_warn_n_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_warn_n_2_b9;
      * pPCW_LX_TTC_kPoints_warn_n_2 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_TTC_KPOINTS_WARN_N_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_27_V
*
* FUNCTION ARGUMENTS:
*    boolean * pPCW_Buffer_27_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_27_V
*    PCW_Buffer_27_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_27_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_27_V( boolean * pPCW_Buffer_27_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pPCW_Buffer_27_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_27_V_b1;
      * pPCW_Buffer_27_V = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_27_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_27
*
* FUNCTION ARGUMENTS:
*    boolean * pPCW_Buffer_27 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_27
*    PCW_Buffer_27 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_27 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_27( boolean * pPCW_Buffer_27 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pPCW_Buffer_27 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_27_b1;
      * pPCW_Buffer_27 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_27_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_warn_n_3_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXTTCKPointsWarnN3V * pPCW_LX_TTC_kPoints_warn_n_3_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_warn_n_3_V
*    PCW_LX_TTC_kPoints_warn_n_3_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_warn_n_3_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_warn_n_3_V( PCWINITL3PCWLXTTCKPointsWarnN3V * pPCW_LX_TTC_kPoints_warn_n_3_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXTTCKPointsWarnN3V signal_value;
   
   if( pPCW_LX_TTC_kPoints_warn_n_3_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_warn_n_3_V_b1;
      * pPCW_LX_TTC_kPoints_warn_n_3_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_warn_n_3
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_TTC_kPoints_warn_n_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_warn_n_3
*    PCW_LX_TTC_kPoints_warn_n_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_warn_n_3 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_warn_n_3( uint16 * pPCW_LX_TTC_kPoints_warn_n_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_TTC_kPoints_warn_n_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_warn_n_3_b9;
      * pPCW_LX_TTC_kPoints_warn_n_3 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_TTC_KPOINTS_WARN_N_3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_warn_n_4_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXTTCKPointsWarnN4V * pPCW_LX_TTC_kPoints_warn_n_4_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_warn_n_4_V
*    PCW_LX_TTC_kPoints_warn_n_4_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_warn_n_4_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_warn_n_4_V( PCWINITL3PCWLXTTCKPointsWarnN4V * pPCW_LX_TTC_kPoints_warn_n_4_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXTTCKPointsWarnN4V signal_value;
   
   if( pPCW_LX_TTC_kPoints_warn_n_4_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_warn_n_4_V_b1;
      * pPCW_LX_TTC_kPoints_warn_n_4_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_warn_n_4
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_TTC_kPoints_warn_n_4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_warn_n_4
*    PCW_LX_TTC_kPoints_warn_n_4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_warn_n_4 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_warn_n_4( uint16 * pPCW_LX_TTC_kPoints_warn_n_4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_TTC_kPoints_warn_n_4 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_warn_n_4_b9;
      * pPCW_LX_TTC_kPoints_warn_n_4 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_TTC_KPOINTS_WARN_N_4_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_warn_n_5_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXTTCKPointsWarnN5V * pPCW_LX_TTC_kPoints_warn_n_5_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_warn_n_5_V
*    PCW_LX_TTC_kPoints_warn_n_5_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_warn_n_5_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_warn_n_5_V( PCWINITL3PCWLXTTCKPointsWarnN5V * pPCW_LX_TTC_kPoints_warn_n_5_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXTTCKPointsWarnN5V signal_value;
   
   if( pPCW_LX_TTC_kPoints_warn_n_5_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_warn_n_5_V_b1;
      * pPCW_LX_TTC_kPoints_warn_n_5_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_warn_n_5
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_TTC_kPoints_warn_n_5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_warn_n_5
*    PCW_LX_TTC_kPoints_warn_n_5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_warn_n_5 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_warn_n_5( uint16 * pPCW_LX_TTC_kPoints_warn_n_5 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_TTC_kPoints_warn_n_5 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_warn_n_5_b9;
      * pPCW_LX_TTC_kPoints_warn_n_5 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_TTC_KPOINTS_WARN_N_5_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_28_V
*
* FUNCTION ARGUMENTS:
*    boolean * pPCW_Buffer_28_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_28_V
*    PCW_Buffer_28_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_28_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_28_V( boolean * pPCW_Buffer_28_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pPCW_Buffer_28_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_28_V_b1;
      * pPCW_Buffer_28_V = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_28_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_28
*
* FUNCTION ARGUMENTS:
*    boolean * pPCW_Buffer_28 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_28
*    PCW_Buffer_28 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_28 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_28( boolean * pPCW_Buffer_28 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pPCW_Buffer_28 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_28_b1;
      * pPCW_Buffer_28 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_28_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bi_F_0_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXTTCKPointsBiF0V * pPCW_LX_TTC_kPoints_bi_F_0_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_bi_F_0_V
*    PCW_LX_TTC_kPoints_bi_F_0_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_bi_F_0_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bi_F_0_V( PCWINITL3PCWLXTTCKPointsBiF0V * pPCW_LX_TTC_kPoints_bi_F_0_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXTTCKPointsBiF0V signal_value;
   
   if( pPCW_LX_TTC_kPoints_bi_F_0_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_bi_F_0_V_b1;
      * pPCW_LX_TTC_kPoints_bi_F_0_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bi_F_0
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_TTC_kPoints_bi_F_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_bi_F_0
*    PCW_LX_TTC_kPoints_bi_F_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_bi_F_0 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bi_F_0( uint16 * pPCW_LX_TTC_kPoints_bi_F_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_TTC_kPoints_bi_F_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_bi_F_0_b9;
      * pPCW_LX_TTC_kPoints_bi_F_0 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_TTC_KPOINTS_BI_F_0_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bi_F_1_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXTTCKPointsBiF1V * pPCW_LX_TTC_kPoints_bi_F_1_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_bi_F_1_V
*    PCW_LX_TTC_kPoints_bi_F_1_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_bi_F_1_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bi_F_1_V( PCWINITL3PCWLXTTCKPointsBiF1V * pPCW_LX_TTC_kPoints_bi_F_1_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXTTCKPointsBiF1V signal_value;
   
   if( pPCW_LX_TTC_kPoints_bi_F_1_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_bi_F_1_V_b1;
      * pPCW_LX_TTC_kPoints_bi_F_1_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bi_F_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_TTC_kPoints_bi_F_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_bi_F_1
*    PCW_LX_TTC_kPoints_bi_F_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_bi_F_1 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bi_F_1( uint16 * pPCW_LX_TTC_kPoints_bi_F_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_TTC_kPoints_bi_F_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_bi_F_1_b9;
      * pPCW_LX_TTC_kPoints_bi_F_1 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_TTC_KPOINTS_BI_F_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bi_F_2_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXTTCKPointsBiF2V * pPCW_LX_TTC_kPoints_bi_F_2_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_bi_F_2_V
*    PCW_LX_TTC_kPoints_bi_F_2_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_bi_F_2_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bi_F_2_V( PCWINITL3PCWLXTTCKPointsBiF2V * pPCW_LX_TTC_kPoints_bi_F_2_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXTTCKPointsBiF2V signal_value;
   
   if( pPCW_LX_TTC_kPoints_bi_F_2_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_bi_F_2_V_b1;
      * pPCW_LX_TTC_kPoints_bi_F_2_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bi_F_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_TTC_kPoints_bi_F_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_bi_F_2
*    PCW_LX_TTC_kPoints_bi_F_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_bi_F_2 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bi_F_2( uint16 * pPCW_LX_TTC_kPoints_bi_F_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_TTC_kPoints_bi_F_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_bi_F_2_b9;
      * pPCW_LX_TTC_kPoints_bi_F_2 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_TTC_KPOINTS_BI_F_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_29_V
*
* FUNCTION ARGUMENTS:
*    boolean * pPCW_Buffer_29_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_29_V
*    PCW_Buffer_29_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_29_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_29_V( boolean * pPCW_Buffer_29_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pPCW_Buffer_29_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_29_V_b1;
      * pPCW_Buffer_29_V = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_29_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_29
*
* FUNCTION ARGUMENTS:
*    boolean * pPCW_Buffer_29 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_29
*    PCW_Buffer_29 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_29 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_29( boolean * pPCW_Buffer_29 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pPCW_Buffer_29 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_29_b1;
      * pPCW_Buffer_29 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_29_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bi_F_3_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXTTCKPointsBiF3V * pPCW_LX_TTC_kPoints_bi_F_3_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_bi_F_3_V
*    PCW_LX_TTC_kPoints_bi_F_3_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_bi_F_3_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bi_F_3_V( PCWINITL3PCWLXTTCKPointsBiF3V * pPCW_LX_TTC_kPoints_bi_F_3_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXTTCKPointsBiF3V signal_value;
   
   if( pPCW_LX_TTC_kPoints_bi_F_3_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_bi_F_3_V_b1;
      * pPCW_LX_TTC_kPoints_bi_F_3_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bi_F_3
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_TTC_kPoints_bi_F_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_bi_F_3
*    PCW_LX_TTC_kPoints_bi_F_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_bi_F_3 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bi_F_3( uint16 * pPCW_LX_TTC_kPoints_bi_F_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_TTC_kPoints_bi_F_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_bi_F_3_b9;
      * pPCW_LX_TTC_kPoints_bi_F_3 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_TTC_KPOINTS_BI_F_3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bi_F_4_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXTTCKPointsBiF4V * pPCW_LX_TTC_kPoints_bi_F_4_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_bi_F_4_V
*    PCW_LX_TTC_kPoints_bi_F_4_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_bi_F_4_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bi_F_4_V( PCWINITL3PCWLXTTCKPointsBiF4V * pPCW_LX_TTC_kPoints_bi_F_4_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXTTCKPointsBiF4V signal_value;
   
   if( pPCW_LX_TTC_kPoints_bi_F_4_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_bi_F_4_V_b1;
      * pPCW_LX_TTC_kPoints_bi_F_4_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bi_F_4
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_TTC_kPoints_bi_F_4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_bi_F_4
*    PCW_LX_TTC_kPoints_bi_F_4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_bi_F_4 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bi_F_4( uint16 * pPCW_LX_TTC_kPoints_bi_F_4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_TTC_kPoints_bi_F_4 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_bi_F_4_b9;
      * pPCW_LX_TTC_kPoints_bi_F_4 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_TTC_KPOINTS_BI_F_4_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bi_F_5_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXTTCKPointsBiF5V * pPCW_LX_TTC_kPoints_bi_F_5_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_bi_F_5_V
*    PCW_LX_TTC_kPoints_bi_F_5_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_bi_F_5_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bi_F_5_V( PCWINITL3PCWLXTTCKPointsBiF5V * pPCW_LX_TTC_kPoints_bi_F_5_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXTTCKPointsBiF5V signal_value;
   
   if( pPCW_LX_TTC_kPoints_bi_F_5_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_bi_F_5_V_b1;
      * pPCW_LX_TTC_kPoints_bi_F_5_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bi_F_5
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_TTC_kPoints_bi_F_5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_bi_F_5
*    PCW_LX_TTC_kPoints_bi_F_5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_bi_F_5 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bi_F_5( uint16 * pPCW_LX_TTC_kPoints_bi_F_5 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_TTC_kPoints_bi_F_5 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_bi_F_5_b9;
      * pPCW_LX_TTC_kPoints_bi_F_5 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_TTC_KPOINTS_BI_F_5_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_30_V
*
* FUNCTION ARGUMENTS:
*    boolean * pPCW_Buffer_30_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_30_V
*    PCW_Buffer_30_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_30_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_30_V( boolean * pPCW_Buffer_30_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pPCW_Buffer_30_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_30_V_b1;
      * pPCW_Buffer_30_V = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_30_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_30
*
* FUNCTION ARGUMENTS:
*    boolean * pPCW_Buffer_30 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_30
*    PCW_Buffer_30 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_30 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_30( boolean * pPCW_Buffer_30 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pPCW_Buffer_30 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_30_b1;
      * pPCW_Buffer_30 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_30_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bi_N_0_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXTTCKPointsBiN0V * pPCW_LX_TTC_kPoints_bi_N_0_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_bi_N_0_V
*    PCW_LX_TTC_kPoints_bi_N_0_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_bi_N_0_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bi_N_0_V( PCWINITL3PCWLXTTCKPointsBiN0V * pPCW_LX_TTC_kPoints_bi_N_0_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXTTCKPointsBiN0V signal_value;
   
   if( pPCW_LX_TTC_kPoints_bi_N_0_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_bi_N_0_V_b1;
      * pPCW_LX_TTC_kPoints_bi_N_0_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bi_N_0
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_TTC_kPoints_bi_N_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_bi_N_0
*    PCW_LX_TTC_kPoints_bi_N_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_bi_N_0 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bi_N_0( uint16 * pPCW_LX_TTC_kPoints_bi_N_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_TTC_kPoints_bi_N_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_bi_N_0_b9;
      * pPCW_LX_TTC_kPoints_bi_N_0 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_TTC_KPOINTS_BI_N_0_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bi_N_1_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXTTCKPointsBiN1V * pPCW_LX_TTC_kPoints_bi_N_1_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_bi_N_1_V
*    PCW_LX_TTC_kPoints_bi_N_1_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_bi_N_1_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bi_N_1_V( PCWINITL3PCWLXTTCKPointsBiN1V * pPCW_LX_TTC_kPoints_bi_N_1_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXTTCKPointsBiN1V signal_value;
   
   if( pPCW_LX_TTC_kPoints_bi_N_1_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_bi_N_1_V_b1;
      * pPCW_LX_TTC_kPoints_bi_N_1_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bi_N_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_TTC_kPoints_bi_N_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_bi_N_1
*    PCW_LX_TTC_kPoints_bi_N_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_bi_N_1 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bi_N_1( uint16 * pPCW_LX_TTC_kPoints_bi_N_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_TTC_kPoints_bi_N_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_bi_N_1_b9;
      * pPCW_LX_TTC_kPoints_bi_N_1 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_TTC_KPOINTS_BI_N_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bi_N_2_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXTTCKPointsBiN2V * pPCW_LX_TTC_kPoints_bi_N_2_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_bi_N_2_V
*    PCW_LX_TTC_kPoints_bi_N_2_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_bi_N_2_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bi_N_2_V( PCWINITL3PCWLXTTCKPointsBiN2V * pPCW_LX_TTC_kPoints_bi_N_2_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXTTCKPointsBiN2V signal_value;
   
   if( pPCW_LX_TTC_kPoints_bi_N_2_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_bi_N_2_V_b1;
      * pPCW_LX_TTC_kPoints_bi_N_2_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bi_N_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_TTC_kPoints_bi_N_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_bi_N_2
*    PCW_LX_TTC_kPoints_bi_N_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_bi_N_2 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bi_N_2( uint16 * pPCW_LX_TTC_kPoints_bi_N_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_TTC_kPoints_bi_N_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_bi_N_2_b9;
      * pPCW_LX_TTC_kPoints_bi_N_2 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_TTC_KPOINTS_BI_N_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_31_V
*
* FUNCTION ARGUMENTS:
*    boolean * pPCW_Buffer_31_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_31_V
*    PCW_Buffer_31_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_31_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_31_V( boolean * pPCW_Buffer_31_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pPCW_Buffer_31_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_31_V_b1;
      * pPCW_Buffer_31_V = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_31_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_Buffer_31
*
* FUNCTION ARGUMENTS:
*    boolean * pPCW_Buffer_31 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_Buffer_31
*    PCW_Buffer_31 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_Buffer_31 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_Buffer_31( boolean * pPCW_Buffer_31 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pPCW_Buffer_31 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_Buffer_31_b1;
      * pPCW_Buffer_31 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_BUFFER_31_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bi_N_3_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXTTCKPointsBiN3V * pPCW_LX_TTC_kPoints_bi_N_3_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_bi_N_3_V
*    PCW_LX_TTC_kPoints_bi_N_3_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_bi_N_3_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bi_N_3_V( PCWINITL3PCWLXTTCKPointsBiN3V * pPCW_LX_TTC_kPoints_bi_N_3_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXTTCKPointsBiN3V signal_value;
   
   if( pPCW_LX_TTC_kPoints_bi_N_3_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_bi_N_3_V_b1;
      * pPCW_LX_TTC_kPoints_bi_N_3_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bi_N_3
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_TTC_kPoints_bi_N_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_bi_N_3
*    PCW_LX_TTC_kPoints_bi_N_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_bi_N_3 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bi_N_3( uint16 * pPCW_LX_TTC_kPoints_bi_N_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_TTC_kPoints_bi_N_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_bi_N_3_b9;
      * pPCW_LX_TTC_kPoints_bi_N_3 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_TTC_KPOINTS_BI_N_3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bi_N_4_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXTTCKPointsBiN4V * pPCW_LX_TTC_kPoints_bi_N_4_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_bi_N_4_V
*    PCW_LX_TTC_kPoints_bi_N_4_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_bi_N_4_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bi_N_4_V( PCWINITL3PCWLXTTCKPointsBiN4V * pPCW_LX_TTC_kPoints_bi_N_4_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXTTCKPointsBiN4V signal_value;
   
   if( pPCW_LX_TTC_kPoints_bi_N_4_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_bi_N_4_V_b1;
      * pPCW_LX_TTC_kPoints_bi_N_4_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bi_N_4
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_TTC_kPoints_bi_N_4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_bi_N_4
*    PCW_LX_TTC_kPoints_bi_N_4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_bi_N_4 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bi_N_4( uint16 * pPCW_LX_TTC_kPoints_bi_N_4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_TTC_kPoints_bi_N_4 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_bi_N_4_b9;
      * pPCW_LX_TTC_kPoints_bi_N_4 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_TTC_KPOINTS_BI_N_4_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bi_N_5_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXTTCKPointsBiN5V * pPCW_LX_TTC_kPoints_bi_N_5_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_bi_N_5_V
*    PCW_LX_TTC_kPoints_bi_N_5_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_bi_N_5_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bi_N_5_V( PCWINITL3PCWLXTTCKPointsBiN5V * pPCW_LX_TTC_kPoints_bi_N_5_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXTTCKPointsBiN5V signal_value;
   
   if( pPCW_LX_TTC_kPoints_bi_N_5_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_bi_N_5_V_b1;
      * pPCW_LX_TTC_kPoints_bi_N_5_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bi_N_5
*
* FUNCTION ARGUMENTS:
*    uint16 * pPCW_LX_TTC_kPoints_bi_N_5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_TTC_kPoints_bi_N_5
*    PCW_LX_TTC_kPoints_bi_N_5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_TTC_kPoints_bi_N_5 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_TTC_kPoints_bi_N_5( uint16 * pPCW_LX_TTC_kPoints_bi_N_5 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pPCW_LX_TTC_kPoints_bi_N_5 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_TTC_kPoints_bi_N_5_b9;
      * pPCW_LX_TTC_kPoints_bi_N_5 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_PCW_LX_TTC_KPOINTS_BI_N_5_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_DeactivateInNight_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXDeactivateInNightV * pPCW_LX_DeactivateInNight_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_DeactivateInNight_V
*    PCW_LX_DeactivateInNight_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_DeactivateInNight_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_DeactivateInNight_V( PCWINITL3PCWLXDeactivateInNightV * pPCW_LX_DeactivateInNight_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXDeactivateInNightV signal_value;
   
   if( pPCW_LX_DeactivateInNight_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_DeactivateInNight_V_b1;
      * pPCW_LX_DeactivateInNight_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_DeactivateInNight
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXDeactivateInNight * pPCW_LX_DeactivateInNight - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_DeactivateInNight
*    PCW_LX_DeactivateInNight returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_DeactivateInNight signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_DeactivateInNight( PCWINITL3PCWLXDeactivateInNight * pPCW_LX_DeactivateInNight )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXDeactivateInNight signal_value;
   
   if( pPCW_LX_DeactivateInNight != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_DeactivateInNight_b1;
      * pPCW_LX_DeactivateInNight = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_adhereToGapSensitivity_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXAdhereToGapSensitivityV * pPCW_LX_adhereToGapSensitivity_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_adhereToGapSensitivity_V
*    PCW_LX_adhereToGapSensitivity_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_adhereToGapSensitivity_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_adhereToGapSensitivity_V( PCWINITL3PCWLXAdhereToGapSensitivityV * pPCW_LX_adhereToGapSensitivity_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXAdhereToGapSensitivityV signal_value;
   
   if( pPCW_LX_adhereToGapSensitivity_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_adhereToGapSensitivity_V_b1;
      * pPCW_LX_adhereToGapSensitivity_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_adhereToGapSensitivity
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXAdhereToGapSensitivity * pPCW_LX_adhereToGapSensitivity - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_adhereToGapSensitivity
*    PCW_LX_adhereToGapSensitivity returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_adhereToGapSensitivity signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_adhereToGapSensitivity( PCWINITL3PCWLXAdhereToGapSensitivity * pPCW_LX_adhereToGapSensitivity )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXAdhereToGapSensitivity signal_value;
   
   if( pPCW_LX_adhereToGapSensitivity != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_adhereToGapSensitivity_b1;
      * pPCW_LX_adhereToGapSensitivity = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_warnOnBicycles_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXWarnOnBicyclesV * pPCW_LX_warnOnBicycles_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_warnOnBicycles_V
*    PCW_LX_warnOnBicycles_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_warnOnBicycles_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_warnOnBicycles_V( PCWINITL3PCWLXWarnOnBicyclesV * pPCW_LX_warnOnBicycles_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXWarnOnBicyclesV signal_value;
   
   if( pPCW_LX_warnOnBicycles_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_warnOnBicycles_V_b1;
      * pPCW_LX_warnOnBicycles_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_warnOnBicycles
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXWarnOnBicycles * pPCW_LX_warnOnBicycles - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_warnOnBicycles
*    PCW_LX_warnOnBicycles returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_warnOnBicycles signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_warnOnBicycles( PCWINITL3PCWLXWarnOnBicycles * pPCW_LX_warnOnBicycles )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXWarnOnBicycles signal_value;
   
   if( pPCW_LX_warnOnBicycles != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_warnOnBicycles_b1;
      * pPCW_LX_warnOnBicycles = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_SuppressByBrake_V
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXSuppressByBrakeV * pPCW_LX_SuppressByBrake_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_SuppressByBrake_V
*    PCW_LX_SuppressByBrake_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_SuppressByBrake_V signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_SuppressByBrake_V( PCWINITL3PCWLXSuppressByBrakeV * pPCW_LX_SuppressByBrake_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXSuppressByBrakeV signal_value;
   
   if( pPCW_LX_SuppressByBrake_V != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_SuppressByBrake_V_b1;
      * pPCW_LX_SuppressByBrake_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_PCW_LX_SuppressByBrake
*
* FUNCTION ARGUMENTS:
*    PCWINITL3PCWLXSuppressByBrake * pPCW_LX_SuppressByBrake - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of PCW_LX_SuppressByBrake
*    PCW_LX_SuppressByBrake returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns PCW_LX_SuppressByBrake signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_PCW_LX_SuppressByBrake( PCWINITL3PCWLXSuppressByBrake * pPCW_LX_SuppressByBrake )
{
   Std_ReturnType status = C_SIG_INVALID;
   PCWINITL3PCWLXSuppressByBrake signal_value;
   
   if( pPCW_LX_SuppressByBrake != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.PCW_LX_SuppressByBrake_b1;
      * pPCW_LX_SuppressByBrake = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_PCWINITL3_Reserved_1
*
* FUNCTION ARGUMENTS:
*    uint32 * pReserved_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1
*    Reserved_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1 signal value of PCW_Init_L3 message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_PCWINITL3_Reserved_1( uint32 * pReserved_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pReserved_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_PCWINITL3_ParamsApp_s.Reserved_1_b27;
      * pReserved_1 = signal_value;
      if( signal_value <= C_EYEQMSG_PCWINITL3_RESERVED_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

