

/*****************************************************************************
                  Include files
*****************************************************************************/
/* The suggested include file order is: */
#include "EyeQ_defs.h"    /* EyeQ project common definitions file    */

#include "EYEQMSG_LightSceneInitProcess.h"

/*****************************************************************************
                  Local symbolic constants
*****************************************************************************/
/*****************************************************************************
                  Local types, enums definitions
*****************************************************************************/
/*****************************************************************************
                  Local function prototypes
*****************************************************************************/
/*****************************************************************************
                  Local object definitions
*****************************************************************************/
/*****************************************************************************
                  Exported object definitions
*****************************************************************************/
EYEQMSG_CORELIGHTSCENEINIT_Params_t   EYEQMSG_CORELIGHTSCENEINIT_Params_s;
EYEQMSG_CORELIGHTSCENEINIT_Params_t   EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s;
/*****************************************************************************
                  Local function-like macros
*****************************************************************************/
/*****************************************************************************
                  Local defined macros
*****************************************************************************/
/*****************************************************************************
                  Function definitions
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_CORELIGHTSCENEINIT_Params_t * pLight_Scene_Init - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Light_Scene_Init message 
*    Light_Scene_Init message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Light_Scene_Init message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_MsgDataStruct( EYEQMSG_CORELIGHTSCENEINIT_Params_t * pLight_Scene_Init )
{
   Std_ReturnType status = C_SIG_INVALID;
   if( pLight_Scene_Init != C_NULL_P )
   {
      status = C_SIG_VALID;
      * pLight_Scene_Init = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pILS_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Zero_byte
*    ILS_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Zero_byte signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Zero_byte( uint8 * pILS_Zero_byte )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pILS_Zero_byte != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Zero_byte_b8;
      * pILS_Zero_byte = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_ZERO_BYTE_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pILS_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Protocol_Version
*    ILS_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Protocol_Version signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Protocol_Version( uint8 * pILS_Protocol_Version )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pILS_Protocol_Version != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Protocol_Version_b8;
      * pILS_Protocol_Version = signal_value;
      if( (signal_value >= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_PROTOCOL_VERSION_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_PROTOCOL_VERSION_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Optional_Signals
*
* FUNCTION ARGUMENTS:
*    uint8 * pILS_Optional_Signals - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Optional_Signals
*    ILS_Optional_Signals returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Optional_Signals signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Optional_Signals( uint8 * pILS_Optional_Signals )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pILS_Optional_Signals != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Optional_Signals_b8;
      * pILS_Optional_Signals = signal_value;
      if( (signal_value >= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_OPTIONAL_SIGNALS_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_OPTIONAL_SIGNALS_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_1_V
*
* FUNCTION ARGUMENTS:
*    boolean * pILS_Buffer_1_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_1_V
*    ILS_Buffer_1_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_1_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_1_V( boolean * pILS_Buffer_1_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pILS_Buffer_1_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_1_V_b1;
      * pILS_Buffer_1_V = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_1_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_1
*
* FUNCTION ARGUMENTS:
*    uint8 * pILS_Buffer_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_1
*    ILS_Buffer_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_1 signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_1( uint8 * pILS_Buffer_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pILS_Buffer_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_1_b6;
      * pILS_Buffer_1 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_IN_CURVE_RADIUS_ENTER_THRESH_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITCINCURVERADIUSENTERTHRESHV * pC_IN_CURVE_RADIUS_ENTER_THRESH_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_IN_CURVE_RADIUS_ENTER_THRESH_V
*    C_IN_CURVE_RADIUS_ENTER_THRESH_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_IN_CURVE_RADIUS_ENTER_THRESH_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_IN_CURVE_RADIUS_ENTER_THRESH_V( CORELIGHTSCENEINITCINCURVERADIUSENTERTHRESHV * pC_IN_CURVE_RADIUS_ENTER_THRESH_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITCINCURVERADIUSENTERTHRESHV signal_value;
   
   if( pC_IN_CURVE_RADIUS_ENTER_THRESH_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_IN_CURVE_RADIUS_ENTER_THRESH_V_b1;
      * pC_IN_CURVE_RADIUS_ENTER_THRESH_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_IN_CURVE_RADIUS_ENTER_THRESH
*
* FUNCTION ARGUMENTS:
*    uint16 * pC_IN_CURVE_RADIUS_ENTER_THRESH - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_IN_CURVE_RADIUS_ENTER_THRESH
*    C_IN_CURVE_RADIUS_ENTER_THRESH returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_IN_CURVE_RADIUS_ENTER_THRESH signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_IN_CURVE_RADIUS_ENTER_THRESH( uint16 * pC_IN_CURVE_RADIUS_ENTER_THRESH )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pC_IN_CURVE_RADIUS_ENTER_THRESH != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_IN_CURVE_RADIUS_ENTER_THRESH_b11;
      * pC_IN_CURVE_RADIUS_ENTER_THRESH = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_C_IN_CURVE_RADIUS_ENTER_THRESH_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_IN_CURVE_RADIUS_EXIT_THRESH_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITCINCURVERADIUSEXITTHRESHV * pC_IN_CURVE_RADIUS_EXIT_THRESH_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_IN_CURVE_RADIUS_EXIT_THRESH_V
*    C_IN_CURVE_RADIUS_EXIT_THRESH_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_IN_CURVE_RADIUS_EXIT_THRESH_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_IN_CURVE_RADIUS_EXIT_THRESH_V( CORELIGHTSCENEINITCINCURVERADIUSEXITTHRESHV * pC_IN_CURVE_RADIUS_EXIT_THRESH_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITCINCURVERADIUSEXITTHRESHV signal_value;
   
   if( pC_IN_CURVE_RADIUS_EXIT_THRESH_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_IN_CURVE_RADIUS_EXIT_THRESH_V_b1;
      * pC_IN_CURVE_RADIUS_EXIT_THRESH_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_IN_CURVE_RADIUS_EXIT_THRESH
*
* FUNCTION ARGUMENTS:
*    uint16 * pC_IN_CURVE_RADIUS_EXIT_THRESH - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_IN_CURVE_RADIUS_EXIT_THRESH
*    C_IN_CURVE_RADIUS_EXIT_THRESH returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_IN_CURVE_RADIUS_EXIT_THRESH signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_IN_CURVE_RADIUS_EXIT_THRESH( uint16 * pC_IN_CURVE_RADIUS_EXIT_THRESH )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pC_IN_CURVE_RADIUS_EXIT_THRESH != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_IN_CURVE_RADIUS_EXIT_THRESH_b11;
      * pC_IN_CURVE_RADIUS_EXIT_THRESH = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_C_IN_CURVE_RADIUS_EXIT_THRESH_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_2_V
*
* FUNCTION ARGUMENTS:
*    boolean * pILS_Buffer_2_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_2_V
*    ILS_Buffer_2_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_2_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_2_V( boolean * pILS_Buffer_2_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pILS_Buffer_2_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_2_V_b1;
      * pILS_Buffer_2_V = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_2_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_2
*
* FUNCTION ARGUMENTS:
*    uint8 * pILS_Buffer_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_2
*    ILS_Buffer_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_2 signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_2( uint8 * pILS_Buffer_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pILS_Buffer_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_2_b7;
      * pILS_Buffer_2 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_VERY_SHARP_CUR_RADIUS_ENTER_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITCVERYSHARPCURRADIUSENTERV * pC_VERY_SHARP_CUR_RADIUS_ENTER_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_VERY_SHARP_CUR_RADIUS_ENTER_V
*    C_VERY_SHARP_CUR_RADIUS_ENTER_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_VERY_SHARP_CUR_RADIUS_ENTER_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_VERY_SHARP_CUR_RADIUS_ENTER_V( CORELIGHTSCENEINITCVERYSHARPCURRADIUSENTERV * pC_VERY_SHARP_CUR_RADIUS_ENTER_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITCVERYSHARPCURRADIUSENTERV signal_value;
   
   if( pC_VERY_SHARP_CUR_RADIUS_ENTER_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_VERY_SHARP_CUR_RADIUS_ENTER_V_b1;
      * pC_VERY_SHARP_CUR_RADIUS_ENTER_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_VERY_SHARP_CUR_RADIUS_ENTER
*
* FUNCTION ARGUMENTS:
*    uint16 * pC_VERY_SHARP_CUR_RADIUS_ENTER - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_VERY_SHARP_CUR_RADIUS_ENTER
*    C_VERY_SHARP_CUR_RADIUS_ENTER returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_VERY_SHARP_CUR_RADIUS_ENTER signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_VERY_SHARP_CUR_RADIUS_ENTER( uint16 * pC_VERY_SHARP_CUR_RADIUS_ENTER )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pC_VERY_SHARP_CUR_RADIUS_ENTER != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_VERY_SHARP_CUR_RADIUS_ENTER_b11;
      * pC_VERY_SHARP_CUR_RADIUS_ENTER = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_C_VERY_SHARP_CUR_RADIUS_ENTER_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_VERY_SHARP_CUR_RADIUS_EXIT_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITCVERYSHARPCURRADIUSEXITV * pC_VERY_SHARP_CUR_RADIUS_EXIT_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_VERY_SHARP_CUR_RADIUS_EXIT_V
*    C_VERY_SHARP_CUR_RADIUS_EXIT_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_VERY_SHARP_CUR_RADIUS_EXIT_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_VERY_SHARP_CUR_RADIUS_EXIT_V( CORELIGHTSCENEINITCVERYSHARPCURRADIUSEXITV * pC_VERY_SHARP_CUR_RADIUS_EXIT_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITCVERYSHARPCURRADIUSEXITV signal_value;
   
   if( pC_VERY_SHARP_CUR_RADIUS_EXIT_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_VERY_SHARP_CUR_RADIUS_EXIT_V_b1;
      * pC_VERY_SHARP_CUR_RADIUS_EXIT_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_VERY_SHARP_CUR_RADIUS_EXIT
*
* FUNCTION ARGUMENTS:
*    uint16 * pC_VERY_SHARP_CUR_RADIUS_EXIT - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_VERY_SHARP_CUR_RADIUS_EXIT
*    C_VERY_SHARP_CUR_RADIUS_EXIT returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_VERY_SHARP_CUR_RADIUS_EXIT signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_VERY_SHARP_CUR_RADIUS_EXIT( uint16 * pC_VERY_SHARP_CUR_RADIUS_EXIT )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pC_VERY_SHARP_CUR_RADIUS_EXIT != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_VERY_SHARP_CUR_RADIUS_EXIT_b11;
      * pC_VERY_SHARP_CUR_RADIUS_EXIT = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_C_VERY_SHARP_CUR_RADIUS_EXIT_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_LOW_BEAM_ON_JUNCTION_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITCLOWBEAMONJUNCTIONV * pC_LOW_BEAM_ON_JUNCTION_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_LOW_BEAM_ON_JUNCTION_V
*    C_LOW_BEAM_ON_JUNCTION_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_LOW_BEAM_ON_JUNCTION_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_LOW_BEAM_ON_JUNCTION_V( CORELIGHTSCENEINITCLOWBEAMONJUNCTIONV * pC_LOW_BEAM_ON_JUNCTION_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITCLOWBEAMONJUNCTIONV signal_value;
   
   if( pC_LOW_BEAM_ON_JUNCTION_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_LOW_BEAM_ON_JUNCTION_V_b1;
      * pC_LOW_BEAM_ON_JUNCTION_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_LOW_BEAM_ON_JUNCTION
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITCLOWBEAMONJUNCTION * pC_LOW_BEAM_ON_JUNCTION - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_LOW_BEAM_ON_JUNCTION
*    C_LOW_BEAM_ON_JUNCTION returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_LOW_BEAM_ON_JUNCTION signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_LOW_BEAM_ON_JUNCTION( CORELIGHTSCENEINITCLOWBEAMONJUNCTION * pC_LOW_BEAM_ON_JUNCTION )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITCLOWBEAMONJUNCTION signal_value;
   
   if( pC_LOW_BEAM_ON_JUNCTION != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_LOW_BEAM_ON_JUNCTION_b1;
      * pC_LOW_BEAM_ON_JUNCTION = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_3_V
*
* FUNCTION ARGUMENTS:
*    boolean * pILS_Buffer_3_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_3_V
*    ILS_Buffer_3_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_3_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_3_V( boolean * pILS_Buffer_3_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pILS_Buffer_3_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_3_V_b1;
      * pILS_Buffer_3_V = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_3_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_3
*
* FUNCTION ARGUMENTS:
*    uint8 * pILS_Buffer_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_3
*    ILS_Buffer_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_3 signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_3( uint8 * pILS_Buffer_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pILS_Buffer_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_3_b5;
      * pILS_Buffer_3 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_OC_CURVE_TIME_DELAY_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITCOCCURVETIMEDELAYV * pC_OC_CURVE_TIME_DELAY_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_OC_CURVE_TIME_DELAY_V
*    C_OC_CURVE_TIME_DELAY_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_OC_CURVE_TIME_DELAY_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_OC_CURVE_TIME_DELAY_V( CORELIGHTSCENEINITCOCCURVETIMEDELAYV * pC_OC_CURVE_TIME_DELAY_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITCOCCURVETIMEDELAYV signal_value;
   
   if( pC_OC_CURVE_TIME_DELAY_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_OC_CURVE_TIME_DELAY_V_b1;
      * pC_OC_CURVE_TIME_DELAY_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_OC_CURVE_TIME_DELAY
*
* FUNCTION ARGUMENTS:
*    uint16 * pC_OC_CURVE_TIME_DELAY - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_OC_CURVE_TIME_DELAY
*    C_OC_CURVE_TIME_DELAY returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_OC_CURVE_TIME_DELAY signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_OC_CURVE_TIME_DELAY( uint16 * pC_OC_CURVE_TIME_DELAY )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pC_OC_CURVE_TIME_DELAY != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_OC_CURVE_TIME_DELAY_b13;
      * pC_OC_CURVE_TIME_DELAY = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_C_OC_CURVE_TIME_DELAY_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_OC_MAX_DELAY_CURVE_UP_AHEAD_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITCOCMAXDELAYCURVEUPAHEADV * pC_OC_MAX_DELAY_CURVE_UP_AHEAD_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_OC_MAX_DELAY_CURVE_UP_AHEAD_V
*    C_OC_MAX_DELAY_CURVE_UP_AHEAD_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_OC_MAX_DELAY_CURVE_UP_AHEAD_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_OC_MAX_DELAY_CURVE_UP_AHEAD_V( CORELIGHTSCENEINITCOCMAXDELAYCURVEUPAHEADV * pC_OC_MAX_DELAY_CURVE_UP_AHEAD_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITCOCMAXDELAYCURVEUPAHEADV signal_value;
   
   if( pC_OC_MAX_DELAY_CURVE_UP_AHEAD_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_OC_MAX_DELAY_CURVE_UP_AHEAD_V_b1;
      * pC_OC_MAX_DELAY_CURVE_UP_AHEAD_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_OC_MAX_DELAY_CURVE_UP_AHEAD
*
* FUNCTION ARGUMENTS:
*    uint16 * pC_OC_MAX_DELAY_CURVE_UP_AHEAD - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_OC_MAX_DELAY_CURVE_UP_AHEAD
*    C_OC_MAX_DELAY_CURVE_UP_AHEAD returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_OC_MAX_DELAY_CURVE_UP_AHEAD signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_OC_MAX_DELAY_CURVE_UP_AHEAD( uint16 * pC_OC_MAX_DELAY_CURVE_UP_AHEAD )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pC_OC_MAX_DELAY_CURVE_UP_AHEAD != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_OC_MAX_DELAY_CURVE_UP_AHEAD_b13;
      * pC_OC_MAX_DELAY_CURVE_UP_AHEAD = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_C_OC_MAX_DELAY_CURVE_UP_AHEAD_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_4_V
*
* FUNCTION ARGUMENTS:
*    boolean * pILS_Buffer_4_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_4_V
*    ILS_Buffer_4_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_4_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_4_V( boolean * pILS_Buffer_4_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pILS_Buffer_4_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_4_V_b1;
      * pILS_Buffer_4_V = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_4_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_4
*
* FUNCTION ARGUMENTS:
*    uint8 * pILS_Buffer_4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_4
*    ILS_Buffer_4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_4 signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_4( uint8 * pILS_Buffer_4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pILS_Buffer_4 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_4_b3;
      * pILS_Buffer_4 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_4_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_OC_MID_DISAP_TIME_DELAY_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITCOCMIDDISAPTIMEDELAYV * pC_OC_MID_DISAP_TIME_DELAY_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_OC_MID_DISAP_TIME_DELAY_V
*    C_OC_MID_DISAP_TIME_DELAY_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_OC_MID_DISAP_TIME_DELAY_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_OC_MID_DISAP_TIME_DELAY_V( CORELIGHTSCENEINITCOCMIDDISAPTIMEDELAYV * pC_OC_MID_DISAP_TIME_DELAY_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITCOCMIDDISAPTIMEDELAYV signal_value;
   
   if( pC_OC_MID_DISAP_TIME_DELAY_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_OC_MID_DISAP_TIME_DELAY_V_b1;
      * pC_OC_MID_DISAP_TIME_DELAY_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_OC_MID_DISAP_TIME_DELAY
*
* FUNCTION ARGUMENTS:
*    uint16 * pC_OC_MID_DISAP_TIME_DELAY - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_OC_MID_DISAP_TIME_DELAY
*    C_OC_MID_DISAP_TIME_DELAY returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_OC_MID_DISAP_TIME_DELAY signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_OC_MID_DISAP_TIME_DELAY( uint16 * pC_OC_MID_DISAP_TIME_DELAY )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pC_OC_MID_DISAP_TIME_DELAY != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_OC_MID_DISAP_TIME_DELAY_b13;
      * pC_OC_MID_DISAP_TIME_DELAY = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_C_OC_MID_DISAP_TIME_DELAY_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_OC_MID_DISAP_TIME_DELAY_HW_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITCOCMIDDISAPTIMEDELAYHWV * pC_OC_MID_DISAP_TIME_DELAY_HW_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_OC_MID_DISAP_TIME_DELAY_HW_V
*    C_OC_MID_DISAP_TIME_DELAY_HW_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_OC_MID_DISAP_TIME_DELAY_HW_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_OC_MID_DISAP_TIME_DELAY_HW_V( CORELIGHTSCENEINITCOCMIDDISAPTIMEDELAYHWV * pC_OC_MID_DISAP_TIME_DELAY_HW_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITCOCMIDDISAPTIMEDELAYHWV signal_value;
   
   if( pC_OC_MID_DISAP_TIME_DELAY_HW_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_OC_MID_DISAP_TIME_DELAY_HW_V_b1;
      * pC_OC_MID_DISAP_TIME_DELAY_HW_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_OC_MID_DISAP_TIME_DELAY_HW
*
* FUNCTION ARGUMENTS:
*    uint16 * pC_OC_MID_DISAP_TIME_DELAY_HW - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_OC_MID_DISAP_TIME_DELAY_HW
*    C_OC_MID_DISAP_TIME_DELAY_HW returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_OC_MID_DISAP_TIME_DELAY_HW signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_OC_MID_DISAP_TIME_DELAY_HW( uint16 * pC_OC_MID_DISAP_TIME_DELAY_HW )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pC_OC_MID_DISAP_TIME_DELAY_HW != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_OC_MID_DISAP_TIME_DELAY_HW_b13;
      * pC_OC_MID_DISAP_TIME_DELAY_HW = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_C_OC_MID_DISAP_TIME_DELAY_HW_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_5_V
*
* FUNCTION ARGUMENTS:
*    boolean * pILS_Buffer_5_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_5_V
*    ILS_Buffer_5_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_5_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_5_V( boolean * pILS_Buffer_5_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pILS_Buffer_5_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_5_V_b1;
      * pILS_Buffer_5_V = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_5_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_5
*
* FUNCTION ARGUMENTS:
*    uint8 * pILS_Buffer_5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_5
*    ILS_Buffer_5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_5 signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_5( uint8 * pILS_Buffer_5 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pILS_Buffer_5 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_5_b3;
      * pILS_Buffer_5 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_5_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_OC_NORMAL_TIME_DELAY_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITCOCNORMALTIMEDELAYV * pC_OC_NORMAL_TIME_DELAY_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_OC_NORMAL_TIME_DELAY_V
*    C_OC_NORMAL_TIME_DELAY_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_OC_NORMAL_TIME_DELAY_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_OC_NORMAL_TIME_DELAY_V( CORELIGHTSCENEINITCOCNORMALTIMEDELAYV * pC_OC_NORMAL_TIME_DELAY_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITCOCNORMALTIMEDELAYV signal_value;
   
   if( pC_OC_NORMAL_TIME_DELAY_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_OC_NORMAL_TIME_DELAY_V_b1;
      * pC_OC_NORMAL_TIME_DELAY_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_OC_NORMAL_TIME_DELAY
*
* FUNCTION ARGUMENTS:
*    uint16 * pC_OC_NORMAL_TIME_DELAY - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_OC_NORMAL_TIME_DELAY
*    C_OC_NORMAL_TIME_DELAY returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_OC_NORMAL_TIME_DELAY signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_OC_NORMAL_TIME_DELAY( uint16 * pC_OC_NORMAL_TIME_DELAY )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pC_OC_NORMAL_TIME_DELAY != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_OC_NORMAL_TIME_DELAY_b13;
      * pC_OC_NORMAL_TIME_DELAY = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_C_OC_NORMAL_TIME_DELAY_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_OC_NORMAL_TIME_DELAY_HW_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITCOCNORMALTIMEDELAYHWV * pC_OC_NORMAL_TIME_DELAY_HW_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_OC_NORMAL_TIME_DELAY_HW_V
*    C_OC_NORMAL_TIME_DELAY_HW_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_OC_NORMAL_TIME_DELAY_HW_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_OC_NORMAL_TIME_DELAY_HW_V( CORELIGHTSCENEINITCOCNORMALTIMEDELAYHWV * pC_OC_NORMAL_TIME_DELAY_HW_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITCOCNORMALTIMEDELAYHWV signal_value;
   
   if( pC_OC_NORMAL_TIME_DELAY_HW_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_OC_NORMAL_TIME_DELAY_HW_V_b1;
      * pC_OC_NORMAL_TIME_DELAY_HW_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_OC_NORMAL_TIME_DELAY_HW
*
* FUNCTION ARGUMENTS:
*    uint16 * pC_OC_NORMAL_TIME_DELAY_HW - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_OC_NORMAL_TIME_DELAY_HW
*    C_OC_NORMAL_TIME_DELAY_HW returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_OC_NORMAL_TIME_DELAY_HW signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_OC_NORMAL_TIME_DELAY_HW( uint16 * pC_OC_NORMAL_TIME_DELAY_HW )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pC_OC_NORMAL_TIME_DELAY_HW != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_OC_NORMAL_TIME_DELAY_HW_b13;
      * pC_OC_NORMAL_TIME_DELAY_HW = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_C_OC_NORMAL_TIME_DELAY_HW_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_6_V
*
* FUNCTION ARGUMENTS:
*    boolean * pILS_Buffer_6_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_6_V
*    ILS_Buffer_6_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_6_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_6_V( boolean * pILS_Buffer_6_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pILS_Buffer_6_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_6_V_b1;
      * pILS_Buffer_6_V = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_6_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_6
*
* FUNCTION ARGUMENTS:
*    uint8 * pILS_Buffer_6 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_6
*    ILS_Buffer_6 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_6 signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_6( uint8 * pILS_Buffer_6 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pILS_Buffer_6 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_6_b3;
      * pILS_Buffer_6 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_6_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_OC_STRONG_SUSP_TIME_DELAY_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITCOCSTRONGSUSPTIMEDELAYV * pC_OC_STRONG_SUSP_TIME_DELAY_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_OC_STRONG_SUSP_TIME_DELAY_V
*    C_OC_STRONG_SUSP_TIME_DELAY_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_OC_STRONG_SUSP_TIME_DELAY_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_OC_STRONG_SUSP_TIME_DELAY_V( CORELIGHTSCENEINITCOCSTRONGSUSPTIMEDELAYV * pC_OC_STRONG_SUSP_TIME_DELAY_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITCOCSTRONGSUSPTIMEDELAYV signal_value;
   
   if( pC_OC_STRONG_SUSP_TIME_DELAY_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_OC_STRONG_SUSP_TIME_DELAY_V_b1;
      * pC_OC_STRONG_SUSP_TIME_DELAY_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_OC_STRONG_SUSP_TIME_DELAY
*
* FUNCTION ARGUMENTS:
*    uint16 * pC_OC_STRONG_SUSP_TIME_DELAY - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_OC_STRONG_SUSP_TIME_DELAY
*    C_OC_STRONG_SUSP_TIME_DELAY returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_OC_STRONG_SUSP_TIME_DELAY signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_OC_STRONG_SUSP_TIME_DELAY( uint16 * pC_OC_STRONG_SUSP_TIME_DELAY )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pC_OC_STRONG_SUSP_TIME_DELAY != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_OC_STRONG_SUSP_TIME_DELAY_b13;
      * pC_OC_STRONG_SUSP_TIME_DELAY = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_C_OC_STRONG_SUSP_TIME_DELAY_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_OC_SUSPECT_TIME_DELAY_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITCOCSUSPECTTIMEDELAYV * pC_OC_SUSPECT_TIME_DELAY_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_OC_SUSPECT_TIME_DELAY_V
*    C_OC_SUSPECT_TIME_DELAY_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_OC_SUSPECT_TIME_DELAY_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_OC_SUSPECT_TIME_DELAY_V( CORELIGHTSCENEINITCOCSUSPECTTIMEDELAYV * pC_OC_SUSPECT_TIME_DELAY_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITCOCSUSPECTTIMEDELAYV signal_value;
   
   if( pC_OC_SUSPECT_TIME_DELAY_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_OC_SUSPECT_TIME_DELAY_V_b1;
      * pC_OC_SUSPECT_TIME_DELAY_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_OC_SUSPECT_TIME_DELAY
*
* FUNCTION ARGUMENTS:
*    uint16 * pC_OC_SUSPECT_TIME_DELAY - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_OC_SUSPECT_TIME_DELAY
*    C_OC_SUSPECT_TIME_DELAY returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_OC_SUSPECT_TIME_DELAY signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_OC_SUSPECT_TIME_DELAY( uint16 * pC_OC_SUSPECT_TIME_DELAY )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pC_OC_SUSPECT_TIME_DELAY != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_OC_SUSPECT_TIME_DELAY_b13;
      * pC_OC_SUSPECT_TIME_DELAY = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_C_OC_SUSPECT_TIME_DELAY_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_ENABLE_O_Take_CALC_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITCTLENABLEOTakeCALCV * pC_TL_ENABLE_O_Take_CALC_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_TL_ENABLE_O_Take_CALC_V
*    C_TL_ENABLE_O_Take_CALC_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_TL_ENABLE_O_Take_CALC_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_ENABLE_O_Take_CALC_V( CORELIGHTSCENEINITCTLENABLEOTakeCALCV * pC_TL_ENABLE_O_Take_CALC_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITCTLENABLEOTakeCALCV signal_value;
   
   if( pC_TL_ENABLE_O_Take_CALC_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_TL_ENABLE_O_Take_CALC_V_b1;
      * pC_TL_ENABLE_O_Take_CALC_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_ENABLE_O_Take_CALC
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITCTLENABLEOTakeCALC * pC_TL_ENABLE_O_Take_CALC - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_TL_ENABLE_O_Take_CALC
*    C_TL_ENABLE_O_Take_CALC returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_TL_ENABLE_O_Take_CALC signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_ENABLE_O_Take_CALC( CORELIGHTSCENEINITCTLENABLEOTakeCALC * pC_TL_ENABLE_O_Take_CALC )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITCTLENABLEOTakeCALC signal_value;
   
   if( pC_TL_ENABLE_O_Take_CALC != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_TL_ENABLE_O_Take_CALC_b1;
      * pC_TL_ENABLE_O_Take_CALC = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_7_V
*
* FUNCTION ARGUMENTS:
*    boolean * pILS_Buffer_7_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_7_V
*    ILS_Buffer_7_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_7_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_7_V( boolean * pILS_Buffer_7_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pILS_Buffer_7_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_7_V_b1;
      * pILS_Buffer_7_V = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_7_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_7
*
* FUNCTION ARGUMENTS:
*    boolean * pILS_Buffer_7 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_7
*    ILS_Buffer_7 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_7 signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_7( boolean * pILS_Buffer_7 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pILS_Buffer_7 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_7_b1;
      * pILS_Buffer_7 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_7_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_LAST_SEEN_SUSPECT_DELAY_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITCTLLASTSEENSUSPECTDELAYV * pC_TL_LAST_SEEN_SUSPECT_DELAY_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_TL_LAST_SEEN_SUSPECT_DELAY_V
*    C_TL_LAST_SEEN_SUSPECT_DELAY_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_TL_LAST_SEEN_SUSPECT_DELAY_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_LAST_SEEN_SUSPECT_DELAY_V( CORELIGHTSCENEINITCTLLASTSEENSUSPECTDELAYV * pC_TL_LAST_SEEN_SUSPECT_DELAY_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITCTLLASTSEENSUSPECTDELAYV signal_value;
   
   if( pC_TL_LAST_SEEN_SUSPECT_DELAY_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_TL_LAST_SEEN_SUSPECT_DELAY_V_b1;
      * pC_TL_LAST_SEEN_SUSPECT_DELAY_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_LAST_SEEN_SUSPECT_DELAY
*
* FUNCTION ARGUMENTS:
*    uint16 * pC_TL_LAST_SEEN_SUSPECT_DELAY - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_TL_LAST_SEEN_SUSPECT_DELAY
*    C_TL_LAST_SEEN_SUSPECT_DELAY returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_TL_LAST_SEEN_SUSPECT_DELAY signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_LAST_SEEN_SUSPECT_DELAY( uint16 * pC_TL_LAST_SEEN_SUSPECT_DELAY )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pC_TL_LAST_SEEN_SUSPECT_DELAY != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_TL_LAST_SEEN_SUSPECT_DELAY_b13;
      * pC_TL_LAST_SEEN_SUSPECT_DELAY = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_C_TL_LAST_SEEN_SUSPECT_DELAY_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_MAX_DELAY_CURVE_UP_AHEAD_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITCTLMAXDELAYCURVEUPAHEADV * pC_TL_MAX_DELAY_CURVE_UP_AHEAD_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_TL_MAX_DELAY_CURVE_UP_AHEAD_V
*    C_TL_MAX_DELAY_CURVE_UP_AHEAD_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_TL_MAX_DELAY_CURVE_UP_AHEAD_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_MAX_DELAY_CURVE_UP_AHEAD_V( CORELIGHTSCENEINITCTLMAXDELAYCURVEUPAHEADV * pC_TL_MAX_DELAY_CURVE_UP_AHEAD_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITCTLMAXDELAYCURVEUPAHEADV signal_value;
   
   if( pC_TL_MAX_DELAY_CURVE_UP_AHEAD_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_TL_MAX_DELAY_CURVE_UP_AHEAD_V_b1;
      * pC_TL_MAX_DELAY_CURVE_UP_AHEAD_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_MAX_DELAY_CURVE_UP_AHEAD
*
* FUNCTION ARGUMENTS:
*    uint16 * pC_TL_MAX_DELAY_CURVE_UP_AHEAD - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_TL_MAX_DELAY_CURVE_UP_AHEAD
*    C_TL_MAX_DELAY_CURVE_UP_AHEAD returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_TL_MAX_DELAY_CURVE_UP_AHEAD signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_MAX_DELAY_CURVE_UP_AHEAD( uint16 * pC_TL_MAX_DELAY_CURVE_UP_AHEAD )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pC_TL_MAX_DELAY_CURVE_UP_AHEAD != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_TL_MAX_DELAY_CURVE_UP_AHEAD_b13;
      * pC_TL_MAX_DELAY_CURVE_UP_AHEAD = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_C_TL_MAX_DELAY_CURVE_UP_AHEAD_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_8_V
*
* FUNCTION ARGUMENTS:
*    boolean * pILS_Buffer_8_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_8_V
*    ILS_Buffer_8_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_8_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_8_V( boolean * pILS_Buffer_8_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pILS_Buffer_8_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_8_V_b1;
      * pILS_Buffer_8_V = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_8_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_8
*
* FUNCTION ARGUMENTS:
*    uint8 * pILS_Buffer_8 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_8
*    ILS_Buffer_8 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_8 signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_8( uint8 * pILS_Buffer_8 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pILS_Buffer_8 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_8_b3;
      * pILS_Buffer_8 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_8_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_MID_DISAP_TIME_DELAY_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITCTLMIDDISAPTIMEDELAYV * pC_TL_MID_DISAP_TIME_DELAY_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_TL_MID_DISAP_TIME_DELAY_V
*    C_TL_MID_DISAP_TIME_DELAY_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_TL_MID_DISAP_TIME_DELAY_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_MID_DISAP_TIME_DELAY_V( CORELIGHTSCENEINITCTLMIDDISAPTIMEDELAYV * pC_TL_MID_DISAP_TIME_DELAY_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITCTLMIDDISAPTIMEDELAYV signal_value;
   
   if( pC_TL_MID_DISAP_TIME_DELAY_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_TL_MID_DISAP_TIME_DELAY_V_b1;
      * pC_TL_MID_DISAP_TIME_DELAY_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_MID_DISAP_TIME_DELAY
*
* FUNCTION ARGUMENTS:
*    uint16 * pC_TL_MID_DISAP_TIME_DELAY - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_TL_MID_DISAP_TIME_DELAY
*    C_TL_MID_DISAP_TIME_DELAY returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_TL_MID_DISAP_TIME_DELAY signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_MID_DISAP_TIME_DELAY( uint16 * pC_TL_MID_DISAP_TIME_DELAY )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pC_TL_MID_DISAP_TIME_DELAY != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_TL_MID_DISAP_TIME_DELAY_b13;
      * pC_TL_MID_DISAP_TIME_DELAY = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_C_TL_MID_DISAP_TIME_DELAY_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_MID_DISAP_TIME_DELAY_HW_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITCTLMIDDISAPTIMEDELAYHWV * pC_TL_MID_DISAP_TIME_DELAY_HW_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_TL_MID_DISAP_TIME_DELAY_HW_V
*    C_TL_MID_DISAP_TIME_DELAY_HW_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_TL_MID_DISAP_TIME_DELAY_HW_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_MID_DISAP_TIME_DELAY_HW_V( CORELIGHTSCENEINITCTLMIDDISAPTIMEDELAYHWV * pC_TL_MID_DISAP_TIME_DELAY_HW_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITCTLMIDDISAPTIMEDELAYHWV signal_value;
   
   if( pC_TL_MID_DISAP_TIME_DELAY_HW_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_TL_MID_DISAP_TIME_DELAY_HW_V_b1;
      * pC_TL_MID_DISAP_TIME_DELAY_HW_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_MID_DISAP_TIME_DELAY_HW
*
* FUNCTION ARGUMENTS:
*    uint16 * pC_TL_MID_DISAP_TIME_DELAY_HW - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_TL_MID_DISAP_TIME_DELAY_HW
*    C_TL_MID_DISAP_TIME_DELAY_HW returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_TL_MID_DISAP_TIME_DELAY_HW signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_MID_DISAP_TIME_DELAY_HW( uint16 * pC_TL_MID_DISAP_TIME_DELAY_HW )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pC_TL_MID_DISAP_TIME_DELAY_HW != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_TL_MID_DISAP_TIME_DELAY_HW_b13;
      * pC_TL_MID_DISAP_TIME_DELAY_HW = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_C_TL_MID_DISAP_TIME_DELAY_HW_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_9_V
*
* FUNCTION ARGUMENTS:
*    boolean * pILS_Buffer_9_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_9_V
*    ILS_Buffer_9_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_9_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_9_V( boolean * pILS_Buffer_9_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pILS_Buffer_9_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_9_V_b1;
      * pILS_Buffer_9_V = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_9_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_9
*
* FUNCTION ARGUMENTS:
*    uint8 * pILS_Buffer_9 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_9
*    ILS_Buffer_9 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_9 signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_9( uint8 * pILS_Buffer_9 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pILS_Buffer_9 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_9_b3;
      * pILS_Buffer_9 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_9_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_NORMAL_TIME_DELAY_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITCTLNORMALTIMEDELAYV * pC_TL_NORMAL_TIME_DELAY_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_TL_NORMAL_TIME_DELAY_V
*    C_TL_NORMAL_TIME_DELAY_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_TL_NORMAL_TIME_DELAY_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_NORMAL_TIME_DELAY_V( CORELIGHTSCENEINITCTLNORMALTIMEDELAYV * pC_TL_NORMAL_TIME_DELAY_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITCTLNORMALTIMEDELAYV signal_value;
   
   if( pC_TL_NORMAL_TIME_DELAY_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_TL_NORMAL_TIME_DELAY_V_b1;
      * pC_TL_NORMAL_TIME_DELAY_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_NORMAL_TIME_DELAY
*
* FUNCTION ARGUMENTS:
*    uint16 * pC_TL_NORMAL_TIME_DELAY - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_TL_NORMAL_TIME_DELAY
*    C_TL_NORMAL_TIME_DELAY returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_TL_NORMAL_TIME_DELAY signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_NORMAL_TIME_DELAY( uint16 * pC_TL_NORMAL_TIME_DELAY )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pC_TL_NORMAL_TIME_DELAY != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_TL_NORMAL_TIME_DELAY_b13;
      * pC_TL_NORMAL_TIME_DELAY = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_C_TL_NORMAL_TIME_DELAY_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_NORMAL_TIME_DELAY_HW_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITCTLNORMALTIMEDELAYHWV * pC_TL_NORMAL_TIME_DELAY_HW_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_TL_NORMAL_TIME_DELAY_HW_V
*    C_TL_NORMAL_TIME_DELAY_HW_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_TL_NORMAL_TIME_DELAY_HW_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_NORMAL_TIME_DELAY_HW_V( CORELIGHTSCENEINITCTLNORMALTIMEDELAYHWV * pC_TL_NORMAL_TIME_DELAY_HW_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITCTLNORMALTIMEDELAYHWV signal_value;
   
   if( pC_TL_NORMAL_TIME_DELAY_HW_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_TL_NORMAL_TIME_DELAY_HW_V_b1;
      * pC_TL_NORMAL_TIME_DELAY_HW_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_NORMAL_TIME_DELAY_HW
*
* FUNCTION ARGUMENTS:
*    uint16 * pC_TL_NORMAL_TIME_DELAY_HW - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_TL_NORMAL_TIME_DELAY_HW
*    C_TL_NORMAL_TIME_DELAY_HW returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_TL_NORMAL_TIME_DELAY_HW signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_NORMAL_TIME_DELAY_HW( uint16 * pC_TL_NORMAL_TIME_DELAY_HW )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pC_TL_NORMAL_TIME_DELAY_HW != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_TL_NORMAL_TIME_DELAY_HW_b13;
      * pC_TL_NORMAL_TIME_DELAY_HW = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_C_TL_NORMAL_TIME_DELAY_HW_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_10_V
*
* FUNCTION ARGUMENTS:
*    boolean * pILS_Buffer_10_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_10_V
*    ILS_Buffer_10_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_10_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_10_V( boolean * pILS_Buffer_10_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pILS_Buffer_10_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_10_V_b1;
      * pILS_Buffer_10_V = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_10_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_10
*
* FUNCTION ARGUMENTS:
*    uint8 * pILS_Buffer_10 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_10
*    ILS_Buffer_10 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_10 signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_10( uint8 * pILS_Buffer_10 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pILS_Buffer_10 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_10_b3;
      * pILS_Buffer_10 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_10_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_OC_STRONG_SUSP_TIME_DELAY_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITCTLOCSTRONGSUSPTIMEDELAYV * pC_TL_OC_STRONG_SUSP_TIME_DELAY_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_TL_OC_STRONG_SUSP_TIME_DELAY_V
*    C_TL_OC_STRONG_SUSP_TIME_DELAY_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_TL_OC_STRONG_SUSP_TIME_DELAY_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_OC_STRONG_SUSP_TIME_DELAY_V( CORELIGHTSCENEINITCTLOCSTRONGSUSPTIMEDELAYV * pC_TL_OC_STRONG_SUSP_TIME_DELAY_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITCTLOCSTRONGSUSPTIMEDELAYV signal_value;
   
   if( pC_TL_OC_STRONG_SUSP_TIME_DELAY_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_TL_OC_STRONG_SUSP_TIME_DELAY_V_b1;
      * pC_TL_OC_STRONG_SUSP_TIME_DELAY_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_OC_STRONG_SUSP_TIME_DELAY
*
* FUNCTION ARGUMENTS:
*    uint16 * pC_TL_OC_STRONG_SUSP_TIME_DELAY - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_TL_OC_STRONG_SUSP_TIME_DELAY
*    C_TL_OC_STRONG_SUSP_TIME_DELAY returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_TL_OC_STRONG_SUSP_TIME_DELAY signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_OC_STRONG_SUSP_TIME_DELAY( uint16 * pC_TL_OC_STRONG_SUSP_TIME_DELAY )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pC_TL_OC_STRONG_SUSP_TIME_DELAY != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_TL_OC_STRONG_SUSP_TIME_DELAY_b13;
      * pC_TL_OC_STRONG_SUSP_TIME_DELAY = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_C_TL_OC_STRONG_SUSP_TIME_DELAY_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_OC_SUSPECT_TIME_DELAY_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITCTLOCSUSPECTTIMEDELAYV * pC_TL_OC_SUSPECT_TIME_DELAY_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_TL_OC_SUSPECT_TIME_DELAY_V
*    C_TL_OC_SUSPECT_TIME_DELAY_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_TL_OC_SUSPECT_TIME_DELAY_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_OC_SUSPECT_TIME_DELAY_V( CORELIGHTSCENEINITCTLOCSUSPECTTIMEDELAYV * pC_TL_OC_SUSPECT_TIME_DELAY_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITCTLOCSUSPECTTIMEDELAYV signal_value;
   
   if( pC_TL_OC_SUSPECT_TIME_DELAY_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_TL_OC_SUSPECT_TIME_DELAY_V_b1;
      * pC_TL_OC_SUSPECT_TIME_DELAY_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_OC_SUSPECT_TIME_DELAY
*
* FUNCTION ARGUMENTS:
*    uint16 * pC_TL_OC_SUSPECT_TIME_DELAY - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_TL_OC_SUSPECT_TIME_DELAY
*    C_TL_OC_SUSPECT_TIME_DELAY returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_TL_OC_SUSPECT_TIME_DELAY signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_OC_SUSPECT_TIME_DELAY( uint16 * pC_TL_OC_SUSPECT_TIME_DELAY )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pC_TL_OC_SUSPECT_TIME_DELAY != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_TL_OC_SUSPECT_TIME_DELAY_b13;
      * pC_TL_OC_SUSPECT_TIME_DELAY = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_C_TL_OC_SUSPECT_TIME_DELAY_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_11_V
*
* FUNCTION ARGUMENTS:
*    boolean * pILS_Buffer_11_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_11_V
*    ILS_Buffer_11_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_11_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_11_V( boolean * pILS_Buffer_11_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pILS_Buffer_11_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_11_V_b1;
      * pILS_Buffer_11_V = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_11_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_11
*
* FUNCTION ARGUMENTS:
*    uint8 * pILS_Buffer_11 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_11
*    ILS_Buffer_11 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_11 signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_11( uint8 * pILS_Buffer_11 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pILS_Buffer_11 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_11_b3;
      * pILS_Buffer_11 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_11_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_O_TAKE_H_BEAM_SIDE_ANGLE_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITCTLOTAKEHBEAMSIDEANGLEV * pC_TL_O_TAKE_H_BEAM_SIDE_ANGLE_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_TL_O_TAKE_H_BEAM_SIDE_ANGLE_V
*    C_TL_O_TAKE_H_BEAM_SIDE_ANGLE_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_TL_O_TAKE_H_BEAM_SIDE_ANGLE_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_O_TAKE_H_BEAM_SIDE_ANGLE_V( CORELIGHTSCENEINITCTLOTAKEHBEAMSIDEANGLEV * pC_TL_O_TAKE_H_BEAM_SIDE_ANGLE_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITCTLOTAKEHBEAMSIDEANGLEV signal_value;
   
   if( pC_TL_O_TAKE_H_BEAM_SIDE_ANGLE_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_TL_O_TAKE_H_BEAM_SIDE_ANGLE_V_b1;
      * pC_TL_O_TAKE_H_BEAM_SIDE_ANGLE_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_O_TAKE_H_BEAM_SIDE_ANGLE
*
* FUNCTION ARGUMENTS:
*    uint16 * pC_TL_O_TAKE_H_BEAM_SIDE_ANGLE - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_TL_O_TAKE_H_BEAM_SIDE_ANGLE
*    C_TL_O_TAKE_H_BEAM_SIDE_ANGLE returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_TL_O_TAKE_H_BEAM_SIDE_ANGLE signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_O_TAKE_H_BEAM_SIDE_ANGLE( uint16 * pC_TL_O_TAKE_H_BEAM_SIDE_ANGLE )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pC_TL_O_TAKE_H_BEAM_SIDE_ANGLE != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_TL_O_TAKE_H_BEAM_SIDE_ANGLE_b10;
      * pC_TL_O_TAKE_H_BEAM_SIDE_ANGLE = signal_value;
      if( (signal_value >= C_EYEQMSG_CORELIGHTSCENEINIT_C_TL_O_TAKE_H_BEAM_SIDE_ANGLE_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_C_TL_O_TAKE_H_BEAM_SIDE_ANGLE_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_O_Take_MAX_TIME_DELAY_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITCTLOTakeMAXTIMEDELAYV * pC_TL_O_Take_MAX_TIME_DELAY_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_TL_O_Take_MAX_TIME_DELAY_V
*    C_TL_O_Take_MAX_TIME_DELAY_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_TL_O_Take_MAX_TIME_DELAY_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_O_Take_MAX_TIME_DELAY_V( CORELIGHTSCENEINITCTLOTakeMAXTIMEDELAYV * pC_TL_O_Take_MAX_TIME_DELAY_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITCTLOTakeMAXTIMEDELAYV signal_value;
   
   if( pC_TL_O_Take_MAX_TIME_DELAY_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_TL_O_Take_MAX_TIME_DELAY_V_b1;
      * pC_TL_O_Take_MAX_TIME_DELAY_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_O_Take_MAX_TIME_DELAY
*
* FUNCTION ARGUMENTS:
*    uint16 * pC_TL_O_Take_MAX_TIME_DELAY - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_TL_O_Take_MAX_TIME_DELAY
*    C_TL_O_Take_MAX_TIME_DELAY returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_TL_O_Take_MAX_TIME_DELAY signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_O_Take_MAX_TIME_DELAY( uint16 * pC_TL_O_Take_MAX_TIME_DELAY )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pC_TL_O_Take_MAX_TIME_DELAY != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_TL_O_Take_MAX_TIME_DELAY_b14;
      * pC_TL_O_Take_MAX_TIME_DELAY = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_C_TL_O_TAKE_MAX_TIME_DELAY_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_12_V
*
* FUNCTION ARGUMENTS:
*    boolean * pILS_Buffer_12_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_12_V
*    ILS_Buffer_12_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_12_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_12_V( boolean * pILS_Buffer_12_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pILS_Buffer_12_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_12_V_b1;
      * pILS_Buffer_12_V = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_12_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_12
*
* FUNCTION ARGUMENTS:
*    uint8 * pILS_Buffer_12 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_12
*    ILS_Buffer_12 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_12 signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_12( uint8 * pILS_Buffer_12 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pILS_Buffer_12 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_12_b5;
      * pILS_Buffer_12 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_12_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_O_Take_TRUCK_LENGTH_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITCTLOTakeTRUCKLENGTHV * pC_TL_O_Take_TRUCK_LENGTH_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_TL_O_Take_TRUCK_LENGTH_V
*    C_TL_O_Take_TRUCK_LENGTH_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_TL_O_Take_TRUCK_LENGTH_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_O_Take_TRUCK_LENGTH_V( CORELIGHTSCENEINITCTLOTakeTRUCKLENGTHV * pC_TL_O_Take_TRUCK_LENGTH_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITCTLOTakeTRUCKLENGTHV signal_value;
   
   if( pC_TL_O_Take_TRUCK_LENGTH_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_TL_O_Take_TRUCK_LENGTH_V_b1;
      * pC_TL_O_Take_TRUCK_LENGTH_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_O_Take_TRUCK_LENGTH
*
* FUNCTION ARGUMENTS:
*    uint16 * pC_TL_O_Take_TRUCK_LENGTH - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_TL_O_Take_TRUCK_LENGTH
*    C_TL_O_Take_TRUCK_LENGTH returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_TL_O_Take_TRUCK_LENGTH signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_O_Take_TRUCK_LENGTH( uint16 * pC_TL_O_Take_TRUCK_LENGTH )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pC_TL_O_Take_TRUCK_LENGTH != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_TL_O_Take_TRUCK_LENGTH_b9;
      * pC_TL_O_Take_TRUCK_LENGTH = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_C_TL_O_TAKE_TRUCK_LENGTH_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_O_Take_VEHICLE_LENGTH_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITCTLOTakeVEHICLELENGTHV * pC_TL_O_Take_VEHICLE_LENGTH_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_TL_O_Take_VEHICLE_LENGTH_V
*    C_TL_O_Take_VEHICLE_LENGTH_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_TL_O_Take_VEHICLE_LENGTH_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_O_Take_VEHICLE_LENGTH_V( CORELIGHTSCENEINITCTLOTakeVEHICLELENGTHV * pC_TL_O_Take_VEHICLE_LENGTH_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITCTLOTakeVEHICLELENGTHV signal_value;
   
   if( pC_TL_O_Take_VEHICLE_LENGTH_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_TL_O_Take_VEHICLE_LENGTH_V_b1;
      * pC_TL_O_Take_VEHICLE_LENGTH_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_O_Take_VEHICLE_LENGTH
*
* FUNCTION ARGUMENTS:
*    uint8 * pC_TL_O_Take_VEHICLE_LENGTH - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of C_TL_O_Take_VEHICLE_LENGTH
*    C_TL_O_Take_VEHICLE_LENGTH returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns C_TL_O_Take_VEHICLE_LENGTH signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_C_TL_O_Take_VEHICLE_LENGTH( uint8 * pC_TL_O_Take_VEHICLE_LENGTH )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pC_TL_O_Take_VEHICLE_LENGTH != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.C_TL_O_Take_VEHICLE_LENGTH_b7;
      * pC_TL_O_Take_VEHICLE_LENGTH = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_C_TL_O_TAKE_VEHICLE_LENGTH_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_SPEED_SWITCHING_HIGH_BEAMS_OFF_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITSPEEDSWITCHINGHIGHBEAMSOFFV * pSPEED_SWITCHING_HIGH_BEAMS_OFF_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SPEED_SWITCHING_HIGH_BEAMS_OFF_V
*    SPEED_SWITCHING_HIGH_BEAMS_OFF_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SPEED_SWITCHING_HIGH_BEAMS_OFF_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_SPEED_SWITCHING_HIGH_BEAMS_OFF_V( CORELIGHTSCENEINITSPEEDSWITCHINGHIGHBEAMSOFFV * pSPEED_SWITCHING_HIGH_BEAMS_OFF_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITSPEEDSWITCHINGHIGHBEAMSOFFV signal_value;
   
   if( pSPEED_SWITCHING_HIGH_BEAMS_OFF_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.SPEED_SWITCHING_HIGH_BEAMS_OFF_V_b1;
      * pSPEED_SWITCHING_HIGH_BEAMS_OFF_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_SPEED_SWITCHING_HIGH_BEAMS_OFF
*
* FUNCTION ARGUMENTS:
*    uint8 * pSPEED_SWITCHING_HIGH_BEAMS_OFF - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SPEED_SWITCHING_HIGH_BEAMS_OFF
*    SPEED_SWITCHING_HIGH_BEAMS_OFF returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SPEED_SWITCHING_HIGH_BEAMS_OFF signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_SPEED_SWITCHING_HIGH_BEAMS_OFF( uint8 * pSPEED_SWITCHING_HIGH_BEAMS_OFF )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pSPEED_SWITCHING_HIGH_BEAMS_OFF != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.SPEED_SWITCHING_HIGH_BEAMS_OFF_b8;
      * pSPEED_SWITCHING_HIGH_BEAMS_OFF = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_SPEED_SWITCHING_HIGH_BEAMS_OFF_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_13_V
*
* FUNCTION ARGUMENTS:
*    boolean * pILS_Buffer_13_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_13_V
*    ILS_Buffer_13_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_13_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_13_V( boolean * pILS_Buffer_13_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pILS_Buffer_13_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_13_V_b1;
      * pILS_Buffer_13_V = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_13_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_13
*
* FUNCTION ARGUMENTS:
*    uint8 * pILS_Buffer_13 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_13
*    ILS_Buffer_13 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_13 signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_13( uint8 * pILS_Buffer_13 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pILS_Buffer_13 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_13_b4;
      * pILS_Buffer_13 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_13_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_SPEED_SWITCHING_HIGH_BEAMS_ON_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITSPEEDSWITCHINGHIGHBEAMSONV * pSPEED_SWITCHING_HIGH_BEAMS_ON_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SPEED_SWITCHING_HIGH_BEAMS_ON_V
*    SPEED_SWITCHING_HIGH_BEAMS_ON_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SPEED_SWITCHING_HIGH_BEAMS_ON_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_SPEED_SWITCHING_HIGH_BEAMS_ON_V( CORELIGHTSCENEINITSPEEDSWITCHINGHIGHBEAMSONV * pSPEED_SWITCHING_HIGH_BEAMS_ON_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITSPEEDSWITCHINGHIGHBEAMSONV signal_value;
   
   if( pSPEED_SWITCHING_HIGH_BEAMS_ON_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.SPEED_SWITCHING_HIGH_BEAMS_ON_V_b1;
      * pSPEED_SWITCHING_HIGH_BEAMS_ON_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_SPEED_SWITCHING_HIGH_BEAMS_ON
*
* FUNCTION ARGUMENTS:
*    uint8 * pSPEED_SWITCHING_HIGH_BEAMS_ON - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SPEED_SWITCHING_HIGH_BEAMS_ON
*    SPEED_SWITCHING_HIGH_BEAMS_ON returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SPEED_SWITCHING_HIGH_BEAMS_ON signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_SPEED_SWITCHING_HIGH_BEAMS_ON( uint8 * pSPEED_SWITCHING_HIGH_BEAMS_ON )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pSPEED_SWITCHING_HIGH_BEAMS_ON != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.SPEED_SWITCHING_HIGH_BEAMS_ON_b8;
      * pSPEED_SWITCHING_HIGH_BEAMS_ON = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_SPEED_SWITCHING_HIGH_BEAMS_ON_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_LN_US_ECE_BEHAVIOR_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITLNUSECEBEHAVIORV * pLN_US_ECE_BEHAVIOR_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LN_US_ECE_BEHAVIOR_V
*    LN_US_ECE_BEHAVIOR_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LN_US_ECE_BEHAVIOR_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_LN_US_ECE_BEHAVIOR_V( CORELIGHTSCENEINITLNUSECEBEHAVIORV * pLN_US_ECE_BEHAVIOR_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITLNUSECEBEHAVIORV signal_value;
   
   if( pLN_US_ECE_BEHAVIOR_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.LN_US_ECE_BEHAVIOR_V_b1;
      * pLN_US_ECE_BEHAVIOR_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_LN_US_ECE_BEHAVIOR
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITLNUSECEBEHAVIOR * pLN_US_ECE_BEHAVIOR - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LN_US_ECE_BEHAVIOR
*    LN_US_ECE_BEHAVIOR returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LN_US_ECE_BEHAVIOR signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_LN_US_ECE_BEHAVIOR( CORELIGHTSCENEINITLNUSECEBEHAVIOR * pLN_US_ECE_BEHAVIOR )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITLNUSECEBEHAVIOR signal_value;
   
   if( pLN_US_ECE_BEHAVIOR != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.LN_US_ECE_BEHAVIOR_b2;
      * pLN_US_ECE_BEHAVIOR = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_LN_US_ECE_BEHAVIOR_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_FAR_TAIL_KIL_DIST_COUPLE_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITFARTAILKILDISTCOUPLEV * pFAR_TAIL_KIL_DIST_COUPLE_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FAR_TAIL_KIL_DIST_COUPLE_V
*    FAR_TAIL_KIL_DIST_COUPLE_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FAR_TAIL_KIL_DIST_COUPLE_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_FAR_TAIL_KIL_DIST_COUPLE_V( CORELIGHTSCENEINITFARTAILKILDISTCOUPLEV * pFAR_TAIL_KIL_DIST_COUPLE_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITFARTAILKILDISTCOUPLEV signal_value;
   
   if( pFAR_TAIL_KIL_DIST_COUPLE_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.FAR_TAIL_KIL_DIST_COUPLE_V_b1;
      * pFAR_TAIL_KIL_DIST_COUPLE_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_FAR_TAIL_KIL_DIST_COUPLE
*
* FUNCTION ARGUMENTS:
*    uint16 * pFAR_TAIL_KIL_DIST_COUPLE - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FAR_TAIL_KIL_DIST_COUPLE
*    FAR_TAIL_KIL_DIST_COUPLE returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FAR_TAIL_KIL_DIST_COUPLE signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_FAR_TAIL_KIL_DIST_COUPLE( uint16 * pFAR_TAIL_KIL_DIST_COUPLE )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFAR_TAIL_KIL_DIST_COUPLE != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.FAR_TAIL_KIL_DIST_COUPLE_b12;
      * pFAR_TAIL_KIL_DIST_COUPLE = signal_value;
      if( (signal_value >= C_EYEQMSG_CORELIGHTSCENEINIT_FAR_TAIL_KIL_DIST_COUPLE_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_FAR_TAIL_KIL_DIST_COUPLE_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_14_V
*
* FUNCTION ARGUMENTS:
*    boolean * pILS_Buffer_14_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_14_V
*    ILS_Buffer_14_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_14_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_14_V( boolean * pILS_Buffer_14_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pILS_Buffer_14_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_14_V_b1;
      * pILS_Buffer_14_V = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_14_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_14
*
* FUNCTION ARGUMENTS:
*    uint8 * pILS_Buffer_14 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_14
*    ILS_Buffer_14 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_14 signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_14( uint8 * pILS_Buffer_14 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pILS_Buffer_14 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_14_b6;
      * pILS_Buffer_14 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_14_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_FAR_TAIL_KIL_DIST_COUPLE_CHI_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITFARTAILKILDISTCOUPLECHIV * pFAR_TAIL_KIL_DIST_COUPLE_CHI_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FAR_TAIL_KIL_DIST_COUPLE_CHI_V
*    FAR_TAIL_KIL_DIST_COUPLE_CHI_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FAR_TAIL_KIL_DIST_COUPLE_CHI_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_FAR_TAIL_KIL_DIST_COUPLE_CHI_V( CORELIGHTSCENEINITFARTAILKILDISTCOUPLECHIV * pFAR_TAIL_KIL_DIST_COUPLE_CHI_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITFARTAILKILDISTCOUPLECHIV signal_value;
   
   if( pFAR_TAIL_KIL_DIST_COUPLE_CHI_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.FAR_TAIL_KIL_DIST_COUPLE_CHI_V_b1;
      * pFAR_TAIL_KIL_DIST_COUPLE_CHI_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_FAR_TAIL_KIL_DIST_COUPLE_CHI
*
* FUNCTION ARGUMENTS:
*    uint16 * pFAR_TAIL_KIL_DIST_COUPLE_CHI - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FAR_TAIL_KIL_DIST_COUPLE_CHI
*    FAR_TAIL_KIL_DIST_COUPLE_CHI returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FAR_TAIL_KIL_DIST_COUPLE_CHI signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_FAR_TAIL_KIL_DIST_COUPLE_CHI( uint16 * pFAR_TAIL_KIL_DIST_COUPLE_CHI )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFAR_TAIL_KIL_DIST_COUPLE_CHI != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.FAR_TAIL_KIL_DIST_COUPLE_CHI_b12;
      * pFAR_TAIL_KIL_DIST_COUPLE_CHI = signal_value;
      if( (signal_value >= C_EYEQMSG_CORELIGHTSCENEINIT_FAR_TAIL_KIL_DIST_COUPLE_CHI_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_FAR_TAIL_KIL_DIST_COUPLE_CHI_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_FAR_TAIL_KIL_DIST_ONE_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITFARTAILKILDISTONEV * pFAR_TAIL_KIL_DIST_ONE_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FAR_TAIL_KIL_DIST_ONE_V
*    FAR_TAIL_KIL_DIST_ONE_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FAR_TAIL_KIL_DIST_ONE_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_FAR_TAIL_KIL_DIST_ONE_V( CORELIGHTSCENEINITFARTAILKILDISTONEV * pFAR_TAIL_KIL_DIST_ONE_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITFARTAILKILDISTONEV signal_value;
   
   if( pFAR_TAIL_KIL_DIST_ONE_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.FAR_TAIL_KIL_DIST_ONE_V_b1;
      * pFAR_TAIL_KIL_DIST_ONE_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_FAR_TAIL_KIL_DIST_ONE
*
* FUNCTION ARGUMENTS:
*    uint16 * pFAR_TAIL_KIL_DIST_ONE - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FAR_TAIL_KIL_DIST_ONE
*    FAR_TAIL_KIL_DIST_ONE returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FAR_TAIL_KIL_DIST_ONE signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_FAR_TAIL_KIL_DIST_ONE( uint16 * pFAR_TAIL_KIL_DIST_ONE )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFAR_TAIL_KIL_DIST_ONE != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.FAR_TAIL_KIL_DIST_ONE_b12;
      * pFAR_TAIL_KIL_DIST_ONE = signal_value;
      if( (signal_value >= C_EYEQMSG_CORELIGHTSCENEINIT_FAR_TAIL_KIL_DIST_ONE_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_FAR_TAIL_KIL_DIST_ONE_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_15_V
*
* FUNCTION ARGUMENTS:
*    boolean * pILS_Buffer_15_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_15_V
*    ILS_Buffer_15_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_15_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_15_V( boolean * pILS_Buffer_15_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pILS_Buffer_15_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_15_V_b1;
      * pILS_Buffer_15_V = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_15_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_15
*
* FUNCTION ARGUMENTS:
*    uint8 * pILS_Buffer_15 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_15
*    ILS_Buffer_15 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_15 signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_15( uint8 * pILS_Buffer_15 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pILS_Buffer_15 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_15_b5;
      * pILS_Buffer_15 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_15_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_FAR_TAIL_KIL_DIST_ONE_CHINA_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITFARTAILKILDISTONECHINAV * pFAR_TAIL_KIL_DIST_ONE_CHINA_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FAR_TAIL_KIL_DIST_ONE_CHINA_V
*    FAR_TAIL_KIL_DIST_ONE_CHINA_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FAR_TAIL_KIL_DIST_ONE_CHINA_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_FAR_TAIL_KIL_DIST_ONE_CHINA_V( CORELIGHTSCENEINITFARTAILKILDISTONECHINAV * pFAR_TAIL_KIL_DIST_ONE_CHINA_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITFARTAILKILDISTONECHINAV signal_value;
   
   if( pFAR_TAIL_KIL_DIST_ONE_CHINA_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.FAR_TAIL_KIL_DIST_ONE_CHINA_V_b1;
      * pFAR_TAIL_KIL_DIST_ONE_CHINA_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_FAR_TAIL_KIL_DIST_ONE_CHINA
*
* FUNCTION ARGUMENTS:
*    uint16 * pFAR_TAIL_KIL_DIST_ONE_CHINA - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FAR_TAIL_KIL_DIST_ONE_CHINA
*    FAR_TAIL_KIL_DIST_ONE_CHINA returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FAR_TAIL_KIL_DIST_ONE_CHINA signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_FAR_TAIL_KIL_DIST_ONE_CHINA( uint16 * pFAR_TAIL_KIL_DIST_ONE_CHINA )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFAR_TAIL_KIL_DIST_ONE_CHINA != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.FAR_TAIL_KIL_DIST_ONE_CHINA_b12;
      * pFAR_TAIL_KIL_DIST_ONE_CHINA = signal_value;
      if( (signal_value >= C_EYEQMSG_CORELIGHTSCENEINIT_FAR_TAIL_KIL_DIST_ONE_CHINA_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_FAR_TAIL_KIL_DIST_ONE_CHINA_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_ONCOMING_DIST_COUPLE_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITMAXONCOMINGDISTCOUPLEV * pMAX_ONCOMING_DIST_COUPLE_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MAX_ONCOMING_DIST_COUPLE_V
*    MAX_ONCOMING_DIST_COUPLE_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MAX_ONCOMING_DIST_COUPLE_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_ONCOMING_DIST_COUPLE_V( CORELIGHTSCENEINITMAXONCOMINGDISTCOUPLEV * pMAX_ONCOMING_DIST_COUPLE_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITMAXONCOMINGDISTCOUPLEV signal_value;
   
   if( pMAX_ONCOMING_DIST_COUPLE_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.MAX_ONCOMING_DIST_COUPLE_V_b1;
      * pMAX_ONCOMING_DIST_COUPLE_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_ONCOMING_DIST_COUPLE
*
* FUNCTION ARGUMENTS:
*    uint16 * pMAX_ONCOMING_DIST_COUPLE - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MAX_ONCOMING_DIST_COUPLE
*    MAX_ONCOMING_DIST_COUPLE returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MAX_ONCOMING_DIST_COUPLE signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_ONCOMING_DIST_COUPLE( uint16 * pMAX_ONCOMING_DIST_COUPLE )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pMAX_ONCOMING_DIST_COUPLE != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.MAX_ONCOMING_DIST_COUPLE_b12;
      * pMAX_ONCOMING_DIST_COUPLE = signal_value;
      if( (signal_value >= C_EYEQMSG_CORELIGHTSCENEINIT_MAX_ONCOMING_DIST_COUPLE_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_MAX_ONCOMING_DIST_COUPLE_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_16_V
*
* FUNCTION ARGUMENTS:
*    boolean * pILS_Buffer_16_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_16_V
*    ILS_Buffer_16_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_16_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_16_V( boolean * pILS_Buffer_16_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pILS_Buffer_16_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_16_V_b1;
      * pILS_Buffer_16_V = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_16_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_16
*
* FUNCTION ARGUMENTS:
*    uint8 * pILS_Buffer_16 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_16
*    ILS_Buffer_16 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_16 signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_16( uint8 * pILS_Buffer_16 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pILS_Buffer_16 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_16_b5;
      * pILS_Buffer_16 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_16_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_ONCOMING_DIST_COUPLE_CHINA_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITMAXONCOMINGDISTCOUPLECHINAV * pMAX_ONCOMING_DIST_COUPLE_CHINA_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MAX_ONCOMING_DIST_COUPLE_CHINA_V
*    MAX_ONCOMING_DIST_COUPLE_CHINA_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MAX_ONCOMING_DIST_COUPLE_CHINA_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_ONCOMING_DIST_COUPLE_CHINA_V( CORELIGHTSCENEINITMAXONCOMINGDISTCOUPLECHINAV * pMAX_ONCOMING_DIST_COUPLE_CHINA_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITMAXONCOMINGDISTCOUPLECHINAV signal_value;
   
   if( pMAX_ONCOMING_DIST_COUPLE_CHINA_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.MAX_ONCOMING_DIST_COUPLE_CHINA_V_b1;
      * pMAX_ONCOMING_DIST_COUPLE_CHINA_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_ONCOMING_DIST_COUPLE_CHINA
*
* FUNCTION ARGUMENTS:
*    uint16 * pMAX_ONCOMING_DIST_COUPLE_CHINA - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MAX_ONCOMING_DIST_COUPLE_CHINA
*    MAX_ONCOMING_DIST_COUPLE_CHINA returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MAX_ONCOMING_DIST_COUPLE_CHINA signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_ONCOMING_DIST_COUPLE_CHINA( uint16 * pMAX_ONCOMING_DIST_COUPLE_CHINA )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pMAX_ONCOMING_DIST_COUPLE_CHINA != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.MAX_ONCOMING_DIST_COUPLE_CHINA_b12;
      * pMAX_ONCOMING_DIST_COUPLE_CHINA = signal_value;
      if( (signal_value >= C_EYEQMSG_CORELIGHTSCENEINIT_MAX_ONCOMING_DIST_COUPLE_CHINA_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_MAX_ONCOMING_DIST_COUPLE_CHINA_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_OC_DIST_COUPLE_IN_LB_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITMAXOCDISTCOUPLEINLBV * pMAX_OC_DIST_COUPLE_IN_LB_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MAX_OC_DIST_COUPLE_IN_LB_V
*    MAX_OC_DIST_COUPLE_IN_LB_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MAX_OC_DIST_COUPLE_IN_LB_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_OC_DIST_COUPLE_IN_LB_V( CORELIGHTSCENEINITMAXOCDISTCOUPLEINLBV * pMAX_OC_DIST_COUPLE_IN_LB_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITMAXOCDISTCOUPLEINLBV signal_value;
   
   if( pMAX_OC_DIST_COUPLE_IN_LB_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.MAX_OC_DIST_COUPLE_IN_LB_V_b1;
      * pMAX_OC_DIST_COUPLE_IN_LB_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_OC_DIST_COUPLE_IN_LB
*
* FUNCTION ARGUMENTS:
*    uint16 * pMAX_OC_DIST_COUPLE_IN_LB - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MAX_OC_DIST_COUPLE_IN_LB
*    MAX_OC_DIST_COUPLE_IN_LB returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MAX_OC_DIST_COUPLE_IN_LB signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_OC_DIST_COUPLE_IN_LB( uint16 * pMAX_OC_DIST_COUPLE_IN_LB )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pMAX_OC_DIST_COUPLE_IN_LB != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.MAX_OC_DIST_COUPLE_IN_LB_b12;
      * pMAX_OC_DIST_COUPLE_IN_LB = signal_value;
      if( (signal_value >= C_EYEQMSG_CORELIGHTSCENEINIT_MAX_OC_DIST_COUPLE_IN_LB_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_MAX_OC_DIST_COUPLE_IN_LB_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_17_V
*
* FUNCTION ARGUMENTS:
*    boolean * pILS_Buffer_17_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_17_V
*    ILS_Buffer_17_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_17_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_17_V( boolean * pILS_Buffer_17_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pILS_Buffer_17_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_17_V_b1;
      * pILS_Buffer_17_V = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_17_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_17
*
* FUNCTION ARGUMENTS:
*    uint8 * pILS_Buffer_17 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_17
*    ILS_Buffer_17 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_17 signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_17( uint8 * pILS_Buffer_17 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pILS_Buffer_17 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_17_b5;
      * pILS_Buffer_17 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_17_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_OC_DIST_COUPLE_IN_LB_CHINA_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITMAXOCDISTCOUPLEINLBCHINAV * pMAX_OC_DIST_COUPLE_IN_LB_CHINA_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MAX_OC_DIST_COUPLE_IN_LB_CHINA_V
*    MAX_OC_DIST_COUPLE_IN_LB_CHINA_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MAX_OC_DIST_COUPLE_IN_LB_CHINA_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_OC_DIST_COUPLE_IN_LB_CHINA_V( CORELIGHTSCENEINITMAXOCDISTCOUPLEINLBCHINAV * pMAX_OC_DIST_COUPLE_IN_LB_CHINA_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITMAXOCDISTCOUPLEINLBCHINAV signal_value;
   
   if( pMAX_OC_DIST_COUPLE_IN_LB_CHINA_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.MAX_OC_DIST_COUPLE_IN_LB_CHINA_V_b1;
      * pMAX_OC_DIST_COUPLE_IN_LB_CHINA_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_OC_DIST_COUPLE_IN_LB_CHINA
*
* FUNCTION ARGUMENTS:
*    uint16 * pMAX_OC_DIST_COUPLE_IN_LB_CHINA - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MAX_OC_DIST_COUPLE_IN_LB_CHINA
*    MAX_OC_DIST_COUPLE_IN_LB_CHINA returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MAX_OC_DIST_COUPLE_IN_LB_CHINA signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_OC_DIST_COUPLE_IN_LB_CHINA( uint16 * pMAX_OC_DIST_COUPLE_IN_LB_CHINA )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pMAX_OC_DIST_COUPLE_IN_LB_CHINA != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.MAX_OC_DIST_COUPLE_IN_LB_CHINA_b12;
      * pMAX_OC_DIST_COUPLE_IN_LB_CHINA = signal_value;
      if( (signal_value >= C_EYEQMSG_CORELIGHTSCENEINIT_MAX_OC_DIST_COUPLE_IN_LB_CHINA_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_MAX_OC_DIST_COUPLE_IN_LB_CHINA_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_OC_DIST_ONE_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITMAXOCDISTONEV * pMAX_OC_DIST_ONE_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MAX_OC_DIST_ONE_V
*    MAX_OC_DIST_ONE_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MAX_OC_DIST_ONE_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_OC_DIST_ONE_V( CORELIGHTSCENEINITMAXOCDISTONEV * pMAX_OC_DIST_ONE_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITMAXOCDISTONEV signal_value;
   
   if( pMAX_OC_DIST_ONE_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.MAX_OC_DIST_ONE_V_b1;
      * pMAX_OC_DIST_ONE_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_OC_DIST_ONE
*
* FUNCTION ARGUMENTS:
*    uint16 * pMAX_OC_DIST_ONE - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MAX_OC_DIST_ONE
*    MAX_OC_DIST_ONE returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MAX_OC_DIST_ONE signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_OC_DIST_ONE( uint16 * pMAX_OC_DIST_ONE )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pMAX_OC_DIST_ONE != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.MAX_OC_DIST_ONE_b12;
      * pMAX_OC_DIST_ONE = signal_value;
      if( (signal_value >= C_EYEQMSG_CORELIGHTSCENEINIT_MAX_OC_DIST_ONE_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_MAX_OC_DIST_ONE_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_18_V
*
* FUNCTION ARGUMENTS:
*    boolean * pILS_Buffer_18_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_18_V
*    ILS_Buffer_18_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_18_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_18_V( boolean * pILS_Buffer_18_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pILS_Buffer_18_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_18_V_b1;
      * pILS_Buffer_18_V = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_18_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_18
*
* FUNCTION ARGUMENTS:
*    uint8 * pILS_Buffer_18 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_18
*    ILS_Buffer_18 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_18 signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_18( uint8 * pILS_Buffer_18 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pILS_Buffer_18 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_18_b5;
      * pILS_Buffer_18 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_18_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_ONCOMING_DIST_ONE_CHINA_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITMAXONCOMINGDISTONECHINAV * pMAX_ONCOMING_DIST_ONE_CHINA_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MAX_ONCOMING_DIST_ONE_CHINA_V
*    MAX_ONCOMING_DIST_ONE_CHINA_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MAX_ONCOMING_DIST_ONE_CHINA_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_ONCOMING_DIST_ONE_CHINA_V( CORELIGHTSCENEINITMAXONCOMINGDISTONECHINAV * pMAX_ONCOMING_DIST_ONE_CHINA_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITMAXONCOMINGDISTONECHINAV signal_value;
   
   if( pMAX_ONCOMING_DIST_ONE_CHINA_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.MAX_ONCOMING_DIST_ONE_CHINA_V_b1;
      * pMAX_ONCOMING_DIST_ONE_CHINA_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_ONCOMING_DIST_ONE_CHINA
*
* FUNCTION ARGUMENTS:
*    uint16 * pMAX_ONCOMING_DIST_ONE_CHINA - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MAX_ONCOMING_DIST_ONE_CHINA
*    MAX_ONCOMING_DIST_ONE_CHINA returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MAX_ONCOMING_DIST_ONE_CHINA signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_ONCOMING_DIST_ONE_CHINA( uint16 * pMAX_ONCOMING_DIST_ONE_CHINA )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pMAX_ONCOMING_DIST_ONE_CHINA != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.MAX_ONCOMING_DIST_ONE_CHINA_b12;
      * pMAX_ONCOMING_DIST_ONE_CHINA = signal_value;
      if( (signal_value >= C_EYEQMSG_CORELIGHTSCENEINIT_MAX_ONCOMING_DIST_ONE_CHINA_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_MAX_ONCOMING_DIST_ONE_CHINA_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_ONCOMING_DIST_ONE_IN_LB_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITMAXONCOMINGDISTONEINLBV * pMAX_ONCOMING_DIST_ONE_IN_LB_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MAX_ONCOMING_DIST_ONE_IN_LB_V
*    MAX_ONCOMING_DIST_ONE_IN_LB_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MAX_ONCOMING_DIST_ONE_IN_LB_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_ONCOMING_DIST_ONE_IN_LB_V( CORELIGHTSCENEINITMAXONCOMINGDISTONEINLBV * pMAX_ONCOMING_DIST_ONE_IN_LB_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITMAXONCOMINGDISTONEINLBV signal_value;
   
   if( pMAX_ONCOMING_DIST_ONE_IN_LB_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.MAX_ONCOMING_DIST_ONE_IN_LB_V_b1;
      * pMAX_ONCOMING_DIST_ONE_IN_LB_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_ONCOMING_DIST_ONE_IN_LB
*
* FUNCTION ARGUMENTS:
*    uint16 * pMAX_ONCOMING_DIST_ONE_IN_LB - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MAX_ONCOMING_DIST_ONE_IN_LB
*    MAX_ONCOMING_DIST_ONE_IN_LB returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MAX_ONCOMING_DIST_ONE_IN_LB signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_ONCOMING_DIST_ONE_IN_LB( uint16 * pMAX_ONCOMING_DIST_ONE_IN_LB )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pMAX_ONCOMING_DIST_ONE_IN_LB != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.MAX_ONCOMING_DIST_ONE_IN_LB_b12;
      * pMAX_ONCOMING_DIST_ONE_IN_LB = signal_value;
      if( (signal_value >= C_EYEQMSG_CORELIGHTSCENEINIT_MAX_ONCOMING_DIST_ONE_IN_LB_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_MAX_ONCOMING_DIST_ONE_IN_LB_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_19_V
*
* FUNCTION ARGUMENTS:
*    boolean * pILS_Buffer_19_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_19_V
*    ILS_Buffer_19_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_19_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_19_V( boolean * pILS_Buffer_19_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pILS_Buffer_19_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_19_V_b1;
      * pILS_Buffer_19_V = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_19_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_19
*
* FUNCTION ARGUMENTS:
*    uint8 * pILS_Buffer_19 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_19
*    ILS_Buffer_19 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_19 signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_19( uint8 * pILS_Buffer_19 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pILS_Buffer_19 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_19_b5;
      * pILS_Buffer_19 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_19_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_OC_DIST_ONE_IN_LB_CHINA_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITMAXOCDISTONEINLBCHINAV * pMAX_OC_DIST_ONE_IN_LB_CHINA_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MAX_OC_DIST_ONE_IN_LB_CHINA_V
*    MAX_OC_DIST_ONE_IN_LB_CHINA_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MAX_OC_DIST_ONE_IN_LB_CHINA_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_OC_DIST_ONE_IN_LB_CHINA_V( CORELIGHTSCENEINITMAXOCDISTONEINLBCHINAV * pMAX_OC_DIST_ONE_IN_LB_CHINA_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITMAXOCDISTONEINLBCHINAV signal_value;
   
   if( pMAX_OC_DIST_ONE_IN_LB_CHINA_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.MAX_OC_DIST_ONE_IN_LB_CHINA_V_b1;
      * pMAX_OC_DIST_ONE_IN_LB_CHINA_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_OC_DIST_ONE_IN_LB_CHINA
*
* FUNCTION ARGUMENTS:
*    uint16 * pMAX_OC_DIST_ONE_IN_LB_CHINA - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MAX_OC_DIST_ONE_IN_LB_CHINA
*    MAX_OC_DIST_ONE_IN_LB_CHINA returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MAX_OC_DIST_ONE_IN_LB_CHINA signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_OC_DIST_ONE_IN_LB_CHINA( uint16 * pMAX_OC_DIST_ONE_IN_LB_CHINA )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pMAX_OC_DIST_ONE_IN_LB_CHINA != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.MAX_OC_DIST_ONE_IN_LB_CHINA_b12;
      * pMAX_OC_DIST_ONE_IN_LB_CHINA = signal_value;
      if( (signal_value >= C_EYEQMSG_CORELIGHTSCENEINIT_MAX_OC_DIST_ONE_IN_LB_CHINA_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_MAX_OC_DIST_ONE_IN_LB_CHINA_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_TAIL_DIST_COUPLE_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITMAXTAILDISTCOUPLEV * pMAX_TAIL_DIST_COUPLE_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MAX_TAIL_DIST_COUPLE_V
*    MAX_TAIL_DIST_COUPLE_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MAX_TAIL_DIST_COUPLE_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_TAIL_DIST_COUPLE_V( CORELIGHTSCENEINITMAXTAILDISTCOUPLEV * pMAX_TAIL_DIST_COUPLE_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITMAXTAILDISTCOUPLEV signal_value;
   
   if( pMAX_TAIL_DIST_COUPLE_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.MAX_TAIL_DIST_COUPLE_V_b1;
      * pMAX_TAIL_DIST_COUPLE_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_TAIL_DIST_COUPLE
*
* FUNCTION ARGUMENTS:
*    uint16 * pMAX_TAIL_DIST_COUPLE - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MAX_TAIL_DIST_COUPLE
*    MAX_TAIL_DIST_COUPLE returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MAX_TAIL_DIST_COUPLE signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_TAIL_DIST_COUPLE( uint16 * pMAX_TAIL_DIST_COUPLE )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pMAX_TAIL_DIST_COUPLE != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.MAX_TAIL_DIST_COUPLE_b12;
      * pMAX_TAIL_DIST_COUPLE = signal_value;
      if( (signal_value >= C_EYEQMSG_CORELIGHTSCENEINIT_MAX_TAIL_DIST_COUPLE_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_MAX_TAIL_DIST_COUPLE_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_20_V
*
* FUNCTION ARGUMENTS:
*    boolean * pILS_Buffer_20_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_20_V
*    ILS_Buffer_20_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_20_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_20_V( boolean * pILS_Buffer_20_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pILS_Buffer_20_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_20_V_b1;
      * pILS_Buffer_20_V = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_20_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_20
*
* FUNCTION ARGUMENTS:
*    uint8 * pILS_Buffer_20 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_20
*    ILS_Buffer_20 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_20 signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_20( uint8 * pILS_Buffer_20 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pILS_Buffer_20 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_20_b5;
      * pILS_Buffer_20 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_20_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_TAIL_DIST_COUPLE_CHINA_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITMAXTAILDISTCOUPLECHINAV * pMAX_TAIL_DIST_COUPLE_CHINA_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MAX_TAIL_DIST_COUPLE_CHINA_V
*    MAX_TAIL_DIST_COUPLE_CHINA_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MAX_TAIL_DIST_COUPLE_CHINA_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_TAIL_DIST_COUPLE_CHINA_V( CORELIGHTSCENEINITMAXTAILDISTCOUPLECHINAV * pMAX_TAIL_DIST_COUPLE_CHINA_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITMAXTAILDISTCOUPLECHINAV signal_value;
   
   if( pMAX_TAIL_DIST_COUPLE_CHINA_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.MAX_TAIL_DIST_COUPLE_CHINA_V_b1;
      * pMAX_TAIL_DIST_COUPLE_CHINA_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_TAIL_DIST_COUPLE_CHINA
*
* FUNCTION ARGUMENTS:
*    uint16 * pMAX_TAIL_DIST_COUPLE_CHINA - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MAX_TAIL_DIST_COUPLE_CHINA
*    MAX_TAIL_DIST_COUPLE_CHINA returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MAX_TAIL_DIST_COUPLE_CHINA signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_TAIL_DIST_COUPLE_CHINA( uint16 * pMAX_TAIL_DIST_COUPLE_CHINA )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pMAX_TAIL_DIST_COUPLE_CHINA != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.MAX_TAIL_DIST_COUPLE_CHINA_b12;
      * pMAX_TAIL_DIST_COUPLE_CHINA = signal_value;
      if( (signal_value >= C_EYEQMSG_CORELIGHTSCENEINIT_MAX_TAIL_DIST_COUPLE_CHINA_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_MAX_TAIL_DIST_COUPLE_CHINA_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_TAIL_DIST_COUPLE_IN_LB_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITMAXTAILDISTCOUPLEINLBV * pMAX_TAIL_DIST_COUPLE_IN_LB_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MAX_TAIL_DIST_COUPLE_IN_LB_V
*    MAX_TAIL_DIST_COUPLE_IN_LB_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MAX_TAIL_DIST_COUPLE_IN_LB_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_TAIL_DIST_COUPLE_IN_LB_V( CORELIGHTSCENEINITMAXTAILDISTCOUPLEINLBV * pMAX_TAIL_DIST_COUPLE_IN_LB_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITMAXTAILDISTCOUPLEINLBV signal_value;
   
   if( pMAX_TAIL_DIST_COUPLE_IN_LB_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.MAX_TAIL_DIST_COUPLE_IN_LB_V_b1;
      * pMAX_TAIL_DIST_COUPLE_IN_LB_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_TAIL_DIST_COUPLE_IN_LB
*
* FUNCTION ARGUMENTS:
*    uint16 * pMAX_TAIL_DIST_COUPLE_IN_LB - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MAX_TAIL_DIST_COUPLE_IN_LB
*    MAX_TAIL_DIST_COUPLE_IN_LB returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MAX_TAIL_DIST_COUPLE_IN_LB signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_TAIL_DIST_COUPLE_IN_LB( uint16 * pMAX_TAIL_DIST_COUPLE_IN_LB )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pMAX_TAIL_DIST_COUPLE_IN_LB != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.MAX_TAIL_DIST_COUPLE_IN_LB_b12;
      * pMAX_TAIL_DIST_COUPLE_IN_LB = signal_value;
      if( (signal_value >= C_EYEQMSG_CORELIGHTSCENEINIT_MAX_TAIL_DIST_COUPLE_IN_LB_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_MAX_TAIL_DIST_COUPLE_IN_LB_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_21_V
*
* FUNCTION ARGUMENTS:
*    boolean * pILS_Buffer_21_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_21_V
*    ILS_Buffer_21_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_21_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_21_V( boolean * pILS_Buffer_21_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pILS_Buffer_21_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_21_V_b1;
      * pILS_Buffer_21_V = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_21_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_21
*
* FUNCTION ARGUMENTS:
*    uint8 * pILS_Buffer_21 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_21
*    ILS_Buffer_21 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_21 signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_21( uint8 * pILS_Buffer_21 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pILS_Buffer_21 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_21_b5;
      * pILS_Buffer_21 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_21_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_TAIL_DIST_COUP_IN_LB_CHINA_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITMAXTAILDISTCOUPINLBCHINAV * pMAX_TAIL_DIST_COUP_IN_LB_CHINA_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MAX_TAIL_DIST_COUP_IN_LB_CHINA_V
*    MAX_TAIL_DIST_COUP_IN_LB_CHINA_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MAX_TAIL_DIST_COUP_IN_LB_CHINA_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_TAIL_DIST_COUP_IN_LB_CHINA_V( CORELIGHTSCENEINITMAXTAILDISTCOUPINLBCHINAV * pMAX_TAIL_DIST_COUP_IN_LB_CHINA_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITMAXTAILDISTCOUPINLBCHINAV signal_value;
   
   if( pMAX_TAIL_DIST_COUP_IN_LB_CHINA_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.MAX_TAIL_DIST_COUP_IN_LB_CHINA_V_b1;
      * pMAX_TAIL_DIST_COUP_IN_LB_CHINA_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_TAIL_DIST_COUPLE_IN_LB_CHINA
*
* FUNCTION ARGUMENTS:
*    uint16 * pMAX_TAIL_DIST_COUPLE_IN_LB_CHINA - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MAX_TAIL_DIST_COUPLE_IN_LB_CHINA
*    MAX_TAIL_DIST_COUPLE_IN_LB_CHINA returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MAX_TAIL_DIST_COUPLE_IN_LB_CHINA signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_TAIL_DIST_COUPLE_IN_LB_CHINA( uint16 * pMAX_TAIL_DIST_COUPLE_IN_LB_CHINA )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pMAX_TAIL_DIST_COUPLE_IN_LB_CHINA != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.MAX_TAIL_DIST_COUPLE_IN_LB_CHINA_b12;
      * pMAX_TAIL_DIST_COUPLE_IN_LB_CHINA = signal_value;
      if( (signal_value >= C_EYEQMSG_CORELIGHTSCENEINIT_MAX_TAIL_DIST_COUPLE_IN_LB_CHINA_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_MAX_TAIL_DIST_COUPLE_IN_LB_CHINA_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_TAIL_DIST_ONE_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITMAXTAILDISTONEV * pMAX_TAIL_DIST_ONE_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MAX_TAIL_DIST_ONE_V
*    MAX_TAIL_DIST_ONE_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MAX_TAIL_DIST_ONE_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_TAIL_DIST_ONE_V( CORELIGHTSCENEINITMAXTAILDISTONEV * pMAX_TAIL_DIST_ONE_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITMAXTAILDISTONEV signal_value;
   
   if( pMAX_TAIL_DIST_ONE_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.MAX_TAIL_DIST_ONE_V_b1;
      * pMAX_TAIL_DIST_ONE_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_TAIL_DIST_ONE
*
* FUNCTION ARGUMENTS:
*    uint16 * pMAX_TAIL_DIST_ONE - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MAX_TAIL_DIST_ONE
*    MAX_TAIL_DIST_ONE returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MAX_TAIL_DIST_ONE signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_TAIL_DIST_ONE( uint16 * pMAX_TAIL_DIST_ONE )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pMAX_TAIL_DIST_ONE != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.MAX_TAIL_DIST_ONE_b12;
      * pMAX_TAIL_DIST_ONE = signal_value;
      if( (signal_value >= C_EYEQMSG_CORELIGHTSCENEINIT_MAX_TAIL_DIST_ONE_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_MAX_TAIL_DIST_ONE_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_22_V
*
* FUNCTION ARGUMENTS:
*    boolean * pILS_Buffer_22_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_22_V
*    ILS_Buffer_22_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_22_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_22_V( boolean * pILS_Buffer_22_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pILS_Buffer_22_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_22_V_b1;
      * pILS_Buffer_22_V = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_22_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_22
*
* FUNCTION ARGUMENTS:
*    uint8 * pILS_Buffer_22 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_22
*    ILS_Buffer_22 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_22 signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_22( uint8 * pILS_Buffer_22 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pILS_Buffer_22 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_22_b5;
      * pILS_Buffer_22 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_22_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_TAIL_DIST_ONE_CHINA_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITMAXTAILDISTONECHINAV * pMAX_TAIL_DIST_ONE_CHINA_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MAX_TAIL_DIST_ONE_CHINA_V
*    MAX_TAIL_DIST_ONE_CHINA_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MAX_TAIL_DIST_ONE_CHINA_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_TAIL_DIST_ONE_CHINA_V( CORELIGHTSCENEINITMAXTAILDISTONECHINAV * pMAX_TAIL_DIST_ONE_CHINA_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITMAXTAILDISTONECHINAV signal_value;
   
   if( pMAX_TAIL_DIST_ONE_CHINA_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.MAX_TAIL_DIST_ONE_CHINA_V_b1;
      * pMAX_TAIL_DIST_ONE_CHINA_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_TAIL_DIST_ONE_CHINA
*
* FUNCTION ARGUMENTS:
*    uint16 * pMAX_TAIL_DIST_ONE_CHINA - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MAX_TAIL_DIST_ONE_CHINA
*    MAX_TAIL_DIST_ONE_CHINA returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MAX_TAIL_DIST_ONE_CHINA signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_TAIL_DIST_ONE_CHINA( uint16 * pMAX_TAIL_DIST_ONE_CHINA )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pMAX_TAIL_DIST_ONE_CHINA != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.MAX_TAIL_DIST_ONE_CHINA_b12;
      * pMAX_TAIL_DIST_ONE_CHINA = signal_value;
      if( (signal_value >= C_EYEQMSG_CORELIGHTSCENEINIT_MAX_TAIL_DIST_ONE_CHINA_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_MAX_TAIL_DIST_ONE_CHINA_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_TAIL_DIST_ONE_IN_LB_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITMAXTAILDISTONEINLBV * pMAX_TAIL_DIST_ONE_IN_LB_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MAX_TAIL_DIST_ONE_IN_LB_V
*    MAX_TAIL_DIST_ONE_IN_LB_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MAX_TAIL_DIST_ONE_IN_LB_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_TAIL_DIST_ONE_IN_LB_V( CORELIGHTSCENEINITMAXTAILDISTONEINLBV * pMAX_TAIL_DIST_ONE_IN_LB_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITMAXTAILDISTONEINLBV signal_value;
   
   if( pMAX_TAIL_DIST_ONE_IN_LB_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.MAX_TAIL_DIST_ONE_IN_LB_V_b1;
      * pMAX_TAIL_DIST_ONE_IN_LB_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_TAIL_DIST_ONE_IN_LB
*
* FUNCTION ARGUMENTS:
*    uint16 * pMAX_TAIL_DIST_ONE_IN_LB - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MAX_TAIL_DIST_ONE_IN_LB
*    MAX_TAIL_DIST_ONE_IN_LB returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MAX_TAIL_DIST_ONE_IN_LB signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_TAIL_DIST_ONE_IN_LB( uint16 * pMAX_TAIL_DIST_ONE_IN_LB )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pMAX_TAIL_DIST_ONE_IN_LB != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.MAX_TAIL_DIST_ONE_IN_LB_b12;
      * pMAX_TAIL_DIST_ONE_IN_LB = signal_value;
      if( (signal_value >= C_EYEQMSG_CORELIGHTSCENEINIT_MAX_TAIL_DIST_ONE_IN_LB_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_MAX_TAIL_DIST_ONE_IN_LB_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_23_V
*
* FUNCTION ARGUMENTS:
*    boolean * pILS_Buffer_23_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_23_V
*    ILS_Buffer_23_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_23_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_23_V( boolean * pILS_Buffer_23_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pILS_Buffer_23_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_23_V_b1;
      * pILS_Buffer_23_V = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_23_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_23
*
* FUNCTION ARGUMENTS:
*    uint8 * pILS_Buffer_23 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_23
*    ILS_Buffer_23 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_23 signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_23( uint8 * pILS_Buffer_23 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pILS_Buffer_23 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_23_b5;
      * pILS_Buffer_23 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_23_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_TAIL_DIST_ONE_IN_LB_CHINA_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITMAXTAILDISTONEINLBCHINAV * pMAX_TAIL_DIST_ONE_IN_LB_CHINA_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MAX_TAIL_DIST_ONE_IN_LB_CHINA_V
*    MAX_TAIL_DIST_ONE_IN_LB_CHINA_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MAX_TAIL_DIST_ONE_IN_LB_CHINA_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_TAIL_DIST_ONE_IN_LB_CHINA_V( CORELIGHTSCENEINITMAXTAILDISTONEINLBCHINAV * pMAX_TAIL_DIST_ONE_IN_LB_CHINA_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITMAXTAILDISTONEINLBCHINAV signal_value;
   
   if( pMAX_TAIL_DIST_ONE_IN_LB_CHINA_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.MAX_TAIL_DIST_ONE_IN_LB_CHINA_V_b1;
      * pMAX_TAIL_DIST_ONE_IN_LB_CHINA_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_TAIL_DIST_ONE_IN_LB_CHINA
*
* FUNCTION ARGUMENTS:
*    uint16 * pMAX_TAIL_DIST_ONE_IN_LB_CHINA - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MAX_TAIL_DIST_ONE_IN_LB_CHINA
*    MAX_TAIL_DIST_ONE_IN_LB_CHINA returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MAX_TAIL_DIST_ONE_IN_LB_CHINA signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_TAIL_DIST_ONE_IN_LB_CHINA( uint16 * pMAX_TAIL_DIST_ONE_IN_LB_CHINA )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pMAX_TAIL_DIST_ONE_IN_LB_CHINA != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.MAX_TAIL_DIST_ONE_IN_LB_CHINA_b12;
      * pMAX_TAIL_DIST_ONE_IN_LB_CHINA = signal_value;
      if( (signal_value >= C_EYEQMSG_CORELIGHTSCENEINIT_MAX_TAIL_DIST_ONE_IN_LB_CHINA_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_MAX_TAIL_DIST_ONE_IN_LB_CHINA_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_OBJECTS_CLUSTERING_METHOD_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITOBJECTSCLUSTERINGMETHODV * pOBJECTS_CLUSTERING_METHOD_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJECTS_CLUSTERING_METHOD_V
*    OBJECTS_CLUSTERING_METHOD_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJECTS_CLUSTERING_METHOD_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_OBJECTS_CLUSTERING_METHOD_V( CORELIGHTSCENEINITOBJECTSCLUSTERINGMETHODV * pOBJECTS_CLUSTERING_METHOD_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITOBJECTSCLUSTERINGMETHODV signal_value;
   
   if( pOBJECTS_CLUSTERING_METHOD_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.OBJECTS_CLUSTERING_METHOD_V_b1;
      * pOBJECTS_CLUSTERING_METHOD_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_OBJECTS_CLUSTERING_METHOD
*
* FUNCTION ARGUMENTS:
*    uint8 * pOBJECTS_CLUSTERING_METHOD - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJECTS_CLUSTERING_METHOD
*    OBJECTS_CLUSTERING_METHOD returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJECTS_CLUSTERING_METHOD signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_OBJECTS_CLUSTERING_METHOD( uint8 * pOBJECTS_CLUSTERING_METHOD )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pOBJECTS_CLUSTERING_METHOD != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.OBJECTS_CLUSTERING_METHOD_b3;
      * pOBJECTS_CLUSTERING_METHOD = signal_value;
      if( (signal_value >= C_EYEQMSG_CORELIGHTSCENEINIT_OBJECTS_CLUSTERING_METHOD_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_OBJECTS_CLUSTERING_METHOD_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_NUM_STRONG_REFLECTORS_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITMAXNUMSTRONGREFLECTORSV * pMAX_NUM_STRONG_REFLECTORS_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MAX_NUM_STRONG_REFLECTORS_V
*    MAX_NUM_STRONG_REFLECTORS_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MAX_NUM_STRONG_REFLECTORS_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_NUM_STRONG_REFLECTORS_V( CORELIGHTSCENEINITMAXNUMSTRONGREFLECTORSV * pMAX_NUM_STRONG_REFLECTORS_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITMAXNUMSTRONGREFLECTORSV signal_value;
   
   if( pMAX_NUM_STRONG_REFLECTORS_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.MAX_NUM_STRONG_REFLECTORS_V_b1;
      * pMAX_NUM_STRONG_REFLECTORS_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_NUM_STRONG_REFLECTORS
*
* FUNCTION ARGUMENTS:
*    uint8 * pMAX_NUM_STRONG_REFLECTORS - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MAX_NUM_STRONG_REFLECTORS
*    MAX_NUM_STRONG_REFLECTORS returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MAX_NUM_STRONG_REFLECTORS signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_NUM_STRONG_REFLECTORS( uint8 * pMAX_NUM_STRONG_REFLECTORS )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pMAX_NUM_STRONG_REFLECTORS != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.MAX_NUM_STRONG_REFLECTORS_b4;
      * pMAX_NUM_STRONG_REFLECTORS = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_MAX_NUM_STRONG_REFLECTORS_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_NUM_VEHICLE_OBJECTS_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITMAXNUMVEHICLEOBJECTSV * pMAX_NUM_VEHICLE_OBJECTS_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MAX_NUM_VEHICLE_OBJECTS_V
*    MAX_NUM_VEHICLE_OBJECTS_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MAX_NUM_VEHICLE_OBJECTS_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_NUM_VEHICLE_OBJECTS_V( CORELIGHTSCENEINITMAXNUMVEHICLEOBJECTSV * pMAX_NUM_VEHICLE_OBJECTS_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITMAXNUMVEHICLEOBJECTSV signal_value;
   
   if( pMAX_NUM_VEHICLE_OBJECTS_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.MAX_NUM_VEHICLE_OBJECTS_V_b1;
      * pMAX_NUM_VEHICLE_OBJECTS_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_NUM_VEHICLE_OBJECTS
*
* FUNCTION ARGUMENTS:
*    uint8 * pMAX_NUM_VEHICLE_OBJECTS - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MAX_NUM_VEHICLE_OBJECTS
*    MAX_NUM_VEHICLE_OBJECTS returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MAX_NUM_VEHICLE_OBJECTS signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_NUM_VEHICLE_OBJECTS( uint8 * pMAX_NUM_VEHICLE_OBJECTS )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pMAX_NUM_VEHICLE_OBJECTS != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.MAX_NUM_VEHICLE_OBJECTS_b4;
      * pMAX_NUM_VEHICLE_OBJECTS = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_Reduce_Sense_Force_Activation_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITReduceSenseForceActivationV * pReduce_Sense_Force_Activation_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reduce_Sense_Force_Activation_V
*    Reduce_Sense_Force_Activation_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reduce_Sense_Force_Activation_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_Reduce_Sense_Force_Activation_V( CORELIGHTSCENEINITReduceSenseForceActivationV * pReduce_Sense_Force_Activation_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITReduceSenseForceActivationV signal_value;
   
   if( pReduce_Sense_Force_Activation_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.Reduce_Sense_Force_Activation_V_b1;
      * pReduce_Sense_Force_Activation_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_Reduce_Sense_Force_Activation
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITReduceSenseForceActivation * pReduce_Sense_Force_Activation - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reduce_Sense_Force_Activation
*    Reduce_Sense_Force_Activation returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reduce_Sense_Force_Activation signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_Reduce_Sense_Force_Activation( CORELIGHTSCENEINITReduceSenseForceActivation * pReduce_Sense_Force_Activation )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITReduceSenseForceActivation signal_value;
   
   if( pReduce_Sense_Force_Activation != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.Reduce_Sense_Force_Activation_b2;
      * pReduce_Sense_Force_Activation = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_REDUCE_SENSE_FORCE_ACTIVATION_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_24_V
*
* FUNCTION ARGUMENTS:
*    boolean * pILS_Buffer_24_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_24_V
*    ILS_Buffer_24_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_24_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_24_V( boolean * pILS_Buffer_24_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pILS_Buffer_24_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_24_V_b1;
      * pILS_Buffer_24_V = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_24_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_24
*
* FUNCTION ARGUMENTS:
*    boolean * pILS_Buffer_24 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_24
*    ILS_Buffer_24 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_24 signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_24( boolean * pILS_Buffer_24 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pILS_Buffer_24 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_24_b1;
      * pILS_Buffer_24 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_24_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_Reduce_Sense_Grace_Frames_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITReduceSenseGraceFramesV * pReduce_Sense_Grace_Frames_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reduce_Sense_Grace_Frames_V
*    Reduce_Sense_Grace_Frames_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reduce_Sense_Grace_Frames_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_Reduce_Sense_Grace_Frames_V( CORELIGHTSCENEINITReduceSenseGraceFramesV * pReduce_Sense_Grace_Frames_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITReduceSenseGraceFramesV signal_value;
   
   if( pReduce_Sense_Grace_Frames_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.Reduce_Sense_Grace_Frames_V_b1;
      * pReduce_Sense_Grace_Frames_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_Reduce_Sense_Grace_Frames
*
* FUNCTION ARGUMENTS:
*    uint8 * pReduce_Sense_Grace_Frames - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reduce_Sense_Grace_Frames
*    Reduce_Sense_Grace_Frames returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reduce_Sense_Grace_Frames signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_Reduce_Sense_Grace_Frames( uint8 * pReduce_Sense_Grace_Frames )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pReduce_Sense_Grace_Frames != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.Reduce_Sense_Grace_Frames_b5;
      * pReduce_Sense_Grace_Frames = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_REDUCE_SENSE_GRACE_FRAMES_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_Reduce_Sense_HighToLow_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITReduceSenseHighToLowV * pReduce_Sense_HighToLow_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reduce_Sense_HighToLow_V
*    Reduce_Sense_HighToLow_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reduce_Sense_HighToLow_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_Reduce_Sense_HighToLow_V( CORELIGHTSCENEINITReduceSenseHighToLowV * pReduce_Sense_HighToLow_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITReduceSenseHighToLowV signal_value;
   
   if( pReduce_Sense_HighToLow_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.Reduce_Sense_HighToLow_V_b1;
      * pReduce_Sense_HighToLow_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_Reduce_Sense_HighToLow
*
* FUNCTION ARGUMENTS:
*    uint16 * pReduce_Sense_HighToLow - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reduce_Sense_HighToLow
*    Reduce_Sense_HighToLow returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reduce_Sense_HighToLow signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_Reduce_Sense_HighToLow( uint16 * pReduce_Sense_HighToLow )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pReduce_Sense_HighToLow != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.Reduce_Sense_HighToLow_b10;
      * pReduce_Sense_HighToLow = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_REDUCE_SENSE_HIGHTOLOW_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_Reduce_Sense_HighToLow_H5R_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITReduceSenseHighToLowH5RV * pReduce_Sense_HighToLow_H5R_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reduce_Sense_HighToLow_H5R_V
*    Reduce_Sense_HighToLow_H5R_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reduce_Sense_HighToLow_H5R_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_Reduce_Sense_HighToLow_H5R_V( CORELIGHTSCENEINITReduceSenseHighToLowH5RV * pReduce_Sense_HighToLow_H5R_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITReduceSenseHighToLowH5RV signal_value;
   
   if( pReduce_Sense_HighToLow_H5R_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.Reduce_Sense_HighToLow_H5R_V_b1;
      * pReduce_Sense_HighToLow_H5R_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_Reduce_Sense_HighToLow_H5R
*
* FUNCTION ARGUMENTS:
*    uint16 * pReduce_Sense_HighToLow_H5R - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reduce_Sense_HighToLow_H5R
*    Reduce_Sense_HighToLow_H5R returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reduce_Sense_HighToLow_H5R signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_Reduce_Sense_HighToLow_H5R( uint16 * pReduce_Sense_HighToLow_H5R )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pReduce_Sense_HighToLow_H5R != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.Reduce_Sense_HighToLow_H5R_b10;
      * pReduce_Sense_HighToLow_H5R = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_REDUCE_SENSE_HIGHTOLOW_H5R_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_25_V
*
* FUNCTION ARGUMENTS:
*    boolean * pILS_Buffer_25_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_25_V
*    ILS_Buffer_25_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_25_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_25_V( boolean * pILS_Buffer_25_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pILS_Buffer_25_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_25_V_b1;
      * pILS_Buffer_25_V = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_25_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_25
*
* FUNCTION ARGUMENTS:
*    uint8 * pILS_Buffer_25 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_25
*    ILS_Buffer_25 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_25 signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_25( uint8 * pILS_Buffer_25 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pILS_Buffer_25 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_25_b3;
      * pILS_Buffer_25 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_25_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_Reduce_Sense_LowToHigh_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITReduceSenseLowToHighV * pReduce_Sense_LowToHigh_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reduce_Sense_LowToHigh_V
*    Reduce_Sense_LowToHigh_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reduce_Sense_LowToHigh_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_Reduce_Sense_LowToHigh_V( CORELIGHTSCENEINITReduceSenseLowToHighV * pReduce_Sense_LowToHigh_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITReduceSenseLowToHighV signal_value;
   
   if( pReduce_Sense_LowToHigh_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.Reduce_Sense_LowToHigh_V_b1;
      * pReduce_Sense_LowToHigh_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_Reduce_Sense_LowToHigh
*
* FUNCTION ARGUMENTS:
*    uint16 * pReduce_Sense_LowToHigh - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reduce_Sense_LowToHigh
*    Reduce_Sense_LowToHigh returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reduce_Sense_LowToHigh signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_Reduce_Sense_LowToHigh( uint16 * pReduce_Sense_LowToHigh )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pReduce_Sense_LowToHigh != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.Reduce_Sense_LowToHigh_b10;
      * pReduce_Sense_LowToHigh = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_REDUCE_SENSE_LOWTOHIGH_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ONCOMING_SENSITIVITY_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITONCOMINGSENSITIVITYV * pONCOMING_SENSITIVITY_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ONCOMING_SENSITIVITY_V
*    ONCOMING_SENSITIVITY_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ONCOMING_SENSITIVITY_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ONCOMING_SENSITIVITY_V( CORELIGHTSCENEINITONCOMINGSENSITIVITYV * pONCOMING_SENSITIVITY_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITONCOMINGSENSITIVITYV signal_value;
   
   if( pONCOMING_SENSITIVITY_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ONCOMING_SENSITIVITY_V_b1;
      * pONCOMING_SENSITIVITY_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ONCOMING_SENSITIVITY
*
* FUNCTION ARGUMENTS:
*    uint8 * pONCOMING_SENSITIVITY - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ONCOMING_SENSITIVITY
*    ONCOMING_SENSITIVITY returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ONCOMING_SENSITIVITY signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ONCOMING_SENSITIVITY( uint8 * pONCOMING_SENSITIVITY )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pONCOMING_SENSITIVITY != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ONCOMING_SENSITIVITY_b6;
      * pONCOMING_SENSITIVITY = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ONCOMING_SENSITIVITY_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_TAILLIGHT_SENSITIVITY_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITTAILLIGHTSENSITIVITYV * pTAILLIGHT_SENSITIVITY_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TAILLIGHT_SENSITIVITY_V
*    TAILLIGHT_SENSITIVITY_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TAILLIGHT_SENSITIVITY_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_TAILLIGHT_SENSITIVITY_V( CORELIGHTSCENEINITTAILLIGHTSENSITIVITYV * pTAILLIGHT_SENSITIVITY_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITTAILLIGHTSENSITIVITYV signal_value;
   
   if( pTAILLIGHT_SENSITIVITY_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.TAILLIGHT_SENSITIVITY_V_b1;
      * pTAILLIGHT_SENSITIVITY_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_TAILLIGHT_SENSITIVITY
*
* FUNCTION ARGUMENTS:
*    uint8 * pTAILLIGHT_SENSITIVITY - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TAILLIGHT_SENSITIVITY
*    TAILLIGHT_SENSITIVITY returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TAILLIGHT_SENSITIVITY signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_TAILLIGHT_SENSITIVITY( uint8 * pTAILLIGHT_SENSITIVITY )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pTAILLIGHT_SENSITIVITY != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.TAILLIGHT_SENSITIVITY_b6;
      * pTAILLIGHT_SENSITIVITY = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_TAILLIGHT_SENSITIVITY_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_OC_REDUCED_SENSITIVITY_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITOCREDUCEDSENSITIVITYV * pOC_REDUCED_SENSITIVITY_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OC_REDUCED_SENSITIVITY_V
*    OC_REDUCED_SENSITIVITY_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OC_REDUCED_SENSITIVITY_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_OC_REDUCED_SENSITIVITY_V( CORELIGHTSCENEINITOCREDUCEDSENSITIVITYV * pOC_REDUCED_SENSITIVITY_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITOCREDUCEDSENSITIVITYV signal_value;
   
   if( pOC_REDUCED_SENSITIVITY_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.OC_REDUCED_SENSITIVITY_V_b1;
      * pOC_REDUCED_SENSITIVITY_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_OC_REDUCED_SENSITIVITY
*
* FUNCTION ARGUMENTS:
*    uint8 * pOC_REDUCED_SENSITIVITY - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OC_REDUCED_SENSITIVITY
*    OC_REDUCED_SENSITIVITY returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OC_REDUCED_SENSITIVITY signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_OC_REDUCED_SENSITIVITY( uint8 * pOC_REDUCED_SENSITIVITY )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pOC_REDUCED_SENSITIVITY != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.OC_REDUCED_SENSITIVITY_b6;
      * pOC_REDUCED_SENSITIVITY = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_OC_REDUCED_SENSITIVITY_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_VE_OBJ_APPROVAL_DIST_FULL_FOV_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITVEOBJAPPROVALDISTFULLFOVV * pVE_OBJ_APPROVAL_DIST_FULL_FOV_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of VE_OBJ_APPROVAL_DIST_FULL_FOV_V
*    VE_OBJ_APPROVAL_DIST_FULL_FOV_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns VE_OBJ_APPROVAL_DIST_FULL_FOV_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_VE_OBJ_APPROVAL_DIST_FULL_FOV_V( CORELIGHTSCENEINITVEOBJAPPROVALDISTFULLFOVV * pVE_OBJ_APPROVAL_DIST_FULL_FOV_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITVEOBJAPPROVALDISTFULLFOVV signal_value;
   
   if( pVE_OBJ_APPROVAL_DIST_FULL_FOV_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.VE_OBJ_APPROVAL_DIST_FULL_FOV_V_b1;
      * pVE_OBJ_APPROVAL_DIST_FULL_FOV_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_VE_OBJ_APPROVAL_DIST_FULL_FOV
*
* FUNCTION ARGUMENTS:
*    uint16 * pVE_OBJ_APPROVAL_DIST_FULL_FOV - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of VE_OBJ_APPROVAL_DIST_FULL_FOV
*    VE_OBJ_APPROVAL_DIST_FULL_FOV returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns VE_OBJ_APPROVAL_DIST_FULL_FOV signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_VE_OBJ_APPROVAL_DIST_FULL_FOV( uint16 * pVE_OBJ_APPROVAL_DIST_FULL_FOV )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pVE_OBJ_APPROVAL_DIST_FULL_FOV != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.VE_OBJ_APPROVAL_DIST_FULL_FOV_b12;
      * pVE_OBJ_APPROVAL_DIST_FULL_FOV = signal_value;
      if( (signal_value >= C_EYEQMSG_CORELIGHTSCENEINIT_VE_OBJ_APPROVAL_DIST_FULL_FOV_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_VE_OBJ_APPROVAL_DIST_FULL_FOV_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_VE_OBJ_APPROVAL_FOV_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITVEOBJAPPROVALFOVV * pVE_OBJ_APPROVAL_FOV_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of VE_OBJ_APPROVAL_FOV_V
*    VE_OBJ_APPROVAL_FOV_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns VE_OBJ_APPROVAL_FOV_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_VE_OBJ_APPROVAL_FOV_V( CORELIGHTSCENEINITVEOBJAPPROVALFOVV * pVE_OBJ_APPROVAL_FOV_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITVEOBJAPPROVALFOVV signal_value;
   
   if( pVE_OBJ_APPROVAL_FOV_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.VE_OBJ_APPROVAL_FOV_V_b1;
      * pVE_OBJ_APPROVAL_FOV_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_VE_OBJ_APPROVAL_FOV
*
* FUNCTION ARGUMENTS:
*    uint16 * pVE_OBJ_APPROVAL_FOV - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of VE_OBJ_APPROVAL_FOV
*    VE_OBJ_APPROVAL_FOV returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns VE_OBJ_APPROVAL_FOV signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_VE_OBJ_APPROVAL_FOV( uint16 * pVE_OBJ_APPROVAL_FOV )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pVE_OBJ_APPROVAL_FOV != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.VE_OBJ_APPROVAL_FOV_b9;
      * pVE_OBJ_APPROVAL_FOV = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_VE_OBJ_APPROVAL_FOV_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_MIN_TTLI_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITMINTTLIV * pMIN_TTLI_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MIN_TTLI_V
*    MIN_TTLI_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MIN_TTLI_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_MIN_TTLI_V( CORELIGHTSCENEINITMINTTLIV * pMIN_TTLI_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITMINTTLIV signal_value;
   
   if( pMIN_TTLI_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.MIN_TTLI_V_b1;
      * pMIN_TTLI_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_MIN_TTLI
*
* FUNCTION ARGUMENTS:
*    uint8 * pMIN_TTLI - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MIN_TTLI
*    MIN_TTLI returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MIN_TTLI signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_MIN_TTLI( uint8 * pMIN_TTLI )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pMIN_TTLI != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.MIN_TTLI_b8;
      * pMIN_TTLI = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_BS_DUSK_DELAY_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITBSDUSKDELAYV * pBS_DUSK_DELAY_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BS_DUSK_DELAY_V
*    BS_DUSK_DELAY_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BS_DUSK_DELAY_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_BS_DUSK_DELAY_V( CORELIGHTSCENEINITBSDUSKDELAYV * pBS_DUSK_DELAY_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITBSDUSKDELAYV signal_value;
   
   if( pBS_DUSK_DELAY_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.BS_DUSK_DELAY_V_b1;
      * pBS_DUSK_DELAY_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_BS_DUSK_DELAY
*
* FUNCTION ARGUMENTS:
*    uint32 * pBS_DUSK_DELAY - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BS_DUSK_DELAY
*    BS_DUSK_DELAY returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BS_DUSK_DELAY signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_BS_DUSK_DELAY( uint32 * pBS_DUSK_DELAY )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pBS_DUSK_DELAY != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.BS_DUSK_DELAY_b20;
      * pBS_DUSK_DELAY = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_BS_DUSK_DELAY_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_BS_ENTER_THRESH_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITBSENTERTHRESHV * pBS_ENTER_THRESH_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BS_ENTER_THRESH_V
*    BS_ENTER_THRESH_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BS_ENTER_THRESH_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_BS_ENTER_THRESH_V( CORELIGHTSCENEINITBSENTERTHRESHV * pBS_ENTER_THRESH_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITBSENTERTHRESHV signal_value;
   
   if( pBS_ENTER_THRESH_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.BS_ENTER_THRESH_V_b1;
      * pBS_ENTER_THRESH_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_BS_ENTER_THRESH
*
* FUNCTION ARGUMENTS:
*    uint16 * pBS_ENTER_THRESH - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BS_ENTER_THRESH
*    BS_ENTER_THRESH returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BS_ENTER_THRESH signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_BS_ENTER_THRESH( uint16 * pBS_ENTER_THRESH )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pBS_ENTER_THRESH != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.BS_ENTER_THRESH_b11;
      * pBS_ENTER_THRESH = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_BS_ENTER_THRESH_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_BS_EXIT_THRESH_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITBSEXITTHRESHV * pBS_EXIT_THRESH_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BS_EXIT_THRESH_V
*    BS_EXIT_THRESH_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BS_EXIT_THRESH_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_BS_EXIT_THRESH_V( CORELIGHTSCENEINITBSEXITTHRESHV * pBS_EXIT_THRESH_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITBSEXITTHRESHV signal_value;
   
   if( pBS_EXIT_THRESH_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.BS_EXIT_THRESH_V_b1;
      * pBS_EXIT_THRESH_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_BS_EXIT_THRESH
*
* FUNCTION ARGUMENTS:
*    uint16 * pBS_EXIT_THRESH - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BS_EXIT_THRESH
*    BS_EXIT_THRESH returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BS_EXIT_THRESH signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_BS_EXIT_THRESH( uint16 * pBS_EXIT_THRESH )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pBS_EXIT_THRESH != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.BS_EXIT_THRESH_b11;
      * pBS_EXIT_THRESH = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_BS_EXIT_THRESH_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_BS_OB_ENTER_THRESH_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITBSOBENTERTHRESHV * pBS_OB_ENTER_THRESH_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BS_OB_ENTER_THRESH_V
*    BS_OB_ENTER_THRESH_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BS_OB_ENTER_THRESH_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_BS_OB_ENTER_THRESH_V( CORELIGHTSCENEINITBSOBENTERTHRESHV * pBS_OB_ENTER_THRESH_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITBSOBENTERTHRESHV signal_value;
   
   if( pBS_OB_ENTER_THRESH_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.BS_OB_ENTER_THRESH_V_b1;
      * pBS_OB_ENTER_THRESH_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_BS_OB_ENTER_THRESH
*
* FUNCTION ARGUMENTS:
*    uint16 * pBS_OB_ENTER_THRESH - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BS_OB_ENTER_THRESH
*    BS_OB_ENTER_THRESH returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BS_OB_ENTER_THRESH signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_BS_OB_ENTER_THRESH( uint16 * pBS_OB_ENTER_THRESH )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pBS_OB_ENTER_THRESH != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.BS_OB_ENTER_THRESH_b11;
      * pBS_OB_ENTER_THRESH = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_BS_OB_ENTER_THRESH_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_26_V
*
* FUNCTION ARGUMENTS:
*    boolean * pILS_Buffer_26_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_26_V
*    ILS_Buffer_26_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_26_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_26_V( boolean * pILS_Buffer_26_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pILS_Buffer_26_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_26_V_b1;
      * pILS_Buffer_26_V = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_26_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_26
*
* FUNCTION ARGUMENTS:
*    uint8 * pILS_Buffer_26 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_26
*    ILS_Buffer_26 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_26 signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_26( uint8 * pILS_Buffer_26 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pILS_Buffer_26 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_26_b6;
      * pILS_Buffer_26 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_26_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_BS_OB_EXIT_THRESH_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITBSOBEXITTHRESHV * pBS_OB_EXIT_THRESH_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BS_OB_EXIT_THRESH_V
*    BS_OB_EXIT_THRESH_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BS_OB_EXIT_THRESH_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_BS_OB_EXIT_THRESH_V( CORELIGHTSCENEINITBSOBEXITTHRESHV * pBS_OB_EXIT_THRESH_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITBSOBEXITTHRESHV signal_value;
   
   if( pBS_OB_EXIT_THRESH_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.BS_OB_EXIT_THRESH_V_b1;
      * pBS_OB_EXIT_THRESH_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_BS_OB_EXIT_THRESH
*
* FUNCTION ARGUMENTS:
*    uint16 * pBS_OB_EXIT_THRESH - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BS_OB_EXIT_THRESH
*    BS_OB_EXIT_THRESH returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BS_OB_EXIT_THRESH signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_BS_OB_EXIT_THRESH( uint16 * pBS_OB_EXIT_THRESH )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pBS_OB_EXIT_THRESH != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.BS_OB_EXIT_THRESH_b11;
      * pBS_OB_EXIT_THRESH = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_BS_OB_EXIT_THRESH_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_CONTROL_LOW_BEAM_ON_BLINK_TFL_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITCONTROLLOWBEAMONBLINKTFLV * pCONTROL_LOW_BEAM_ON_BLINK_TFL_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CONTROL_LOW_BEAM_ON_BLINK_TFL_V
*    CONTROL_LOW_BEAM_ON_BLINK_TFL_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CONTROL_LOW_BEAM_ON_BLINK_TFL_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_CONTROL_LOW_BEAM_ON_BLINK_TFL_V( CORELIGHTSCENEINITCONTROLLOWBEAMONBLINKTFLV * pCONTROL_LOW_BEAM_ON_BLINK_TFL_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITCONTROLLOWBEAMONBLINKTFLV signal_value;
   
   if( pCONTROL_LOW_BEAM_ON_BLINK_TFL_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.CONTROL_LOW_BEAM_ON_BLINK_TFL_V_b1;
      * pCONTROL_LOW_BEAM_ON_BLINK_TFL_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_CONTROL_LOW_BEAM_ON_BLINK_TFL
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITCONTROLLOWBEAMONBLINKTFL * pCONTROL_LOW_BEAM_ON_BLINK_TFL - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CONTROL_LOW_BEAM_ON_BLINK_TFL
*    CONTROL_LOW_BEAM_ON_BLINK_TFL returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CONTROL_LOW_BEAM_ON_BLINK_TFL signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_CONTROL_LOW_BEAM_ON_BLINK_TFL( CORELIGHTSCENEINITCONTROLLOWBEAMONBLINKTFL * pCONTROL_LOW_BEAM_ON_BLINK_TFL )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITCONTROLLOWBEAMONBLINKTFL signal_value;
   
   if( pCONTROL_LOW_BEAM_ON_BLINK_TFL != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.CONTROL_LOW_BEAM_ON_BLINK_TFL_b1;
      * pCONTROL_LOW_BEAM_ON_BLINK_TFL = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_CONTROL_OC_CURVY_ROAD_DELAY_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITCONTROLOCCURVYROADDELAYV * pCONTROL_OC_CURVY_ROAD_DELAY_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CONTROL_OC_CURVY_ROAD_DELAY_V
*    CONTROL_OC_CURVY_ROAD_DELAY_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CONTROL_OC_CURVY_ROAD_DELAY_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_CONTROL_OC_CURVY_ROAD_DELAY_V( CORELIGHTSCENEINITCONTROLOCCURVYROADDELAYV * pCONTROL_OC_CURVY_ROAD_DELAY_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITCONTROLOCCURVYROADDELAYV signal_value;
   
   if( pCONTROL_OC_CURVY_ROAD_DELAY_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.CONTROL_OC_CURVY_ROAD_DELAY_V_b1;
      * pCONTROL_OC_CURVY_ROAD_DELAY_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_CONTROL_OC_CURVY_ROAD_DELAY
*
* FUNCTION ARGUMENTS:
*    uint16 * pCONTROL_OC_CURVY_ROAD_DELAY - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CONTROL_OC_CURVY_ROAD_DELAY
*    CONTROL_OC_CURVY_ROAD_DELAY returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CONTROL_OC_CURVY_ROAD_DELAY signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_CONTROL_OC_CURVY_ROAD_DELAY( uint16 * pCONTROL_OC_CURVY_ROAD_DELAY )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pCONTROL_OC_CURVY_ROAD_DELAY != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.CONTROL_OC_CURVY_ROAD_DELAY_b13;
      * pCONTROL_OC_CURVY_ROAD_DELAY = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_CONTROL_OC_CURVY_ROAD_DELAY_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_27_V
*
* FUNCTION ARGUMENTS:
*    boolean * pILS_Buffer_27_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_27_V
*    ILS_Buffer_27_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_27_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_27_V( boolean * pILS_Buffer_27_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pILS_Buffer_27_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_27_V_b1;
      * pILS_Buffer_27_V = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_27_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_27
*
* FUNCTION ARGUMENTS:
*    uint8 * pILS_Buffer_27 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_27
*    ILS_Buffer_27 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_27 signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_27( uint8 * pILS_Buffer_27 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pILS_Buffer_27 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_27_b3;
      * pILS_Buffer_27 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_27_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_CONTROL_TL_CURVY_ROAD_DELAY_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITCONTROLTLCURVYROADDELAYV * pCONTROL_TL_CURVY_ROAD_DELAY_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CONTROL_TL_CURVY_ROAD_DELAY_V
*    CONTROL_TL_CURVY_ROAD_DELAY_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CONTROL_TL_CURVY_ROAD_DELAY_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_CONTROL_TL_CURVY_ROAD_DELAY_V( CORELIGHTSCENEINITCONTROLTLCURVYROADDELAYV * pCONTROL_TL_CURVY_ROAD_DELAY_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITCONTROLTLCURVYROADDELAYV signal_value;
   
   if( pCONTROL_TL_CURVY_ROAD_DELAY_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.CONTROL_TL_CURVY_ROAD_DELAY_V_b1;
      * pCONTROL_TL_CURVY_ROAD_DELAY_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_CONTROL_TL_CURVY_ROAD_DELAY
*
* FUNCTION ARGUMENTS:
*    uint16 * pCONTROL_TL_CURVY_ROAD_DELAY - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CONTROL_TL_CURVY_ROAD_DELAY
*    CONTROL_TL_CURVY_ROAD_DELAY returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CONTROL_TL_CURVY_ROAD_DELAY signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_CONTROL_TL_CURVY_ROAD_DELAY( uint16 * pCONTROL_TL_CURVY_ROAD_DELAY )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pCONTROL_TL_CURVY_ROAD_DELAY != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.CONTROL_TL_CURVY_ROAD_DELAY_b13;
      * pCONTROL_TL_CURVY_ROAD_DELAY = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_CONTROL_TL_CURVY_ROAD_DELAY_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_COUPLE_H_LIGHTS_DIST_PRIVATE_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITCOUPLEHLIGHTSDISTPRIVATEV * pCOUPLE_H_LIGHTS_DIST_PRIVATE_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of COUPLE_H_LIGHTS_DIST_PRIVATE_V
*    COUPLE_H_LIGHTS_DIST_PRIVATE_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns COUPLE_H_LIGHTS_DIST_PRIVATE_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_COUPLE_H_LIGHTS_DIST_PRIVATE_V( CORELIGHTSCENEINITCOUPLEHLIGHTSDISTPRIVATEV * pCOUPLE_H_LIGHTS_DIST_PRIVATE_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITCOUPLEHLIGHTSDISTPRIVATEV signal_value;
   
   if( pCOUPLE_H_LIGHTS_DIST_PRIVATE_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.COUPLE_H_LIGHTS_DIST_PRIVATE_V_b1;
      * pCOUPLE_H_LIGHTS_DIST_PRIVATE_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_COUPLE_H_LIGHTS_DIST_PRIVATE
*
* FUNCTION ARGUMENTS:
*    uint8 * pCOUPLE_H_LIGHTS_DIST_PRIVATE - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of COUPLE_H_LIGHTS_DIST_PRIVATE
*    COUPLE_H_LIGHTS_DIST_PRIVATE returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns COUPLE_H_LIGHTS_DIST_PRIVATE signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_COUPLE_H_LIGHTS_DIST_PRIVATE( uint8 * pCOUPLE_H_LIGHTS_DIST_PRIVATE )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pCOUPLE_H_LIGHTS_DIST_PRIVATE != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.COUPLE_H_LIGHTS_DIST_PRIVATE_b8;
      * pCOUPLE_H_LIGHTS_DIST_PRIVATE = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_COUPLE_H_LIGHTS_DIST_TRUCK_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITCOUPLEHLIGHTSDISTTRUCKV * pCOUPLE_H_LIGHTS_DIST_TRUCK_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of COUPLE_H_LIGHTS_DIST_TRUCK_V
*    COUPLE_H_LIGHTS_DIST_TRUCK_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns COUPLE_H_LIGHTS_DIST_TRUCK_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_COUPLE_H_LIGHTS_DIST_TRUCK_V( CORELIGHTSCENEINITCOUPLEHLIGHTSDISTTRUCKV * pCOUPLE_H_LIGHTS_DIST_TRUCK_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITCOUPLEHLIGHTSDISTTRUCKV signal_value;
   
   if( pCOUPLE_H_LIGHTS_DIST_TRUCK_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.COUPLE_H_LIGHTS_DIST_TRUCK_V_b1;
      * pCOUPLE_H_LIGHTS_DIST_TRUCK_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_COUPLE_H_LIGHTS_DIST_TRUCK
*
* FUNCTION ARGUMENTS:
*    uint8 * pCOUPLE_H_LIGHTS_DIST_TRUCK - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of COUPLE_H_LIGHTS_DIST_TRUCK
*    COUPLE_H_LIGHTS_DIST_TRUCK returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns COUPLE_H_LIGHTS_DIST_TRUCK signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_COUPLE_H_LIGHTS_DIST_TRUCK( uint8 * pCOUPLE_H_LIGHTS_DIST_TRUCK )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pCOUPLE_H_LIGHTS_DIST_TRUCK != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.COUPLE_H_LIGHTS_DIST_TRUCK_b8;
      * pCOUPLE_H_LIGHTS_DIST_TRUCK = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_COUPLE_T_LIGHTS_DIST_PRIVATE_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITCOUPLETLIGHTSDISTPRIVATEV * pCOUPLE_T_LIGHTS_DIST_PRIVATE_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of COUPLE_T_LIGHTS_DIST_PRIVATE_V
*    COUPLE_T_LIGHTS_DIST_PRIVATE_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns COUPLE_T_LIGHTS_DIST_PRIVATE_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_COUPLE_T_LIGHTS_DIST_PRIVATE_V( CORELIGHTSCENEINITCOUPLETLIGHTSDISTPRIVATEV * pCOUPLE_T_LIGHTS_DIST_PRIVATE_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITCOUPLETLIGHTSDISTPRIVATEV signal_value;
   
   if( pCOUPLE_T_LIGHTS_DIST_PRIVATE_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.COUPLE_T_LIGHTS_DIST_PRIVATE_V_b1;
      * pCOUPLE_T_LIGHTS_DIST_PRIVATE_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_COUPLE_T_LIGHTS_DIST_PRIVATE
*
* FUNCTION ARGUMENTS:
*    uint8 * pCOUPLE_T_LIGHTS_DIST_PRIVATE - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of COUPLE_T_LIGHTS_DIST_PRIVATE
*    COUPLE_T_LIGHTS_DIST_PRIVATE returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns COUPLE_T_LIGHTS_DIST_PRIVATE signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_COUPLE_T_LIGHTS_DIST_PRIVATE( uint8 * pCOUPLE_T_LIGHTS_DIST_PRIVATE )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pCOUPLE_T_LIGHTS_DIST_PRIVATE != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.COUPLE_T_LIGHTS_DIST_PRIVATE_b8;
      * pCOUPLE_T_LIGHTS_DIST_PRIVATE = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_COUPLE_T_LIGHTS_DIST_TRUCK_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITCOUPLETLIGHTSDISTTRUCKV * pCOUPLE_T_LIGHTS_DIST_TRUCK_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of COUPLE_T_LIGHTS_DIST_TRUCK_V
*    COUPLE_T_LIGHTS_DIST_TRUCK_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns COUPLE_T_LIGHTS_DIST_TRUCK_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_COUPLE_T_LIGHTS_DIST_TRUCK_V( CORELIGHTSCENEINITCOUPLETLIGHTSDISTTRUCKV * pCOUPLE_T_LIGHTS_DIST_TRUCK_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITCOUPLETLIGHTSDISTTRUCKV signal_value;
   
   if( pCOUPLE_T_LIGHTS_DIST_TRUCK_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.COUPLE_T_LIGHTS_DIST_TRUCK_V_b1;
      * pCOUPLE_T_LIGHTS_DIST_TRUCK_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_COUPLE_T_LIGHTS_DIST_TRUCK
*
* FUNCTION ARGUMENTS:
*    uint8 * pCOUPLE_T_LIGHTS_DIST_TRUCK - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of COUPLE_T_LIGHTS_DIST_TRUCK
*    COUPLE_T_LIGHTS_DIST_TRUCK returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns COUPLE_T_LIGHTS_DIST_TRUCK signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_COUPLE_T_LIGHTS_DIST_TRUCK( uint8 * pCOUPLE_T_LIGHTS_DIST_TRUCK )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pCOUPLE_T_LIGHTS_DIST_TRUCK != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.COUPLE_T_LIGHTS_DIST_TRUCK_b8;
      * pCOUPLE_T_LIGHTS_DIST_TRUCK = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_DARK_SCENE_ONCOMING_SENS_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITDARKSCENEONCOMINGSENSV * pDARK_SCENE_ONCOMING_SENS_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of DARK_SCENE_ONCOMING_SENS_V
*    DARK_SCENE_ONCOMING_SENS_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns DARK_SCENE_ONCOMING_SENS_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_DARK_SCENE_ONCOMING_SENS_V( CORELIGHTSCENEINITDARKSCENEONCOMINGSENSV * pDARK_SCENE_ONCOMING_SENS_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITDARKSCENEONCOMINGSENSV signal_value;
   
   if( pDARK_SCENE_ONCOMING_SENS_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.DARK_SCENE_ONCOMING_SENS_V_b1;
      * pDARK_SCENE_ONCOMING_SENS_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_DARK_SCENE_ONCOMING_SENS
*
* FUNCTION ARGUMENTS:
*    uint8 * pDARK_SCENE_ONCOMING_SENS - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of DARK_SCENE_ONCOMING_SENS
*    DARK_SCENE_ONCOMING_SENS returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns DARK_SCENE_ONCOMING_SENS signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_DARK_SCENE_ONCOMING_SENS( uint8 * pDARK_SCENE_ONCOMING_SENS )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pDARK_SCENE_ONCOMING_SENS != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.DARK_SCENE_ONCOMING_SENS_b8;
      * pDARK_SCENE_ONCOMING_SENS = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_DARK_SCENE_ONCOMING_SENS_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_28_V
*
* FUNCTION ARGUMENTS:
*    boolean * pILS_Buffer_28_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_28_V
*    ILS_Buffer_28_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_28_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_28_V( boolean * pILS_Buffer_28_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pILS_Buffer_28_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_28_V_b1;
      * pILS_Buffer_28_V = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_28_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_28
*
* FUNCTION ARGUMENTS:
*    uint8 * pILS_Buffer_28 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_28
*    ILS_Buffer_28 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_28 signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_28( uint8 * pILS_Buffer_28 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pILS_Buffer_28 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_28_b4;
      * pILS_Buffer_28 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_28_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_DARK_SCENE_TAILLIGHT_SENS_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITDARKSCENETAILLIGHTSENSV * pDARK_SCENE_TAILLIGHT_SENS_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of DARK_SCENE_TAILLIGHT_SENS_V
*    DARK_SCENE_TAILLIGHT_SENS_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns DARK_SCENE_TAILLIGHT_SENS_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_DARK_SCENE_TAILLIGHT_SENS_V( CORELIGHTSCENEINITDARKSCENETAILLIGHTSENSV * pDARK_SCENE_TAILLIGHT_SENS_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITDARKSCENETAILLIGHTSENSV signal_value;
   
   if( pDARK_SCENE_TAILLIGHT_SENS_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.DARK_SCENE_TAILLIGHT_SENS_V_b1;
      * pDARK_SCENE_TAILLIGHT_SENS_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_DARK_SCENE_TAILLIGHT_SENS
*
* FUNCTION ARGUMENTS:
*    uint8 * pDARK_SCENE_TAILLIGHT_SENS - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of DARK_SCENE_TAILLIGHT_SENS
*    DARK_SCENE_TAILLIGHT_SENS returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns DARK_SCENE_TAILLIGHT_SENS signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_DARK_SCENE_TAILLIGHT_SENS( uint8 * pDARK_SCENE_TAILLIGHT_SENS )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pDARK_SCENE_TAILLIGHT_SENS != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.DARK_SCENE_TAILLIGHT_SENS_b8;
      * pDARK_SCENE_TAILLIGHT_SENS = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_DARK_SCENE_TAILLIGHT_SENS_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_DELAY_HLB_FULL_TO_INACTIVE_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITDELAYHLBFULLTOINACTIVEV * pDELAY_HLB_FULL_TO_INACTIVE_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of DELAY_HLB_FULL_TO_INACTIVE_V
*    DELAY_HLB_FULL_TO_INACTIVE_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns DELAY_HLB_FULL_TO_INACTIVE_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_DELAY_HLB_FULL_TO_INACTIVE_V( CORELIGHTSCENEINITDELAYHLBFULLTOINACTIVEV * pDELAY_HLB_FULL_TO_INACTIVE_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITDELAYHLBFULLTOINACTIVEV signal_value;
   
   if( pDELAY_HLB_FULL_TO_INACTIVE_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.DELAY_HLB_FULL_TO_INACTIVE_V_b1;
      * pDELAY_HLB_FULL_TO_INACTIVE_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_DELAY_HLB_FULL_TO_INACTIVE
*
* FUNCTION ARGUMENTS:
*    uint16 * pDELAY_HLB_FULL_TO_INACTIVE - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of DELAY_HLB_FULL_TO_INACTIVE
*    DELAY_HLB_FULL_TO_INACTIVE returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns DELAY_HLB_FULL_TO_INACTIVE signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_DELAY_HLB_FULL_TO_INACTIVE( uint16 * pDELAY_HLB_FULL_TO_INACTIVE )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pDELAY_HLB_FULL_TO_INACTIVE != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.DELAY_HLB_FULL_TO_INACTIVE_b13;
      * pDELAY_HLB_FULL_TO_INACTIVE = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_DELAY_HLB_FULL_TO_INACTIVE_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_29_V
*
* FUNCTION ARGUMENTS:
*    boolean * pILS_Buffer_29_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_29_V
*    ILS_Buffer_29_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_29_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_29_V( boolean * pILS_Buffer_29_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pILS_Buffer_29_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_29_V_b1;
      * pILS_Buffer_29_V = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_29_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_29
*
* FUNCTION ARGUMENTS:
*    uint8 * pILS_Buffer_29 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_29
*    ILS_Buffer_29 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_29 signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_29( uint8 * pILS_Buffer_29 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pILS_Buffer_29 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_29_b8;
      * pILS_Buffer_29 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_29_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_DELAY_HLB_INACTIVE_TO_FULL_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITDELAYHLBINACTIVETOFULLV * pDELAY_HLB_INACTIVE_TO_FULL_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of DELAY_HLB_INACTIVE_TO_FULL_V
*    DELAY_HLB_INACTIVE_TO_FULL_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns DELAY_HLB_INACTIVE_TO_FULL_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_DELAY_HLB_INACTIVE_TO_FULL_V( CORELIGHTSCENEINITDELAYHLBINACTIVETOFULLV * pDELAY_HLB_INACTIVE_TO_FULL_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITDELAYHLBINACTIVETOFULLV signal_value;
   
   if( pDELAY_HLB_INACTIVE_TO_FULL_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.DELAY_HLB_INACTIVE_TO_FULL_V_b1;
      * pDELAY_HLB_INACTIVE_TO_FULL_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_DELAY_HLB_INACTIVE_TO_FULL
*
* FUNCTION ARGUMENTS:
*    uint32 * pDELAY_HLB_INACTIVE_TO_FULL - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of DELAY_HLB_INACTIVE_TO_FULL
*    DELAY_HLB_INACTIVE_TO_FULL returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns DELAY_HLB_INACTIVE_TO_FULL signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_DELAY_HLB_INACTIVE_TO_FULL( uint32 * pDELAY_HLB_INACTIVE_TO_FULL )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pDELAY_HLB_INACTIVE_TO_FULL != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.DELAY_HLB_INACTIVE_TO_FULL_b18;
      * pDELAY_HLB_INACTIVE_TO_FULL = signal_value;
      if( (signal_value >= C_EYEQMSG_CORELIGHTSCENEINIT_DELAY_HLB_INACTIVE_TO_FULL_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_DELAY_HLB_INACTIVE_TO_FULL_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_HEADLIGHTS_HEIGHT_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITHEADLIGHTSHEIGHTV * pHEADLIGHTS_HEIGHT_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of HEADLIGHTS_HEIGHT_V
*    HEADLIGHTS_HEIGHT_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns HEADLIGHTS_HEIGHT_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_HEADLIGHTS_HEIGHT_V( CORELIGHTSCENEINITHEADLIGHTSHEIGHTV * pHEADLIGHTS_HEIGHT_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITHEADLIGHTSHEIGHTV signal_value;
   
   if( pHEADLIGHTS_HEIGHT_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.HEADLIGHTS_HEIGHT_V_b1;
      * pHEADLIGHTS_HEIGHT_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_HEADLIGHTS_HEIGHT
*
* FUNCTION ARGUMENTS:
*    uint8 * pHEADLIGHTS_HEIGHT - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of HEADLIGHTS_HEIGHT
*    HEADLIGHTS_HEIGHT returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns HEADLIGHTS_HEIGHT signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_HEADLIGHTS_HEIGHT( uint8 * pHEADLIGHTS_HEIGHT )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pHEADLIGHTS_HEIGHT != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.HEADLIGHTS_HEIGHT_b8;
      * pHEADLIGHTS_HEIGHT = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_NUM_MODELIF_STREET_LIGHTS_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITMAXNUMMODELIFSTREETLIGHTSV * pMAX_NUM_MODELIF_STREET_LIGHTS_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MAX_NUM_MODELIF_STREET_LIGHTS_V
*    MAX_NUM_MODELIF_STREET_LIGHTS_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MAX_NUM_MODELIF_STREET_LIGHTS_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_NUM_MODELIF_STREET_LIGHTS_V( CORELIGHTSCENEINITMAXNUMMODELIFSTREETLIGHTSV * pMAX_NUM_MODELIF_STREET_LIGHTS_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITMAXNUMMODELIFSTREETLIGHTSV signal_value;
   
   if( pMAX_NUM_MODELIF_STREET_LIGHTS_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.MAX_NUM_MODELIF_STREET_LIGHTS_V_b1;
      * pMAX_NUM_MODELIF_STREET_LIGHTS_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_NUM_MODELIF_STREET_LIGHTS
*
* FUNCTION ARGUMENTS:
*    uint8 * pMAX_NUM_MODELIF_STREET_LIGHTS - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MAX_NUM_MODELIF_STREET_LIGHTS
*    MAX_NUM_MODELIF_STREET_LIGHTS returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MAX_NUM_MODELIF_STREET_LIGHTS signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_MAX_NUM_MODELIF_STREET_LIGHTS( uint8 * pMAX_NUM_MODELIF_STREET_LIGHTS )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pMAX_NUM_MODELIF_STREET_LIGHTS != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.MAX_NUM_MODELIF_STREET_LIGHTS_b4;
      * pMAX_NUM_MODELIF_STREET_LIGHTS = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_MAX_NUM_MODELIF_STREET_LIGHTS_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_NO_HLB_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITNOHLBV * pNO_HLB_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of NO_HLB_V
*    NO_HLB_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns NO_HLB_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_NO_HLB_V( CORELIGHTSCENEINITNOHLBV * pNO_HLB_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITNOHLBV signal_value;
   
   if( pNO_HLB_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.NO_HLB_V_b1;
      * pNO_HLB_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_NO_HLB
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITNOHLB * pNO_HLB - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of NO_HLB
*    NO_HLB returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns NO_HLB signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_NO_HLB( CORELIGHTSCENEINITNOHLB * pNO_HLB )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITNOHLB signal_value;
   
   if( pNO_HLB != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.NO_HLB_b1;
      * pNO_HLB = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_NO_HLB_MODEL_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITNOHLBMODELV * pNO_HLB_MODEL_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of NO_HLB_MODEL_V
*    NO_HLB_MODEL_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns NO_HLB_MODEL_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_NO_HLB_MODEL_V( CORELIGHTSCENEINITNOHLBMODELV * pNO_HLB_MODEL_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITNOHLBMODELV signal_value;
   
   if( pNO_HLB_MODEL_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.NO_HLB_MODEL_V_b1;
      * pNO_HLB_MODEL_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_NO_HLB_MODEL
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITNOHLBMODEL * pNO_HLB_MODEL - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of NO_HLB_MODEL
*    NO_HLB_MODEL returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns NO_HLB_MODEL signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_NO_HLB_MODEL( CORELIGHTSCENEINITNOHLBMODEL * pNO_HLB_MODEL )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITNOHLBMODEL signal_value;
   
   if( pNO_HLB_MODEL != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.NO_HLB_MODEL_b1;
      * pNO_HLB_MODEL = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_REFLECTOR_MIN_BRIGHTNESS_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITREFLECTORMINBRIGHTNESSV * pREFLECTOR_MIN_BRIGHTNESS_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of REFLECTOR_MIN_BRIGHTNESS_V
*    REFLECTOR_MIN_BRIGHTNESS_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns REFLECTOR_MIN_BRIGHTNESS_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_REFLECTOR_MIN_BRIGHTNESS_V( CORELIGHTSCENEINITREFLECTORMINBRIGHTNESSV * pREFLECTOR_MIN_BRIGHTNESS_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITREFLECTORMINBRIGHTNESSV signal_value;
   
   if( pREFLECTOR_MIN_BRIGHTNESS_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.REFLECTOR_MIN_BRIGHTNESS_V_b1;
      * pREFLECTOR_MIN_BRIGHTNESS_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_REFLECTOR_MIN_BRIGHTNESS
*
* FUNCTION ARGUMENTS:
*    uint8 * pREFLECTOR_MIN_BRIGHTNESS - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of REFLECTOR_MIN_BRIGHTNESS
*    REFLECTOR_MIN_BRIGHTNESS returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns REFLECTOR_MIN_BRIGHTNESS signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_REFLECTOR_MIN_BRIGHTNESS( uint8 * pREFLECTOR_MIN_BRIGHTNESS )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pREFLECTOR_MIN_BRIGHTNESS != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.REFLECTOR_MIN_BRIGHTNESS_b7;
      * pREFLECTOR_MIN_BRIGHTNESS = signal_value;
      if( (signal_value >= C_EYEQMSG_CORELIGHTSCENEINIT_REFLECTOR_MIN_BRIGHTNESS_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_REFLECTOR_MIN_BRIGHTNESS_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_REFLECTOR_MIN_SIZE_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITREFLECTORMINSIZEV * pREFLECTOR_MIN_SIZE_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of REFLECTOR_MIN_SIZE_V
*    REFLECTOR_MIN_SIZE_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns REFLECTOR_MIN_SIZE_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_REFLECTOR_MIN_SIZE_V( CORELIGHTSCENEINITREFLECTORMINSIZEV * pREFLECTOR_MIN_SIZE_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITREFLECTORMINSIZEV signal_value;
   
   if( pREFLECTOR_MIN_SIZE_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.REFLECTOR_MIN_SIZE_V_b1;
      * pREFLECTOR_MIN_SIZE_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_REFLECTOR_MIN_SIZE
*
* FUNCTION ARGUMENTS:
*    uint16 * pREFLECTOR_MIN_SIZE - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of REFLECTOR_MIN_SIZE
*    REFLECTOR_MIN_SIZE returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns REFLECTOR_MIN_SIZE signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_REFLECTOR_MIN_SIZE( uint16 * pREFLECTOR_MIN_SIZE )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pREFLECTOR_MIN_SIZE != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.REFLECTOR_MIN_SIZE_b11;
      * pREFLECTOR_MIN_SIZE = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_REFLECTOR_MIN_SIZE_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_30_V
*
* FUNCTION ARGUMENTS:
*    boolean * pILS_Buffer_30_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_30_V
*    ILS_Buffer_30_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_30_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_30_V( boolean * pILS_Buffer_30_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pILS_Buffer_30_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_30_V_b1;
      * pILS_Buffer_30_V = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_30_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_30
*
* FUNCTION ARGUMENTS:
*    uint8 * pILS_Buffer_30 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_30
*    ILS_Buffer_30 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_30 signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_30( uint8 * pILS_Buffer_30 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pILS_Buffer_30 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_30_b6;
      * pILS_Buffer_30 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_30_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_REFLECTOR_ROI_X_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITREFLECTORROIXV * pREFLECTOR_ROI_X_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of REFLECTOR_ROI_X_V
*    REFLECTOR_ROI_X_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns REFLECTOR_ROI_X_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_REFLECTOR_ROI_X_V( CORELIGHTSCENEINITREFLECTORROIXV * pREFLECTOR_ROI_X_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITREFLECTORROIXV signal_value;
   
   if( pREFLECTOR_ROI_X_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.REFLECTOR_ROI_X_V_b1;
      * pREFLECTOR_ROI_X_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_REFLECTOR_ROI_X
*
* FUNCTION ARGUMENTS:
*    uint16 * pREFLECTOR_ROI_X - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of REFLECTOR_ROI_X
*    REFLECTOR_ROI_X returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns REFLECTOR_ROI_X signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_REFLECTOR_ROI_X( uint16 * pREFLECTOR_ROI_X )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pREFLECTOR_ROI_X != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.REFLECTOR_ROI_X_b13;
      * pREFLECTOR_ROI_X = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_REFLECTOR_ROI_X_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_REFLECTOR_ROI_Y_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITREFLECTORROIYV * pREFLECTOR_ROI_Y_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of REFLECTOR_ROI_Y_V
*    REFLECTOR_ROI_Y_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns REFLECTOR_ROI_Y_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_REFLECTOR_ROI_Y_V( CORELIGHTSCENEINITREFLECTORROIYV * pREFLECTOR_ROI_Y_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITREFLECTORROIYV signal_value;
   
   if( pREFLECTOR_ROI_Y_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.REFLECTOR_ROI_Y_V_b1;
      * pREFLECTOR_ROI_Y_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_REFLECTOR_ROI_Y
*
* FUNCTION ARGUMENTS:
*    uint16 * pREFLECTOR_ROI_Y - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of REFLECTOR_ROI_Y
*    REFLECTOR_ROI_Y returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns REFLECTOR_ROI_Y signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_REFLECTOR_ROI_Y( uint16 * pREFLECTOR_ROI_Y )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pREFLECTOR_ROI_Y != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.REFLECTOR_ROI_Y_b11;
      * pREFLECTOR_ROI_Y = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_REFLECTOR_ROI_Y_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_31_V
*
* FUNCTION ARGUMENTS:
*    boolean * pILS_Buffer_31_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_31_V
*    ILS_Buffer_31_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_31_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_31_V( boolean * pILS_Buffer_31_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pILS_Buffer_31_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_31_V_b1;
      * pILS_Buffer_31_V = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_31_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_31
*
* FUNCTION ARGUMENTS:
*    uint8 * pILS_Buffer_31 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_31
*    ILS_Buffer_31 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_31 signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_31( uint8 * pILS_Buffer_31 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pILS_Buffer_31 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_31_b5;
      * pILS_Buffer_31 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_31_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_SL_MAX_GRACE_DIST_HIGH_SPEED_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITSLMAXGRACEDISTHIGHSPEEDV * pSL_MAX_GRACE_DIST_HIGH_SPEED_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SL_MAX_GRACE_DIST_HIGH_SPEED_V
*    SL_MAX_GRACE_DIST_HIGH_SPEED_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SL_MAX_GRACE_DIST_HIGH_SPEED_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_SL_MAX_GRACE_DIST_HIGH_SPEED_V( CORELIGHTSCENEINITSLMAXGRACEDISTHIGHSPEEDV * pSL_MAX_GRACE_DIST_HIGH_SPEED_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITSLMAXGRACEDISTHIGHSPEEDV signal_value;
   
   if( pSL_MAX_GRACE_DIST_HIGH_SPEED_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.SL_MAX_GRACE_DIST_HIGH_SPEED_V_b1;
      * pSL_MAX_GRACE_DIST_HIGH_SPEED_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_SL_MAX_GRACE_DIST_HIGH_SPEED
*
* FUNCTION ARGUMENTS:
*    uint8 * pSL_MAX_GRACE_DIST_HIGH_SPEED - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SL_MAX_GRACE_DIST_HIGH_SPEED
*    SL_MAX_GRACE_DIST_HIGH_SPEED returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SL_MAX_GRACE_DIST_HIGH_SPEED signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_SL_MAX_GRACE_DIST_HIGH_SPEED( uint8 * pSL_MAX_GRACE_DIST_HIGH_SPEED )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pSL_MAX_GRACE_DIST_HIGH_SPEED != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.SL_MAX_GRACE_DIST_HIGH_SPEED_b8;
      * pSL_MAX_GRACE_DIST_HIGH_SPEED = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_SL_MAX_GRACE_DIST_HIGH_SPEED_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_SL_MAX_GRACE_DIST_LOW_SPEED_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITSLMAXGRACEDISTLOWSPEEDV * pSL_MAX_GRACE_DIST_LOW_SPEED_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SL_MAX_GRACE_DIST_LOW_SPEED_V
*    SL_MAX_GRACE_DIST_LOW_SPEED_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SL_MAX_GRACE_DIST_LOW_SPEED_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_SL_MAX_GRACE_DIST_LOW_SPEED_V( CORELIGHTSCENEINITSLMAXGRACEDISTLOWSPEEDV * pSL_MAX_GRACE_DIST_LOW_SPEED_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITSLMAXGRACEDISTLOWSPEEDV signal_value;
   
   if( pSL_MAX_GRACE_DIST_LOW_SPEED_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.SL_MAX_GRACE_DIST_LOW_SPEED_V_b1;
      * pSL_MAX_GRACE_DIST_LOW_SPEED_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_SL_MAX_GRACE_DIST_LOW_SPEED
*
* FUNCTION ARGUMENTS:
*    uint8 * pSL_MAX_GRACE_DIST_LOW_SPEED - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SL_MAX_GRACE_DIST_LOW_SPEED
*    SL_MAX_GRACE_DIST_LOW_SPEED returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SL_MAX_GRACE_DIST_LOW_SPEED signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_SL_MAX_GRACE_DIST_LOW_SPEED( uint8 * pSL_MAX_GRACE_DIST_LOW_SPEED )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pSL_MAX_GRACE_DIST_LOW_SPEED != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.SL_MAX_GRACE_DIST_LOW_SPEED_b8;
      * pSL_MAX_GRACE_DIST_LOW_SPEED = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_SL_MAX_GRACE_DIST_LOW_SPEED_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_SL_MAX_GRACE_DIST_VILL_SPEED_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITSLMAXGRACEDISTVILLSPEEDV * pSL_MAX_GRACE_DIST_VILL_SPEED_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SL_MAX_GRACE_DIST_VILL_SPEED_V
*    SL_MAX_GRACE_DIST_VILL_SPEED_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SL_MAX_GRACE_DIST_VILL_SPEED_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_SL_MAX_GRACE_DIST_VILL_SPEED_V( CORELIGHTSCENEINITSLMAXGRACEDISTVILLSPEEDV * pSL_MAX_GRACE_DIST_VILL_SPEED_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITSLMAXGRACEDISTVILLSPEEDV signal_value;
   
   if( pSL_MAX_GRACE_DIST_VILL_SPEED_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.SL_MAX_GRACE_DIST_VILL_SPEED_V_b1;
      * pSL_MAX_GRACE_DIST_VILL_SPEED_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_SL_MAX_GRACE_DIST_VILL_SPEED
*
* FUNCTION ARGUMENTS:
*    uint8 * pSL_MAX_GRACE_DIST_VILL_SPEED - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SL_MAX_GRACE_DIST_VILL_SPEED
*    SL_MAX_GRACE_DIST_VILL_SPEED returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SL_MAX_GRACE_DIST_VILL_SPEED signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_SL_MAX_GRACE_DIST_VILL_SPEED( uint8 * pSL_MAX_GRACE_DIST_VILL_SPEED )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pSL_MAX_GRACE_DIST_VILL_SPEED != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.SL_MAX_GRACE_DIST_VILL_SPEED_b8;
      * pSL_MAX_GRACE_DIST_VILL_SPEED = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_SL_MAX_GRACE_DIST_VILL_SPEED_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_32_V
*
* FUNCTION ARGUMENTS:
*    boolean * pILS_Buffer_32_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_32_V
*    ILS_Buffer_32_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_32_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_32_V( boolean * pILS_Buffer_32_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pILS_Buffer_32_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_32_V_b1;
      * pILS_Buffer_32_V = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_32_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_32
*
* FUNCTION ARGUMENTS:
*    uint8 * pILS_Buffer_32 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_32
*    ILS_Buffer_32 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_32 signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_32( uint8 * pILS_Buffer_32 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pILS_Buffer_32 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_32_b4;
      * pILS_Buffer_32 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_32_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_TAILLIGHTS_HEIGHT_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITTAILLIGHTSHEIGHTV * pTAILLIGHTS_HEIGHT_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TAILLIGHTS_HEIGHT_V
*    TAILLIGHTS_HEIGHT_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TAILLIGHTS_HEIGHT_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_TAILLIGHTS_HEIGHT_V( CORELIGHTSCENEINITTAILLIGHTSHEIGHTV * pTAILLIGHTS_HEIGHT_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITTAILLIGHTSHEIGHTV signal_value;
   
   if( pTAILLIGHTS_HEIGHT_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.TAILLIGHTS_HEIGHT_V_b1;
      * pTAILLIGHTS_HEIGHT_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_TAILLIGHTS_HEIGHT
*
* FUNCTION ARGUMENTS:
*    uint8 * pTAILLIGHTS_HEIGHT - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TAILLIGHTS_HEIGHT
*    TAILLIGHTS_HEIGHT returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TAILLIGHTS_HEIGHT signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_TAILLIGHTS_HEIGHT( uint8 * pTAILLIGHTS_HEIGHT )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pTAILLIGHTS_HEIGHT != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.TAILLIGHTS_HEIGHT_b8;
      * pTAILLIGHTS_HEIGHT = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_LSI_Buffer_C0
*
* FUNCTION ARGUMENTS:
*    boolean * pLSI_Buffer_C0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSI_Buffer_C0
*    LSI_Buffer_C0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSI_Buffer_C0 signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_LSI_Buffer_C0( boolean * pLSI_Buffer_C0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pLSI_Buffer_C0 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.LSI_Buffer_C0_b1;
      * pLSI_Buffer_C0 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_LSI_Buffer_C1
*
* FUNCTION ARGUMENTS:
*    boolean * pLSI_Buffer_C1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSI_Buffer_C1
*    LSI_Buffer_C1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSI_Buffer_C1 signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_LSI_Buffer_C1( boolean * pLSI_Buffer_C1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pLSI_Buffer_C1 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.LSI_Buffer_C1_b1;
      * pLSI_Buffer_C1 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_LSI_Buffer_C2
*
* FUNCTION ARGUMENTS:
*    boolean * pLSI_Buffer_C2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSI_Buffer_C2
*    LSI_Buffer_C2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSI_Buffer_C2 signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_LSI_Buffer_C2( boolean * pLSI_Buffer_C2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pLSI_Buffer_C2 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.LSI_Buffer_C2_b1;
      * pLSI_Buffer_C2 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_LSI_Buffer_C3
*
* FUNCTION ARGUMENTS:
*    boolean * pLSI_Buffer_C3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSI_Buffer_C3
*    LSI_Buffer_C3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSI_Buffer_C3 signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_LSI_Buffer_C3( boolean * pLSI_Buffer_C3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pLSI_Buffer_C3 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.LSI_Buffer_C3_b1;
      * pLSI_Buffer_C3 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_LSI_Buffer_C4
*
* FUNCTION ARGUMENTS:
*    boolean * pLSI_Buffer_C4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSI_Buffer_C4
*    LSI_Buffer_C4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSI_Buffer_C4 signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_LSI_Buffer_C4( boolean * pLSI_Buffer_C4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pLSI_Buffer_C4 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.LSI_Buffer_C4_b1;
      * pLSI_Buffer_C4 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_LSI_Buffer_C5
*
* FUNCTION ARGUMENTS:
*    boolean * pLSI_Buffer_C5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSI_Buffer_C5
*    LSI_Buffer_C5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSI_Buffer_C5 signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_LSI_Buffer_C5( boolean * pLSI_Buffer_C5 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pLSI_Buffer_C5 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.LSI_Buffer_C5_b1;
      * pLSI_Buffer_C5 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_LN_ONLY_SL_SPEED_EXIT_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITLNONLYSLSPEEDEXITV * pLN_ONLY_SL_SPEED_EXIT_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LN_ONLY_SL_SPEED_EXIT_V
*    LN_ONLY_SL_SPEED_EXIT_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LN_ONLY_SL_SPEED_EXIT_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_LN_ONLY_SL_SPEED_EXIT_V( CORELIGHTSCENEINITLNONLYSLSPEEDEXITV * pLN_ONLY_SL_SPEED_EXIT_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITLNONLYSLSPEEDEXITV signal_value;
   
   if( pLN_ONLY_SL_SPEED_EXIT_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.LN_ONLY_SL_SPEED_EXIT_V_b1;
      * pLN_ONLY_SL_SPEED_EXIT_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_LN_ONLY_SL_SPEED_EXIT
*
* FUNCTION ARGUMENTS:
*    uint8 * pLN_ONLY_SL_SPEED_EXIT - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LN_ONLY_SL_SPEED_EXIT
*    LN_ONLY_SL_SPEED_EXIT returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LN_ONLY_SL_SPEED_EXIT signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_LN_ONLY_SL_SPEED_EXIT( uint8 * pLN_ONLY_SL_SPEED_EXIT )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pLN_ONLY_SL_SPEED_EXIT != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.LN_ONLY_SL_SPEED_EXIT_b8;
      * pLN_ONLY_SL_SPEED_EXIT = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_LN_ONLY_SL_SPEED_ENTER_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITLNONLYSLSPEEDENTERV * pLN_ONLY_SL_SPEED_ENTER_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LN_ONLY_SL_SPEED_ENTER_V
*    LN_ONLY_SL_SPEED_ENTER_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LN_ONLY_SL_SPEED_ENTER_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_LN_ONLY_SL_SPEED_ENTER_V( CORELIGHTSCENEINITLNONLYSLSPEEDENTERV * pLN_ONLY_SL_SPEED_ENTER_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITLNONLYSLSPEEDENTERV signal_value;
   
   if( pLN_ONLY_SL_SPEED_ENTER_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.LN_ONLY_SL_SPEED_ENTER_V_b1;
      * pLN_ONLY_SL_SPEED_ENTER_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_LN_ONLY_SL_SPEED_ENTER
*
* FUNCTION ARGUMENTS:
*    uint8 * pLN_ONLY_SL_SPEED_ENTER - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LN_ONLY_SL_SPEED_ENTER
*    LN_ONLY_SL_SPEED_ENTER returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LN_ONLY_SL_SPEED_ENTER signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_LN_ONLY_SL_SPEED_ENTER( uint8 * pLN_ONLY_SL_SPEED_ENTER )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pLN_ONLY_SL_SPEED_ENTER != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.LN_ONLY_SL_SPEED_ENTER_b8;
      * pLN_ONLY_SL_SPEED_ENTER = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_LSI_Buffer_C6
*
* FUNCTION ARGUMENTS:
*    boolean * pLSI_Buffer_C6 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSI_Buffer_C6
*    LSI_Buffer_C6 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSI_Buffer_C6 signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_LSI_Buffer_C6( boolean * pLSI_Buffer_C6 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pLSI_Buffer_C6 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.LSI_Buffer_C6_b1;
      * pLSI_Buffer_C6 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_LSI_Buffer_C7
*
* FUNCTION ARGUMENTS:
*    boolean * pLSI_Buffer_C7 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSI_Buffer_C7
*    LSI_Buffer_C7 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSI_Buffer_C7 signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_LSI_Buffer_C7( boolean * pLSI_Buffer_C7 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pLSI_Buffer_C7 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.LSI_Buffer_C7_b1;
      * pLSI_Buffer_C7 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_LSI_Buffer_C8
*
* FUNCTION ARGUMENTS:
*    boolean * pLSI_Buffer_C8 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSI_Buffer_C8
*    LSI_Buffer_C8 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSI_Buffer_C8 signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_LSI_Buffer_C8( boolean * pLSI_Buffer_C8 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pLSI_Buffer_C8 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.LSI_Buffer_C8_b1;
      * pLSI_Buffer_C8 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_LSI_BUFFER_C8_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_LSI_Buffer_C9
*
* FUNCTION ARGUMENTS:
*    uint16 * pLSI_Buffer_C9 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSI_Buffer_C9
*    LSI_Buffer_C9 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSI_Buffer_C9 signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_LSI_Buffer_C9( uint16 * pLSI_Buffer_C9 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pLSI_Buffer_C9 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.LSI_Buffer_C9_b9;
      * pLSI_Buffer_C9 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_LSI_BUFFER_C9_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_LSI_Buffer_C10
*
* FUNCTION ARGUMENTS:
*    boolean * pLSI_Buffer_C10 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSI_Buffer_C10
*    LSI_Buffer_C10 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSI_Buffer_C10 signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_LSI_Buffer_C10( boolean * pLSI_Buffer_C10 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pLSI_Buffer_C10 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.LSI_Buffer_C10_b1;
      * pLSI_Buffer_C10 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_LSI_BUFFER_C10_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_LSI_Buffer_C11
*
* FUNCTION ARGUMENTS:
*    boolean * pLSI_Buffer_C11 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSI_Buffer_C11
*    LSI_Buffer_C11 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSI_Buffer_C11 signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_LSI_Buffer_C11( boolean * pLSI_Buffer_C11 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pLSI_Buffer_C11 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.LSI_Buffer_C11_b1;
      * pLSI_Buffer_C11 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_LSI_BUFFER_C11_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_DETECTION_SENSITIVITY_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITDETECTIONSENSITIVITYV * pDETECTION_SENSITIVITY_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of DETECTION_SENSITIVITY_V
*    DETECTION_SENSITIVITY_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns DETECTION_SENSITIVITY_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_DETECTION_SENSITIVITY_V( CORELIGHTSCENEINITDETECTIONSENSITIVITYV * pDETECTION_SENSITIVITY_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITDETECTIONSENSITIVITYV signal_value;
   
   if( pDETECTION_SENSITIVITY_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.DETECTION_SENSITIVITY_V_b1;
      * pDETECTION_SENSITIVITY_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_DETECTION_SENSITIVITY
*
* FUNCTION ARGUMENTS:
*    uint8 * pDETECTION_SENSITIVITY - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of DETECTION_SENSITIVITY
*    DETECTION_SENSITIVITY returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns DETECTION_SENSITIVITY signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_DETECTION_SENSITIVITY( uint8 * pDETECTION_SENSITIVITY )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pDETECTION_SENSITIVITY != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.DETECTION_SENSITIVITY_b4;
      * pDETECTION_SENSITIVITY = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_DETECTION_SENSITIVITY_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_LSI_Buffer_C12
*
* FUNCTION ARGUMENTS:
*    boolean * pLSI_Buffer_C12 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSI_Buffer_C12
*    LSI_Buffer_C12 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSI_Buffer_C12 signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_LSI_Buffer_C12( boolean * pLSI_Buffer_C12 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pLSI_Buffer_C12 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.LSI_Buffer_C12_b1;
      * pLSI_Buffer_C12 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_LSI_BUFFER_C12_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_LSI_Buffer_C13
*
* FUNCTION ARGUMENTS:
*    uint16 * pLSI_Buffer_C13 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSI_Buffer_C13
*    LSI_Buffer_C13 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSI_Buffer_C13 signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_LSI_Buffer_C13( uint16 * pLSI_Buffer_C13 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pLSI_Buffer_C13 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.LSI_Buffer_C13_b9;
      * pLSI_Buffer_C13 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_LSI_BUFFER_C13_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_LSI_Buffer_C14
*
* FUNCTION ARGUMENTS:
*    boolean * pLSI_Buffer_C14 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSI_Buffer_C14
*    LSI_Buffer_C14 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSI_Buffer_C14 signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_LSI_Buffer_C14( boolean * pLSI_Buffer_C14 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pLSI_Buffer_C14 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.LSI_Buffer_C14_b1;
      * pLSI_Buffer_C14 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_LSI_BUFFER_C14_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_33_V
*
* FUNCTION ARGUMENTS:
*    boolean * pILS_Buffer_33_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_33_V
*    ILS_Buffer_33_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_33_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_33_V( boolean * pILS_Buffer_33_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pILS_Buffer_33_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_33_V_b1;
      * pILS_Buffer_33_V = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_33_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_33
*
* FUNCTION ARGUMENTS:
*    boolean * pILS_Buffer_33 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILS_Buffer_33
*    ILS_Buffer_33 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILS_Buffer_33 signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_ILS_Buffer_33( boolean * pILS_Buffer_33 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pILS_Buffer_33 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.ILS_Buffer_33_b1;
      * pILS_Buffer_33 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_ILS_BUFFER_33_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_LSI_Buffer_C15
*
* FUNCTION ARGUMENTS:
*    uint16 * pLSI_Buffer_C15 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSI_Buffer_C15
*    LSI_Buffer_C15 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSI_Buffer_C15 signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_LSI_Buffer_C15( uint16 * pLSI_Buffer_C15 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pLSI_Buffer_C15 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.LSI_Buffer_C15_b9;
      * pLSI_Buffer_C15 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_LSI_BUFFER_C15_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_USE_SINGLE_OBJECT_CLUSTERING_V
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITUSESINGLEOBJECTCLUSTERINGV * pUSE_SINGLE_OBJECT_CLUSTERING_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of USE_SINGLE_OBJECT_CLUSTERING_V
*    USE_SINGLE_OBJECT_CLUSTERING_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns USE_SINGLE_OBJECT_CLUSTERING_V signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_USE_SINGLE_OBJECT_CLUSTERING_V( CORELIGHTSCENEINITUSESINGLEOBJECTCLUSTERINGV * pUSE_SINGLE_OBJECT_CLUSTERING_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITUSESINGLEOBJECTCLUSTERINGV signal_value;
   
   if( pUSE_SINGLE_OBJECT_CLUSTERING_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.USE_SINGLE_OBJECT_CLUSTERING_V_b1;
      * pUSE_SINGLE_OBJECT_CLUSTERING_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_USE_SINGLE_OBJECT_CLUSTERING
*
* FUNCTION ARGUMENTS:
*    CORELIGHTSCENEINITUSESINGLEOBJECTCLUSTERING * pUSE_SINGLE_OBJECT_CLUSTERING - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of USE_SINGLE_OBJECT_CLUSTERING
*    USE_SINGLE_OBJECT_CLUSTERING returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns USE_SINGLE_OBJECT_CLUSTERING signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_USE_SINGLE_OBJECT_CLUSTERING( CORELIGHTSCENEINITUSESINGLEOBJECTCLUSTERING * pUSE_SINGLE_OBJECT_CLUSTERING )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTSCENEINITUSESINGLEOBJECTCLUSTERING signal_value;
   
   if( pUSE_SINGLE_OBJECT_CLUSTERING != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.USE_SINGLE_OBJECT_CLUSTERING_b1;
      * pUSE_SINGLE_OBJECT_CLUSTERING = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTSCENEINIT_Reserved_1
*
* FUNCTION ARGUMENTS:
*    uint32 * pReserved_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1
*    Reserved_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1 signal value of Light_Scene_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTSCENEINIT_Reserved_1( uint32 * pReserved_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pReserved_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTSCENEINIT_ParamsApp_s.Reserved_1_b21;
      * pReserved_1 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTSCENEINIT_RESERVED_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

