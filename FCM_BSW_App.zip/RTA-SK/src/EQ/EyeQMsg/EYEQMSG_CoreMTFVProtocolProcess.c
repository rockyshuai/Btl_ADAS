

/*****************************************************************************
                  Include files
*****************************************************************************/
/* The suggested include file order is: */
#include "EyeQ_defs.h"    /* EyeQ project common definitions file    */

#include "EYEQMSG_CoreMTFVProtocolProcess.h"

/*****************************************************************************
                  Local symbolic constants
*****************************************************************************/
/*****************************************************************************
                  Local types, enums definitions
*****************************************************************************/
/*****************************************************************************
                  Local function prototypes
*****************************************************************************/
/*****************************************************************************
                  Local object definitions
*****************************************************************************/
/*****************************************************************************
                  Exported object definitions
*****************************************************************************/
EYEQMSG_COREMTFV_Params_t   EYEQMSG_COREMTFV_Params_s;
EYEQMSG_COREMTFV_Params_t   EYEQMSG_COREMTFV_ParamsApp_s;
/*****************************************************************************
                  Local function-like macros
*****************************************************************************/
/*****************************************************************************
                  Local defined macros
*****************************************************************************/
/*****************************************************************************
                  Function definitions
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREMTFVvH_MTFV_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pMTFV_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MTFV_Zero_byte
*    MTFV_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MTFV_Zero_byte signal value of Virtual_HEADER_msg_Core_MTFV_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREMTFVvH_MTFV_Zero_byte( uint8 * pMTFV_Zero_byte )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pMTFV_Zero_byte != C_NULL_P )
   {
      signal_value = EYEQMSG_COREMTFV_ParamsApp_s.EYEQMSG_COREMTFVvH_Params_s.MTFV_Zero_byte_b8;
      * pMTFV_Zero_byte = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREMTFVvH_MTFV_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pMTFV_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MTFV_Protocol_Version
*    MTFV_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MTFV_Protocol_Version signal value of Virtual_HEADER_msg_Core_MTFV_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREMTFVvH_MTFV_Protocol_Version( uint8 * pMTFV_Protocol_Version )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pMTFV_Protocol_Version != C_NULL_P )
   {
      signal_value = EYEQMSG_COREMTFV_ParamsApp_s.EYEQMSG_COREMTFVvH_Params_s.MTFV_Protocol_Version_b8;
      * pMTFV_Protocol_Version = signal_value;
      if( (signal_value >= C_EYEQMSG_COREMTFVvH_MTFV_PROTOCOL_VERSION_RMIN ) 
          && (signal_value <= C_EYEQMSG_COREMTFVvH_MTFV_PROTOCOL_VERSION_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREMTFVvH_MTFV_Sync_ID
*
* FUNCTION ARGUMENTS:
*    uint8 * pMTFV_Sync_ID - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MTFV_Sync_ID
*    MTFV_Sync_ID returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MTFV_Sync_ID signal value of Virtual_HEADER_msg_Core_MTFV_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREMTFVvH_MTFV_Sync_ID( uint8 * pMTFV_Sync_ID )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pMTFV_Sync_ID != C_NULL_P )
   {
      signal_value = EYEQMSG_COREMTFV_ParamsApp_s.EYEQMSG_COREMTFVvH_Params_s.MTFV_Sync_ID_b8;
      * pMTFV_Sync_ID = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREMTFVvH_MTFV_Number_of_points
*
* FUNCTION ARGUMENTS:
*    uint8 * pMTFV_Number_of_points - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MTFV_Number_of_points
*    MTFV_Number_of_points returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MTFV_Number_of_points signal value of Virtual_HEADER_msg_Core_MTFV_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREMTFVvH_MTFV_Number_of_points( uint8 * pMTFV_Number_of_points )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pMTFV_Number_of_points != C_NULL_P )
   {
      signal_value = EYEQMSG_COREMTFV_ParamsApp_s.EYEQMSG_COREMTFVvH_Params_s.MTFV_Number_of_points_b4;
      * pMTFV_Number_of_points = signal_value;
      if( signal_value <= C_EYEQMSG_COREMTFVvH_MTFV_NUMBER_OF_POINTS_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREMTFVvH_MTFV_Status
*
* FUNCTION ARGUMENTS:
*    COREMTFVvHMTFVStatus * pMTFV_Status - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MTFV_Status
*    MTFV_Status returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MTFV_Status signal value of Virtual_HEADER_msg_Core_MTFV_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREMTFVvH_MTFV_Status( COREMTFVvHMTFVStatus * pMTFV_Status )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREMTFVvHMTFVStatus signal_value;
   
   if( pMTFV_Status != C_NULL_P )
   {
      signal_value = EYEQMSG_COREMTFV_ParamsApp_s.EYEQMSG_COREMTFVvH_Params_s.MTFV_Status_b3;
      * pMTFV_Status = signal_value;
      if( signal_value <= C_EYEQMSG_COREMTFVvH_MTFV_STATUS_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREMTFVvH_Reserved_1
*
* FUNCTION ARGUMENTS:
*    boolean * pReserved_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1
*    Reserved_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1 signal value of Virtual_HEADER_msg_Core_MTFV_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREMTFVvH_Reserved_1( boolean * pReserved_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pReserved_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREMTFV_ParamsApp_s.EYEQMSG_COREMTFVvH_Params_s.Reserved_1_b1;
      * pReserved_1 = signal_value;
      if( signal_value <= C_EYEQMSG_COREMTFVvH_RESERVED_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREMTFVvH_MTFV_Camera_Source
*
* FUNCTION ARGUMENTS:
*    COREMTFVvHMTFVCameraSource * pMTFV_Camera_Source - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MTFV_Camera_Source
*    MTFV_Camera_Source returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MTFV_Camera_Source signal value of Virtual_HEADER_msg_Core_MTFV_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREMTFVvH_MTFV_Camera_Source( COREMTFVvHMTFVCameraSource * pMTFV_Camera_Source )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREMTFVvHMTFVCameraSource signal_value;
   
   if( pMTFV_Camera_Source != C_NULL_P )
   {
      signal_value = EYEQMSG_COREMTFV_ParamsApp_s.EYEQMSG_COREMTFVvH_Params_s.MTFV_Camera_Source_b3;
      * pMTFV_Camera_Source = signal_value;
      if( signal_value <= C_EYEQMSG_COREMTFVvH_MTFV_CAMERA_SOURCE_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREMTFVvH_MTFV_Average_Image_Intensity
*
* FUNCTION ARGUMENTS:
*    uint16 * pMTFV_Average_Image_Intensity - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MTFV_Average_Image_Intensity
*    MTFV_Average_Image_Intensity returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MTFV_Average_Image_Intensity signal value of Virtual_HEADER_msg_Core_MTFV_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREMTFVvH_MTFV_Average_Image_Intensity( uint16 * pMTFV_Average_Image_Intensity )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pMTFV_Average_Image_Intensity != C_NULL_P )
   {
      signal_value = EYEQMSG_COREMTFV_ParamsApp_s.EYEQMSG_COREMTFVvH_Params_s.MTFV_Average_Image_Intensity_b12;
      * pMTFV_Average_Image_Intensity = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREMTFVvH_MTFV_Num_Saturated_Pixels
*
* FUNCTION ARGUMENTS:
*    uint8 * pMTFV_Num_Saturated_Pixels - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MTFV_Num_Saturated_Pixels
*    MTFV_Num_Saturated_Pixels returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MTFV_Num_Saturated_Pixels signal value of Virtual_HEADER_msg_Core_MTFV_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREMTFVvH_MTFV_Num_Saturated_Pixels( uint8 * pMTFV_Num_Saturated_Pixels )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pMTFV_Num_Saturated_Pixels != C_NULL_P )
   {
      signal_value = EYEQMSG_COREMTFV_ParamsApp_s.EYEQMSG_COREMTFVvH_Params_s.MTFV_Num_Saturated_Pixels_b5;
      * pMTFV_Num_Saturated_Pixels = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREMTFVvH_Reserved_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pReserved_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_2
*    Reserved_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_2 signal value of Virtual_HEADER_msg_Core_MTFV_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREMTFVvH_Reserved_2( uint16 * pReserved_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pReserved_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREMTFV_ParamsApp_s.EYEQMSG_COREMTFVvH_Params_s.Reserved_2_b12;
      * pReserved_2 = signal_value;
      if( signal_value <= C_EYEQMSG_COREMTFVvH_RESERVED_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREMTFVvO_MTFV_Point_TargetCenter_X_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pMTFV_Point_TargetCenter_X_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MTFV_Point_TargetCenter_X_0
*    MTFV_Point_TargetCenter_X_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MTFV_Point_TargetCenter_X_0 signal value of Virtual_OBJECT_msg_Core_MTFV_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREMTFVvO_MTFV_Point_TargetCenter_X_0( uint8 objIndx_u8, uint16 * pMTFV_Point_TargetCenter_X_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_MTFV_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREMTFVvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pMTFV_Point_TargetCenter_X_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREMTFV_ParamsApp_s.EYEQMSG_COREMTFVvO_Params_as[objIndx_u8].MTFV_Point_TargetCenter_X_0_b11;
         * pMTFV_Point_TargetCenter_X_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREMTFVvO_MTFV_POINT_TARGETCENTER_X_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREMTFVvO_MTFV_Point_TargetCenter_Y_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pMTFV_Point_TargetCenter_Y_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MTFV_Point_TargetCenter_Y_0
*    MTFV_Point_TargetCenter_Y_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MTFV_Point_TargetCenter_Y_0 signal value of Virtual_OBJECT_msg_Core_MTFV_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREMTFVvO_MTFV_Point_TargetCenter_Y_0( uint8 objIndx_u8, uint16 * pMTFV_Point_TargetCenter_Y_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_MTFV_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREMTFVvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pMTFV_Point_TargetCenter_Y_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREMTFV_ParamsApp_s.EYEQMSG_COREMTFVvO_Params_as[objIndx_u8].MTFV_Point_TargetCenter_Y_0_b11;
         * pMTFV_Point_TargetCenter_Y_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREMTFVvO_MTFV_POINT_TARGETCENTER_Y_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREMTFVvO_MTFV_Point_Value_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pMTFV_Point_Value_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MTFV_Point_Value_0
*    MTFV_Point_Value_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MTFV_Point_Value_0 signal value of Virtual_OBJECT_msg_Core_MTFV_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREMTFVvO_MTFV_Point_Value_0( uint8 objIndx_u8, uint8 * pMTFV_Point_Value_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_MTFV_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREMTFVvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pMTFV_Point_Value_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREMTFV_ParamsApp_s.EYEQMSG_COREMTFVvO_Params_as[objIndx_u8].MTFV_Point_Value_0_b8;
         * pMTFV_Point_Value_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREMTFVvO_MTFV_Point_Status_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREMTFVvOMTFVPointStatus0 * pMTFV_Point_Status_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MTFV_Point_Status_0
*    MTFV_Point_Status_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MTFV_Point_Status_0 signal value of Virtual_OBJECT_msg_Core_MTFV_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREMTFVvO_MTFV_Point_Status_0( uint8 objIndx_u8, COREMTFVvOMTFVPointStatus0 * pMTFV_Point_Status_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREMTFVvOMTFVPointStatus0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_MTFV_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREMTFVvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pMTFV_Point_Status_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREMTFV_ParamsApp_s.EYEQMSG_COREMTFVvO_Params_as[objIndx_u8].MTFV_Point_Status_0_b2;
         * pMTFV_Point_Status_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREMTFVvO_MTFV_POINT_STATUS_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_COREMTFV_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_COREMTFV_Params_t * pCore_MTFV_protocol - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_MTFV_protocol message 
*    Core_MTFV_protocol message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_MTFV_protocol message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_COREMTFV_ParamsApp_MsgDataStruct( EYEQMSG_COREMTFV_Params_t * pCore_MTFV_protocol )
{
   Std_ReturnType status = C_SIG_INVALID;
   if( pCore_MTFV_protocol != C_NULL_P )
   {
      status = C_SIG_VALID;
      * pCore_MTFV_protocol = EYEQMSG_COREMTFV_ParamsApp_s;
   }
   return ( status );
}

