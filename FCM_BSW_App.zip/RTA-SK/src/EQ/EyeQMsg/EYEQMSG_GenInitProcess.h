#ifndef _EYEQMSG_GENINITPROCESS_H_
#define _EYEQMSG_GENINITPROCESS_H_

/*****************************************************************************
                  Included header files
*****************************************************************************/
#include <Std_Types.h>

/*****************************************************************************
                  Include files
*****************************************************************************/
/*****************************************************************************
                  Exported symbolic constants
*****************************************************************************/

/* Datagram message ID */
#define C_EYEQMSG_GENINIT_MSG_ID                              ( 0xD3U )

/* Datagram message lengths */
#define C_EYEQMSG_GENINIT_MSG_LEN                             ( sizeof(EYEQMSG_GENINIT_Params_t) )

/* Protocol ENUMs */

/* MCU output messages */

/* General_Init Enums */
/* Reserved_2_b16 signal Min & Max range limits */
#define C_EYEQMSG_GENINIT_RESERVED_2_RMIN                     ( 0U )
#define C_EYEQMSG_GENINIT_RESERVED_2_RMAX                     ( 0U )
#define C_EYEQMSG_GENINIT_RESERVED_2_NUMR                     ( 1U )
#define C_EYEQMSG_GENINIT_RESERVED_2_DEMNR                    ( 1U )
#define C_EYEQMSG_GENINIT_RESERVED_2_OFFSET                   ( 0U )

/* IGeneral_Camera_Height_Base_b16 signal Min & Max range limits */
#define C_EYEQMSG_GENINIT_IGENERAL_CAMERA_HEIGHT_BASE_RMIN    ( 50U )
#define C_EYEQMSG_GENINIT_IGENERAL_CAMERA_HEIGHT_BASE_RMAX    ( 300U )
#define C_EYEQMSG_GENINIT_IGENERAL_CAMERA_HEIGHT_BASE_NUMR    ( 1U )
#define C_EYEQMSG_GENINIT_IGENERAL_CAMERA_HEIGHT_BASE_DEMNR   ( 100U )
#define C_EYEQMSG_GENINIT_IGENERAL_CAMERA_HEIGHT_BASE_OFFSET  ( 0U )

/* IGeneral_Yaw_Base_b16 signal Min & Max range limits */
#define C_EYEQMSG_GENINIT_IGENERAL_YAW_BASE_RMIN              ( 0U )
#define C_EYEQMSG_GENINIT_IGENERAL_YAW_BASE_RMAX              ( 500U )
#define C_EYEQMSG_GENINIT_IGENERAL_YAW_BASE_NUMR              ( 1 )
#define C_EYEQMSG_GENINIT_IGENERAL_YAW_BASE_DEMNR             ( 1 )
#define C_EYEQMSG_GENINIT_IGENERAL_YAW_BASE_OFFSET            ( -250 )

/* IGeneral_Pitch_Base_b16 signal Min & Max range limits */
#define C_EYEQMSG_GENINIT_IGENERAL_PITCH_BASE_RMIN            ( 0U )
#define C_EYEQMSG_GENINIT_IGENERAL_PITCH_BASE_RMAX            ( 1000U )
#define C_EYEQMSG_GENINIT_IGENERAL_PITCH_BASE_NUMR            ( 1 )
#define C_EYEQMSG_GENINIT_IGENERAL_PITCH_BASE_DEMNR           ( 1 )
#define C_EYEQMSG_GENINIT_IGENERAL_PITCH_BASE_OFFSET          ( -500 )

/* Reserved_1_b5 signal Min & Max range limits */
#define C_EYEQMSG_GENINIT_RESERVED_1_RMIN                     ( 0U )
#define C_EYEQMSG_GENINIT_RESERVED_1_RMAX                     ( 0U )
#define C_EYEQMSG_GENINIT_RESERVED_1_NUMR                     ( 1U )
#define C_EYEQMSG_GENINIT_RESERVED_1_DEMNR                    ( 1U )
#define C_EYEQMSG_GENINIT_RESERVED_1_OFFSET                   ( 0U )

/* IGeneral_Cam_Height_Full_b16 signal Min & Max range limits */
#define C_EYEQMSG_GENINIT_IGENERAL_CAM_HEIGHT_FULL_RMIN       ( 50U )
#define C_EYEQMSG_GENINIT_IGENERAL_CAM_HEIGHT_FULL_RMAX       ( 300U )
#define C_EYEQMSG_GENINIT_IGENERAL_CAM_HEIGHT_FULL_NUMR       ( 1U )
#define C_EYEQMSG_GENINIT_IGENERAL_CAM_HEIGHT_FULL_DEMNR      ( 100U )
#define C_EYEQMSG_GENINIT_IGENERAL_CAM_HEIGHT_FULL_OFFSET     ( 0U )

/* IGeneral_HIL_Mode_b1 signal Enums */
typedef boolean GENINITIGeneralHILMode;
#define C_EYEQMSG_GENINIT_IGENERAL_HIL_MODE_SET_OFF           ( GENINITIGeneralHILMode ) ( 0U )
#define C_EYEQMSG_GENINIT_IGENERAL_HIL_MODE_SET_ON            ( GENINITIGeneralHILMode ) ( 1U )

/* IGeneral_HIL_Mode_b1 signal Min & Max range limits */
#define C_EYEQMSG_GENINIT_IGENERAL_HIL_MODE_RMIN              ( 0U )
#define C_EYEQMSG_GENINIT_IGENERAL_HIL_MODE_RMAX              ( 1U )
#define C_EYEQMSG_GENINIT_IGENERAL_HIL_MODE_NUMR              ( 1U )
#define C_EYEQMSG_GENINIT_IGENERAL_HIL_MODE_DEMNR             ( 1U )
#define C_EYEQMSG_GENINIT_IGENERAL_HIL_MODE_OFFSET            ( 0U )

/* IGeneral_Driving_Side_b2 signal Enums */
typedef uint8 GENINITIGeneralDrivingSide;
#define C_EYEQMSG_GENINIT_IGENERAL_DRIVING_SIDE_UNKNOWN       ( GENINITIGeneralDrivingSide ) ( 0U )
#define C_EYEQMSG_GENINIT_IGENERAL_DRIVING_SIDE_LEFT          ( GENINITIGeneralDrivingSide ) ( 1U )
#define C_EYEQMSG_GENINIT_IGENERAL_DRIVING_SIDE_RIGHT         ( GENINITIGeneralDrivingSide ) ( 2U )

/* IGeneral_Driving_Side_b2 signal Min & Max range limits */
#define C_EYEQMSG_GENINIT_IGENERAL_DRIVING_SIDE_RMIN          ( 0U )
#define C_EYEQMSG_GENINIT_IGENERAL_DRIVING_SIDE_RMAX          ( 2U )
#define C_EYEQMSG_GENINIT_IGENERAL_DRIVING_SIDE_NUMR          ( 1U )
#define C_EYEQMSG_GENINIT_IGENERAL_DRIVING_SIDE_DEMNR         ( 1U )
#define C_EYEQMSG_GENINIT_IGENERAL_DRIVING_SIDE_OFFSET        ( 0U )

/* IGeneral_Region_Code_b8 signal Enums */
typedef uint8 GENINITIGeneralRegionCode;
#define C_EYEQMSG_GENINIT_IGENERAL_REGION_CODE_WORLD          ( GENINITIGeneralRegionCode ) ( 0U )
#define C_EYEQMSG_GENINIT_IGENERAL_REGION_CODE_EUROPE         ( GENINITIGeneralRegionCode ) ( 1U )
#define C_EYEQMSG_GENINIT_IGENERAL_REGION_CODE_GULFREGION     ( GENINITIGeneralRegionCode ) ( 2U )
#define C_EYEQMSG_GENINIT_IGENERAL_REGION_CODE_USA            ( GENINITIGeneralRegionCode ) ( 3U )
#define C_EYEQMSG_GENINIT_IGENERAL_REGION_CODE_CANADA         ( GENINITIGeneralRegionCode ) ( 4U )
#define C_EYEQMSG_GENINIT_IGENERAL_REGION_CODE_JAPAN          ( GENINITIGeneralRegionCode ) ( 5U )
#define C_EYEQMSG_GENINIT_IGENERAL_REGION_CODE_CHINA          ( GENINITIGeneralRegionCode ) ( 6U )
#define C_EYEQMSG_GENINIT_IGENERAL_REGION_CODE_SOUTH_AFRICA   ( GENINITIGeneralRegionCode ) ( 7U )
#define C_EYEQMSG_GENINIT_IGENERAL_REGION_CODE_KOREA          ( GENINITIGeneralRegionCode ) ( 8U )
#define C_EYEQMSG_GENINIT_IGENERAL_REGION_CODE_AUSTRALIA      ( GENINITIGeneralRegionCode ) ( 9U )
#define C_EYEQMSG_GENINIT_IGENERAL_REGION_CODE_UK             ( GENINITIGeneralRegionCode ) ( 10U )
#define C_EYEQMSG_GENINIT_IGENERAL_REGION_CODE_INDIA          ( GENINITIGeneralRegionCode ) ( 11U )

/* IGeneral_Region_Code_b8 signal Min & Max range limits */
#define C_EYEQMSG_GENINIT_IGENERAL_REGION_CODE_RMIN           ( 0U )
#define C_EYEQMSG_GENINIT_IGENERAL_REGION_CODE_RMAX           ( 11U )
#define C_EYEQMSG_GENINIT_IGENERAL_REGION_CODE_NUMR           ( 1U )
#define C_EYEQMSG_GENINIT_IGENERAL_REGION_CODE_DEMNR          ( 1U )
#define C_EYEQMSG_GENINIT_IGENERAL_REGION_CODE_OFFSET         ( 0U )

/* IGeneral_CLB_DYN_AF_Roll_sb32 signal Min & Max range limits */
#define C_EYEQMSG_GENINIT_IGENERAL_CLB_DYN_AF_ROLL_RMIN       ( -0.05 )
#define C_EYEQMSG_GENINIT_IGENERAL_CLB_DYN_AF_ROLL_RMAX       ( 0.05 )
#define C_EYEQMSG_GENINIT_IGENERAL_CLB_DYN_AF_ROLL_NUMR       ( 1 )
#define C_EYEQMSG_GENINIT_IGENERAL_CLB_DYN_AF_ROLL_DEMNR      ( 1 )
#define C_EYEQMSG_GENINIT_IGENERAL_CLB_DYN_AF_ROLL_OFFSET     ( 0U )

/* IGeneral_CLB_DYN_AF_Roll_V_b1 signal Enums */
typedef boolean GENINITIGeneralCLBDYNAFRollV;
#define C_EYEQMSG_GENINIT_IGENERAL_CLB_DYN_AF_ROLL_V_FALSE    ( GENINITIGeneralCLBDYNAFRollV ) ( 0U )
#define C_EYEQMSG_GENINIT_IGENERAL_CLB_DYN_AF_ROLL_V_TRUE     ( GENINITIGeneralCLBDYNAFRollV ) ( 1U )

/* IGeneral_CLB_DYN_AF_Roll_V_b1 signal Min & Max range limits */
#define C_EYEQMSG_GENINIT_IGENERAL_CLB_DYN_AF_ROLL_V_RMIN     ( 0U )
#define C_EYEQMSG_GENINIT_IGENERAL_CLB_DYN_AF_ROLL_V_RMAX     ( 1U )
#define C_EYEQMSG_GENINIT_IGENERAL_CLB_DYN_AF_ROLL_V_NUMR     ( 1U )
#define C_EYEQMSG_GENINIT_IGENERAL_CLB_DYN_AF_ROLL_V_DEMNR    ( 1U )
#define C_EYEQMSG_GENINIT_IGENERAL_CLB_DYN_AF_ROLL_V_OFFSET   ( 0U )

/* IGeneral_CLB_DYN_AF_Yaw_b14 signal Min & Max range limits */
#define C_EYEQMSG_GENINIT_IGENERAL_CLB_DYN_AF_YAW_RMIN        ( 0U )
#define C_EYEQMSG_GENINIT_IGENERAL_CLB_DYN_AF_YAW_RMAX        ( 320U )
#define C_EYEQMSG_GENINIT_IGENERAL_CLB_DYN_AF_YAW_NUMR        ( 1 )
#define C_EYEQMSG_GENINIT_IGENERAL_CLB_DYN_AF_YAW_DEMNR       ( 1 )
#define C_EYEQMSG_GENINIT_IGENERAL_CLB_DYN_AF_YAW_OFFSET      ( -160 )

/* IGeneral_CLB_DYN_AF_Yaw_V_b1 signal Enums */
typedef boolean GENINITIGeneralCLBDYNAFYawV;
#define C_EYEQMSG_GENINIT_IGENERAL_CLB_DYN_AF_YAW_V_FALSE     ( GENINITIGeneralCLBDYNAFYawV ) ( 0U )
#define C_EYEQMSG_GENINIT_IGENERAL_CLB_DYN_AF_YAW_V_TRUE      ( GENINITIGeneralCLBDYNAFYawV ) ( 1U )

/* IGeneral_CLB_DYN_AF_Yaw_V_b1 signal Min & Max range limits */
#define C_EYEQMSG_GENINIT_IGENERAL_CLB_DYN_AF_YAW_V_RMIN      ( 0U )
#define C_EYEQMSG_GENINIT_IGENERAL_CLB_DYN_AF_YAW_V_RMAX      ( 1U )
#define C_EYEQMSG_GENINIT_IGENERAL_CLB_DYN_AF_YAW_V_NUMR      ( 1U )
#define C_EYEQMSG_GENINIT_IGENERAL_CLB_DYN_AF_YAW_V_DEMNR     ( 1U )
#define C_EYEQMSG_GENINIT_IGENERAL_CLB_DYN_AF_YAW_V_OFFSET    ( 0U )

/* IGeneral_CLB_DYN_AF_Pitch_b15 signal Min & Max range limits */
#define C_EYEQMSG_GENINIT_IGENERAL_CLB_DYN_AF_PITCH_RMIN      ( 0U )
#define C_EYEQMSG_GENINIT_IGENERAL_CLB_DYN_AF_PITCH_RMAX      ( 660U )
#define C_EYEQMSG_GENINIT_IGENERAL_CLB_DYN_AF_PITCH_NUMR      ( 1 )
#define C_EYEQMSG_GENINIT_IGENERAL_CLB_DYN_AF_PITCH_DEMNR     ( 1 )
#define C_EYEQMSG_GENINIT_IGENERAL_CLB_DYN_AF_PITCH_OFFSET    ( -500 )

/* IGeneral_CLB_DYN_AF_Pitch_V_b1 signal Enums */
typedef boolean GENINITIGeneralCLBDYNAFPitchV;
#define C_EYEQMSG_GENINIT_IGENERAL_CLB_DYN_AF_PITCH_V_FALSE   ( GENINITIGeneralCLBDYNAFPitchV ) ( 0U )
#define C_EYEQMSG_GENINIT_IGENERAL_CLB_DYN_AF_PITCH_V_TRUE    ( GENINITIGeneralCLBDYNAFPitchV ) ( 1U )

/* IGeneral_CLB_DYN_AF_Pitch_V_b1 signal Min & Max range limits */
#define C_EYEQMSG_GENINIT_IGENERAL_CLB_DYN_AF_PITCH_V_RMIN    ( 0U )
#define C_EYEQMSG_GENINIT_IGENERAL_CLB_DYN_AF_PITCH_V_RMAX    ( 1U )
#define C_EYEQMSG_GENINIT_IGENERAL_CLB_DYN_AF_PITCH_V_NUMR    ( 1U )
#define C_EYEQMSG_GENINIT_IGENERAL_CLB_DYN_AF_PITCH_V_DEMNR   ( 1U )
#define C_EYEQMSG_GENINIT_IGENERAL_CLB_DYN_AF_PITCH_V_OFFSET  ( 0U )

/* IGeneral_Roll_Angle_Base_sb32 signal Min & Max range limits */
#define C_EYEQMSG_GENINIT_IGENERAL_ROLL_ANGLE_BASE_RMIN       ( -0.05 )
#define C_EYEQMSG_GENINIT_IGENERAL_ROLL_ANGLE_BASE_RMAX       ( 0.05 )
#define C_EYEQMSG_GENINIT_IGENERAL_ROLL_ANGLE_BASE_NUMR       ( 1 )
#define C_EYEQMSG_GENINIT_IGENERAL_ROLL_ANGLE_BASE_DEMNR      ( 1 )
#define C_EYEQMSG_GENINIT_IGENERAL_ROLL_ANGLE_BASE_OFFSET     ( 0U )

/* IGeneral_Roll_Angle_Base_V_b1 signal Enums */
typedef boolean GENINITIGeneralRollAngleBaseV;
#define C_EYEQMSG_GENINIT_IGENERAL_ROLL_ANGLE_BASE_V_FALSE    ( GENINITIGeneralRollAngleBaseV ) ( 0U )
#define C_EYEQMSG_GENINIT_IGENERAL_ROLL_ANGLE_BASE_V_TRUE     ( GENINITIGeneralRollAngleBaseV ) ( 1U )

/* IGeneral_Roll_Angle_Base_V_b1 signal Min & Max range limits */
#define C_EYEQMSG_GENINIT_IGENERAL_ROLL_ANGLE_BASE_V_RMIN     ( 0U )
#define C_EYEQMSG_GENINIT_IGENERAL_ROLL_ANGLE_BASE_V_RMAX     ( 1U )
#define C_EYEQMSG_GENINIT_IGENERAL_ROLL_ANGLE_BASE_V_NUMR     ( 1U )
#define C_EYEQMSG_GENINIT_IGENERAL_ROLL_ANGLE_BASE_V_DEMNR    ( 1U )
#define C_EYEQMSG_GENINIT_IGENERAL_ROLL_ANGLE_BASE_V_OFFSET   ( 0U )

/* IGeneral_Buffer_1_b11 signal Min & Max range limits */
#define C_EYEQMSG_GENINIT_IGENERAL_BUFFER_1_RMIN              ( 0U )
#define C_EYEQMSG_GENINIT_IGENERAL_BUFFER_1_RMAX              ( 0U )
#define C_EYEQMSG_GENINIT_IGENERAL_BUFFER_1_NUMR              ( 1U )
#define C_EYEQMSG_GENINIT_IGENERAL_BUFFER_1_DEMNR             ( 1U )
#define C_EYEQMSG_GENINIT_IGENERAL_BUFFER_1_OFFSET            ( 0U )

/* IGeneral_Buffer_1_V_b1 signal Min & Max range limits */
#define C_EYEQMSG_GENINIT_IGENERAL_BUFFER_1_V_RMIN            ( 0U )
#define C_EYEQMSG_GENINIT_IGENERAL_BUFFER_1_V_RMAX            ( 0U )
#define C_EYEQMSG_GENINIT_IGENERAL_BUFFER_1_V_NUMR            ( 1U )
#define C_EYEQMSG_GENINIT_IGENERAL_BUFFER_1_V_DEMNR           ( 1U )
#define C_EYEQMSG_GENINIT_IGENERAL_BUFFER_1_V_OFFSET          ( 0U )

/* IGeneral_Optional_Signals_b3 signal Min & Max range limits */
#define C_EYEQMSG_GENINIT_IGENERAL_OPTIONAL_SIGNALS_RMIN      ( 5U )
#define C_EYEQMSG_GENINIT_IGENERAL_OPTIONAL_SIGNALS_RMAX      ( 5U )
#define C_EYEQMSG_GENINIT_IGENERAL_OPTIONAL_SIGNALS_NUMR      ( 1U )
#define C_EYEQMSG_GENINIT_IGENERAL_OPTIONAL_SIGNALS_DEMNR     ( 1U )
#define C_EYEQMSG_GENINIT_IGENERAL_OPTIONAL_SIGNALS_OFFSET    ( 0U )

/* IGeneral_Protocol_Version_b8 signal Min & Max range limits */
#define C_EYEQMSG_GENINIT_IGENERAL_PROTOCOL_VERSION_RMIN      ( 7U )
#define C_EYEQMSG_GENINIT_IGENERAL_PROTOCOL_VERSION_RMAX      ( 7U )
#define C_EYEQMSG_GENINIT_IGENERAL_PROTOCOL_VERSION_NUMR      ( 1U )
#define C_EYEQMSG_GENINIT_IGENERAL_PROTOCOL_VERSION_DEMNR     ( 1U )
#define C_EYEQMSG_GENINIT_IGENERAL_PROTOCOL_VERSION_OFFSET    ( 0U )

/* IGeneral_Zero_Byte_b8 signal Min & Max range limits */
#define C_EYEQMSG_GENINIT_IGENERAL_ZERO_BYTE_RMIN             ( 0U )
#define C_EYEQMSG_GENINIT_IGENERAL_ZERO_BYTE_RMAX             ( 0U )
#define C_EYEQMSG_GENINIT_IGENERAL_ZERO_BYTE_NUMR             ( 1U )
#define C_EYEQMSG_GENINIT_IGENERAL_ZERO_BYTE_DEMNR            ( 1U )
#define C_EYEQMSG_GENINIT_IGENERAL_ZERO_BYTE_OFFSET           ( 0U )


/*****************************************************************************
                  Exported function-like macros
*****************************************************************************/
/*****************************************************************************
                  Exported defined macros
*****************************************************************************/
/*****************************************************************************
                  Exported types, enums definitions
*****************************************************************************/
typedef struct
{
   #if ENABLE_BIG_ENDIAN_FORMAT
      uint32        IGeneral_Zero_Byte_b8                        : 8U;
      
      uint32        IGeneral_Protocol_Version_b8                 : 8U;
      
      uint32        unused1_b5                                   : 5;
      uint32        IGeneral_Optional_Signals_b3                 : 3U;
      
      uint32        IGeneral_Buffer_1_V_b1                       : 1U;
      
      uint32        IGeneral_Buffer_1_1_b4                       : 4U;
      
      uint32        IGeneral_Buffer_1_2_b7                       : 7U;
      
      uint32        IGeneral_Roll_Angle_Base_V_b1                : 1U;
      
      uint32        IGeneral_Roll_Angle_Base_1_sb8               : 8U;
      
      uint32        IGeneral_Roll_Angle_Base_2_sb8               : 8U;
      
      uint32        IGeneral_Roll_Angle_Base_3_sb8               : 8U;
      
      uint32        IGeneral_Roll_Angle_Base_4_sb8               : 8U;
      
      uint32        unused2_b2                                   : 2;
      uint32        IGeneral_CLB_DYN_AF_Pitch_V_b1               : 1U;
      
      uint32        IGeneral_CLB_DYN_AF_Pitch_1_b7               : 7U;
      
      uint32        IGeneral_CLB_DYN_AF_Pitch_2_b8               : 8U;
      
      uint32        IGeneral_CLB_DYN_AF_Yaw_V_b1                 : 1U;
      
      uint32        IGeneral_CLB_DYN_AF_Yaw_1_b7                 : 7U;
      
      uint32        IGeneral_CLB_DYN_AF_Yaw_2_b7                 : 7U;
      
      uint32        IGeneral_CLB_DYN_AF_Roll_V_b1                : 1U;
      
      uint32        IGeneral_CLB_DYN_AF_Roll_1_sb8               : 8U;
      
      uint32        IGeneral_CLB_DYN_AF_Roll_2_sb8               : 8U;
      
      uint32        IGeneral_CLB_DYN_AF_Roll_3_sb8               : 8U;
      
      uint32        IGeneral_CLB_DYN_AF_Roll_4_sb8               : 8U;
      
      uint32        IGeneral_Region_Code_b8                      : 8U;
      
      uint32        IGeneral_Driving_Side_b2                     : 2U;
      
      uint32        IGeneral_HIL_Mode_b1                         : 1U;
      
      uint32        IGeneral_Cam_Height_Full_1_b5                : 5U;
      
      uint32        IGeneral_Cam_Height_Full_2_b8                : 8U;
      
      uint32        IGeneral_Cam_Height_Full_3_b3                : 3U;
      
      uint32        Reserved_1_b5                                : 5U;
      
      uint32        IGeneral_Pitch_Base_1_b8                     : 8U;
      
      uint32        IGeneral_Pitch_Base_2_b8                     : 8U;
      
      uint32        IGeneral_Yaw_Base_1_b8                       : 8U;
      
      uint32        IGeneral_Yaw_Base_2_b8                       : 8U;
      
      uint32        IGeneral_Camera_Height_Base_1_b8             : 8U;
      
      uint32        IGeneral_Camera_Height_Base_2_b8             : 8U;
      
      uint32        Reserved_2_1_b8                              : 8U;
      
      uint32        Reserved_2_2_b8                              : 8U;
      
   #else
      uint32        IGeneral_Zero_Byte_b8                        : 8U;
      
      uint32        IGeneral_Protocol_Version_b8                 : 8U;
      
      uint32        IGeneral_Optional_Signals_b3                 : 3U;
      
      uint32        IGeneral_Buffer_1_V_b1                       : 1U;
      
      uint32        IGeneral_Buffer_1_b11                        : 11U;
      
      uint32        IGeneral_Roll_Angle_Base_V_b1                : 1U;
      
      sint32        IGeneral_Roll_Angle_Base_sb32                : 32;
      
      uint32        IGeneral_CLB_DYN_AF_Pitch_V_b1               : 1U;
      
      uint32        IGeneral_CLB_DYN_AF_Pitch_b15                : 15U;
      
      uint32        IGeneral_CLB_DYN_AF_Yaw_V_b1                 : 1U;
      
      uint32        IGeneral_CLB_DYN_AF_Yaw_b14                  : 14U;
      
      uint32        IGeneral_CLB_DYN_AF_Roll_V_b1                : 1U;
      
      sint32        IGeneral_CLB_DYN_AF_Roll_sb32                : 32;
      
      uint32        IGeneral_Region_Code_b8                      : 8U;
      
      uint32        IGeneral_Driving_Side_b2                     : 2U;
      
      uint32        IGeneral_HIL_Mode_b1                         : 1U;
      
      uint32        IGeneral_Cam_Height_Full_b16                 : 16U;
      
      uint32        Reserved_1_b5                                : 5U;
      
      uint32        IGeneral_Pitch_Base_b16                      : 16U;
      
      uint32        IGeneral_Yaw_Base_b16                        : 16U;
      
      uint32        IGeneral_Camera_Height_Base_b16              : 16U;
      
      uint32        Reserved_2_b16                               : 16U;
      
   #endif
} EYEQMSG_GENINIT_Params_t;


/*****************************************************************************
                  Exported function prototypes
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_GENINIT_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_GENINIT_Params_t * pGeneral_Init - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of General_Init message 
*    General_Init message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns General_Init message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_GENINIT_ParamsApp_MsgDataStruct( EYEQMSG_GENINIT_Params_t * pGeneral_Init );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_GENINIT_IGeneral_Zero_Byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pIGeneral_Zero_Byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IGeneral_Zero_Byte
*    IGeneral_Zero_Byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IGeneral_Zero_Byte signal value of General_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_GENINIT_IGeneral_Zero_Byte( uint8 * pIGeneral_Zero_Byte );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_GENINIT_IGeneral_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pIGeneral_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IGeneral_Protocol_Version
*    IGeneral_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IGeneral_Protocol_Version signal value of General_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_GENINIT_IGeneral_Protocol_Version( uint8 * pIGeneral_Protocol_Version );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_GENINIT_IGeneral_Optional_Signals
*
* FUNCTION ARGUMENTS:
*    uint8 * pIGeneral_Optional_Signals - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IGeneral_Optional_Signals
*    IGeneral_Optional_Signals returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IGeneral_Optional_Signals signal value of General_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_GENINIT_IGeneral_Optional_Signals( uint8 * pIGeneral_Optional_Signals );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_GENINIT_IGeneral_Buffer_1_V
*
* FUNCTION ARGUMENTS:
*    boolean * pIGeneral_Buffer_1_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IGeneral_Buffer_1_V
*    IGeneral_Buffer_1_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IGeneral_Buffer_1_V signal value of General_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_GENINIT_IGeneral_Buffer_1_V( boolean * pIGeneral_Buffer_1_V );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_GENINIT_IGeneral_Buffer_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pIGeneral_Buffer_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IGeneral_Buffer_1
*    IGeneral_Buffer_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IGeneral_Buffer_1 signal value of General_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_GENINIT_IGeneral_Buffer_1( uint16 * pIGeneral_Buffer_1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_GENINIT_IGeneral_Roll_Angle_Base_V
*
* FUNCTION ARGUMENTS:
*    GENINITIGeneralRollAngleBaseV * pIGeneral_Roll_Angle_Base_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IGeneral_Roll_Angle_Base_V
*    IGeneral_Roll_Angle_Base_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IGeneral_Roll_Angle_Base_V signal value of General_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_GENINIT_IGeneral_Roll_Angle_Base_V( GENINITIGeneralRollAngleBaseV * pIGeneral_Roll_Angle_Base_V );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_GENINIT_IGeneral_Roll_Angle_Base
*
* FUNCTION ARGUMENTS:
*    float32 * pIGeneral_Roll_Angle_Base - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IGeneral_Roll_Angle_Base
*    IGeneral_Roll_Angle_Base returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IGeneral_Roll_Angle_Base signal value of General_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_GENINIT_IGeneral_Roll_Angle_Base( float32 * pIGeneral_Roll_Angle_Base );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_GENINIT_IGeneral_CLB_DYN_AF_Pitch_V
*
* FUNCTION ARGUMENTS:
*    GENINITIGeneralCLBDYNAFPitchV * pIGeneral_CLB_DYN_AF_Pitch_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IGeneral_CLB_DYN_AF_Pitch_V
*    IGeneral_CLB_DYN_AF_Pitch_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IGeneral_CLB_DYN_AF_Pitch_V signal value of General_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_GENINIT_IGeneral_CLB_DYN_AF_Pitch_V( GENINITIGeneralCLBDYNAFPitchV * pIGeneral_CLB_DYN_AF_Pitch_V );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_GENINIT_IGeneral_CLB_DYN_AF_Pitch
*
* FUNCTION ARGUMENTS:
*    uint16 * pIGeneral_CLB_DYN_AF_Pitch - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IGeneral_CLB_DYN_AF_Pitch
*    IGeneral_CLB_DYN_AF_Pitch returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IGeneral_CLB_DYN_AF_Pitch signal value of General_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_GENINIT_IGeneral_CLB_DYN_AF_Pitch( uint16 * pIGeneral_CLB_DYN_AF_Pitch );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_GENINIT_IGeneral_CLB_DYN_AF_Yaw_V
*
* FUNCTION ARGUMENTS:
*    GENINITIGeneralCLBDYNAFYawV * pIGeneral_CLB_DYN_AF_Yaw_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IGeneral_CLB_DYN_AF_Yaw_V
*    IGeneral_CLB_DYN_AF_Yaw_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IGeneral_CLB_DYN_AF_Yaw_V signal value of General_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_GENINIT_IGeneral_CLB_DYN_AF_Yaw_V( GENINITIGeneralCLBDYNAFYawV * pIGeneral_CLB_DYN_AF_Yaw_V );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_GENINIT_IGeneral_CLB_DYN_AF_Yaw
*
* FUNCTION ARGUMENTS:
*    uint16 * pIGeneral_CLB_DYN_AF_Yaw - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IGeneral_CLB_DYN_AF_Yaw
*    IGeneral_CLB_DYN_AF_Yaw returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IGeneral_CLB_DYN_AF_Yaw signal value of General_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_GENINIT_IGeneral_CLB_DYN_AF_Yaw( uint16 * pIGeneral_CLB_DYN_AF_Yaw );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_GENINIT_IGeneral_CLB_DYN_AF_Roll_V
*
* FUNCTION ARGUMENTS:
*    GENINITIGeneralCLBDYNAFRollV * pIGeneral_CLB_DYN_AF_Roll_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IGeneral_CLB_DYN_AF_Roll_V
*    IGeneral_CLB_DYN_AF_Roll_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IGeneral_CLB_DYN_AF_Roll_V signal value of General_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_GENINIT_IGeneral_CLB_DYN_AF_Roll_V( GENINITIGeneralCLBDYNAFRollV * pIGeneral_CLB_DYN_AF_Roll_V );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_GENINIT_IGeneral_CLB_DYN_AF_Roll
*
* FUNCTION ARGUMENTS:
*    float32 * pIGeneral_CLB_DYN_AF_Roll - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IGeneral_CLB_DYN_AF_Roll
*    IGeneral_CLB_DYN_AF_Roll returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IGeneral_CLB_DYN_AF_Roll signal value of General_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_GENINIT_IGeneral_CLB_DYN_AF_Roll( float32 * pIGeneral_CLB_DYN_AF_Roll );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_GENINIT_IGeneral_Region_Code
*
* FUNCTION ARGUMENTS:
*    GENINITIGeneralRegionCode * pIGeneral_Region_Code - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IGeneral_Region_Code
*    IGeneral_Region_Code returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IGeneral_Region_Code signal value of General_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_GENINIT_IGeneral_Region_Code( GENINITIGeneralRegionCode * pIGeneral_Region_Code );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_GENINIT_IGeneral_Driving_Side
*
* FUNCTION ARGUMENTS:
*    GENINITIGeneralDrivingSide * pIGeneral_Driving_Side - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IGeneral_Driving_Side
*    IGeneral_Driving_Side returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IGeneral_Driving_Side signal value of General_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_GENINIT_IGeneral_Driving_Side( GENINITIGeneralDrivingSide * pIGeneral_Driving_Side );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_GENINIT_IGeneral_HIL_Mode
*
* FUNCTION ARGUMENTS:
*    GENINITIGeneralHILMode * pIGeneral_HIL_Mode - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IGeneral_HIL_Mode
*    IGeneral_HIL_Mode returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IGeneral_HIL_Mode signal value of General_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_GENINIT_IGeneral_HIL_Mode( GENINITIGeneralHILMode * pIGeneral_HIL_Mode );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_GENINIT_IGeneral_Cam_Height_Full
*
* FUNCTION ARGUMENTS:
*    uint16 * pIGeneral_Cam_Height_Full - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IGeneral_Cam_Height_Full
*    IGeneral_Cam_Height_Full returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IGeneral_Cam_Height_Full signal value of General_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_GENINIT_IGeneral_Cam_Height_Full( uint16 * pIGeneral_Cam_Height_Full );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_GENINIT_Reserved_1
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1
*    Reserved_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1 signal value of General_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_GENINIT_Reserved_1( uint8 * pReserved_1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_GENINIT_IGeneral_Pitch_Base
*
* FUNCTION ARGUMENTS:
*    uint16 * pIGeneral_Pitch_Base - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IGeneral_Pitch_Base
*    IGeneral_Pitch_Base returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IGeneral_Pitch_Base signal value of General_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_GENINIT_IGeneral_Pitch_Base( uint16 * pIGeneral_Pitch_Base );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_GENINIT_IGeneral_Yaw_Base
*
* FUNCTION ARGUMENTS:
*    uint16 * pIGeneral_Yaw_Base - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IGeneral_Yaw_Base
*    IGeneral_Yaw_Base returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IGeneral_Yaw_Base signal value of General_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_GENINIT_IGeneral_Yaw_Base( uint16 * pIGeneral_Yaw_Base );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_GENINIT_IGeneral_Camera_Height_Base
*
* FUNCTION ARGUMENTS:
*    uint16 * pIGeneral_Camera_Height_Base - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IGeneral_Camera_Height_Base
*    IGeneral_Camera_Height_Base returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IGeneral_Camera_Height_Base signal value of General_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_GENINIT_IGeneral_Camera_Height_Base( uint16 * pIGeneral_Camera_Height_Base );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_GENINIT_Reserved_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pReserved_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_2
*    Reserved_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_2 signal value of General_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_GENINIT_Reserved_2( uint16 * pReserved_2 );
/*****************************************************************************
                  Exported object declarations
*****************************************************************************/
extern EYEQMSG_GENINIT_Params_t   EYEQMSG_GENINIT_Params_s;
extern EYEQMSG_GENINIT_Params_t   EYEQMSG_GENINIT_ParamsApp_s;
/****************************************************************************/
#endif /* _EYEQMSG_GENINITPROCESS_H_ */


