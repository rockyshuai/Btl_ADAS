#ifndef _EYEQMSG_CAMINITPRPROCESS_H_
#define _EYEQMSG_CAMINITPRPROCESS_H_

/*****************************************************************************
                  Included header files
*****************************************************************************/
#include <Std_Types.h>

/*****************************************************************************
                  Include files
*****************************************************************************/
/*****************************************************************************
                  Exported symbolic constants
*****************************************************************************/

/* Datagram message ID */
#define C_EYEQMSG_CAMINITPR_MSG_ID                            ( 0x40U )

/* Datagram message lengths */
#define C_EYEQMSG_CAMINITPR_MSG_LEN                           ( sizeof(EYEQMSG_CAMINITPR_Params_t) )

/* Protocol ENUMs */

/* MCU output messages */

/* Camera_Init_parking_rear Enums */
/* INIT_Cam_PrincipalPointY_sb64 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_PRINCIPALPOINTY_RMIN     ( 0 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_PRINCIPALPOINTY_RMAX     ( 2000 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_PRINCIPALPOINTY_NUMR     ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_PRINCIPALPOINTY_DEMNR    ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_PRINCIPALPOINTY_OFFSET   ( 0U )

/* INIT_Cam_PrincipalPointX_sb64 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_PRINCIPALPOINTX_RMIN     ( 0 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_PRINCIPALPOINTX_RMAX     ( 2000 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_PRINCIPALPOINTX_NUMR     ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_PRINCIPALPOINTX_DEMNR    ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_PRINCIPALPOINTX_OFFSET   ( 0U )

/* INIT_Cam_Skew_sb64 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SKEW_RMIN                ( 0 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SKEW_RMAX                ( 2000 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SKEW_NUMR                ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SKEW_DEMNR               ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SKEW_OFFSET              ( 0U )

/* INIT_Cam_FocalLengthY_sb64 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_FOCALLENGTHY_RMIN        ( 0 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_FOCALLENGTHY_RMAX        ( 8000 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_FOCALLENGTHY_NUMR        ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_FOCALLENGTHY_DEMNR       ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_FOCALLENGTHY_OFFSET      ( 0U )

/* INIT_Cam_FocalLengthX_sb64 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_FOCALLENGTHX_RMIN        ( 0 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_FOCALLENGTHX_RMAX        ( 8000 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_FOCALLENGTHX_NUMR        ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_FOCALLENGTHX_DEMNR       ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_FOCALLENGTHX_OFFSET      ( 0U )

/* INIT_Cam_distorParams15_sb64 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS15_RMIN      ( -0.8 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS15_RMAX      ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS15_NUMR      ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS15_DEMNR     ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS15_OFFSET    ( 0U )

/* INIT_Cam_distorParams14_sb64 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS14_RMIN      ( -0.8 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS14_RMAX      ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS14_NUMR      ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS14_DEMNR     ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS14_OFFSET    ( 0U )

/* INIT_Cam_distorParams13_sb64 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS13_RMIN      ( -0.8 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS13_RMAX      ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS13_NUMR      ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS13_DEMNR     ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS13_OFFSET    ( 0U )

/* INIT_Cam_distorParams12_sb64 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS12_RMIN      ( -0.8 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS12_RMAX      ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS12_NUMR      ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS12_DEMNR     ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS12_OFFSET    ( 0U )

/* INIT_Cam_distorParams11_sb64 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS11_RMIN      ( -0.8 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS11_RMAX      ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS11_NUMR      ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS11_DEMNR     ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS11_OFFSET    ( 0U )

/* INIT_Cam_distorParams10_sb64 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS10_RMIN      ( -0.8 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS10_RMAX      ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS10_NUMR      ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS10_DEMNR     ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS10_OFFSET    ( 0U )

/* INIT_Cam_distorParams9_sb64 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS9_RMIN       ( -0.8 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS9_RMAX       ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS9_NUMR       ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS9_DEMNR      ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS9_OFFSET     ( 0U )

/* INIT_Cam_distorParams8_sb64 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS8_RMIN       ( -0.8 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS8_RMAX       ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS8_NUMR       ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS8_DEMNR      ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS8_OFFSET     ( 0U )

/* INIT_Cam_distorParams7_sb64 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS7_RMIN       ( -0.8 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS7_RMAX       ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS7_NUMR       ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS7_DEMNR      ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS7_OFFSET     ( 0U )

/* INIT_Cam_distorParams6_sb64 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS6_RMIN       ( -0.8 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS6_RMAX       ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS6_NUMR       ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS6_DEMNR      ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS6_OFFSET     ( 0U )

/* INIT_Cam_distorParams5_sb64 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS5_RMIN       ( -0.8 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS5_RMAX       ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS5_NUMR       ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS5_DEMNR      ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS5_OFFSET     ( 0U )

/* INIT_Cam_distorParams4_sb64 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS4_RMIN       ( -0.8 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS4_RMAX       ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS4_NUMR       ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS4_DEMNR      ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS4_OFFSET     ( 0U )

/* INIT_Cam_distorParams3_sb64 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS3_RMIN       ( -0.8 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS3_RMAX       ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS3_NUMR       ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS3_DEMNR      ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS3_OFFSET     ( 0U )

/* INIT_Cam_distorParams2_sb64 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS2_RMIN       ( -0.8 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS2_RMAX       ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS2_NUMR       ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS2_DEMNR      ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS2_OFFSET     ( 0U )

/* INIT_Cam_distorParams1_sb64 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS1_RMIN       ( -0.8 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS1_RMAX       ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS1_NUMR       ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS1_DEMNR      ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS1_OFFSET     ( 0U )

/* INIT_Cam_distorParams0_sb64 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS0_RMIN       ( -0.8 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS0_RMAX       ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS0_NUMR       ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS0_DEMNR      ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORPARAMS0_OFFSET     ( 0U )

/* INIT_Cam_CODY_sb64 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_CODY_RMIN                ( 0 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_CODY_RMAX                ( 2000 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_CODY_NUMR                ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_CODY_DEMNR               ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_CODY_OFFSET              ( 0U )

/* INIT_Cam_CODX_sb64 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_CODX_RMIN                ( 0 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_CODX_RMAX                ( 2000 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_CODX_NUMR                ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_CODX_DEMNR               ( 1 )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_CODX_OFFSET              ( 0U )

/* Reserved_1_b21 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_RESERVED_1_RMIN                   ( 0U )
#define C_EYEQMSG_CAMINITPR_RESERVED_1_RMAX                   ( 0U )
#define C_EYEQMSG_CAMINITPR_RESERVED_1_NUMR                   ( 1U )
#define C_EYEQMSG_CAMINITPR_RESERVED_1_DEMNR                  ( 1U )
#define C_EYEQMSG_CAMINITPR_RESERVED_1_OFFSET                 ( 0U )

/* INIT_Cam_distortionModelType_b3 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORTIONMODELTYPE_RMIN ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORTIONMODELTYPE_RMAX ( 3U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORTIONMODELTYPE_NUMR ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORTIONMODELTYPE_DEMNR ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_DISTORTIONMODELTYPE_OFFSET ( 0U )

/* INIT_Cam_Type_b8 signal Enums */
typedef uint8 CAMINITPRINITCamType;
#define C_EYEQMSG_CAMINITPR_INIT_CAM_TYPE_MAIN                ( CAMINITPRINITCamType ) ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_TYPE_NARROW              ( CAMINITPRINITCamType ) ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_TYPE_FISHEYE             ( CAMINITPRINITCamType ) ( 2U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_TYPE_FRONT_LEFT          ( CAMINITPRINITCamType ) ( 3U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_TYPE_FRONT_RIGHT         ( CAMINITPRINITCamType ) ( 4U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_TYPE_REAR_LEFT           ( CAMINITPRINITCamType ) ( 5U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_TYPE_REAR_RIGHT          ( CAMINITPRINITCamType ) ( 6U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_TYPE_REAR                ( CAMINITPRINITCamType ) ( 7U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_TYPE_PARKING_FRONT_LEFT  ( CAMINITPRINITCamType ) ( 8U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_TYPE_PARKING_FRONT_RIGHT ( CAMINITPRINITCamType ) ( 9U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_TYPE_PARKING_BACK_LEFT   ( CAMINITPRINITCamType ) ( 10U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_TYPE_PARKING_BACK_RIGHT  ( CAMINITPRINITCamType ) ( 11U )

/* INIT_Cam_Type_b8 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_TYPE_RMIN                ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_TYPE_RMAX                ( 31U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_TYPE_NUMR                ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_TYPE_DEMNR               ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_TYPE_OFFSET              ( 0U )

/* INIT_Cam_EPROM_CRC_b32 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_EPROM_CRC_RMIN           ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_EPROM_CRC_RMAX           ( 4294967295U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_EPROM_CRC_NUMR           ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_EPROM_CRC_DEMNR          ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_EPROM_CRC_OFFSET         ( 0U )

/* INIT_Cam_EPROM_CRC_V_b1 signal Enums */
typedef boolean CAMINITPRINITCamEPROMCRCV;
#define C_EYEQMSG_CAMINITPR_INIT_CAM_EPROM_CRC_V_FALSE        ( CAMINITPRINITCamEPROMCRCV ) ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_EPROM_CRC_V_TRUE         ( CAMINITPRINITCamEPROMCRCV ) ( 1U )

/* INIT_Cam_EPROM_CRC_V_b1 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_EPROM_CRC_V_RMIN         ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_EPROM_CRC_V_RMAX         ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_EPROM_CRC_V_NUMR         ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_EPROM_CRC_V_DEMNR        ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_EPROM_CRC_V_OFFSET       ( 0U )

/* INIT_Cam_Buffer_9_b30 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_9_RMIN            ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_9_RMAX            ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_9_NUMR            ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_9_DEMNR           ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_9_OFFSET          ( 0U )

/* INIT_Cam_Buffer_9_V_b1 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_9_V_RMIN          ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_9_V_RMAX          ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_9_V_NUMR          ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_9_V_DEMNR         ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_9_V_OFFSET        ( 0U )

/* INIT_Cam_Sensor_ID_P8_b64 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P8_RMIN        ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P8_RMAX        ( 18446744073709551615U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P8_NUMR        ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P8_DEMNR       ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P8_OFFSET      ( 0U )

/* INIT_Cam_Sensor_ID_P8_V_b1 signal Enums */
typedef boolean CAMINITPRINITCamSensorIDP8V;
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P8_V_FALSE     ( CAMINITPRINITCamSensorIDP8V ) ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P8_V_TRUE      ( CAMINITPRINITCamSensorIDP8V ) ( 1U )

/* INIT_Cam_Sensor_ID_P8_V_b1 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P8_V_RMIN      ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P8_V_RMAX      ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P8_V_NUMR      ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P8_V_DEMNR     ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P8_V_OFFSET    ( 0U )

/* INIT_Cam_Buffer_8_b30 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_8_RMIN            ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_8_RMAX            ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_8_NUMR            ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_8_DEMNR           ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_8_OFFSET          ( 0U )

/* INIT_Cam_Buffer_8_V_b1 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_8_V_RMIN          ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_8_V_RMAX          ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_8_V_NUMR          ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_8_V_DEMNR         ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_8_V_OFFSET        ( 0U )

/* INIT_Cam_Sensor_ID_P7_b64 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P7_RMIN        ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P7_RMAX        ( 18446744073709551615U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P7_NUMR        ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P7_DEMNR       ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P7_OFFSET      ( 0U )

/* INIT_Cam_Sensor_ID_P7_V_b1 signal Enums */
typedef boolean CAMINITPRINITCamSensorIDP7V;
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P7_V_FALSE     ( CAMINITPRINITCamSensorIDP7V ) ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P7_V_TRUE      ( CAMINITPRINITCamSensorIDP7V ) ( 1U )

/* INIT_Cam_Sensor_ID_P7_V_b1 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P7_V_RMIN      ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P7_V_RMAX      ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P7_V_NUMR      ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P7_V_DEMNR     ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P7_V_OFFSET    ( 0U )

/* INIT_Cam_Buffer_7_b30 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_7_RMIN            ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_7_RMAX            ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_7_NUMR            ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_7_DEMNR           ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_7_OFFSET          ( 0U )

/* INIT_Cam_Buffer_7_V_b1 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_7_V_RMIN          ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_7_V_RMAX          ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_7_V_NUMR          ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_7_V_DEMNR         ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_7_V_OFFSET        ( 0U )

/* INIT_Cam_Sensor_ID_P6_b64 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P6_RMIN        ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P6_RMAX        ( 18446744073709551615U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P6_NUMR        ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P6_DEMNR       ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P6_OFFSET      ( 0U )

/* INIT_Cam_Sensor_ID_P6_V_b1 signal Enums */
typedef boolean CAMINITPRINITCamSensorIDP6V;
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P6_V_FALSE     ( CAMINITPRINITCamSensorIDP6V ) ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P6_V_TRUE      ( CAMINITPRINITCamSensorIDP6V ) ( 1U )

/* INIT_Cam_Sensor_ID_P6_V_b1 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P6_V_RMIN      ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P6_V_RMAX      ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P6_V_NUMR      ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P6_V_DEMNR     ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P6_V_OFFSET    ( 0U )

/* INIT_Cam_Buffer_6_b30 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_6_RMIN            ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_6_RMAX            ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_6_NUMR            ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_6_DEMNR           ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_6_OFFSET          ( 0U )

/* INIT_Cam_Buffer_6_V_b1 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_6_V_RMIN          ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_6_V_RMAX          ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_6_V_NUMR          ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_6_V_DEMNR         ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_6_V_OFFSET        ( 0U )

/* INIT_Cam_Sensor_ID_P5_b64 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P5_RMIN        ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P5_RMAX        ( 18446744073709551615U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P5_NUMR        ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P5_DEMNR       ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P5_OFFSET      ( 0U )

/* INIT_Cam_Sensor_ID_P5_V_b1 signal Enums */
typedef boolean CAMINITPRINITCamSensorIDP5V;
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P5_V_FALSE     ( CAMINITPRINITCamSensorIDP5V ) ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P5_V_TRUE      ( CAMINITPRINITCamSensorIDP5V ) ( 1U )

/* INIT_Cam_Sensor_ID_P5_V_b1 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P5_V_RMIN      ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P5_V_RMAX      ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P5_V_NUMR      ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P5_V_DEMNR     ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P5_V_OFFSET    ( 0U )

/* INIT_Cam_Buffer_5_b30 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_5_RMIN            ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_5_RMAX            ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_5_NUMR            ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_5_DEMNR           ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_5_OFFSET          ( 0U )

/* INIT_Cam_Buffer_5_V_b1 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_5_V_RMIN          ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_5_V_RMAX          ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_5_V_NUMR          ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_5_V_DEMNR         ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_5_V_OFFSET        ( 0U )

/* INIT_Cam_Sensor_ID_P4_b64 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P4_RMIN        ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P4_RMAX        ( 18446744073709551615U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P4_NUMR        ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P4_DEMNR       ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P4_OFFSET      ( 0U )

/* INIT_Cam_Sensor_ID_P4_V_b1 signal Enums */
typedef boolean CAMINITPRINITCamSensorIDP4V;
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P4_V_FALSE     ( CAMINITPRINITCamSensorIDP4V ) ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P4_V_TRUE      ( CAMINITPRINITCamSensorIDP4V ) ( 1U )

/* INIT_Cam_Sensor_ID_P4_V_b1 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P4_V_RMIN      ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P4_V_RMAX      ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P4_V_NUMR      ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P4_V_DEMNR     ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P4_V_OFFSET    ( 0U )

/* INIT_Cam_Buffer_4_b30 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_4_RMIN            ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_4_RMAX            ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_4_NUMR            ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_4_DEMNR           ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_4_OFFSET          ( 0U )

/* INIT_Cam_Buffer_4_V_b1 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_4_V_RMIN          ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_4_V_RMAX          ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_4_V_NUMR          ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_4_V_DEMNR         ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_4_V_OFFSET        ( 0U )

/* INIT_Cam_Sensor_ID_P3_b64 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P3_RMIN        ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P3_RMAX        ( 18446744073709551615U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P3_NUMR        ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P3_DEMNR       ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P3_OFFSET      ( 0U )

/* INIT_Cam_Sensor_ID_P3_V_b1 signal Enums */
typedef boolean CAMINITPRINITCamSensorIDP3V;
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P3_V_FALSE     ( CAMINITPRINITCamSensorIDP3V ) ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P3_V_TRUE      ( CAMINITPRINITCamSensorIDP3V ) ( 1U )

/* INIT_Cam_Sensor_ID_P3_V_b1 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P3_V_RMIN      ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P3_V_RMAX      ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P3_V_NUMR      ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P3_V_DEMNR     ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P3_V_OFFSET    ( 0U )

/* INIT_Cam_Buffer_3_b30 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_3_RMIN            ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_3_RMAX            ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_3_NUMR            ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_3_DEMNR           ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_3_OFFSET          ( 0U )

/* INIT_Cam_Buffer_3_V_b1 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_3_V_RMIN          ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_3_V_RMAX          ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_3_V_NUMR          ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_3_V_DEMNR         ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_3_V_OFFSET        ( 0U )

/* INIT_Cam_Sensor_ID_P2_b64 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P2_RMIN        ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P2_RMAX        ( 18446744073709551615U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P2_NUMR        ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P2_DEMNR       ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P2_OFFSET      ( 0U )

/* INIT_Cam_Sensor_ID_P2_V_b1 signal Enums */
typedef boolean CAMINITPRINITCamSensorIDP2V;
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P2_V_FALSE     ( CAMINITPRINITCamSensorIDP2V ) ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P2_V_TRUE      ( CAMINITPRINITCamSensorIDP2V ) ( 1U )

/* INIT_Cam_Sensor_ID_P2_V_b1 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P2_V_RMIN      ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P2_V_RMAX      ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P2_V_NUMR      ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P2_V_DEMNR     ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P2_V_OFFSET    ( 0U )

/* INIT_Cam_Buffer_2_b30 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_2_RMIN            ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_2_RMAX            ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_2_NUMR            ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_2_DEMNR           ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_2_OFFSET          ( 0U )

/* INIT_Cam_Buffer_2_V_b1 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_2_V_RMIN          ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_2_V_RMAX          ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_2_V_NUMR          ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_2_V_DEMNR         ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_2_V_OFFSET        ( 0U )

/* INIT_Cam_Sensor_ID_P1_b64 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P1_RMIN        ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P1_RMAX        ( 18446744073709551615U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P1_NUMR        ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P1_DEMNR       ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P1_OFFSET      ( 0U )

/* INIT_Cam_Sensor_ID_P1_V_b1 signal Enums */
typedef boolean CAMINITPRINITCamSensorIDP1V;
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P1_V_FALSE     ( CAMINITPRINITCamSensorIDP1V ) ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P1_V_TRUE      ( CAMINITPRINITCamSensorIDP1V ) ( 1U )

/* INIT_Cam_Sensor_ID_P1_V_b1 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P1_V_RMIN      ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P1_V_RMAX      ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P1_V_NUMR      ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P1_V_DEMNR     ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_SENSOR_ID_P1_V_OFFSET    ( 0U )

/* INIT_Cam_Buffer_1_b30 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_1_RMIN            ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_1_RMAX            ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_1_NUMR            ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_1_DEMNR           ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_1_OFFSET          ( 0U )

/* INIT_Cam_Buffer_1_V_b1 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_1_V_RMIN          ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_1_V_RMAX          ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_1_V_NUMR          ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_1_V_DEMNR         ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_BUFFER_1_V_OFFSET        ( 0U )

/* INIT_Cam_Optional_Signals_b16 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_OPTIONAL_SIGNALS_RMIN    ( 18U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_OPTIONAL_SIGNALS_RMAX    ( 18U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_OPTIONAL_SIGNALS_NUMR    ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_OPTIONAL_SIGNALS_DEMNR   ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_OPTIONAL_SIGNALS_OFFSET  ( 0U )

/* INIT_Cam_Protocol_Version_b8 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_PROTOCOL_VERSION_RMIN    ( 6U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_PROTOCOL_VERSION_RMAX    ( 6U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_PROTOCOL_VERSION_NUMR    ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_PROTOCOL_VERSION_DEMNR   ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_PROTOCOL_VERSION_OFFSET  ( 0U )

/* INIT_Cam_Zero_Byte_b8 signal Min & Max range limits */
#define C_EYEQMSG_CAMINITPR_INIT_CAM_ZERO_BYTE_RMIN           ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_ZERO_BYTE_RMAX           ( 0U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_ZERO_BYTE_NUMR           ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_ZERO_BYTE_DEMNR          ( 1U )
#define C_EYEQMSG_CAMINITPR_INIT_CAM_ZERO_BYTE_OFFSET         ( 0U )


/*****************************************************************************
                  Exported function-like macros
*****************************************************************************/
/*****************************************************************************
                  Exported defined macros
*****************************************************************************/
/*****************************************************************************
                  Exported types, enums definitions
*****************************************************************************/
typedef struct
{
   #if ENABLE_BIG_ENDIAN_FORMAT
      uint32        INIT_Cam_Zero_Byte_b8                        : 8U;
      
      uint32        INIT_Cam_Protocol_Version_b8                 : 8U;
      
      uint32        INIT_Cam_Optional_Signals_1_b8               : 8U;
      
      uint32        INIT_Cam_Optional_Signals_2_b8               : 8U;
      
      uint32        unused1_b7                                   : 7;
      uint32        INIT_Cam_Buffer_1_V_b1                       : 1U;
      
      uint32        INIT_Cam_Buffer_1_1_b7                       : 7U;
      
      uint32        INIT_Cam_Buffer_1_2_b8                       : 8U;
      
      uint32        INIT_Cam_Buffer_1_3_b8                       : 8U;
      
      uint32        INIT_Cam_Buffer_1_4_b7                       : 7U;
      
      uint32        INIT_Cam_Sensor_ID_P1_V_b1                   : 1U;
      
      uint32        INIT_Cam_Sensor_ID_P1_1_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P1_2_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P1_3_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P1_4_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P1_5_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P1_6_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P1_7_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P1_8_b8                   : 8U;
      
      uint32        INIT_Cam_Buffer_2_V_b1                       : 1U;
      
      uint32        INIT_Cam_Buffer_2_1_b7                       : 7U;
      
      uint32        INIT_Cam_Buffer_2_2_b8                       : 8U;
      
      uint32        INIT_Cam_Buffer_2_3_b8                       : 8U;
      
      uint32        INIT_Cam_Buffer_2_4_b7                       : 7U;
      
      uint32        INIT_Cam_Sensor_ID_P2_V_b1                   : 1U;
      
      uint32        INIT_Cam_Sensor_ID_P2_1_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P2_2_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P2_3_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P2_4_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P2_5_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P2_6_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P2_7_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P2_8_b8                   : 8U;
      
      uint32        INIT_Cam_Buffer_3_V_b1                       : 1U;
      
      uint32        INIT_Cam_Buffer_3_1_b7                       : 7U;
      
      uint32        INIT_Cam_Buffer_3_2_b8                       : 8U;
      
      uint32        INIT_Cam_Buffer_3_3_b8                       : 8U;
      
      uint32        INIT_Cam_Buffer_3_4_b7                       : 7U;
      
      uint32        INIT_Cam_Sensor_ID_P3_V_b1                   : 1U;
      
      uint32        INIT_Cam_Sensor_ID_P3_1_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P3_2_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P3_3_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P3_4_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P3_5_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P3_6_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P3_7_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P3_8_b8                   : 8U;
      
      uint32        INIT_Cam_Buffer_4_V_b1                       : 1U;
      
      uint32        INIT_Cam_Buffer_4_1_b7                       : 7U;
      
      uint32        INIT_Cam_Buffer_4_2_b8                       : 8U;
      
      uint32        INIT_Cam_Buffer_4_3_b8                       : 8U;
      
      uint32        INIT_Cam_Buffer_4_4_b7                       : 7U;
      
      uint32        INIT_Cam_Sensor_ID_P4_V_b1                   : 1U;
      
      uint32        INIT_Cam_Sensor_ID_P4_1_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P4_2_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P4_3_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P4_4_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P4_5_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P4_6_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P4_7_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P4_8_b8                   : 8U;
      
      uint32        INIT_Cam_Buffer_5_V_b1                       : 1U;
      
      uint32        INIT_Cam_Buffer_5_1_b7                       : 7U;
      
      uint32        INIT_Cam_Buffer_5_2_b8                       : 8U;
      
      uint32        INIT_Cam_Buffer_5_3_b8                       : 8U;
      
      uint32        INIT_Cam_Buffer_5_4_b7                       : 7U;
      
      uint32        INIT_Cam_Sensor_ID_P5_V_b1                   : 1U;
      
      uint32        INIT_Cam_Sensor_ID_P5_1_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P5_2_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P5_3_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P5_4_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P5_5_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P5_6_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P5_7_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P5_8_b8                   : 8U;
      
      uint32        INIT_Cam_Buffer_6_V_b1                       : 1U;
      
      uint32        INIT_Cam_Buffer_6_1_b7                       : 7U;
      
      uint32        INIT_Cam_Buffer_6_2_b8                       : 8U;
      
      uint32        INIT_Cam_Buffer_6_3_b8                       : 8U;
      
      uint32        INIT_Cam_Buffer_6_4_b7                       : 7U;
      
      uint32        INIT_Cam_Sensor_ID_P6_V_b1                   : 1U;
      
      uint32        INIT_Cam_Sensor_ID_P6_1_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P6_2_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P6_3_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P6_4_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P6_5_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P6_6_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P6_7_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P6_8_b8                   : 8U;
      
      uint32        INIT_Cam_Buffer_7_V_b1                       : 1U;
      
      uint32        INIT_Cam_Buffer_7_1_b7                       : 7U;
      
      uint32        INIT_Cam_Buffer_7_2_b8                       : 8U;
      
      uint32        INIT_Cam_Buffer_7_3_b8                       : 8U;
      
      uint32        INIT_Cam_Buffer_7_4_b7                       : 7U;
      
      uint32        INIT_Cam_Sensor_ID_P7_V_b1                   : 1U;
      
      uint32        INIT_Cam_Sensor_ID_P7_1_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P7_2_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P7_3_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P7_4_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P7_5_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P7_6_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P7_7_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P7_8_b8                   : 8U;
      
      uint32        INIT_Cam_Buffer_8_V_b1                       : 1U;
      
      uint32        INIT_Cam_Buffer_8_1_b7                       : 7U;
      
      uint32        INIT_Cam_Buffer_8_2_b8                       : 8U;
      
      uint32        INIT_Cam_Buffer_8_3_b8                       : 8U;
      
      uint32        INIT_Cam_Buffer_8_4_b7                       : 7U;
      
      uint32        INIT_Cam_Sensor_ID_P8_V_b1                   : 1U;
      
      uint32        INIT_Cam_Sensor_ID_P8_1_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P8_2_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P8_3_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P8_4_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P8_5_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P8_6_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P8_7_b8                   : 8U;
      
      uint32        INIT_Cam_Sensor_ID_P8_8_b8                   : 8U;
      
      uint32        INIT_Cam_Buffer_9_V_b1                       : 1U;
      
      uint32        INIT_Cam_Buffer_9_1_b7                       : 7U;
      
      uint32        INIT_Cam_Buffer_9_2_b8                       : 8U;
      
      uint32        INIT_Cam_Buffer_9_3_b8                       : 8U;
      
      uint32        INIT_Cam_Buffer_9_4_b7                       : 7U;
      
      uint32        INIT_Cam_EPROM_CRC_V_b1                      : 1U;
      
      uint32        INIT_Cam_EPROM_CRC_1_b8                      : 8U;
      
      uint32        INIT_Cam_EPROM_CRC_2_b8                      : 8U;
      
      uint32        INIT_Cam_EPROM_CRC_3_b8                      : 8U;
      
      uint32        INIT_Cam_EPROM_CRC_4_b8                      : 8U;
      
      uint32        INIT_Cam_Type_b8                             : 8U;
      
      uint32        INIT_Cam_distortionModelType_b3              : 3U;
      
      uint32        Reserved_1_1_b5                              : 5U;
      
      uint32        Reserved_1_2_b8                              : 8U;
      
      uint32        Reserved_1_3_b8                              : 8U;
      
      uint32        INIT_Cam_CODX_1_sb8                          : 8U;
      
      uint32        INIT_Cam_CODX_2_sb8                          : 8U;
      
      uint32        INIT_Cam_CODX_3_sb8                          : 8U;
      
      uint32        INIT_Cam_CODX_4_sb8                          : 8U;
      
      uint32        INIT_Cam_CODX_5_sb8                          : 8U;
      
      uint32        INIT_Cam_CODX_6_sb8                          : 8U;
      
      uint32        INIT_Cam_CODX_7_sb8                          : 8U;
      
      uint32        INIT_Cam_CODX_8_sb8                          : 8U;
      
      uint32        INIT_Cam_CODY_1_sb8                          : 8U;
      
      uint32        INIT_Cam_CODY_2_sb8                          : 8U;
      
      uint32        INIT_Cam_CODY_3_sb8                          : 8U;
      
      uint32        INIT_Cam_CODY_4_sb8                          : 8U;
      
      uint32        INIT_Cam_CODY_5_sb8                          : 8U;
      
      uint32        INIT_Cam_CODY_6_sb8                          : 8U;
      
      uint32        INIT_Cam_CODY_7_sb8                          : 8U;
      
      uint32        INIT_Cam_CODY_8_sb8                          : 8U;
      
      uint32        INIT_Cam_distorParams0_1_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams0_2_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams0_3_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams0_4_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams0_5_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams0_6_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams0_7_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams0_8_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams1_1_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams1_2_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams1_3_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams1_4_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams1_5_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams1_6_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams1_7_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams1_8_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams2_1_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams2_2_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams2_3_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams2_4_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams2_5_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams2_6_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams2_7_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams2_8_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams3_1_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams3_2_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams3_3_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams3_4_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams3_5_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams3_6_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams3_7_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams3_8_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams4_1_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams4_2_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams4_3_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams4_4_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams4_5_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams4_6_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams4_7_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams4_8_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams5_1_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams5_2_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams5_3_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams5_4_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams5_5_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams5_6_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams5_7_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams5_8_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams6_1_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams6_2_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams6_3_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams6_4_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams6_5_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams6_6_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams6_7_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams6_8_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams7_1_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams7_2_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams7_3_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams7_4_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams7_5_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams7_6_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams7_7_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams7_8_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams8_1_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams8_2_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams8_3_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams8_4_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams8_5_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams8_6_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams8_7_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams8_8_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams9_1_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams9_2_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams9_3_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams9_4_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams9_5_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams9_6_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams9_7_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams9_8_sb8                 : 8U;
      
      uint32        INIT_Cam_distorParams10_1_sb8                : 8U;
      
      uint32        INIT_Cam_distorParams10_2_sb8                : 8U;
      
      uint32        INIT_Cam_distorParams10_3_sb8                : 8U;
      
      uint32        INIT_Cam_distorParams10_4_sb8                : 8U;
      
      uint32        INIT_Cam_distorParams10_5_sb8                : 8U;
      
      uint32        INIT_Cam_distorParams10_6_sb8                : 8U;
      
      uint32        INIT_Cam_distorParams10_7_sb8                : 8U;
      
      uint32        INIT_Cam_distorParams10_8_sb8                : 8U;
      
      uint32        INIT_Cam_distorParams11_1_sb8                : 8U;
      
      uint32        INIT_Cam_distorParams11_2_sb8                : 8U;
      
      uint32        INIT_Cam_distorParams11_3_sb8                : 8U;
      
      uint32        INIT_Cam_distorParams11_4_sb8                : 8U;
      
      uint32        INIT_Cam_distorParams11_5_sb8                : 8U;
      
      uint32        INIT_Cam_distorParams11_6_sb8                : 8U;
      
      uint32        INIT_Cam_distorParams11_7_sb8                : 8U;
      
      uint32        INIT_Cam_distorParams11_8_sb8                : 8U;
      
      uint32        INIT_Cam_distorParams12_1_sb8                : 8U;
      
      uint32        INIT_Cam_distorParams12_2_sb8                : 8U;
      
      uint32        INIT_Cam_distorParams12_3_sb8                : 8U;
      
      uint32        INIT_Cam_distorParams12_4_sb8                : 8U;
      
      uint32        INIT_Cam_distorParams12_5_sb8                : 8U;
      
      uint32        INIT_Cam_distorParams12_6_sb8                : 8U;
      
      uint32        INIT_Cam_distorParams12_7_sb8                : 8U;
      
      uint32        INIT_Cam_distorParams12_8_sb8                : 8U;
      
      uint32        INIT_Cam_distorParams13_1_sb8                : 8U;
      
      uint32        INIT_Cam_distorParams13_2_sb8                : 8U;
      
      uint32        INIT_Cam_distorParams13_3_sb8                : 8U;
      
      uint32        INIT_Cam_distorParams13_4_sb8                : 8U;
      
      uint32        INIT_Cam_distorParams13_5_sb8                : 8U;
      
      uint32        INIT_Cam_distorParams13_6_sb8                : 8U;
      
      uint32        INIT_Cam_distorParams13_7_sb8                : 8U;
      
      uint32        INIT_Cam_distorParams13_8_sb8                : 8U;
      
      uint32        INIT_Cam_distorParams14_1_sb8                : 8U;
      
      uint32        INIT_Cam_distorParams14_2_sb8                : 8U;
      
      uint32        INIT_Cam_distorParams14_3_sb8                : 8U;
      
      uint32        INIT_Cam_distorParams14_4_sb8                : 8U;
      
      uint32        INIT_Cam_distorParams14_5_sb8                : 8U;
      
      uint32        INIT_Cam_distorParams14_6_sb8                : 8U;
      
      uint32        INIT_Cam_distorParams14_7_sb8                : 8U;
      
      uint32        INIT_Cam_distorParams14_8_sb8                : 8U;
      
      uint32        INIT_Cam_distorParams15_1_sb8                : 8U;
      
      uint32        INIT_Cam_distorParams15_2_sb8                : 8U;
      
      uint32        INIT_Cam_distorParams15_3_sb8                : 8U;
      
      uint32        INIT_Cam_distorParams15_4_sb8                : 8U;
      
      uint32        INIT_Cam_distorParams15_5_sb8                : 8U;
      
      uint32        INIT_Cam_distorParams15_6_sb8                : 8U;
      
      uint32        INIT_Cam_distorParams15_7_sb8                : 8U;
      
      uint32        INIT_Cam_distorParams15_8_sb8                : 8U;
      
      uint32        INIT_Cam_FocalLengthX_1_sb8                  : 8U;
      
      uint32        INIT_Cam_FocalLengthX_2_sb8                  : 8U;
      
      uint32        INIT_Cam_FocalLengthX_3_sb8                  : 8U;
      
      uint32        INIT_Cam_FocalLengthX_4_sb8                  : 8U;
      
      uint32        INIT_Cam_FocalLengthX_5_sb8                  : 8U;
      
      uint32        INIT_Cam_FocalLengthX_6_sb8                  : 8U;
      
      uint32        INIT_Cam_FocalLengthX_7_sb8                  : 8U;
      
      uint32        INIT_Cam_FocalLengthX_8_sb8                  : 8U;
      
      uint32        INIT_Cam_FocalLengthY_1_sb8                  : 8U;
      
      uint32        INIT_Cam_FocalLengthY_2_sb8                  : 8U;
      
      uint32        INIT_Cam_FocalLengthY_3_sb8                  : 8U;
      
      uint32        INIT_Cam_FocalLengthY_4_sb8                  : 8U;
      
      uint32        INIT_Cam_FocalLengthY_5_sb8                  : 8U;
      
      uint32        INIT_Cam_FocalLengthY_6_sb8                  : 8U;
      
      uint32        INIT_Cam_FocalLengthY_7_sb8                  : 8U;
      
      uint32        INIT_Cam_FocalLengthY_8_sb8                  : 8U;
      
      uint32        INIT_Cam_Skew_1_sb8                          : 8U;
      
      uint32        INIT_Cam_Skew_2_sb8                          : 8U;
      
      uint32        INIT_Cam_Skew_3_sb8                          : 8U;
      
      uint32        INIT_Cam_Skew_4_sb8                          : 8U;
      
      uint32        INIT_Cam_Skew_5_sb8                          : 8U;
      
      uint32        INIT_Cam_Skew_6_sb8                          : 8U;
      
      uint32        INIT_Cam_Skew_7_sb8                          : 8U;
      
      uint32        INIT_Cam_Skew_8_sb8                          : 8U;
      
      uint32        INIT_Cam_PrincipalPointX_1_sb8               : 8U;
      
      uint32        INIT_Cam_PrincipalPointX_2_sb8               : 8U;
      
      uint32        INIT_Cam_PrincipalPointX_3_sb8               : 8U;
      
      uint32        INIT_Cam_PrincipalPointX_4_sb8               : 8U;
      
      uint32        INIT_Cam_PrincipalPointX_5_sb8               : 8U;
      
      uint32        INIT_Cam_PrincipalPointX_6_sb8               : 8U;
      
      uint32        INIT_Cam_PrincipalPointX_7_sb8               : 8U;
      
      uint32        INIT_Cam_PrincipalPointX_8_sb8               : 8U;
      
      uint32        INIT_Cam_PrincipalPointY_1_sb8               : 8U;
      
      uint32        INIT_Cam_PrincipalPointY_2_sb8               : 8U;
      
      uint32        INIT_Cam_PrincipalPointY_3_sb8               : 8U;
      
      uint32        INIT_Cam_PrincipalPointY_4_sb8               : 8U;
      
      uint32        INIT_Cam_PrincipalPointY_5_sb8               : 8U;
      
      uint32        INIT_Cam_PrincipalPointY_6_sb8               : 8U;
      
      uint32        INIT_Cam_PrincipalPointY_7_sb8               : 8U;
      
      uint32        INIT_Cam_PrincipalPointY_8_sb8               : 8U;
      
   #else
      uint32        INIT_Cam_Zero_Byte_b8                        : 8U;
      
      uint32        INIT_Cam_Protocol_Version_b8                 : 8U;
      
      uint32        INIT_Cam_Optional_Signals_b16                : 16U;
      
      uint32        INIT_Cam_Buffer_1_V_b1                       : 1U;
      
      uint32        INIT_Cam_Buffer_1_b30                        : 30U;
      
      uint32        INIT_Cam_Sensor_ID_P1_V_b1                   : 1U;
      
      uint32        INIT_Cam_Sensor_ID_P1_1_b32                  : 32U;
      
      uint32        INIT_Cam_Sensor_ID_P1_2_b32                  : 32U;
      
      uint32        INIT_Cam_Buffer_2_V_b1                       : 1U;
      
      uint32        INIT_Cam_Buffer_2_b30                        : 30U;
      
      uint32        INIT_Cam_Sensor_ID_P2_V_b1                   : 1U;
      
      uint32        INIT_Cam_Sensor_ID_P2_1_b32                  : 32U;
      
      uint32        INIT_Cam_Sensor_ID_P2_2_b32                  : 32U;
      
      uint32        INIT_Cam_Buffer_3_V_b1                       : 1U;
      
      uint32        INIT_Cam_Buffer_3_b30                        : 30U;
      
      uint32        INIT_Cam_Sensor_ID_P3_V_b1                   : 1U;
      
      uint32        INIT_Cam_Sensor_ID_P3_1_b32                  : 32U;
      
      uint32        INIT_Cam_Sensor_ID_P3_2_b32                  : 32U;
      
      uint32        INIT_Cam_Buffer_4_V_b1                       : 1U;
      
      uint32        INIT_Cam_Buffer_4_b30                        : 30U;
      
      uint32        INIT_Cam_Sensor_ID_P4_V_b1                   : 1U;
      
      uint32        INIT_Cam_Sensor_ID_P4_1_b32                  : 32U;
      
      uint32        INIT_Cam_Sensor_ID_P4_2_b32                  : 32U;
      
      uint32        INIT_Cam_Buffer_5_V_b1                       : 1U;
      
      uint32        INIT_Cam_Buffer_5_b30                        : 30U;
      
      uint32        INIT_Cam_Sensor_ID_P5_V_b1                   : 1U;
      
      uint32        INIT_Cam_Sensor_ID_P5_1_b32                  : 32U;
      
      uint32        INIT_Cam_Sensor_ID_P5_2_b32                  : 32U;
      
      uint32        INIT_Cam_Buffer_6_V_b1                       : 1U;
      
      uint32        INIT_Cam_Buffer_6_b30                        : 30U;
      
      uint32        INIT_Cam_Sensor_ID_P6_V_b1                   : 1U;
      
      uint32        INIT_Cam_Sensor_ID_P6_1_b32                  : 32U;
      
      uint32        INIT_Cam_Sensor_ID_P6_2_b32                  : 32U;
      
      uint32        INIT_Cam_Buffer_7_V_b1                       : 1U;
      
      uint32        INIT_Cam_Buffer_7_b30                        : 30U;
      
      uint32        INIT_Cam_Sensor_ID_P7_V_b1                   : 1U;
      
      uint32        INIT_Cam_Sensor_ID_P7_1_b32                  : 32U;
      
      uint32        INIT_Cam_Sensor_ID_P7_2_b32                  : 32U;
      
      uint32        INIT_Cam_Buffer_8_V_b1                       : 1U;
      
      uint32        INIT_Cam_Buffer_8_b30                        : 30U;
      
      uint32        INIT_Cam_Sensor_ID_P8_V_b1                   : 1U;
      
      uint32        INIT_Cam_Sensor_ID_P8_1_b32                  : 32U;
      
      uint32        INIT_Cam_Sensor_ID_P8_2_b32                  : 32U;
      
      uint32        INIT_Cam_Buffer_9_V_b1                       : 1U;
      
      uint32        INIT_Cam_Buffer_9_b30                        : 30U;
      
      uint32        INIT_Cam_EPROM_CRC_V_b1                      : 1U;
      
      uint32        INIT_Cam_EPROM_CRC_b32                       : 32U;
      
      uint32        INIT_Cam_Type_b8                             : 8U;
      
      uint32        INIT_Cam_distortionModelType_b3              : 3U;
      
      uint32        Reserved_1_b21                               : 21U;
      
      uint32        INIT_Cam_CODX_1_sb32                         : 32U;
      
      uint32        INIT_Cam_CODX_2_sb32                         : 32U;
      
      uint32        INIT_Cam_CODY_1_sb32                         : 32U;
      
      uint32        INIT_Cam_CODY_2_sb32                         : 32U;
      
      uint32        INIT_Cam_distorParams0_1_sb32                : 32U;
      
      uint32        INIT_Cam_distorParams0_2_sb32                : 32U;
      
      uint32        INIT_Cam_distorParams1_1_sb32                : 32U;
      
      uint32        INIT_Cam_distorParams1_2_sb32                : 32U;
      
      uint32        INIT_Cam_distorParams2_1_sb32                : 32U;
      
      uint32        INIT_Cam_distorParams2_2_sb32                : 32U;
      
      uint32        INIT_Cam_distorParams3_1_sb32                : 32U;
      
      uint32        INIT_Cam_distorParams3_2_sb32                : 32U;
      
      uint32        INIT_Cam_distorParams4_1_sb32                : 32U;
      
      uint32        INIT_Cam_distorParams4_2_sb32                : 32U;
      
      uint32        INIT_Cam_distorParams5_1_sb32                : 32U;
      
      uint32        INIT_Cam_distorParams5_2_sb32                : 32U;
      
      uint32        INIT_Cam_distorParams6_1_sb32                : 32U;
      
      uint32        INIT_Cam_distorParams6_2_sb32                : 32U;
      
      uint32        INIT_Cam_distorParams7_1_sb32                : 32U;
      
      uint32        INIT_Cam_distorParams7_2_sb32                : 32U;
      
      uint32        INIT_Cam_distorParams8_1_sb32                : 32U;
      
      uint32        INIT_Cam_distorParams8_2_sb32                : 32U;
      
      uint32        INIT_Cam_distorParams9_1_sb32                : 32U;
      
      uint32        INIT_Cam_distorParams9_2_sb32                : 32U;
      
      uint32        INIT_Cam_distorParams10_1_sb32               : 32U;
      
      uint32        INIT_Cam_distorParams10_2_sb32               : 32U;
      
      uint32        INIT_Cam_distorParams11_1_sb32               : 32U;
      
      uint32        INIT_Cam_distorParams11_2_sb32               : 32U;
      
      uint32        INIT_Cam_distorParams12_1_sb32               : 32U;
      
      uint32        INIT_Cam_distorParams12_2_sb32               : 32U;
      
      uint32        INIT_Cam_distorParams13_1_sb32               : 32U;
      
      uint32        INIT_Cam_distorParams13_2_sb32               : 32U;
      
      uint32        INIT_Cam_distorParams14_1_sb32               : 32U;
      
      uint32        INIT_Cam_distorParams14_2_sb32               : 32U;
      
      uint32        INIT_Cam_distorParams15_1_sb32               : 32U;
      
      uint32        INIT_Cam_distorParams15_2_sb32               : 32U;
      
      uint32        INIT_Cam_FocalLengthX_1_sb32                 : 32U;
      
      uint32        INIT_Cam_FocalLengthX_2_sb32                 : 32U;
      
      uint32        INIT_Cam_FocalLengthY_1_sb32                 : 32U;
      
      uint32        INIT_Cam_FocalLengthY_2_sb32                 : 32U;
      
      uint32        INIT_Cam_Skew_1_sb32                         : 32U;
      
      uint32        INIT_Cam_Skew_2_sb32                         : 32U;
      
      uint32        INIT_Cam_PrincipalPointX_1_sb32              : 32U;
      
      uint32        INIT_Cam_PrincipalPointX_2_sb32              : 32U;
      
      uint32        INIT_Cam_PrincipalPointY_1_sb32              : 32U;
      
      uint32        INIT_Cam_PrincipalPointY_2_sb32              : 32U;
      
   #endif
} EYEQMSG_CAMINITPR_Params_t;


/*****************************************************************************
                  Exported function prototypes
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_CAMINITPR_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_CAMINITPR_Params_t * pCamera_Init_parking_rear - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Camera_Init_parking_rear message 
*    Camera_Init_parking_rear message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Camera_Init_parking_rear message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_CAMINITPR_ParamsApp_MsgDataStruct( EYEQMSG_CAMINITPR_Params_t * pCamera_Init_parking_rear );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_Zero_Byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pINIT_Cam_Zero_Byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Zero_Byte
*    INIT_Cam_Zero_Byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Zero_Byte signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_Zero_Byte( uint8 * pINIT_Cam_Zero_Byte );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pINIT_Cam_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Protocol_Version
*    INIT_Cam_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Protocol_Version signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_Protocol_Version( uint8 * pINIT_Cam_Protocol_Version );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_Optional_Signals
*
* FUNCTION ARGUMENTS:
*    uint16 * pINIT_Cam_Optional_Signals - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Optional_Signals
*    INIT_Cam_Optional_Signals returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Optional_Signals signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_Optional_Signals( uint16 * pINIT_Cam_Optional_Signals );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_Buffer_1_V
*
* FUNCTION ARGUMENTS:
*    boolean * pINIT_Cam_Buffer_1_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Buffer_1_V
*    INIT_Cam_Buffer_1_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Buffer_1_V signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_Buffer_1_V( boolean * pINIT_Cam_Buffer_1_V );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_Buffer_1
*
* FUNCTION ARGUMENTS:
*    uint32 * pINIT_Cam_Buffer_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Buffer_1
*    INIT_Cam_Buffer_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Buffer_1 signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_Buffer_1( uint32 * pINIT_Cam_Buffer_1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_Sensor_ID_P1_V
*
* FUNCTION ARGUMENTS:
*    CAMINITPRINITCamSensorIDP1V * pINIT_Cam_Sensor_ID_P1_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Sensor_ID_P1_V
*    INIT_Cam_Sensor_ID_P1_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Sensor_ID_P1_V signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_Sensor_ID_P1_V( CAMINITPRINITCamSensorIDP1V * pINIT_Cam_Sensor_ID_P1_V );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_Sensor_ID_P1
*
* FUNCTION ARGUMENTS:
*    uint64 * pINIT_Cam_Sensor_ID_P1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Sensor_ID_P1
*    INIT_Cam_Sensor_ID_P1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Sensor_ID_P1 signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_Sensor_ID_P1( uint64 * pINIT_Cam_Sensor_ID_P1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_Buffer_2_V
*
* FUNCTION ARGUMENTS:
*    boolean * pINIT_Cam_Buffer_2_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Buffer_2_V
*    INIT_Cam_Buffer_2_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Buffer_2_V signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_Buffer_2_V( boolean * pINIT_Cam_Buffer_2_V );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_Buffer_2
*
* FUNCTION ARGUMENTS:
*    uint32 * pINIT_Cam_Buffer_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Buffer_2
*    INIT_Cam_Buffer_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Buffer_2 signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_Buffer_2( uint32 * pINIT_Cam_Buffer_2 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_Sensor_ID_P2_V
*
* FUNCTION ARGUMENTS:
*    CAMINITPRINITCamSensorIDP2V * pINIT_Cam_Sensor_ID_P2_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Sensor_ID_P2_V
*    INIT_Cam_Sensor_ID_P2_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Sensor_ID_P2_V signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_Sensor_ID_P2_V( CAMINITPRINITCamSensorIDP2V * pINIT_Cam_Sensor_ID_P2_V );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_Sensor_ID_P2
*
* FUNCTION ARGUMENTS:
*    uint64 * pINIT_Cam_Sensor_ID_P2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Sensor_ID_P2
*    INIT_Cam_Sensor_ID_P2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Sensor_ID_P2 signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_Sensor_ID_P2( uint64 * pINIT_Cam_Sensor_ID_P2 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_Buffer_3_V
*
* FUNCTION ARGUMENTS:
*    boolean * pINIT_Cam_Buffer_3_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Buffer_3_V
*    INIT_Cam_Buffer_3_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Buffer_3_V signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_Buffer_3_V( boolean * pINIT_Cam_Buffer_3_V );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_Buffer_3
*
* FUNCTION ARGUMENTS:
*    uint32 * pINIT_Cam_Buffer_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Buffer_3
*    INIT_Cam_Buffer_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Buffer_3 signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_Buffer_3( uint32 * pINIT_Cam_Buffer_3 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_Sensor_ID_P3_V
*
* FUNCTION ARGUMENTS:
*    CAMINITPRINITCamSensorIDP3V * pINIT_Cam_Sensor_ID_P3_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Sensor_ID_P3_V
*    INIT_Cam_Sensor_ID_P3_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Sensor_ID_P3_V signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_Sensor_ID_P3_V( CAMINITPRINITCamSensorIDP3V * pINIT_Cam_Sensor_ID_P3_V );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_Sensor_ID_P3
*
* FUNCTION ARGUMENTS:
*    uint64 * pINIT_Cam_Sensor_ID_P3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Sensor_ID_P3
*    INIT_Cam_Sensor_ID_P3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Sensor_ID_P3 signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_Sensor_ID_P3( uint64 * pINIT_Cam_Sensor_ID_P3 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_Buffer_4_V
*
* FUNCTION ARGUMENTS:
*    boolean * pINIT_Cam_Buffer_4_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Buffer_4_V
*    INIT_Cam_Buffer_4_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Buffer_4_V signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_Buffer_4_V( boolean * pINIT_Cam_Buffer_4_V );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_Buffer_4
*
* FUNCTION ARGUMENTS:
*    uint32 * pINIT_Cam_Buffer_4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Buffer_4
*    INIT_Cam_Buffer_4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Buffer_4 signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_Buffer_4( uint32 * pINIT_Cam_Buffer_4 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_Sensor_ID_P4_V
*
* FUNCTION ARGUMENTS:
*    CAMINITPRINITCamSensorIDP4V * pINIT_Cam_Sensor_ID_P4_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Sensor_ID_P4_V
*    INIT_Cam_Sensor_ID_P4_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Sensor_ID_P4_V signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_Sensor_ID_P4_V( CAMINITPRINITCamSensorIDP4V * pINIT_Cam_Sensor_ID_P4_V );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_Sensor_ID_P4
*
* FUNCTION ARGUMENTS:
*    uint64 * pINIT_Cam_Sensor_ID_P4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Sensor_ID_P4
*    INIT_Cam_Sensor_ID_P4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Sensor_ID_P4 signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_Sensor_ID_P4( uint64 * pINIT_Cam_Sensor_ID_P4 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_Buffer_5_V
*
* FUNCTION ARGUMENTS:
*    boolean * pINIT_Cam_Buffer_5_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Buffer_5_V
*    INIT_Cam_Buffer_5_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Buffer_5_V signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_Buffer_5_V( boolean * pINIT_Cam_Buffer_5_V );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_Buffer_5
*
* FUNCTION ARGUMENTS:
*    uint32 * pINIT_Cam_Buffer_5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Buffer_5
*    INIT_Cam_Buffer_5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Buffer_5 signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_Buffer_5( uint32 * pINIT_Cam_Buffer_5 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_Sensor_ID_P5_V
*
* FUNCTION ARGUMENTS:
*    CAMINITPRINITCamSensorIDP5V * pINIT_Cam_Sensor_ID_P5_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Sensor_ID_P5_V
*    INIT_Cam_Sensor_ID_P5_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Sensor_ID_P5_V signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_Sensor_ID_P5_V( CAMINITPRINITCamSensorIDP5V * pINIT_Cam_Sensor_ID_P5_V );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_Sensor_ID_P5
*
* FUNCTION ARGUMENTS:
*    uint64 * pINIT_Cam_Sensor_ID_P5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Sensor_ID_P5
*    INIT_Cam_Sensor_ID_P5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Sensor_ID_P5 signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_Sensor_ID_P5( uint64 * pINIT_Cam_Sensor_ID_P5 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_Buffer_6_V
*
* FUNCTION ARGUMENTS:
*    boolean * pINIT_Cam_Buffer_6_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Buffer_6_V
*    INIT_Cam_Buffer_6_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Buffer_6_V signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_Buffer_6_V( boolean * pINIT_Cam_Buffer_6_V );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_Buffer_6
*
* FUNCTION ARGUMENTS:
*    uint32 * pINIT_Cam_Buffer_6 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Buffer_6
*    INIT_Cam_Buffer_6 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Buffer_6 signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_Buffer_6( uint32 * pINIT_Cam_Buffer_6 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_Sensor_ID_P6_V
*
* FUNCTION ARGUMENTS:
*    CAMINITPRINITCamSensorIDP6V * pINIT_Cam_Sensor_ID_P6_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Sensor_ID_P6_V
*    INIT_Cam_Sensor_ID_P6_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Sensor_ID_P6_V signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_Sensor_ID_P6_V( CAMINITPRINITCamSensorIDP6V * pINIT_Cam_Sensor_ID_P6_V );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_Sensor_ID_P6
*
* FUNCTION ARGUMENTS:
*    uint64 * pINIT_Cam_Sensor_ID_P6 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Sensor_ID_P6
*    INIT_Cam_Sensor_ID_P6 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Sensor_ID_P6 signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_Sensor_ID_P6( uint64 * pINIT_Cam_Sensor_ID_P6 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_Buffer_7_V
*
* FUNCTION ARGUMENTS:
*    boolean * pINIT_Cam_Buffer_7_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Buffer_7_V
*    INIT_Cam_Buffer_7_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Buffer_7_V signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_Buffer_7_V( boolean * pINIT_Cam_Buffer_7_V );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_Buffer_7
*
* FUNCTION ARGUMENTS:
*    uint32 * pINIT_Cam_Buffer_7 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Buffer_7
*    INIT_Cam_Buffer_7 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Buffer_7 signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_Buffer_7( uint32 * pINIT_Cam_Buffer_7 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_Sensor_ID_P7_V
*
* FUNCTION ARGUMENTS:
*    CAMINITPRINITCamSensorIDP7V * pINIT_Cam_Sensor_ID_P7_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Sensor_ID_P7_V
*    INIT_Cam_Sensor_ID_P7_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Sensor_ID_P7_V signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_Sensor_ID_P7_V( CAMINITPRINITCamSensorIDP7V * pINIT_Cam_Sensor_ID_P7_V );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_Sensor_ID_P7
*
* FUNCTION ARGUMENTS:
*    uint64 * pINIT_Cam_Sensor_ID_P7 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Sensor_ID_P7
*    INIT_Cam_Sensor_ID_P7 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Sensor_ID_P7 signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_Sensor_ID_P7( uint64 * pINIT_Cam_Sensor_ID_P7 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_Buffer_8_V
*
* FUNCTION ARGUMENTS:
*    boolean * pINIT_Cam_Buffer_8_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Buffer_8_V
*    INIT_Cam_Buffer_8_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Buffer_8_V signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_Buffer_8_V( boolean * pINIT_Cam_Buffer_8_V );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_Buffer_8
*
* FUNCTION ARGUMENTS:
*    uint32 * pINIT_Cam_Buffer_8 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Buffer_8
*    INIT_Cam_Buffer_8 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Buffer_8 signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_Buffer_8( uint32 * pINIT_Cam_Buffer_8 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_Sensor_ID_P8_V
*
* FUNCTION ARGUMENTS:
*    CAMINITPRINITCamSensorIDP8V * pINIT_Cam_Sensor_ID_P8_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Sensor_ID_P8_V
*    INIT_Cam_Sensor_ID_P8_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Sensor_ID_P8_V signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_Sensor_ID_P8_V( CAMINITPRINITCamSensorIDP8V * pINIT_Cam_Sensor_ID_P8_V );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_Sensor_ID_P8
*
* FUNCTION ARGUMENTS:
*    uint64 * pINIT_Cam_Sensor_ID_P8 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Sensor_ID_P8
*    INIT_Cam_Sensor_ID_P8 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Sensor_ID_P8 signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_Sensor_ID_P8( uint64 * pINIT_Cam_Sensor_ID_P8 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_Buffer_9_V
*
* FUNCTION ARGUMENTS:
*    boolean * pINIT_Cam_Buffer_9_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Buffer_9_V
*    INIT_Cam_Buffer_9_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Buffer_9_V signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_Buffer_9_V( boolean * pINIT_Cam_Buffer_9_V );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_Buffer_9
*
* FUNCTION ARGUMENTS:
*    uint32 * pINIT_Cam_Buffer_9 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Buffer_9
*    INIT_Cam_Buffer_9 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Buffer_9 signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_Buffer_9( uint32 * pINIT_Cam_Buffer_9 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_EPROM_CRC_V
*
* FUNCTION ARGUMENTS:
*    CAMINITPRINITCamEPROMCRCV * pINIT_Cam_EPROM_CRC_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_EPROM_CRC_V
*    INIT_Cam_EPROM_CRC_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_EPROM_CRC_V signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_EPROM_CRC_V( CAMINITPRINITCamEPROMCRCV * pINIT_Cam_EPROM_CRC_V );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_EPROM_CRC
*
* FUNCTION ARGUMENTS:
*    uint32 * pINIT_Cam_EPROM_CRC - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_EPROM_CRC
*    INIT_Cam_EPROM_CRC returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_EPROM_CRC signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_EPROM_CRC( uint32 * pINIT_Cam_EPROM_CRC );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_Type
*
* FUNCTION ARGUMENTS:
*    CAMINITPRINITCamType * pINIT_Cam_Type - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Type
*    INIT_Cam_Type returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Type signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_Type( CAMINITPRINITCamType * pINIT_Cam_Type );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_distortionModelType
*
* FUNCTION ARGUMENTS:
*    uint8 * pINIT_Cam_distortionModelType - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_distortionModelType
*    INIT_Cam_distortionModelType returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_distortionModelType signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_distortionModelType( uint8 * pINIT_Cam_distortionModelType );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_Reserved_1
*
* FUNCTION ARGUMENTS:
*    uint32 * pReserved_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1
*    Reserved_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1 signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_Reserved_1( uint32 * pReserved_1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_CODX
*
* FUNCTION ARGUMENTS:
*    float64 * pINIT_Cam_CODX - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_CODX
*    INIT_Cam_CODX returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_CODX signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_CODX( float64 * pINIT_Cam_CODX );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_CODY
*
* FUNCTION ARGUMENTS:
*    float64 * pINIT_Cam_CODY - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_CODY
*    INIT_Cam_CODY returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_CODY signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_CODY( float64 * pINIT_Cam_CODY );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_distorParams0
*
* FUNCTION ARGUMENTS:
*    float64 * pINIT_Cam_distorParams0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_distorParams0
*    INIT_Cam_distorParams0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_distorParams0 signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_distorParams0( float64 * pINIT_Cam_distorParams0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_distorParams1
*
* FUNCTION ARGUMENTS:
*    float64 * pINIT_Cam_distorParams1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_distorParams1
*    INIT_Cam_distorParams1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_distorParams1 signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_distorParams1( float64 * pINIT_Cam_distorParams1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_distorParams2
*
* FUNCTION ARGUMENTS:
*    float64 * pINIT_Cam_distorParams2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_distorParams2
*    INIT_Cam_distorParams2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_distorParams2 signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_distorParams2( float64 * pINIT_Cam_distorParams2 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_distorParams3
*
* FUNCTION ARGUMENTS:
*    float64 * pINIT_Cam_distorParams3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_distorParams3
*    INIT_Cam_distorParams3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_distorParams3 signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_distorParams3( float64 * pINIT_Cam_distorParams3 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_distorParams4
*
* FUNCTION ARGUMENTS:
*    float64 * pINIT_Cam_distorParams4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_distorParams4
*    INIT_Cam_distorParams4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_distorParams4 signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_distorParams4( float64 * pINIT_Cam_distorParams4 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_distorParams5
*
* FUNCTION ARGUMENTS:
*    float64 * pINIT_Cam_distorParams5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_distorParams5
*    INIT_Cam_distorParams5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_distorParams5 signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_distorParams5( float64 * pINIT_Cam_distorParams5 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_distorParams6
*
* FUNCTION ARGUMENTS:
*    float64 * pINIT_Cam_distorParams6 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_distorParams6
*    INIT_Cam_distorParams6 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_distorParams6 signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_distorParams6( float64 * pINIT_Cam_distorParams6 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_distorParams7
*
* FUNCTION ARGUMENTS:
*    float64 * pINIT_Cam_distorParams7 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_distorParams7
*    INIT_Cam_distorParams7 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_distorParams7 signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_distorParams7( float64 * pINIT_Cam_distorParams7 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_distorParams8
*
* FUNCTION ARGUMENTS:
*    float64 * pINIT_Cam_distorParams8 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_distorParams8
*    INIT_Cam_distorParams8 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_distorParams8 signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_distorParams8( float64 * pINIT_Cam_distorParams8 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_distorParams9
*
* FUNCTION ARGUMENTS:
*    float64 * pINIT_Cam_distorParams9 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_distorParams9
*    INIT_Cam_distorParams9 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_distorParams9 signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_distorParams9( float64 * pINIT_Cam_distorParams9 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_distorParams10
*
* FUNCTION ARGUMENTS:
*    float64 * pINIT_Cam_distorParams10 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_distorParams10
*    INIT_Cam_distorParams10 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_distorParams10 signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_distorParams10( float64 * pINIT_Cam_distorParams10 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_distorParams11
*
* FUNCTION ARGUMENTS:
*    float64 * pINIT_Cam_distorParams11 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_distorParams11
*    INIT_Cam_distorParams11 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_distorParams11 signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_distorParams11( float64 * pINIT_Cam_distorParams11 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_distorParams12
*
* FUNCTION ARGUMENTS:
*    float64 * pINIT_Cam_distorParams12 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_distorParams12
*    INIT_Cam_distorParams12 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_distorParams12 signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_distorParams12( float64 * pINIT_Cam_distorParams12 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_distorParams13
*
* FUNCTION ARGUMENTS:
*    float64 * pINIT_Cam_distorParams13 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_distorParams13
*    INIT_Cam_distorParams13 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_distorParams13 signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_distorParams13( float64 * pINIT_Cam_distorParams13 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_distorParams14
*
* FUNCTION ARGUMENTS:
*    float64 * pINIT_Cam_distorParams14 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_distorParams14
*    INIT_Cam_distorParams14 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_distorParams14 signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_distorParams14( float64 * pINIT_Cam_distorParams14 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_distorParams15
*
* FUNCTION ARGUMENTS:
*    float64 * pINIT_Cam_distorParams15 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_distorParams15
*    INIT_Cam_distorParams15 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_distorParams15 signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_distorParams15( float64 * pINIT_Cam_distorParams15 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_FocalLengthX
*
* FUNCTION ARGUMENTS:
*    float64 * pINIT_Cam_FocalLengthX - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_FocalLengthX
*    INIT_Cam_FocalLengthX returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_FocalLengthX signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_FocalLengthX( float64 * pINIT_Cam_FocalLengthX );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_FocalLengthY
*
* FUNCTION ARGUMENTS:
*    float64 * pINIT_Cam_FocalLengthY - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_FocalLengthY
*    INIT_Cam_FocalLengthY returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_FocalLengthY signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_FocalLengthY( float64 * pINIT_Cam_FocalLengthY );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_Skew
*
* FUNCTION ARGUMENTS:
*    float64 * pINIT_Cam_Skew - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_Skew
*    INIT_Cam_Skew returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_Skew signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_Skew( float64 * pINIT_Cam_Skew );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_PrincipalPointX
*
* FUNCTION ARGUMENTS:
*    float64 * pINIT_Cam_PrincipalPointX - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_PrincipalPointX
*    INIT_Cam_PrincipalPointX returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_PrincipalPointX signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_PrincipalPointX( float64 * pINIT_Cam_PrincipalPointX );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CAMINITPR_INIT_Cam_PrincipalPointY
*
* FUNCTION ARGUMENTS:
*    float64 * pINIT_Cam_PrincipalPointY - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of INIT_Cam_PrincipalPointY
*    INIT_Cam_PrincipalPointY returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns INIT_Cam_PrincipalPointY signal value of Camera_Init_parking_rear message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CAMINITPR_INIT_Cam_PrincipalPointY( float64 * pINIT_Cam_PrincipalPointY );
/*****************************************************************************
                  Exported object declarations
*****************************************************************************/
extern EYEQMSG_CAMINITPR_Params_t   EYEQMSG_CAMINITPR_Params_s;
extern EYEQMSG_CAMINITPR_Params_t   EYEQMSG_CAMINITPR_ParamsApp_s;
/****************************************************************************/
#endif /* _EYEQMSG_CAMINITPRPROCESS_H_ */


