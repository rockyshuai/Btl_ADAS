#ifndef _EYEQMSG_CORECALSTATICPROCESS_H_
#define _EYEQMSG_CORECALSTATICPROCESS_H_

/*****************************************************************************
                  Included header files
*****************************************************************************/
#include <Std_Types.h>

/*****************************************************************************
                  Include files
*****************************************************************************/
/*****************************************************************************
                  Exported symbolic constants
*****************************************************************************/

/* Datagram message ID */
#define C_EYEQMSG_CORECALSTATIC_MSG_ID                        ( 0x64U )

/* Datagram message lengths */
#define C_EYEQMSG_CORECALSTATIC_MSG_LEN                       ( sizeof(EYEQMSG_CORECALSTATIC_Params_t) )

/* Protocol ENUMs */

/* MCU output messages */

/* Core_Calibration_Static_protocol Enums */
/* CLB_Stat_Buffer_b13 signal Min & Max range limits */
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_BUFFER_RMIN          ( 0U )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_BUFFER_RMAX          ( 0U )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_BUFFER_NUMR          ( 1U )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_BUFFER_DEMNR         ( 1U )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_BUFFER_OFFSET        ( 0U )

/* CLB_Recorder_Status_b3 signal Enums */
typedef uint8 CORECALSTATICCLBRecorderStatus;
#define C_EYEQMSG_CORECALSTATIC_CLB_RECORDER_STATUS_IS_ACTIVATED ( CORECALSTATICCLBRecorderStatus ) ( 0U )
#define C_EYEQMSG_CORECALSTATIC_CLB_RECORDER_STATUS_INIT      ( CORECALSTATICCLBRecorderStatus ) ( 1U )
#define C_EYEQMSG_CORECALSTATIC_CLB_RECORDER_STATUS_COLLECT   ( CORECALSTATICCLBRecorderStatus ) ( 2U )
#define C_EYEQMSG_CORECALSTATIC_CLB_RECORDER_STATUS_PREP_TO_BURN ( CORECALSTATICCLBRecorderStatus ) ( 3U )
#define C_EYEQMSG_CORECALSTATIC_CLB_RECORDER_STATUS_NOTHING_TO_BURN ( CORECALSTATICCLBRecorderStatus ) ( 4U )
#define C_EYEQMSG_CORECALSTATIC_CLB_RECORDER_STATUS_BURN_IN_PROCESS ( CORECALSTATICCLBRecorderStatus ) ( 5U )
#define C_EYEQMSG_CORECALSTATIC_CLB_RECORDER_STATUS_BURN      ( CORECALSTATICCLBRecorderStatus ) ( 6U )
#define C_EYEQMSG_CORECALSTATIC_CLB_RECORDER_STATUS_BURN_DONE ( CORECALSTATICCLBRecorderStatus ) ( 7U )

/* CLB_Recorder_Status_b3 signal Min & Max range limits */
#define C_EYEQMSG_CORECALSTATIC_CLB_RECORDER_STATUS_RMIN      ( 0U )
#define C_EYEQMSG_CORECALSTATIC_CLB_RECORDER_STATUS_RMAX      ( 7U )
#define C_EYEQMSG_CORECALSTATIC_CLB_RECORDER_STATUS_NUMR      ( 1U )
#define C_EYEQMSG_CORECALSTATIC_CLB_RECORDER_STATUS_DEMNR     ( 1U )
#define C_EYEQMSG_CORECALSTATIC_CLB_RECORDER_STATUS_OFFSET    ( 0U )

/* CLB_Stat_CAM_Height_b16 signal Min & Max range limits */
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_CAM_HEIGHT_RMIN      ( 50U )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_CAM_HEIGHT_RMAX      ( 300U )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_CAM_HEIGHT_NUMR      ( 1U )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_CAM_HEIGHT_DEMNR     ( 100U )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_CAM_HEIGHT_OFFSET    ( 0U )

/* CLB_Stat_Roll_sb32 signal Min & Max range limits */
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_ROLL_RMIN            ( -0.05 )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_ROLL_RMAX            ( 0.05 )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_ROLL_NUMR            ( 1 )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_ROLL_DEMNR           ( 1 )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_ROLL_OFFSET          ( 0U )

/* Reserved_2_b12 signal Min & Max range limits */
#define C_EYEQMSG_CORECALSTATIC_RESERVED_2_RMIN               ( 0U )
#define C_EYEQMSG_CORECALSTATIC_RESERVED_2_RMAX               ( 0U )
#define C_EYEQMSG_CORECALSTATIC_RESERVED_2_NUMR               ( 1U )
#define C_EYEQMSG_CORECALSTATIC_RESERVED_2_DEMNR              ( 1U )
#define C_EYEQMSG_CORECALSTATIC_RESERVED_2_OFFSET             ( 0U )

/* CLB_Stat_DIST_Pitch_b10 signal Min & Max range limits */
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_DIST_PITCH_RMIN      ( 0U )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_DIST_PITCH_RMAX      ( 1000U )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_DIST_PITCH_NUMR      ( 1 )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_DIST_PITCH_DEMNR     ( 1 )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_DIST_PITCH_OFFSET    ( -500 )

/* CLB_Stat_DIST_Yaw_b10 signal Min & Max range limits */
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_DIST_YAW_RMIN        ( 0U )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_DIST_YAW_RMAX        ( 1000U )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_DIST_YAW_NUMR        ( 1 )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_DIST_YAW_DEMNR       ( 1 )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_DIST_YAW_OFFSET      ( -500 )

/* CLB_Stat_PH_Pitch_sb32 signal Min & Max range limits */
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_PH_PITCH_RMIN        ( -180 )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_PH_PITCH_RMAX        ( 180 )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_PH_PITCH_NUMR        ( 1 )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_PH_PITCH_DEMNR       ( 1 )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_PH_PITCH_OFFSET      ( 0U )

/* CLB_Stat_PH_Yaw_sb32 signal Min & Max range limits */
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_PH_YAW_RMIN          ( -180 )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_PH_YAW_RMAX          ( 180 )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_PH_YAW_NUMR          ( 1 )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_PH_YAW_DEMNR         ( 1 )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_PH_YAW_OFFSET        ( 0U )

/* CLB_Stat_Header_Buffer_b2 signal Min & Max range limits */
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_HEADER_BUFFER_RMIN   ( 0U )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_HEADER_BUFFER_RMAX   ( 0U )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_HEADER_BUFFER_NUMR   ( 1U )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_HEADER_BUFFER_DEMNR  ( 1U )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_HEADER_BUFFER_OFFSET ( 0U )

/* CLB_Stat_Error_b4 signal Min & Max range limits */
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_ERROR_RMIN           ( 0U )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_ERROR_RMAX           ( 15U )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_ERROR_NUMR           ( 1U )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_ERROR_DEMNR          ( 1U )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_ERROR_OFFSET         ( 0U )

/* CLB_Stat_Progress_b7 signal Enums */
typedef uint8 CORECALSTATICCLBStatProgress;
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_PROGRESS_NONE        ( CORECALSTATICCLBStatProgress ) ( 0U )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_PROGRESS_INIT        ( CORECALSTATICCLBStatProgress ) ( 1U )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_PROGRESS_CLOSE_TARGET_COMPLETE ( CORECALSTATICCLBStatProgress ) ( 2U )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_PROGRESS_FAR_TARGET_COMPLETE ( CORECALSTATICCLBStatProgress ) ( 3U )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_PROGRESS_RESULTS_READY ( CORECALSTATICCLBStatProgress ) ( 4U )

/* CLB_Stat_Progress_b7 signal Min & Max range limits */
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_PROGRESS_RMIN        ( 0U )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_PROGRESS_RMAX        ( 4U )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_PROGRESS_NUMR        ( 1U )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_PROGRESS_DEMNR       ( 1U )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_PROGRESS_OFFSET      ( 0U )

/* CLB_Stat_Run_Mode_b3 signal Enums */
typedef uint8 CORECALSTATICCLBStatRunMode;
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_RUN_MODE_NONE        ( CORECALSTATICCLBStatRunMode ) ( 0U )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_RUN_MODE_TAC2        ( CORECALSTATICCLBStatRunMode ) ( 1U )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_RUN_MODE_SPTAC       ( CORECALSTATICCLBStatRunMode ) ( 2U )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_RUN_MODE_CTAC        ( CORECALSTATICCLBStatRunMode ) ( 3U )

/* CLB_Stat_Run_Mode_b3 signal Min & Max range limits */
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_RUN_MODE_RMIN        ( 0U )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_RUN_MODE_RMAX        ( 6U )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_RUN_MODE_NUMR        ( 1U )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_RUN_MODE_DEMNR       ( 1U )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_RUN_MODE_OFFSET      ( 0U )

/* CLB_Sync_ID_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORECALSTATIC_CLB_SYNC_ID_RMIN              ( 0U )
#define C_EYEQMSG_CORECALSTATIC_CLB_SYNC_ID_RMAX              ( 255U )
#define C_EYEQMSG_CORECALSTATIC_CLB_SYNC_ID_NUMR              ( 1U )
#define C_EYEQMSG_CORECALSTATIC_CLB_SYNC_ID_DEMNR             ( 1U )
#define C_EYEQMSG_CORECALSTATIC_CLB_SYNC_ID_OFFSET            ( 0U )

/* CLB_Stat_Protocol_Version_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_PROTOCOL_VERSION_RMIN ( 4U )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_PROTOCOL_VERSION_RMAX ( 4U )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_PROTOCOL_VERSION_NUMR ( 1U )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_PROTOCOL_VERSION_DEMNR ( 1U )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_PROTOCOL_VERSION_OFFSET ( 0U )

/* CLB_Stat_CRC_b32 signal Min & Max range limits */
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_CRC_RMIN             ( 0U )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_CRC_RMAX             ( 4294967295U )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_CRC_NUMR             ( 1U )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_CRC_DEMNR            ( 1U )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_CRC_OFFSET           ( 0U )

/* Reserved_1_b24 signal Min & Max range limits */
#define C_EYEQMSG_CORECALSTATIC_RESERVED_1_RMIN               ( 0U )
#define C_EYEQMSG_CORECALSTATIC_RESERVED_1_RMAX               ( 0U )
#define C_EYEQMSG_CORECALSTATIC_RESERVED_1_NUMR               ( 1U )
#define C_EYEQMSG_CORECALSTATIC_RESERVED_1_DEMNR              ( 1U )
#define C_EYEQMSG_CORECALSTATIC_RESERVED_1_OFFSET             ( 0U )

/* CLB_Stat_Zero_byte_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_ZERO_BYTE_RMIN       ( 0U )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_ZERO_BYTE_RMAX       ( 255U )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_ZERO_BYTE_NUMR       ( 1U )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_ZERO_BYTE_DEMNR      ( 1U )
#define C_EYEQMSG_CORECALSTATIC_CLB_STAT_ZERO_BYTE_OFFSET     ( 0U )


/*****************************************************************************
                  Exported function-like macros
*****************************************************************************/
/*****************************************************************************
                  Exported defined macros
*****************************************************************************/
/*****************************************************************************
                  Exported types, enums definitions
*****************************************************************************/
typedef struct
{
   #if ENABLE_BIG_ENDIAN_FORMAT
      uint32        CLB_Stat_Zero_byte_b8                        : 8U;
      
      uint32        Reserved_1_1_b8                              : 8U;
      
      uint32        Reserved_1_2_b8                              : 8U;
      
      uint32        Reserved_1_3_b8                              : 8U;
      
      uint32        CLB_Stat_CRC_1_b8                            : 8U;
      
      uint32        CLB_Stat_CRC_2_b8                            : 8U;
      
      uint32        CLB_Stat_CRC_3_b8                            : 8U;
      
      uint32        CLB_Stat_CRC_4_b8                            : 8U;
      
      uint32        CLB_Stat_Protocol_Version_b8                 : 8U;
      
      uint32        CLB_Sync_ID_b8                               : 8U;
      
      uint32        unused1_b5                                   : 5;
      uint32        CLB_Stat_Run_Mode_b3                         : 3U;
      
      uint32        CLB_Stat_Progress_1_b5                       : 5U;
      
      uint32        unused2_b1                                   : 1;
      uint32        CLB_Stat_Progress_2_b2                       : 2U;
      
      uint32        CLB_Stat_Error_b4                            : 4U;
      
      uint32        CLB_Stat_Header_Buffer_b2                    : 2U;
      
      uint32        CLB_Stat_PH_Yaw_1_sb8                        : 8U;
      
      uint32        CLB_Stat_PH_Yaw_2_sb8                        : 8U;
      
      uint32        CLB_Stat_PH_Yaw_3_sb8                        : 8U;
      
      uint32        CLB_Stat_PH_Yaw_4_sb8                        : 8U;
      
      uint32        CLB_Stat_PH_Pitch_1_sb8                      : 8U;
      
      uint32        CLB_Stat_PH_Pitch_2_sb8                      : 8U;
      
      uint32        CLB_Stat_PH_Pitch_3_sb8                      : 8U;
      
      uint32        CLB_Stat_PH_Pitch_4_sb8                      : 8U;
      
      uint32        CLB_Stat_DIST_Yaw_1_b8                       : 8U;
      
      uint32        CLB_Stat_DIST_Yaw_2_b2                       : 2U;
      
      uint32        CLB_Stat_DIST_Pitch_1_b6                     : 6U;
      
      uint32        CLB_Stat_DIST_Pitch_2_b4                     : 4U;
      
      uint32        Reserved_2_1_b4                              : 4U;
      
      uint32        Reserved_2_2_b8                              : 8U;
      
      uint32        CLB_Stat_Roll_1_sb8                          : 8U;
      
      uint32        CLB_Stat_Roll_2_sb8                          : 8U;
      
      uint32        CLB_Stat_Roll_3_sb8                          : 8U;
      
      uint32        CLB_Stat_Roll_4_sb8                          : 8U;
      
      uint32        CLB_Stat_CAM_Height_1_b8                     : 8U;
      
      uint32        CLB_Stat_CAM_Height_2_b8                     : 8U;
      
      uint32        CLB_Recorder_Status_b3                       : 3U;
      
      uint32        CLB_Stat_Buffer_1_b5                         : 5U;
      
      uint32        CLB_Stat_Buffer_2_b8                         : 8U;
      
   #else
      uint32        CLB_Stat_Zero_byte_b8                        : 8U;
      
      uint32        Reserved_1_b24                               : 24U;
      
      uint32        CLB_Stat_CRC_b32                             : 32U;
      
      uint32        CLB_Stat_Protocol_Version_b8                 : 8U;
      
      uint32        CLB_Sync_ID_b8                               : 8U;
      
      uint32        CLB_Stat_Run_Mode_b3                         : 3U;
      
      uint32        CLB_Stat_Progress_b7                         : 7U;
      
      uint32        CLB_Stat_Error_b4                            : 4U;
      
      uint32        CLB_Stat_Header_Buffer_b2                    : 2U;
      
      sint32        CLB_Stat_PH_Yaw_sb32                         : 32;
      
      sint32        CLB_Stat_PH_Pitch_sb32                       : 32;
      
      uint32        CLB_Stat_DIST_Yaw_b10                        : 10U;
      
      uint32        CLB_Stat_DIST_Pitch_b10                      : 10U;
      
      uint32        Reserved_2_b12                               : 12U;
      
      sint32        CLB_Stat_Roll_sb32                           : 32;
      
      uint32        CLB_Stat_CAM_Height_b16                      : 16U;
      
      uint32        CLB_Recorder_Status_b3                       : 3U;
      
      uint32        CLB_Stat_Buffer_b13                          : 13U;
      
   #endif
} EYEQMSG_CORECALSTATIC_Params_t;


/*****************************************************************************
                  Exported function prototypes
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_CORECALSTATIC_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_CORECALSTATIC_Params_t * pCore_Calibration_Static_protocol - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_Calibration_Static_protocol message 
*    Core_Calibration_Static_protocol message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_Calibration_Static_protocol message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_CORECALSTATIC_ParamsApp_MsgDataStruct( EYEQMSG_CORECALSTATIC_Params_t * pCore_Calibration_Static_protocol );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSTATIC_CLB_Stat_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pCLB_Stat_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_Stat_Zero_byte
*    CLB_Stat_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_Stat_Zero_byte signal value of Core_Calibration_Static_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSTATIC_CLB_Stat_Zero_byte( uint8 * pCLB_Stat_Zero_byte );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSTATIC_Reserved_1
*
* FUNCTION ARGUMENTS:
*    uint32 * pReserved_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1
*    Reserved_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1 signal value of Core_Calibration_Static_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSTATIC_Reserved_1( uint32 * pReserved_1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSTATIC_CLB_Stat_CRC
*
* FUNCTION ARGUMENTS:
*    uint32 * pCLB_Stat_CRC - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_Stat_CRC
*    CLB_Stat_CRC returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_Stat_CRC signal value of Core_Calibration_Static_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSTATIC_CLB_Stat_CRC( uint32 * pCLB_Stat_CRC );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSTATIC_CLB_Stat_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pCLB_Stat_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_Stat_Protocol_Version
*    CLB_Stat_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_Stat_Protocol_Version signal value of Core_Calibration_Static_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSTATIC_CLB_Stat_Protocol_Version( uint8 * pCLB_Stat_Protocol_Version );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSTATIC_CLB_Sync_ID
*
* FUNCTION ARGUMENTS:
*    uint8 * pCLB_Sync_ID - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_Sync_ID
*    CLB_Sync_ID returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_Sync_ID signal value of Core_Calibration_Static_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSTATIC_CLB_Sync_ID( uint8 * pCLB_Sync_ID );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSTATIC_CLB_Stat_Run_Mode
*
* FUNCTION ARGUMENTS:
*    CORECALSTATICCLBStatRunMode * pCLB_Stat_Run_Mode - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_Stat_Run_Mode
*    CLB_Stat_Run_Mode returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_Stat_Run_Mode signal value of Core_Calibration_Static_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSTATIC_CLB_Stat_Run_Mode( CORECALSTATICCLBStatRunMode * pCLB_Stat_Run_Mode );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSTATIC_CLB_Stat_Progress
*
* FUNCTION ARGUMENTS:
*    CORECALSTATICCLBStatProgress * pCLB_Stat_Progress - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_Stat_Progress
*    CLB_Stat_Progress returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_Stat_Progress signal value of Core_Calibration_Static_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSTATIC_CLB_Stat_Progress( CORECALSTATICCLBStatProgress * pCLB_Stat_Progress );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSTATIC_CLB_Stat_Error
*
* FUNCTION ARGUMENTS:
*    uint8 * pCLB_Stat_Error - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_Stat_Error
*    CLB_Stat_Error returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_Stat_Error signal value of Core_Calibration_Static_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSTATIC_CLB_Stat_Error( uint8 * pCLB_Stat_Error );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSTATIC_CLB_Stat_Header_Buffer
*
* FUNCTION ARGUMENTS:
*    uint8 * pCLB_Stat_Header_Buffer - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_Stat_Header_Buffer
*    CLB_Stat_Header_Buffer returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_Stat_Header_Buffer signal value of Core_Calibration_Static_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSTATIC_CLB_Stat_Header_Buffer( uint8 * pCLB_Stat_Header_Buffer );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSTATIC_CLB_Stat_PH_Yaw
*
* FUNCTION ARGUMENTS:
*    float32 * pCLB_Stat_PH_Yaw - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_Stat_PH_Yaw
*    CLB_Stat_PH_Yaw returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_Stat_PH_Yaw signal value of Core_Calibration_Static_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSTATIC_CLB_Stat_PH_Yaw( float32 * pCLB_Stat_PH_Yaw );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSTATIC_CLB_Stat_PH_Pitch
*
* FUNCTION ARGUMENTS:
*    float32 * pCLB_Stat_PH_Pitch - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_Stat_PH_Pitch
*    CLB_Stat_PH_Pitch returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_Stat_PH_Pitch signal value of Core_Calibration_Static_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSTATIC_CLB_Stat_PH_Pitch( float32 * pCLB_Stat_PH_Pitch );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSTATIC_CLB_Stat_DIST_Yaw
*
* FUNCTION ARGUMENTS:
*    uint16 * pCLB_Stat_DIST_Yaw - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_Stat_DIST_Yaw
*    CLB_Stat_DIST_Yaw returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_Stat_DIST_Yaw signal value of Core_Calibration_Static_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSTATIC_CLB_Stat_DIST_Yaw( uint16 * pCLB_Stat_DIST_Yaw );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSTATIC_CLB_Stat_DIST_Pitch
*
* FUNCTION ARGUMENTS:
*    uint16 * pCLB_Stat_DIST_Pitch - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_Stat_DIST_Pitch
*    CLB_Stat_DIST_Pitch returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_Stat_DIST_Pitch signal value of Core_Calibration_Static_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSTATIC_CLB_Stat_DIST_Pitch( uint16 * pCLB_Stat_DIST_Pitch );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSTATIC_Reserved_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pReserved_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_2
*    Reserved_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_2 signal value of Core_Calibration_Static_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSTATIC_Reserved_2( uint16 * pReserved_2 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSTATIC_CLB_Stat_Roll
*
* FUNCTION ARGUMENTS:
*    float32 * pCLB_Stat_Roll - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_Stat_Roll
*    CLB_Stat_Roll returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_Stat_Roll signal value of Core_Calibration_Static_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSTATIC_CLB_Stat_Roll( float32 * pCLB_Stat_Roll );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSTATIC_CLB_Stat_CAM_Height
*
* FUNCTION ARGUMENTS:
*    uint16 * pCLB_Stat_CAM_Height - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_Stat_CAM_Height
*    CLB_Stat_CAM_Height returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_Stat_CAM_Height signal value of Core_Calibration_Static_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSTATIC_CLB_Stat_CAM_Height( uint16 * pCLB_Stat_CAM_Height );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSTATIC_CLB_Recorder_Status
*
* FUNCTION ARGUMENTS:
*    CORECALSTATICCLBRecorderStatus * pCLB_Recorder_Status - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_Recorder_Status
*    CLB_Recorder_Status returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_Recorder_Status signal value of Core_Calibration_Static_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSTATIC_CLB_Recorder_Status( CORECALSTATICCLBRecorderStatus * pCLB_Recorder_Status );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSTATIC_CLB_Stat_Buffer
*
* FUNCTION ARGUMENTS:
*    uint16 * pCLB_Stat_Buffer - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_Stat_Buffer
*    CLB_Stat_Buffer returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_Stat_Buffer signal value of Core_Calibration_Static_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSTATIC_CLB_Stat_Buffer( uint16 * pCLB_Stat_Buffer );
/*****************************************************************************
                  Exported object declarations
*****************************************************************************/
extern EYEQMSG_CORECALSTATIC_Params_t   EYEQMSG_CORECALSTATIC_Params_s;
extern EYEQMSG_CORECALSTATIC_Params_t   EYEQMSG_CORECALSTATIC_ParamsApp_s;
/****************************************************************************/
#endif /* _EYEQMSG_CORECALSTATICPROCESS_H_ */


