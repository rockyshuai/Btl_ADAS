#ifndef _EYEQMSG_COREOBJPROCESS_H_
#define _EYEQMSG_COREOBJPROCESS_H_

/*****************************************************************************
                  Included header files
*****************************************************************************/
#include <Std_Types.h>

/*****************************************************************************
                  Include files
*****************************************************************************/
/*****************************************************************************
                  Exported symbolic constants
*****************************************************************************/
#define C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX ( 40U )

/* Datagram message ID */
#define C_EYEQMSG_COREOBJvH_MSG_ID                            ( 0x9AU )
#define C_EYEQMSG_COREOBJvO_MSG_ID                            ( 0x9AU )
#define C_EYEQMSG_COREOBJ_MSG_ID                              ( 0x9AU )

/* Datagram message lengths */
#define C_EYEQMSG_COREOBJvH_MSG_LEN                           ( sizeof(EYEQMSG_COREOBJvH_Params_t) )
#define C_EYEQMSG_COREOBJvO_MSG_LEN                           ( sizeof(EYEQMSG_COREOBJvO_Params_t) )
#define C_EYEQMSG_COREOBJ_MSG_LEN                             ( sizeof(EYEQMSG_COREOBJ_Params_t) )

/* Protocol ENUMs */

/* MCU output messages */

/* Virtual_HEADER_msg_Core_Objects_protocol Enums */
/* Reserved_3_b20 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvH_RESERVED_3_RMIN                   ( 0U )
#define C_EYEQMSG_COREOBJvH_RESERVED_3_RMAX                   ( 0U )
#define C_EYEQMSG_COREOBJvH_RESERVED_3_NUMR                   ( 1U )
#define C_EYEQMSG_COREOBJvH_RESERVED_3_DEMNR                  ( 1U )
#define C_EYEQMSG_COREOBJvH_RESERVED_3_OFFSET                 ( 0U )

/* OBJ_CIPBIC_Lost_b2 signal Enums */
typedef uint8 COREOBJvHOBJCIPBICLost;
#define C_EYEQMSG_COREOBJvH_OBJ_CIPBIC_LOST_NO_LOSS           ( COREOBJvHOBJCIPBICLost ) ( 0U )
#define C_EYEQMSG_COREOBJvH_OBJ_CIPBIC_LOST_LOST_TARGET_FOV_OUT ( COREOBJvHOBJCIPBICLost ) ( 1U )
#define C_EYEQMSG_COREOBJvH_OBJ_CIPBIC_LOST_LOST_TARGET_FOV_IN ( COREOBJvHOBJCIPBICLost ) ( 2U )

/* OBJ_CIPBIC_Lost_b2 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvH_OBJ_CIPBIC_LOST_RMIN              ( 0U )
#define C_EYEQMSG_COREOBJvH_OBJ_CIPBIC_LOST_RMAX              ( 2U )
#define C_EYEQMSG_COREOBJvH_OBJ_CIPBIC_LOST_NUMR              ( 1U )
#define C_EYEQMSG_COREOBJvH_OBJ_CIPBIC_LOST_DEMNR             ( 1U )
#define C_EYEQMSG_COREOBJvH_OBJ_CIPBIC_LOST_OFFSET            ( 0U )

/* OBJ_CIPBIC_ID_b8 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvH_OBJ_CIPBIC_ID_RMIN                ( 0U )
#define C_EYEQMSG_COREOBJvH_OBJ_CIPBIC_ID_RMAX                ( 255U )
#define C_EYEQMSG_COREOBJvH_OBJ_CIPBIC_ID_NUMR                ( 1U )
#define C_EYEQMSG_COREOBJvH_OBJ_CIPBIC_ID_DEMNR               ( 1U )
#define C_EYEQMSG_COREOBJvH_OBJ_CIPBIC_ID_OFFSET              ( 0U )

/* OBJ_Is_Blocked_Right_b1 signal Enums */
typedef boolean COREOBJvHOBJIsBlockedRight;
#define C_EYEQMSG_COREOBJvH_OBJ_IS_BLOCKED_RIGHT_FALSE        ( COREOBJvHOBJIsBlockedRight ) ( 0U )
#define C_EYEQMSG_COREOBJvH_OBJ_IS_BLOCKED_RIGHT_TRUE         ( COREOBJvHOBJIsBlockedRight ) ( 1U )

/* OBJ_Is_Blocked_Right_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvH_OBJ_IS_BLOCKED_RIGHT_RMIN         ( 0U )
#define C_EYEQMSG_COREOBJvH_OBJ_IS_BLOCKED_RIGHT_RMAX         ( 1U )
#define C_EYEQMSG_COREOBJvH_OBJ_IS_BLOCKED_RIGHT_NUMR         ( 1U )
#define C_EYEQMSG_COREOBJvH_OBJ_IS_BLOCKED_RIGHT_DEMNR        ( 1U )
#define C_EYEQMSG_COREOBJvH_OBJ_IS_BLOCKED_RIGHT_OFFSET       ( 0U )

/* OBJ_Is_Blocked_Left_b1 signal Enums */
typedef boolean COREOBJvHOBJIsBlockedLeft;
#define C_EYEQMSG_COREOBJvH_OBJ_IS_BLOCKED_LEFT_FALSE         ( COREOBJvHOBJIsBlockedLeft ) ( 0U )
#define C_EYEQMSG_COREOBJvH_OBJ_IS_BLOCKED_LEFT_TRUE          ( COREOBJvHOBJIsBlockedLeft ) ( 1U )

/* OBJ_Is_Blocked_Left_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvH_OBJ_IS_BLOCKED_LEFT_RMIN          ( 0U )
#define C_EYEQMSG_COREOBJvH_OBJ_IS_BLOCKED_LEFT_RMAX          ( 1U )
#define C_EYEQMSG_COREOBJvH_OBJ_IS_BLOCKED_LEFT_NUMR          ( 1U )
#define C_EYEQMSG_COREOBJvH_OBJ_IS_BLOCKED_LEFT_DEMNR         ( 1U )
#define C_EYEQMSG_COREOBJvH_OBJ_IS_BLOCKED_LEFT_OFFSET        ( 0U )

/* OBJ_VD_Allow_Acc_b2 signal Enums */
typedef uint8 COREOBJvHOBJVDAllowAcc;
#define C_EYEQMSG_COREOBJvH_OBJ_VD_ALLOW_ACC_FREE_SPACE       ( COREOBJvHOBJVDAllowAcc ) ( 0U )
#define C_EYEQMSG_COREOBJvH_OBJ_VD_ALLOW_ACC_SPACE_NOT_FREE   ( COREOBJvHOBJVDAllowAcc ) ( 1U )
#define C_EYEQMSG_COREOBJvH_OBJ_VD_ALLOW_ACC_FREE_SPACE_UNKNOWN ( COREOBJvHOBJVDAllowAcc ) ( 2U )

/* OBJ_VD_Allow_Acc_b2 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvH_OBJ_VD_ALLOW_ACC_RMIN             ( 0U )
#define C_EYEQMSG_COREOBJvH_OBJ_VD_ALLOW_ACC_RMAX             ( 2U )
#define C_EYEQMSG_COREOBJvH_OBJ_VD_ALLOW_ACC_NUMR             ( 1U )
#define C_EYEQMSG_COREOBJvH_OBJ_VD_ALLOW_ACC_DEMNR            ( 1U )
#define C_EYEQMSG_COREOBJvH_OBJ_VD_ALLOW_ACC_OFFSET           ( 0U )

/* OBJ_VD_CIPV_Lost_b2 signal Enums */
typedef uint8 COREOBJvHOBJVDCIPVLost;
#define C_EYEQMSG_COREOBJvH_OBJ_VD_CIPV_LOST_NO_LOSS          ( COREOBJvHOBJVDCIPVLost ) ( 0U )
#define C_EYEQMSG_COREOBJvH_OBJ_VD_CIPV_LOST_LOST_TARGET_FOV_OUT ( COREOBJvHOBJVDCIPVLost ) ( 1U )
#define C_EYEQMSG_COREOBJvH_OBJ_VD_CIPV_LOST_LOST_TARGET_FOV_IN ( COREOBJvHOBJVDCIPVLost ) ( 2U )

/* OBJ_VD_CIPV_Lost_b2 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvH_OBJ_VD_CIPV_LOST_RMIN             ( 0U )
#define C_EYEQMSG_COREOBJvH_OBJ_VD_CIPV_LOST_RMAX             ( 2U )
#define C_EYEQMSG_COREOBJvH_OBJ_VD_CIPV_LOST_NUMR             ( 1U )
#define C_EYEQMSG_COREOBJvH_OBJ_VD_CIPV_LOST_DEMNR            ( 1U )
#define C_EYEQMSG_COREOBJvH_OBJ_VD_CIPV_LOST_OFFSET           ( 0U )

/* OBJ_VD_CIPV_ID_b8 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvH_OBJ_VD_CIPV_ID_RMIN               ( 0U )
#define C_EYEQMSG_COREOBJvH_OBJ_VD_CIPV_ID_RMAX               ( 255U )
#define C_EYEQMSG_COREOBJvH_OBJ_VD_CIPV_ID_NUMR               ( 1U )
#define C_EYEQMSG_COREOBJvH_OBJ_VD_CIPV_ID_DEMNR              ( 1U )
#define C_EYEQMSG_COREOBJvH_OBJ_VD_CIPV_ID_OFFSET             ( 0U )

/* OBJ_VD_NIV_Right_b8 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvH_OBJ_VD_NIV_RIGHT_RMIN             ( 0U )
#define C_EYEQMSG_COREOBJvH_OBJ_VD_NIV_RIGHT_RMAX             ( 255U )
#define C_EYEQMSG_COREOBJvH_OBJ_VD_NIV_RIGHT_NUMR             ( 1U )
#define C_EYEQMSG_COREOBJvH_OBJ_VD_NIV_RIGHT_DEMNR            ( 1U )
#define C_EYEQMSG_COREOBJvH_OBJ_VD_NIV_RIGHT_OFFSET           ( 0U )

/* OBJ_VD_NIV_Left_b8 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvH_OBJ_VD_NIV_LEFT_RMIN              ( 0U )
#define C_EYEQMSG_COREOBJvH_OBJ_VD_NIV_LEFT_RMAX              ( 255U )
#define C_EYEQMSG_COREOBJvH_OBJ_VD_NIV_LEFT_NUMR              ( 1U )
#define C_EYEQMSG_COREOBJvH_OBJ_VD_NIV_LEFT_DEMNR             ( 1U )
#define C_EYEQMSG_COREOBJvH_OBJ_VD_NIV_LEFT_OFFSET            ( 0U )

/* OBJ_Animal_Count_b4 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvH_OBJ_ANIMAL_COUNT_RMIN             ( 0U )
#define C_EYEQMSG_COREOBJvH_OBJ_ANIMAL_COUNT_RMAX             ( 10U )
#define C_EYEQMSG_COREOBJvH_OBJ_ANIMAL_COUNT_NUMR             ( 1U )
#define C_EYEQMSG_COREOBJvH_OBJ_ANIMAL_COUNT_DEMNR            ( 1U )
#define C_EYEQMSG_COREOBJvH_OBJ_ANIMAL_COUNT_OFFSET           ( 0U )

/* Reserved_2_b2 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvH_RESERVED_2_RMIN                   ( 0U )
#define C_EYEQMSG_COREOBJvH_RESERVED_2_RMAX                   ( 0U )
#define C_EYEQMSG_COREOBJvH_RESERVED_2_NUMR                   ( 1U )
#define C_EYEQMSG_COREOBJvH_RESERVED_2_DEMNR                  ( 1U )
#define C_EYEQMSG_COREOBJvH_RESERVED_2_OFFSET                 ( 0U )

/* OBJ_General_OBJ_Count_b4 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvH_OBJ_GENERAL_OBJ_COUNT_RMIN        ( 0U )
#define C_EYEQMSG_COREOBJvH_OBJ_GENERAL_OBJ_COUNT_RMAX        ( 10U )
#define C_EYEQMSG_COREOBJvH_OBJ_GENERAL_OBJ_COUNT_NUMR        ( 1U )
#define C_EYEQMSG_COREOBJvH_OBJ_GENERAL_OBJ_COUNT_DEMNR       ( 1U )
#define C_EYEQMSG_COREOBJvH_OBJ_GENERAL_OBJ_COUNT_OFFSET      ( 0U )

/* OBJ_VD_Count_b5 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvH_OBJ_VD_COUNT_RMIN                 ( 0U )
#define C_EYEQMSG_COREOBJvH_OBJ_VD_COUNT_RMAX                 ( 20U )
#define C_EYEQMSG_COREOBJvH_OBJ_VD_COUNT_NUMR                 ( 1U )
#define C_EYEQMSG_COREOBJvH_OBJ_VD_COUNT_DEMNR                ( 1U )
#define C_EYEQMSG_COREOBJvH_OBJ_VD_COUNT_OFFSET               ( 0U )

/* OBJ_VRU_Count_b5 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvH_OBJ_VRU_COUNT_RMIN                ( 0U )
#define C_EYEQMSG_COREOBJvH_OBJ_VRU_COUNT_RMAX                ( 20U )
#define C_EYEQMSG_COREOBJvH_OBJ_VRU_COUNT_NUMR                ( 1U )
#define C_EYEQMSG_COREOBJvH_OBJ_VRU_COUNT_DEMNR               ( 1U )
#define C_EYEQMSG_COREOBJvH_OBJ_VRU_COUNT_OFFSET              ( 0U )

/* OBJ_Sync_ID_b8 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvH_OBJ_SYNC_ID_RMIN                  ( 0U )
#define C_EYEQMSG_COREOBJvH_OBJ_SYNC_ID_RMAX                  ( 255U )
#define C_EYEQMSG_COREOBJvH_OBJ_SYNC_ID_NUMR                  ( 1U )
#define C_EYEQMSG_COREOBJvH_OBJ_SYNC_ID_DEMNR                 ( 1U )
#define C_EYEQMSG_COREOBJvH_OBJ_SYNC_ID_OFFSET                ( 0U )

/* OBJ_Protocol_Version_b8 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvH_OBJ_PROTOCOL_VERSION_RMIN         ( 12U )
#define C_EYEQMSG_COREOBJvH_OBJ_PROTOCOL_VERSION_RMAX         ( 12U )
#define C_EYEQMSG_COREOBJvH_OBJ_PROTOCOL_VERSION_NUMR         ( 1U )
#define C_EYEQMSG_COREOBJvH_OBJ_PROTOCOL_VERSION_DEMNR        ( 1U )
#define C_EYEQMSG_COREOBJvH_OBJ_PROTOCOL_VERSION_OFFSET       ( 0U )

/* OBJ_Header_CRC_b32 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvH_OBJ_HEADER_CRC_RMIN               ( 0U )
#define C_EYEQMSG_COREOBJvH_OBJ_HEADER_CRC_RMAX               ( 4294967295U )
#define C_EYEQMSG_COREOBJvH_OBJ_HEADER_CRC_NUMR               ( 1U )
#define C_EYEQMSG_COREOBJvH_OBJ_HEADER_CRC_DEMNR              ( 1U )
#define C_EYEQMSG_COREOBJvH_OBJ_HEADER_CRC_OFFSET             ( 0U )

/* Reserved_1_b24 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvH_RESERVED_1_RMIN                   ( 0U )
#define C_EYEQMSG_COREOBJvH_RESERVED_1_RMAX                   ( 0U )
#define C_EYEQMSG_COREOBJvH_RESERVED_1_NUMR                   ( 1U )
#define C_EYEQMSG_COREOBJvH_RESERVED_1_DEMNR                  ( 1U )
#define C_EYEQMSG_COREOBJvH_RESERVED_1_OFFSET                 ( 0U )

/* OBJ_Zero_byte_b8 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvH_OBJ_ZERO_BYTE_RMIN                ( 0U )
#define C_EYEQMSG_COREOBJvH_OBJ_ZERO_BYTE_RMAX                ( 255U )
#define C_EYEQMSG_COREOBJvH_OBJ_ZERO_BYTE_NUMR                ( 1U )
#define C_EYEQMSG_COREOBJvH_OBJ_ZERO_BYTE_DEMNR               ( 1U )
#define C_EYEQMSG_COREOBJvH_OBJ_ZERO_BYTE_OFFSET              ( 0U )


/* Virtual_OBJECT_msg_Core_Objects_protocol Enums */
/* Reserved_23_0_b28 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_RESERVED_23_0_RMIN                ( 0U )
#define C_EYEQMSG_COREOBJvO_RESERVED_23_0_RMAX                ( 0U )
#define C_EYEQMSG_COREOBJvO_RESERVED_23_0_NUMR                ( 1U )
#define C_EYEQMSG_COREOBJvO_RESERVED_23_0_DEMNR               ( 1U )
#define C_EYEQMSG_COREOBJvO_RESERVED_23_0_OFFSET              ( 0U )

/* OBJ_Visible_Left_or_Right_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJVisibleLeftOrRightV0;
#define C_EYEQMSG_COREOBJvO_OBJ_VISIBLE_LEFT_OR_RIGHT_V_0_INVALID ( COREOBJvOOBJVisibleLeftOrRightV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_VISIBLE_LEFT_OR_RIGHT_V_0_VALID ( COREOBJvOOBJVisibleLeftOrRightV0 ) ( 1U )

/* OBJ_Visible_Left_or_Right_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_VISIBLE_LEFT_OR_RIGHT_V_0_RMIN ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_VISIBLE_LEFT_OR_RIGHT_V_0_RMAX ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_VISIBLE_LEFT_OR_RIGHT_V_0_NUMR ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_VISIBLE_LEFT_OR_RIGHT_V_0_DEMNR ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_VISIBLE_LEFT_OR_RIGHT_V_0_OFFSET ( 0U )

/* OBJ_Visible_Left_or_Right_0_b2 signal Enums */
typedef uint8 COREOBJvOOBJVisibleLeftOrRight0;
#define C_EYEQMSG_COREOBJvO_OBJ_VISIBLE_LEFT_OR_RIGHT_0_NOT_VISIABLE ( COREOBJvOOBJVisibleLeftOrRight0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_VISIBLE_LEFT_OR_RIGHT_0_LEFT  ( COREOBJvOOBJVisibleLeftOrRight0 ) ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_VISIBLE_LEFT_OR_RIGHT_0_RIGHT ( COREOBJvOOBJVisibleLeftOrRight0 ) ( 2U )

/* OBJ_Visible_Left_or_Right_0_b2 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_VISIBLE_LEFT_OR_RIGHT_0_RMIN  ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_VISIBLE_LEFT_OR_RIGHT_0_RMAX  ( 2U )
#define C_EYEQMSG_COREOBJvO_OBJ_VISIBLE_LEFT_OR_RIGHT_0_NUMR  ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_VISIBLE_LEFT_OR_RIGHT_0_DEMNR ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_VISIBLE_LEFT_OR_RIGHT_0_OFFSET ( 0U )

/* OBJ_Open_Door_Right_0_b1 signal Enums */
typedef boolean COREOBJvOOBJOpenDoorRight0;
#define C_EYEQMSG_COREOBJvO_OBJ_OPEN_DOOR_RIGHT_0_FALSE       ( COREOBJvOOBJOpenDoorRight0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_OPEN_DOOR_RIGHT_0_TRUE        ( COREOBJvOOBJOpenDoorRight0 ) ( 1U )

/* OBJ_Open_Door_Right_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_OPEN_DOOR_RIGHT_0_RMIN        ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_OPEN_DOOR_RIGHT_0_RMAX        ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_OPEN_DOOR_RIGHT_0_NUMR        ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_OPEN_DOOR_RIGHT_0_DEMNR       ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_OPEN_DOOR_RIGHT_0_OFFSET      ( 0U )

/* OBJ_Open_Door_Left_0_b1 signal Enums */
typedef boolean COREOBJvOOBJOpenDoorLeft0;
#define C_EYEQMSG_COREOBJvO_OBJ_OPEN_DOOR_LEFT_0_FALSE        ( COREOBJvOOBJOpenDoorLeft0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_OPEN_DOOR_LEFT_0_TRUE         ( COREOBJvOOBJOpenDoorLeft0 ) ( 1U )

/* OBJ_Open_Door_Left_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_OPEN_DOOR_LEFT_0_RMIN         ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_OPEN_DOOR_LEFT_0_RMAX         ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_OPEN_DOOR_LEFT_0_NUMR         ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_OPEN_DOOR_LEFT_0_DEMNR        ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_OPEN_DOOR_LEFT_0_OFFSET       ( 0U )

/* OBJ_Angle_Top_STD_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJAngleTopSTDV0;
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_TOP_STD_V_0_INVALID     ( COREOBJvOOBJAngleTopSTDV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_TOP_STD_V_0_VALID       ( COREOBJvOOBJAngleTopSTDV0 ) ( 1U )

/* OBJ_Angle_Top_STD_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_TOP_STD_V_0_RMIN        ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_TOP_STD_V_0_RMAX        ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_TOP_STD_V_0_NUMR        ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_TOP_STD_V_0_DEMNR       ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_TOP_STD_V_0_OFFSET      ( 0U )

/* OBJ_Angle_Top_STD_0_b15 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_TOP_STD_0_RMIN          ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_TOP_STD_0_RMAX          ( 31415U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_TOP_STD_0_NUMR          ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_TOP_STD_0_DEMNR         ( 10000U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_TOP_STD_0_OFFSET        ( 0U )

/* OBJ_Angle_Top_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJAngleTopV0;
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_TOP_V_0_INVALID         ( COREOBJvOOBJAngleTopV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_TOP_V_0_VALID           ( COREOBJvOOBJAngleTopV0 ) ( 1U )

/* OBJ_Angle_Top_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_TOP_V_0_RMIN            ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_TOP_V_0_RMAX            ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_TOP_V_0_NUMR            ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_TOP_V_0_DEMNR           ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_TOP_V_0_OFFSET          ( 0U )

/* OBJ_Angle_Top_0_b14 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_TOP_0_RMIN              ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_TOP_0_RMAX              ( 15708U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_TOP_0_NUMR              ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_TOP_0_DEMNR             ( 5000U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_TOP_0_OFFSET            ( 0U )

/* Reserved_22_0_b6 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_RESERVED_22_0_RMIN                ( 0U )
#define C_EYEQMSG_COREOBJvO_RESERVED_22_0_RMAX                ( 0U )
#define C_EYEQMSG_COREOBJvO_RESERVED_22_0_NUMR                ( 1U )
#define C_EYEQMSG_COREOBJvO_RESERVED_22_0_DEMNR               ( 1U )
#define C_EYEQMSG_COREOBJvO_RESERVED_22_0_OFFSET              ( 0U )

/* OBJ_EMERGENCY_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJEMERGENCYV0;
#define C_EYEQMSG_COREOBJvO_OBJ_EMERGENCY_V_0_FALSE           ( COREOBJvOOBJEMERGENCYV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_EMERGENCY_V_0_TRUE            ( COREOBJvOOBJEMERGENCYV0 ) ( 1U )

/* OBJ_EMERGENCY_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_EMERGENCY_V_0_RMIN            ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_EMERGENCY_V_0_RMAX            ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_EMERGENCY_V_0_NUMR            ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_EMERGENCY_V_0_DEMNR           ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_EMERGENCY_V_0_OFFSET          ( 0U )

/* OBJ_EMERGENCY_LIGHT_COLOR_0_b4 signal Enums */
typedef uint8 COREOBJvOOBJEMERGENCYLIGHTCOLOR0;
#define C_EYEQMSG_COREOBJvO_OBJ_EMERGENCY_LIGHT_COLOR_0__0001_OTHER ( COREOBJvOOBJEMERGENCYLIGHTCOLOR0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_EMERGENCY_LIGHT_COLOR_0__0010_RED ( COREOBJvOOBJEMERGENCYLIGHTCOLOR0 ) ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_EMERGENCY_LIGHT_COLOR_0__0100_BLUE ( COREOBJvOOBJEMERGENCYLIGHTCOLOR0 ) ( 2U )
#define C_EYEQMSG_COREOBJvO_OBJ_EMERGENCY_LIGHT_COLOR_0__1000_ORANGE ( COREOBJvOOBJEMERGENCYLIGHTCOLOR0 ) ( 3U )

/* OBJ_EMERGENCY_LIGHT_COLOR_0_b4 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_EMERGENCY_LIGHT_COLOR_0_RMIN  ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_EMERGENCY_LIGHT_COLOR_0_RMAX  ( 15U )
#define C_EYEQMSG_COREOBJvO_OBJ_EMERGENCY_LIGHT_COLOR_0_NUMR  ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_EMERGENCY_LIGHT_COLOR_0_DEMNR ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_EMERGENCY_LIGHT_COLOR_0_OFFSET ( 0U )

/* OBJ_Is_EMERGENCY_VCL_0_b1 signal Enums */
typedef boolean COREOBJvOOBJIsEMERGENCYVCL0;
#define C_EYEQMSG_COREOBJvO_OBJ_IS_EMERGENCY_VCL_0_FALSE      ( COREOBJvOOBJIsEMERGENCYVCL0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_IS_EMERGENCY_VCL_0_TRUE       ( COREOBJvOOBJIsEMERGENCYVCL0 ) ( 1U )

/* OBJ_Is_EMERGENCY_VCL_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_IS_EMERGENCY_VCL_0_RMIN       ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_IS_EMERGENCY_VCL_0_RMAX       ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_IS_EMERGENCY_VCL_0_NUMR       ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_IS_EMERGENCY_VCL_0_DEMNR      ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_IS_EMERGENCY_VCL_0_OFFSET     ( 0U )

/* OBJ_OverlapAngleEgoLaneL_0_b10 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_OVERLAPANGLEEGOLANEL_0_RMIN   ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_OVERLAPANGLEEGOLANEL_0_RMAX   ( 628U )
#define C_EYEQMSG_COREOBJvO_OBJ_OVERLAPANGLEEGOLANEL_0_NUMR   ( 1 )
#define C_EYEQMSG_COREOBJvO_OBJ_OVERLAPANGLEEGOLANEL_0_DEMNR  ( 100 )
#define C_EYEQMSG_COREOBJvO_OBJ_OVERLAPANGLEEGOLANEL_0_OFFSET ( -3.14f )

/* OBJ_OverlapAngleEgoLaneR_0_b10 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_OVERLAPANGLEEGOLANER_0_RMIN   ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_OVERLAPANGLEEGOLANER_0_RMAX   ( 628U )
#define C_EYEQMSG_COREOBJvO_OBJ_OVERLAPANGLEEGOLANER_0_NUMR   ( 1 )
#define C_EYEQMSG_COREOBJvO_OBJ_OVERLAPANGLEEGOLANER_0_DEMNR  ( 100 )
#define C_EYEQMSG_COREOBJvO_OBJ_OVERLAPANGLEEGOLANER_0_OFFSET ( -3.14f )

/* Reserved_21_0_b2 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_RESERVED_21_0_RMIN                ( 0U )
#define C_EYEQMSG_COREOBJvO_RESERVED_21_0_RMAX                ( 0U )
#define C_EYEQMSG_COREOBJvO_RESERVED_21_0_NUMR                ( 1U )
#define C_EYEQMSG_COREOBJvO_RESERVED_21_0_DEMNR               ( 1U )
#define C_EYEQMSG_COREOBJvO_RESERVED_21_0_OFFSET              ( 0U )

/* OBJ_Occlusion_FL_0_b2 signal Enums */
typedef uint8 COREOBJvOOBJOcclusionFL0;
#define C_EYEQMSG_COREOBJvO_OBJ_OCCLUSION_FL_0_NOT_RELEVANT   ( COREOBJvOOBJOcclusionFL0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_OCCLUSION_FL_0_NOT_OCCLUDED   ( COREOBJvOOBJOcclusionFL0 ) ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_OCCLUSION_FL_0_OCCLUDED       ( COREOBJvOOBJOcclusionFL0 ) ( 2U )

/* OBJ_Occlusion_FL_0_b2 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_OCCLUSION_FL_0_RMIN           ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_OCCLUSION_FL_0_RMAX           ( 2U )
#define C_EYEQMSG_COREOBJvO_OBJ_OCCLUSION_FL_0_NUMR           ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_OCCLUSION_FL_0_DEMNR          ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_OCCLUSION_FL_0_OFFSET         ( 0U )

/* OBJ_Occlusion_FR_0_b2 signal Enums */
typedef uint8 COREOBJvOOBJOcclusionFR0;
#define C_EYEQMSG_COREOBJvO_OBJ_OCCLUSION_FR_0_NOT_RELEVANT   ( COREOBJvOOBJOcclusionFR0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_OCCLUSION_FR_0_NOT_OCCLUDED   ( COREOBJvOOBJOcclusionFR0 ) ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_OCCLUSION_FR_0_OCCLUDED       ( COREOBJvOOBJOcclusionFR0 ) ( 2U )

/* OBJ_Occlusion_FR_0_b2 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_OCCLUSION_FR_0_RMIN           ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_OCCLUSION_FR_0_RMAX           ( 2U )
#define C_EYEQMSG_COREOBJvO_OBJ_OCCLUSION_FR_0_NUMR           ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_OCCLUSION_FR_0_DEMNR          ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_OCCLUSION_FR_0_OFFSET         ( 0U )

/* OBJ_Occlusion_RR_0_b2 signal Enums */
typedef uint8 COREOBJvOOBJOcclusionRR0;
#define C_EYEQMSG_COREOBJvO_OBJ_OCCLUSION_RR_0_NOT_RELEVANT   ( COREOBJvOOBJOcclusionRR0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_OCCLUSION_RR_0_NOT_OCCLUDED   ( COREOBJvOOBJOcclusionRR0 ) ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_OCCLUSION_RR_0_OCCLUDED       ( COREOBJvOOBJOcclusionRR0 ) ( 2U )

/* OBJ_Occlusion_RR_0_b2 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_OCCLUSION_RR_0_RMIN           ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_OCCLUSION_RR_0_RMAX           ( 2U )
#define C_EYEQMSG_COREOBJvO_OBJ_OCCLUSION_RR_0_NUMR           ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_OCCLUSION_RR_0_DEMNR          ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_OCCLUSION_RR_0_OFFSET         ( 0U )

/* OBJ_Occlusion_RL_0_b2 signal Enums */
typedef uint8 COREOBJvOOBJOcclusionRL0;
#define C_EYEQMSG_COREOBJvO_OBJ_OCCLUSION_RL_0_NOT_RELEVANT   ( COREOBJvOOBJOcclusionRL0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_OCCLUSION_RL_0_NOT_OCCLUDED   ( COREOBJvOOBJOcclusionRL0 ) ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_OCCLUSION_RL_0_OCCLUDED       ( COREOBJvOOBJOcclusionRL0 ) ( 2U )

/* OBJ_Occlusion_RL_0_b2 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_OCCLUSION_RL_0_RMIN           ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_OCCLUSION_RL_0_RMAX           ( 2U )
#define C_EYEQMSG_COREOBJvO_OBJ_OCCLUSION_RL_0_NUMR           ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_OCCLUSION_RL_0_DEMNR          ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_OCCLUSION_RL_0_OFFSET         ( 0U )

/* OBJ_Is_VeryClose_0_b1 signal Enums */
typedef boolean COREOBJvOOBJIsVeryClose0;
#define C_EYEQMSG_COREOBJvO_OBJ_IS_VERYCLOSE_0_FALSE          ( COREOBJvOOBJIsVeryClose0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_IS_VERYCLOSE_0_TRUE           ( COREOBJvOOBJIsVeryClose0 ) ( 1U )

/* OBJ_Is_VeryClose_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_IS_VERYCLOSE_0_RMIN           ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_IS_VERYCLOSE_0_RMAX           ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_IS_VERYCLOSE_0_NUMR           ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_IS_VERYCLOSE_0_DEMNR          ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_IS_VERYCLOSE_0_OFFSET         ( 0U )

/* OBJ_Is_VeryClose_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJIsVeryCloseV0;
#define C_EYEQMSG_COREOBJvO_OBJ_IS_VERYCLOSE_V_0_INVALID      ( COREOBJvOOBJIsVeryCloseV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_IS_VERYCLOSE_V_0_VALID        ( COREOBJvOOBJIsVeryCloseV0 ) ( 1U )

/* OBJ_Is_VeryClose_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_IS_VERYCLOSE_V_0_RMIN         ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_IS_VERYCLOSE_V_0_RMAX         ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_IS_VERYCLOSE_V_0_NUMR         ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_IS_VERYCLOSE_V_0_DEMNR        ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_IS_VERYCLOSE_V_0_OFFSET       ( 0U )

/* OBJ_Is_In_Drivable_Area_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJIsInDrivableAreaV0;
#define C_EYEQMSG_COREOBJvO_OBJ_IS_IN_DRIVABLE_AREA_V_0_INVALID ( COREOBJvOOBJIsInDrivableAreaV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_IS_IN_DRIVABLE_AREA_V_0_VALID ( COREOBJvOOBJIsInDrivableAreaV0 ) ( 1U )

/* OBJ_Is_In_Drivable_Area_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_IS_IN_DRIVABLE_AREA_V_0_RMIN  ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_IS_IN_DRIVABLE_AREA_V_0_RMAX  ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_IS_IN_DRIVABLE_AREA_V_0_NUMR  ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_IS_IN_DRIVABLE_AREA_V_0_DEMNR ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_IS_IN_DRIVABLE_AREA_V_0_OFFSET ( 0U )

/* OBJ_Is_In_Drivable_Area_0_b1 signal Enums */
typedef boolean COREOBJvOOBJIsInDrivableArea0;
#define C_EYEQMSG_COREOBJvO_OBJ_IS_IN_DRIVABLE_AREA_0_FALSE   ( COREOBJvOOBJIsInDrivableArea0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_IS_IN_DRIVABLE_AREA_0_TRUE    ( COREOBJvOOBJIsInDrivableArea0 ) ( 1U )

/* OBJ_Is_In_Drivable_Area_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_IS_IN_DRIVABLE_AREA_0_RMIN    ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_IS_IN_DRIVABLE_AREA_0_RMAX    ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_IS_IN_DRIVABLE_AREA_0_NUMR    ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_IS_IN_DRIVABLE_AREA_0_DEMNR   ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_IS_IN_DRIVABLE_AREA_0_OFFSET  ( 0U )

/* OBJ_Visibility_Side_0_b2 signal Enums */
typedef uint8 COREOBJvOOBJVisibilitySide0;
#define C_EYEQMSG_COREOBJvO_OBJ_VISIBILITY_SIDE_0_NOT_VISIBLE ( COREOBJvOOBJVisibilitySide0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_VISIBILITY_SIDE_0_FRONT       ( COREOBJvOOBJVisibilitySide0 ) ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_VISIBILITY_SIDE_0_REAR        ( COREOBJvOOBJVisibilitySide0 ) ( 2U )

/* OBJ_Visibility_Side_0_b2 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_VISIBILITY_SIDE_0_RMIN        ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_VISIBILITY_SIDE_0_RMAX        ( 2U )
#define C_EYEQMSG_COREOBJvO_OBJ_VISIBILITY_SIDE_0_NUMR        ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_VISIBILITY_SIDE_0_DEMNR       ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_VISIBILITY_SIDE_0_OFFSET      ( 0U )

/* OBJ_Visibility_Side_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJVisibilitySideV0;
#define C_EYEQMSG_COREOBJvO_OBJ_VISIBILITY_SIDE_V_0_INVALID   ( COREOBJvOOBJVisibilitySideV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_VISIBILITY_SIDE_V_0_VALID     ( COREOBJvOOBJVisibilitySideV0 ) ( 1U )

/* OBJ_Visibility_Side_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_VISIBILITY_SIDE_V_0_RMIN      ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_VISIBILITY_SIDE_V_0_RMAX      ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_VISIBILITY_SIDE_V_0_NUMR      ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_VISIBILITY_SIDE_V_0_DEMNR     ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_VISIBILITY_SIDE_V_0_OFFSET    ( 0U )

/* OBJ_Angle_Bottom_STD_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJAngleBottomSTDV0;
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_BOTTOM_STD_V_0_INVALID  ( COREOBJvOOBJAngleBottomSTDV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_BOTTOM_STD_V_0_VALID    ( COREOBJvOOBJAngleBottomSTDV0 ) ( 1U )

/* OBJ_Angle_Bottom_STD_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_BOTTOM_STD_V_0_RMIN     ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_BOTTOM_STD_V_0_RMAX     ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_BOTTOM_STD_V_0_NUMR     ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_BOTTOM_STD_V_0_DEMNR    ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_BOTTOM_STD_V_0_OFFSET   ( 0U )

/* OBJ_Angle_Bottom_STD_0_b14 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_BOTTOM_STD_0_RMIN       ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_BOTTOM_STD_0_RMAX       ( 15710U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_BOTTOM_STD_0_NUMR       ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_BOTTOM_STD_0_DEMNR      ( 10000U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_BOTTOM_STD_0_OFFSET     ( 0U )

/* Reserved_20_0_b2 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_RESERVED_20_0_RMIN                ( 0U )
#define C_EYEQMSG_COREOBJvO_RESERVED_20_0_RMAX                ( 0U )
#define C_EYEQMSG_COREOBJvO_RESERVED_20_0_NUMR                ( 1U )
#define C_EYEQMSG_COREOBJvO_RESERVED_20_0_DEMNR               ( 1U )
#define C_EYEQMSG_COREOBJvO_RESERVED_20_0_OFFSET              ( 0U )

/* OBJ_Angle_Bottom_0_b14 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_BOTTOM_0_RMIN           ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_BOTTOM_0_RMAX           ( 15710U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_BOTTOM_0_NUMR           ( 1 )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_BOTTOM_0_DEMNR          ( 5000 )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_BOTTOM_0_OFFSET         ( -1.571f )

/* OBJ_Angle_Bottom_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJAngleBottomV0;
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_BOTTOM_V_0_INVALID      ( COREOBJvOOBJAngleBottomV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_BOTTOM_V_0_VALID        ( COREOBJvOOBJAngleBottomV0 ) ( 1U )

/* OBJ_Angle_Bottom_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_BOTTOM_V_0_RMIN         ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_BOTTOM_V_0_RMAX         ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_BOTTOM_V_0_NUMR         ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_BOTTOM_V_0_DEMNR        ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_BOTTOM_V_0_OFFSET       ( 0U )

/* OBJ_Angle_Mid_STD_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJAngleMidSTDV0;
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_MID_STD_V_0_INVALID     ( COREOBJvOOBJAngleMidSTDV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_MID_STD_V_0_VALID       ( COREOBJvOOBJAngleMidSTDV0 ) ( 1U )

/* OBJ_Angle_Mid_STD_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_MID_STD_V_0_RMIN        ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_MID_STD_V_0_RMAX        ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_MID_STD_V_0_NUMR        ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_MID_STD_V_0_DEMNR       ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_MID_STD_V_0_OFFSET      ( 0U )

/* OBJ_Angle_Mid_STD_0_b14 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_MID_STD_0_RMIN          ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_MID_STD_0_RMAX          ( 15710U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_MID_STD_0_NUMR          ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_MID_STD_0_DEMNR         ( 10000U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_MID_STD_0_OFFSET        ( 0U )

/* Reserved_19_0_b2 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_RESERVED_19_0_RMIN                ( 0U )
#define C_EYEQMSG_COREOBJvO_RESERVED_19_0_RMAX                ( 0U )
#define C_EYEQMSG_COREOBJvO_RESERVED_19_0_NUMR                ( 1U )
#define C_EYEQMSG_COREOBJvO_RESERVED_19_0_DEMNR               ( 1U )
#define C_EYEQMSG_COREOBJvO_RESERVED_19_0_OFFSET              ( 0U )

/* OBJ_Angle_Mid_0_b14 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_MID_0_RMIN              ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_MID_0_RMAX              ( 15710U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_MID_0_NUMR              ( 1 )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_MID_0_DEMNR             ( 5000 )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_MID_0_OFFSET            ( -1.571f )

/* OBJ_Angle_Mid_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJAngleMidV0;
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_MID_V_0_INVALID         ( COREOBJvOOBJAngleMidV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_MID_V_0_VALID           ( COREOBJvOOBJAngleMidV0 ) ( 1U )

/* OBJ_Angle_Mid_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_MID_V_0_RMIN            ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_MID_V_0_RMAX            ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_MID_V_0_NUMR            ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_MID_V_0_DEMNR           ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_MID_V_0_OFFSET          ( 0U )

/* OBJ_Angle_Side_STD_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJAngleSideSTDV0;
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_SIDE_STD_V_0_INVALID    ( COREOBJvOOBJAngleSideSTDV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_SIDE_STD_V_0_VALID      ( COREOBJvOOBJAngleSideSTDV0 ) ( 1U )

/* OBJ_Angle_Side_STD_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_SIDE_STD_V_0_RMIN       ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_SIDE_STD_V_0_RMAX       ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_SIDE_STD_V_0_NUMR       ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_SIDE_STD_V_0_DEMNR      ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_SIDE_STD_V_0_OFFSET     ( 0U )

/* OBJ_Angle_Side_STD_0_b14 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_SIDE_STD_0_RMIN         ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_SIDE_STD_0_RMAX         ( 15710U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_SIDE_STD_0_NUMR         ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_SIDE_STD_0_DEMNR        ( 10000U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_SIDE_STD_0_OFFSET       ( 0U )

/* Reserved_18_0_b2 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_RESERVED_18_0_RMIN                ( 0U )
#define C_EYEQMSG_COREOBJvO_RESERVED_18_0_RMAX                ( 0U )
#define C_EYEQMSG_COREOBJvO_RESERVED_18_0_NUMR                ( 1U )
#define C_EYEQMSG_COREOBJvO_RESERVED_18_0_DEMNR               ( 1U )
#define C_EYEQMSG_COREOBJvO_RESERVED_18_0_OFFSET              ( 0U )

/* OBJ_Angle_Side_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJAngleSideV0;
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_SIDE_V_0_INVALID        ( COREOBJvOOBJAngleSideV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_SIDE_V_0_VALID          ( COREOBJvOOBJAngleSideV0 ) ( 1U )

/* OBJ_Angle_Side_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_SIDE_V_0_RMIN           ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_SIDE_V_0_RMAX           ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_SIDE_V_0_NUMR           ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_SIDE_V_0_DEMNR          ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_SIDE_V_0_OFFSET         ( 0U )

/* OBJ_Angle_Side_0_b14 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_SIDE_0_RMIN             ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_SIDE_0_RMAX             ( 15710U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_SIDE_0_NUMR             ( 1 )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_SIDE_0_DEMNR            ( 5000 )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_SIDE_0_OFFSET           ( -1.571f )

/* OBJ_Angle_Left_STD_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJAngleLeftSTDV0;
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_LEFT_STD_V_0_INVALID    ( COREOBJvOOBJAngleLeftSTDV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_LEFT_STD_V_0_VALID      ( COREOBJvOOBJAngleLeftSTDV0 ) ( 1U )

/* OBJ_Angle_Left_STD_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_LEFT_STD_V_0_RMIN       ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_LEFT_STD_V_0_RMAX       ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_LEFT_STD_V_0_NUMR       ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_LEFT_STD_V_0_DEMNR      ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_LEFT_STD_V_0_OFFSET     ( 0U )

/* OBJ_Angle_Left_STD_0_b14 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_LEFT_STD_0_RMIN         ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_LEFT_STD_0_RMAX         ( 15710U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_LEFT_STD_0_NUMR         ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_LEFT_STD_0_DEMNR        ( 10000U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_LEFT_STD_0_OFFSET       ( 0U )

/* Reserved_17_0_b2 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_RESERVED_17_0_RMIN                ( 0U )
#define C_EYEQMSG_COREOBJvO_RESERVED_17_0_RMAX                ( 0U )
#define C_EYEQMSG_COREOBJvO_RESERVED_17_0_NUMR                ( 1U )
#define C_EYEQMSG_COREOBJvO_RESERVED_17_0_DEMNR               ( 1U )
#define C_EYEQMSG_COREOBJvO_RESERVED_17_0_OFFSET              ( 0U )

/* OBJ_Angle_Left_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJAngleLeftV0;
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_LEFT_V_0_INVALID        ( COREOBJvOOBJAngleLeftV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_LEFT_V_0_VALID          ( COREOBJvOOBJAngleLeftV0 ) ( 1U )

/* OBJ_Angle_Left_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_LEFT_V_0_RMIN           ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_LEFT_V_0_RMAX           ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_LEFT_V_0_NUMR           ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_LEFT_V_0_DEMNR          ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_LEFT_V_0_OFFSET         ( 0U )

/* OBJ_Angle_Left_0_b14 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_LEFT_0_RMIN             ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_LEFT_0_RMAX             ( 15710U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_LEFT_0_NUMR             ( 1 )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_LEFT_0_DEMNR            ( 5000 )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_LEFT_0_OFFSET           ( -1.571f )

/* OBJ_Angle_Right_STD_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJAngleRightSTDV0;
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RIGHT_STD_V_0_INVALID   ( COREOBJvOOBJAngleRightSTDV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RIGHT_STD_V_0_VALID     ( COREOBJvOOBJAngleRightSTDV0 ) ( 1U )

/* OBJ_Angle_Right_STD_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RIGHT_STD_V_0_RMIN      ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RIGHT_STD_V_0_RMAX      ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RIGHT_STD_V_0_NUMR      ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RIGHT_STD_V_0_DEMNR     ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RIGHT_STD_V_0_OFFSET    ( 0U )

/* OBJ_Angle_Right_STD_0_b14 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RIGHT_STD_0_RMIN        ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RIGHT_STD_0_RMAX        ( 15710U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RIGHT_STD_0_NUMR        ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RIGHT_STD_0_DEMNR       ( 10000U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RIGHT_STD_0_OFFSET      ( 0U )

/* Reserved_16_0_b4 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_RESERVED_16_0_RMIN                ( 0U )
#define C_EYEQMSG_COREOBJvO_RESERVED_16_0_RMAX                ( 0U )
#define C_EYEQMSG_COREOBJvO_RESERVED_16_0_NUMR                ( 1U )
#define C_EYEQMSG_COREOBJvO_RESERVED_16_0_DEMNR               ( 1U )
#define C_EYEQMSG_COREOBJvO_RESERVED_16_0_OFFSET              ( 0U )

/* OBJ_Angle_Right_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJAngleRightV0;
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RIGHT_V_0_INVALID       ( COREOBJvOOBJAngleRightV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RIGHT_V_0_VALID         ( COREOBJvOOBJAngleRightV0 ) ( 1U )

/* OBJ_Angle_Right_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RIGHT_V_0_RMIN          ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RIGHT_V_0_RMAX          ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RIGHT_V_0_NUMR          ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RIGHT_V_0_DEMNR         ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RIGHT_V_0_OFFSET        ( 0U )

/* OBJ_Angle_Right_0_b14 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RIGHT_0_RMIN            ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RIGHT_0_RMAX            ( 15710U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RIGHT_0_NUMR            ( 1 )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RIGHT_0_DEMNR           ( 5000 )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RIGHT_0_OFFSET          ( -1.571f )

/* OBJ_Angle_Rate_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJAngleRateV0;
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RATE_V_0_INVALID        ( COREOBJvOOBJAngleRateV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RATE_V_0_VALID          ( COREOBJvOOBJAngleRateV0 ) ( 1U )

/* OBJ_Angle_Rate_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RATE_V_0_RMIN           ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RATE_V_0_RMAX           ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RATE_V_0_NUMR           ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RATE_V_0_DEMNR          ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RATE_V_0_OFFSET         ( 0U )

/* OBJ_Angle_Rate_0_b12 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RATE_0_RMIN             ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RATE_0_RMAX             ( 2233U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RATE_0_NUMR             ( 1 )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RATE_0_DEMNR            ( 500 )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RATE_0_OFFSET           ( -2.234f )

/* OBJ_Angle_Rate_STD_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJAngleRateSTDV0;
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RATE_STD_V_0_INVALID    ( COREOBJvOOBJAngleRateSTDV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RATE_STD_V_0_VALID      ( COREOBJvOOBJAngleRateSTDV0 ) ( 1U )

/* OBJ_Angle_Rate_STD_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RATE_STD_V_0_RMIN       ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RATE_STD_V_0_RMAX       ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RATE_STD_V_0_NUMR       ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RATE_STD_V_0_DEMNR      ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RATE_STD_V_0_OFFSET     ( 0U )

/* OBJ_Angle_Rate_STD_0_b15 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RATE_STD_0_RMIN         ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RATE_STD_0_RMAX         ( 22318U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RATE_STD_0_NUMR         ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RATE_STD_0_DEMNR        ( 10000U )
#define C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RATE_STD_0_OFFSET       ( 0U )

/* OBJ_Heading_STD_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJHeadingSTDV0;
#define C_EYEQMSG_COREOBJvO_OBJ_HEADING_STD_V_0_INVALID       ( COREOBJvOOBJHeadingSTDV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_HEADING_STD_V_0_VALID         ( COREOBJvOOBJHeadingSTDV0 ) ( 1U )

/* OBJ_Heading_STD_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_HEADING_STD_V_0_RMIN          ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_HEADING_STD_V_0_RMAX          ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_HEADING_STD_V_0_NUMR          ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_HEADING_STD_V_0_DEMNR         ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_HEADING_STD_V_0_OFFSET        ( 0U )

/* OBJ_Heading_STD_0_b15 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_HEADING_STD_0_RMIN            ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_HEADING_STD_0_RMAX            ( 31400U )
#define C_EYEQMSG_COREOBJvO_OBJ_HEADING_STD_0_NUMR            ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_HEADING_STD_0_DEMNR           ( 10000U )
#define C_EYEQMSG_COREOBJvO_OBJ_HEADING_STD_0_OFFSET          ( 0U )

/* Reserved_15_0_b7 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_RESERVED_15_0_RMIN                ( 0U )
#define C_EYEQMSG_COREOBJvO_RESERVED_15_0_RMAX                ( 0U )
#define C_EYEQMSG_COREOBJvO_RESERVED_15_0_NUMR                ( 1U )
#define C_EYEQMSG_COREOBJvO_RESERVED_15_0_DEMNR               ( 1U )
#define C_EYEQMSG_COREOBJvO_RESERVED_15_0_OFFSET              ( 0U )

/* OBJ_Heading_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJHeadingV0;
#define C_EYEQMSG_COREOBJvO_OBJ_HEADING_V_0_INVALID           ( COREOBJvOOBJHeadingV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_HEADING_V_0_VALID             ( COREOBJvOOBJHeadingV0 ) ( 1U )

/* OBJ_Heading_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_HEADING_V_0_RMIN              ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_HEADING_V_0_RMAX              ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_HEADING_V_0_NUMR              ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_HEADING_V_0_DEMNR             ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_HEADING_V_0_OFFSET            ( 0U )

/* OBJ_Heading_0_b10 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_HEADING_0_RMIN                ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_HEADING_0_RMAX                ( 628U )
#define C_EYEQMSG_COREOBJvO_OBJ_HEADING_0_NUMR                ( 1 )
#define C_EYEQMSG_COREOBJvO_OBJ_HEADING_0_DEMNR               ( 100 )
#define C_EYEQMSG_COREOBJvO_OBJ_HEADING_0_OFFSET              ( -3.14f )

/* OBJ_Absolute_Speed_STD_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJAbsoluteSpeedSTDV0;
#define C_EYEQMSG_COREOBJvO_OBJ_ABSOLUTE_SPEED_STD_V_0_INVALID ( COREOBJvOOBJAbsoluteSpeedSTDV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABSOLUTE_SPEED_STD_V_0_VALID  ( COREOBJvOOBJAbsoluteSpeedSTDV0 ) ( 1U )

/* OBJ_Absolute_Speed_STD_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ABSOLUTE_SPEED_STD_V_0_RMIN   ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABSOLUTE_SPEED_STD_V_0_RMAX   ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABSOLUTE_SPEED_STD_V_0_NUMR   ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABSOLUTE_SPEED_STD_V_0_DEMNR  ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABSOLUTE_SPEED_STD_V_0_OFFSET ( 0U )

/* OBJ_Absolute_Speed_STD_0_b13 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ABSOLUTE_SPEED_STD_0_RMIN     ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABSOLUTE_SPEED_STD_0_RMAX     ( 6500U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABSOLUTE_SPEED_STD_0_NUMR     ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABSOLUTE_SPEED_STD_0_DEMNR    ( 100U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABSOLUTE_SPEED_STD_0_OFFSET   ( 0U )

/* Reserved_14_0_b4 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_RESERVED_14_0_RMIN                ( 0U )
#define C_EYEQMSG_COREOBJvO_RESERVED_14_0_RMAX                ( 0U )
#define C_EYEQMSG_COREOBJvO_RESERVED_14_0_NUMR                ( 1U )
#define C_EYEQMSG_COREOBJvO_RESERVED_14_0_DEMNR               ( 1U )
#define C_EYEQMSG_COREOBJvO_RESERVED_14_0_OFFSET              ( 0U )

/* OBJ_Absolute_Speed_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJAbsoluteSpeedV0;
#define C_EYEQMSG_COREOBJvO_OBJ_ABSOLUTE_SPEED_V_0_INVALID    ( COREOBJvOOBJAbsoluteSpeedV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABSOLUTE_SPEED_V_0_VALID      ( COREOBJvOOBJAbsoluteSpeedV0 ) ( 1U )

/* OBJ_Absolute_Speed_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ABSOLUTE_SPEED_V_0_RMIN       ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABSOLUTE_SPEED_V_0_RMAX       ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABSOLUTE_SPEED_V_0_NUMR       ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABSOLUTE_SPEED_V_0_DEMNR      ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABSOLUTE_SPEED_V_0_OFFSET     ( 0U )

/* OBJ_Absolute_Speed_0_b12 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ABSOLUTE_SPEED_0_RMIN         ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABSOLUTE_SPEED_0_RMAX         ( 2600U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABSOLUTE_SPEED_0_NUMR         ( 1 )
#define C_EYEQMSG_COREOBJvO_OBJ_ABSOLUTE_SPEED_0_DEMNR        ( 20 )
#define C_EYEQMSG_COREOBJvO_OBJ_ABSOLUTE_SPEED_0_OFFSET       ( -65 )

/* OBJ_Lat_Distance_STD_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJLatDistanceSTDV0;
#define C_EYEQMSG_COREOBJvO_OBJ_LAT_DISTANCE_STD_V_0_INVALID  ( COREOBJvOOBJLatDistanceSTDV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_LAT_DISTANCE_STD_V_0_VALID    ( COREOBJvOOBJLatDistanceSTDV0 ) ( 1U )

/* OBJ_Lat_Distance_STD_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_LAT_DISTANCE_STD_V_0_RMIN     ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_LAT_DISTANCE_STD_V_0_RMAX     ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_LAT_DISTANCE_STD_V_0_NUMR     ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_LAT_DISTANCE_STD_V_0_DEMNR    ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_LAT_DISTANCE_STD_V_0_OFFSET   ( 0U )

/* OBJ_Lat_Distance_STD_0_b14 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_LAT_DISTANCE_STD_0_RMIN       ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_LAT_DISTANCE_STD_0_RMAX       ( 10000U )
#define C_EYEQMSG_COREOBJvO_OBJ_LAT_DISTANCE_STD_0_NUMR       ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_LAT_DISTANCE_STD_0_DEMNR      ( 100U )
#define C_EYEQMSG_COREOBJvO_OBJ_LAT_DISTANCE_STD_0_OFFSET     ( 0U )

/* Reserved_13_0_b3 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_RESERVED_13_0_RMIN                ( 0U )
#define C_EYEQMSG_COREOBJvO_RESERVED_13_0_RMAX                ( 0U )
#define C_EYEQMSG_COREOBJvO_RESERVED_13_0_NUMR                ( 1U )
#define C_EYEQMSG_COREOBJvO_RESERVED_13_0_DEMNR               ( 1U )
#define C_EYEQMSG_COREOBJvO_RESERVED_13_0_OFFSET              ( 0U )

/* OBJ_Lat_Distance_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJLatDistanceV0;
#define C_EYEQMSG_COREOBJvO_OBJ_LAT_DISTANCE_V_0_INVALID      ( COREOBJvOOBJLatDistanceV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_LAT_DISTANCE_V_0_VALID        ( COREOBJvOOBJLatDistanceV0 ) ( 1U )

/* OBJ_Lat_Distance_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_LAT_DISTANCE_V_0_RMIN         ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_LAT_DISTANCE_V_0_RMAX         ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_LAT_DISTANCE_V_0_NUMR         ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_LAT_DISTANCE_V_0_DEMNR        ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_LAT_DISTANCE_V_0_OFFSET       ( 0U )

/* OBJ_Lat_Distance_0_b12 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_LAT_DISTANCE_0_RMIN           ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_LAT_DISTANCE_0_RMAX           ( 4000U )
#define C_EYEQMSG_COREOBJvO_OBJ_LAT_DISTANCE_0_NUMR           ( 1 )
#define C_EYEQMSG_COREOBJvO_OBJ_LAT_DISTANCE_0_DEMNR          ( 20 )
#define C_EYEQMSG_COREOBJvO_OBJ_LAT_DISTANCE_0_OFFSET         ( -100 )

/* OBJ_Long_Distance_STD_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJLongDistanceSTDV0;
#define C_EYEQMSG_COREOBJvO_OBJ_LONG_DISTANCE_STD_V_0_INVALID ( COREOBJvOOBJLongDistanceSTDV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_LONG_DISTANCE_STD_V_0_VALID   ( COREOBJvOOBJLongDistanceSTDV0 ) ( 1U )

/* OBJ_Long_Distance_STD_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_LONG_DISTANCE_STD_V_0_RMIN    ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_LONG_DISTANCE_STD_V_0_RMAX    ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_LONG_DISTANCE_STD_V_0_NUMR    ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_LONG_DISTANCE_STD_V_0_DEMNR   ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_LONG_DISTANCE_STD_V_0_OFFSET  ( 0U )

/* OBJ_Long_Distance_STD_0_b15 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_LONG_DISTANCE_STD_0_RMIN      ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_LONG_DISTANCE_STD_0_RMAX      ( 25000U )
#define C_EYEQMSG_COREOBJvO_OBJ_LONG_DISTANCE_STD_0_NUMR      ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_LONG_DISTANCE_STD_0_DEMNR     ( 100U )
#define C_EYEQMSG_COREOBJvO_OBJ_LONG_DISTANCE_STD_0_OFFSET    ( 0U )

/* Reserved_12_0_b3 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_RESERVED_12_0_RMIN                ( 0U )
#define C_EYEQMSG_COREOBJvO_RESERVED_12_0_RMAX                ( 0U )
#define C_EYEQMSG_COREOBJvO_RESERVED_12_0_NUMR                ( 1U )
#define C_EYEQMSG_COREOBJvO_RESERVED_12_0_DEMNR               ( 1U )
#define C_EYEQMSG_COREOBJvO_RESERVED_12_0_OFFSET              ( 0U )

/* OBJ_Long_Distance_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJLongDistanceV0;
#define C_EYEQMSG_COREOBJvO_OBJ_LONG_DISTANCE_V_0_INVALID     ( COREOBJvOOBJLongDistanceV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_LONG_DISTANCE_V_0_VALID       ( COREOBJvOOBJLongDistanceV0 ) ( 1U )

/* OBJ_Long_Distance_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_LONG_DISTANCE_V_0_RMIN        ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_LONG_DISTANCE_V_0_RMAX        ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_LONG_DISTANCE_V_0_NUMR        ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_LONG_DISTANCE_V_0_DEMNR       ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_LONG_DISTANCE_V_0_OFFSET      ( 0U )

/* OBJ_Long_Distance_0_b14 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_LONG_DISTANCE_0_RMIN          ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_LONG_DISTANCE_0_RMAX          ( 14000U )
#define C_EYEQMSG_COREOBJvO_OBJ_LONG_DISTANCE_0_NUMR          ( 1 )
#define C_EYEQMSG_COREOBJvO_OBJ_LONG_DISTANCE_0_DEMNR         ( 20 )
#define C_EYEQMSG_COREOBJvO_OBJ_LONG_DISTANCE_0_OFFSET        ( -200 )

/* OBJ_Rel_Lat_Vel_STD_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJRelLatVelSTDV0;
#define C_EYEQMSG_COREOBJvO_OBJ_REL_LAT_VEL_STD_V_0_INVALID   ( COREOBJvOOBJRelLatVelSTDV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_REL_LAT_VEL_STD_V_0_VALID     ( COREOBJvOOBJRelLatVelSTDV0 ) ( 1U )

/* OBJ_Rel_Lat_Vel_STD_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_REL_LAT_VEL_STD_V_0_RMIN      ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_REL_LAT_VEL_STD_V_0_RMAX      ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_REL_LAT_VEL_STD_V_0_NUMR      ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_REL_LAT_VEL_STD_V_0_DEMNR     ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_REL_LAT_VEL_STD_V_0_OFFSET    ( 0U )

/* OBJ_Relative_Lat_Velocity_STD_0_b13 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LAT_VELOCITY_STD_0_RMIN ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LAT_VELOCITY_STD_0_RMAX ( 5000U )
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LAT_VELOCITY_STD_0_NUMR ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LAT_VELOCITY_STD_0_DEMNR ( 100U )
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LAT_VELOCITY_STD_0_OFFSET ( 0U )

/* Reserved_11_0_b5 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_RESERVED_11_0_RMIN                ( 0U )
#define C_EYEQMSG_COREOBJvO_RESERVED_11_0_RMAX                ( 0U )
#define C_EYEQMSG_COREOBJvO_RESERVED_11_0_NUMR                ( 1U )
#define C_EYEQMSG_COREOBJvO_RESERVED_11_0_DEMNR               ( 1U )
#define C_EYEQMSG_COREOBJvO_RESERVED_11_0_OFFSET              ( 0U )

/* OBJ_Relative_Lat_Velocity_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJRelativeLatVelocityV0;
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LAT_VELOCITY_V_0_INVALID ( COREOBJvOOBJRelativeLatVelocityV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LAT_VELOCITY_V_0_VALID ( COREOBJvOOBJRelativeLatVelocityV0 ) ( 1U )

/* OBJ_Relative_Lat_Velocity_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LAT_VELOCITY_V_0_RMIN ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LAT_VELOCITY_V_0_RMAX ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LAT_VELOCITY_V_0_NUMR ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LAT_VELOCITY_V_0_DEMNR ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LAT_VELOCITY_V_0_OFFSET ( 0U )

/* OBJ_Relative_Lat_Velocity_0_b11 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LAT_VELOCITY_0_RMIN  ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LAT_VELOCITY_0_RMAX  ( 2000U )
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LAT_VELOCITY_0_NUMR  ( 1 )
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LAT_VELOCITY_0_DEMNR ( 20 )
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LAT_VELOCITY_0_OFFSET ( -50 )

/* OBJ_Rel_Long_Vel_STD_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJRelLongVelSTDV0;
#define C_EYEQMSG_COREOBJvO_OBJ_REL_LONG_VEL_STD_V_0_INVALID  ( COREOBJvOOBJRelLongVelSTDV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_REL_LONG_VEL_STD_V_0_VALID    ( COREOBJvOOBJRelLongVelSTDV0 ) ( 1U )

/* OBJ_Rel_Long_Vel_STD_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_REL_LONG_VEL_STD_V_0_RMIN     ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_REL_LONG_VEL_STD_V_0_RMAX     ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_REL_LONG_VEL_STD_V_0_NUMR     ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_REL_LONG_VEL_STD_V_0_DEMNR    ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_REL_LONG_VEL_STD_V_0_OFFSET   ( 0U )

/* OBJ_Relative_Long_Vel_STD_0_b14 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LONG_VEL_STD_0_RMIN  ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LONG_VEL_STD_0_RMAX  ( 13000U )
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LONG_VEL_STD_0_NUMR  ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LONG_VEL_STD_0_DEMNR ( 100U )
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LONG_VEL_STD_0_OFFSET ( 0U )

/* Reserved_10_0_b7 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_RESERVED_10_0_RMIN                ( 0U )
#define C_EYEQMSG_COREOBJvO_RESERVED_10_0_RMAX                ( 0U )
#define C_EYEQMSG_COREOBJvO_RESERVED_10_0_NUMR                ( 1U )
#define C_EYEQMSG_COREOBJvO_RESERVED_10_0_DEMNR               ( 1U )
#define C_EYEQMSG_COREOBJvO_RESERVED_10_0_OFFSET              ( 0U )

/* OBJ_Relative_Long_Velocity_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJRelativeLongVelocityV0;
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LONG_VELOCITY_V_0_INVALID ( COREOBJvOOBJRelativeLongVelocityV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LONG_VELOCITY_V_0_VALID ( COREOBJvOOBJRelativeLongVelocityV0 ) ( 1U )

/* OBJ_Relative_Long_Velocity_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LONG_VELOCITY_V_0_RMIN ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LONG_VELOCITY_V_0_RMAX ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LONG_VELOCITY_V_0_NUMR ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LONG_VELOCITY_V_0_DEMNR ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LONG_VELOCITY_V_0_OFFSET ( 0U )

/* OBJ_Relative_Long_Velocity_0_b13 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LONG_VELOCITY_0_RMIN ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LONG_VELOCITY_0_RMAX ( 5000U )
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LONG_VELOCITY_0_NUMR ( 1 )
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LONG_VELOCITY_0_DEMNR ( 20 )
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LONG_VELOCITY_0_OFFSET ( -120 )

/* OBJ_Rel_Long_Acc_STD_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJRelLongAccSTDV0;
#define C_EYEQMSG_COREOBJvO_OBJ_REL_LONG_ACC_STD_V_0_INVALID  ( COREOBJvOOBJRelLongAccSTDV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_REL_LONG_ACC_STD_V_0_VALID    ( COREOBJvOOBJRelLongAccSTDV0 ) ( 1U )

/* OBJ_Rel_Long_Acc_STD_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_REL_LONG_ACC_STD_V_0_RMIN     ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_REL_LONG_ACC_STD_V_0_RMAX     ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_REL_LONG_ACC_STD_V_0_NUMR     ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_REL_LONG_ACC_STD_V_0_DEMNR    ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_REL_LONG_ACC_STD_V_0_OFFSET   ( 0U )

/* OBJ_Relative_Long_Acc_STD_0_b10 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LONG_ACC_STD_0_RMIN  ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LONG_ACC_STD_0_RMAX  ( 730U )
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LONG_ACC_STD_0_NUMR  ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LONG_ACC_STD_0_DEMNR ( 100U )
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LONG_ACC_STD_0_OFFSET ( 0U )

/* Reserved_9_0_b7 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_RESERVED_9_0_RMIN                 ( 0U )
#define C_EYEQMSG_COREOBJvO_RESERVED_9_0_RMAX                 ( 0U )
#define C_EYEQMSG_COREOBJvO_RESERVED_9_0_NUMR                 ( 1U )
#define C_EYEQMSG_COREOBJvO_RESERVED_9_0_DEMNR                ( 1U )
#define C_EYEQMSG_COREOBJvO_RESERVED_9_0_OFFSET               ( 0U )

/* OBJ_Relative_Long_Acc_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJRelativeLongAccV0;
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LONG_ACC_V_0_INVALID ( COREOBJvOOBJRelativeLongAccV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LONG_ACC_V_0_VALID   ( COREOBJvOOBJRelativeLongAccV0 ) ( 1U )

/* OBJ_Relative_Long_Acc_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LONG_ACC_V_0_RMIN    ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LONG_ACC_V_0_RMAX    ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LONG_ACC_V_0_NUMR    ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LONG_ACC_V_0_DEMNR   ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LONG_ACC_V_0_OFFSET  ( 0U )

/* OBJ_Relative_Long_Acc_0_b10 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LONG_ACC_0_RMIN      ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LONG_ACC_0_RMAX      ( 800U )
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LONG_ACC_0_NUMR      ( 1 )
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LONG_ACC_0_DEMNR     ( 20 )
#define C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LONG_ACC_0_OFFSET    ( -20 )

/* OBJ_Inv_TTC_STD_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJInvTTCSTDV0;
#define C_EYEQMSG_COREOBJvO_OBJ_INV_TTC_STD_V_0_INVALID       ( COREOBJvOOBJInvTTCSTDV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_INV_TTC_STD_V_0_VALID         ( COREOBJvOOBJInvTTCSTDV0 ) ( 1U )

/* OBJ_Inv_TTC_STD_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_INV_TTC_STD_V_0_RMIN          ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_INV_TTC_STD_V_0_RMAX          ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_INV_TTC_STD_V_0_NUMR          ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_INV_TTC_STD_V_0_DEMNR         ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_INV_TTC_STD_V_0_OFFSET        ( 0U )

/* OBJ_Inv_TTC_STD_0_b12 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_INV_TTC_STD_0_RMIN            ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_INV_TTC_STD_0_RMAX            ( 4000U )
#define C_EYEQMSG_COREOBJvO_OBJ_INV_TTC_STD_0_NUMR            ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_INV_TTC_STD_0_DEMNR           ( 1000U )
#define C_EYEQMSG_COREOBJvO_OBJ_INV_TTC_STD_0_OFFSET          ( 0U )

/* OBJ_Inv_TTC_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJInvTTCV0;
#define C_EYEQMSG_COREOBJvO_OBJ_INV_TTC_V_0_INVALID           ( COREOBJvOOBJInvTTCV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_INV_TTC_V_0_VALID             ( COREOBJvOOBJInvTTCV0 ) ( 1U )

/* OBJ_Inv_TTC_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_INV_TTC_V_0_RMIN              ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_INV_TTC_V_0_RMAX              ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_INV_TTC_V_0_NUMR              ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_INV_TTC_V_0_DEMNR             ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_INV_TTC_V_0_OFFSET            ( 0U )

/* OBJ_Inv_TTC_0_b11 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_INV_TTC_0_RMIN                ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_INV_TTC_0_RMAX                ( 1600U )
#define C_EYEQMSG_COREOBJvO_OBJ_INV_TTC_0_NUMR                ( 1 )
#define C_EYEQMSG_COREOBJvO_OBJ_INV_TTC_0_DEMNR               ( 100 )
#define C_EYEQMSG_COREOBJvO_OBJ_INV_TTC_0_OFFSET              ( -8 )

/* OBJ_Abs_Acc_STD_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJAbsAccSTDV0;
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_ACC_STD_V_0_INVALID       ( COREOBJvOOBJAbsAccSTDV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_ACC_STD_V_0_VALID         ( COREOBJvOOBJAbsAccSTDV0 ) ( 1U )

/* OBJ_Abs_Acc_STD_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_ACC_STD_V_0_RMIN          ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_ACC_STD_V_0_RMAX          ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_ACC_STD_V_0_NUMR          ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_ACC_STD_V_0_DEMNR         ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_ACC_STD_V_0_OFFSET        ( 0U )

/* OBJ_Abs_Acc_STD_0_b10 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_ACC_STD_0_RMIN            ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_ACC_STD_0_RMAX            ( 730U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_ACC_STD_0_NUMR            ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_ACC_STD_0_DEMNR           ( 100U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_ACC_STD_0_OFFSET          ( 0U )

/* OBJ_Abs_Acceleration_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJAbsAccelerationV0;
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_ACCELERATION_V_0_INVALID  ( COREOBJvOOBJAbsAccelerationV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_ACCELERATION_V_0_VALID    ( COREOBJvOOBJAbsAccelerationV0 ) ( 1U )

/* OBJ_Abs_Acceleration_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_ACCELERATION_V_0_RMIN     ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_ACCELERATION_V_0_RMAX     ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_ACCELERATION_V_0_NUMR     ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_ACCELERATION_V_0_DEMNR    ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_ACCELERATION_V_0_OFFSET   ( 0U )

/* OBJ_Abs_Acceleration_0_b9 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_ACCELERATION_0_RMIN       ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_ACCELERATION_0_RMAX       ( 352U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_ACCELERATION_0_NUMR       ( 1 )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_ACCELERATION_0_DEMNR      ( 20 )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_ACCELERATION_0_OFFSET     ( -10.3f )

/* OBJ_Abs_Lat_Acc_STD_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJAbsLatAccSTDV0;
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_ACC_STD_V_0_INVALID   ( COREOBJvOOBJAbsLatAccSTDV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_ACC_STD_V_0_VALID     ( COREOBJvOOBJAbsLatAccSTDV0 ) ( 1U )

/* OBJ_Abs_Lat_Acc_STD_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_ACC_STD_V_0_RMIN      ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_ACC_STD_V_0_RMAX      ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_ACC_STD_V_0_NUMR      ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_ACC_STD_V_0_DEMNR     ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_ACC_STD_V_0_OFFSET    ( 0U )

/* OBJ_Abs_Lat_Acc_STD_0_b10 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_ACC_STD_0_RMIN        ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_ACC_STD_0_RMAX        ( 730U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_ACC_STD_0_NUMR        ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_ACC_STD_0_DEMNR       ( 100U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_ACC_STD_0_OFFSET      ( 0U )

/* OBJ_Abs_Lat_Acc_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJAbsLatAccV0;
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_ACC_V_0_INVALID       ( COREOBJvOOBJAbsLatAccV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_ACC_V_0_VALID         ( COREOBJvOOBJAbsLatAccV0 ) ( 1U )

/* OBJ_Abs_Lat_Acc_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_ACC_V_0_RMIN          ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_ACC_V_0_RMAX          ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_ACC_V_0_NUMR          ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_ACC_V_0_DEMNR         ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_ACC_V_0_OFFSET        ( 0U )

/* OBJ_Abs_Lat_Acc_0_b9 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_ACC_0_RMIN            ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_ACC_0_RMAX            ( 352U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_ACC_0_NUMR            ( 1 )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_ACC_0_DEMNR           ( 20 )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_ACC_0_OFFSET          ( -10.3f )

/* OBJ_Abs_Long_Acc_STD_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJAbsLongAccSTDV0;
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_ACC_STD_V_0_INVALID  ( COREOBJvOOBJAbsLongAccSTDV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_ACC_STD_V_0_VALID    ( COREOBJvOOBJAbsLongAccSTDV0 ) ( 1U )

/* OBJ_Abs_Long_Acc_STD_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_ACC_STD_V_0_RMIN     ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_ACC_STD_V_0_RMAX     ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_ACC_STD_V_0_NUMR     ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_ACC_STD_V_0_DEMNR    ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_ACC_STD_V_0_OFFSET   ( 0U )

/* OBJ_Abs_Long_Acc_STD_0_b10 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_ACC_STD_0_RMIN       ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_ACC_STD_0_RMAX       ( 730U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_ACC_STD_0_NUMR       ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_ACC_STD_0_DEMNR      ( 100U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_ACC_STD_0_OFFSET     ( 0U )

/* Reserved_8_0_b8 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_RESERVED_8_0_RMIN                 ( 0U )
#define C_EYEQMSG_COREOBJvO_RESERVED_8_0_RMAX                 ( 0U )
#define C_EYEQMSG_COREOBJvO_RESERVED_8_0_NUMR                 ( 1U )
#define C_EYEQMSG_COREOBJvO_RESERVED_8_0_DEMNR                ( 1U )
#define C_EYEQMSG_COREOBJvO_RESERVED_8_0_OFFSET               ( 0U )

/* OBJ_Abs_Long_Acc_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJAbsLongAccV0;
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_ACC_V_0_INVALID      ( COREOBJvOOBJAbsLongAccV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_ACC_V_0_VALID        ( COREOBJvOOBJAbsLongAccV0 ) ( 1U )

/* OBJ_Abs_Long_Acc_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_ACC_V_0_RMIN         ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_ACC_V_0_RMAX         ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_ACC_V_0_NUMR         ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_ACC_V_0_DEMNR        ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_ACC_V_0_OFFSET       ( 0U )

/* OBJ_Abs_Long_Acc_0_b9 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_ACC_0_RMIN           ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_ACC_0_RMAX           ( 400U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_ACC_0_NUMR           ( 1 )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_ACC_0_DEMNR          ( 20 )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_ACC_0_OFFSET         ( -10 )

/* OBJ_Abs_Lat_Vel_STD_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJAbsLatVelSTDV0;
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_VEL_STD_V_0_INVALID   ( COREOBJvOOBJAbsLatVelSTDV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_VEL_STD_V_0_VALID     ( COREOBJvOOBJAbsLatVelSTDV0 ) ( 1U )

/* OBJ_Abs_Lat_Vel_STD_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_VEL_STD_V_0_RMIN      ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_VEL_STD_V_0_RMAX      ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_VEL_STD_V_0_NUMR      ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_VEL_STD_V_0_DEMNR     ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_VEL_STD_V_0_OFFSET    ( 0U )

/* OBJ_Abs_Lat_Velocity_STD_0_b13 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_VELOCITY_STD_0_RMIN   ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_VELOCITY_STD_0_RMAX   ( 5000U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_VELOCITY_STD_0_NUMR   ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_VELOCITY_STD_0_DEMNR  ( 100U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_VELOCITY_STD_0_OFFSET ( 0U )

/* Reserved_7_0_b6 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_RESERVED_7_0_RMIN                 ( 0U )
#define C_EYEQMSG_COREOBJvO_RESERVED_7_0_RMAX                 ( 0U )
#define C_EYEQMSG_COREOBJvO_RESERVED_7_0_NUMR                 ( 1U )
#define C_EYEQMSG_COREOBJvO_RESERVED_7_0_DEMNR                ( 1U )
#define C_EYEQMSG_COREOBJvO_RESERVED_7_0_OFFSET               ( 0U )

/* OBJ_Abs_Lat_Velocity_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJAbsLatVelocityV0;
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_VELOCITY_V_0_INVALID  ( COREOBJvOOBJAbsLatVelocityV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_VELOCITY_V_0_VALID    ( COREOBJvOOBJAbsLatVelocityV0 ) ( 1U )

/* OBJ_Abs_Lat_Velocity_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_VELOCITY_V_0_RMIN     ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_VELOCITY_V_0_RMAX     ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_VELOCITY_V_0_NUMR     ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_VELOCITY_V_0_DEMNR    ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_VELOCITY_V_0_OFFSET   ( 0U )

/* OBJ_Abs_Lat_Velocity_0_b11 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_VELOCITY_0_RMIN       ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_VELOCITY_0_RMAX       ( 2000U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_VELOCITY_0_NUMR       ( 1 )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_VELOCITY_0_DEMNR      ( 20 )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_VELOCITY_0_OFFSET     ( -50 )

/* OBJ_Abs_Long_Vel_STD_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJAbsLongVelSTDV0;
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_VEL_STD_V_0_INVALID  ( COREOBJvOOBJAbsLongVelSTDV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_VEL_STD_V_0_VALID    ( COREOBJvOOBJAbsLongVelSTDV0 ) ( 1U )

/* OBJ_Abs_Long_Vel_STD_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_VEL_STD_V_0_RMIN     ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_VEL_STD_V_0_RMAX     ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_VEL_STD_V_0_NUMR     ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_VEL_STD_V_0_DEMNR    ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_VEL_STD_V_0_OFFSET   ( 0U )

/* OBJ_Abs_Long_Velocity_STD_0_b13 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_VELOCITY_STD_0_RMIN  ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_VELOCITY_STD_0_RMAX  ( 6500U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_VELOCITY_STD_0_NUMR  ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_VELOCITY_STD_0_DEMNR ( 100U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_VELOCITY_STD_0_OFFSET ( 0U )

/* Reserved_6_0_b7 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_RESERVED_6_0_RMIN                 ( 0U )
#define C_EYEQMSG_COREOBJvO_RESERVED_6_0_RMAX                 ( 0U )
#define C_EYEQMSG_COREOBJvO_RESERVED_6_0_NUMR                 ( 1U )
#define C_EYEQMSG_COREOBJvO_RESERVED_6_0_DEMNR                ( 1U )
#define C_EYEQMSG_COREOBJvO_RESERVED_6_0_OFFSET               ( 0U )

/* OBJ_Abs_Long_Velocity_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJAbsLongVelocityV0;
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_VELOCITY_V_0_INVALID ( COREOBJvOOBJAbsLongVelocityV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_VELOCITY_V_0_VALID   ( COREOBJvOOBJAbsLongVelocityV0 ) ( 1U )

/* OBJ_Abs_Long_Velocity_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_VELOCITY_V_0_RMIN    ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_VELOCITY_V_0_RMAX    ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_VELOCITY_V_0_NUMR    ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_VELOCITY_V_0_DEMNR   ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_VELOCITY_V_0_OFFSET  ( 0U )

/* OBJ_Abs_Long_Velocity_0_b12 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_VELOCITY_0_RMIN      ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_VELOCITY_0_RMAX      ( 4000U )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_VELOCITY_0_NUMR      ( 1 )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_VELOCITY_0_DEMNR     ( 20 )
#define C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_VELOCITY_0_OFFSET    ( -100 )

/* OBJ_Height_STD_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJHeightSTDV0;
#define C_EYEQMSG_COREOBJvO_OBJ_HEIGHT_STD_V_0_INVALID        ( COREOBJvOOBJHeightSTDV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_HEIGHT_STD_V_0_VALID          ( COREOBJvOOBJHeightSTDV0 ) ( 1U )

/* OBJ_Height_STD_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_HEIGHT_STD_V_0_RMIN           ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_HEIGHT_STD_V_0_RMAX           ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_HEIGHT_STD_V_0_NUMR           ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_HEIGHT_STD_V_0_DEMNR          ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_HEIGHT_STD_V_0_OFFSET         ( 0U )

/* OBJ_Height_STD_0_b11 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_HEIGHT_STD_0_RMIN             ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_HEIGHT_STD_0_RMAX             ( 2000U )
#define C_EYEQMSG_COREOBJvO_OBJ_HEIGHT_STD_0_NUMR             ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_HEIGHT_STD_0_DEMNR            ( 1000U )
#define C_EYEQMSG_COREOBJvO_OBJ_HEIGHT_STD_0_OFFSET           ( 0U )

/* Reserved_5_0_b2 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_RESERVED_5_0_RMIN                 ( 0U )
#define C_EYEQMSG_COREOBJvO_RESERVED_5_0_RMAX                 ( 0U )
#define C_EYEQMSG_COREOBJvO_RESERVED_5_0_NUMR                 ( 1U )
#define C_EYEQMSG_COREOBJvO_RESERVED_5_0_DEMNR                ( 1U )
#define C_EYEQMSG_COREOBJvO_RESERVED_5_0_OFFSET               ( 0U )

/* OBJ_Height_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJHeightV0;
#define C_EYEQMSG_COREOBJvO_OBJ_HEIGHT_V_0_INVALID            ( COREOBJvOOBJHeightV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_HEIGHT_V_0_VALID              ( COREOBJvOOBJHeightV0 ) ( 1U )

/* OBJ_Height_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_HEIGHT_V_0_RMIN               ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_HEIGHT_V_0_RMAX               ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_HEIGHT_V_0_NUMR               ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_HEIGHT_V_0_DEMNR              ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_HEIGHT_V_0_OFFSET             ( 0U )

/* OBJ_Height_0_b9 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_HEIGHT_0_RMIN                 ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_HEIGHT_0_RMAX                 ( 295U )
#define C_EYEQMSG_COREOBJvO_OBJ_HEIGHT_0_NUMR                 ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_HEIGHT_0_DEMNR                ( 100U )
#define C_EYEQMSG_COREOBJvO_OBJ_HEIGHT_0_OFFSET               ( 0U )

/* OBJ_Radar_ID_0_b8 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_RADAR_ID_0_RMIN               ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_RADAR_ID_0_RMAX               ( 255U )
#define C_EYEQMSG_COREOBJvO_OBJ_RADAR_ID_0_NUMR               ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_RADAR_ID_0_DEMNR              ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_RADAR_ID_0_OFFSET             ( 0U )

/* OBJ_Length_STD_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJLengthSTDV0;
#define C_EYEQMSG_COREOBJvO_OBJ_LENGTH_STD_V_0_INVALID        ( COREOBJvOOBJLengthSTDV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_LENGTH_STD_V_0_VALID          ( COREOBJvOOBJLengthSTDV0 ) ( 1U )

/* OBJ_Length_STD_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_LENGTH_STD_V_0_RMIN           ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_LENGTH_STD_V_0_RMAX           ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_LENGTH_STD_V_0_NUMR           ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_LENGTH_STD_V_0_DEMNR          ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_LENGTH_STD_V_0_OFFSET         ( 0U )

/* OBJ_Length_STD_0_b10 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_LENGTH_STD_0_RMIN             ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_LENGTH_STD_0_RMAX             ( 1000U )
#define C_EYEQMSG_COREOBJvO_OBJ_LENGTH_STD_0_NUMR             ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_LENGTH_STD_0_DEMNR            ( 100U )
#define C_EYEQMSG_COREOBJvO_OBJ_LENGTH_STD_0_OFFSET           ( 0U )

/* OBJ_Length_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJLengthV0;
#define C_EYEQMSG_COREOBJvO_OBJ_LENGTH_V_0_INVALID            ( COREOBJvOOBJLengthV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_LENGTH_V_0_VALID              ( COREOBJvOOBJLengthV0 ) ( 1U )

/* OBJ_Length_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_LENGTH_V_0_RMIN               ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_LENGTH_V_0_RMAX               ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_LENGTH_V_0_NUMR               ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_LENGTH_V_0_DEMNR              ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_LENGTH_V_0_OFFSET             ( 0U )

/* OBJ_Length_0_b9 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_LENGTH_0_RMIN                 ( 24U )
#define C_EYEQMSG_COREOBJvO_OBJ_LENGTH_0_RMAX                 ( 420U )
#define C_EYEQMSG_COREOBJvO_OBJ_LENGTH_0_NUMR                 ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_LENGTH_0_DEMNR                ( 20U )
#define C_EYEQMSG_COREOBJvO_OBJ_LENGTH_0_OFFSET               ( 0U )

/* OBJ_Width_STD_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJWidthSTDV0;
#define C_EYEQMSG_COREOBJvO_OBJ_WIDTH_STD_V_0_INVALID         ( COREOBJvOOBJWidthSTDV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_WIDTH_STD_V_0_VALID           ( COREOBJvOOBJWidthSTDV0 ) ( 1U )

/* OBJ_Width_STD_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_WIDTH_STD_V_0_RMIN            ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_WIDTH_STD_V_0_RMAX            ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_WIDTH_STD_V_0_NUMR            ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_WIDTH_STD_V_0_DEMNR           ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_WIDTH_STD_V_0_OFFSET          ( 0U )

/* OBJ_Width_STD_0_b11 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_WIDTH_STD_0_RMIN              ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_WIDTH_STD_0_RMAX              ( 2000U )
#define C_EYEQMSG_COREOBJvO_OBJ_WIDTH_STD_0_NUMR              ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_WIDTH_STD_0_DEMNR             ( 1000U )
#define C_EYEQMSG_COREOBJvO_OBJ_WIDTH_STD_0_OFFSET            ( 0U )

/* OBJ_Width_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJWidthV0;
#define C_EYEQMSG_COREOBJvO_OBJ_WIDTH_V_0_INVALID             ( COREOBJvOOBJWidthV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_WIDTH_V_0_VALID               ( COREOBJvOOBJWidthV0 ) ( 1U )

/* OBJ_Width_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_WIDTH_V_0_RMIN                ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_WIDTH_V_0_RMAX                ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_WIDTH_V_0_NUMR                ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_WIDTH_V_0_DEMNR               ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_WIDTH_V_0_OFFSET              ( 0U )

/* OBJ_Width_0_b9 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_WIDTH_0_RMIN                  ( 40U )
#define C_EYEQMSG_COREOBJvO_OBJ_WIDTH_0_RMAX                  ( 295U )
#define C_EYEQMSG_COREOBJvO_OBJ_WIDTH_0_NUMR                  ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_WIDTH_0_DEMNR                 ( 100U )
#define C_EYEQMSG_COREOBJvO_OBJ_WIDTH_0_OFFSET                ( 0U )

/* OBJ_Age_Seconds_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJAgeSecondsV0;
#define C_EYEQMSG_COREOBJvO_OBJ_AGE_SECONDS_V_0_INVALID       ( COREOBJvOOBJAgeSecondsV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_AGE_SECONDS_V_0_VALID         ( COREOBJvOOBJAgeSecondsV0 ) ( 1U )

/* OBJ_Age_Seconds_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_AGE_SECONDS_V_0_RMIN          ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_AGE_SECONDS_V_0_RMAX          ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_AGE_SECONDS_V_0_NUMR          ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_AGE_SECONDS_V_0_DEMNR         ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_AGE_SECONDS_V_0_OFFSET        ( 0U )

/* OBJ_Age_Seconds_0_b7 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_AGE_SECONDS_0_RMIN            ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_AGE_SECONDS_0_RMAX            ( 100U )
#define C_EYEQMSG_COREOBJvO_OBJ_AGE_SECONDS_0_NUMR            ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_AGE_SECONDS_0_DEMNR           ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_AGE_SECONDS_0_OFFSET          ( 0U )

/* OBJ_Lane_Assignment_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJLaneAssignmentV0;
#define C_EYEQMSG_COREOBJvO_OBJ_LANE_ASSIGNMENT_V_0_INVALID   ( COREOBJvOOBJLaneAssignmentV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_LANE_ASSIGNMENT_V_0_VALID     ( COREOBJvOOBJLaneAssignmentV0 ) ( 1U )

/* OBJ_Lane_Assignment_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_LANE_ASSIGNMENT_V_0_RMIN      ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_LANE_ASSIGNMENT_V_0_RMAX      ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_LANE_ASSIGNMENT_V_0_NUMR      ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_LANE_ASSIGNMENT_V_0_DEMNR     ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_LANE_ASSIGNMENT_V_0_OFFSET    ( 0U )

/* OBJ_Lane_Assignment_0_b3 signal Enums */
typedef uint8 COREOBJvOOBJLaneAssignment0;
#define C_EYEQMSG_COREOBJvO_OBJ_LANE_ASSIGNMENT_0_UNKNOWN     ( COREOBJvOOBJLaneAssignment0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_LANE_ASSIGNMENT_0_LEFT_LEFT   ( COREOBJvOOBJLaneAssignment0 ) ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_LANE_ASSIGNMENT_0_LEFT        ( COREOBJvOOBJLaneAssignment0 ) ( 2U )
#define C_EYEQMSG_COREOBJvO_OBJ_LANE_ASSIGNMENT_0_HOST        ( COREOBJvOOBJLaneAssignment0 ) ( 3U )
#define C_EYEQMSG_COREOBJvO_OBJ_LANE_ASSIGNMENT_0_RIGHT       ( COREOBJvOOBJLaneAssignment0 ) ( 4U )
#define C_EYEQMSG_COREOBJvO_OBJ_LANE_ASSIGNMENT_0_RIGHT_RIGHT ( COREOBJvOOBJLaneAssignment0 ) ( 5U )

/* OBJ_Lane_Assignment_0_b3 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_LANE_ASSIGNMENT_0_RMIN        ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_LANE_ASSIGNMENT_0_RMAX        ( 5U )
#define C_EYEQMSG_COREOBJvO_OBJ_LANE_ASSIGNMENT_0_NUMR        ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_LANE_ASSIGNMENT_0_DEMNR       ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_LANE_ASSIGNMENT_0_OFFSET      ( 0U )

/* OBJ_Bottom_Out_Of_Image_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJBottomOutOfImageV0;
#define C_EYEQMSG_COREOBJvO_OBJ_BOTTOM_OUT_OF_IMAGE_V_0_INVALID ( COREOBJvOOBJBottomOutOfImageV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_BOTTOM_OUT_OF_IMAGE_V_0_VALID ( COREOBJvOOBJBottomOutOfImageV0 ) ( 1U )

/* OBJ_Bottom_Out_Of_Image_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_BOTTOM_OUT_OF_IMAGE_V_0_RMIN  ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_BOTTOM_OUT_OF_IMAGE_V_0_RMAX  ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_BOTTOM_OUT_OF_IMAGE_V_0_NUMR  ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_BOTTOM_OUT_OF_IMAGE_V_0_DEMNR ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_BOTTOM_OUT_OF_IMAGE_V_0_OFFSET ( 0U )

/* OBJ_Top_Out_Of_Image_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJTopOutOfImageV0;
#define C_EYEQMSG_COREOBJvO_OBJ_TOP_OUT_OF_IMAGE_V_0_INVALID  ( COREOBJvOOBJTopOutOfImageV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_TOP_OUT_OF_IMAGE_V_0_VALID    ( COREOBJvOOBJTopOutOfImageV0 ) ( 1U )

/* OBJ_Top_Out_Of_Image_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_TOP_OUT_OF_IMAGE_V_0_RMIN     ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_TOP_OUT_OF_IMAGE_V_0_RMAX     ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_TOP_OUT_OF_IMAGE_V_0_NUMR     ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_TOP_OUT_OF_IMAGE_V_0_DEMNR    ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_TOP_OUT_OF_IMAGE_V_0_OFFSET   ( 0U )

/* OBJ_Bottom_Out_Of_Image_0_b1 signal Enums */
typedef boolean COREOBJvOOBJBottomOutOfImage0;
#define C_EYEQMSG_COREOBJvO_OBJ_BOTTOM_OUT_OF_IMAGE_0_FALSE   ( COREOBJvOOBJBottomOutOfImage0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_BOTTOM_OUT_OF_IMAGE_0_TRUE    ( COREOBJvOOBJBottomOutOfImage0 ) ( 1U )

/* OBJ_Bottom_Out_Of_Image_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_BOTTOM_OUT_OF_IMAGE_0_RMIN    ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_BOTTOM_OUT_OF_IMAGE_0_RMAX    ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_BOTTOM_OUT_OF_IMAGE_0_NUMR    ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_BOTTOM_OUT_OF_IMAGE_0_DEMNR   ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_BOTTOM_OUT_OF_IMAGE_0_OFFSET  ( 0U )

/* OBJ_Top_Out_Of_Image_0_b1 signal Enums */
typedef boolean COREOBJvOOBJTopOutOfImage0;
#define C_EYEQMSG_COREOBJvO_OBJ_TOP_OUT_OF_IMAGE_0_FALSE      ( COREOBJvOOBJTopOutOfImage0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_TOP_OUT_OF_IMAGE_0_TRUE       ( COREOBJvOOBJTopOutOfImage0 ) ( 1U )

/* OBJ_Top_Out_Of_Image_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_TOP_OUT_OF_IMAGE_0_RMIN       ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_TOP_OUT_OF_IMAGE_0_RMAX       ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_TOP_OUT_OF_IMAGE_0_NUMR       ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_TOP_OUT_OF_IMAGE_0_DEMNR      ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_TOP_OUT_OF_IMAGE_0_OFFSET     ( 0U )

/* OBJ_Left_Out_Of_Image_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJLeftOutOfImageV0;
#define C_EYEQMSG_COREOBJvO_OBJ_LEFT_OUT_OF_IMAGE_V_0_FALSE   ( COREOBJvOOBJLeftOutOfImageV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_LEFT_OUT_OF_IMAGE_V_0_TRUE    ( COREOBJvOOBJLeftOutOfImageV0 ) ( 1U )

/* OBJ_Left_Out_Of_Image_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_LEFT_OUT_OF_IMAGE_V_0_RMIN    ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_LEFT_OUT_OF_IMAGE_V_0_RMAX    ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_LEFT_OUT_OF_IMAGE_V_0_NUMR    ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_LEFT_OUT_OF_IMAGE_V_0_DEMNR   ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_LEFT_OUT_OF_IMAGE_V_0_OFFSET  ( 0U )

/* OBJ_Right_Out_Of_Image_V_0_b1 signal Enums */
typedef boolean COREOBJvOOBJRightOutOfImageV0;
#define C_EYEQMSG_COREOBJvO_OBJ_RIGHT_OUT_OF_IMAGE_V_0_FALSE  ( COREOBJvOOBJRightOutOfImageV0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_RIGHT_OUT_OF_IMAGE_V_0_TRUE   ( COREOBJvOOBJRightOutOfImageV0 ) ( 1U )

/* OBJ_Right_Out_Of_Image_V_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_RIGHT_OUT_OF_IMAGE_V_0_RMIN   ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_RIGHT_OUT_OF_IMAGE_V_0_RMAX   ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_RIGHT_OUT_OF_IMAGE_V_0_NUMR   ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_RIGHT_OUT_OF_IMAGE_V_0_DEMNR  ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_RIGHT_OUT_OF_IMAGE_V_0_OFFSET ( 0U )

/* OBJ_Left_Out_Of_Image_0_b1 signal Enums */
typedef boolean COREOBJvOOBJLeftOutOfImage0;
#define C_EYEQMSG_COREOBJvO_OBJ_LEFT_OUT_OF_IMAGE_0_FALSE     ( COREOBJvOOBJLeftOutOfImage0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_LEFT_OUT_OF_IMAGE_0_TRUE      ( COREOBJvOOBJLeftOutOfImage0 ) ( 1U )

/* OBJ_Left_Out_Of_Image_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_LEFT_OUT_OF_IMAGE_0_RMIN      ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_LEFT_OUT_OF_IMAGE_0_RMAX      ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_LEFT_OUT_OF_IMAGE_0_NUMR      ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_LEFT_OUT_OF_IMAGE_0_DEMNR     ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_LEFT_OUT_OF_IMAGE_0_OFFSET    ( 0U )

/* OBJ_Right_Out_Of_Image_0_b1 signal Enums */
typedef boolean COREOBJvOOBJRightOutOfImage0;
#define C_EYEQMSG_COREOBJvO_OBJ_RIGHT_OUT_OF_IMAGE_0_FALSE    ( COREOBJvOOBJRightOutOfImage0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_RIGHT_OUT_OF_IMAGE_0_TRUE     ( COREOBJvOOBJRightOutOfImage0 ) ( 1U )

/* OBJ_Right_Out_Of_Image_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_RIGHT_OUT_OF_IMAGE_0_RMIN     ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_RIGHT_OUT_OF_IMAGE_0_RMAX     ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_RIGHT_OUT_OF_IMAGE_0_NUMR     ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_RIGHT_OUT_OF_IMAGE_0_DEMNR    ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_RIGHT_OUT_OF_IMAGE_0_OFFSET   ( 0U )

/* OBJ_Light_Indicator_Validity_0_b1 signal Enums */
typedef boolean COREOBJvOOBJLightIndicatorValidity0;
#define C_EYEQMSG_COREOBJvO_OBJ_LIGHT_INDICATOR_VALIDITY_0_FALSE ( COREOBJvOOBJLightIndicatorValidity0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_LIGHT_INDICATOR_VALIDITY_0_TRUE ( COREOBJvOOBJLightIndicatorValidity0 ) ( 1U )

/* OBJ_Light_Indicator_Validity_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_LIGHT_INDICATOR_VALIDITY_0_RMIN ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_LIGHT_INDICATOR_VALIDITY_0_RMAX ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_LIGHT_INDICATOR_VALIDITY_0_NUMR ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_LIGHT_INDICATOR_VALIDITY_0_DEMNR ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_LIGHT_INDICATOR_VALIDITY_0_OFFSET ( 0U )

/* OBJ_Turn_Indicator_Left_0_b1 signal Enums */
typedef boolean COREOBJvOOBJTurnIndicatorLeft0;
#define C_EYEQMSG_COREOBJvO_OBJ_TURN_INDICATOR_LEFT_0_FALSE   ( COREOBJvOOBJTurnIndicatorLeft0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_TURN_INDICATOR_LEFT_0_TRUE    ( COREOBJvOOBJTurnIndicatorLeft0 ) ( 1U )

/* OBJ_Turn_Indicator_Left_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_TURN_INDICATOR_LEFT_0_RMIN    ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_TURN_INDICATOR_LEFT_0_RMAX    ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_TURN_INDICATOR_LEFT_0_NUMR    ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_TURN_INDICATOR_LEFT_0_DEMNR   ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_TURN_INDICATOR_LEFT_0_OFFSET  ( 0U )

/* OBJ_Turn_Indicator_Right_0_b1 signal Enums */
typedef boolean COREOBJvOOBJTurnIndicatorRight0;
#define C_EYEQMSG_COREOBJvO_OBJ_TURN_INDICATOR_RIGHT_0_FALSE  ( COREOBJvOOBJTurnIndicatorRight0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_TURN_INDICATOR_RIGHT_0_TRUE   ( COREOBJvOOBJTurnIndicatorRight0 ) ( 1U )

/* OBJ_Turn_Indicator_Right_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_TURN_INDICATOR_RIGHT_0_RMIN   ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_TURN_INDICATOR_RIGHT_0_RMAX   ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_TURN_INDICATOR_RIGHT_0_NUMR   ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_TURN_INDICATOR_RIGHT_0_DEMNR  ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_TURN_INDICATOR_RIGHT_0_OFFSET ( 0U )

/* OBJ_Brake_Light_0_b1 signal Enums */
typedef boolean COREOBJvOOBJBrakeLight0;
#define C_EYEQMSG_COREOBJvO_OBJ_BRAKE_LIGHT_0_FALSE           ( COREOBJvOOBJBrakeLight0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_BRAKE_LIGHT_0_TRUE            ( COREOBJvOOBJBrakeLight0 ) ( 1U )

/* OBJ_Brake_Light_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_BRAKE_LIGHT_0_RMIN            ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_BRAKE_LIGHT_0_RMAX            ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_BRAKE_LIGHT_0_NUMR            ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_BRAKE_LIGHT_0_DEMNR           ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_BRAKE_LIGHT_0_OFFSET          ( 0U )

/* OBJ_Has_Cut_Path_0_b1 signal Enums */
typedef boolean COREOBJvOOBJHasCutPath0;
#define C_EYEQMSG_COREOBJvO_OBJ_HAS_CUT_PATH_0_FALSE          ( COREOBJvOOBJHasCutPath0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_HAS_CUT_PATH_0_TRUE           ( COREOBJvOOBJHasCutPath0 ) ( 1U )

/* OBJ_Has_Cut_Path_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_HAS_CUT_PATH_0_RMIN           ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_HAS_CUT_PATH_0_RMAX           ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_HAS_CUT_PATH_0_NUMR           ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_HAS_CUT_PATH_0_DEMNR          ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_HAS_CUT_PATH_0_OFFSET         ( 0U )

/* OBJ_Has_Cut_Lane_0_b1 signal Enums */
typedef boolean COREOBJvOOBJHasCutLane0;
#define C_EYEQMSG_COREOBJvO_OBJ_HAS_CUT_LANE_0_FALSE          ( COREOBJvOOBJHasCutLane0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_HAS_CUT_LANE_0_TRUE           ( COREOBJvOOBJHasCutLane0 ) ( 1U )

/* OBJ_Has_Cut_Lane_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_HAS_CUT_LANE_0_RMIN           ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_HAS_CUT_LANE_0_RMAX           ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_HAS_CUT_LANE_0_NUMR           ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_HAS_CUT_LANE_0_DEMNR          ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_HAS_CUT_LANE_0_OFFSET         ( 0U )

/* OBJ_Motion_Orientation_0_b4 signal Enums */
typedef uint8 COREOBJvOOBJMotionOrientation0;
#define C_EYEQMSG_COREOBJvO_OBJ_MOTION_ORIENTATION_0_UNKNOWN  ( COREOBJvOOBJMotionOrientation0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_MOTION_ORIENTATION_0_NORTH_EAST ( COREOBJvOOBJMotionOrientation0 ) ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_MOTION_ORIENTATION_0_EAST     ( COREOBJvOOBJMotionOrientation0 ) ( 3U )
#define C_EYEQMSG_COREOBJvO_OBJ_MOTION_ORIENTATION_0_SOUTH_EAST ( COREOBJvOOBJMotionOrientation0 ) ( 5U )
#define C_EYEQMSG_COREOBJvO_OBJ_MOTION_ORIENTATION_0_SOUTH    ( COREOBJvOOBJMotionOrientation0 ) ( 6U )
#define C_EYEQMSG_COREOBJvO_OBJ_MOTION_ORIENTATION_0_SOUTH_WEST ( COREOBJvOOBJMotionOrientation0 ) ( 7U )
#define C_EYEQMSG_COREOBJvO_OBJ_MOTION_ORIENTATION_0_WEST     ( COREOBJvOOBJMotionOrientation0 ) ( 9U )
#define C_EYEQMSG_COREOBJvO_OBJ_MOTION_ORIENTATION_0_NORTH_WEST ( COREOBJvOOBJMotionOrientation0 ) ( 11U )
#define C_EYEQMSG_COREOBJvO_OBJ_MOTION_ORIENTATION_0_NORTH    ( COREOBJvOOBJMotionOrientation0 ) ( 12U )
#define C_EYEQMSG_COREOBJvO_OBJ_MOTION_ORIENTATION_0_INVALID  ( COREOBJvOOBJMotionOrientation0 ) ( 13U )

/* OBJ_Motion_Orientation_0_b4 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_MOTION_ORIENTATION_0_RMIN     ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_MOTION_ORIENTATION_0_RMAX     ( 13U )
#define C_EYEQMSG_COREOBJvO_OBJ_MOTION_ORIENTATION_0_NUMR     ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_MOTION_ORIENTATION_0_DEMNR    ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_MOTION_ORIENTATION_0_OFFSET   ( 0U )

/* OBJ_Motion_Status_0_b3 signal Enums */
typedef uint8 COREOBJvOOBJMotionStatus0;
#define C_EYEQMSG_COREOBJvO_OBJ_MOTION_STATUS_0_INVALID       ( COREOBJvOOBJMotionStatus0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_MOTION_STATUS_0_UNKNOWN       ( COREOBJvOOBJMotionStatus0 ) ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_MOTION_STATUS_0_MOVING        ( COREOBJvOOBJMotionStatus0 ) ( 2U )
#define C_EYEQMSG_COREOBJvO_OBJ_MOTION_STATUS_0_STATIONARY    ( COREOBJvOOBJMotionStatus0 ) ( 3U )
#define C_EYEQMSG_COREOBJvO_OBJ_MOTION_STATUS_0_STOPPED       ( COREOBJvOOBJMotionStatus0 ) ( 4U )
#define C_EYEQMSG_COREOBJvO_OBJ_MOTION_STATUS_0_MOVING_SLOWLY ( COREOBJvOOBJMotionStatus0 ) ( 5U )

/* OBJ_Motion_Status_0_b3 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_MOTION_STATUS_0_RMIN          ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_MOTION_STATUS_0_RMAX          ( 5U )
#define C_EYEQMSG_COREOBJvO_OBJ_MOTION_STATUS_0_NUMR          ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_MOTION_STATUS_0_DEMNR         ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_MOTION_STATUS_0_OFFSET        ( 0U )

/* OBJ_Camera_Source_0_b4 signal Enums */
typedef uint8 COREOBJvOOBJCameraSource0;
#define C_EYEQMSG_COREOBJvO_OBJ_CAMERA_SOURCE_0_FRONT_MAIN    ( COREOBJvOOBJCameraSource0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_CAMERA_SOURCE_0_FRONT_NARROW  ( COREOBJvOOBJCameraSource0 ) ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_CAMERA_SOURCE_0_FRONT_FISHEYE ( COREOBJvOOBJCameraSource0 ) ( 2U )
#define C_EYEQMSG_COREOBJvO_OBJ_CAMERA_SOURCE_0_REAR          ( COREOBJvOOBJCameraSource0 ) ( 3U )
#define C_EYEQMSG_COREOBJvO_OBJ_CAMERA_SOURCE_0_REAR_CORNER_LEFT ( COREOBJvOOBJCameraSource0 ) ( 4U )
#define C_EYEQMSG_COREOBJvO_OBJ_CAMERA_SOURCE_0_REAR_CORNER_RIGHT ( COREOBJvOOBJCameraSource0 ) ( 5U )
#define C_EYEQMSG_COREOBJvO_OBJ_CAMERA_SOURCE_0_FRONT_CORNER_LEFT ( COREOBJvOOBJCameraSource0 ) ( 6U )
#define C_EYEQMSG_COREOBJvO_OBJ_CAMERA_SOURCE_0_FRONT_CORNER_RIGHT ( COREOBJvOOBJCameraSource0 ) ( 7U )
#define C_EYEQMSG_COREOBJvO_OBJ_CAMERA_SOURCE_0_PARKING_FRONT ( COREOBJvOOBJCameraSource0 ) ( 8U )
#define C_EYEQMSG_COREOBJvO_OBJ_CAMERA_SOURCE_0_PARKING_REAR  ( COREOBJvOOBJCameraSource0 ) ( 9U )
#define C_EYEQMSG_COREOBJvO_OBJ_CAMERA_SOURCE_0_PARKING_LEFT  ( COREOBJvOOBJCameraSource0 ) ( 10U )
#define C_EYEQMSG_COREOBJvO_OBJ_CAMERA_SOURCE_0_PARKING_RIGHT ( COREOBJvOOBJCameraSource0 ) ( 11U )

/* OBJ_Camera_Source_0_b4 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_CAMERA_SOURCE_0_RMIN          ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_CAMERA_SOURCE_0_RMAX          ( 15U )
#define C_EYEQMSG_COREOBJvO_OBJ_CAMERA_SOURCE_0_NUMR          ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_CAMERA_SOURCE_0_DEMNR         ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_CAMERA_SOURCE_0_OFFSET        ( 0U )

/* OBJ_Bike_Probability_0_b7 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_BIKE_PROBABILITY_0_RMIN       ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_BIKE_PROBABILITY_0_RMAX       ( 100U )
#define C_EYEQMSG_COREOBJvO_OBJ_BIKE_PROBABILITY_0_NUMR       ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_BIKE_PROBABILITY_0_DEMNR      ( 100U )
#define C_EYEQMSG_COREOBJvO_OBJ_BIKE_PROBABILITY_0_OFFSET     ( 0U )

/* OBJ_Truck_Probability_0_b7 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_TRUCK_PROBABILITY_0_RMIN      ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_TRUCK_PROBABILITY_0_RMAX      ( 100U )
#define C_EYEQMSG_COREOBJvO_OBJ_TRUCK_PROBABILITY_0_NUMR      ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_TRUCK_PROBABILITY_0_DEMNR     ( 100U )
#define C_EYEQMSG_COREOBJvO_OBJ_TRUCK_PROBABILITY_0_OFFSET    ( 0U )

/* OBJ_Car_Probability_0_b7 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_CAR_PROBABILITY_0_RMIN        ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_CAR_PROBABILITY_0_RMAX        ( 100U )
#define C_EYEQMSG_COREOBJvO_OBJ_CAR_PROBABILITY_0_NUMR        ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_CAR_PROBABILITY_0_DEMNR       ( 100U )
#define C_EYEQMSG_COREOBJvO_OBJ_CAR_PROBABILITY_0_OFFSET      ( 0U )

/* OBJ_Class_Probability_0_b7 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_CLASS_PROBABILITY_0_RMIN      ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_CLASS_PROBABILITY_0_RMAX      ( 100U )
#define C_EYEQMSG_COREOBJvO_OBJ_CLASS_PROBABILITY_0_NUMR      ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_CLASS_PROBABILITY_0_DEMNR     ( 100U )
#define C_EYEQMSG_COREOBJvO_OBJ_CLASS_PROBABILITY_0_OFFSET    ( 0U )

/* Reserved_4_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_RESERVED_4_0_RMIN                 ( 0U )
#define C_EYEQMSG_COREOBJvO_RESERVED_4_0_RMAX                 ( 0U )
#define C_EYEQMSG_COREOBJvO_RESERVED_4_0_NUMR                 ( 1U )
#define C_EYEQMSG_COREOBJvO_RESERVED_4_0_DEMNR                ( 1U )
#define C_EYEQMSG_COREOBJvO_RESERVED_4_0_OFFSET               ( 0U )

/* OBJ_Object_Class_0_b4 signal Enums */
typedef uint8 COREOBJvOOBJObjectClass0;
#define C_EYEQMSG_COREOBJvO_OBJ_OBJECT_CLASS_0_UNFILLED       ( COREOBJvOOBJObjectClass0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_OBJECT_CLASS_0_CAR            ( COREOBJvOOBJObjectClass0 ) ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_OBJECT_CLASS_0_TRUCK          ( COREOBJvOOBJObjectClass0 ) ( 2U )
#define C_EYEQMSG_COREOBJvO_OBJ_OBJECT_CLASS_0_MOTORBIKE      ( COREOBJvOOBJObjectClass0 ) ( 3U )
#define C_EYEQMSG_COREOBJvO_OBJ_OBJECT_CLASS_0_BICYCLE        ( COREOBJvOOBJObjectClass0 ) ( 4U )
#define C_EYEQMSG_COREOBJvO_OBJ_OBJECT_CLASS_0_PEDESTRIAN     ( COREOBJvOOBJObjectClass0 ) ( 5U )
#define C_EYEQMSG_COREOBJvO_OBJ_OBJECT_CLASS_0_GENERAL_OBJECT ( COREOBJvOOBJObjectClass0 ) ( 6U )
#define C_EYEQMSG_COREOBJvO_OBJ_OBJECT_CLASS_0_ANIMAL         ( COREOBJvOOBJObjectClass0 ) ( 7U )
#define C_EYEQMSG_COREOBJvO_OBJ_OBJECT_CLASS_0_UNCERTAIN_VCL  ( COREOBJvOOBJObjectClass0 ) ( 8U )

/* OBJ_Object_Class_0_b4 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_OBJECT_CLASS_0_RMIN           ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_OBJECT_CLASS_0_RMAX           ( 8U )
#define C_EYEQMSG_COREOBJvO_OBJ_OBJECT_CLASS_0_NUMR           ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_OBJECT_CLASS_0_DEMNR          ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_OBJECT_CLASS_0_OFFSET         ( 0U )

/* OBJ_Measuring_Status_0_b3 signal Enums */
typedef uint8 COREOBJvOOBJMeasuringStatus0;
#define C_EYEQMSG_COREOBJvO_OBJ_MEASURING_STATUS_0__BIT_0_OLD_OR_NEW ( COREOBJvOOBJMeasuringStatus0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_MEASURING_STATUS_0__BIT_1_PREDICTED_OR_MEASURED ( COREOBJvOOBJMeasuringStatus0 ) ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_MEASURING_STATUS_0__BIT_2_NOT_VALID_OR_VALID ( COREOBJvOOBJMeasuringStatus0 ) ( 2U )

/* OBJ_Measuring_Status_0_b3 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_MEASURING_STATUS_0_RMIN       ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_MEASURING_STATUS_0_RMAX       ( 7U )
#define C_EYEQMSG_COREOBJvO_OBJ_MEASURING_STATUS_0_NUMR       ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_MEASURING_STATUS_0_DEMNR      ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_MEASURING_STATUS_0_OFFSET     ( 0U )

/* OBJ_Object_Age_0_b11 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_OBJECT_AGE_0_RMIN             ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_OBJECT_AGE_0_RMAX             ( 2047U )
#define C_EYEQMSG_COREOBJvO_OBJ_OBJECT_AGE_0_NUMR             ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_OBJECT_AGE_0_DEMNR            ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_OBJECT_AGE_0_OFFSET           ( 0U )

/* OBJ_Moving_IN_Probability_0_b7 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_MOVING_IN_PROBABILITY_0_RMIN  ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_MOVING_IN_PROBABILITY_0_RMAX  ( 100U )
#define C_EYEQMSG_COREOBJvO_OBJ_MOVING_IN_PROBABILITY_0_NUMR  ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_MOVING_IN_PROBABILITY_0_DEMNR ( 100U )
#define C_EYEQMSG_COREOBJvO_OBJ_MOVING_IN_PROBABILITY_0_OFFSET ( 0U )

/* OBJ_Motion_Category_0_b4 signal Enums */
typedef uint8 COREOBJvOOBJMotionCategory0;
#define C_EYEQMSG_COREOBJvO_OBJ_MOTION_CATEGORY_0_UNFILLED    ( COREOBJvOOBJMotionCategory0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_MOTION_CATEGORY_0_UNDEFINED   ( COREOBJvOOBJMotionCategory0 ) ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_MOTION_CATEGORY_0_PASSING     ( COREOBJvOOBJMotionCategory0 ) ( 2U )
#define C_EYEQMSG_COREOBJvO_OBJ_MOTION_CATEGORY_0_PASSING_IN  ( COREOBJvOOBJMotionCategory0 ) ( 3U )
#define C_EYEQMSG_COREOBJvO_OBJ_MOTION_CATEGORY_0_PASSING_OUT ( COREOBJvOOBJMotionCategory0 ) ( 4U )
#define C_EYEQMSG_COREOBJvO_OBJ_MOTION_CATEGORY_0_CLOSE_CUT_IN ( COREOBJvOOBJMotionCategory0 ) ( 5U )
#define C_EYEQMSG_COREOBJvO_OBJ_MOTION_CATEGORY_0_MOVING_IN   ( COREOBJvOOBJMotionCategory0 ) ( 6U )
#define C_EYEQMSG_COREOBJvO_OBJ_MOTION_CATEGORY_0_MOVING_OUT  ( COREOBJvOOBJMotionCategory0 ) ( 7U )
#define C_EYEQMSG_COREOBJvO_OBJ_MOTION_CATEGORY_0_CROSSING    ( COREOBJvOOBJMotionCategory0 ) ( 8U )
#define C_EYEQMSG_COREOBJvO_OBJ_MOTION_CATEGORY_0_LTAP        ( COREOBJvOOBJMotionCategory0 ) ( 9U )
#define C_EYEQMSG_COREOBJvO_OBJ_MOTION_CATEGORY_0_RTAP        ( COREOBJvOOBJMotionCategory0 ) ( 10U )
#define C_EYEQMSG_COREOBJvO_OBJ_MOTION_CATEGORY_0_MOVING      ( COREOBJvOOBJMotionCategory0 ) ( 11U )
#define C_EYEQMSG_COREOBJvO_OBJ_MOTION_CATEGORY_0_PRECEEDING  ( COREOBJvOOBJMotionCategory0 ) ( 12U )
#define C_EYEQMSG_COREOBJvO_OBJ_MOTION_CATEGORY_0_ONCOMING    ( COREOBJvOOBJMotionCategory0 ) ( 13U )

/* OBJ_Motion_Category_0_b4 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_MOTION_CATEGORY_0_RMIN        ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_MOTION_CATEGORY_0_RMAX        ( 13U )
#define C_EYEQMSG_COREOBJvO_OBJ_MOTION_CATEGORY_0_NUMR        ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_MOTION_CATEGORY_0_DEMNR       ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_MOTION_CATEGORY_0_OFFSET      ( 0U )

/* OBJ_Triggered_SDM_0_b2 signal Enums */
typedef uint8 COREOBJvOOBJTriggeredSDM0;
#define C_EYEQMSG_COREOBJvO_OBJ_TRIGGERED_SDM_0_NOT_AVAILABLE ( COREOBJvOOBJTriggeredSDM0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_TRIGGERED_SDM_0_TRIGGERED     ( COREOBJvOOBJTriggeredSDM0 ) ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_TRIGGERED_SDM_0_NOT_TRIGGERED ( COREOBJvOOBJTriggeredSDM0 ) ( 2U )

/* OBJ_Triggered_SDM_0_b2 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_TRIGGERED_SDM_0_RMIN          ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_TRIGGERED_SDM_0_RMAX          ( 2U )
#define C_EYEQMSG_COREOBJvO_OBJ_TRIGGERED_SDM_0_NUMR          ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_TRIGGERED_SDM_0_DEMNR         ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_TRIGGERED_SDM_0_OFFSET        ( 0U )

/* OBJ_Fusion_Source_0_b16 signal Enums */
typedef uint16 COREOBJvOOBJFusionSource0;
#define C_EYEQMSG_COREOBJvO_OBJ_FUSION_SOURCE_0__BIT_0_CAMERA ( COREOBJvOOBJFusionSource0 ) ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_FUSION_SOURCE_0__BIT_1_RADAR1 ( COREOBJvOOBJFusionSource0 ) ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_FUSION_SOURCE_0__BIT_2_RADAR2 ( COREOBJvOOBJFusionSource0 ) ( 2U )

/* OBJ_Fusion_Source_0_b16 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_FUSION_SOURCE_0_RMIN          ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_FUSION_SOURCE_0_RMAX          ( 65535U )
#define C_EYEQMSG_COREOBJvO_OBJ_FUSION_SOURCE_0_NUMR          ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_FUSION_SOURCE_0_DEMNR         ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_FUSION_SOURCE_0_OFFSET        ( 0U )

/* OBJ_Existence_Probability_0_b8 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_EXISTENCE_PROBABILITY_0_RMIN  ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_EXISTENCE_PROBABILITY_0_RMAX  ( 100U )
#define C_EYEQMSG_COREOBJvO_OBJ_EXISTENCE_PROBABILITY_0_NUMR  ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_EXISTENCE_PROBABILITY_0_DEMNR ( 100U )
#define C_EYEQMSG_COREOBJvO_OBJ_EXISTENCE_PROBABILITY_0_OFFSET ( 0U )

/* OBJ_ID_0_b8 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_ID_0_RMIN                     ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_ID_0_RMAX                     ( 255U )
#define C_EYEQMSG_COREOBJvO_OBJ_ID_0_NUMR                     ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ID_0_DEMNR                    ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_ID_0_OFFSET                   ( 0U )

/* OBJ_CRC_0_b32 signal Min & Max range limits */
#define C_EYEQMSG_COREOBJvO_OBJ_CRC_0_RMIN                    ( 0U )
#define C_EYEQMSG_COREOBJvO_OBJ_CRC_0_RMAX                    ( 4294967295U )
#define C_EYEQMSG_COREOBJvO_OBJ_CRC_0_NUMR                    ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_CRC_0_DEMNR                   ( 1U )
#define C_EYEQMSG_COREOBJvO_OBJ_CRC_0_OFFSET                  ( 0U )


/*****************************************************************************
                  Exported function-like macros
*****************************************************************************/
/*****************************************************************************
                  Exported defined macros
*****************************************************************************/
/*****************************************************************************
                  Exported types, enums definitions
*****************************************************************************/
typedef struct
{
   #if ENABLE_BIG_ENDIAN_FORMAT
      uint32        OBJ_Zero_byte_b8                             : 8U;
      
      uint32        Reserved_1_1_b8                              : 8U;
      
      uint32        Reserved_1_2_b8                              : 8U;
      
      uint32        Reserved_1_3_b8                              : 8U;
      
      uint32        OBJ_Header_CRC_1_b8                          : 8U;
      
      uint32        OBJ_Header_CRC_2_b8                          : 8U;
      
      uint32        OBJ_Header_CRC_3_b8                          : 8U;
      
      uint32        OBJ_Header_CRC_4_b8                          : 8U;
      
      uint32        OBJ_Protocol_Version_b8                      : 8U;
      
      uint32        OBJ_Sync_ID_b8                               : 8U;
      
      uint32        unused1_b3                                   : 3;
      uint32        OBJ_VRU_Count_b5                             : 5U;
      
      uint32        OBJ_VD_Count_1_b3                            : 3U;
      
      uint32        unused2_b3                                   : 3;
      uint32        OBJ_VD_Count_2_b2                            : 2U;
      
      uint32        OBJ_General_OBJ_Count_b4                     : 4U;
      
      uint32        Reserved_2_b2                                : 2U;
      
      uint32        OBJ_Animal_Count_b4                          : 4U;
      
      uint32        OBJ_VD_NIV_Left_1_b4                         : 4U;
      
      uint32        OBJ_VD_NIV_Left_2_b4                         : 4U;
      
      uint32        OBJ_VD_NIV_Right_1_b4                        : 4U;
      
      uint32        OBJ_VD_NIV_Right_2_b4                        : 4U;
      
      uint32        OBJ_VD_CIPV_ID_1_b4                          : 4U;
      
      uint32        OBJ_VD_CIPV_ID_2_b4                          : 4U;
      
      uint32        OBJ_VD_CIPV_Lost_b2                          : 2U;
      
      uint32        OBJ_VD_Allow_Acc_b2                          : 2U;
      
      uint32        unused3_b1                                   : 1;
      uint32        OBJ_Is_Blocked_Left_b1                       : 1U;
      
      uint32        OBJ_Is_Blocked_Right_b1                      : 1U;
      
      uint32        OBJ_CIPBIC_ID_1_b6                           : 6U;
      
      uint32        OBJ_CIPBIC_ID_2_b2                           : 2U;
      
      uint32        OBJ_CIPBIC_Lost_b2                           : 2U;
      
      uint32        Reserved_3_1_b4                              : 4U;
      
      uint32        Reserved_3_2_b8                              : 8U;
      
      uint32        Reserved_3_3_b8                              : 8U;
      
   #else
      uint32        OBJ_Zero_byte_b8                             : 8U;
      
      uint32        Reserved_1_b24                               : 24U;
      
      uint32        OBJ_Header_CRC_b32                           : 32U;
      
      uint32        OBJ_Protocol_Version_b8                      : 8U;
      
      uint32        OBJ_Sync_ID_b8                               : 8U;
      
      uint32        OBJ_VRU_Count_b5                             : 5U;
      
      uint32        OBJ_VD_Count_b5                              : 5U;
      
      uint32        OBJ_General_OBJ_Count_b4                     : 4U;
      
      uint32        Reserved_2_b2                                : 2U;
      
      uint32        OBJ_Animal_Count_b4                          : 4U;
      
      uint32        OBJ_VD_NIV_Left_b8                           : 8U;
      
      uint32        OBJ_VD_NIV_Right_b8                          : 8U;
      
      uint32        OBJ_VD_CIPV_ID_b8                            : 8U;
      
      uint32        OBJ_VD_CIPV_Lost_b2                          : 2U;
      
      uint32        OBJ_VD_Allow_Acc_b2                          : 2U;
      
      uint32        OBJ_Is_Blocked_Left_b1                       : 1U;
      
      uint32        OBJ_Is_Blocked_Right_b1                      : 1U;
      
      uint32        OBJ_CIPBIC_ID_b8                             : 8U;
      
      uint32        OBJ_CIPBIC_Lost_b2                           : 2U;
      
      uint32        Reserved_3_b20                               : 20U;
      
   #endif
} EYEQMSG_COREOBJvH_Params_t;


typedef struct
{
   #if ENABLE_BIG_ENDIAN_FORMAT
      uint32        unused1_b160                                 : 160;
      uint32        OBJ_CRC_0_1_b8                               : 8U;
      
      uint32        OBJ_CRC_0_2_b8                               : 8U;
      
      uint32        OBJ_CRC_0_3_b8                               : 8U;
      
      uint32        OBJ_CRC_0_4_b8                               : 8U;
      
      uint32        OBJ_ID_0_b8                                  : 8U;
      
      uint32        OBJ_Existence_Probability_0_b8               : 8U;
      
      uint32        OBJ_Fusion_Source_0_1_b8                     : 8U;
      
      uint32        OBJ_Fusion_Source_0_2_b8                     : 8U;
      
      uint32        unused2_b6                                   : 6;
      uint32        OBJ_Triggered_SDM_0_b2                       : 2U;
      
      uint32        OBJ_Motion_Category_0_b4                     : 4U;
      
      uint32        OBJ_Moving_IN_Probability_0_1_b2             : 2U;
      
      uint32        OBJ_Moving_IN_Probability_0_2_b5             : 5U;
      
      uint32        OBJ_Object_Age_0_1_b3                        : 3U;
      
      uint32        OBJ_Object_Age_0_2_b8                        : 8U;
      
      uint32        OBJ_Measuring_Status_0_b3                    : 3U;
      
      uint32        OBJ_Object_Class_0_b4                        : 4U;
      
      uint32        Reserved_4_0_b1                              : 1U;
      
      uint32        OBJ_Class_Probability_0_b7                   : 7U;
      
      uint32        OBJ_Car_Probability_0_1_b1                   : 1U;
      
      uint32        OBJ_Car_Probability_0_2_b6                   : 6U;
      
      uint32        OBJ_Truck_Probability_0_1_b2                 : 2U;
      
      uint32        OBJ_Truck_Probability_0_2_b5                 : 5U;
      
      uint32        OBJ_Bike_Probability_0_1_b3                  : 3U;
      
      uint32        OBJ_Bike_Probability_0_2_b4                  : 4U;
      
      uint32        OBJ_Camera_Source_0_b4                       : 4U;
      
      uint32        OBJ_Motion_Status_0_b3                       : 3U;
      
      uint32        OBJ_Motion_Orientation_0_b4                  : 4U;
      
      uint32        OBJ_Has_Cut_Lane_0_b1                        : 1U;
      
      uint32        unused3_b1                                   : 1;
      uint32        OBJ_Has_Cut_Path_0_b1                        : 1U;
      
      uint32        OBJ_Brake_Light_0_b1                         : 1U;
      
      uint32        OBJ_Turn_Indicator_Right_0_b1                : 1U;
      
      uint32        OBJ_Turn_Indicator_Left_0_b1                 : 1U;
      
      uint32        OBJ_Light_Indicator_Validity_0_b1            : 1U;
      
      uint32        OBJ_Right_Out_Of_Image_0_b1                  : 1U;
      
      uint32        OBJ_Left_Out_Of_Image_0_b1                   : 1U;
      
      uint32        OBJ_Right_Out_Of_Image_V_0_b1                : 1U;
      
      uint32        OBJ_Left_Out_Of_Image_V_0_b1                 : 1U;
      
      uint32        OBJ_Top_Out_Of_Image_0_b1                    : 1U;
      
      uint32        OBJ_Bottom_Out_Of_Image_0_b1                 : 1U;
      
      uint32        OBJ_Top_Out_Of_Image_V_0_b1                  : 1U;
      
      uint32        OBJ_Bottom_Out_Of_Image_V_0_b1               : 1U;
      
      uint32        OBJ_Lane_Assignment_0_b3                     : 3U;
      
      uint32        OBJ_Lane_Assignment_V_0_b1                   : 1U;
      
      uint32        OBJ_Age_Seconds_0_b7                         : 7U;
      
      uint32        OBJ_Age_Seconds_V_0_b1                       : 1U;
      
      uint32        OBJ_Width_0_1_b7                             : 7U;
      
      uint32        OBJ_Width_0_2_b2                             : 2U;
      
      uint32        OBJ_Width_V_0_b1                             : 1U;
      
      uint32        OBJ_Width_STD_0_1_b5                         : 5U;
      
      uint32        OBJ_Width_STD_0_2_b6                         : 6U;
      
      uint32        OBJ_Width_STD_V_0_b1                         : 1U;
      
      uint32        OBJ_Length_0_1_b1                            : 1U;
      
      uint32        OBJ_Length_0_2_b8                            : 8U;
      
      uint32        OBJ_Length_V_0_b1                            : 1U;
      
      uint32        OBJ_Length_STD_0_1_b7                        : 7U;
      
      uint32        OBJ_Length_STD_0_2_b3                        : 3U;
      
      uint32        OBJ_Length_STD_V_0_b1                        : 1U;
      
      uint32        OBJ_Radar_ID_0_1_b4                          : 4U;
      
      uint32        OBJ_Radar_ID_0_2_b4                          : 4U;
      
      uint32        OBJ_Height_0_1_b4                            : 4U;
      
      uint32        OBJ_Height_0_2_b5                            : 5U;
      
      uint32        OBJ_Height_V_0_b1                            : 1U;
      
      uint32        Reserved_5_0_b2                              : 2U;
      
      uint32        OBJ_Height_STD_0_1_b8                        : 8U;
      
      uint32        OBJ_Height_STD_0_2_b3                        : 3U;
      
      uint32        OBJ_Height_STD_V_0_b1                        : 1U;
      
      uint32        OBJ_Abs_Long_Velocity_0_1_b4                 : 4U;
      
      uint32        OBJ_Abs_Long_Velocity_0_2_b8                 : 8U;
      
      uint32        OBJ_Abs_Long_Velocity_V_0_b1                 : 1U;
      
      uint32        Reserved_6_0_b7                              : 7U;
      
      uint32        OBJ_Abs_Long_Velocity_STD_0_1_b8             : 8U;
      
      uint32        OBJ_Abs_Long_Velocity_STD_0_2_b5             : 5U;
      
      uint32        OBJ_Abs_Long_Vel_STD_V_0_b1                  : 1U;
      
      uint32        OBJ_Abs_Lat_Velocity_0_1_b2                  : 2U;
      
      uint32        OBJ_Abs_Lat_Velocity_0_2_b8                  : 8U;
      
      uint32        OBJ_Abs_Lat_Velocity_0_3_b1                  : 1U;
      
      uint32        OBJ_Abs_Lat_Velocity_V_0_b1                  : 1U;
      
      uint32        Reserved_7_0_b6                              : 6U;
      
      uint32        OBJ_Abs_Lat_Velocity_STD_0_1_b8              : 8U;
      
      uint32        OBJ_Abs_Lat_Velocity_STD_0_2_b5              : 5U;
      
      uint32        OBJ_Abs_Lat_Vel_STD_V_0_b1                   : 1U;
      
      uint32        OBJ_Abs_Long_Acc_0_1_b2                      : 2U;
      
      uint32        OBJ_Abs_Long_Acc_0_2_b7                      : 7U;
      
      uint32        OBJ_Abs_Long_Acc_V_0_b1                      : 1U;
      
      uint32        Reserved_8_0_b8                              : 8U;
      
      uint32        OBJ_Abs_Long_Acc_STD_0_1_b8                  : 8U;
      
      uint32        OBJ_Abs_Long_Acc_STD_0_2_b2                  : 2U;
      
      uint32        OBJ_Abs_Long_Acc_STD_V_0_b1                  : 1U;
      
      uint32        OBJ_Abs_Lat_Acc_0_1_b5                       : 5U;
      
      uint32        OBJ_Abs_Lat_Acc_0_2_b4                       : 4U;
      
      uint32        OBJ_Abs_Lat_Acc_V_0_b1                       : 1U;
      
      uint32        OBJ_Abs_Lat_Acc_STD_0_1_b3                   : 3U;
      
      uint32        OBJ_Abs_Lat_Acc_STD_0_2_b7                   : 7U;
      
      uint32        OBJ_Abs_Lat_Acc_STD_V_0_b1                   : 1U;
      
      uint32        OBJ_Abs_Acceleration_0_1_b8                  : 8U;
      
      uint32        OBJ_Abs_Acceleration_0_2_b1                  : 1U;
      
      uint32        OBJ_Abs_Acceleration_V_0_b1                  : 1U;
      
      uint32        OBJ_Abs_Acc_STD_0_1_b6                       : 6U;
      
      uint32        OBJ_Abs_Acc_STD_0_2_b4                       : 4U;
      
      uint32        OBJ_Abs_Acc_STD_V_0_b1                       : 1U;
      
      uint32        OBJ_Inv_TTC_0_1_b3                           : 3U;
      
      uint32        OBJ_Inv_TTC_0_2_b8                           : 8U;
      
      uint32        OBJ_Inv_TTC_V_0_b1                           : 1U;
      
      uint32        OBJ_Inv_TTC_STD_0_1_b7                       : 7U;
      
      uint32        OBJ_Inv_TTC_STD_0_2_b5                       : 5U;
      
      uint32        OBJ_Inv_TTC_STD_V_0_b1                       : 1U;
      
      uint32        OBJ_Relative_Long_Acc_0_1_b2                 : 2U;
      
      uint32        OBJ_Relative_Long_Acc_0_2_b8                 : 8U;
      
      uint32        OBJ_Relative_Long_Acc_V_0_b1                 : 1U;
      
      uint32        Reserved_9_0_b7                              : 7U;
      
      uint32        OBJ_Relative_Long_Acc_STD_0_1_b8             : 8U;
      
      uint32        OBJ_Relative_Long_Acc_STD_0_2_b2             : 2U;
      
      uint32        OBJ_Rel_Long_Acc_STD_V_0_b1                  : 1U;
      
      uint32        OBJ_Relative_Long_Velocity_0_1_b5            : 5U;
      
      uint32        OBJ_Relative_Long_Velocity_0_2_b8            : 8U;
      
      uint32        OBJ_Relative_Long_Velocity_V_0_b1            : 1U;
      
      uint32        Reserved_10_0_b7                             : 7U;
      
      uint32        OBJ_Relative_Long_Vel_STD_0_1_b8             : 8U;
      
      uint32        OBJ_Relative_Long_Vel_STD_0_2_b6             : 6U;
      
      uint32        OBJ_Rel_Long_Vel_STD_V_0_b1                  : 1U;
      
      uint32        OBJ_Relative_Lat_Velocity_0_1_b1             : 1U;
      
      uint32        OBJ_Relative_Lat_Velocity_0_2_b8             : 8U;
      
      uint32        OBJ_Relative_Lat_Velocity_0_3_b2             : 2U;
      
      uint32        OBJ_Relative_Lat_Velocity_V_0_b1             : 1U;
      
      uint32        Reserved_11_0_b5                             : 5U;
      
      uint32        OBJ_Relative_Lat_Velocity_STD_0_1_b8         : 8U;
      
      uint32        OBJ_Relative_Lat_Velocity_STD_0_2_b5         : 5U;
      
      uint32        OBJ_Rel_Lat_Vel_STD_V_0_b1                   : 1U;
      
      uint32        OBJ_Long_Distance_0_1_b2                     : 2U;
      
      uint32        OBJ_Long_Distance_0_2_b8                     : 8U;
      
      uint32        OBJ_Long_Distance_0_3_b4                     : 4U;
      
      uint32        OBJ_Long_Distance_V_0_b1                     : 1U;
      
      uint32        Reserved_12_0_b3                             : 3U;
      
      uint32        OBJ_Long_Distance_STD_0_1_b8                 : 8U;
      
      uint32        OBJ_Long_Distance_STD_0_2_b7                 : 7U;
      
      uint32        OBJ_Long_Distance_STD_V_0_b1                 : 1U;
      
      uint32        OBJ_Lat_Distance_0_1_b8                      : 8U;
      
      uint32        OBJ_Lat_Distance_0_2_b4                      : 4U;
      
      uint32        OBJ_Lat_Distance_V_0_b1                      : 1U;
      
      uint32        Reserved_13_0_b3                             : 3U;
      
      uint32        OBJ_Lat_Distance_STD_0_1_b8                  : 8U;
      
      uint32        OBJ_Lat_Distance_STD_0_2_b6                  : 6U;
      
      uint32        OBJ_Lat_Distance_STD_V_0_b1                  : 1U;
      
      uint32        OBJ_Absolute_Speed_0_1_b1                    : 1U;
      
      uint32        OBJ_Absolute_Speed_0_2_b8                    : 8U;
      
      uint32        OBJ_Absolute_Speed_0_3_b3                    : 3U;
      
      uint32        OBJ_Absolute_Speed_V_0_b1                    : 1U;
      
      uint32        Reserved_14_0_b4                             : 4U;
      
      uint32        OBJ_Absolute_Speed_STD_0_1_b8                : 8U;
      
      uint32        OBJ_Absolute_Speed_STD_0_2_b5                : 5U;
      
      uint32        OBJ_Absolute_Speed_STD_V_0_b1                : 1U;
      
      uint32        OBJ_Heading_0_1_b2                           : 2U;
      
      uint32        OBJ_Heading_0_2_b8                           : 8U;
      
      uint32        OBJ_Heading_V_0_b1                           : 1U;
      
      uint32        Reserved_15_0_b7                             : 7U;
      
      uint32        OBJ_Heading_STD_0_1_b8                       : 8U;
      
      uint32        OBJ_Heading_STD_0_2_b7                       : 7U;
      
      uint32        OBJ_Heading_STD_V_0_b1                       : 1U;
      
      uint32        OBJ_Angle_Rate_STD_0_1_b8                    : 8U;
      
      uint32        OBJ_Angle_Rate_STD_0_2_b7                    : 7U;
      
      uint32        OBJ_Angle_Rate_STD_V_0_b1                    : 1U;
      
      uint32        OBJ_Angle_Rate_0_1_b8                        : 8U;
      
      uint32        OBJ_Angle_Rate_0_2_b4                        : 4U;
      
      uint32        OBJ_Angle_Rate_V_0_b1                        : 1U;
      
      uint32        OBJ_Angle_Right_0_1_b3                       : 3U;
      
      uint32        OBJ_Angle_Right_0_2_b8                       : 8U;
      
      uint32        OBJ_Angle_Right_0_3_b3                       : 3U;
      
      uint32        OBJ_Angle_Right_V_0_b1                       : 1U;
      
      uint32        Reserved_16_0_b4                             : 4U;
      
      uint32        OBJ_Angle_Right_STD_0_1_b8                   : 8U;
      
      uint32        OBJ_Angle_Right_STD_0_2_b6                   : 6U;
      
      uint32        OBJ_Angle_Right_STD_V_0_b1                   : 1U;
      
      uint32        OBJ_Angle_Left_0_1_b1                        : 1U;
      
      uint32        OBJ_Angle_Left_0_2_b8                        : 8U;
      
      uint32        OBJ_Angle_Left_0_3_b5                        : 5U;
      
      uint32        OBJ_Angle_Left_V_0_b1                        : 1U;
      
      uint32        Reserved_17_0_b2                             : 2U;
      
      uint32        OBJ_Angle_Left_STD_0_1_b8                    : 8U;
      
      uint32        OBJ_Angle_Left_STD_0_2_b6                    : 6U;
      
      uint32        OBJ_Angle_Left_STD_V_0_b1                    : 1U;
      
      uint32        OBJ_Angle_Side_0_1_b1                        : 1U;
      
      uint32        OBJ_Angle_Side_0_2_b8                        : 8U;
      
      uint32        OBJ_Angle_Side_0_3_b5                        : 5U;
      
      uint32        OBJ_Angle_Side_V_0_b1                        : 1U;
      
      uint32        Reserved_18_0_b2                             : 2U;
      
      uint32        OBJ_Angle_Side_STD_0_1_b8                    : 8U;
      
      uint32        OBJ_Angle_Side_STD_0_2_b6                    : 6U;
      
      uint32        OBJ_Angle_Side_STD_V_0_b1                    : 1U;
      
      uint32        OBJ_Angle_Mid_V_0_b1                         : 1U;
      
      uint32        OBJ_Angle_Mid_0_1_b8                         : 8U;
      
      uint32        OBJ_Angle_Mid_0_2_b6                         : 6U;
      
      uint32        Reserved_19_0_b2                             : 2U;
      
      uint32        OBJ_Angle_Mid_STD_0_1_b8                     : 8U;
      
      uint32        OBJ_Angle_Mid_STD_0_2_b6                     : 6U;
      
      uint32        OBJ_Angle_Mid_STD_V_0_b1                     : 1U;
      
      uint32        OBJ_Angle_Bottom_V_0_b1                      : 1U;
      
      uint32        OBJ_Angle_Bottom_0_1_b8                      : 8U;
      
      uint32        OBJ_Angle_Bottom_0_2_b6                      : 6U;
      
      uint32        Reserved_20_0_b2                             : 2U;
      
      uint32        OBJ_Angle_Bottom_STD_0_1_b8                  : 8U;
      
      uint32        OBJ_Angle_Bottom_STD_0_2_b6                  : 6U;
      
      uint32        OBJ_Angle_Bottom_STD_V_0_b1                  : 1U;
      
      uint32        OBJ_Visibility_Side_V_0_b1                   : 1U;
      
      uint32        OBJ_Visibility_Side_0_b2                     : 2U;
      
      uint32        OBJ_Is_In_Drivable_Area_0_b1                 : 1U;
      
      uint32        OBJ_Is_In_Drivable_Area_V_0_b1               : 1U;
      
      uint32        OBJ_Is_VeryClose_V_0_b1                      : 1U;
      
      uint32        OBJ_Is_VeryClose_0_b1                        : 1U;
      
      uint32        OBJ_Occlusion_RL_0_b2                        : 2U;
      
      uint32        OBJ_Occlusion_RR_0_b2                        : 2U;
      
      uint32        OBJ_Occlusion_FR_0_b2                        : 2U;
      
      uint32        OBJ_Occlusion_FL_0_b2                        : 2U;
      
      uint32        Reserved_21_0_b2                             : 2U;
      
      uint32        OBJ_OverlapAngleEgoLaneR_0_1_b8              : 8U;
      
      uint32        OBJ_OverlapAngleEgoLaneR_0_2_b2              : 2U;
      
      uint32        OBJ_OverlapAngleEgoLaneL_0_1_b6              : 6U;
      
      uint32        OBJ_OverlapAngleEgoLaneL_0_2_b4              : 4U;
      
      uint32        OBJ_Is_EMERGENCY_VCL_0_b1                    : 1U;
      
      uint32        OBJ_EMERGENCY_LIGHT_COLOR_0_1_b3             : 3U;
      
      uint32        OBJ_EMERGENCY_LIGHT_COLOR_0_2_b1             : 1U;
      
      uint32        OBJ_EMERGENCY_V_0_b1                         : 1U;
      
      uint32        Reserved_22_0_b6                             : 6U;
      
      uint32        OBJ_Angle_Top_0_1_b8                         : 8U;
      
      uint32        OBJ_Angle_Top_0_2_b6                         : 6U;
      
      uint32        OBJ_Angle_Top_V_0_b1                         : 1U;
      
      uint32        OBJ_Angle_Top_STD_0_1_b1                     : 1U;
      
      uint32        OBJ_Angle_Top_STD_0_2_b8                     : 8U;
      
      uint32        OBJ_Angle_Top_STD_0_3_b6                     : 6U;
      
      uint32        OBJ_Angle_Top_STD_V_0_b1                     : 1U;
      
      uint32        OBJ_Open_Door_Left_0_b1                      : 1U;
      
      uint32        OBJ_Open_Door_Right_0_b1                     : 1U;
      
      uint32        OBJ_Visible_Left_or_Right_0_b2               : 2U;
      
      uint32        OBJ_Visible_Left_or_Right_V_0_b1             : 1U;
      
      uint32        Reserved_23_0_1_b4                           : 4U;
      
      uint32        Reserved_23_0_2_b8                           : 8U;
      
      uint32        Reserved_23_0_3_b8                           : 8U;
      
      uint32        Reserved_23_0_4_b8                           : 8U;
      
   #else
      uint32        OBJ_CRC_0_b32                                : 32U;
      
      uint32        OBJ_ID_0_b8                                  : 8U;
      
      uint32        OBJ_Existence_Probability_0_b8               : 8U;
      
      uint32        OBJ_Fusion_Source_0_b16                      : 16U;
      
      uint32        OBJ_Triggered_SDM_0_b2                       : 2U;
      
      uint32        OBJ_Motion_Category_0_b4                     : 4U;
      
      uint32        OBJ_Moving_IN_Probability_0_b7               : 7U;
      
      uint32        OBJ_Object_Age_0_b11                         : 11U;
      
      uint32        OBJ_Measuring_Status_0_b3                    : 3U;
      
      uint32        OBJ_Object_Class_0_b4                        : 4U;
      
      uint32        Reserved_4_0_b1                              : 1U;
      
      uint32        OBJ_Class_Probability_0_b7                   : 7U;
      
      uint32        OBJ_Car_Probability_0_b7                     : 7U;
      
      uint32        OBJ_Truck_Probability_0_b7                   : 7U;
      
      uint32        OBJ_Bike_Probability_0_b7                    : 7U;
      
      uint32        OBJ_Camera_Source_0_b4                       : 4U;
      
      uint32        OBJ_Motion_Status_0_b3                       : 3U;
      
      uint32        OBJ_Motion_Orientation_0_b4                  : 4U;
      
      uint32        OBJ_Has_Cut_Lane_0_b1                        : 1U;
      
      uint32        OBJ_Has_Cut_Path_0_b1                        : 1U;
      
      uint32        OBJ_Brake_Light_0_b1                         : 1U;
      
      uint32        OBJ_Turn_Indicator_Right_0_b1                : 1U;
      
      uint32        OBJ_Turn_Indicator_Left_0_b1                 : 1U;
      
      uint32        OBJ_Light_Indicator_Validity_0_b1            : 1U;
      
      uint32        OBJ_Right_Out_Of_Image_0_b1                  : 1U;
      
      uint32        OBJ_Left_Out_Of_Image_0_b1                   : 1U;
      
      uint32        OBJ_Right_Out_Of_Image_V_0_b1                : 1U;
      
      uint32        OBJ_Left_Out_Of_Image_V_0_b1                 : 1U;
      
      uint32        OBJ_Top_Out_Of_Image_0_b1                    : 1U;
      
      uint32        OBJ_Bottom_Out_Of_Image_0_b1                 : 1U;
      
      uint32        OBJ_Top_Out_Of_Image_V_0_b1                  : 1U;
      
      uint32        OBJ_Bottom_Out_Of_Image_V_0_b1               : 1U;
      
      uint32        OBJ_Lane_Assignment_0_b3                     : 3U;
      
      uint32        OBJ_Lane_Assignment_V_0_b1                   : 1U;
      
      uint32        OBJ_Age_Seconds_0_b7                         : 7U;
      
      uint32        OBJ_Age_Seconds_V_0_b1                       : 1U;
      
      uint32        OBJ_Width_0_b9                               : 9U;
      
      uint32        OBJ_Width_V_0_b1                             : 1U;
      
      uint32        OBJ_Width_STD_0_b11                          : 11U;
      
      uint32        OBJ_Width_STD_V_0_b1                         : 1U;
      
      uint32        OBJ_Length_0_b9                              : 9U;
      
      uint32        OBJ_Length_V_0_b1                            : 1U;
      
      uint32        OBJ_Length_STD_0_b10                         : 10U;
      
      uint32        OBJ_Length_STD_V_0_b1                        : 1U;
      
      uint32        OBJ_Radar_ID_0_b8                            : 8U;
      
      uint32        OBJ_Height_0_b9                              : 9U;
      
      uint32        OBJ_Height_V_0_b1                            : 1U;
      
      uint32        Reserved_5_0_b2                              : 2U;
      
      uint32        OBJ_Height_STD_0_b11                         : 11U;
      
      uint32        OBJ_Height_STD_V_0_b1                        : 1U;
      
      uint32        OBJ_Abs_Long_Velocity_0_b12                  : 12U;
      
      uint32        OBJ_Abs_Long_Velocity_V_0_b1                 : 1U;
      
      uint32        Reserved_6_0_b7                              : 7U;
      
      uint32        OBJ_Abs_Long_Velocity_STD_0_b13              : 13U;
      
      uint32        OBJ_Abs_Long_Vel_STD_V_0_b1                  : 1U;
      
      uint32        OBJ_Abs_Lat_Velocity_0_b11                   : 11U;
      
      uint32        OBJ_Abs_Lat_Velocity_V_0_b1                  : 1U;
      
      uint32        Reserved_7_0_b6                              : 6U;
      
      uint32        OBJ_Abs_Lat_Velocity_STD_0_b13               : 13U;
      
      uint32        OBJ_Abs_Lat_Vel_STD_V_0_b1                   : 1U;
      
      uint32        OBJ_Abs_Long_Acc_0_b9                        : 9U;
      
      uint32        OBJ_Abs_Long_Acc_V_0_b1                      : 1U;
      
      uint32        Reserved_8_0_b8                              : 8U;
      
      uint32        OBJ_Abs_Long_Acc_STD_0_b10                   : 10U;
      
      uint32        OBJ_Abs_Long_Acc_STD_V_0_b1                  : 1U;
      
      uint32        OBJ_Abs_Lat_Acc_0_b9                         : 9U;
      
      uint32        OBJ_Abs_Lat_Acc_V_0_b1                       : 1U;
      
      uint32        OBJ_Abs_Lat_Acc_STD_0_b10                    : 10U;
      
      uint32        OBJ_Abs_Lat_Acc_STD_V_0_b1                   : 1U;
      
      uint32        OBJ_Abs_Acceleration_0_b9                    : 9U;
      
      uint32        OBJ_Abs_Acceleration_V_0_b1                  : 1U;
      
      uint32        OBJ_Abs_Acc_STD_0_b10                        : 10U;
      
      uint32        OBJ_Abs_Acc_STD_V_0_b1                       : 1U;
      
      uint32        OBJ_Inv_TTC_0_b11                            : 11U;
      
      uint32        OBJ_Inv_TTC_V_0_b1                           : 1U;
      
      uint32        OBJ_Inv_TTC_STD_0_b12                        : 12U;
      
      uint32        OBJ_Inv_TTC_STD_V_0_b1                       : 1U;
      
      uint32        OBJ_Relative_Long_Acc_0_b10                  : 10U;
      
      uint32        OBJ_Relative_Long_Acc_V_0_b1                 : 1U;
      
      uint32        Reserved_9_0_b7                              : 7U;
      
      uint32        OBJ_Relative_Long_Acc_STD_0_b10              : 10U;
      
      uint32        OBJ_Rel_Long_Acc_STD_V_0_b1                  : 1U;
      
      uint32        OBJ_Relative_Long_Velocity_0_b13             : 13U;
      
      uint32        OBJ_Relative_Long_Velocity_V_0_b1            : 1U;
      
      uint32        Reserved_10_0_b7                             : 7U;
      
      uint32        OBJ_Relative_Long_Vel_STD_0_b14              : 14U;
      
      uint32        OBJ_Rel_Long_Vel_STD_V_0_b1                  : 1U;
      
      uint32        OBJ_Relative_Lat_Velocity_0_b11              : 11U;
      
      uint32        OBJ_Relative_Lat_Velocity_V_0_b1             : 1U;
      
      uint32        Reserved_11_0_b5                             : 5U;
      
      uint32        OBJ_Relative_Lat_Velocity_STD_0_b13          : 13U;
      
      uint32        OBJ_Rel_Lat_Vel_STD_V_0_b1                   : 1U;
      
      uint32        OBJ_Long_Distance_0_b14                      : 14U;
      
      uint32        OBJ_Long_Distance_V_0_b1                     : 1U;
      
      uint32        Reserved_12_0_b3                             : 3U;
      
      uint32        OBJ_Long_Distance_STD_0_b15                  : 15U;
      
      uint32        OBJ_Long_Distance_STD_V_0_b1                 : 1U;
      
      uint32        OBJ_Lat_Distance_0_b12                       : 12U;
      
      uint32        OBJ_Lat_Distance_V_0_b1                      : 1U;
      
      uint32        Reserved_13_0_b3                             : 3U;
      
      uint32        OBJ_Lat_Distance_STD_0_b14                   : 14U;
      
      uint32        OBJ_Lat_Distance_STD_V_0_b1                  : 1U;
      
      uint32        OBJ_Absolute_Speed_0_b12                     : 12U;
      
      uint32        OBJ_Absolute_Speed_V_0_b1                    : 1U;
      
      uint32        Reserved_14_0_b4                             : 4U;
      
      uint32        OBJ_Absolute_Speed_STD_0_b13                 : 13U;
      
      uint32        OBJ_Absolute_Speed_STD_V_0_b1                : 1U;
      
      uint32        OBJ_Heading_0_b10                            : 10U;
      
      uint32        OBJ_Heading_V_0_b1                           : 1U;
      
      uint32        Reserved_15_0_b7                             : 7U;
      
      uint32        OBJ_Heading_STD_0_b15                        : 15U;
      
      uint32        OBJ_Heading_STD_V_0_b1                       : 1U;
      
      uint32        OBJ_Angle_Rate_STD_0_b15                     : 15U;
      
      uint32        OBJ_Angle_Rate_STD_V_0_b1                    : 1U;
      
      uint32        OBJ_Angle_Rate_0_b12                         : 12U;
      
      uint32        OBJ_Angle_Rate_V_0_b1                        : 1U;
      
      uint32        OBJ_Angle_Right_0_b14                        : 14U;
      
      uint32        OBJ_Angle_Right_V_0_b1                       : 1U;
      
      uint32        Reserved_16_0_b4                             : 4U;
      
      uint32        OBJ_Angle_Right_STD_0_b14                    : 14U;
      
      uint32        OBJ_Angle_Right_STD_V_0_b1                   : 1U;
      
      uint32        OBJ_Angle_Left_0_b14                         : 14U;
      
      uint32        OBJ_Angle_Left_V_0_b1                        : 1U;
      
      uint32        Reserved_17_0_b2                             : 2U;
      
      uint32        OBJ_Angle_Left_STD_0_b14                     : 14U;
      
      uint32        OBJ_Angle_Left_STD_V_0_b1                    : 1U;
      
      uint32        OBJ_Angle_Side_0_b14                         : 14U;
      
      uint32        OBJ_Angle_Side_V_0_b1                        : 1U;
      
      uint32        Reserved_18_0_b2                             : 2U;
      
      uint32        OBJ_Angle_Side_STD_0_b14                     : 14U;
      
      uint32        OBJ_Angle_Side_STD_V_0_b1                    : 1U;
      
      uint32        OBJ_Angle_Mid_V_0_b1                         : 1U;
      
      uint32        OBJ_Angle_Mid_0_b14                          : 14U;
      
      uint32        Reserved_19_0_b2                             : 2U;
      
      uint32        OBJ_Angle_Mid_STD_0_b14                      : 14U;
      
      uint32        OBJ_Angle_Mid_STD_V_0_b1                     : 1U;
      
      uint32        OBJ_Angle_Bottom_V_0_b1                      : 1U;
      
      uint32        OBJ_Angle_Bottom_0_b14                       : 14U;
      
      uint32        Reserved_20_0_b2                             : 2U;
      
      uint32        OBJ_Angle_Bottom_STD_0_b14                   : 14U;
      
      uint32        OBJ_Angle_Bottom_STD_V_0_b1                  : 1U;
      
      uint32        OBJ_Visibility_Side_V_0_b1                   : 1U;
      
      uint32        OBJ_Visibility_Side_0_b2                     : 2U;
      
      uint32        OBJ_Is_In_Drivable_Area_0_b1                 : 1U;
      
      uint32        OBJ_Is_In_Drivable_Area_V_0_b1               : 1U;
      
      uint32        OBJ_Is_VeryClose_V_0_b1                      : 1U;
      
      uint32        OBJ_Is_VeryClose_0_b1                        : 1U;
      
      uint32        OBJ_Occlusion_RL_0_b2                        : 2U;
      
      uint32        OBJ_Occlusion_RR_0_b2                        : 2U;
      
      uint32        OBJ_Occlusion_FR_0_b2                        : 2U;
      
      uint32        OBJ_Occlusion_FL_0_b2                        : 2U;
      
      uint32        Reserved_21_0_b2                             : 2U;
      
      uint32        OBJ_OverlapAngleEgoLaneR_0_b10               : 10U;
      
      uint32        OBJ_OverlapAngleEgoLaneL_0_b10               : 10U;
      
      uint32        OBJ_Is_EMERGENCY_VCL_0_b1                    : 1U;
      
      uint32        OBJ_EMERGENCY_LIGHT_COLOR_0_b4               : 4U;
      
      uint32        OBJ_EMERGENCY_V_0_b1                         : 1U;
      
      uint32        Reserved_22_0_b6                             : 6U;
      
      uint32        OBJ_Angle_Top_0_b14                          : 14U;
      
      uint32        OBJ_Angle_Top_V_0_b1                         : 1U;
      
      uint32        OBJ_Angle_Top_STD_0_b15                      : 15U;
      
      uint32        OBJ_Angle_Top_STD_V_0_b1                     : 1U;
      
      uint32        OBJ_Open_Door_Left_0_b1                      : 1U;
      
      uint32        OBJ_Open_Door_Right_0_b1                     : 1U;
      
      uint32        OBJ_Visible_Left_or_Right_0_b2               : 2U;
      
      uint32        OBJ_Visible_Left_or_Right_V_0_b1             : 1U;
      
      uint32        Reserved_23_0_b28                            : 28U;
      
   #endif
} EYEQMSG_COREOBJvO_Params_t;


typedef struct
{
   EYEQMSG_COREOBJvH_Params_t EYEQMSG_COREOBJvH_Params_s;
   EYEQMSG_COREOBJvO_Params_t EYEQMSG_COREOBJvO_Params_as[C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX];
} EYEQMSG_COREOBJ_Params_t;


/*****************************************************************************
                  Exported function prototypes
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvH_OBJ_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pOBJ_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Zero_byte
*    OBJ_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Zero_byte signal value of Virtual_HEADER_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvH_OBJ_Zero_byte( uint8 * pOBJ_Zero_byte );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvH_Reserved_1
*
* FUNCTION ARGUMENTS:
*    uint32 * pReserved_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1
*    Reserved_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1 signal value of Virtual_HEADER_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvH_Reserved_1( uint32 * pReserved_1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvH_OBJ_Header_CRC
*
* FUNCTION ARGUMENTS:
*    uint32 * pOBJ_Header_CRC - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Header_CRC
*    OBJ_Header_CRC returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Header_CRC signal value of Virtual_HEADER_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvH_OBJ_Header_CRC( uint32 * pOBJ_Header_CRC );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvH_OBJ_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pOBJ_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Protocol_Version
*    OBJ_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Protocol_Version signal value of Virtual_HEADER_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvH_OBJ_Protocol_Version( uint8 * pOBJ_Protocol_Version );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvH_OBJ_Sync_ID
*
* FUNCTION ARGUMENTS:
*    uint8 * pOBJ_Sync_ID - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Sync_ID
*    OBJ_Sync_ID returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Sync_ID signal value of Virtual_HEADER_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvH_OBJ_Sync_ID( uint8 * pOBJ_Sync_ID );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvH_OBJ_VRU_Count
*
* FUNCTION ARGUMENTS:
*    uint8 * pOBJ_VRU_Count - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_VRU_Count
*    OBJ_VRU_Count returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_VRU_Count signal value of Virtual_HEADER_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvH_OBJ_VRU_Count( uint8 * pOBJ_VRU_Count );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvH_OBJ_VD_Count
*
* FUNCTION ARGUMENTS:
*    uint8 * pOBJ_VD_Count - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_VD_Count
*    OBJ_VD_Count returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_VD_Count signal value of Virtual_HEADER_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvH_OBJ_VD_Count( uint8 * pOBJ_VD_Count );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvH_OBJ_General_OBJ_Count
*
* FUNCTION ARGUMENTS:
*    uint8 * pOBJ_General_OBJ_Count - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_General_OBJ_Count
*    OBJ_General_OBJ_Count returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_General_OBJ_Count signal value of Virtual_HEADER_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvH_OBJ_General_OBJ_Count( uint8 * pOBJ_General_OBJ_Count );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvH_Reserved_2
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_2
*    Reserved_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_2 signal value of Virtual_HEADER_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvH_Reserved_2( uint8 * pReserved_2 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvH_OBJ_Animal_Count
*
* FUNCTION ARGUMENTS:
*    uint8 * pOBJ_Animal_Count - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Animal_Count
*    OBJ_Animal_Count returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Animal_Count signal value of Virtual_HEADER_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvH_OBJ_Animal_Count( uint8 * pOBJ_Animal_Count );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvH_OBJ_VD_NIV_Left
*
* FUNCTION ARGUMENTS:
*    uint8 * pOBJ_VD_NIV_Left - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_VD_NIV_Left
*    OBJ_VD_NIV_Left returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_VD_NIV_Left signal value of Virtual_HEADER_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvH_OBJ_VD_NIV_Left( uint8 * pOBJ_VD_NIV_Left );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvH_OBJ_VD_NIV_Right
*
* FUNCTION ARGUMENTS:
*    uint8 * pOBJ_VD_NIV_Right - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_VD_NIV_Right
*    OBJ_VD_NIV_Right returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_VD_NIV_Right signal value of Virtual_HEADER_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvH_OBJ_VD_NIV_Right( uint8 * pOBJ_VD_NIV_Right );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvH_OBJ_VD_CIPV_ID
*
* FUNCTION ARGUMENTS:
*    uint8 * pOBJ_VD_CIPV_ID - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_VD_CIPV_ID
*    OBJ_VD_CIPV_ID returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_VD_CIPV_ID signal value of Virtual_HEADER_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvH_OBJ_VD_CIPV_ID( uint8 * pOBJ_VD_CIPV_ID );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvH_OBJ_VD_CIPV_Lost
*
* FUNCTION ARGUMENTS:
*    COREOBJvHOBJVDCIPVLost * pOBJ_VD_CIPV_Lost - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_VD_CIPV_Lost
*    OBJ_VD_CIPV_Lost returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_VD_CIPV_Lost signal value of Virtual_HEADER_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvH_OBJ_VD_CIPV_Lost( COREOBJvHOBJVDCIPVLost * pOBJ_VD_CIPV_Lost );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvH_OBJ_VD_Allow_Acc
*
* FUNCTION ARGUMENTS:
*    COREOBJvHOBJVDAllowAcc * pOBJ_VD_Allow_Acc - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_VD_Allow_Acc
*    OBJ_VD_Allow_Acc returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_VD_Allow_Acc signal value of Virtual_HEADER_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvH_OBJ_VD_Allow_Acc( COREOBJvHOBJVDAllowAcc * pOBJ_VD_Allow_Acc );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvH_OBJ_Is_Blocked_Left
*
* FUNCTION ARGUMENTS:
*    COREOBJvHOBJIsBlockedLeft * pOBJ_Is_Blocked_Left - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Is_Blocked_Left
*    OBJ_Is_Blocked_Left returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Is_Blocked_Left signal value of Virtual_HEADER_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvH_OBJ_Is_Blocked_Left( COREOBJvHOBJIsBlockedLeft * pOBJ_Is_Blocked_Left );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvH_OBJ_Is_Blocked_Right
*
* FUNCTION ARGUMENTS:
*    COREOBJvHOBJIsBlockedRight * pOBJ_Is_Blocked_Right - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Is_Blocked_Right
*    OBJ_Is_Blocked_Right returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Is_Blocked_Right signal value of Virtual_HEADER_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvH_OBJ_Is_Blocked_Right( COREOBJvHOBJIsBlockedRight * pOBJ_Is_Blocked_Right );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvH_OBJ_CIPBIC_ID
*
* FUNCTION ARGUMENTS:
*    uint8 * pOBJ_CIPBIC_ID - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_CIPBIC_ID
*    OBJ_CIPBIC_ID returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_CIPBIC_ID signal value of Virtual_HEADER_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvH_OBJ_CIPBIC_ID( uint8 * pOBJ_CIPBIC_ID );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvH_OBJ_CIPBIC_Lost
*
* FUNCTION ARGUMENTS:
*    COREOBJvHOBJCIPBICLost * pOBJ_CIPBIC_Lost - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_CIPBIC_Lost
*    OBJ_CIPBIC_Lost returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_CIPBIC_Lost signal value of Virtual_HEADER_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvH_OBJ_CIPBIC_Lost( COREOBJvHOBJCIPBICLost * pOBJ_CIPBIC_Lost );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvH_Reserved_3
*
* FUNCTION ARGUMENTS:
*    uint32 * pReserved_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_3
*    Reserved_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_3 signal value of Virtual_HEADER_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvH_Reserved_3( uint32 * pReserved_3 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_CRC_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint32 * pOBJ_CRC_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_CRC_0
*    OBJ_CRC_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_CRC_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_CRC_0( uint8 objIndx_u8, uint32 * pOBJ_CRC_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_ID_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pOBJ_ID_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_ID_0
*    OBJ_ID_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_ID_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_ID_0( uint8 objIndx_u8, uint8 * pOBJ_ID_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Existence_Probability_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pOBJ_Existence_Probability_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Existence_Probability_0
*    OBJ_Existence_Probability_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Existence_Probability_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Existence_Probability_0( uint8 objIndx_u8, uint8 * pOBJ_Existence_Probability_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Fusion_Source_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJFusionSource0 * pOBJ_Fusion_Source_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Fusion_Source_0
*    OBJ_Fusion_Source_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Fusion_Source_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Fusion_Source_0( uint8 objIndx_u8, COREOBJvOOBJFusionSource0 * pOBJ_Fusion_Source_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Triggered_SDM_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJTriggeredSDM0 * pOBJ_Triggered_SDM_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Triggered_SDM_0
*    OBJ_Triggered_SDM_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Triggered_SDM_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Triggered_SDM_0( uint8 objIndx_u8, COREOBJvOOBJTriggeredSDM0 * pOBJ_Triggered_SDM_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Motion_Category_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJMotionCategory0 * pOBJ_Motion_Category_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Motion_Category_0
*    OBJ_Motion_Category_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Motion_Category_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Motion_Category_0( uint8 objIndx_u8, COREOBJvOOBJMotionCategory0 * pOBJ_Motion_Category_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Moving_IN_Probability_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pOBJ_Moving_IN_Probability_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Moving_IN_Probability_0
*    OBJ_Moving_IN_Probability_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Moving_IN_Probability_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Moving_IN_Probability_0( uint8 objIndx_u8, uint8 * pOBJ_Moving_IN_Probability_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Object_Age_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Object_Age_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Object_Age_0
*    OBJ_Object_Age_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Object_Age_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Object_Age_0( uint8 objIndx_u8, uint16 * pOBJ_Object_Age_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Measuring_Status_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJMeasuringStatus0 * pOBJ_Measuring_Status_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Measuring_Status_0
*    OBJ_Measuring_Status_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Measuring_Status_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Measuring_Status_0( uint8 objIndx_u8, COREOBJvOOBJMeasuringStatus0 * pOBJ_Measuring_Status_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Object_Class_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJObjectClass0 * pOBJ_Object_Class_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Object_Class_0
*    OBJ_Object_Class_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Object_Class_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Object_Class_0( uint8 objIndx_u8, COREOBJvOOBJObjectClass0 * pOBJ_Object_Class_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_Reserved_4_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    boolean * pReserved_4_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_4_0
*    Reserved_4_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_4_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_Reserved_4_0( uint8 objIndx_u8, boolean * pReserved_4_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Class_Probability_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pOBJ_Class_Probability_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Class_Probability_0
*    OBJ_Class_Probability_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Class_Probability_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Class_Probability_0( uint8 objIndx_u8, uint8 * pOBJ_Class_Probability_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Car_Probability_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pOBJ_Car_Probability_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Car_Probability_0
*    OBJ_Car_Probability_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Car_Probability_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Car_Probability_0( uint8 objIndx_u8, uint8 * pOBJ_Car_Probability_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Truck_Probability_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pOBJ_Truck_Probability_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Truck_Probability_0
*    OBJ_Truck_Probability_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Truck_Probability_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Truck_Probability_0( uint8 objIndx_u8, uint8 * pOBJ_Truck_Probability_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Bike_Probability_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pOBJ_Bike_Probability_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Bike_Probability_0
*    OBJ_Bike_Probability_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Bike_Probability_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Bike_Probability_0( uint8 objIndx_u8, uint8 * pOBJ_Bike_Probability_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Camera_Source_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJCameraSource0 * pOBJ_Camera_Source_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Camera_Source_0
*    OBJ_Camera_Source_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Camera_Source_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Camera_Source_0( uint8 objIndx_u8, COREOBJvOOBJCameraSource0 * pOBJ_Camera_Source_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Motion_Status_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJMotionStatus0 * pOBJ_Motion_Status_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Motion_Status_0
*    OBJ_Motion_Status_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Motion_Status_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Motion_Status_0( uint8 objIndx_u8, COREOBJvOOBJMotionStatus0 * pOBJ_Motion_Status_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Motion_Orientation_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJMotionOrientation0 * pOBJ_Motion_Orientation_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Motion_Orientation_0
*    OBJ_Motion_Orientation_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Motion_Orientation_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Motion_Orientation_0( uint8 objIndx_u8, COREOBJvOOBJMotionOrientation0 * pOBJ_Motion_Orientation_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Has_Cut_Lane_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJHasCutLane0 * pOBJ_Has_Cut_Lane_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Has_Cut_Lane_0
*    OBJ_Has_Cut_Lane_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Has_Cut_Lane_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Has_Cut_Lane_0( uint8 objIndx_u8, COREOBJvOOBJHasCutLane0 * pOBJ_Has_Cut_Lane_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Has_Cut_Path_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJHasCutPath0 * pOBJ_Has_Cut_Path_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Has_Cut_Path_0
*    OBJ_Has_Cut_Path_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Has_Cut_Path_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Has_Cut_Path_0( uint8 objIndx_u8, COREOBJvOOBJHasCutPath0 * pOBJ_Has_Cut_Path_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Brake_Light_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJBrakeLight0 * pOBJ_Brake_Light_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Brake_Light_0
*    OBJ_Brake_Light_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Brake_Light_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Brake_Light_0( uint8 objIndx_u8, COREOBJvOOBJBrakeLight0 * pOBJ_Brake_Light_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Turn_Indicator_Right_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJTurnIndicatorRight0 * pOBJ_Turn_Indicator_Right_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Turn_Indicator_Right_0
*    OBJ_Turn_Indicator_Right_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Turn_Indicator_Right_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Turn_Indicator_Right_0( uint8 objIndx_u8, COREOBJvOOBJTurnIndicatorRight0 * pOBJ_Turn_Indicator_Right_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Turn_Indicator_Left_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJTurnIndicatorLeft0 * pOBJ_Turn_Indicator_Left_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Turn_Indicator_Left_0
*    OBJ_Turn_Indicator_Left_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Turn_Indicator_Left_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Turn_Indicator_Left_0( uint8 objIndx_u8, COREOBJvOOBJTurnIndicatorLeft0 * pOBJ_Turn_Indicator_Left_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Light_Indicator_Validity_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJLightIndicatorValidity0 * pOBJ_Light_Indicator_Validity_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Light_Indicator_Validity_0
*    OBJ_Light_Indicator_Validity_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Light_Indicator_Validity_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Light_Indicator_Validity_0( uint8 objIndx_u8, COREOBJvOOBJLightIndicatorValidity0 * pOBJ_Light_Indicator_Validity_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Right_Out_Of_Image_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJRightOutOfImage0 * pOBJ_Right_Out_Of_Image_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Right_Out_Of_Image_0
*    OBJ_Right_Out_Of_Image_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Right_Out_Of_Image_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Right_Out_Of_Image_0( uint8 objIndx_u8, COREOBJvOOBJRightOutOfImage0 * pOBJ_Right_Out_Of_Image_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Left_Out_Of_Image_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJLeftOutOfImage0 * pOBJ_Left_Out_Of_Image_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Left_Out_Of_Image_0
*    OBJ_Left_Out_Of_Image_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Left_Out_Of_Image_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Left_Out_Of_Image_0( uint8 objIndx_u8, COREOBJvOOBJLeftOutOfImage0 * pOBJ_Left_Out_Of_Image_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Right_Out_Of_Image_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJRightOutOfImageV0 * pOBJ_Right_Out_Of_Image_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Right_Out_Of_Image_V_0
*    OBJ_Right_Out_Of_Image_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Right_Out_Of_Image_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Right_Out_Of_Image_V_0( uint8 objIndx_u8, COREOBJvOOBJRightOutOfImageV0 * pOBJ_Right_Out_Of_Image_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Left_Out_Of_Image_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJLeftOutOfImageV0 * pOBJ_Left_Out_Of_Image_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Left_Out_Of_Image_V_0
*    OBJ_Left_Out_Of_Image_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Left_Out_Of_Image_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Left_Out_Of_Image_V_0( uint8 objIndx_u8, COREOBJvOOBJLeftOutOfImageV0 * pOBJ_Left_Out_Of_Image_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Top_Out_Of_Image_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJTopOutOfImage0 * pOBJ_Top_Out_Of_Image_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Top_Out_Of_Image_0
*    OBJ_Top_Out_Of_Image_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Top_Out_Of_Image_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Top_Out_Of_Image_0( uint8 objIndx_u8, COREOBJvOOBJTopOutOfImage0 * pOBJ_Top_Out_Of_Image_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Bottom_Out_Of_Image_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJBottomOutOfImage0 * pOBJ_Bottom_Out_Of_Image_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Bottom_Out_Of_Image_0
*    OBJ_Bottom_Out_Of_Image_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Bottom_Out_Of_Image_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Bottom_Out_Of_Image_0( uint8 objIndx_u8, COREOBJvOOBJBottomOutOfImage0 * pOBJ_Bottom_Out_Of_Image_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Top_Out_Of_Image_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJTopOutOfImageV0 * pOBJ_Top_Out_Of_Image_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Top_Out_Of_Image_V_0
*    OBJ_Top_Out_Of_Image_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Top_Out_Of_Image_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Top_Out_Of_Image_V_0( uint8 objIndx_u8, COREOBJvOOBJTopOutOfImageV0 * pOBJ_Top_Out_Of_Image_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Bottom_Out_Of_Image_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJBottomOutOfImageV0 * pOBJ_Bottom_Out_Of_Image_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Bottom_Out_Of_Image_V_0
*    OBJ_Bottom_Out_Of_Image_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Bottom_Out_Of_Image_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Bottom_Out_Of_Image_V_0( uint8 objIndx_u8, COREOBJvOOBJBottomOutOfImageV0 * pOBJ_Bottom_Out_Of_Image_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Lane_Assignment_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJLaneAssignment0 * pOBJ_Lane_Assignment_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Lane_Assignment_0
*    OBJ_Lane_Assignment_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Lane_Assignment_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Lane_Assignment_0( uint8 objIndx_u8, COREOBJvOOBJLaneAssignment0 * pOBJ_Lane_Assignment_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Lane_Assignment_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJLaneAssignmentV0 * pOBJ_Lane_Assignment_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Lane_Assignment_V_0
*    OBJ_Lane_Assignment_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Lane_Assignment_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Lane_Assignment_V_0( uint8 objIndx_u8, COREOBJvOOBJLaneAssignmentV0 * pOBJ_Lane_Assignment_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Age_Seconds_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pOBJ_Age_Seconds_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Age_Seconds_0
*    OBJ_Age_Seconds_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Age_Seconds_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Age_Seconds_0( uint8 objIndx_u8, uint8 * pOBJ_Age_Seconds_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Age_Seconds_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAgeSecondsV0 * pOBJ_Age_Seconds_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Age_Seconds_V_0
*    OBJ_Age_Seconds_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Age_Seconds_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Age_Seconds_V_0( uint8 objIndx_u8, COREOBJvOOBJAgeSecondsV0 * pOBJ_Age_Seconds_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Width_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Width_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Width_0
*    OBJ_Width_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Width_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Width_0( uint8 objIndx_u8, uint16 * pOBJ_Width_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Width_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJWidthV0 * pOBJ_Width_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Width_V_0
*    OBJ_Width_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Width_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Width_V_0( uint8 objIndx_u8, COREOBJvOOBJWidthV0 * pOBJ_Width_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Width_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Width_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Width_STD_0
*    OBJ_Width_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Width_STD_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Width_STD_0( uint8 objIndx_u8, uint16 * pOBJ_Width_STD_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Width_STD_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJWidthSTDV0 * pOBJ_Width_STD_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Width_STD_V_0
*    OBJ_Width_STD_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Width_STD_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Width_STD_V_0( uint8 objIndx_u8, COREOBJvOOBJWidthSTDV0 * pOBJ_Width_STD_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Length_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Length_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Length_0
*    OBJ_Length_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Length_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Length_0( uint8 objIndx_u8, uint16 * pOBJ_Length_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Length_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJLengthV0 * pOBJ_Length_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Length_V_0
*    OBJ_Length_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Length_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Length_V_0( uint8 objIndx_u8, COREOBJvOOBJLengthV0 * pOBJ_Length_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Length_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Length_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Length_STD_0
*    OBJ_Length_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Length_STD_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Length_STD_0( uint8 objIndx_u8, uint16 * pOBJ_Length_STD_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Length_STD_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJLengthSTDV0 * pOBJ_Length_STD_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Length_STD_V_0
*    OBJ_Length_STD_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Length_STD_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Length_STD_V_0( uint8 objIndx_u8, COREOBJvOOBJLengthSTDV0 * pOBJ_Length_STD_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Radar_ID_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pOBJ_Radar_ID_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Radar_ID_0
*    OBJ_Radar_ID_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Radar_ID_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Radar_ID_0( uint8 objIndx_u8, uint8 * pOBJ_Radar_ID_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Height_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Height_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Height_0
*    OBJ_Height_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Height_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Height_0( uint8 objIndx_u8, uint16 * pOBJ_Height_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Height_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJHeightV0 * pOBJ_Height_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Height_V_0
*    OBJ_Height_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Height_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Height_V_0( uint8 objIndx_u8, COREOBJvOOBJHeightV0 * pOBJ_Height_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_Reserved_5_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_5_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_5_0
*    Reserved_5_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_5_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_Reserved_5_0( uint8 objIndx_u8, uint8 * pReserved_5_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Height_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Height_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Height_STD_0
*    OBJ_Height_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Height_STD_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Height_STD_0( uint8 objIndx_u8, uint16 * pOBJ_Height_STD_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Height_STD_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJHeightSTDV0 * pOBJ_Height_STD_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Height_STD_V_0
*    OBJ_Height_STD_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Height_STD_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Height_STD_V_0( uint8 objIndx_u8, COREOBJvOOBJHeightSTDV0 * pOBJ_Height_STD_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Abs_Long_Velocity_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Abs_Long_Velocity_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Abs_Long_Velocity_0
*    OBJ_Abs_Long_Velocity_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Abs_Long_Velocity_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Abs_Long_Velocity_0( uint8 objIndx_u8, uint16 * pOBJ_Abs_Long_Velocity_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Abs_Long_Velocity_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAbsLongVelocityV0 * pOBJ_Abs_Long_Velocity_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Abs_Long_Velocity_V_0
*    OBJ_Abs_Long_Velocity_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Abs_Long_Velocity_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Abs_Long_Velocity_V_0( uint8 objIndx_u8, COREOBJvOOBJAbsLongVelocityV0 * pOBJ_Abs_Long_Velocity_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_Reserved_6_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_6_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_6_0
*    Reserved_6_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_6_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_Reserved_6_0( uint8 objIndx_u8, uint8 * pReserved_6_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Abs_Long_Velocity_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Abs_Long_Velocity_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Abs_Long_Velocity_STD_0
*    OBJ_Abs_Long_Velocity_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Abs_Long_Velocity_STD_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Abs_Long_Velocity_STD_0( uint8 objIndx_u8, uint16 * pOBJ_Abs_Long_Velocity_STD_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Abs_Long_Vel_STD_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAbsLongVelSTDV0 * pOBJ_Abs_Long_Vel_STD_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Abs_Long_Vel_STD_V_0
*    OBJ_Abs_Long_Vel_STD_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Abs_Long_Vel_STD_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Abs_Long_Vel_STD_V_0( uint8 objIndx_u8, COREOBJvOOBJAbsLongVelSTDV0 * pOBJ_Abs_Long_Vel_STD_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Abs_Lat_Velocity_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Abs_Lat_Velocity_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Abs_Lat_Velocity_0
*    OBJ_Abs_Lat_Velocity_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Abs_Lat_Velocity_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Abs_Lat_Velocity_0( uint8 objIndx_u8, uint16 * pOBJ_Abs_Lat_Velocity_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Abs_Lat_Velocity_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAbsLatVelocityV0 * pOBJ_Abs_Lat_Velocity_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Abs_Lat_Velocity_V_0
*    OBJ_Abs_Lat_Velocity_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Abs_Lat_Velocity_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Abs_Lat_Velocity_V_0( uint8 objIndx_u8, COREOBJvOOBJAbsLatVelocityV0 * pOBJ_Abs_Lat_Velocity_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_Reserved_7_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_7_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_7_0
*    Reserved_7_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_7_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_Reserved_7_0( uint8 objIndx_u8, uint8 * pReserved_7_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Abs_Lat_Velocity_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Abs_Lat_Velocity_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Abs_Lat_Velocity_STD_0
*    OBJ_Abs_Lat_Velocity_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Abs_Lat_Velocity_STD_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Abs_Lat_Velocity_STD_0( uint8 objIndx_u8, uint16 * pOBJ_Abs_Lat_Velocity_STD_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Abs_Lat_Vel_STD_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAbsLatVelSTDV0 * pOBJ_Abs_Lat_Vel_STD_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Abs_Lat_Vel_STD_V_0
*    OBJ_Abs_Lat_Vel_STD_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Abs_Lat_Vel_STD_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Abs_Lat_Vel_STD_V_0( uint8 objIndx_u8, COREOBJvOOBJAbsLatVelSTDV0 * pOBJ_Abs_Lat_Vel_STD_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Abs_Long_Acc_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Abs_Long_Acc_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Abs_Long_Acc_0
*    OBJ_Abs_Long_Acc_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Abs_Long_Acc_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Abs_Long_Acc_0( uint8 objIndx_u8, uint16 * pOBJ_Abs_Long_Acc_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Abs_Long_Acc_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAbsLongAccV0 * pOBJ_Abs_Long_Acc_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Abs_Long_Acc_V_0
*    OBJ_Abs_Long_Acc_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Abs_Long_Acc_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Abs_Long_Acc_V_0( uint8 objIndx_u8, COREOBJvOOBJAbsLongAccV0 * pOBJ_Abs_Long_Acc_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_Reserved_8_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_8_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_8_0
*    Reserved_8_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_8_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_Reserved_8_0( uint8 objIndx_u8, uint8 * pReserved_8_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Abs_Long_Acc_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Abs_Long_Acc_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Abs_Long_Acc_STD_0
*    OBJ_Abs_Long_Acc_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Abs_Long_Acc_STD_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Abs_Long_Acc_STD_0( uint8 objIndx_u8, uint16 * pOBJ_Abs_Long_Acc_STD_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Abs_Long_Acc_STD_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAbsLongAccSTDV0 * pOBJ_Abs_Long_Acc_STD_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Abs_Long_Acc_STD_V_0
*    OBJ_Abs_Long_Acc_STD_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Abs_Long_Acc_STD_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Abs_Long_Acc_STD_V_0( uint8 objIndx_u8, COREOBJvOOBJAbsLongAccSTDV0 * pOBJ_Abs_Long_Acc_STD_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Abs_Lat_Acc_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Abs_Lat_Acc_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Abs_Lat_Acc_0
*    OBJ_Abs_Lat_Acc_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Abs_Lat_Acc_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Abs_Lat_Acc_0( uint8 objIndx_u8, uint16 * pOBJ_Abs_Lat_Acc_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Abs_Lat_Acc_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAbsLatAccV0 * pOBJ_Abs_Lat_Acc_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Abs_Lat_Acc_V_0
*    OBJ_Abs_Lat_Acc_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Abs_Lat_Acc_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Abs_Lat_Acc_V_0( uint8 objIndx_u8, COREOBJvOOBJAbsLatAccV0 * pOBJ_Abs_Lat_Acc_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Abs_Lat_Acc_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Abs_Lat_Acc_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Abs_Lat_Acc_STD_0
*    OBJ_Abs_Lat_Acc_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Abs_Lat_Acc_STD_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Abs_Lat_Acc_STD_0( uint8 objIndx_u8, uint16 * pOBJ_Abs_Lat_Acc_STD_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Abs_Lat_Acc_STD_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAbsLatAccSTDV0 * pOBJ_Abs_Lat_Acc_STD_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Abs_Lat_Acc_STD_V_0
*    OBJ_Abs_Lat_Acc_STD_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Abs_Lat_Acc_STD_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Abs_Lat_Acc_STD_V_0( uint8 objIndx_u8, COREOBJvOOBJAbsLatAccSTDV0 * pOBJ_Abs_Lat_Acc_STD_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Abs_Acceleration_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Abs_Acceleration_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Abs_Acceleration_0
*    OBJ_Abs_Acceleration_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Abs_Acceleration_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Abs_Acceleration_0( uint8 objIndx_u8, uint16 * pOBJ_Abs_Acceleration_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Abs_Acceleration_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAbsAccelerationV0 * pOBJ_Abs_Acceleration_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Abs_Acceleration_V_0
*    OBJ_Abs_Acceleration_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Abs_Acceleration_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Abs_Acceleration_V_0( uint8 objIndx_u8, COREOBJvOOBJAbsAccelerationV0 * pOBJ_Abs_Acceleration_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Abs_Acc_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Abs_Acc_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Abs_Acc_STD_0
*    OBJ_Abs_Acc_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Abs_Acc_STD_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Abs_Acc_STD_0( uint8 objIndx_u8, uint16 * pOBJ_Abs_Acc_STD_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Abs_Acc_STD_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAbsAccSTDV0 * pOBJ_Abs_Acc_STD_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Abs_Acc_STD_V_0
*    OBJ_Abs_Acc_STD_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Abs_Acc_STD_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Abs_Acc_STD_V_0( uint8 objIndx_u8, COREOBJvOOBJAbsAccSTDV0 * pOBJ_Abs_Acc_STD_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Inv_TTC_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Inv_TTC_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Inv_TTC_0
*    OBJ_Inv_TTC_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Inv_TTC_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Inv_TTC_0( uint8 objIndx_u8, uint16 * pOBJ_Inv_TTC_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Inv_TTC_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJInvTTCV0 * pOBJ_Inv_TTC_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Inv_TTC_V_0
*    OBJ_Inv_TTC_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Inv_TTC_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Inv_TTC_V_0( uint8 objIndx_u8, COREOBJvOOBJInvTTCV0 * pOBJ_Inv_TTC_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Inv_TTC_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Inv_TTC_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Inv_TTC_STD_0
*    OBJ_Inv_TTC_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Inv_TTC_STD_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Inv_TTC_STD_0( uint8 objIndx_u8, uint16 * pOBJ_Inv_TTC_STD_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Inv_TTC_STD_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJInvTTCSTDV0 * pOBJ_Inv_TTC_STD_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Inv_TTC_STD_V_0
*    OBJ_Inv_TTC_STD_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Inv_TTC_STD_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Inv_TTC_STD_V_0( uint8 objIndx_u8, COREOBJvOOBJInvTTCSTDV0 * pOBJ_Inv_TTC_STD_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Relative_Long_Acc_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Relative_Long_Acc_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Relative_Long_Acc_0
*    OBJ_Relative_Long_Acc_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Relative_Long_Acc_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Relative_Long_Acc_0( uint8 objIndx_u8, uint16 * pOBJ_Relative_Long_Acc_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Relative_Long_Acc_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJRelativeLongAccV0 * pOBJ_Relative_Long_Acc_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Relative_Long_Acc_V_0
*    OBJ_Relative_Long_Acc_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Relative_Long_Acc_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Relative_Long_Acc_V_0( uint8 objIndx_u8, COREOBJvOOBJRelativeLongAccV0 * pOBJ_Relative_Long_Acc_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_Reserved_9_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_9_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_9_0
*    Reserved_9_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_9_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_Reserved_9_0( uint8 objIndx_u8, uint8 * pReserved_9_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Relative_Long_Acc_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Relative_Long_Acc_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Relative_Long_Acc_STD_0
*    OBJ_Relative_Long_Acc_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Relative_Long_Acc_STD_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Relative_Long_Acc_STD_0( uint8 objIndx_u8, uint16 * pOBJ_Relative_Long_Acc_STD_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Rel_Long_Acc_STD_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJRelLongAccSTDV0 * pOBJ_Rel_Long_Acc_STD_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Rel_Long_Acc_STD_V_0
*    OBJ_Rel_Long_Acc_STD_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Rel_Long_Acc_STD_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Rel_Long_Acc_STD_V_0( uint8 objIndx_u8, COREOBJvOOBJRelLongAccSTDV0 * pOBJ_Rel_Long_Acc_STD_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Relative_Long_Velocity_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Relative_Long_Velocity_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Relative_Long_Velocity_0
*    OBJ_Relative_Long_Velocity_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Relative_Long_Velocity_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Relative_Long_Velocity_0( uint8 objIndx_u8, uint16 * pOBJ_Relative_Long_Velocity_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Relative_Long_Velocity_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJRelativeLongVelocityV0 * pOBJ_Relative_Long_Velocity_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Relative_Long_Velocity_V_0
*    OBJ_Relative_Long_Velocity_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Relative_Long_Velocity_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Relative_Long_Velocity_V_0( uint8 objIndx_u8, COREOBJvOOBJRelativeLongVelocityV0 * pOBJ_Relative_Long_Velocity_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_Reserved_10_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_10_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_10_0
*    Reserved_10_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_10_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_Reserved_10_0( uint8 objIndx_u8, uint8 * pReserved_10_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Relative_Long_Vel_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Relative_Long_Vel_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Relative_Long_Vel_STD_0
*    OBJ_Relative_Long_Vel_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Relative_Long_Vel_STD_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Relative_Long_Vel_STD_0( uint8 objIndx_u8, uint16 * pOBJ_Relative_Long_Vel_STD_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Rel_Long_Vel_STD_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJRelLongVelSTDV0 * pOBJ_Rel_Long_Vel_STD_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Rel_Long_Vel_STD_V_0
*    OBJ_Rel_Long_Vel_STD_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Rel_Long_Vel_STD_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Rel_Long_Vel_STD_V_0( uint8 objIndx_u8, COREOBJvOOBJRelLongVelSTDV0 * pOBJ_Rel_Long_Vel_STD_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Relative_Lat_Velocity_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Relative_Lat_Velocity_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Relative_Lat_Velocity_0
*    OBJ_Relative_Lat_Velocity_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Relative_Lat_Velocity_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Relative_Lat_Velocity_0( uint8 objIndx_u8, uint16 * pOBJ_Relative_Lat_Velocity_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Relative_Lat_Velocity_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJRelativeLatVelocityV0 * pOBJ_Relative_Lat_Velocity_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Relative_Lat_Velocity_V_0
*    OBJ_Relative_Lat_Velocity_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Relative_Lat_Velocity_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Relative_Lat_Velocity_V_0( uint8 objIndx_u8, COREOBJvOOBJRelativeLatVelocityV0 * pOBJ_Relative_Lat_Velocity_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_Reserved_11_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_11_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_11_0
*    Reserved_11_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_11_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_Reserved_11_0( uint8 objIndx_u8, uint8 * pReserved_11_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Relative_Lat_Velocity_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Relative_Lat_Velocity_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Relative_Lat_Velocity_STD_0
*    OBJ_Relative_Lat_Velocity_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Relative_Lat_Velocity_STD_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Relative_Lat_Velocity_STD_0( uint8 objIndx_u8, uint16 * pOBJ_Relative_Lat_Velocity_STD_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Rel_Lat_Vel_STD_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJRelLatVelSTDV0 * pOBJ_Rel_Lat_Vel_STD_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Rel_Lat_Vel_STD_V_0
*    OBJ_Rel_Lat_Vel_STD_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Rel_Lat_Vel_STD_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Rel_Lat_Vel_STD_V_0( uint8 objIndx_u8, COREOBJvOOBJRelLatVelSTDV0 * pOBJ_Rel_Lat_Vel_STD_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Long_Distance_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Long_Distance_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Long_Distance_0
*    OBJ_Long_Distance_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Long_Distance_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Long_Distance_0( uint8 objIndx_u8, uint16 * pOBJ_Long_Distance_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Long_Distance_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJLongDistanceV0 * pOBJ_Long_Distance_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Long_Distance_V_0
*    OBJ_Long_Distance_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Long_Distance_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Long_Distance_V_0( uint8 objIndx_u8, COREOBJvOOBJLongDistanceV0 * pOBJ_Long_Distance_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_Reserved_12_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_12_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_12_0
*    Reserved_12_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_12_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_Reserved_12_0( uint8 objIndx_u8, uint8 * pReserved_12_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Long_Distance_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Long_Distance_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Long_Distance_STD_0
*    OBJ_Long_Distance_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Long_Distance_STD_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Long_Distance_STD_0( uint8 objIndx_u8, uint16 * pOBJ_Long_Distance_STD_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Long_Distance_STD_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJLongDistanceSTDV0 * pOBJ_Long_Distance_STD_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Long_Distance_STD_V_0
*    OBJ_Long_Distance_STD_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Long_Distance_STD_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Long_Distance_STD_V_0( uint8 objIndx_u8, COREOBJvOOBJLongDistanceSTDV0 * pOBJ_Long_Distance_STD_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Lat_Distance_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Lat_Distance_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Lat_Distance_0
*    OBJ_Lat_Distance_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Lat_Distance_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Lat_Distance_0( uint8 objIndx_u8, uint16 * pOBJ_Lat_Distance_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Lat_Distance_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJLatDistanceV0 * pOBJ_Lat_Distance_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Lat_Distance_V_0
*    OBJ_Lat_Distance_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Lat_Distance_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Lat_Distance_V_0( uint8 objIndx_u8, COREOBJvOOBJLatDistanceV0 * pOBJ_Lat_Distance_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_Reserved_13_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_13_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_13_0
*    Reserved_13_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_13_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_Reserved_13_0( uint8 objIndx_u8, uint8 * pReserved_13_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Lat_Distance_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Lat_Distance_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Lat_Distance_STD_0
*    OBJ_Lat_Distance_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Lat_Distance_STD_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Lat_Distance_STD_0( uint8 objIndx_u8, uint16 * pOBJ_Lat_Distance_STD_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Lat_Distance_STD_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJLatDistanceSTDV0 * pOBJ_Lat_Distance_STD_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Lat_Distance_STD_V_0
*    OBJ_Lat_Distance_STD_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Lat_Distance_STD_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Lat_Distance_STD_V_0( uint8 objIndx_u8, COREOBJvOOBJLatDistanceSTDV0 * pOBJ_Lat_Distance_STD_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Absolute_Speed_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Absolute_Speed_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Absolute_Speed_0
*    OBJ_Absolute_Speed_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Absolute_Speed_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Absolute_Speed_0( uint8 objIndx_u8, uint16 * pOBJ_Absolute_Speed_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Absolute_Speed_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAbsoluteSpeedV0 * pOBJ_Absolute_Speed_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Absolute_Speed_V_0
*    OBJ_Absolute_Speed_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Absolute_Speed_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Absolute_Speed_V_0( uint8 objIndx_u8, COREOBJvOOBJAbsoluteSpeedV0 * pOBJ_Absolute_Speed_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_Reserved_14_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_14_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_14_0
*    Reserved_14_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_14_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_Reserved_14_0( uint8 objIndx_u8, uint8 * pReserved_14_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Absolute_Speed_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Absolute_Speed_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Absolute_Speed_STD_0
*    OBJ_Absolute_Speed_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Absolute_Speed_STD_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Absolute_Speed_STD_0( uint8 objIndx_u8, uint16 * pOBJ_Absolute_Speed_STD_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Absolute_Speed_STD_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAbsoluteSpeedSTDV0 * pOBJ_Absolute_Speed_STD_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Absolute_Speed_STD_V_0
*    OBJ_Absolute_Speed_STD_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Absolute_Speed_STD_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Absolute_Speed_STD_V_0( uint8 objIndx_u8, COREOBJvOOBJAbsoluteSpeedSTDV0 * pOBJ_Absolute_Speed_STD_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Heading_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Heading_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Heading_0
*    OBJ_Heading_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Heading_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Heading_0( uint8 objIndx_u8, uint16 * pOBJ_Heading_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Heading_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJHeadingV0 * pOBJ_Heading_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Heading_V_0
*    OBJ_Heading_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Heading_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Heading_V_0( uint8 objIndx_u8, COREOBJvOOBJHeadingV0 * pOBJ_Heading_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_Reserved_15_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_15_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_15_0
*    Reserved_15_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_15_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_Reserved_15_0( uint8 objIndx_u8, uint8 * pReserved_15_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Heading_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Heading_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Heading_STD_0
*    OBJ_Heading_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Heading_STD_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Heading_STD_0( uint8 objIndx_u8, uint16 * pOBJ_Heading_STD_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Heading_STD_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJHeadingSTDV0 * pOBJ_Heading_STD_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Heading_STD_V_0
*    OBJ_Heading_STD_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Heading_STD_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Heading_STD_V_0( uint8 objIndx_u8, COREOBJvOOBJHeadingSTDV0 * pOBJ_Heading_STD_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Rate_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Angle_Rate_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Rate_STD_0
*    OBJ_Angle_Rate_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Rate_STD_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Rate_STD_0( uint8 objIndx_u8, uint16 * pOBJ_Angle_Rate_STD_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Rate_STD_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAngleRateSTDV0 * pOBJ_Angle_Rate_STD_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Rate_STD_V_0
*    OBJ_Angle_Rate_STD_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Rate_STD_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Rate_STD_V_0( uint8 objIndx_u8, COREOBJvOOBJAngleRateSTDV0 * pOBJ_Angle_Rate_STD_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Rate_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Angle_Rate_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Rate_0
*    OBJ_Angle_Rate_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Rate_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Rate_0( uint8 objIndx_u8, uint16 * pOBJ_Angle_Rate_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Rate_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAngleRateV0 * pOBJ_Angle_Rate_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Rate_V_0
*    OBJ_Angle_Rate_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Rate_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Rate_V_0( uint8 objIndx_u8, COREOBJvOOBJAngleRateV0 * pOBJ_Angle_Rate_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Right_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Angle_Right_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Right_0
*    OBJ_Angle_Right_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Right_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Right_0( uint8 objIndx_u8, uint16 * pOBJ_Angle_Right_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Right_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAngleRightV0 * pOBJ_Angle_Right_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Right_V_0
*    OBJ_Angle_Right_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Right_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Right_V_0( uint8 objIndx_u8, COREOBJvOOBJAngleRightV0 * pOBJ_Angle_Right_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_Reserved_16_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_16_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_16_0
*    Reserved_16_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_16_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_Reserved_16_0( uint8 objIndx_u8, uint8 * pReserved_16_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Right_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Angle_Right_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Right_STD_0
*    OBJ_Angle_Right_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Right_STD_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Right_STD_0( uint8 objIndx_u8, uint16 * pOBJ_Angle_Right_STD_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Right_STD_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAngleRightSTDV0 * pOBJ_Angle_Right_STD_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Right_STD_V_0
*    OBJ_Angle_Right_STD_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Right_STD_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Right_STD_V_0( uint8 objIndx_u8, COREOBJvOOBJAngleRightSTDV0 * pOBJ_Angle_Right_STD_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Left_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Angle_Left_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Left_0
*    OBJ_Angle_Left_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Left_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Left_0( uint8 objIndx_u8, uint16 * pOBJ_Angle_Left_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Left_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAngleLeftV0 * pOBJ_Angle_Left_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Left_V_0
*    OBJ_Angle_Left_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Left_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Left_V_0( uint8 objIndx_u8, COREOBJvOOBJAngleLeftV0 * pOBJ_Angle_Left_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_Reserved_17_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_17_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_17_0
*    Reserved_17_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_17_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_Reserved_17_0( uint8 objIndx_u8, uint8 * pReserved_17_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Left_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Angle_Left_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Left_STD_0
*    OBJ_Angle_Left_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Left_STD_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Left_STD_0( uint8 objIndx_u8, uint16 * pOBJ_Angle_Left_STD_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Left_STD_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAngleLeftSTDV0 * pOBJ_Angle_Left_STD_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Left_STD_V_0
*    OBJ_Angle_Left_STD_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Left_STD_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Left_STD_V_0( uint8 objIndx_u8, COREOBJvOOBJAngleLeftSTDV0 * pOBJ_Angle_Left_STD_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Side_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Angle_Side_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Side_0
*    OBJ_Angle_Side_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Side_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Side_0( uint8 objIndx_u8, uint16 * pOBJ_Angle_Side_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Side_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAngleSideV0 * pOBJ_Angle_Side_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Side_V_0
*    OBJ_Angle_Side_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Side_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Side_V_0( uint8 objIndx_u8, COREOBJvOOBJAngleSideV0 * pOBJ_Angle_Side_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_Reserved_18_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_18_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_18_0
*    Reserved_18_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_18_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_Reserved_18_0( uint8 objIndx_u8, uint8 * pReserved_18_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Side_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Angle_Side_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Side_STD_0
*    OBJ_Angle_Side_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Side_STD_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Side_STD_0( uint8 objIndx_u8, uint16 * pOBJ_Angle_Side_STD_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Side_STD_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAngleSideSTDV0 * pOBJ_Angle_Side_STD_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Side_STD_V_0
*    OBJ_Angle_Side_STD_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Side_STD_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Side_STD_V_0( uint8 objIndx_u8, COREOBJvOOBJAngleSideSTDV0 * pOBJ_Angle_Side_STD_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Mid_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAngleMidV0 * pOBJ_Angle_Mid_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Mid_V_0
*    OBJ_Angle_Mid_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Mid_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Mid_V_0( uint8 objIndx_u8, COREOBJvOOBJAngleMidV0 * pOBJ_Angle_Mid_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Mid_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Angle_Mid_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Mid_0
*    OBJ_Angle_Mid_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Mid_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Mid_0( uint8 objIndx_u8, uint16 * pOBJ_Angle_Mid_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_Reserved_19_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_19_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_19_0
*    Reserved_19_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_19_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_Reserved_19_0( uint8 objIndx_u8, uint8 * pReserved_19_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Mid_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Angle_Mid_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Mid_STD_0
*    OBJ_Angle_Mid_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Mid_STD_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Mid_STD_0( uint8 objIndx_u8, uint16 * pOBJ_Angle_Mid_STD_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Mid_STD_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAngleMidSTDV0 * pOBJ_Angle_Mid_STD_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Mid_STD_V_0
*    OBJ_Angle_Mid_STD_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Mid_STD_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Mid_STD_V_0( uint8 objIndx_u8, COREOBJvOOBJAngleMidSTDV0 * pOBJ_Angle_Mid_STD_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Bottom_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAngleBottomV0 * pOBJ_Angle_Bottom_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Bottom_V_0
*    OBJ_Angle_Bottom_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Bottom_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Bottom_V_0( uint8 objIndx_u8, COREOBJvOOBJAngleBottomV0 * pOBJ_Angle_Bottom_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Bottom_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Angle_Bottom_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Bottom_0
*    OBJ_Angle_Bottom_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Bottom_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Bottom_0( uint8 objIndx_u8, uint16 * pOBJ_Angle_Bottom_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_Reserved_20_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_20_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_20_0
*    Reserved_20_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_20_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_Reserved_20_0( uint8 objIndx_u8, uint8 * pReserved_20_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Bottom_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Angle_Bottom_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Bottom_STD_0
*    OBJ_Angle_Bottom_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Bottom_STD_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Bottom_STD_0( uint8 objIndx_u8, uint16 * pOBJ_Angle_Bottom_STD_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Bottom_STD_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAngleBottomSTDV0 * pOBJ_Angle_Bottom_STD_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Bottom_STD_V_0
*    OBJ_Angle_Bottom_STD_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Bottom_STD_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Bottom_STD_V_0( uint8 objIndx_u8, COREOBJvOOBJAngleBottomSTDV0 * pOBJ_Angle_Bottom_STD_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Visibility_Side_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJVisibilitySideV0 * pOBJ_Visibility_Side_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Visibility_Side_V_0
*    OBJ_Visibility_Side_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Visibility_Side_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Visibility_Side_V_0( uint8 objIndx_u8, COREOBJvOOBJVisibilitySideV0 * pOBJ_Visibility_Side_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Visibility_Side_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJVisibilitySide0 * pOBJ_Visibility_Side_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Visibility_Side_0
*    OBJ_Visibility_Side_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Visibility_Side_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Visibility_Side_0( uint8 objIndx_u8, COREOBJvOOBJVisibilitySide0 * pOBJ_Visibility_Side_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Is_In_Drivable_Area_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJIsInDrivableArea0 * pOBJ_Is_In_Drivable_Area_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Is_In_Drivable_Area_0
*    OBJ_Is_In_Drivable_Area_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Is_In_Drivable_Area_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Is_In_Drivable_Area_0( uint8 objIndx_u8, COREOBJvOOBJIsInDrivableArea0 * pOBJ_Is_In_Drivable_Area_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Is_In_Drivable_Area_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJIsInDrivableAreaV0 * pOBJ_Is_In_Drivable_Area_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Is_In_Drivable_Area_V_0
*    OBJ_Is_In_Drivable_Area_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Is_In_Drivable_Area_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Is_In_Drivable_Area_V_0( uint8 objIndx_u8, COREOBJvOOBJIsInDrivableAreaV0 * pOBJ_Is_In_Drivable_Area_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Is_VeryClose_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJIsVeryCloseV0 * pOBJ_Is_VeryClose_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Is_VeryClose_V_0
*    OBJ_Is_VeryClose_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Is_VeryClose_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Is_VeryClose_V_0( uint8 objIndx_u8, COREOBJvOOBJIsVeryCloseV0 * pOBJ_Is_VeryClose_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Is_VeryClose_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJIsVeryClose0 * pOBJ_Is_VeryClose_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Is_VeryClose_0
*    OBJ_Is_VeryClose_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Is_VeryClose_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Is_VeryClose_0( uint8 objIndx_u8, COREOBJvOOBJIsVeryClose0 * pOBJ_Is_VeryClose_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Occlusion_RL_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJOcclusionRL0 * pOBJ_Occlusion_RL_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Occlusion_RL_0
*    OBJ_Occlusion_RL_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Occlusion_RL_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Occlusion_RL_0( uint8 objIndx_u8, COREOBJvOOBJOcclusionRL0 * pOBJ_Occlusion_RL_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Occlusion_RR_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJOcclusionRR0 * pOBJ_Occlusion_RR_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Occlusion_RR_0
*    OBJ_Occlusion_RR_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Occlusion_RR_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Occlusion_RR_0( uint8 objIndx_u8, COREOBJvOOBJOcclusionRR0 * pOBJ_Occlusion_RR_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Occlusion_FR_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJOcclusionFR0 * pOBJ_Occlusion_FR_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Occlusion_FR_0
*    OBJ_Occlusion_FR_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Occlusion_FR_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Occlusion_FR_0( uint8 objIndx_u8, COREOBJvOOBJOcclusionFR0 * pOBJ_Occlusion_FR_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Occlusion_FL_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJOcclusionFL0 * pOBJ_Occlusion_FL_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Occlusion_FL_0
*    OBJ_Occlusion_FL_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Occlusion_FL_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Occlusion_FL_0( uint8 objIndx_u8, COREOBJvOOBJOcclusionFL0 * pOBJ_Occlusion_FL_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_Reserved_21_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_21_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_21_0
*    Reserved_21_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_21_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_Reserved_21_0( uint8 objIndx_u8, uint8 * pReserved_21_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_OverlapAngleEgoLaneR_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_OverlapAngleEgoLaneR_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_OverlapAngleEgoLaneR_0
*    OBJ_OverlapAngleEgoLaneR_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_OverlapAngleEgoLaneR_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_OverlapAngleEgoLaneR_0( uint8 objIndx_u8, uint16 * pOBJ_OverlapAngleEgoLaneR_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_OverlapAngleEgoLaneL_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_OverlapAngleEgoLaneL_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_OverlapAngleEgoLaneL_0
*    OBJ_OverlapAngleEgoLaneL_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_OverlapAngleEgoLaneL_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_OverlapAngleEgoLaneL_0( uint8 objIndx_u8, uint16 * pOBJ_OverlapAngleEgoLaneL_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Is_EMERGENCY_VCL_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJIsEMERGENCYVCL0 * pOBJ_Is_EMERGENCY_VCL_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Is_EMERGENCY_VCL_0
*    OBJ_Is_EMERGENCY_VCL_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Is_EMERGENCY_VCL_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Is_EMERGENCY_VCL_0( uint8 objIndx_u8, COREOBJvOOBJIsEMERGENCYVCL0 * pOBJ_Is_EMERGENCY_VCL_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_EMERGENCY_LIGHT_COLOR_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJEMERGENCYLIGHTCOLOR0 * pOBJ_EMERGENCY_LIGHT_COLOR_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_EMERGENCY_LIGHT_COLOR_0
*    OBJ_EMERGENCY_LIGHT_COLOR_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_EMERGENCY_LIGHT_COLOR_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_EMERGENCY_LIGHT_COLOR_0( uint8 objIndx_u8, COREOBJvOOBJEMERGENCYLIGHTCOLOR0 * pOBJ_EMERGENCY_LIGHT_COLOR_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_EMERGENCY_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJEMERGENCYV0 * pOBJ_EMERGENCY_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_EMERGENCY_V_0
*    OBJ_EMERGENCY_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_EMERGENCY_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_EMERGENCY_V_0( uint8 objIndx_u8, COREOBJvOOBJEMERGENCYV0 * pOBJ_EMERGENCY_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_Reserved_22_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_22_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_22_0
*    Reserved_22_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_22_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_Reserved_22_0( uint8 objIndx_u8, uint8 * pReserved_22_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Top_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Angle_Top_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Top_0
*    OBJ_Angle_Top_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Top_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Top_0( uint8 objIndx_u8, uint16 * pOBJ_Angle_Top_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Top_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAngleTopV0 * pOBJ_Angle_Top_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Top_V_0
*    OBJ_Angle_Top_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Top_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Top_V_0( uint8 objIndx_u8, COREOBJvOOBJAngleTopV0 * pOBJ_Angle_Top_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Top_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Angle_Top_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Top_STD_0
*    OBJ_Angle_Top_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Top_STD_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Top_STD_0( uint8 objIndx_u8, uint16 * pOBJ_Angle_Top_STD_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Top_STD_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAngleTopSTDV0 * pOBJ_Angle_Top_STD_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Top_STD_V_0
*    OBJ_Angle_Top_STD_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Top_STD_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Top_STD_V_0( uint8 objIndx_u8, COREOBJvOOBJAngleTopSTDV0 * pOBJ_Angle_Top_STD_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Open_Door_Left_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJOpenDoorLeft0 * pOBJ_Open_Door_Left_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Open_Door_Left_0
*    OBJ_Open_Door_Left_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Open_Door_Left_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Open_Door_Left_0( uint8 objIndx_u8, COREOBJvOOBJOpenDoorLeft0 * pOBJ_Open_Door_Left_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Open_Door_Right_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJOpenDoorRight0 * pOBJ_Open_Door_Right_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Open_Door_Right_0
*    OBJ_Open_Door_Right_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Open_Door_Right_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Open_Door_Right_0( uint8 objIndx_u8, COREOBJvOOBJOpenDoorRight0 * pOBJ_Open_Door_Right_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Visible_Left_or_Right_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJVisibleLeftOrRight0 * pOBJ_Visible_Left_or_Right_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Visible_Left_or_Right_0
*    OBJ_Visible_Left_or_Right_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Visible_Left_or_Right_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Visible_Left_or_Right_0( uint8 objIndx_u8, COREOBJvOOBJVisibleLeftOrRight0 * pOBJ_Visible_Left_or_Right_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Visible_Left_or_Right_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJVisibleLeftOrRightV0 * pOBJ_Visible_Left_or_Right_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Visible_Left_or_Right_V_0
*    OBJ_Visible_Left_or_Right_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Visible_Left_or_Right_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Visible_Left_or_Right_V_0( uint8 objIndx_u8, COREOBJvOOBJVisibleLeftOrRightV0 * pOBJ_Visible_Left_or_Right_V_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_Reserved_23_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint32 * pReserved_23_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_23_0
*    Reserved_23_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_23_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_Reserved_23_0( uint8 objIndx_u8, uint32 * pReserved_23_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_COREOBJ_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_COREOBJ_Params_t * pCore_Objects_protocol - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_Objects_protocol message 
*    Core_Objects_protocol message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_Objects_protocol message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_COREOBJ_ParamsApp_MsgDataStruct( EYEQMSG_COREOBJ_Params_t * pCore_Objects_protocol );
/*****************************************************************************
                  Exported object declarations
*****************************************************************************/
extern EYEQMSG_COREOBJ_Params_t   EYEQMSG_COREOBJ_Params_s;
extern EYEQMSG_COREOBJ_Params_t   EYEQMSG_COREOBJ_ParamsApp_s;
/****************************************************************************/
#endif /* _EYEQMSG_COREOBJPROCESS_H_ */


