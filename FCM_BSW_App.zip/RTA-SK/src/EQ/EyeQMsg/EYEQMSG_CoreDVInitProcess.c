

/*****************************************************************************
                  Include files
*****************************************************************************/
/* The suggested include file order is: */
#include "EyeQ_defs.h"    /* EyeQ project common definitions file    */

#include "EYEQMSG_CoreDVInitProcess.h"

/*****************************************************************************
                  Local symbolic constants
*****************************************************************************/
/*****************************************************************************
                  Local types, enums definitions
*****************************************************************************/
/*****************************************************************************
                  Local function prototypes
*****************************************************************************/
/*****************************************************************************
                  Local object definitions
*****************************************************************************/
/*****************************************************************************
                  Exported object definitions
*****************************************************************************/
EYEQMSG_COREDVINIT_Params_t   EYEQMSG_COREDVINIT_Params_s;
EYEQMSG_COREDVINIT_Params_t   EYEQMSG_COREDVINIT_ParamsApp_s;
/*****************************************************************************
                  Local function-like macros
*****************************************************************************/
/*****************************************************************************
                  Local defined macros
*****************************************************************************/
/*****************************************************************************
                  Function definitions
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_COREDVINIT_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_COREDVINIT_Params_t * pCore_DV_Init - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_DV_Init message 
*    Core_DV_Init message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_DV_Init message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_COREDVINIT_ParamsApp_MsgDataStruct( EYEQMSG_COREDVINIT_Params_t * pCore_DV_Init )
{
   Std_ReturnType status = C_SIG_INVALID;
   if( pCore_DV_Init != C_NULL_P )
   {
      status = C_SIG_VALID;
      * pCore_DV_Init = EYEQMSG_COREDVINIT_ParamsApp_s;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREDVINIT_IDV_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pIDV_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IDV_Zero_byte
*    IDV_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IDV_Zero_byte signal value of Core_DV_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREDVINIT_IDV_Zero_byte( uint8 * pIDV_Zero_byte )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pIDV_Zero_byte != C_NULL_P )
   {
      signal_value = EYEQMSG_COREDVINIT_ParamsApp_s.IDV_Zero_byte_b8;
      * pIDV_Zero_byte = signal_value;
      if( signal_value <= C_EYEQMSG_COREDVINIT_IDV_ZERO_BYTE_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREDVINIT_IDV_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pIDV_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IDV_Protocol_Version
*    IDV_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IDV_Protocol_Version signal value of Core_DV_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREDVINIT_IDV_Protocol_Version( uint8 * pIDV_Protocol_Version )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pIDV_Protocol_Version != C_NULL_P )
   {
      signal_value = EYEQMSG_COREDVINIT_ParamsApp_s.IDV_Protocol_Version_b8;
      * pIDV_Protocol_Version = signal_value;
      if( (signal_value >= C_EYEQMSG_COREDVINIT_IDV_PROTOCOL_VERSION_RMIN ) 
          && (signal_value <= C_EYEQMSG_COREDVINIT_IDV_PROTOCOL_VERSION_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREDVINIT_IDV_Optional_Signals
*
* FUNCTION ARGUMENTS:
*    uint16 * pIDV_Optional_Signals - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IDV_Optional_Signals
*    IDV_Optional_Signals returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IDV_Optional_Signals signal value of Core_DV_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREDVINIT_IDV_Optional_Signals( uint16 * pIDV_Optional_Signals )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pIDV_Optional_Signals != C_NULL_P )
   {
      signal_value = EYEQMSG_COREDVINIT_ParamsApp_s.IDV_Optional_Signals_b16;
      * pIDV_Optional_Signals = signal_value;
      if( signal_value <= C_EYEQMSG_COREDVINIT_IDV_OPTIONAL_SIGNALS_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

