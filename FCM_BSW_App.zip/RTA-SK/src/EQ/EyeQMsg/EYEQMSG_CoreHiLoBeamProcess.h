#ifndef _EYEQMSG_COREHILOBEAMPROCESS_H_
#define _EYEQMSG_COREHILOBEAMPROCESS_H_

/*****************************************************************************
                  Included header files
*****************************************************************************/
#include <Std_Types.h>

/*****************************************************************************
                  Include files
*****************************************************************************/
/*****************************************************************************
                  Exported symbolic constants
*****************************************************************************/

/* Datagram message ID */
#define C_EYEQMSG_COREHILOBEAM_MSG_ID                         ( 0x7CU )

/* Datagram message lengths */
#define C_EYEQMSG_COREHILOBEAM_MSG_LEN                        ( sizeof(EYEQMSG_COREHILOBEAM_Params_t) )

/* Protocol ENUMs */

/* MCU output messages */

/* Core_High_Low_Beam_protocol Enums */
/* HLB_Brightness_Score_b32 signal Min & Max range limits */
#define C_EYEQMSG_COREHILOBEAM_HLB_BRIGHTNESS_SCORE_RMIN      ( 0U )
#define C_EYEQMSG_COREHILOBEAM_HLB_BRIGHTNESS_SCORE_RMAX      ( 2000U )
#define C_EYEQMSG_COREHILOBEAM_HLB_BRIGHTNESS_SCORE_NUMR      ( 1U )
#define C_EYEQMSG_COREHILOBEAM_HLB_BRIGHTNESS_SCORE_DEMNR     ( 100U )
#define C_EYEQMSG_COREHILOBEAM_HLB_BRIGHTNESS_SCORE_OFFSET    ( 0U )

/* HLB_Reason_b32 signal Enums */
typedef uint32 COREHILOBEAMHLBReason;
#define C_EYEQMSG_COREHILOBEAM_HLB_REASON__BIT_0_TAIL_LIGHT   ( COREHILOBEAMHLBReason ) ( 0U )
#define C_EYEQMSG_COREHILOBEAM_HLB_REASON__BIT_1_ONCOMING     ( COREHILOBEAMHLBReason ) ( 1U )
#define C_EYEQMSG_COREHILOBEAM_HLB_REASON__BIT_2_ONCOMING_GRACE ( COREHILOBEAMHLBReason ) ( 2U )
#define C_EYEQMSG_COREHILOBEAM_HLB_REASON__BIT_3_TAIL_LIGHT_GRACE ( COREHILOBEAMHLBReason ) ( 3U )
#define C_EYEQMSG_COREHILOBEAM_HLB_REASON__BIT_4_LOW_SPEED    ( COREHILOBEAMHLBReason ) ( 4U )
#define C_EYEQMSG_COREHILOBEAM_HLB_REASON__BIT_5_STREET_LIGHTS ( COREHILOBEAMHLBReason ) ( 5U )
#define C_EYEQMSG_COREHILOBEAM_HLB_REASON__BIT_6_SL_SCENE_GRACE ( COREHILOBEAMHLBReason ) ( 6U )
#define C_EYEQMSG_COREHILOBEAM_HLB_REASON__BIT_7_BRIGHT_SCENE ( COREHILOBEAMHLBReason ) ( 7U )
#define C_EYEQMSG_COREHILOBEAM_HLB_REASON__BIT_8_OBVIOUSLY_BRIGHT_SCENE ( COREHILOBEAMHLBReason ) ( 8U )
#define C_EYEQMSG_COREHILOBEAM_HLB_REASON__BIT_9_LIT_NIGHT    ( COREHILOBEAMHLBReason ) ( 9U )
#define C_EYEQMSG_COREHILOBEAM_HLB_REASON__BIT_10_LIT_NIGHT_US ( COREHILOBEAMHLBReason ) ( 10U )
#define C_EYEQMSG_COREHILOBEAM_HLB_REASON__BIT_11_LIT_NIGHT_ECE ( COREHILOBEAMHLBReason ) ( 11U )
#define C_EYEQMSG_COREHILOBEAM_HLB_REASON__BIT_12_IN_VERY_SHARPE_CURVE ( COREHILOBEAMHLBReason ) ( 12U )
#define C_EYEQMSG_COREHILOBEAM_HLB_REASON__BIT_13_IN_CURVE    ( COREHILOBEAMHLBReason ) ( 13U )
#define C_EYEQMSG_COREHILOBEAM_HLB_REASON__BIT_14_IN_BLINKING_TRAFFICLIGHT_SCENE ( COREHILOBEAMHLBReason ) ( 14U )
#define C_EYEQMSG_COREHILOBEAM_HLB_REASON__BIT_15_APPROACHING_JUNCTION ( COREHILOBEAMHLBReason ) ( 15U )
#define C_EYEQMSG_COREHILOBEAM_HLB_REASON__BIT_16_APPROACHING_ROUNDABOUT ( COREHILOBEAMHLBReason ) ( 16U )
#define C_EYEQMSG_COREHILOBEAM_HLB_REASON__BIT_17_IN_ROUNDABOUT ( COREHILOBEAMHLBReason ) ( 17U )
#define C_EYEQMSG_COREHILOBEAM_HLB_REASON__BIT_18_TUNNEL      ( COREHILOBEAMHLBReason ) ( 18U )
#define C_EYEQMSG_COREHILOBEAM_HLB_REASON__BIT_19_NOISY_SCENE ( COREHILOBEAMHLBReason ) ( 19U )
#define C_EYEQMSG_COREHILOBEAM_HLB_REASON__BIT_20_LIGHT_CONE  ( COREHILOBEAMHLBReason ) ( 20U )

/* HLB_Reason_b32 signal Min & Max range limits */
#define C_EYEQMSG_COREHILOBEAM_HLB_REASON_RMIN                ( 0U )
#define C_EYEQMSG_COREHILOBEAM_HLB_REASON_RMAX                ( 2097151U )
#define C_EYEQMSG_COREHILOBEAM_HLB_REASON_NUMR                ( 1U )
#define C_EYEQMSG_COREHILOBEAM_HLB_REASON_DEMNR               ( 1U )
#define C_EYEQMSG_COREHILOBEAM_HLB_REASON_OFFSET              ( 0U )

/* HLB_Lane_Not_Dark_b1 signal Enums */
typedef boolean COREHILOBEAMHLBLaneNotDark;
#define C_EYEQMSG_COREHILOBEAM_HLB_LANE_NOT_DARK_FALSE        ( COREHILOBEAMHLBLaneNotDark ) ( 0U )
#define C_EYEQMSG_COREHILOBEAM_HLB_LANE_NOT_DARK_TRUE         ( COREHILOBEAMHLBLaneNotDark ) ( 1U )

/* HLB_Lane_Not_Dark_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREHILOBEAM_HLB_LANE_NOT_DARK_RMIN         ( 0U )
#define C_EYEQMSG_COREHILOBEAM_HLB_LANE_NOT_DARK_RMAX         ( 1U )
#define C_EYEQMSG_COREHILOBEAM_HLB_LANE_NOT_DARK_NUMR         ( 1U )
#define C_EYEQMSG_COREHILOBEAM_HLB_LANE_NOT_DARK_DEMNR        ( 1U )
#define C_EYEQMSG_COREHILOBEAM_HLB_LANE_NOT_DARK_OFFSET       ( 0U )

/* HLB_Decision_b2 signal Enums */
typedef uint8 COREHILOBEAMHLBDecision;
#define C_EYEQMSG_COREHILOBEAM_HLB_DECISION_UNKNOWN           ( COREHILOBEAMHLBDecision ) ( 0U )
#define C_EYEQMSG_COREHILOBEAM_HLB_DECISION_HIGH              ( COREHILOBEAMHLBDecision ) ( 1U )
#define C_EYEQMSG_COREHILOBEAM_HLB_DECISION_LOW               ( COREHILOBEAMHLBDecision ) ( 2U )

/* HLB_Decision_b2 signal Min & Max range limits */
#define C_EYEQMSG_COREHILOBEAM_HLB_DECISION_RMIN              ( 0U )
#define C_EYEQMSG_COREHILOBEAM_HLB_DECISION_RMAX              ( 2U )
#define C_EYEQMSG_COREHILOBEAM_HLB_DECISION_NUMR              ( 1U )
#define C_EYEQMSG_COREHILOBEAM_HLB_DECISION_DEMNR             ( 1U )
#define C_EYEQMSG_COREHILOBEAM_HLB_DECISION_OFFSET            ( 0U )

/* HLB_Inactive_Reason_b3 signal Enums */
typedef uint8 COREHILOBEAMHLBInactiveReason;
#define C_EYEQMSG_COREHILOBEAM_HLB_INACTIVE_REASON_INVALID_REASON ( COREHILOBEAMHLBInactiveReason ) ( 0U )
#define C_EYEQMSG_COREHILOBEAM_HLB_INACTIVE_REASON_OBVIOUSLY_BRIGHT ( COREHILOBEAMHLBInactiveReason ) ( 1U )
#define C_EYEQMSG_COREHILOBEAM_HLB_INACTIVE_REASON_LOW_DETECTION_RATE ( COREHILOBEAMHLBInactiveReason ) ( 2U )
#define C_EYEQMSG_COREHILOBEAM_HLB_INACTIVE_REASON_OVER_FLOW  ( COREHILOBEAMHLBInactiveReason ) ( 3U )
#define C_EYEQMSG_COREHILOBEAM_HLB_INACTIVE_REASON_IN_GRACE   ( COREHILOBEAMHLBInactiveReason ) ( 4U )
#define C_EYEQMSG_COREHILOBEAM_HLB_INACTIVE_REASON_DEACTIVATED ( COREHILOBEAMHLBInactiveReason ) ( 5U )
#define C_EYEQMSG_COREHILOBEAM_HLB_INACTIVE_REASON_DUSK_DELAY ( COREHILOBEAMHLBInactiveReason ) ( 6U )

/* HLB_Inactive_Reason_b3 signal Min & Max range limits */
#define C_EYEQMSG_COREHILOBEAM_HLB_INACTIVE_REASON_RMIN       ( 0U )
#define C_EYEQMSG_COREHILOBEAM_HLB_INACTIVE_REASON_RMAX       ( 7U )
#define C_EYEQMSG_COREHILOBEAM_HLB_INACTIVE_REASON_NUMR       ( 1U )
#define C_EYEQMSG_COREHILOBEAM_HLB_INACTIVE_REASON_DEMNR      ( 1U )
#define C_EYEQMSG_COREHILOBEAM_HLB_INACTIVE_REASON_OFFSET     ( 0U )

/* HLB_Running_Mode_b2 signal Enums */
typedef uint8 COREHILOBEAMHLBRunningMode;
#define C_EYEQMSG_COREHILOBEAM_HLB_RUNNING_MODE_INVALID_TYPE  ( COREHILOBEAMHLBRunningMode ) ( 0U )
#define C_EYEQMSG_COREHILOBEAM_HLB_RUNNING_MODE_HLB_OFF       ( COREHILOBEAMHLBRunningMode ) ( 1U )
#define C_EYEQMSG_COREHILOBEAM_HLB_RUNNING_MODE_HLB_INACTIVE  ( COREHILOBEAMHLBRunningMode ) ( 2U )
#define C_EYEQMSG_COREHILOBEAM_HLB_RUNNING_MODE_HLB_FULL      ( COREHILOBEAMHLBRunningMode ) ( 3U )

/* HLB_Running_Mode_b2 signal Min & Max range limits */
#define C_EYEQMSG_COREHILOBEAM_HLB_RUNNING_MODE_RMIN          ( 0U )
#define C_EYEQMSG_COREHILOBEAM_HLB_RUNNING_MODE_RMAX          ( 3U )
#define C_EYEQMSG_COREHILOBEAM_HLB_RUNNING_MODE_NUMR          ( 1U )
#define C_EYEQMSG_COREHILOBEAM_HLB_RUNNING_MODE_DEMNR         ( 1U )
#define C_EYEQMSG_COREHILOBEAM_HLB_RUNNING_MODE_OFFSET        ( 0U )

/* HLB_Sync_ID_b8 signal Min & Max range limits */
#define C_EYEQMSG_COREHILOBEAM_HLB_SYNC_ID_RMIN               ( 0U )
#define C_EYEQMSG_COREHILOBEAM_HLB_SYNC_ID_RMAX               ( 255U )
#define C_EYEQMSG_COREHILOBEAM_HLB_SYNC_ID_NUMR               ( 1U )
#define C_EYEQMSG_COREHILOBEAM_HLB_SYNC_ID_DEMNR              ( 1U )
#define C_EYEQMSG_COREHILOBEAM_HLB_SYNC_ID_OFFSET             ( 0U )

/* HLB_Protocol_Version_b8 signal Min & Max range limits */
#define C_EYEQMSG_COREHILOBEAM_HLB_PROTOCOL_VERSION_RMIN      ( 8U )
#define C_EYEQMSG_COREHILOBEAM_HLB_PROTOCOL_VERSION_RMAX      ( 8U )
#define C_EYEQMSG_COREHILOBEAM_HLB_PROTOCOL_VERSION_NUMR      ( 1U )
#define C_EYEQMSG_COREHILOBEAM_HLB_PROTOCOL_VERSION_DEMNR     ( 1U )
#define C_EYEQMSG_COREHILOBEAM_HLB_PROTOCOL_VERSION_OFFSET    ( 0U )

/* HLB_Zero_byte_b8 signal Min & Max range limits */
#define C_EYEQMSG_COREHILOBEAM_HLB_ZERO_BYTE_RMIN             ( 0U )
#define C_EYEQMSG_COREHILOBEAM_HLB_ZERO_BYTE_RMAX             ( 255U )
#define C_EYEQMSG_COREHILOBEAM_HLB_ZERO_BYTE_NUMR             ( 1U )
#define C_EYEQMSG_COREHILOBEAM_HLB_ZERO_BYTE_DEMNR            ( 1U )
#define C_EYEQMSG_COREHILOBEAM_HLB_ZERO_BYTE_OFFSET           ( 0U )


/*****************************************************************************
                  Exported function-like macros
*****************************************************************************/
/*****************************************************************************
                  Exported defined macros
*****************************************************************************/
/*****************************************************************************
                  Exported types, enums definitions
*****************************************************************************/
typedef struct
{
   #if ENABLE_BIG_ENDIAN_FORMAT
      uint32        HLB_Zero_byte_b8                             : 8U;
      
      uint32        HLB_Protocol_Version_b8                      : 8U;
      
      uint32        HLB_Sync_ID_b8                               : 8U;
      
      uint32        unused1_b6                                   : 6;
      uint32        HLB_Running_Mode_b2                          : 2U;
      
      uint32        HLB_Inactive_Reason_b3                       : 3U;
      
      uint32        HLB_Decision_b2                              : 2U;
      
      uint32        HLB_Lane_Not_Dark_b1                         : 1U;
      
      uint32        HLB_Reason_1_b8                              : 8U;
      
      uint32        HLB_Reason_2_b8                              : 8U;
      
      uint32        HLB_Reason_3_b8                              : 8U;
      
      uint32        HLB_Reason_4_b8                              : 8U;
      
      uint32        HLB_Brightness_Score_1_b8                    : 8U;
      
      uint32        HLB_Brightness_Score_2_b8                    : 8U;
      
      uint32        HLB_Brightness_Score_3_b8                    : 8U;
      
      uint32        HLB_Brightness_Score_4_b8                    : 8U;
      
   #else
      uint32        HLB_Zero_byte_b8                             : 8U;
      
      uint32        HLB_Protocol_Version_b8                      : 8U;
      
      uint32        HLB_Sync_ID_b8                               : 8U;
      
      uint32        HLB_Running_Mode_b2                          : 2U;
      
      uint32        HLB_Inactive_Reason_b3                       : 3U;
      
      uint32        HLB_Decision_b2                              : 2U;
      
      uint32        HLB_Lane_Not_Dark_b1                         : 1U;
      
      uint32        HLB_Reason_b32                               : 32U;
      
      uint32        HLB_Brightness_Score_b32                     : 32U;
      
   #endif
} EYEQMSG_COREHILOBEAM_Params_t;


/*****************************************************************************
                  Exported function prototypes
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_COREHILOBEAM_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_COREHILOBEAM_Params_t * pCore_High_Low_Beam_protocol - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_High_Low_Beam_protocol message 
*    Core_High_Low_Beam_protocol message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_High_Low_Beam_protocol message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_COREHILOBEAM_ParamsApp_MsgDataStruct( EYEQMSG_COREHILOBEAM_Params_t * pCore_High_Low_Beam_protocol );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREHILOBEAM_HLB_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pHLB_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of HLB_Zero_byte
*    HLB_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns HLB_Zero_byte signal value of Core_High_Low_Beam_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREHILOBEAM_HLB_Zero_byte( uint8 * pHLB_Zero_byte );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREHILOBEAM_HLB_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pHLB_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of HLB_Protocol_Version
*    HLB_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns HLB_Protocol_Version signal value of Core_High_Low_Beam_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREHILOBEAM_HLB_Protocol_Version( uint8 * pHLB_Protocol_Version );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREHILOBEAM_HLB_Sync_ID
*
* FUNCTION ARGUMENTS:
*    uint8 * pHLB_Sync_ID - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of HLB_Sync_ID
*    HLB_Sync_ID returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns HLB_Sync_ID signal value of Core_High_Low_Beam_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREHILOBEAM_HLB_Sync_ID( uint8 * pHLB_Sync_ID );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREHILOBEAM_HLB_Running_Mode
*
* FUNCTION ARGUMENTS:
*    COREHILOBEAMHLBRunningMode * pHLB_Running_Mode - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of HLB_Running_Mode
*    HLB_Running_Mode returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns HLB_Running_Mode signal value of Core_High_Low_Beam_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREHILOBEAM_HLB_Running_Mode( COREHILOBEAMHLBRunningMode * pHLB_Running_Mode );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREHILOBEAM_HLB_Inactive_Reason
*
* FUNCTION ARGUMENTS:
*    COREHILOBEAMHLBInactiveReason * pHLB_Inactive_Reason - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of HLB_Inactive_Reason
*    HLB_Inactive_Reason returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns HLB_Inactive_Reason signal value of Core_High_Low_Beam_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREHILOBEAM_HLB_Inactive_Reason( COREHILOBEAMHLBInactiveReason * pHLB_Inactive_Reason );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREHILOBEAM_HLB_Decision
*
* FUNCTION ARGUMENTS:
*    COREHILOBEAMHLBDecision * pHLB_Decision - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of HLB_Decision
*    HLB_Decision returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns HLB_Decision signal value of Core_High_Low_Beam_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREHILOBEAM_HLB_Decision( COREHILOBEAMHLBDecision * pHLB_Decision );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREHILOBEAM_HLB_Lane_Not_Dark
*
* FUNCTION ARGUMENTS:
*    COREHILOBEAMHLBLaneNotDark * pHLB_Lane_Not_Dark - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of HLB_Lane_Not_Dark
*    HLB_Lane_Not_Dark returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns HLB_Lane_Not_Dark signal value of Core_High_Low_Beam_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREHILOBEAM_HLB_Lane_Not_Dark( COREHILOBEAMHLBLaneNotDark * pHLB_Lane_Not_Dark );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREHILOBEAM_HLB_Reason
*
* FUNCTION ARGUMENTS:
*    COREHILOBEAMHLBReason * pHLB_Reason - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of HLB_Reason
*    HLB_Reason returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns HLB_Reason signal value of Core_High_Low_Beam_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREHILOBEAM_HLB_Reason( COREHILOBEAMHLBReason * pHLB_Reason );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREHILOBEAM_HLB_Brightness_Score
*
* FUNCTION ARGUMENTS:
*    uint32 * pHLB_Brightness_Score - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of HLB_Brightness_Score
*    HLB_Brightness_Score returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns HLB_Brightness_Score signal value of Core_High_Low_Beam_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREHILOBEAM_HLB_Brightness_Score( uint32 * pHLB_Brightness_Score );
/*****************************************************************************
                  Exported object declarations
*****************************************************************************/
extern EYEQMSG_COREHILOBEAM_Params_t   EYEQMSG_COREHILOBEAM_Params_s;
extern EYEQMSG_COREHILOBEAM_Params_t   EYEQMSG_COREHILOBEAM_ParamsApp_s;
/****************************************************************************/
#endif /* _EYEQMSG_COREHILOBEAMPROCESS_H_ */


