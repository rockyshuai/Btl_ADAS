#ifndef _EYEQMSG_CORELATDEPWARNPROCESS_H_
#define _EYEQMSG_CORELATDEPWARNPROCESS_H_

/*****************************************************************************
                  Included header files
*****************************************************************************/
#include <Std_Types.h>

/*****************************************************************************
                  Include files
*****************************************************************************/
/*****************************************************************************
                  Exported symbolic constants
*****************************************************************************/
#define C_EYEQMSG_CORELDWvH_VIRTUAL_OBJECT_INDEX_RMAX ( 4U )

/* Datagram message ID */
#define C_EYEQMSG_CORELDWvH_MSG_ID                            ( 0x8BU )
#define C_EYEQMSG_CORELDWvO_MSG_ID                            ( 0x8BU )
#define C_EYEQMSG_CORELDW_MSG_ID                              ( 0x8BU )

/* Datagram message lengths */
#define C_EYEQMSG_CORELDWvH_MSG_LEN                           ( sizeof(EYEQMSG_CORELDWvH_Params_t) )
#define C_EYEQMSG_CORELDWvO_MSG_LEN                           ( sizeof(EYEQMSG_CORELDWvO_Params_t) )
#define C_EYEQMSG_CORELDW_MSG_LEN                             ( sizeof(EYEQMSG_CORELDW_Params_t) )

/* Protocol ENUMs */

/* MCU output messages */

/* Virtual_HEADER_msg_Core_Lateral_Departure_Warning_protocol Enums */
/* Reserved_2_b16 signal Min & Max range limits */
#define C_EYEQMSG_CORELDWvH_RESERVED_2_RMIN                   ( 0U )
#define C_EYEQMSG_CORELDWvH_RESERVED_2_RMAX                   ( 0U )
#define C_EYEQMSG_CORELDWvH_RESERVED_2_NUMR                   ( 1U )
#define C_EYEQMSG_CORELDWvH_RESERVED_2_DEMNR                  ( 1U )
#define C_EYEQMSG_CORELDWvH_RESERVED_2_OFFSET                 ( 0U )

/* LDW_Time_To_Host_Right_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORELDWvH_LDW_TIME_TO_HOST_RIGHT_RMIN       ( 0U )
#define C_EYEQMSG_CORELDWvH_LDW_TIME_TO_HOST_RIGHT_RMAX       ( 200U )
#define C_EYEQMSG_CORELDWvH_LDW_TIME_TO_HOST_RIGHT_NUMR       ( 1U )
#define C_EYEQMSG_CORELDWvH_LDW_TIME_TO_HOST_RIGHT_DEMNR      ( 100U )
#define C_EYEQMSG_CORELDWvH_LDW_TIME_TO_HOST_RIGHT_OFFSET     ( 0U )

/* LDW_Time_To_Host_Left_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORELDWvH_LDW_TIME_TO_HOST_LEFT_RMIN        ( 0U )
#define C_EYEQMSG_CORELDWvH_LDW_TIME_TO_HOST_LEFT_RMAX        ( 200U )
#define C_EYEQMSG_CORELDWvH_LDW_TIME_TO_HOST_LEFT_NUMR        ( 1U )
#define C_EYEQMSG_CORELDWvH_LDW_TIME_TO_HOST_LEFT_DEMNR       ( 100U )
#define C_EYEQMSG_CORELDWvH_LDW_TIME_TO_HOST_LEFT_OFFSET      ( 0U )

/* Reserved_1_b6 signal Min & Max range limits */
#define C_EYEQMSG_CORELDWvH_RESERVED_1_RMIN                   ( 0U )
#define C_EYEQMSG_CORELDWvH_RESERVED_1_RMAX                   ( 0U )
#define C_EYEQMSG_CORELDWvH_RESERVED_1_NUMR                   ( 1U )
#define C_EYEQMSG_CORELDWvH_RESERVED_1_DEMNR                  ( 1U )
#define C_EYEQMSG_CORELDWvH_RESERVED_1_OFFSET                 ( 0U )

/* LDW_Line_Valid_Right_b1 signal Enums */
typedef boolean CORELDWvHLDWLineValidRight;
#define C_EYEQMSG_CORELDWvH_LDW_LINE_VALID_RIGHT_FALSE        ( CORELDWvHLDWLineValidRight ) ( 0U )
#define C_EYEQMSG_CORELDWvH_LDW_LINE_VALID_RIGHT_TRUE         ( CORELDWvHLDWLineValidRight ) ( 1U )

/* LDW_Line_Valid_Right_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORELDWvH_LDW_LINE_VALID_RIGHT_RMIN         ( 0U )
#define C_EYEQMSG_CORELDWvH_LDW_LINE_VALID_RIGHT_RMAX         ( 1U )
#define C_EYEQMSG_CORELDWvH_LDW_LINE_VALID_RIGHT_NUMR         ( 1U )
#define C_EYEQMSG_CORELDWvH_LDW_LINE_VALID_RIGHT_DEMNR        ( 1U )
#define C_EYEQMSG_CORELDWvH_LDW_LINE_VALID_RIGHT_OFFSET       ( 0U )

/* LDW_Line_Valid_Left_b1 signal Enums */
typedef boolean CORELDWvHLDWLineValidLeft;
#define C_EYEQMSG_CORELDWvH_LDW_LINE_VALID_LEFT_FALSE         ( CORELDWvHLDWLineValidLeft ) ( 0U )
#define C_EYEQMSG_CORELDWvH_LDW_LINE_VALID_LEFT_TRUE          ( CORELDWvHLDWLineValidLeft ) ( 1U )

/* LDW_Line_Valid_Left_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORELDWvH_LDW_LINE_VALID_LEFT_RMIN          ( 0U )
#define C_EYEQMSG_CORELDWvH_LDW_LINE_VALID_LEFT_RMAX          ( 1U )
#define C_EYEQMSG_CORELDWvH_LDW_LINE_VALID_LEFT_NUMR          ( 1U )
#define C_EYEQMSG_CORELDWvH_LDW_LINE_VALID_LEFT_DEMNR         ( 1U )
#define C_EYEQMSG_CORELDWvH_LDW_LINE_VALID_LEFT_OFFSET        ( 0U )

/* LDW_Sync_ID_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORELDWvH_LDW_SYNC_ID_RMIN                  ( 0U )
#define C_EYEQMSG_CORELDWvH_LDW_SYNC_ID_RMAX                  ( 255U )
#define C_EYEQMSG_CORELDWvH_LDW_SYNC_ID_NUMR                  ( 1U )
#define C_EYEQMSG_CORELDWvH_LDW_SYNC_ID_DEMNR                 ( 1U )
#define C_EYEQMSG_CORELDWvH_LDW_SYNC_ID_OFFSET                ( 0U )

/* LDW_Protocol_Version_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORELDWvH_LDW_PROTOCOL_VERSION_RMIN         ( 4U )
#define C_EYEQMSG_CORELDWvH_LDW_PROTOCOL_VERSION_RMAX         ( 4U )
#define C_EYEQMSG_CORELDWvH_LDW_PROTOCOL_VERSION_NUMR         ( 1U )
#define C_EYEQMSG_CORELDWvH_LDW_PROTOCOL_VERSION_DEMNR        ( 1U )
#define C_EYEQMSG_CORELDWvH_LDW_PROTOCOL_VERSION_OFFSET       ( 0U )

/* LDW_Zero_byte_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORELDWvH_LDW_ZERO_BYTE_RMIN                ( 0U )
#define C_EYEQMSG_CORELDWvH_LDW_ZERO_BYTE_RMAX                ( 255U )
#define C_EYEQMSG_CORELDWvH_LDW_ZERO_BYTE_NUMR                ( 1U )
#define C_EYEQMSG_CORELDWvH_LDW_ZERO_BYTE_DEMNR               ( 1U )
#define C_EYEQMSG_CORELDWvH_LDW_ZERO_BYTE_OFFSET              ( 0U )


/* Virtual_OBJECT_msg_Core_Lateral_Departure_Warning_protocol Enums */
/* Reserved_3_0_b2 signal Min & Max range limits */
#define C_EYEQMSG_CORELDWvO_RESERVED_3_0_RMIN                 ( 0U )
#define C_EYEQMSG_CORELDWvO_RESERVED_3_0_RMAX                 ( 0U )
#define C_EYEQMSG_CORELDWvO_RESERVED_3_0_NUMR                 ( 1U )
#define C_EYEQMSG_CORELDWvO_RESERVED_3_0_DEMNR                ( 1U )
#define C_EYEQMSG_CORELDWvO_RESERVED_3_0_OFFSET               ( 0U )

/* LDW_Warning_Status_Right_0_b2 signal Enums */
typedef uint8 CORELDWvOLDWWarningStatusRight0;
#define C_EYEQMSG_CORELDWvO_LDW_WARNING_STATUS_RIGHT_0_SUPPRESSED ( CORELDWvOLDWWarningStatusRight0 ) ( 0U )
#define C_EYEQMSG_CORELDWvO_LDW_WARNING_STATUS_RIGHT_0_DISABLED ( CORELDWvOLDWWarningStatusRight0 ) ( 1U )
#define C_EYEQMSG_CORELDWvO_LDW_WARNING_STATUS_RIGHT_0_ENABLED ( CORELDWvOLDWWarningStatusRight0 ) ( 2U )
#define C_EYEQMSG_CORELDWvO_LDW_WARNING_STATUS_RIGHT_0_ACTIVE ( CORELDWvOLDWWarningStatusRight0 ) ( 3U )

/* LDW_Warning_Status_Right_0_b2 signal Min & Max range limits */
#define C_EYEQMSG_CORELDWvO_LDW_WARNING_STATUS_RIGHT_0_RMIN   ( 0U )
#define C_EYEQMSG_CORELDWvO_LDW_WARNING_STATUS_RIGHT_0_RMAX   ( 3U )
#define C_EYEQMSG_CORELDWvO_LDW_WARNING_STATUS_RIGHT_0_NUMR   ( 1U )
#define C_EYEQMSG_CORELDWvO_LDW_WARNING_STATUS_RIGHT_0_DEMNR  ( 1U )
#define C_EYEQMSG_CORELDWvO_LDW_WARNING_STATUS_RIGHT_0_OFFSET ( 0U )

/* LDW_Warning_Status_Left_0_b2 signal Enums */
typedef uint8 CORELDWvOLDWWarningStatusLeft0;
#define C_EYEQMSG_CORELDWvO_LDW_WARNING_STATUS_LEFT_0_SUPPRESSED ( CORELDWvOLDWWarningStatusLeft0 ) ( 0U )
#define C_EYEQMSG_CORELDWvO_LDW_WARNING_STATUS_LEFT_0_DISABLED ( CORELDWvOLDWWarningStatusLeft0 ) ( 1U )
#define C_EYEQMSG_CORELDWvO_LDW_WARNING_STATUS_LEFT_0_ENABLED ( CORELDWvOLDWWarningStatusLeft0 ) ( 2U )
#define C_EYEQMSG_CORELDWvO_LDW_WARNING_STATUS_LEFT_0_ACTIVE  ( CORELDWvOLDWWarningStatusLeft0 ) ( 3U )

/* LDW_Warning_Status_Left_0_b2 signal Min & Max range limits */
#define C_EYEQMSG_CORELDWvO_LDW_WARNING_STATUS_LEFT_0_RMIN    ( 0U )
#define C_EYEQMSG_CORELDWvO_LDW_WARNING_STATUS_LEFT_0_RMAX    ( 3U )
#define C_EYEQMSG_CORELDWvO_LDW_WARNING_STATUS_LEFT_0_NUMR    ( 1U )
#define C_EYEQMSG_CORELDWvO_LDW_WARNING_STATUS_LEFT_0_DEMNR   ( 1U )
#define C_EYEQMSG_CORELDWvO_LDW_WARNING_STATUS_LEFT_0_OFFSET  ( 0U )

/* LDW_Time_To_Warning_Right_0_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORELDWvO_LDW_TIME_TO_WARNING_RIGHT_0_RMIN  ( 0U )
#define C_EYEQMSG_CORELDWvO_LDW_TIME_TO_WARNING_RIGHT_0_RMAX  ( 200U )
#define C_EYEQMSG_CORELDWvO_LDW_TIME_TO_WARNING_RIGHT_0_NUMR  ( 1U )
#define C_EYEQMSG_CORELDWvO_LDW_TIME_TO_WARNING_RIGHT_0_DEMNR ( 100U )
#define C_EYEQMSG_CORELDWvO_LDW_TIME_TO_WARNING_RIGHT_0_OFFSET ( 0U )

/* LDW_Time_To_Warning_Left_0_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORELDWvO_LDW_TIME_TO_WARNING_LEFT_0_RMIN   ( 0U )
#define C_EYEQMSG_CORELDWvO_LDW_TIME_TO_WARNING_LEFT_0_RMAX   ( 200U )
#define C_EYEQMSG_CORELDWvO_LDW_TIME_TO_WARNING_LEFT_0_NUMR   ( 1U )
#define C_EYEQMSG_CORELDWvO_LDW_TIME_TO_WARNING_LEFT_0_DEMNR  ( 100U )
#define C_EYEQMSG_CORELDWvO_LDW_TIME_TO_WARNING_LEFT_0_OFFSET ( 0U )

/* LDW_Suppression_Reason_0_b10 signal Min & Max range limits */
#define C_EYEQMSG_CORELDWvO_LDW_SUPPRESSION_REASON_0_RMIN     ( 0U )
#define C_EYEQMSG_CORELDWvO_LDW_SUPPRESSION_REASON_0_RMAX     ( 1023U )
#define C_EYEQMSG_CORELDWvO_LDW_SUPPRESSION_REASON_0_NUMR     ( 1U )
#define C_EYEQMSG_CORELDWvO_LDW_SUPPRESSION_REASON_0_DEMNR    ( 1U )
#define C_EYEQMSG_CORELDWvO_LDW_SUPPRESSION_REASON_0_OFFSET   ( 0U )


/*****************************************************************************
                  Exported function-like macros
*****************************************************************************/
/*****************************************************************************
                  Exported defined macros
*****************************************************************************/
/*****************************************************************************
                  Exported types, enums definitions
*****************************************************************************/
typedef struct
{
   #if ENABLE_BIG_ENDIAN_FORMAT
      uint32        LDW_Zero_byte_b8                             : 8U;
      
      uint32        LDW_Protocol_Version_b8                      : 8U;
      
      uint32        LDW_Sync_ID_b8                               : 8U;
      
      uint32        unused1_b7                                   : 7;
      uint32        LDW_Line_Valid_Left_b1                       : 1U;
      
      uint32        LDW_Line_Valid_Right_b1                      : 1U;
      
      uint32        Reserved_1_b6                                : 6U;
      
      uint32        LDW_Time_To_Host_Left_b8                     : 8U;
      
      uint32        LDW_Time_To_Host_Right_b8                    : 8U;
      
      uint32        Reserved_2_1_b8                              : 8U;
      
      uint32        Reserved_2_2_b8                              : 8U;
      
   #else
      uint32        LDW_Zero_byte_b8                             : 8U;
      
      uint32        LDW_Protocol_Version_b8                      : 8U;
      
      uint32        LDW_Sync_ID_b8                               : 8U;
      
      uint32        LDW_Line_Valid_Left_b1                       : 1U;
      
      uint32        LDW_Line_Valid_Right_b1                      : 1U;
      
      uint32        Reserved_1_b6                                : 6U;
      
      uint32        LDW_Time_To_Host_Left_b8                     : 8U;
      
      uint32        LDW_Time_To_Host_Right_b8                    : 8U;
      
      uint32        Reserved_2_b16                               : 16U;
      
   #endif
} EYEQMSG_CORELDWvH_Params_t;


typedef struct
{
   #if ENABLE_BIG_ENDIAN_FORMAT
      uint32        unused1_b64                                  : 64;
      uint32        LDW_Suppression_Reason_0_1_b8                : 8U;
      
      uint32        unused2_b6                                   : 6;
      uint32        LDW_Suppression_Reason_0_2_b2                : 2U;
      
      uint32        LDW_Time_To_Warning_Left_0_1_b6              : 6U;
      
      uint32        LDW_Time_To_Warning_Left_0_2_b2              : 2U;
      
      uint32        LDW_Time_To_Warning_Right_0_1_b6             : 6U;
      
      uint32        LDW_Time_To_Warning_Right_0_2_b2             : 2U;
      
      uint32        LDW_Warning_Status_Left_0_b2                 : 2U;
      
      uint32        LDW_Warning_Status_Right_0_b2                : 2U;
      
      uint32        Reserved_3_0_b2                              : 2U;
      
   #else
      uint32        LDW_Suppression_Reason_0_b10                 : 10U;
      
      uint32        LDW_Time_To_Warning_Left_0_b8                : 8U;
      
      uint32        LDW_Time_To_Warning_Right_0_b8               : 8U;
      
      uint32        LDW_Warning_Status_Left_0_b2                 : 2U;
      
      uint32        LDW_Warning_Status_Right_0_b2                : 2U;
      
      uint32        Reserved_3_0_b2                              : 2U;
      
   #endif
} EYEQMSG_CORELDWvO_Params_t;


typedef struct
{
   EYEQMSG_CORELDWvH_Params_t EYEQMSG_CORELDWvH_Params_s;
   EYEQMSG_CORELDWvO_Params_t EYEQMSG_CORELDWvO_Params_as[C_EYEQMSG_CORELDWvH_VIRTUAL_OBJECT_INDEX_RMAX];
} EYEQMSG_CORELDW_Params_t;


/*****************************************************************************
                  Exported function prototypes
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELDWvH_LDW_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pLDW_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LDW_Zero_byte
*    LDW_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LDW_Zero_byte signal value of Virtual_HEADER_msg_Core_Lateral_Departure_Warning_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELDWvH_LDW_Zero_byte( uint8 * pLDW_Zero_byte );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELDWvH_LDW_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pLDW_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LDW_Protocol_Version
*    LDW_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LDW_Protocol_Version signal value of Virtual_HEADER_msg_Core_Lateral_Departure_Warning_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELDWvH_LDW_Protocol_Version( uint8 * pLDW_Protocol_Version );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELDWvH_LDW_Sync_ID
*
* FUNCTION ARGUMENTS:
*    uint8 * pLDW_Sync_ID - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LDW_Sync_ID
*    LDW_Sync_ID returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LDW_Sync_ID signal value of Virtual_HEADER_msg_Core_Lateral_Departure_Warning_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELDWvH_LDW_Sync_ID( uint8 * pLDW_Sync_ID );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELDWvH_LDW_Line_Valid_Left
*
* FUNCTION ARGUMENTS:
*    CORELDWvHLDWLineValidLeft * pLDW_Line_Valid_Left - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LDW_Line_Valid_Left
*    LDW_Line_Valid_Left returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LDW_Line_Valid_Left signal value of Virtual_HEADER_msg_Core_Lateral_Departure_Warning_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELDWvH_LDW_Line_Valid_Left( CORELDWvHLDWLineValidLeft * pLDW_Line_Valid_Left );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELDWvH_LDW_Line_Valid_Right
*
* FUNCTION ARGUMENTS:
*    CORELDWvHLDWLineValidRight * pLDW_Line_Valid_Right - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LDW_Line_Valid_Right
*    LDW_Line_Valid_Right returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LDW_Line_Valid_Right signal value of Virtual_HEADER_msg_Core_Lateral_Departure_Warning_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELDWvH_LDW_Line_Valid_Right( CORELDWvHLDWLineValidRight * pLDW_Line_Valid_Right );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELDWvH_Reserved_1
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1
*    Reserved_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1 signal value of Virtual_HEADER_msg_Core_Lateral_Departure_Warning_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELDWvH_Reserved_1( uint8 * pReserved_1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELDWvH_LDW_Time_To_Host_Left
*
* FUNCTION ARGUMENTS:
*    uint8 * pLDW_Time_To_Host_Left - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LDW_Time_To_Host_Left
*    LDW_Time_To_Host_Left returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LDW_Time_To_Host_Left signal value of Virtual_HEADER_msg_Core_Lateral_Departure_Warning_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELDWvH_LDW_Time_To_Host_Left( uint8 * pLDW_Time_To_Host_Left );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELDWvH_LDW_Time_To_Host_Right
*
* FUNCTION ARGUMENTS:
*    uint8 * pLDW_Time_To_Host_Right - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LDW_Time_To_Host_Right
*    LDW_Time_To_Host_Right returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LDW_Time_To_Host_Right signal value of Virtual_HEADER_msg_Core_Lateral_Departure_Warning_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELDWvH_LDW_Time_To_Host_Right( uint8 * pLDW_Time_To_Host_Right );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELDWvH_Reserved_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pReserved_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_2
*    Reserved_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_2 signal value of Virtual_HEADER_msg_Core_Lateral_Departure_Warning_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELDWvH_Reserved_2( uint16 * pReserved_2 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELDWvO_LDW_Suppression_Reason_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLDW_Suppression_Reason_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LDW_Suppression_Reason_0
*    LDW_Suppression_Reason_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LDW_Suppression_Reason_0 signal value of Virtual_OBJECT_msg_Core_Lateral_Departure_Warning_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELDWvO_LDW_Suppression_Reason_0( uint8 objIndx_u8, uint16 * pLDW_Suppression_Reason_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELDWvO_LDW_Time_To_Warning_Left_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLDW_Time_To_Warning_Left_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LDW_Time_To_Warning_Left_0
*    LDW_Time_To_Warning_Left_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LDW_Time_To_Warning_Left_0 signal value of Virtual_OBJECT_msg_Core_Lateral_Departure_Warning_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELDWvO_LDW_Time_To_Warning_Left_0( uint8 objIndx_u8, uint8 * pLDW_Time_To_Warning_Left_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELDWvO_LDW_Time_To_Warning_Right_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLDW_Time_To_Warning_Right_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LDW_Time_To_Warning_Right_0
*    LDW_Time_To_Warning_Right_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LDW_Time_To_Warning_Right_0 signal value of Virtual_OBJECT_msg_Core_Lateral_Departure_Warning_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELDWvO_LDW_Time_To_Warning_Right_0( uint8 objIndx_u8, uint8 * pLDW_Time_To_Warning_Right_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELDWvO_LDW_Warning_Status_Left_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELDWvOLDWWarningStatusLeft0 * pLDW_Warning_Status_Left_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LDW_Warning_Status_Left_0
*    LDW_Warning_Status_Left_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LDW_Warning_Status_Left_0 signal value of Virtual_OBJECT_msg_Core_Lateral_Departure_Warning_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELDWvO_LDW_Warning_Status_Left_0( uint8 objIndx_u8, CORELDWvOLDWWarningStatusLeft0 * pLDW_Warning_Status_Left_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELDWvO_LDW_Warning_Status_Right_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELDWvOLDWWarningStatusRight0 * pLDW_Warning_Status_Right_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LDW_Warning_Status_Right_0
*    LDW_Warning_Status_Right_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LDW_Warning_Status_Right_0 signal value of Virtual_OBJECT_msg_Core_Lateral_Departure_Warning_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELDWvO_LDW_Warning_Status_Right_0( uint8 objIndx_u8, CORELDWvOLDWWarningStatusRight0 * pLDW_Warning_Status_Right_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELDWvO_Reserved_3_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_3_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_3_0
*    Reserved_3_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_3_0 signal value of Virtual_OBJECT_msg_Core_Lateral_Departure_Warning_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELDWvO_Reserved_3_0( uint8 objIndx_u8, uint8 * pReserved_3_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_CORELDW_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_CORELDW_Params_t * pCore_Lateral_Departure_Warning_protocol - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_Lateral_Departure_Warning_protocol message 
*    Core_Lateral_Departure_Warning_protocol message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_Lateral_Departure_Warning_protocol message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_CORELDW_ParamsApp_MsgDataStruct( EYEQMSG_CORELDW_Params_t * pCore_Lateral_Departure_Warning_protocol );
/*****************************************************************************
                  Exported object declarations
*****************************************************************************/
extern EYEQMSG_CORELDW_Params_t   EYEQMSG_CORELDW_Params_s;
extern EYEQMSG_CORELDW_Params_t   EYEQMSG_CORELDW_ParamsApp_s;
/****************************************************************************/
#endif /* _EYEQMSG_CORELATDEPWARNPROCESS_H_ */


