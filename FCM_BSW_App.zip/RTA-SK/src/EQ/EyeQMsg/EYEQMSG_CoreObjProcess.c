

/*****************************************************************************
                  Include files
*****************************************************************************/
/* The suggested include file order is: */
#include "EyeQ_defs.h"    /* EyeQ project common definitions file    */

#include "EYEQMSG_CoreObjProcess.h"

/*****************************************************************************
                  Local symbolic constants
*****************************************************************************/
/*****************************************************************************
                  Local types, enums definitions
*****************************************************************************/
/*****************************************************************************
                  Local function prototypes
*****************************************************************************/
/*****************************************************************************
                  Local object definitions
*****************************************************************************/
/*****************************************************************************
                  Exported object definitions
*****************************************************************************/
EYEQMSG_COREOBJ_Params_t   EYEQMSG_COREOBJ_Params_s;
EYEQMSG_COREOBJ_Params_t   EYEQMSG_COREOBJ_ParamsApp_s;
/*****************************************************************************
                  Local function-like macros
*****************************************************************************/
/*****************************************************************************
                  Local defined macros
*****************************************************************************/
/*****************************************************************************
                  Function definitions
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvH_OBJ_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pOBJ_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Zero_byte
*    OBJ_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Zero_byte signal value of Virtual_HEADER_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvH_OBJ_Zero_byte( uint8 * pOBJ_Zero_byte )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pOBJ_Zero_byte != C_NULL_P )
   {
      signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvH_Params_s.OBJ_Zero_byte_b8;
      * pOBJ_Zero_byte = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvH_Reserved_1
*
* FUNCTION ARGUMENTS:
*    uint32 * pReserved_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1
*    Reserved_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1 signal value of Virtual_HEADER_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvH_Reserved_1( uint32 * pReserved_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pReserved_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvH_Params_s.Reserved_1_b24;
      * pReserved_1 = signal_value;
      if( signal_value <= C_EYEQMSG_COREOBJvH_RESERVED_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvH_OBJ_Header_CRC
*
* FUNCTION ARGUMENTS:
*    uint32 * pOBJ_Header_CRC - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Header_CRC
*    OBJ_Header_CRC returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Header_CRC signal value of Virtual_HEADER_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvH_OBJ_Header_CRC( uint32 * pOBJ_Header_CRC )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pOBJ_Header_CRC != C_NULL_P )
   {
      signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvH_Params_s.OBJ_Header_CRC_b32;
      * pOBJ_Header_CRC = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvH_OBJ_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pOBJ_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Protocol_Version
*    OBJ_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Protocol_Version signal value of Virtual_HEADER_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvH_OBJ_Protocol_Version( uint8 * pOBJ_Protocol_Version )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pOBJ_Protocol_Version != C_NULL_P )
   {
      signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvH_Params_s.OBJ_Protocol_Version_b8;
      * pOBJ_Protocol_Version = signal_value;
      if( (signal_value >= C_EYEQMSG_COREOBJvH_OBJ_PROTOCOL_VERSION_RMIN ) 
          && (signal_value <= C_EYEQMSG_COREOBJvH_OBJ_PROTOCOL_VERSION_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvH_OBJ_Sync_ID
*
* FUNCTION ARGUMENTS:
*    uint8 * pOBJ_Sync_ID - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Sync_ID
*    OBJ_Sync_ID returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Sync_ID signal value of Virtual_HEADER_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvH_OBJ_Sync_ID( uint8 * pOBJ_Sync_ID )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pOBJ_Sync_ID != C_NULL_P )
   {
      signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvH_Params_s.OBJ_Sync_ID_b8;
      * pOBJ_Sync_ID = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvH_OBJ_VRU_Count
*
* FUNCTION ARGUMENTS:
*    uint8 * pOBJ_VRU_Count - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_VRU_Count
*    OBJ_VRU_Count returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_VRU_Count signal value of Virtual_HEADER_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvH_OBJ_VRU_Count( uint8 * pOBJ_VRU_Count )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pOBJ_VRU_Count != C_NULL_P )
   {
      signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvH_Params_s.OBJ_VRU_Count_b5;
      * pOBJ_VRU_Count = signal_value;
      if( signal_value <= C_EYEQMSG_COREOBJvH_OBJ_VRU_COUNT_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvH_OBJ_VD_Count
*
* FUNCTION ARGUMENTS:
*    uint8 * pOBJ_VD_Count - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_VD_Count
*    OBJ_VD_Count returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_VD_Count signal value of Virtual_HEADER_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvH_OBJ_VD_Count( uint8 * pOBJ_VD_Count )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pOBJ_VD_Count != C_NULL_P )
   {
      signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvH_Params_s.OBJ_VD_Count_b5;
      * pOBJ_VD_Count = signal_value;
      if( signal_value <= C_EYEQMSG_COREOBJvH_OBJ_VD_COUNT_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvH_OBJ_General_OBJ_Count
*
* FUNCTION ARGUMENTS:
*    uint8 * pOBJ_General_OBJ_Count - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_General_OBJ_Count
*    OBJ_General_OBJ_Count returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_General_OBJ_Count signal value of Virtual_HEADER_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvH_OBJ_General_OBJ_Count( uint8 * pOBJ_General_OBJ_Count )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pOBJ_General_OBJ_Count != C_NULL_P )
   {
      signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvH_Params_s.OBJ_General_OBJ_Count_b4;
      * pOBJ_General_OBJ_Count = signal_value;
      if( signal_value <= C_EYEQMSG_COREOBJvH_OBJ_GENERAL_OBJ_COUNT_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvH_Reserved_2
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_2
*    Reserved_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_2 signal value of Virtual_HEADER_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvH_Reserved_2( uint8 * pReserved_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pReserved_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvH_Params_s.Reserved_2_b2;
      * pReserved_2 = signal_value;
      if( signal_value <= C_EYEQMSG_COREOBJvH_RESERVED_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvH_OBJ_Animal_Count
*
* FUNCTION ARGUMENTS:
*    uint8 * pOBJ_Animal_Count - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Animal_Count
*    OBJ_Animal_Count returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Animal_Count signal value of Virtual_HEADER_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvH_OBJ_Animal_Count( uint8 * pOBJ_Animal_Count )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pOBJ_Animal_Count != C_NULL_P )
   {
      signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvH_Params_s.OBJ_Animal_Count_b4;
      * pOBJ_Animal_Count = signal_value;
      if( signal_value <= C_EYEQMSG_COREOBJvH_OBJ_ANIMAL_COUNT_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvH_OBJ_VD_NIV_Left
*
* FUNCTION ARGUMENTS:
*    uint8 * pOBJ_VD_NIV_Left - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_VD_NIV_Left
*    OBJ_VD_NIV_Left returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_VD_NIV_Left signal value of Virtual_HEADER_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvH_OBJ_VD_NIV_Left( uint8 * pOBJ_VD_NIV_Left )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pOBJ_VD_NIV_Left != C_NULL_P )
   {
      signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvH_Params_s.OBJ_VD_NIV_Left_b8;
      * pOBJ_VD_NIV_Left = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvH_OBJ_VD_NIV_Right
*
* FUNCTION ARGUMENTS:
*    uint8 * pOBJ_VD_NIV_Right - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_VD_NIV_Right
*    OBJ_VD_NIV_Right returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_VD_NIV_Right signal value of Virtual_HEADER_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvH_OBJ_VD_NIV_Right( uint8 * pOBJ_VD_NIV_Right )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pOBJ_VD_NIV_Right != C_NULL_P )
   {
      signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvH_Params_s.OBJ_VD_NIV_Right_b8;
      * pOBJ_VD_NIV_Right = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvH_OBJ_VD_CIPV_ID
*
* FUNCTION ARGUMENTS:
*    uint8 * pOBJ_VD_CIPV_ID - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_VD_CIPV_ID
*    OBJ_VD_CIPV_ID returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_VD_CIPV_ID signal value of Virtual_HEADER_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvH_OBJ_VD_CIPV_ID( uint8 * pOBJ_VD_CIPV_ID )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pOBJ_VD_CIPV_ID != C_NULL_P )
   {
      signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvH_Params_s.OBJ_VD_CIPV_ID_b8;
      * pOBJ_VD_CIPV_ID = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvH_OBJ_VD_CIPV_Lost
*
* FUNCTION ARGUMENTS:
*    COREOBJvHOBJVDCIPVLost * pOBJ_VD_CIPV_Lost - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_VD_CIPV_Lost
*    OBJ_VD_CIPV_Lost returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_VD_CIPV_Lost signal value of Virtual_HEADER_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvH_OBJ_VD_CIPV_Lost( COREOBJvHOBJVDCIPVLost * pOBJ_VD_CIPV_Lost )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvHOBJVDCIPVLost signal_value;
   
   if( pOBJ_VD_CIPV_Lost != C_NULL_P )
   {
      signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvH_Params_s.OBJ_VD_CIPV_Lost_b2;
      * pOBJ_VD_CIPV_Lost = signal_value;
      if( signal_value <= C_EYEQMSG_COREOBJvH_OBJ_VD_CIPV_LOST_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvH_OBJ_VD_Allow_Acc
*
* FUNCTION ARGUMENTS:
*    COREOBJvHOBJVDAllowAcc * pOBJ_VD_Allow_Acc - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_VD_Allow_Acc
*    OBJ_VD_Allow_Acc returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_VD_Allow_Acc signal value of Virtual_HEADER_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvH_OBJ_VD_Allow_Acc( COREOBJvHOBJVDAllowAcc * pOBJ_VD_Allow_Acc )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvHOBJVDAllowAcc signal_value;
   
   if( pOBJ_VD_Allow_Acc != C_NULL_P )
   {
      signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvH_Params_s.OBJ_VD_Allow_Acc_b2;
      * pOBJ_VD_Allow_Acc = signal_value;
      if( signal_value <= C_EYEQMSG_COREOBJvH_OBJ_VD_ALLOW_ACC_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvH_OBJ_Is_Blocked_Left
*
* FUNCTION ARGUMENTS:
*    COREOBJvHOBJIsBlockedLeft * pOBJ_Is_Blocked_Left - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Is_Blocked_Left
*    OBJ_Is_Blocked_Left returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Is_Blocked_Left signal value of Virtual_HEADER_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvH_OBJ_Is_Blocked_Left( COREOBJvHOBJIsBlockedLeft * pOBJ_Is_Blocked_Left )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvHOBJIsBlockedLeft signal_value;
   
   if( pOBJ_Is_Blocked_Left != C_NULL_P )
   {
      signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvH_Params_s.OBJ_Is_Blocked_Left_b1;
      * pOBJ_Is_Blocked_Left = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvH_OBJ_Is_Blocked_Right
*
* FUNCTION ARGUMENTS:
*    COREOBJvHOBJIsBlockedRight * pOBJ_Is_Blocked_Right - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Is_Blocked_Right
*    OBJ_Is_Blocked_Right returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Is_Blocked_Right signal value of Virtual_HEADER_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvH_OBJ_Is_Blocked_Right( COREOBJvHOBJIsBlockedRight * pOBJ_Is_Blocked_Right )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvHOBJIsBlockedRight signal_value;
   
   if( pOBJ_Is_Blocked_Right != C_NULL_P )
   {
      signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvH_Params_s.OBJ_Is_Blocked_Right_b1;
      * pOBJ_Is_Blocked_Right = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvH_OBJ_CIPBIC_ID
*
* FUNCTION ARGUMENTS:
*    uint8 * pOBJ_CIPBIC_ID - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_CIPBIC_ID
*    OBJ_CIPBIC_ID returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_CIPBIC_ID signal value of Virtual_HEADER_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvH_OBJ_CIPBIC_ID( uint8 * pOBJ_CIPBIC_ID )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pOBJ_CIPBIC_ID != C_NULL_P )
   {
      signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvH_Params_s.OBJ_CIPBIC_ID_b8;
      * pOBJ_CIPBIC_ID = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvH_OBJ_CIPBIC_Lost
*
* FUNCTION ARGUMENTS:
*    COREOBJvHOBJCIPBICLost * pOBJ_CIPBIC_Lost - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_CIPBIC_Lost
*    OBJ_CIPBIC_Lost returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_CIPBIC_Lost signal value of Virtual_HEADER_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvH_OBJ_CIPBIC_Lost( COREOBJvHOBJCIPBICLost * pOBJ_CIPBIC_Lost )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvHOBJCIPBICLost signal_value;
   
   if( pOBJ_CIPBIC_Lost != C_NULL_P )
   {
      signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvH_Params_s.OBJ_CIPBIC_Lost_b2;
      * pOBJ_CIPBIC_Lost = signal_value;
      if( signal_value <= C_EYEQMSG_COREOBJvH_OBJ_CIPBIC_LOST_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvH_Reserved_3
*
* FUNCTION ARGUMENTS:
*    uint32 * pReserved_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_3
*    Reserved_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_3 signal value of Virtual_HEADER_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvH_Reserved_3( uint32 * pReserved_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pReserved_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvH_Params_s.Reserved_3_b20;
      * pReserved_3 = signal_value;
      if( signal_value <= C_EYEQMSG_COREOBJvH_RESERVED_3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_CRC_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint32 * pOBJ_CRC_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_CRC_0
*    OBJ_CRC_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_CRC_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_CRC_0( uint8 objIndx_u8, uint32 * pOBJ_CRC_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_CRC_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_CRC_0_b32;
         * pOBJ_CRC_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_ID_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pOBJ_ID_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_ID_0
*    OBJ_ID_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_ID_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_ID_0( uint8 objIndx_u8, uint8 * pOBJ_ID_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_ID_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_ID_0_b8;
         * pOBJ_ID_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Existence_Probability_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pOBJ_Existence_Probability_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Existence_Probability_0
*    OBJ_Existence_Probability_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Existence_Probability_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Existence_Probability_0( uint8 objIndx_u8, uint8 * pOBJ_Existence_Probability_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Existence_Probability_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Existence_Probability_0_b8;
         * pOBJ_Existence_Probability_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_EXISTENCE_PROBABILITY_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Fusion_Source_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJFusionSource0 * pOBJ_Fusion_Source_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Fusion_Source_0
*    OBJ_Fusion_Source_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Fusion_Source_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Fusion_Source_0( uint8 objIndx_u8, COREOBJvOOBJFusionSource0 * pOBJ_Fusion_Source_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJFusionSource0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Fusion_Source_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Fusion_Source_0_b16;
         * pOBJ_Fusion_Source_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Triggered_SDM_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJTriggeredSDM0 * pOBJ_Triggered_SDM_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Triggered_SDM_0
*    OBJ_Triggered_SDM_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Triggered_SDM_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Triggered_SDM_0( uint8 objIndx_u8, COREOBJvOOBJTriggeredSDM0 * pOBJ_Triggered_SDM_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJTriggeredSDM0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Triggered_SDM_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Triggered_SDM_0_b2;
         * pOBJ_Triggered_SDM_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_TRIGGERED_SDM_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Motion_Category_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJMotionCategory0 * pOBJ_Motion_Category_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Motion_Category_0
*    OBJ_Motion_Category_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Motion_Category_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Motion_Category_0( uint8 objIndx_u8, COREOBJvOOBJMotionCategory0 * pOBJ_Motion_Category_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJMotionCategory0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Motion_Category_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Motion_Category_0_b4;
         * pOBJ_Motion_Category_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_MOTION_CATEGORY_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Moving_IN_Probability_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pOBJ_Moving_IN_Probability_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Moving_IN_Probability_0
*    OBJ_Moving_IN_Probability_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Moving_IN_Probability_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Moving_IN_Probability_0( uint8 objIndx_u8, uint8 * pOBJ_Moving_IN_Probability_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Moving_IN_Probability_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Moving_IN_Probability_0_b7;
         * pOBJ_Moving_IN_Probability_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_MOVING_IN_PROBABILITY_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Object_Age_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Object_Age_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Object_Age_0
*    OBJ_Object_Age_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Object_Age_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Object_Age_0( uint8 objIndx_u8, uint16 * pOBJ_Object_Age_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Object_Age_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Object_Age_0_b11;
         * pOBJ_Object_Age_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Measuring_Status_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJMeasuringStatus0 * pOBJ_Measuring_Status_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Measuring_Status_0
*    OBJ_Measuring_Status_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Measuring_Status_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Measuring_Status_0( uint8 objIndx_u8, COREOBJvOOBJMeasuringStatus0 * pOBJ_Measuring_Status_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJMeasuringStatus0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Measuring_Status_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Measuring_Status_0_b3;
         * pOBJ_Measuring_Status_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Object_Class_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJObjectClass0 * pOBJ_Object_Class_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Object_Class_0
*    OBJ_Object_Class_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Object_Class_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Object_Class_0( uint8 objIndx_u8, COREOBJvOOBJObjectClass0 * pOBJ_Object_Class_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJObjectClass0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Object_Class_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Object_Class_0_b4;
         * pOBJ_Object_Class_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_OBJECT_CLASS_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_Reserved_4_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    boolean * pReserved_4_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_4_0
*    Reserved_4_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_4_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_Reserved_4_0( uint8 objIndx_u8, boolean * pReserved_4_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_4_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].Reserved_4_0_b1;
         * pReserved_4_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_RESERVED_4_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Class_Probability_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pOBJ_Class_Probability_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Class_Probability_0
*    OBJ_Class_Probability_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Class_Probability_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Class_Probability_0( uint8 objIndx_u8, uint8 * pOBJ_Class_Probability_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Class_Probability_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Class_Probability_0_b7;
         * pOBJ_Class_Probability_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_CLASS_PROBABILITY_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Car_Probability_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pOBJ_Car_Probability_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Car_Probability_0
*    OBJ_Car_Probability_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Car_Probability_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Car_Probability_0( uint8 objIndx_u8, uint8 * pOBJ_Car_Probability_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Car_Probability_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Car_Probability_0_b7;
         * pOBJ_Car_Probability_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_CAR_PROBABILITY_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Truck_Probability_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pOBJ_Truck_Probability_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Truck_Probability_0
*    OBJ_Truck_Probability_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Truck_Probability_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Truck_Probability_0( uint8 objIndx_u8, uint8 * pOBJ_Truck_Probability_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Truck_Probability_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Truck_Probability_0_b7;
         * pOBJ_Truck_Probability_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_TRUCK_PROBABILITY_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Bike_Probability_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pOBJ_Bike_Probability_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Bike_Probability_0
*    OBJ_Bike_Probability_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Bike_Probability_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Bike_Probability_0( uint8 objIndx_u8, uint8 * pOBJ_Bike_Probability_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Bike_Probability_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Bike_Probability_0_b7;
         * pOBJ_Bike_Probability_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_BIKE_PROBABILITY_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Camera_Source_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJCameraSource0 * pOBJ_Camera_Source_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Camera_Source_0
*    OBJ_Camera_Source_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Camera_Source_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Camera_Source_0( uint8 objIndx_u8, COREOBJvOOBJCameraSource0 * pOBJ_Camera_Source_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJCameraSource0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Camera_Source_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Camera_Source_0_b4;
         * pOBJ_Camera_Source_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Motion_Status_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJMotionStatus0 * pOBJ_Motion_Status_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Motion_Status_0
*    OBJ_Motion_Status_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Motion_Status_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Motion_Status_0( uint8 objIndx_u8, COREOBJvOOBJMotionStatus0 * pOBJ_Motion_Status_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJMotionStatus0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Motion_Status_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Motion_Status_0_b3;
         * pOBJ_Motion_Status_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_MOTION_STATUS_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Motion_Orientation_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJMotionOrientation0 * pOBJ_Motion_Orientation_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Motion_Orientation_0
*    OBJ_Motion_Orientation_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Motion_Orientation_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Motion_Orientation_0( uint8 objIndx_u8, COREOBJvOOBJMotionOrientation0 * pOBJ_Motion_Orientation_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJMotionOrientation0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Motion_Orientation_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Motion_Orientation_0_b4;
         * pOBJ_Motion_Orientation_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_MOTION_ORIENTATION_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Has_Cut_Lane_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJHasCutLane0 * pOBJ_Has_Cut_Lane_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Has_Cut_Lane_0
*    OBJ_Has_Cut_Lane_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Has_Cut_Lane_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Has_Cut_Lane_0( uint8 objIndx_u8, COREOBJvOOBJHasCutLane0 * pOBJ_Has_Cut_Lane_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJHasCutLane0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Has_Cut_Lane_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Has_Cut_Lane_0_b1;
         * pOBJ_Has_Cut_Lane_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Has_Cut_Path_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJHasCutPath0 * pOBJ_Has_Cut_Path_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Has_Cut_Path_0
*    OBJ_Has_Cut_Path_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Has_Cut_Path_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Has_Cut_Path_0( uint8 objIndx_u8, COREOBJvOOBJHasCutPath0 * pOBJ_Has_Cut_Path_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJHasCutPath0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Has_Cut_Path_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Has_Cut_Path_0_b1;
         * pOBJ_Has_Cut_Path_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Brake_Light_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJBrakeLight0 * pOBJ_Brake_Light_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Brake_Light_0
*    OBJ_Brake_Light_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Brake_Light_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Brake_Light_0( uint8 objIndx_u8, COREOBJvOOBJBrakeLight0 * pOBJ_Brake_Light_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJBrakeLight0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Brake_Light_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Brake_Light_0_b1;
         * pOBJ_Brake_Light_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Turn_Indicator_Right_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJTurnIndicatorRight0 * pOBJ_Turn_Indicator_Right_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Turn_Indicator_Right_0
*    OBJ_Turn_Indicator_Right_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Turn_Indicator_Right_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Turn_Indicator_Right_0( uint8 objIndx_u8, COREOBJvOOBJTurnIndicatorRight0 * pOBJ_Turn_Indicator_Right_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJTurnIndicatorRight0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Turn_Indicator_Right_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Turn_Indicator_Right_0_b1;
         * pOBJ_Turn_Indicator_Right_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Turn_Indicator_Left_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJTurnIndicatorLeft0 * pOBJ_Turn_Indicator_Left_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Turn_Indicator_Left_0
*    OBJ_Turn_Indicator_Left_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Turn_Indicator_Left_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Turn_Indicator_Left_0( uint8 objIndx_u8, COREOBJvOOBJTurnIndicatorLeft0 * pOBJ_Turn_Indicator_Left_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJTurnIndicatorLeft0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Turn_Indicator_Left_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Turn_Indicator_Left_0_b1;
         * pOBJ_Turn_Indicator_Left_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Light_Indicator_Validity_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJLightIndicatorValidity0 * pOBJ_Light_Indicator_Validity_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Light_Indicator_Validity_0
*    OBJ_Light_Indicator_Validity_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Light_Indicator_Validity_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Light_Indicator_Validity_0( uint8 objIndx_u8, COREOBJvOOBJLightIndicatorValidity0 * pOBJ_Light_Indicator_Validity_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJLightIndicatorValidity0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Light_Indicator_Validity_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Light_Indicator_Validity_0_b1;
         * pOBJ_Light_Indicator_Validity_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Right_Out_Of_Image_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJRightOutOfImage0 * pOBJ_Right_Out_Of_Image_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Right_Out_Of_Image_0
*    OBJ_Right_Out_Of_Image_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Right_Out_Of_Image_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Right_Out_Of_Image_0( uint8 objIndx_u8, COREOBJvOOBJRightOutOfImage0 * pOBJ_Right_Out_Of_Image_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJRightOutOfImage0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Right_Out_Of_Image_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Right_Out_Of_Image_0_b1;
         * pOBJ_Right_Out_Of_Image_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Left_Out_Of_Image_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJLeftOutOfImage0 * pOBJ_Left_Out_Of_Image_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Left_Out_Of_Image_0
*    OBJ_Left_Out_Of_Image_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Left_Out_Of_Image_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Left_Out_Of_Image_0( uint8 objIndx_u8, COREOBJvOOBJLeftOutOfImage0 * pOBJ_Left_Out_Of_Image_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJLeftOutOfImage0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Left_Out_Of_Image_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Left_Out_Of_Image_0_b1;
         * pOBJ_Left_Out_Of_Image_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Right_Out_Of_Image_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJRightOutOfImageV0 * pOBJ_Right_Out_Of_Image_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Right_Out_Of_Image_V_0
*    OBJ_Right_Out_Of_Image_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Right_Out_Of_Image_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Right_Out_Of_Image_V_0( uint8 objIndx_u8, COREOBJvOOBJRightOutOfImageV0 * pOBJ_Right_Out_Of_Image_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJRightOutOfImageV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Right_Out_Of_Image_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Right_Out_Of_Image_V_0_b1;
         * pOBJ_Right_Out_Of_Image_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Left_Out_Of_Image_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJLeftOutOfImageV0 * pOBJ_Left_Out_Of_Image_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Left_Out_Of_Image_V_0
*    OBJ_Left_Out_Of_Image_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Left_Out_Of_Image_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Left_Out_Of_Image_V_0( uint8 objIndx_u8, COREOBJvOOBJLeftOutOfImageV0 * pOBJ_Left_Out_Of_Image_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJLeftOutOfImageV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Left_Out_Of_Image_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Left_Out_Of_Image_V_0_b1;
         * pOBJ_Left_Out_Of_Image_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Top_Out_Of_Image_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJTopOutOfImage0 * pOBJ_Top_Out_Of_Image_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Top_Out_Of_Image_0
*    OBJ_Top_Out_Of_Image_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Top_Out_Of_Image_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Top_Out_Of_Image_0( uint8 objIndx_u8, COREOBJvOOBJTopOutOfImage0 * pOBJ_Top_Out_Of_Image_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJTopOutOfImage0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Top_Out_Of_Image_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Top_Out_Of_Image_0_b1;
         * pOBJ_Top_Out_Of_Image_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Bottom_Out_Of_Image_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJBottomOutOfImage0 * pOBJ_Bottom_Out_Of_Image_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Bottom_Out_Of_Image_0
*    OBJ_Bottom_Out_Of_Image_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Bottom_Out_Of_Image_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Bottom_Out_Of_Image_0( uint8 objIndx_u8, COREOBJvOOBJBottomOutOfImage0 * pOBJ_Bottom_Out_Of_Image_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJBottomOutOfImage0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Bottom_Out_Of_Image_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Bottom_Out_Of_Image_0_b1;
         * pOBJ_Bottom_Out_Of_Image_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Top_Out_Of_Image_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJTopOutOfImageV0 * pOBJ_Top_Out_Of_Image_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Top_Out_Of_Image_V_0
*    OBJ_Top_Out_Of_Image_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Top_Out_Of_Image_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Top_Out_Of_Image_V_0( uint8 objIndx_u8, COREOBJvOOBJTopOutOfImageV0 * pOBJ_Top_Out_Of_Image_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJTopOutOfImageV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Top_Out_Of_Image_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Top_Out_Of_Image_V_0_b1;
         * pOBJ_Top_Out_Of_Image_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Bottom_Out_Of_Image_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJBottomOutOfImageV0 * pOBJ_Bottom_Out_Of_Image_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Bottom_Out_Of_Image_V_0
*    OBJ_Bottom_Out_Of_Image_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Bottom_Out_Of_Image_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Bottom_Out_Of_Image_V_0( uint8 objIndx_u8, COREOBJvOOBJBottomOutOfImageV0 * pOBJ_Bottom_Out_Of_Image_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJBottomOutOfImageV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Bottom_Out_Of_Image_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Bottom_Out_Of_Image_V_0_b1;
         * pOBJ_Bottom_Out_Of_Image_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Lane_Assignment_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJLaneAssignment0 * pOBJ_Lane_Assignment_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Lane_Assignment_0
*    OBJ_Lane_Assignment_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Lane_Assignment_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Lane_Assignment_0( uint8 objIndx_u8, COREOBJvOOBJLaneAssignment0 * pOBJ_Lane_Assignment_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJLaneAssignment0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Lane_Assignment_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Lane_Assignment_0_b3;
         * pOBJ_Lane_Assignment_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_LANE_ASSIGNMENT_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Lane_Assignment_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJLaneAssignmentV0 * pOBJ_Lane_Assignment_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Lane_Assignment_V_0
*    OBJ_Lane_Assignment_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Lane_Assignment_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Lane_Assignment_V_0( uint8 objIndx_u8, COREOBJvOOBJLaneAssignmentV0 * pOBJ_Lane_Assignment_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJLaneAssignmentV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Lane_Assignment_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Lane_Assignment_V_0_b1;
         * pOBJ_Lane_Assignment_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Age_Seconds_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pOBJ_Age_Seconds_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Age_Seconds_0
*    OBJ_Age_Seconds_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Age_Seconds_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Age_Seconds_0( uint8 objIndx_u8, uint8 * pOBJ_Age_Seconds_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Age_Seconds_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Age_Seconds_0_b7;
         * pOBJ_Age_Seconds_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_AGE_SECONDS_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Age_Seconds_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAgeSecondsV0 * pOBJ_Age_Seconds_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Age_Seconds_V_0
*    OBJ_Age_Seconds_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Age_Seconds_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Age_Seconds_V_0( uint8 objIndx_u8, COREOBJvOOBJAgeSecondsV0 * pOBJ_Age_Seconds_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJAgeSecondsV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Age_Seconds_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Age_Seconds_V_0_b1;
         * pOBJ_Age_Seconds_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Width_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Width_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Width_0
*    OBJ_Width_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Width_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Width_0( uint8 objIndx_u8, uint16 * pOBJ_Width_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Width_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Width_0_b9;
         * pOBJ_Width_0 = signal_value;
         if( (signal_value >= C_EYEQMSG_COREOBJvO_OBJ_WIDTH_0_RMIN ) 
             && (signal_value <= C_EYEQMSG_COREOBJvO_OBJ_WIDTH_0_RMAX ) )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Width_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJWidthV0 * pOBJ_Width_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Width_V_0
*    OBJ_Width_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Width_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Width_V_0( uint8 objIndx_u8, COREOBJvOOBJWidthV0 * pOBJ_Width_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJWidthV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Width_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Width_V_0_b1;
         * pOBJ_Width_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Width_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Width_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Width_STD_0
*    OBJ_Width_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Width_STD_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Width_STD_0( uint8 objIndx_u8, uint16 * pOBJ_Width_STD_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Width_STD_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Width_STD_0_b11;
         * pOBJ_Width_STD_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_WIDTH_STD_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Width_STD_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJWidthSTDV0 * pOBJ_Width_STD_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Width_STD_V_0
*    OBJ_Width_STD_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Width_STD_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Width_STD_V_0( uint8 objIndx_u8, COREOBJvOOBJWidthSTDV0 * pOBJ_Width_STD_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJWidthSTDV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Width_STD_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Width_STD_V_0_b1;
         * pOBJ_Width_STD_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Length_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Length_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Length_0
*    OBJ_Length_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Length_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Length_0( uint8 objIndx_u8, uint16 * pOBJ_Length_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Length_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Length_0_b9;
         * pOBJ_Length_0 = signal_value;
         if( (signal_value >= C_EYEQMSG_COREOBJvO_OBJ_LENGTH_0_RMIN ) 
             && (signal_value <= C_EYEQMSG_COREOBJvO_OBJ_LENGTH_0_RMAX ) )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Length_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJLengthV0 * pOBJ_Length_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Length_V_0
*    OBJ_Length_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Length_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Length_V_0( uint8 objIndx_u8, COREOBJvOOBJLengthV0 * pOBJ_Length_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJLengthV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Length_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Length_V_0_b1;
         * pOBJ_Length_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Length_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Length_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Length_STD_0
*    OBJ_Length_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Length_STD_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Length_STD_0( uint8 objIndx_u8, uint16 * pOBJ_Length_STD_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Length_STD_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Length_STD_0_b10;
         * pOBJ_Length_STD_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_LENGTH_STD_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Length_STD_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJLengthSTDV0 * pOBJ_Length_STD_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Length_STD_V_0
*    OBJ_Length_STD_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Length_STD_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Length_STD_V_0( uint8 objIndx_u8, COREOBJvOOBJLengthSTDV0 * pOBJ_Length_STD_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJLengthSTDV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Length_STD_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Length_STD_V_0_b1;
         * pOBJ_Length_STD_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Radar_ID_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pOBJ_Radar_ID_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Radar_ID_0
*    OBJ_Radar_ID_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Radar_ID_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Radar_ID_0( uint8 objIndx_u8, uint8 * pOBJ_Radar_ID_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Radar_ID_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Radar_ID_0_b8;
         * pOBJ_Radar_ID_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Height_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Height_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Height_0
*    OBJ_Height_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Height_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Height_0( uint8 objIndx_u8, uint16 * pOBJ_Height_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Height_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Height_0_b9;
         * pOBJ_Height_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_HEIGHT_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Height_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJHeightV0 * pOBJ_Height_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Height_V_0
*    OBJ_Height_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Height_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Height_V_0( uint8 objIndx_u8, COREOBJvOOBJHeightV0 * pOBJ_Height_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJHeightV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Height_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Height_V_0_b1;
         * pOBJ_Height_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_Reserved_5_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_5_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_5_0
*    Reserved_5_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_5_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_Reserved_5_0( uint8 objIndx_u8, uint8 * pReserved_5_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_5_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].Reserved_5_0_b2;
         * pReserved_5_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_RESERVED_5_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Height_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Height_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Height_STD_0
*    OBJ_Height_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Height_STD_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Height_STD_0( uint8 objIndx_u8, uint16 * pOBJ_Height_STD_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Height_STD_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Height_STD_0_b11;
         * pOBJ_Height_STD_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_HEIGHT_STD_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Height_STD_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJHeightSTDV0 * pOBJ_Height_STD_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Height_STD_V_0
*    OBJ_Height_STD_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Height_STD_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Height_STD_V_0( uint8 objIndx_u8, COREOBJvOOBJHeightSTDV0 * pOBJ_Height_STD_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJHeightSTDV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Height_STD_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Height_STD_V_0_b1;
         * pOBJ_Height_STD_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Abs_Long_Velocity_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Abs_Long_Velocity_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Abs_Long_Velocity_0
*    OBJ_Abs_Long_Velocity_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Abs_Long_Velocity_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Abs_Long_Velocity_0( uint8 objIndx_u8, uint16 * pOBJ_Abs_Long_Velocity_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Abs_Long_Velocity_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Abs_Long_Velocity_0_b12;
         * pOBJ_Abs_Long_Velocity_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_VELOCITY_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Abs_Long_Velocity_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAbsLongVelocityV0 * pOBJ_Abs_Long_Velocity_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Abs_Long_Velocity_V_0
*    OBJ_Abs_Long_Velocity_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Abs_Long_Velocity_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Abs_Long_Velocity_V_0( uint8 objIndx_u8, COREOBJvOOBJAbsLongVelocityV0 * pOBJ_Abs_Long_Velocity_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJAbsLongVelocityV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Abs_Long_Velocity_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Abs_Long_Velocity_V_0_b1;
         * pOBJ_Abs_Long_Velocity_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_Reserved_6_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_6_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_6_0
*    Reserved_6_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_6_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_Reserved_6_0( uint8 objIndx_u8, uint8 * pReserved_6_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_6_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].Reserved_6_0_b7;
         * pReserved_6_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_RESERVED_6_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Abs_Long_Velocity_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Abs_Long_Velocity_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Abs_Long_Velocity_STD_0
*    OBJ_Abs_Long_Velocity_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Abs_Long_Velocity_STD_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Abs_Long_Velocity_STD_0( uint8 objIndx_u8, uint16 * pOBJ_Abs_Long_Velocity_STD_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Abs_Long_Velocity_STD_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Abs_Long_Velocity_STD_0_b13;
         * pOBJ_Abs_Long_Velocity_STD_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_VELOCITY_STD_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Abs_Long_Vel_STD_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAbsLongVelSTDV0 * pOBJ_Abs_Long_Vel_STD_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Abs_Long_Vel_STD_V_0
*    OBJ_Abs_Long_Vel_STD_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Abs_Long_Vel_STD_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Abs_Long_Vel_STD_V_0( uint8 objIndx_u8, COREOBJvOOBJAbsLongVelSTDV0 * pOBJ_Abs_Long_Vel_STD_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJAbsLongVelSTDV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Abs_Long_Vel_STD_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Abs_Long_Vel_STD_V_0_b1;
         * pOBJ_Abs_Long_Vel_STD_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Abs_Lat_Velocity_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Abs_Lat_Velocity_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Abs_Lat_Velocity_0
*    OBJ_Abs_Lat_Velocity_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Abs_Lat_Velocity_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Abs_Lat_Velocity_0( uint8 objIndx_u8, uint16 * pOBJ_Abs_Lat_Velocity_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Abs_Lat_Velocity_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Abs_Lat_Velocity_0_b11;
         * pOBJ_Abs_Lat_Velocity_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_VELOCITY_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Abs_Lat_Velocity_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAbsLatVelocityV0 * pOBJ_Abs_Lat_Velocity_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Abs_Lat_Velocity_V_0
*    OBJ_Abs_Lat_Velocity_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Abs_Lat_Velocity_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Abs_Lat_Velocity_V_0( uint8 objIndx_u8, COREOBJvOOBJAbsLatVelocityV0 * pOBJ_Abs_Lat_Velocity_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJAbsLatVelocityV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Abs_Lat_Velocity_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Abs_Lat_Velocity_V_0_b1;
         * pOBJ_Abs_Lat_Velocity_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_Reserved_7_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_7_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_7_0
*    Reserved_7_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_7_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_Reserved_7_0( uint8 objIndx_u8, uint8 * pReserved_7_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_7_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].Reserved_7_0_b6;
         * pReserved_7_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_RESERVED_7_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Abs_Lat_Velocity_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Abs_Lat_Velocity_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Abs_Lat_Velocity_STD_0
*    OBJ_Abs_Lat_Velocity_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Abs_Lat_Velocity_STD_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Abs_Lat_Velocity_STD_0( uint8 objIndx_u8, uint16 * pOBJ_Abs_Lat_Velocity_STD_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Abs_Lat_Velocity_STD_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Abs_Lat_Velocity_STD_0_b13;
         * pOBJ_Abs_Lat_Velocity_STD_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_VELOCITY_STD_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Abs_Lat_Vel_STD_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAbsLatVelSTDV0 * pOBJ_Abs_Lat_Vel_STD_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Abs_Lat_Vel_STD_V_0
*    OBJ_Abs_Lat_Vel_STD_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Abs_Lat_Vel_STD_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Abs_Lat_Vel_STD_V_0( uint8 objIndx_u8, COREOBJvOOBJAbsLatVelSTDV0 * pOBJ_Abs_Lat_Vel_STD_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJAbsLatVelSTDV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Abs_Lat_Vel_STD_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Abs_Lat_Vel_STD_V_0_b1;
         * pOBJ_Abs_Lat_Vel_STD_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Abs_Long_Acc_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Abs_Long_Acc_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Abs_Long_Acc_0
*    OBJ_Abs_Long_Acc_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Abs_Long_Acc_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Abs_Long_Acc_0( uint8 objIndx_u8, uint16 * pOBJ_Abs_Long_Acc_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Abs_Long_Acc_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Abs_Long_Acc_0_b9;
         * pOBJ_Abs_Long_Acc_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_ACC_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Abs_Long_Acc_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAbsLongAccV0 * pOBJ_Abs_Long_Acc_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Abs_Long_Acc_V_0
*    OBJ_Abs_Long_Acc_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Abs_Long_Acc_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Abs_Long_Acc_V_0( uint8 objIndx_u8, COREOBJvOOBJAbsLongAccV0 * pOBJ_Abs_Long_Acc_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJAbsLongAccV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Abs_Long_Acc_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Abs_Long_Acc_V_0_b1;
         * pOBJ_Abs_Long_Acc_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_Reserved_8_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_8_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_8_0
*    Reserved_8_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_8_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_Reserved_8_0( uint8 objIndx_u8, uint8 * pReserved_8_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_8_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].Reserved_8_0_b8;
         * pReserved_8_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_RESERVED_8_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Abs_Long_Acc_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Abs_Long_Acc_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Abs_Long_Acc_STD_0
*    OBJ_Abs_Long_Acc_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Abs_Long_Acc_STD_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Abs_Long_Acc_STD_0( uint8 objIndx_u8, uint16 * pOBJ_Abs_Long_Acc_STD_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Abs_Long_Acc_STD_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Abs_Long_Acc_STD_0_b10;
         * pOBJ_Abs_Long_Acc_STD_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_ABS_LONG_ACC_STD_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Abs_Long_Acc_STD_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAbsLongAccSTDV0 * pOBJ_Abs_Long_Acc_STD_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Abs_Long_Acc_STD_V_0
*    OBJ_Abs_Long_Acc_STD_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Abs_Long_Acc_STD_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Abs_Long_Acc_STD_V_0( uint8 objIndx_u8, COREOBJvOOBJAbsLongAccSTDV0 * pOBJ_Abs_Long_Acc_STD_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJAbsLongAccSTDV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Abs_Long_Acc_STD_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Abs_Long_Acc_STD_V_0_b1;
         * pOBJ_Abs_Long_Acc_STD_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Abs_Lat_Acc_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Abs_Lat_Acc_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Abs_Lat_Acc_0
*    OBJ_Abs_Lat_Acc_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Abs_Lat_Acc_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Abs_Lat_Acc_0( uint8 objIndx_u8, uint16 * pOBJ_Abs_Lat_Acc_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Abs_Lat_Acc_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Abs_Lat_Acc_0_b9;
         * pOBJ_Abs_Lat_Acc_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_ACC_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Abs_Lat_Acc_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAbsLatAccV0 * pOBJ_Abs_Lat_Acc_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Abs_Lat_Acc_V_0
*    OBJ_Abs_Lat_Acc_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Abs_Lat_Acc_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Abs_Lat_Acc_V_0( uint8 objIndx_u8, COREOBJvOOBJAbsLatAccV0 * pOBJ_Abs_Lat_Acc_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJAbsLatAccV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Abs_Lat_Acc_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Abs_Lat_Acc_V_0_b1;
         * pOBJ_Abs_Lat_Acc_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Abs_Lat_Acc_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Abs_Lat_Acc_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Abs_Lat_Acc_STD_0
*    OBJ_Abs_Lat_Acc_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Abs_Lat_Acc_STD_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Abs_Lat_Acc_STD_0( uint8 objIndx_u8, uint16 * pOBJ_Abs_Lat_Acc_STD_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Abs_Lat_Acc_STD_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Abs_Lat_Acc_STD_0_b10;
         * pOBJ_Abs_Lat_Acc_STD_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_ABS_LAT_ACC_STD_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Abs_Lat_Acc_STD_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAbsLatAccSTDV0 * pOBJ_Abs_Lat_Acc_STD_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Abs_Lat_Acc_STD_V_0
*    OBJ_Abs_Lat_Acc_STD_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Abs_Lat_Acc_STD_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Abs_Lat_Acc_STD_V_0( uint8 objIndx_u8, COREOBJvOOBJAbsLatAccSTDV0 * pOBJ_Abs_Lat_Acc_STD_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJAbsLatAccSTDV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Abs_Lat_Acc_STD_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Abs_Lat_Acc_STD_V_0_b1;
         * pOBJ_Abs_Lat_Acc_STD_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Abs_Acceleration_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Abs_Acceleration_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Abs_Acceleration_0
*    OBJ_Abs_Acceleration_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Abs_Acceleration_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Abs_Acceleration_0( uint8 objIndx_u8, uint16 * pOBJ_Abs_Acceleration_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Abs_Acceleration_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Abs_Acceleration_0_b9;
         * pOBJ_Abs_Acceleration_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_ABS_ACCELERATION_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Abs_Acceleration_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAbsAccelerationV0 * pOBJ_Abs_Acceleration_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Abs_Acceleration_V_0
*    OBJ_Abs_Acceleration_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Abs_Acceleration_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Abs_Acceleration_V_0( uint8 objIndx_u8, COREOBJvOOBJAbsAccelerationV0 * pOBJ_Abs_Acceleration_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJAbsAccelerationV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Abs_Acceleration_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Abs_Acceleration_V_0_b1;
         * pOBJ_Abs_Acceleration_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Abs_Acc_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Abs_Acc_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Abs_Acc_STD_0
*    OBJ_Abs_Acc_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Abs_Acc_STD_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Abs_Acc_STD_0( uint8 objIndx_u8, uint16 * pOBJ_Abs_Acc_STD_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Abs_Acc_STD_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Abs_Acc_STD_0_b10;
         * pOBJ_Abs_Acc_STD_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_ABS_ACC_STD_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Abs_Acc_STD_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAbsAccSTDV0 * pOBJ_Abs_Acc_STD_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Abs_Acc_STD_V_0
*    OBJ_Abs_Acc_STD_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Abs_Acc_STD_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Abs_Acc_STD_V_0( uint8 objIndx_u8, COREOBJvOOBJAbsAccSTDV0 * pOBJ_Abs_Acc_STD_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJAbsAccSTDV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Abs_Acc_STD_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Abs_Acc_STD_V_0_b1;
         * pOBJ_Abs_Acc_STD_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Inv_TTC_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Inv_TTC_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Inv_TTC_0
*    OBJ_Inv_TTC_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Inv_TTC_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Inv_TTC_0( uint8 objIndx_u8, uint16 * pOBJ_Inv_TTC_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Inv_TTC_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Inv_TTC_0_b11;
         * pOBJ_Inv_TTC_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_INV_TTC_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Inv_TTC_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJInvTTCV0 * pOBJ_Inv_TTC_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Inv_TTC_V_0
*    OBJ_Inv_TTC_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Inv_TTC_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Inv_TTC_V_0( uint8 objIndx_u8, COREOBJvOOBJInvTTCV0 * pOBJ_Inv_TTC_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJInvTTCV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Inv_TTC_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Inv_TTC_V_0_b1;
         * pOBJ_Inv_TTC_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Inv_TTC_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Inv_TTC_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Inv_TTC_STD_0
*    OBJ_Inv_TTC_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Inv_TTC_STD_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Inv_TTC_STD_0( uint8 objIndx_u8, uint16 * pOBJ_Inv_TTC_STD_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Inv_TTC_STD_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Inv_TTC_STD_0_b12;
         * pOBJ_Inv_TTC_STD_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_INV_TTC_STD_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Inv_TTC_STD_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJInvTTCSTDV0 * pOBJ_Inv_TTC_STD_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Inv_TTC_STD_V_0
*    OBJ_Inv_TTC_STD_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Inv_TTC_STD_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Inv_TTC_STD_V_0( uint8 objIndx_u8, COREOBJvOOBJInvTTCSTDV0 * pOBJ_Inv_TTC_STD_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJInvTTCSTDV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Inv_TTC_STD_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Inv_TTC_STD_V_0_b1;
         * pOBJ_Inv_TTC_STD_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Relative_Long_Acc_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Relative_Long_Acc_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Relative_Long_Acc_0
*    OBJ_Relative_Long_Acc_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Relative_Long_Acc_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Relative_Long_Acc_0( uint8 objIndx_u8, uint16 * pOBJ_Relative_Long_Acc_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Relative_Long_Acc_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Relative_Long_Acc_0_b10;
         * pOBJ_Relative_Long_Acc_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LONG_ACC_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Relative_Long_Acc_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJRelativeLongAccV0 * pOBJ_Relative_Long_Acc_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Relative_Long_Acc_V_0
*    OBJ_Relative_Long_Acc_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Relative_Long_Acc_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Relative_Long_Acc_V_0( uint8 objIndx_u8, COREOBJvOOBJRelativeLongAccV0 * pOBJ_Relative_Long_Acc_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJRelativeLongAccV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Relative_Long_Acc_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Relative_Long_Acc_V_0_b1;
         * pOBJ_Relative_Long_Acc_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_Reserved_9_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_9_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_9_0
*    Reserved_9_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_9_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_Reserved_9_0( uint8 objIndx_u8, uint8 * pReserved_9_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_9_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].Reserved_9_0_b7;
         * pReserved_9_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_RESERVED_9_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Relative_Long_Acc_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Relative_Long_Acc_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Relative_Long_Acc_STD_0
*    OBJ_Relative_Long_Acc_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Relative_Long_Acc_STD_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Relative_Long_Acc_STD_0( uint8 objIndx_u8, uint16 * pOBJ_Relative_Long_Acc_STD_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Relative_Long_Acc_STD_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Relative_Long_Acc_STD_0_b10;
         * pOBJ_Relative_Long_Acc_STD_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LONG_ACC_STD_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Rel_Long_Acc_STD_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJRelLongAccSTDV0 * pOBJ_Rel_Long_Acc_STD_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Rel_Long_Acc_STD_V_0
*    OBJ_Rel_Long_Acc_STD_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Rel_Long_Acc_STD_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Rel_Long_Acc_STD_V_0( uint8 objIndx_u8, COREOBJvOOBJRelLongAccSTDV0 * pOBJ_Rel_Long_Acc_STD_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJRelLongAccSTDV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Rel_Long_Acc_STD_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Rel_Long_Acc_STD_V_0_b1;
         * pOBJ_Rel_Long_Acc_STD_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Relative_Long_Velocity_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Relative_Long_Velocity_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Relative_Long_Velocity_0
*    OBJ_Relative_Long_Velocity_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Relative_Long_Velocity_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Relative_Long_Velocity_0( uint8 objIndx_u8, uint16 * pOBJ_Relative_Long_Velocity_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Relative_Long_Velocity_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Relative_Long_Velocity_0_b13;
         * pOBJ_Relative_Long_Velocity_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LONG_VELOCITY_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Relative_Long_Velocity_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJRelativeLongVelocityV0 * pOBJ_Relative_Long_Velocity_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Relative_Long_Velocity_V_0
*    OBJ_Relative_Long_Velocity_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Relative_Long_Velocity_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Relative_Long_Velocity_V_0( uint8 objIndx_u8, COREOBJvOOBJRelativeLongVelocityV0 * pOBJ_Relative_Long_Velocity_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJRelativeLongVelocityV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Relative_Long_Velocity_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Relative_Long_Velocity_V_0_b1;
         * pOBJ_Relative_Long_Velocity_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_Reserved_10_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_10_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_10_0
*    Reserved_10_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_10_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_Reserved_10_0( uint8 objIndx_u8, uint8 * pReserved_10_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_10_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].Reserved_10_0_b7;
         * pReserved_10_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_RESERVED_10_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Relative_Long_Vel_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Relative_Long_Vel_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Relative_Long_Vel_STD_0
*    OBJ_Relative_Long_Vel_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Relative_Long_Vel_STD_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Relative_Long_Vel_STD_0( uint8 objIndx_u8, uint16 * pOBJ_Relative_Long_Vel_STD_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Relative_Long_Vel_STD_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Relative_Long_Vel_STD_0_b14;
         * pOBJ_Relative_Long_Vel_STD_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LONG_VEL_STD_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Rel_Long_Vel_STD_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJRelLongVelSTDV0 * pOBJ_Rel_Long_Vel_STD_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Rel_Long_Vel_STD_V_0
*    OBJ_Rel_Long_Vel_STD_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Rel_Long_Vel_STD_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Rel_Long_Vel_STD_V_0( uint8 objIndx_u8, COREOBJvOOBJRelLongVelSTDV0 * pOBJ_Rel_Long_Vel_STD_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJRelLongVelSTDV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Rel_Long_Vel_STD_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Rel_Long_Vel_STD_V_0_b1;
         * pOBJ_Rel_Long_Vel_STD_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Relative_Lat_Velocity_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Relative_Lat_Velocity_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Relative_Lat_Velocity_0
*    OBJ_Relative_Lat_Velocity_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Relative_Lat_Velocity_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Relative_Lat_Velocity_0( uint8 objIndx_u8, uint16 * pOBJ_Relative_Lat_Velocity_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Relative_Lat_Velocity_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Relative_Lat_Velocity_0_b11;
         * pOBJ_Relative_Lat_Velocity_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LAT_VELOCITY_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Relative_Lat_Velocity_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJRelativeLatVelocityV0 * pOBJ_Relative_Lat_Velocity_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Relative_Lat_Velocity_V_0
*    OBJ_Relative_Lat_Velocity_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Relative_Lat_Velocity_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Relative_Lat_Velocity_V_0( uint8 objIndx_u8, COREOBJvOOBJRelativeLatVelocityV0 * pOBJ_Relative_Lat_Velocity_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJRelativeLatVelocityV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Relative_Lat_Velocity_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Relative_Lat_Velocity_V_0_b1;
         * pOBJ_Relative_Lat_Velocity_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_Reserved_11_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_11_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_11_0
*    Reserved_11_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_11_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_Reserved_11_0( uint8 objIndx_u8, uint8 * pReserved_11_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_11_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].Reserved_11_0_b5;
         * pReserved_11_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_RESERVED_11_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Relative_Lat_Velocity_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Relative_Lat_Velocity_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Relative_Lat_Velocity_STD_0
*    OBJ_Relative_Lat_Velocity_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Relative_Lat_Velocity_STD_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Relative_Lat_Velocity_STD_0( uint8 objIndx_u8, uint16 * pOBJ_Relative_Lat_Velocity_STD_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Relative_Lat_Velocity_STD_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Relative_Lat_Velocity_STD_0_b13;
         * pOBJ_Relative_Lat_Velocity_STD_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_RELATIVE_LAT_VELOCITY_STD_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Rel_Lat_Vel_STD_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJRelLatVelSTDV0 * pOBJ_Rel_Lat_Vel_STD_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Rel_Lat_Vel_STD_V_0
*    OBJ_Rel_Lat_Vel_STD_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Rel_Lat_Vel_STD_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Rel_Lat_Vel_STD_V_0( uint8 objIndx_u8, COREOBJvOOBJRelLatVelSTDV0 * pOBJ_Rel_Lat_Vel_STD_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJRelLatVelSTDV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Rel_Lat_Vel_STD_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Rel_Lat_Vel_STD_V_0_b1;
         * pOBJ_Rel_Lat_Vel_STD_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Long_Distance_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Long_Distance_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Long_Distance_0
*    OBJ_Long_Distance_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Long_Distance_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Long_Distance_0( uint8 objIndx_u8, uint16 * pOBJ_Long_Distance_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Long_Distance_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Long_Distance_0_b14;
         * pOBJ_Long_Distance_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_LONG_DISTANCE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Long_Distance_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJLongDistanceV0 * pOBJ_Long_Distance_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Long_Distance_V_0
*    OBJ_Long_Distance_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Long_Distance_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Long_Distance_V_0( uint8 objIndx_u8, COREOBJvOOBJLongDistanceV0 * pOBJ_Long_Distance_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJLongDistanceV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Long_Distance_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Long_Distance_V_0_b1;
         * pOBJ_Long_Distance_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_Reserved_12_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_12_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_12_0
*    Reserved_12_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_12_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_Reserved_12_0( uint8 objIndx_u8, uint8 * pReserved_12_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_12_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].Reserved_12_0_b3;
         * pReserved_12_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_RESERVED_12_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Long_Distance_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Long_Distance_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Long_Distance_STD_0
*    OBJ_Long_Distance_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Long_Distance_STD_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Long_Distance_STD_0( uint8 objIndx_u8, uint16 * pOBJ_Long_Distance_STD_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Long_Distance_STD_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Long_Distance_STD_0_b15;
         * pOBJ_Long_Distance_STD_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_LONG_DISTANCE_STD_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Long_Distance_STD_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJLongDistanceSTDV0 * pOBJ_Long_Distance_STD_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Long_Distance_STD_V_0
*    OBJ_Long_Distance_STD_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Long_Distance_STD_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Long_Distance_STD_V_0( uint8 objIndx_u8, COREOBJvOOBJLongDistanceSTDV0 * pOBJ_Long_Distance_STD_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJLongDistanceSTDV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Long_Distance_STD_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Long_Distance_STD_V_0_b1;
         * pOBJ_Long_Distance_STD_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Lat_Distance_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Lat_Distance_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Lat_Distance_0
*    OBJ_Lat_Distance_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Lat_Distance_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Lat_Distance_0( uint8 objIndx_u8, uint16 * pOBJ_Lat_Distance_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Lat_Distance_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Lat_Distance_0_b12;
         * pOBJ_Lat_Distance_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_LAT_DISTANCE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Lat_Distance_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJLatDistanceV0 * pOBJ_Lat_Distance_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Lat_Distance_V_0
*    OBJ_Lat_Distance_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Lat_Distance_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Lat_Distance_V_0( uint8 objIndx_u8, COREOBJvOOBJLatDistanceV0 * pOBJ_Lat_Distance_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJLatDistanceV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Lat_Distance_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Lat_Distance_V_0_b1;
         * pOBJ_Lat_Distance_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_Reserved_13_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_13_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_13_0
*    Reserved_13_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_13_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_Reserved_13_0( uint8 objIndx_u8, uint8 * pReserved_13_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_13_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].Reserved_13_0_b3;
         * pReserved_13_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_RESERVED_13_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Lat_Distance_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Lat_Distance_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Lat_Distance_STD_0
*    OBJ_Lat_Distance_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Lat_Distance_STD_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Lat_Distance_STD_0( uint8 objIndx_u8, uint16 * pOBJ_Lat_Distance_STD_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Lat_Distance_STD_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Lat_Distance_STD_0_b14;
         * pOBJ_Lat_Distance_STD_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_LAT_DISTANCE_STD_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Lat_Distance_STD_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJLatDistanceSTDV0 * pOBJ_Lat_Distance_STD_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Lat_Distance_STD_V_0
*    OBJ_Lat_Distance_STD_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Lat_Distance_STD_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Lat_Distance_STD_V_0( uint8 objIndx_u8, COREOBJvOOBJLatDistanceSTDV0 * pOBJ_Lat_Distance_STD_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJLatDistanceSTDV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Lat_Distance_STD_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Lat_Distance_STD_V_0_b1;
         * pOBJ_Lat_Distance_STD_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Absolute_Speed_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Absolute_Speed_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Absolute_Speed_0
*    OBJ_Absolute_Speed_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Absolute_Speed_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Absolute_Speed_0( uint8 objIndx_u8, uint16 * pOBJ_Absolute_Speed_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Absolute_Speed_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Absolute_Speed_0_b12;
         * pOBJ_Absolute_Speed_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_ABSOLUTE_SPEED_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Absolute_Speed_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAbsoluteSpeedV0 * pOBJ_Absolute_Speed_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Absolute_Speed_V_0
*    OBJ_Absolute_Speed_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Absolute_Speed_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Absolute_Speed_V_0( uint8 objIndx_u8, COREOBJvOOBJAbsoluteSpeedV0 * pOBJ_Absolute_Speed_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJAbsoluteSpeedV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Absolute_Speed_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Absolute_Speed_V_0_b1;
         * pOBJ_Absolute_Speed_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_Reserved_14_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_14_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_14_0
*    Reserved_14_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_14_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_Reserved_14_0( uint8 objIndx_u8, uint8 * pReserved_14_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_14_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].Reserved_14_0_b4;
         * pReserved_14_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_RESERVED_14_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Absolute_Speed_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Absolute_Speed_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Absolute_Speed_STD_0
*    OBJ_Absolute_Speed_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Absolute_Speed_STD_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Absolute_Speed_STD_0( uint8 objIndx_u8, uint16 * pOBJ_Absolute_Speed_STD_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Absolute_Speed_STD_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Absolute_Speed_STD_0_b13;
         * pOBJ_Absolute_Speed_STD_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_ABSOLUTE_SPEED_STD_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Absolute_Speed_STD_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAbsoluteSpeedSTDV0 * pOBJ_Absolute_Speed_STD_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Absolute_Speed_STD_V_0
*    OBJ_Absolute_Speed_STD_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Absolute_Speed_STD_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Absolute_Speed_STD_V_0( uint8 objIndx_u8, COREOBJvOOBJAbsoluteSpeedSTDV0 * pOBJ_Absolute_Speed_STD_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJAbsoluteSpeedSTDV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Absolute_Speed_STD_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Absolute_Speed_STD_V_0_b1;
         * pOBJ_Absolute_Speed_STD_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Heading_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Heading_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Heading_0
*    OBJ_Heading_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Heading_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Heading_0( uint8 objIndx_u8, uint16 * pOBJ_Heading_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Heading_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Heading_0_b10;
         * pOBJ_Heading_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_HEADING_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Heading_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJHeadingV0 * pOBJ_Heading_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Heading_V_0
*    OBJ_Heading_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Heading_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Heading_V_0( uint8 objIndx_u8, COREOBJvOOBJHeadingV0 * pOBJ_Heading_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJHeadingV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Heading_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Heading_V_0_b1;
         * pOBJ_Heading_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_Reserved_15_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_15_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_15_0
*    Reserved_15_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_15_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_Reserved_15_0( uint8 objIndx_u8, uint8 * pReserved_15_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_15_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].Reserved_15_0_b7;
         * pReserved_15_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_RESERVED_15_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Heading_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Heading_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Heading_STD_0
*    OBJ_Heading_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Heading_STD_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Heading_STD_0( uint8 objIndx_u8, uint16 * pOBJ_Heading_STD_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Heading_STD_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Heading_STD_0_b15;
         * pOBJ_Heading_STD_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_HEADING_STD_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Heading_STD_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJHeadingSTDV0 * pOBJ_Heading_STD_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Heading_STD_V_0
*    OBJ_Heading_STD_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Heading_STD_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Heading_STD_V_0( uint8 objIndx_u8, COREOBJvOOBJHeadingSTDV0 * pOBJ_Heading_STD_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJHeadingSTDV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Heading_STD_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Heading_STD_V_0_b1;
         * pOBJ_Heading_STD_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Rate_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Angle_Rate_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Rate_STD_0
*    OBJ_Angle_Rate_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Rate_STD_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Rate_STD_0( uint8 objIndx_u8, uint16 * pOBJ_Angle_Rate_STD_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Angle_Rate_STD_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Angle_Rate_STD_0_b15;
         * pOBJ_Angle_Rate_STD_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RATE_STD_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Rate_STD_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAngleRateSTDV0 * pOBJ_Angle_Rate_STD_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Rate_STD_V_0
*    OBJ_Angle_Rate_STD_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Rate_STD_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Rate_STD_V_0( uint8 objIndx_u8, COREOBJvOOBJAngleRateSTDV0 * pOBJ_Angle_Rate_STD_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJAngleRateSTDV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Angle_Rate_STD_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Angle_Rate_STD_V_0_b1;
         * pOBJ_Angle_Rate_STD_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Rate_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Angle_Rate_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Rate_0
*    OBJ_Angle_Rate_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Rate_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Rate_0( uint8 objIndx_u8, uint16 * pOBJ_Angle_Rate_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Angle_Rate_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Angle_Rate_0_b12;
         * pOBJ_Angle_Rate_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RATE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Rate_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAngleRateV0 * pOBJ_Angle_Rate_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Rate_V_0
*    OBJ_Angle_Rate_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Rate_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Rate_V_0( uint8 objIndx_u8, COREOBJvOOBJAngleRateV0 * pOBJ_Angle_Rate_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJAngleRateV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Angle_Rate_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Angle_Rate_V_0_b1;
         * pOBJ_Angle_Rate_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Right_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Angle_Right_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Right_0
*    OBJ_Angle_Right_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Right_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Right_0( uint8 objIndx_u8, uint16 * pOBJ_Angle_Right_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Angle_Right_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Angle_Right_0_b14;
         * pOBJ_Angle_Right_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RIGHT_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Right_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAngleRightV0 * pOBJ_Angle_Right_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Right_V_0
*    OBJ_Angle_Right_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Right_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Right_V_0( uint8 objIndx_u8, COREOBJvOOBJAngleRightV0 * pOBJ_Angle_Right_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJAngleRightV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Angle_Right_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Angle_Right_V_0_b1;
         * pOBJ_Angle_Right_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_Reserved_16_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_16_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_16_0
*    Reserved_16_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_16_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_Reserved_16_0( uint8 objIndx_u8, uint8 * pReserved_16_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_16_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].Reserved_16_0_b4;
         * pReserved_16_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_RESERVED_16_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Right_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Angle_Right_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Right_STD_0
*    OBJ_Angle_Right_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Right_STD_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Right_STD_0( uint8 objIndx_u8, uint16 * pOBJ_Angle_Right_STD_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Angle_Right_STD_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Angle_Right_STD_0_b14;
         * pOBJ_Angle_Right_STD_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_ANGLE_RIGHT_STD_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Right_STD_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAngleRightSTDV0 * pOBJ_Angle_Right_STD_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Right_STD_V_0
*    OBJ_Angle_Right_STD_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Right_STD_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Right_STD_V_0( uint8 objIndx_u8, COREOBJvOOBJAngleRightSTDV0 * pOBJ_Angle_Right_STD_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJAngleRightSTDV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Angle_Right_STD_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Angle_Right_STD_V_0_b1;
         * pOBJ_Angle_Right_STD_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Left_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Angle_Left_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Left_0
*    OBJ_Angle_Left_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Left_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Left_0( uint8 objIndx_u8, uint16 * pOBJ_Angle_Left_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Angle_Left_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Angle_Left_0_b14;
         * pOBJ_Angle_Left_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_ANGLE_LEFT_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Left_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAngleLeftV0 * pOBJ_Angle_Left_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Left_V_0
*    OBJ_Angle_Left_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Left_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Left_V_0( uint8 objIndx_u8, COREOBJvOOBJAngleLeftV0 * pOBJ_Angle_Left_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJAngleLeftV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Angle_Left_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Angle_Left_V_0_b1;
         * pOBJ_Angle_Left_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_Reserved_17_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_17_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_17_0
*    Reserved_17_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_17_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_Reserved_17_0( uint8 objIndx_u8, uint8 * pReserved_17_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_17_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].Reserved_17_0_b2;
         * pReserved_17_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_RESERVED_17_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Left_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Angle_Left_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Left_STD_0
*    OBJ_Angle_Left_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Left_STD_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Left_STD_0( uint8 objIndx_u8, uint16 * pOBJ_Angle_Left_STD_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Angle_Left_STD_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Angle_Left_STD_0_b14;
         * pOBJ_Angle_Left_STD_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_ANGLE_LEFT_STD_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Left_STD_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAngleLeftSTDV0 * pOBJ_Angle_Left_STD_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Left_STD_V_0
*    OBJ_Angle_Left_STD_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Left_STD_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Left_STD_V_0( uint8 objIndx_u8, COREOBJvOOBJAngleLeftSTDV0 * pOBJ_Angle_Left_STD_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJAngleLeftSTDV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Angle_Left_STD_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Angle_Left_STD_V_0_b1;
         * pOBJ_Angle_Left_STD_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Side_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Angle_Side_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Side_0
*    OBJ_Angle_Side_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Side_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Side_0( uint8 objIndx_u8, uint16 * pOBJ_Angle_Side_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Angle_Side_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Angle_Side_0_b14;
         * pOBJ_Angle_Side_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_ANGLE_SIDE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Side_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAngleSideV0 * pOBJ_Angle_Side_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Side_V_0
*    OBJ_Angle_Side_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Side_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Side_V_0( uint8 objIndx_u8, COREOBJvOOBJAngleSideV0 * pOBJ_Angle_Side_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJAngleSideV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Angle_Side_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Angle_Side_V_0_b1;
         * pOBJ_Angle_Side_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_Reserved_18_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_18_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_18_0
*    Reserved_18_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_18_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_Reserved_18_0( uint8 objIndx_u8, uint8 * pReserved_18_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_18_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].Reserved_18_0_b2;
         * pReserved_18_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_RESERVED_18_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Side_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Angle_Side_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Side_STD_0
*    OBJ_Angle_Side_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Side_STD_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Side_STD_0( uint8 objIndx_u8, uint16 * pOBJ_Angle_Side_STD_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Angle_Side_STD_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Angle_Side_STD_0_b14;
         * pOBJ_Angle_Side_STD_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_ANGLE_SIDE_STD_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Side_STD_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAngleSideSTDV0 * pOBJ_Angle_Side_STD_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Side_STD_V_0
*    OBJ_Angle_Side_STD_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Side_STD_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Side_STD_V_0( uint8 objIndx_u8, COREOBJvOOBJAngleSideSTDV0 * pOBJ_Angle_Side_STD_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJAngleSideSTDV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Angle_Side_STD_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Angle_Side_STD_V_0_b1;
         * pOBJ_Angle_Side_STD_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Mid_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAngleMidV0 * pOBJ_Angle_Mid_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Mid_V_0
*    OBJ_Angle_Mid_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Mid_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Mid_V_0( uint8 objIndx_u8, COREOBJvOOBJAngleMidV0 * pOBJ_Angle_Mid_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJAngleMidV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Angle_Mid_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Angle_Mid_V_0_b1;
         * pOBJ_Angle_Mid_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Mid_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Angle_Mid_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Mid_0
*    OBJ_Angle_Mid_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Mid_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Mid_0( uint8 objIndx_u8, uint16 * pOBJ_Angle_Mid_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Angle_Mid_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Angle_Mid_0_b14;
         * pOBJ_Angle_Mid_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_ANGLE_MID_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_Reserved_19_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_19_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_19_0
*    Reserved_19_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_19_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_Reserved_19_0( uint8 objIndx_u8, uint8 * pReserved_19_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_19_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].Reserved_19_0_b2;
         * pReserved_19_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_RESERVED_19_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Mid_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Angle_Mid_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Mid_STD_0
*    OBJ_Angle_Mid_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Mid_STD_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Mid_STD_0( uint8 objIndx_u8, uint16 * pOBJ_Angle_Mid_STD_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Angle_Mid_STD_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Angle_Mid_STD_0_b14;
         * pOBJ_Angle_Mid_STD_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_ANGLE_MID_STD_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Mid_STD_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAngleMidSTDV0 * pOBJ_Angle_Mid_STD_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Mid_STD_V_0
*    OBJ_Angle_Mid_STD_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Mid_STD_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Mid_STD_V_0( uint8 objIndx_u8, COREOBJvOOBJAngleMidSTDV0 * pOBJ_Angle_Mid_STD_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJAngleMidSTDV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Angle_Mid_STD_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Angle_Mid_STD_V_0_b1;
         * pOBJ_Angle_Mid_STD_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Bottom_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAngleBottomV0 * pOBJ_Angle_Bottom_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Bottom_V_0
*    OBJ_Angle_Bottom_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Bottom_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Bottom_V_0( uint8 objIndx_u8, COREOBJvOOBJAngleBottomV0 * pOBJ_Angle_Bottom_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJAngleBottomV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Angle_Bottom_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Angle_Bottom_V_0_b1;
         * pOBJ_Angle_Bottom_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Bottom_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Angle_Bottom_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Bottom_0
*    OBJ_Angle_Bottom_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Bottom_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Bottom_0( uint8 objIndx_u8, uint16 * pOBJ_Angle_Bottom_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Angle_Bottom_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Angle_Bottom_0_b14;
         * pOBJ_Angle_Bottom_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_ANGLE_BOTTOM_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_Reserved_20_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_20_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_20_0
*    Reserved_20_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_20_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_Reserved_20_0( uint8 objIndx_u8, uint8 * pReserved_20_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_20_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].Reserved_20_0_b2;
         * pReserved_20_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_RESERVED_20_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Bottom_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Angle_Bottom_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Bottom_STD_0
*    OBJ_Angle_Bottom_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Bottom_STD_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Bottom_STD_0( uint8 objIndx_u8, uint16 * pOBJ_Angle_Bottom_STD_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Angle_Bottom_STD_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Angle_Bottom_STD_0_b14;
         * pOBJ_Angle_Bottom_STD_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_ANGLE_BOTTOM_STD_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Bottom_STD_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAngleBottomSTDV0 * pOBJ_Angle_Bottom_STD_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Bottom_STD_V_0
*    OBJ_Angle_Bottom_STD_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Bottom_STD_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Bottom_STD_V_0( uint8 objIndx_u8, COREOBJvOOBJAngleBottomSTDV0 * pOBJ_Angle_Bottom_STD_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJAngleBottomSTDV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Angle_Bottom_STD_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Angle_Bottom_STD_V_0_b1;
         * pOBJ_Angle_Bottom_STD_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Visibility_Side_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJVisibilitySideV0 * pOBJ_Visibility_Side_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Visibility_Side_V_0
*    OBJ_Visibility_Side_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Visibility_Side_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Visibility_Side_V_0( uint8 objIndx_u8, COREOBJvOOBJVisibilitySideV0 * pOBJ_Visibility_Side_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJVisibilitySideV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Visibility_Side_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Visibility_Side_V_0_b1;
         * pOBJ_Visibility_Side_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Visibility_Side_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJVisibilitySide0 * pOBJ_Visibility_Side_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Visibility_Side_0
*    OBJ_Visibility_Side_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Visibility_Side_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Visibility_Side_0( uint8 objIndx_u8, COREOBJvOOBJVisibilitySide0 * pOBJ_Visibility_Side_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJVisibilitySide0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Visibility_Side_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Visibility_Side_0_b2;
         * pOBJ_Visibility_Side_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_VISIBILITY_SIDE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Is_In_Drivable_Area_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJIsInDrivableArea0 * pOBJ_Is_In_Drivable_Area_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Is_In_Drivable_Area_0
*    OBJ_Is_In_Drivable_Area_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Is_In_Drivable_Area_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Is_In_Drivable_Area_0( uint8 objIndx_u8, COREOBJvOOBJIsInDrivableArea0 * pOBJ_Is_In_Drivable_Area_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJIsInDrivableArea0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Is_In_Drivable_Area_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Is_In_Drivable_Area_0_b1;
         * pOBJ_Is_In_Drivable_Area_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Is_In_Drivable_Area_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJIsInDrivableAreaV0 * pOBJ_Is_In_Drivable_Area_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Is_In_Drivable_Area_V_0
*    OBJ_Is_In_Drivable_Area_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Is_In_Drivable_Area_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Is_In_Drivable_Area_V_0( uint8 objIndx_u8, COREOBJvOOBJIsInDrivableAreaV0 * pOBJ_Is_In_Drivable_Area_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJIsInDrivableAreaV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Is_In_Drivable_Area_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Is_In_Drivable_Area_V_0_b1;
         * pOBJ_Is_In_Drivable_Area_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Is_VeryClose_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJIsVeryCloseV0 * pOBJ_Is_VeryClose_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Is_VeryClose_V_0
*    OBJ_Is_VeryClose_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Is_VeryClose_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Is_VeryClose_V_0( uint8 objIndx_u8, COREOBJvOOBJIsVeryCloseV0 * pOBJ_Is_VeryClose_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJIsVeryCloseV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Is_VeryClose_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Is_VeryClose_V_0_b1;
         * pOBJ_Is_VeryClose_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Is_VeryClose_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJIsVeryClose0 * pOBJ_Is_VeryClose_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Is_VeryClose_0
*    OBJ_Is_VeryClose_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Is_VeryClose_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Is_VeryClose_0( uint8 objIndx_u8, COREOBJvOOBJIsVeryClose0 * pOBJ_Is_VeryClose_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJIsVeryClose0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Is_VeryClose_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Is_VeryClose_0_b1;
         * pOBJ_Is_VeryClose_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Occlusion_RL_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJOcclusionRL0 * pOBJ_Occlusion_RL_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Occlusion_RL_0
*    OBJ_Occlusion_RL_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Occlusion_RL_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Occlusion_RL_0( uint8 objIndx_u8, COREOBJvOOBJOcclusionRL0 * pOBJ_Occlusion_RL_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJOcclusionRL0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Occlusion_RL_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Occlusion_RL_0_b2;
         * pOBJ_Occlusion_RL_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_OCCLUSION_RL_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Occlusion_RR_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJOcclusionRR0 * pOBJ_Occlusion_RR_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Occlusion_RR_0
*    OBJ_Occlusion_RR_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Occlusion_RR_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Occlusion_RR_0( uint8 objIndx_u8, COREOBJvOOBJOcclusionRR0 * pOBJ_Occlusion_RR_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJOcclusionRR0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Occlusion_RR_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Occlusion_RR_0_b2;
         * pOBJ_Occlusion_RR_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_OCCLUSION_RR_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Occlusion_FR_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJOcclusionFR0 * pOBJ_Occlusion_FR_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Occlusion_FR_0
*    OBJ_Occlusion_FR_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Occlusion_FR_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Occlusion_FR_0( uint8 objIndx_u8, COREOBJvOOBJOcclusionFR0 * pOBJ_Occlusion_FR_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJOcclusionFR0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Occlusion_FR_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Occlusion_FR_0_b2;
         * pOBJ_Occlusion_FR_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_OCCLUSION_FR_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Occlusion_FL_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJOcclusionFL0 * pOBJ_Occlusion_FL_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Occlusion_FL_0
*    OBJ_Occlusion_FL_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Occlusion_FL_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Occlusion_FL_0( uint8 objIndx_u8, COREOBJvOOBJOcclusionFL0 * pOBJ_Occlusion_FL_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJOcclusionFL0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Occlusion_FL_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Occlusion_FL_0_b2;
         * pOBJ_Occlusion_FL_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_OCCLUSION_FL_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_Reserved_21_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_21_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_21_0
*    Reserved_21_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_21_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_Reserved_21_0( uint8 objIndx_u8, uint8 * pReserved_21_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_21_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].Reserved_21_0_b2;
         * pReserved_21_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_RESERVED_21_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_OverlapAngleEgoLaneR_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_OverlapAngleEgoLaneR_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_OverlapAngleEgoLaneR_0
*    OBJ_OverlapAngleEgoLaneR_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_OverlapAngleEgoLaneR_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_OverlapAngleEgoLaneR_0( uint8 objIndx_u8, uint16 * pOBJ_OverlapAngleEgoLaneR_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_OverlapAngleEgoLaneR_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_OverlapAngleEgoLaneR_0_b10;
         * pOBJ_OverlapAngleEgoLaneR_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_OVERLAPANGLEEGOLANER_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_OverlapAngleEgoLaneL_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_OverlapAngleEgoLaneL_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_OverlapAngleEgoLaneL_0
*    OBJ_OverlapAngleEgoLaneL_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_OverlapAngleEgoLaneL_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_OverlapAngleEgoLaneL_0( uint8 objIndx_u8, uint16 * pOBJ_OverlapAngleEgoLaneL_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_OverlapAngleEgoLaneL_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_OverlapAngleEgoLaneL_0_b10;
         * pOBJ_OverlapAngleEgoLaneL_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_OVERLAPANGLEEGOLANEL_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Is_EMERGENCY_VCL_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJIsEMERGENCYVCL0 * pOBJ_Is_EMERGENCY_VCL_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Is_EMERGENCY_VCL_0
*    OBJ_Is_EMERGENCY_VCL_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Is_EMERGENCY_VCL_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Is_EMERGENCY_VCL_0( uint8 objIndx_u8, COREOBJvOOBJIsEMERGENCYVCL0 * pOBJ_Is_EMERGENCY_VCL_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJIsEMERGENCYVCL0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Is_EMERGENCY_VCL_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Is_EMERGENCY_VCL_0_b1;
         * pOBJ_Is_EMERGENCY_VCL_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_EMERGENCY_LIGHT_COLOR_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJEMERGENCYLIGHTCOLOR0 * pOBJ_EMERGENCY_LIGHT_COLOR_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_EMERGENCY_LIGHT_COLOR_0
*    OBJ_EMERGENCY_LIGHT_COLOR_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_EMERGENCY_LIGHT_COLOR_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_EMERGENCY_LIGHT_COLOR_0( uint8 objIndx_u8, COREOBJvOOBJEMERGENCYLIGHTCOLOR0 * pOBJ_EMERGENCY_LIGHT_COLOR_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJEMERGENCYLIGHTCOLOR0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_EMERGENCY_LIGHT_COLOR_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_EMERGENCY_LIGHT_COLOR_0_b4;
         * pOBJ_EMERGENCY_LIGHT_COLOR_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_EMERGENCY_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJEMERGENCYV0 * pOBJ_EMERGENCY_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_EMERGENCY_V_0
*    OBJ_EMERGENCY_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_EMERGENCY_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_EMERGENCY_V_0( uint8 objIndx_u8, COREOBJvOOBJEMERGENCYV0 * pOBJ_EMERGENCY_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJEMERGENCYV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_EMERGENCY_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_EMERGENCY_V_0_b1;
         * pOBJ_EMERGENCY_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_Reserved_22_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_22_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_22_0
*    Reserved_22_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_22_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_Reserved_22_0( uint8 objIndx_u8, uint8 * pReserved_22_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_22_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].Reserved_22_0_b6;
         * pReserved_22_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_RESERVED_22_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Top_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Angle_Top_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Top_0
*    OBJ_Angle_Top_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Top_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Top_0( uint8 objIndx_u8, uint16 * pOBJ_Angle_Top_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Angle_Top_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Angle_Top_0_b14;
         * pOBJ_Angle_Top_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_ANGLE_TOP_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Top_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAngleTopV0 * pOBJ_Angle_Top_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Top_V_0
*    OBJ_Angle_Top_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Top_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Top_V_0( uint8 objIndx_u8, COREOBJvOOBJAngleTopV0 * pOBJ_Angle_Top_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJAngleTopV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Angle_Top_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Angle_Top_V_0_b1;
         * pOBJ_Angle_Top_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Top_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pOBJ_Angle_Top_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Top_STD_0
*    OBJ_Angle_Top_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Top_STD_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Top_STD_0( uint8 objIndx_u8, uint16 * pOBJ_Angle_Top_STD_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Angle_Top_STD_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Angle_Top_STD_0_b15;
         * pOBJ_Angle_Top_STD_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_ANGLE_TOP_STD_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Angle_Top_STD_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJAngleTopSTDV0 * pOBJ_Angle_Top_STD_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Angle_Top_STD_V_0
*    OBJ_Angle_Top_STD_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Angle_Top_STD_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Angle_Top_STD_V_0( uint8 objIndx_u8, COREOBJvOOBJAngleTopSTDV0 * pOBJ_Angle_Top_STD_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJAngleTopSTDV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Angle_Top_STD_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Angle_Top_STD_V_0_b1;
         * pOBJ_Angle_Top_STD_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Open_Door_Left_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJOpenDoorLeft0 * pOBJ_Open_Door_Left_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Open_Door_Left_0
*    OBJ_Open_Door_Left_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Open_Door_Left_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Open_Door_Left_0( uint8 objIndx_u8, COREOBJvOOBJOpenDoorLeft0 * pOBJ_Open_Door_Left_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJOpenDoorLeft0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Open_Door_Left_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Open_Door_Left_0_b1;
         * pOBJ_Open_Door_Left_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Open_Door_Right_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJOpenDoorRight0 * pOBJ_Open_Door_Right_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Open_Door_Right_0
*    OBJ_Open_Door_Right_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Open_Door_Right_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Open_Door_Right_0( uint8 objIndx_u8, COREOBJvOOBJOpenDoorRight0 * pOBJ_Open_Door_Right_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJOpenDoorRight0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Open_Door_Right_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Open_Door_Right_0_b1;
         * pOBJ_Open_Door_Right_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Visible_Left_or_Right_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJVisibleLeftOrRight0 * pOBJ_Visible_Left_or_Right_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Visible_Left_or_Right_0
*    OBJ_Visible_Left_or_Right_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Visible_Left_or_Right_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Visible_Left_or_Right_0( uint8 objIndx_u8, COREOBJvOOBJVisibleLeftOrRight0 * pOBJ_Visible_Left_or_Right_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJVisibleLeftOrRight0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Visible_Left_or_Right_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Visible_Left_or_Right_0_b2;
         * pOBJ_Visible_Left_or_Right_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_OBJ_VISIBLE_LEFT_OR_RIGHT_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_OBJ_Visible_Left_or_Right_V_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREOBJvOOBJVisibleLeftOrRightV0 * pOBJ_Visible_Left_or_Right_V_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of OBJ_Visible_Left_or_Right_V_0
*    OBJ_Visible_Left_or_Right_V_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns OBJ_Visible_Left_or_Right_V_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_OBJ_Visible_Left_or_Right_V_0( uint8 objIndx_u8, COREOBJvOOBJVisibleLeftOrRightV0 * pOBJ_Visible_Left_or_Right_V_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREOBJvOOBJVisibleLeftOrRightV0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pOBJ_Visible_Left_or_Right_V_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].OBJ_Visible_Left_or_Right_V_0_b1;
         * pOBJ_Visible_Left_or_Right_V_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREOBJvO_Reserved_23_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint32 * pReserved_23_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_23_0
*    Reserved_23_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_23_0 signal value of Virtual_OBJECT_msg_Core_Objects_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREOBJvO_Reserved_23_0( uint8 objIndx_u8, uint32 * pReserved_23_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Objects_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREOBJvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_23_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREOBJ_ParamsApp_s.EYEQMSG_COREOBJvO_Params_as[objIndx_u8].Reserved_23_0_b28;
         * pReserved_23_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREOBJvO_RESERVED_23_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_COREOBJ_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_COREOBJ_Params_t * pCore_Objects_protocol - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_Objects_protocol message 
*    Core_Objects_protocol message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_Objects_protocol message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_COREOBJ_ParamsApp_MsgDataStruct( EYEQMSG_COREOBJ_Params_t * pCore_Objects_protocol )
{
   Std_ReturnType status = C_SIG_INVALID;
   if( pCore_Objects_protocol != C_NULL_P )
   {
      status = C_SIG_VALID;
      * pCore_Objects_protocol = EYEQMSG_COREOBJ_ParamsApp_s;
   }
   return ( status );
}

