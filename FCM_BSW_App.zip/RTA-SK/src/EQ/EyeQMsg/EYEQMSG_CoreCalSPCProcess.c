

/*****************************************************************************
                  Include files
*****************************************************************************/
/* The suggested include file order is: */
#include "EyeQ_defs.h"    /* EyeQ project common definitions file    */

#include "EYEQMSG_CoreCalSPCProcess.h"

/*****************************************************************************
                  Local symbolic constants
*****************************************************************************/
/*****************************************************************************
                  Local types, enums definitions
*****************************************************************************/
/*****************************************************************************
                  Local function prototypes
*****************************************************************************/
/*****************************************************************************
                  Local object definitions
*****************************************************************************/
/*****************************************************************************
                  Exported object definitions
*****************************************************************************/
EYEQMSG_CORECALSPC_Params_t   EYEQMSG_CORECALSPC_Params_s;
EYEQMSG_CORECALSPC_Params_t   EYEQMSG_CORECALSPC_ParamsApp_s;
/*****************************************************************************
                  Local function-like macros
*****************************************************************************/
/*****************************************************************************
                  Local defined macros
*****************************************************************************/
/*****************************************************************************
                  Function definitions
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_CORECALSPC_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_CORECALSPC_Params_t * pCore_Calibration_SPC_protocol - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_Calibration_SPC_protocol message 
*    Core_Calibration_SPC_protocol message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_Calibration_SPC_protocol message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_CORECALSPC_ParamsApp_MsgDataStruct( EYEQMSG_CORECALSPC_Params_t * pCore_Calibration_SPC_protocol )
{
   Std_ReturnType status = C_SIG_INVALID;
   if( pCore_Calibration_SPC_protocol != C_NULL_P )
   {
      status = C_SIG_VALID;
      * pCore_Calibration_SPC_protocol = EYEQMSG_CORECALSPC_ParamsApp_s;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSPC_CLB_SPC_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pCLB_SPC_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_SPC_Zero_byte
*    CLB_SPC_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_SPC_Zero_byte signal value of Core_Calibration_SPC_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSPC_CLB_SPC_Zero_byte( uint8 * pCLB_SPC_Zero_byte )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pCLB_SPC_Zero_byte != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECALSPC_ParamsApp_s.CLB_SPC_Zero_byte_b8;
      * pCLB_SPC_Zero_byte = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSPC_Reserved_1
*
* FUNCTION ARGUMENTS:
*    uint32 * pReserved_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1
*    Reserved_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1 signal value of Core_Calibration_SPC_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSPC_Reserved_1( uint32 * pReserved_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pReserved_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECALSPC_ParamsApp_s.Reserved_1_b24;
      * pReserved_1 = signal_value;
      if( signal_value <= C_EYEQMSG_CORECALSPC_RESERVED_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSPC_CLB_SPC_Header_CRC
*
* FUNCTION ARGUMENTS:
*    uint32 * pCLB_SPC_Header_CRC - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_SPC_Header_CRC
*    CLB_SPC_Header_CRC returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_SPC_Header_CRC signal value of Core_Calibration_SPC_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSPC_CLB_SPC_Header_CRC( uint32 * pCLB_SPC_Header_CRC )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pCLB_SPC_Header_CRC != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECALSPC_ParamsApp_s.CLB_SPC_Header_CRC_b32;
      * pCLB_SPC_Header_CRC = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSPC_CLB_SPC_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pCLB_SPC_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_SPC_Protocol_Version
*    CLB_SPC_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_SPC_Protocol_Version signal value of Core_Calibration_SPC_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSPC_CLB_SPC_Protocol_Version( uint8 * pCLB_SPC_Protocol_Version )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pCLB_SPC_Protocol_Version != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECALSPC_ParamsApp_s.CLB_SPC_Protocol_Version_b8;
      * pCLB_SPC_Protocol_Version = signal_value;
      if( (signal_value >= C_EYEQMSG_CORECALSPC_CLB_SPC_PROTOCOL_VERSION_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORECALSPC_CLB_SPC_PROTOCOL_VERSION_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSPC_CLB_SPC_Sync_ID
*
* FUNCTION ARGUMENTS:
*    uint8 * pCLB_SPC_Sync_ID - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_SPC_Sync_ID
*    CLB_SPC_Sync_ID returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_SPC_Sync_ID signal value of Core_Calibration_SPC_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSPC_CLB_SPC_Sync_ID( uint8 * pCLB_SPC_Sync_ID )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pCLB_SPC_Sync_ID != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECALSPC_ParamsApp_s.CLB_SPC_Sync_ID_b8;
      * pCLB_SPC_Sync_ID = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSPC_CLB_SPC_Status
*
* FUNCTION ARGUMENTS:
*    CORECALSPCCLBSPCStatus * pCLB_SPC_Status - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_SPC_Status
*    CLB_SPC_Status returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_SPC_Status signal value of Core_Calibration_SPC_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSPC_CLB_SPC_Status( CORECALSPCCLBSPCStatus * pCLB_SPC_Status )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECALSPCCLBSPCStatus signal_value;
   
   if( pCLB_SPC_Status != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECALSPC_ParamsApp_s.CLB_SPC_Status_b2;
      * pCLB_SPC_Status = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSPC_CLB_SPC_Progress
*
* FUNCTION ARGUMENTS:
*    uint8 * pCLB_SPC_Progress - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_SPC_Progress
*    CLB_SPC_Progress returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_SPC_Progress signal value of Core_Calibration_SPC_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSPC_CLB_SPC_Progress( uint8 * pCLB_SPC_Progress )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pCLB_SPC_Progress != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECALSPC_ParamsApp_s.CLB_SPC_Progress_b7;
      * pCLB_SPC_Progress = signal_value;
      if( signal_value <= C_EYEQMSG_CORECALSPC_CLB_SPC_PROGRESS_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSPC_CLB_SPC_Error
*
* FUNCTION ARGUMENTS:
*    CORECALSPCCLBSPCError * pCLB_SPC_Error - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_SPC_Error
*    CLB_SPC_Error returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_SPC_Error signal value of Core_Calibration_SPC_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSPC_CLB_SPC_Error( CORECALSPCCLBSPCError * pCLB_SPC_Error )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECALSPCCLBSPCError signal_value;
   
   if( pCLB_SPC_Error != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECALSPC_ParamsApp_s.CLB_SPC_Error_b2;
      * pCLB_SPC_Error = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSPC_CLB_SPC_Session_Number
*
* FUNCTION ARGUMENTS:
*    uint8 * pCLB_SPC_Session_Number - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_SPC_Session_Number
*    CLB_SPC_Session_Number returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_SPC_Session_Number signal value of Core_Calibration_SPC_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSPC_CLB_SPC_Session_Number( uint8 * pCLB_SPC_Session_Number )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pCLB_SPC_Session_Number != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECALSPC_ParamsApp_s.CLB_SPC_Session_Number_b3;
      * pCLB_SPC_Session_Number = signal_value;
      if( signal_value <= C_EYEQMSG_CORECALSPC_CLB_SPC_SESSION_NUMBER_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSPC_CLB_SPC_Frame_Valid
*
* FUNCTION ARGUMENTS:
*    CORECALSPCCLBSPCFrameValid * pCLB_SPC_Frame_Valid - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_SPC_Frame_Valid
*    CLB_SPC_Frame_Valid returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_SPC_Frame_Valid signal value of Core_Calibration_SPC_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSPC_CLB_SPC_Frame_Valid( CORECALSPCCLBSPCFrameValid * pCLB_SPC_Frame_Valid )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECALSPCCLBSPCFrameValid signal_value;
   
   if( pCLB_SPC_Frame_Valid != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECALSPC_ParamsApp_s.CLB_SPC_Frame_Valid_b1;
      * pCLB_SPC_Frame_Valid = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSPC_Reserved_2
*
* FUNCTION ARGUMENTS:
*    boolean * pReserved_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_2
*    Reserved_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_2 signal value of Core_Calibration_SPC_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSPC_Reserved_2( boolean * pReserved_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pReserved_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECALSPC_ParamsApp_s.Reserved_2_b1;
      * pReserved_2 = signal_value;
      if( signal_value <= C_EYEQMSG_CORECALSPC_RESERVED_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSPC_CLB_SPC_Invalid_Signal
*
* FUNCTION ARGUMENTS:
*    uint8 * pCLB_SPC_Invalid_Signal - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_SPC_Invalid_Signal
*    CLB_SPC_Invalid_Signal returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_SPC_Invalid_Signal signal value of Core_Calibration_SPC_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSPC_CLB_SPC_Invalid_Signal( uint8 * pCLB_SPC_Invalid_Signal )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pCLB_SPC_Invalid_Signal != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECALSPC_ParamsApp_s.CLB_SPC_Invalid_Signal_b8;
      * pCLB_SPC_Invalid_Signal = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSPC_CLB_SPC_Invalid_Reason
*
* FUNCTION ARGUMENTS:
*    CORECALSPCCLBSPCInvalidReason * pCLB_SPC_Invalid_Reason - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_SPC_Invalid_Reason
*    CLB_SPC_Invalid_Reason returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_SPC_Invalid_Reason signal value of Core_Calibration_SPC_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSPC_CLB_SPC_Invalid_Reason( CORECALSPCCLBSPCInvalidReason * pCLB_SPC_Invalid_Reason )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECALSPCCLBSPCInvalidReason signal_value;
   
   if( pCLB_SPC_Invalid_Reason != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECALSPC_ParamsApp_s.CLB_SPC_Invalid_Reason_b8;
      * pCLB_SPC_Invalid_Reason = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSPC_CLB_SPC_Baseline_Yaw
*
* FUNCTION ARGUMENTS:
*    uint16 * pCLB_SPC_Baseline_Yaw - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_SPC_Baseline_Yaw
*    CLB_SPC_Baseline_Yaw returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_SPC_Baseline_Yaw signal value of Core_Calibration_SPC_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSPC_CLB_SPC_Baseline_Yaw( uint16 * pCLB_SPC_Baseline_Yaw )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pCLB_SPC_Baseline_Yaw != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECALSPC_ParamsApp_s.CLB_SPC_Baseline_Yaw_b16;
      * pCLB_SPC_Baseline_Yaw = signal_value;
      if( signal_value <= C_EYEQMSG_CORECALSPC_CLB_SPC_BASELINE_YAW_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSPC_CLB_SPC_Baseline_Pitch
*
* FUNCTION ARGUMENTS:
*    uint16 * pCLB_SPC_Baseline_Pitch - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_SPC_Baseline_Pitch
*    CLB_SPC_Baseline_Pitch returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_SPC_Baseline_Pitch signal value of Core_Calibration_SPC_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSPC_CLB_SPC_Baseline_Pitch( uint16 * pCLB_SPC_Baseline_Pitch )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pCLB_SPC_Baseline_Pitch != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECALSPC_ParamsApp_s.CLB_SPC_Baseline_Pitch_b16;
      * pCLB_SPC_Baseline_Pitch = signal_value;
      if( signal_value <= C_EYEQMSG_CORECALSPC_CLB_SPC_BASELINE_PITCH_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSPC_CLB_SPC_Baseline_Height
*
* FUNCTION ARGUMENTS:
*    uint16 * pCLB_SPC_Baseline_Height - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_SPC_Baseline_Height
*    CLB_SPC_Baseline_Height returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_SPC_Baseline_Height signal value of Core_Calibration_SPC_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSPC_CLB_SPC_Baseline_Height( uint16 * pCLB_SPC_Baseline_Height )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pCLB_SPC_Baseline_Height != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECALSPC_ParamsApp_s.CLB_SPC_Baseline_Height_b16;
      * pCLB_SPC_Baseline_Height = signal_value;
      if( (signal_value >= C_EYEQMSG_CORECALSPC_CLB_SPC_BASELINE_HEIGHT_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORECALSPC_CLB_SPC_BASELINE_HEIGHT_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSPC_CLB_SPC_Baseline_Roll
*
* FUNCTION ARGUMENTS:
*    float32 * pCLB_SPC_Baseline_Roll - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_SPC_Baseline_Roll
*    CLB_SPC_Baseline_Roll returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_SPC_Baseline_Roll signal value of Core_Calibration_SPC_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSPC_CLB_SPC_Baseline_Roll( float32 * pCLB_SPC_Baseline_Roll )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float32SigDataType signal_value;
   
   if( pCLB_SPC_Baseline_Roll != C_NULL_P )
   {
      signal_value.u = EYEQMSG_CORECALSPC_ParamsApp_s.CLB_SPC_Baseline_Roll_sb32;
      * pCLB_SPC_Baseline_Roll = signal_value.f;
      if( (signal_value.f >= C_EYEQMSG_CORECALSPC_CLB_SPC_BASELINE_ROLL_RMIN ) 
          && (signal_value.f <= C_EYEQMSG_CORECALSPC_CLB_SPC_BASELINE_ROLL_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

