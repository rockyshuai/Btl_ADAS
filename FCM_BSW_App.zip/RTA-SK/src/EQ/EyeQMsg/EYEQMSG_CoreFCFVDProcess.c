

/*****************************************************************************
                  Include files
*****************************************************************************/
/* The suggested include file order is: */
#include "EyeQ_defs.h"    /* EyeQ project common definitions file    */

#include "EYEQMSG_CoreFCFVDProcess.h"

/*****************************************************************************
                  Local symbolic constants
*****************************************************************************/
/*****************************************************************************
                  Local types, enums definitions
*****************************************************************************/
/*****************************************************************************
                  Local function prototypes
*****************************************************************************/
/*****************************************************************************
                  Local object definitions
*****************************************************************************/
/*****************************************************************************
                  Exported object definitions
*****************************************************************************/
EYEQMSG_COREFCFVD_Params_t   EYEQMSG_COREFCFVD_Params_s;
EYEQMSG_COREFCFVD_Params_t   EYEQMSG_COREFCFVD_ParamsApp_s;
/*****************************************************************************
                  Local function-like macros
*****************************************************************************/
/*****************************************************************************
                  Local defined macros
*****************************************************************************/
/*****************************************************************************
                  Function definitions
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_COREFCFVD_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_COREFCFVD_Params_t * pCore_FCF_VD_protocol - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_FCF_VD_protocol message 
*    Core_FCF_VD_protocol message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_FCF_VD_protocol message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_COREFCFVD_ParamsApp_MsgDataStruct( EYEQMSG_COREFCFVD_Params_t * pCore_FCF_VD_protocol )
{
   Std_ReturnType status = C_SIG_INVALID;
   if( pCore_FCF_VD_protocol != C_NULL_P )
   {
      status = C_SIG_VALID;
      * pCore_FCF_VD_protocol = EYEQMSG_COREFCFVD_ParamsApp_s;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_VD_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_Zero_byte
*    FCF_VD_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_Zero_byte signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_Zero_byte( uint8 * pFCF_VD_Zero_byte )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_VD_Zero_byte != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_Zero_byte_b8;
      * pFCF_VD_Zero_byte = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_VD_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_Protocol_Version
*    FCF_VD_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_Protocol_Version signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_Protocol_Version( uint8 * pFCF_VD_Protocol_Version )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_VD_Protocol_Version != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_Protocol_Version_b8;
      * pFCF_VD_Protocol_Version = signal_value;
      if( (signal_value >= C_EYEQMSG_COREFCFVD_FCF_VD_PROTOCOL_VERSION_RMIN ) 
          && (signal_value <= C_EYEQMSG_COREFCFVD_FCF_VD_PROTOCOL_VERSION_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_SyncID
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_VD_SyncID - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_SyncID
*    FCF_VD_SyncID returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_SyncID signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_SyncID( uint8 * pFCF_VD_SyncID )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_VD_SyncID != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_SyncID_b8;
      * pFCF_VD_SyncID = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_Reserved_1
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1
*    Reserved_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1 signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_Reserved_1( uint8 * pReserved_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pReserved_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.Reserved_1_b8;
      * pReserved_1 = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVD_RESERVED_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_Header_CRC
*
* FUNCTION ARGUMENTS:
*    uint32 * pFCF_Header_CRC - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_Header_CRC
*    FCF_Header_CRC returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_Header_CRC signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_Header_CRC( uint32 * pFCF_Header_CRC )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pFCF_Header_CRC != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_Header_CRC_b32;
      * pFCF_Header_CRC = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_AEB_Supp_FCV
*
* FUNCTION ARGUMENTS:
*    COREFCFVDFCFVDAEBSuppFCV * pFCF_VD_AEB_Supp_FCV - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_AEB_Supp_FCV
*    FCF_VD_AEB_Supp_FCV returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_AEB_Supp_FCV signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_AEB_Supp_FCV( COREFCFVDFCFVDAEBSuppFCV * pFCF_VD_AEB_Supp_FCV )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVDFCFVDAEBSuppFCV signal_value;
   
   if( pFCF_VD_AEB_Supp_FCV != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_AEB_Supp_FCV_b16;
      * pFCF_VD_AEB_Supp_FCV = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_Alert_FCV
*
* FUNCTION ARGUMENTS:
*    COREFCFVDFCFVDAlertFCV * pFCF_VD_Alert_FCV - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_Alert_FCV
*    FCF_VD_Alert_FCV returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_Alert_FCV signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_Alert_FCV( COREFCFVDFCFVDAlertFCV * pFCF_VD_Alert_FCV )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVDFCFVDAlertFCV signal_value;
   
   if( pFCF_VD_Alert_FCV != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_Alert_FCV_b16;
      * pFCF_VD_Alert_FCV = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_ID_FCV
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_VD_ID_FCV - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_ID_FCV
*    FCF_VD_ID_FCV returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_ID_FCV signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_ID_FCV( uint8 * pFCF_VD_ID_FCV )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_VD_ID_FCV != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_ID_FCV_b8;
      * pFCF_VD_ID_FCV = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_HeadWay_Alert
*
* FUNCTION ARGUMENTS:
*    COREFCFVDFCFVDHeadWayAlert * pFCF_VD_HeadWay_Alert - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_HeadWay_Alert
*    FCF_VD_HeadWay_Alert returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_HeadWay_Alert signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_HeadWay_Alert( COREFCFVDFCFVDHeadWayAlert * pFCF_VD_HeadWay_Alert )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVDFCFVDHeadWayAlert signal_value;
   
   if( pFCF_VD_HeadWay_Alert != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_HeadWay_Alert_b1;
      * pFCF_VD_HeadWay_Alert = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_HeadWay_Distance
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCF_VD_HeadWay_Distance - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_HeadWay_Distance
*    FCF_VD_HeadWay_Distance returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_HeadWay_Distance signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_HeadWay_Distance( uint16 * pFCF_VD_HeadWay_Distance )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCF_VD_HeadWay_Distance != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_HeadWay_Distance_b11;
      * pFCF_VD_HeadWay_Distance = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVD_FCF_VD_HEADWAY_DISTANCE_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_Req_Decel_Raw
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_VD_Req_Decel_Raw - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_Req_Decel_Raw
*    FCF_VD_Req_Decel_Raw returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_Req_Decel_Raw signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_Req_Decel_Raw( uint8 * pFCF_VD_Req_Decel_Raw )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_VD_Req_Decel_Raw != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_Req_Decel_Raw_b8;
      * pFCF_VD_Req_Decel_Raw = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_Brake_Stage
*
* FUNCTION ARGUMENTS:
*    COREFCFVDFCFVDBrakeStage * pFCF_VD_Brake_Stage - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_Brake_Stage
*    FCF_VD_Brake_Stage returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_Brake_Stage signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_Brake_Stage( COREFCFVDFCFVDBrakeStage * pFCF_VD_Brake_Stage )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVDFCFVDBrakeStage signal_value;
   
   if( pFCF_VD_Brake_Stage != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_Brake_Stage_b2;
      * pFCF_VD_Brake_Stage = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_Reserved_2
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_2
*    Reserved_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_2 signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_Reserved_2( uint8 * pReserved_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pReserved_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.Reserved_2_b2;
      * pReserved_2 = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVD_RESERVED_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_HW_Supp_Reason
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCF_VD_HW_Supp_Reason - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_HW_Supp_Reason
*    FCF_VD_HW_Supp_Reason returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_HW_Supp_Reason signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_HW_Supp_Reason( uint16 * pFCF_VD_HW_Supp_Reason )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCF_VD_HW_Supp_Reason != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_HW_Supp_Reason_b16;
      * pFCF_VD_HW_Supp_Reason = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_Brake_Decel_Req
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_VD_Brake_Decel_Req - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_Brake_Decel_Req
*    FCF_VD_Brake_Decel_Req returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_Brake_Decel_Req signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_Brake_Decel_Req( uint8 * pFCF_VD_Brake_Decel_Req )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_VD_Brake_Decel_Req != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_Brake_Decel_Req_b8;
      * pFCF_VD_Brake_Decel_Req = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVD_FCF_VD_BRAKE_DECEL_REQ_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_Header_Buffer
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_Header_Buffer - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_Header_Buffer
*    FCF_Header_Buffer returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_Header_Buffer signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_Header_Buffer( uint8 * pFCF_Header_Buffer )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_Header_Buffer != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_Header_Buffer_b8;
      * pFCF_Header_Buffer = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVD_FCF_HEADER_BUFFER_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_CRC_A
*
* FUNCTION ARGUMENTS:
*    uint32 * pFCF_VD_CRC_A - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_CRC_A
*    FCF_VD_CRC_A returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_CRC_A signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_CRC_A( uint32 * pFCF_VD_CRC_A )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pFCF_VD_CRC_A != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_CRC_A_b32;
      * pFCF_VD_CRC_A = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_Alert_A
*
* FUNCTION ARGUMENTS:
*    COREFCFVDFCFVDAlertA * pFCF_VD_Alert_A - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_Alert_A
*    FCF_VD_Alert_A returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_Alert_A signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_Alert_A( COREFCFVDFCFVDAlertA * pFCF_VD_Alert_A )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVDFCFVDAlertA signal_value;
   
   if( pFCF_VD_Alert_A != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_Alert_A_b16;
      * pFCF_VD_Alert_A = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_ID_A
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_VD_ID_A - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_ID_A
*    FCF_VD_ID_A returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_ID_A signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_ID_A( uint8 * pFCF_VD_ID_A )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_VD_ID_A != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_ID_A_b8;
      * pFCF_VD_ID_A = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_Brake_Decel_Req_A
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_VD_Brake_Decel_Req_A - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_Brake_Decel_Req_A
*    FCF_VD_Brake_Decel_Req_A returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_Brake_Decel_Req_A signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_Brake_Decel_Req_A( uint8 * pFCF_VD_Brake_Decel_Req_A )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_VD_Brake_Decel_Req_A != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_Brake_Decel_Req_A_b8;
      * pFCF_VD_Brake_Decel_Req_A = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_AEB_Supp_A
*
* FUNCTION ARGUMENTS:
*    COREFCFVDFCFVDAEBSuppA * pFCF_VD_AEB_Supp_A - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_AEB_Supp_A
*    FCF_VD_AEB_Supp_A returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_AEB_Supp_A signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_AEB_Supp_A( COREFCFVDFCFVDAEBSuppA * pFCF_VD_AEB_Supp_A )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVDFCFVDAEBSuppA signal_value;
   
   if( pFCF_VD_AEB_Supp_A != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_AEB_Supp_A_b16;
      * pFCF_VD_AEB_Supp_A = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_Safety_Suppressed_A
*
* FUNCTION ARGUMENTS:
*    COREFCFVDFCFVDSafetySuppressedA * pFCF_VD_Safety_Suppressed_A - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_Safety_Suppressed_A
*    FCF_VD_Safety_Suppressed_A returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_Safety_Suppressed_A signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_Safety_Suppressed_A( COREFCFVDFCFVDSafetySuppressedA * pFCF_VD_Safety_Suppressed_A )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVDFCFVDSafetySuppressedA signal_value;
   
   if( pFCF_VD_Safety_Suppressed_A != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_Safety_Suppressed_A_b1;
      * pFCF_VD_Safety_Suppressed_A = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_Reserved_3
*
* FUNCTION ARGUMENTS:
*    uint16 * pReserved_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_3
*    Reserved_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_3 signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_Reserved_3( uint16 * pReserved_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pReserved_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.Reserved_3_b15;
      * pReserved_3 = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVD_RESERVED_3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_FCW_Supp_A
*
* FUNCTION ARGUMENTS:
*    COREFCFVDFCFVDFCWSuppA * pFCF_VD_FCW_Supp_A - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_FCW_Supp_A
*    FCF_VD_FCW_Supp_A returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_FCW_Supp_A signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_FCW_Supp_A( COREFCFVDFCFVDFCWSuppA * pFCF_VD_FCW_Supp_A )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVDFCFVDFCWSuppA signal_value;
   
   if( pFCF_VD_FCW_Supp_A != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_FCW_Supp_A_b32;
      * pFCF_VD_FCW_Supp_A = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_Set_Type_A
*
* FUNCTION ARGUMENTS:
*    COREFCFVDFCFVDSetTypeA * pFCF_VD_Set_Type_A - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_Set_Type_A
*    FCF_VD_Set_Type_A returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_Set_Type_A signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_Set_Type_A( COREFCFVDFCFVDSetTypeA * pFCF_VD_Set_Type_A )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVDFCFVDSetTypeA signal_value;
   
   if( pFCF_VD_Set_Type_A != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_Set_Type_A_b2;
      * pFCF_VD_Set_Type_A = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_TTC_Thresh_A
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCF_VD_TTC_Thresh_A - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_TTC_Thresh_A
*    FCF_VD_TTC_Thresh_A returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_TTC_Thresh_A signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_TTC_Thresh_A( uint16 * pFCF_VD_TTC_Thresh_A )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCF_VD_TTC_Thresh_A != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_TTC_Thresh_A_b10;
      * pFCF_VD_TTC_Thresh_A = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVD_FCF_VD_TTC_THRESH_A_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_TTC_A
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCF_VD_TTC_A - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_TTC_A
*    FCF_VD_TTC_A returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_TTC_A signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_TTC_A( uint16 * pFCF_VD_TTC_A )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCF_VD_TTC_A != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_TTC_A_b10;
      * pFCF_VD_TTC_A = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVD_FCF_VD_TTC_A_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_Buffer_A
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCF_VD_Buffer_A - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_Buffer_A
*    FCF_VD_Buffer_A returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_Buffer_A signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_Buffer_A( uint16 * pFCF_VD_Buffer_A )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCF_VD_Buffer_A != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_Buffer_A_b10;
      * pFCF_VD_Buffer_A = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVD_FCF_VD_BUFFER_A_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_CRC_B
*
* FUNCTION ARGUMENTS:
*    uint32 * pFCF_VD_CRC_B - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_CRC_B
*    FCF_VD_CRC_B returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_CRC_B signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_CRC_B( uint32 * pFCF_VD_CRC_B )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pFCF_VD_CRC_B != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_CRC_B_b32;
      * pFCF_VD_CRC_B = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_Alert_B
*
* FUNCTION ARGUMENTS:
*    COREFCFVDFCFVDAlertB * pFCF_VD_Alert_B - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_Alert_B
*    FCF_VD_Alert_B returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_Alert_B signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_Alert_B( COREFCFVDFCFVDAlertB * pFCF_VD_Alert_B )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVDFCFVDAlertB signal_value;
   
   if( pFCF_VD_Alert_B != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_Alert_B_b16;
      * pFCF_VD_Alert_B = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_ID_B
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_VD_ID_B - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_ID_B
*    FCF_VD_ID_B returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_ID_B signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_ID_B( uint8 * pFCF_VD_ID_B )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_VD_ID_B != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_ID_B_b8;
      * pFCF_VD_ID_B = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_Brake_Decel_Req_B
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_VD_Brake_Decel_Req_B - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_Brake_Decel_Req_B
*    FCF_VD_Brake_Decel_Req_B returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_Brake_Decel_Req_B signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_Brake_Decel_Req_B( uint8 * pFCF_VD_Brake_Decel_Req_B )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_VD_Brake_Decel_Req_B != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_Brake_Decel_Req_B_b8;
      * pFCF_VD_Brake_Decel_Req_B = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_AEB_Supp_B
*
* FUNCTION ARGUMENTS:
*    COREFCFVDFCFVDAEBSuppB * pFCF_VD_AEB_Supp_B - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_AEB_Supp_B
*    FCF_VD_AEB_Supp_B returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_AEB_Supp_B signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_AEB_Supp_B( COREFCFVDFCFVDAEBSuppB * pFCF_VD_AEB_Supp_B )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVDFCFVDAEBSuppB signal_value;
   
   if( pFCF_VD_AEB_Supp_B != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_AEB_Supp_B_b16;
      * pFCF_VD_AEB_Supp_B = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_Safety_Suppressed_B
*
* FUNCTION ARGUMENTS:
*    COREFCFVDFCFVDSafetySuppressedB * pFCF_VD_Safety_Suppressed_B - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_Safety_Suppressed_B
*    FCF_VD_Safety_Suppressed_B returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_Safety_Suppressed_B signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_Safety_Suppressed_B( COREFCFVDFCFVDSafetySuppressedB * pFCF_VD_Safety_Suppressed_B )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVDFCFVDSafetySuppressedB signal_value;
   
   if( pFCF_VD_Safety_Suppressed_B != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_Safety_Suppressed_B_b1;
      * pFCF_VD_Safety_Suppressed_B = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_Reserved_4
*
* FUNCTION ARGUMENTS:
*    uint16 * pReserved_4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_4
*    Reserved_4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_4 signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_Reserved_4( uint16 * pReserved_4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pReserved_4 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.Reserved_4_b15;
      * pReserved_4 = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVD_RESERVED_4_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_FCW_Supp_B
*
* FUNCTION ARGUMENTS:
*    COREFCFVDFCFVDFCWSuppB * pFCF_VD_FCW_Supp_B - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_FCW_Supp_B
*    FCF_VD_FCW_Supp_B returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_FCW_Supp_B signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_FCW_Supp_B( COREFCFVDFCFVDFCWSuppB * pFCF_VD_FCW_Supp_B )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVDFCFVDFCWSuppB signal_value;
   
   if( pFCF_VD_FCW_Supp_B != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_FCW_Supp_B_b32;
      * pFCF_VD_FCW_Supp_B = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_Set_Type_B
*
* FUNCTION ARGUMENTS:
*    COREFCFVDFCFVDSetTypeB * pFCF_VD_Set_Type_B - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_Set_Type_B
*    FCF_VD_Set_Type_B returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_Set_Type_B signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_Set_Type_B( COREFCFVDFCFVDSetTypeB * pFCF_VD_Set_Type_B )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVDFCFVDSetTypeB signal_value;
   
   if( pFCF_VD_Set_Type_B != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_Set_Type_B_b2;
      * pFCF_VD_Set_Type_B = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_TTC_Thresh_B
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCF_VD_TTC_Thresh_B - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_TTC_Thresh_B
*    FCF_VD_TTC_Thresh_B returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_TTC_Thresh_B signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_TTC_Thresh_B( uint16 * pFCF_VD_TTC_Thresh_B )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCF_VD_TTC_Thresh_B != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_TTC_Thresh_B_b10;
      * pFCF_VD_TTC_Thresh_B = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVD_FCF_VD_TTC_THRESH_B_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_TTC_B
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCF_VD_TTC_B - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_TTC_B
*    FCF_VD_TTC_B returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_TTC_B signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_TTC_B( uint16 * pFCF_VD_TTC_B )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCF_VD_TTC_B != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_TTC_B_b10;
      * pFCF_VD_TTC_B = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVD_FCF_VD_TTC_B_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_Buffer_B
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCF_VD_Buffer_B - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_Buffer_B
*    FCF_VD_Buffer_B returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_Buffer_B signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_Buffer_B( uint16 * pFCF_VD_Buffer_B )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCF_VD_Buffer_B != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_Buffer_B_b10;
      * pFCF_VD_Buffer_B = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVD_FCF_VD_BUFFER_B_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_CRC_C
*
* FUNCTION ARGUMENTS:
*    uint32 * pFCF_VD_CRC_C - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_CRC_C
*    FCF_VD_CRC_C returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_CRC_C signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_CRC_C( uint32 * pFCF_VD_CRC_C )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pFCF_VD_CRC_C != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_CRC_C_b32;
      * pFCF_VD_CRC_C = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_Alert_C
*
* FUNCTION ARGUMENTS:
*    COREFCFVDFCFVDAlertC * pFCF_VD_Alert_C - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_Alert_C
*    FCF_VD_Alert_C returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_Alert_C signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_Alert_C( COREFCFVDFCFVDAlertC * pFCF_VD_Alert_C )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVDFCFVDAlertC signal_value;
   
   if( pFCF_VD_Alert_C != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_Alert_C_b16;
      * pFCF_VD_Alert_C = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_ID_C
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_VD_ID_C - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_ID_C
*    FCF_VD_ID_C returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_ID_C signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_ID_C( uint8 * pFCF_VD_ID_C )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_VD_ID_C != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_ID_C_b8;
      * pFCF_VD_ID_C = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_Brake_Decel_Req_C
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_VD_Brake_Decel_Req_C - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_Brake_Decel_Req_C
*    FCF_VD_Brake_Decel_Req_C returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_Brake_Decel_Req_C signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_Brake_Decel_Req_C( uint8 * pFCF_VD_Brake_Decel_Req_C )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_VD_Brake_Decel_Req_C != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_Brake_Decel_Req_C_b8;
      * pFCF_VD_Brake_Decel_Req_C = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_AEB_Supp_C
*
* FUNCTION ARGUMENTS:
*    COREFCFVDFCFVDAEBSuppC * pFCF_VD_AEB_Supp_C - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_AEB_Supp_C
*    FCF_VD_AEB_Supp_C returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_AEB_Supp_C signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_AEB_Supp_C( COREFCFVDFCFVDAEBSuppC * pFCF_VD_AEB_Supp_C )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVDFCFVDAEBSuppC signal_value;
   
   if( pFCF_VD_AEB_Supp_C != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_AEB_Supp_C_b16;
      * pFCF_VD_AEB_Supp_C = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_Safety_Suppressed_C
*
* FUNCTION ARGUMENTS:
*    COREFCFVDFCFVDSafetySuppressedC * pFCF_VD_Safety_Suppressed_C - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_Safety_Suppressed_C
*    FCF_VD_Safety_Suppressed_C returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_Safety_Suppressed_C signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_Safety_Suppressed_C( COREFCFVDFCFVDSafetySuppressedC * pFCF_VD_Safety_Suppressed_C )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVDFCFVDSafetySuppressedC signal_value;
   
   if( pFCF_VD_Safety_Suppressed_C != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_Safety_Suppressed_C_b1;
      * pFCF_VD_Safety_Suppressed_C = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_Reserved_5
*
* FUNCTION ARGUMENTS:
*    uint16 * pReserved_5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_5
*    Reserved_5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_5 signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_Reserved_5( uint16 * pReserved_5 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pReserved_5 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.Reserved_5_b15;
      * pReserved_5 = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVD_RESERVED_5_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_FCW_Supp_C
*
* FUNCTION ARGUMENTS:
*    COREFCFVDFCFVDFCWSuppC * pFCF_VD_FCW_Supp_C - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_FCW_Supp_C
*    FCF_VD_FCW_Supp_C returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_FCW_Supp_C signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_FCW_Supp_C( COREFCFVDFCFVDFCWSuppC * pFCF_VD_FCW_Supp_C )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVDFCFVDFCWSuppC signal_value;
   
   if( pFCF_VD_FCW_Supp_C != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_FCW_Supp_C_b32;
      * pFCF_VD_FCW_Supp_C = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_Set_Type_C
*
* FUNCTION ARGUMENTS:
*    COREFCFVDFCFVDSetTypeC * pFCF_VD_Set_Type_C - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_Set_Type_C
*    FCF_VD_Set_Type_C returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_Set_Type_C signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_Set_Type_C( COREFCFVDFCFVDSetTypeC * pFCF_VD_Set_Type_C )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVDFCFVDSetTypeC signal_value;
   
   if( pFCF_VD_Set_Type_C != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_Set_Type_C_b2;
      * pFCF_VD_Set_Type_C = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_TTC_Thresh_C
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCF_VD_TTC_Thresh_C - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_TTC_Thresh_C
*    FCF_VD_TTC_Thresh_C returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_TTC_Thresh_C signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_TTC_Thresh_C( uint16 * pFCF_VD_TTC_Thresh_C )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCF_VD_TTC_Thresh_C != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_TTC_Thresh_C_b10;
      * pFCF_VD_TTC_Thresh_C = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVD_FCF_VD_TTC_THRESH_C_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_TTC_C
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCF_VD_TTC_C - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_TTC_C
*    FCF_VD_TTC_C returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_TTC_C signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_TTC_C( uint16 * pFCF_VD_TTC_C )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCF_VD_TTC_C != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_TTC_C_b10;
      * pFCF_VD_TTC_C = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVD_FCF_VD_TTC_C_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_Buffer_C
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCF_VD_Buffer_C - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_Buffer_C
*    FCF_VD_Buffer_C returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_Buffer_C signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_Buffer_C( uint16 * pFCF_VD_Buffer_C )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCF_VD_Buffer_C != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_Buffer_C_b10;
      * pFCF_VD_Buffer_C = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVD_FCF_VD_BUFFER_C_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_CRC_D
*
* FUNCTION ARGUMENTS:
*    uint32 * pFCF_VD_CRC_D - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_CRC_D
*    FCF_VD_CRC_D returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_CRC_D signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_CRC_D( uint32 * pFCF_VD_CRC_D )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pFCF_VD_CRC_D != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_CRC_D_b32;
      * pFCF_VD_CRC_D = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_Alert_D
*
* FUNCTION ARGUMENTS:
*    COREFCFVDFCFVDAlertD * pFCF_VD_Alert_D - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_Alert_D
*    FCF_VD_Alert_D returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_Alert_D signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_Alert_D( COREFCFVDFCFVDAlertD * pFCF_VD_Alert_D )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVDFCFVDAlertD signal_value;
   
   if( pFCF_VD_Alert_D != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_Alert_D_b16;
      * pFCF_VD_Alert_D = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_ID_D
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_VD_ID_D - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_ID_D
*    FCF_VD_ID_D returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_ID_D signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_ID_D( uint8 * pFCF_VD_ID_D )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_VD_ID_D != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_ID_D_b8;
      * pFCF_VD_ID_D = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_Brake_Decel_Req_D
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_VD_Brake_Decel_Req_D - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_Brake_Decel_Req_D
*    FCF_VD_Brake_Decel_Req_D returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_Brake_Decel_Req_D signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_Brake_Decel_Req_D( uint8 * pFCF_VD_Brake_Decel_Req_D )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_VD_Brake_Decel_Req_D != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_Brake_Decel_Req_D_b8;
      * pFCF_VD_Brake_Decel_Req_D = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_AEB_Supp_D
*
* FUNCTION ARGUMENTS:
*    COREFCFVDFCFVDAEBSuppD * pFCF_VD_AEB_Supp_D - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_AEB_Supp_D
*    FCF_VD_AEB_Supp_D returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_AEB_Supp_D signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_AEB_Supp_D( COREFCFVDFCFVDAEBSuppD * pFCF_VD_AEB_Supp_D )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVDFCFVDAEBSuppD signal_value;
   
   if( pFCF_VD_AEB_Supp_D != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_AEB_Supp_D_b16;
      * pFCF_VD_AEB_Supp_D = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_Safety_Suppressed_D
*
* FUNCTION ARGUMENTS:
*    COREFCFVDFCFVDSafetySuppressedD * pFCF_VD_Safety_Suppressed_D - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_Safety_Suppressed_D
*    FCF_VD_Safety_Suppressed_D returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_Safety_Suppressed_D signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_Safety_Suppressed_D( COREFCFVDFCFVDSafetySuppressedD * pFCF_VD_Safety_Suppressed_D )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVDFCFVDSafetySuppressedD signal_value;
   
   if( pFCF_VD_Safety_Suppressed_D != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_Safety_Suppressed_D_b1;
      * pFCF_VD_Safety_Suppressed_D = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_Reserved_6
*
* FUNCTION ARGUMENTS:
*    uint16 * pReserved_6 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_6
*    Reserved_6 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_6 signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_Reserved_6( uint16 * pReserved_6 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pReserved_6 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.Reserved_6_b15;
      * pReserved_6 = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVD_RESERVED_6_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_FCW_Supp_D
*
* FUNCTION ARGUMENTS:
*    COREFCFVDFCFVDFCWSuppD * pFCF_VD_FCW_Supp_D - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_FCW_Supp_D
*    FCF_VD_FCW_Supp_D returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_FCW_Supp_D signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_FCW_Supp_D( COREFCFVDFCFVDFCWSuppD * pFCF_VD_FCW_Supp_D )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVDFCFVDFCWSuppD signal_value;
   
   if( pFCF_VD_FCW_Supp_D != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_FCW_Supp_D_b32;
      * pFCF_VD_FCW_Supp_D = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_Set_Type_D
*
* FUNCTION ARGUMENTS:
*    COREFCFVDFCFVDSetTypeD * pFCF_VD_Set_Type_D - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_Set_Type_D
*    FCF_VD_Set_Type_D returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_Set_Type_D signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_Set_Type_D( COREFCFVDFCFVDSetTypeD * pFCF_VD_Set_Type_D )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVDFCFVDSetTypeD signal_value;
   
   if( pFCF_VD_Set_Type_D != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_Set_Type_D_b2;
      * pFCF_VD_Set_Type_D = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_TTC_Thresh_D
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCF_VD_TTC_Thresh_D - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_TTC_Thresh_D
*    FCF_VD_TTC_Thresh_D returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_TTC_Thresh_D signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_TTC_Thresh_D( uint16 * pFCF_VD_TTC_Thresh_D )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCF_VD_TTC_Thresh_D != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_TTC_Thresh_D_b10;
      * pFCF_VD_TTC_Thresh_D = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVD_FCF_VD_TTC_THRESH_D_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_TTC_D
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCF_VD_TTC_D - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_TTC_D
*    FCF_VD_TTC_D returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_TTC_D signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_TTC_D( uint16 * pFCF_VD_TTC_D )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCF_VD_TTC_D != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_TTC_D_b10;
      * pFCF_VD_TTC_D = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVD_FCF_VD_TTC_D_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_Buffer_D
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCF_VD_Buffer_D - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_Buffer_D
*    FCF_VD_Buffer_D returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_Buffer_D signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_Buffer_D( uint16 * pFCF_VD_Buffer_D )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCF_VD_Buffer_D != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_Buffer_D_b10;
      * pFCF_VD_Buffer_D = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVD_FCF_VD_BUFFER_D_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_CRC_E
*
* FUNCTION ARGUMENTS:
*    uint32 * pFCF_VD_CRC_E - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_CRC_E
*    FCF_VD_CRC_E returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_CRC_E signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_CRC_E( uint32 * pFCF_VD_CRC_E )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pFCF_VD_CRC_E != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_CRC_E_b32;
      * pFCF_VD_CRC_E = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_Alert_E
*
* FUNCTION ARGUMENTS:
*    COREFCFVDFCFVDAlertE * pFCF_VD_Alert_E - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_Alert_E
*    FCF_VD_Alert_E returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_Alert_E signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_Alert_E( COREFCFVDFCFVDAlertE * pFCF_VD_Alert_E )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVDFCFVDAlertE signal_value;
   
   if( pFCF_VD_Alert_E != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_Alert_E_b16;
      * pFCF_VD_Alert_E = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_ID_E
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_VD_ID_E - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_ID_E
*    FCF_VD_ID_E returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_ID_E signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_ID_E( uint8 * pFCF_VD_ID_E )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_VD_ID_E != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_ID_E_b8;
      * pFCF_VD_ID_E = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_Brake_Decel_Req_E
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_VD_Brake_Decel_Req_E - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_Brake_Decel_Req_E
*    FCF_VD_Brake_Decel_Req_E returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_Brake_Decel_Req_E signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_Brake_Decel_Req_E( uint8 * pFCF_VD_Brake_Decel_Req_E )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_VD_Brake_Decel_Req_E != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_Brake_Decel_Req_E_b8;
      * pFCF_VD_Brake_Decel_Req_E = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_AEB_Supp_E
*
* FUNCTION ARGUMENTS:
*    COREFCFVDFCFVDAEBSuppE * pFCF_VD_AEB_Supp_E - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_AEB_Supp_E
*    FCF_VD_AEB_Supp_E returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_AEB_Supp_E signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_AEB_Supp_E( COREFCFVDFCFVDAEBSuppE * pFCF_VD_AEB_Supp_E )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVDFCFVDAEBSuppE signal_value;
   
   if( pFCF_VD_AEB_Supp_E != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_AEB_Supp_E_b16;
      * pFCF_VD_AEB_Supp_E = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_Safety_Suppressed_E
*
* FUNCTION ARGUMENTS:
*    COREFCFVDFCFVDSafetySuppressedE * pFCF_VD_Safety_Suppressed_E - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_Safety_Suppressed_E
*    FCF_VD_Safety_Suppressed_E returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_Safety_Suppressed_E signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_Safety_Suppressed_E( COREFCFVDFCFVDSafetySuppressedE * pFCF_VD_Safety_Suppressed_E )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVDFCFVDSafetySuppressedE signal_value;
   
   if( pFCF_VD_Safety_Suppressed_E != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_Safety_Suppressed_E_b1;
      * pFCF_VD_Safety_Suppressed_E = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_Reserved_7
*
* FUNCTION ARGUMENTS:
*    uint16 * pReserved_7 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_7
*    Reserved_7 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_7 signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_Reserved_7( uint16 * pReserved_7 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pReserved_7 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.Reserved_7_b15;
      * pReserved_7 = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVD_RESERVED_7_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_FCW_Supp_E
*
* FUNCTION ARGUMENTS:
*    COREFCFVDFCFVDFCWSuppE * pFCF_VD_FCW_Supp_E - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_FCW_Supp_E
*    FCF_VD_FCW_Supp_E returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_FCW_Supp_E signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_FCW_Supp_E( COREFCFVDFCFVDFCWSuppE * pFCF_VD_FCW_Supp_E )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVDFCFVDFCWSuppE signal_value;
   
   if( pFCF_VD_FCW_Supp_E != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_FCW_Supp_E_b32;
      * pFCF_VD_FCW_Supp_E = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_Set_Type_E
*
* FUNCTION ARGUMENTS:
*    COREFCFVDFCFVDSetTypeE * pFCF_VD_Set_Type_E - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_Set_Type_E
*    FCF_VD_Set_Type_E returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_Set_Type_E signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_Set_Type_E( COREFCFVDFCFVDSetTypeE * pFCF_VD_Set_Type_E )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVDFCFVDSetTypeE signal_value;
   
   if( pFCF_VD_Set_Type_E != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_Set_Type_E_b2;
      * pFCF_VD_Set_Type_E = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_TTC_Thresh_E
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCF_VD_TTC_Thresh_E - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_TTC_Thresh_E
*    FCF_VD_TTC_Thresh_E returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_TTC_Thresh_E signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_TTC_Thresh_E( uint16 * pFCF_VD_TTC_Thresh_E )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCF_VD_TTC_Thresh_E != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_TTC_Thresh_E_b10;
      * pFCF_VD_TTC_Thresh_E = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVD_FCF_VD_TTC_THRESH_E_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_TTC_E
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCF_VD_TTC_E - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_TTC_E
*    FCF_VD_TTC_E returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_TTC_E signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_TTC_E( uint16 * pFCF_VD_TTC_E )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCF_VD_TTC_E != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_TTC_E_b10;
      * pFCF_VD_TTC_E = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVD_FCF_VD_TTC_E_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_Buffer_E
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCF_VD_Buffer_E - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_Buffer_E
*    FCF_VD_Buffer_E returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_Buffer_E signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_Buffer_E( uint16 * pFCF_VD_Buffer_E )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCF_VD_Buffer_E != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_Buffer_E_b10;
      * pFCF_VD_Buffer_E = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVD_FCF_VD_BUFFER_E_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_CRC_F
*
* FUNCTION ARGUMENTS:
*    uint32 * pFCF_VD_CRC_F - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_CRC_F
*    FCF_VD_CRC_F returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_CRC_F signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_CRC_F( uint32 * pFCF_VD_CRC_F )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pFCF_VD_CRC_F != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_CRC_F_b32;
      * pFCF_VD_CRC_F = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_Alert_F
*
* FUNCTION ARGUMENTS:
*    COREFCFVDFCFVDAlertF * pFCF_VD_Alert_F - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_Alert_F
*    FCF_VD_Alert_F returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_Alert_F signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_Alert_F( COREFCFVDFCFVDAlertF * pFCF_VD_Alert_F )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVDFCFVDAlertF signal_value;
   
   if( pFCF_VD_Alert_F != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_Alert_F_b16;
      * pFCF_VD_Alert_F = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_ID_F
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_VD_ID_F - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_ID_F
*    FCF_VD_ID_F returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_ID_F signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_ID_F( uint8 * pFCF_VD_ID_F )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_VD_ID_F != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_ID_F_b8;
      * pFCF_VD_ID_F = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_Brake_Decel_Req_F
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_VD_Brake_Decel_Req_F - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_Brake_Decel_Req_F
*    FCF_VD_Brake_Decel_Req_F returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_Brake_Decel_Req_F signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_Brake_Decel_Req_F( uint8 * pFCF_VD_Brake_Decel_Req_F )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_VD_Brake_Decel_Req_F != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_Brake_Decel_Req_F_b8;
      * pFCF_VD_Brake_Decel_Req_F = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_AEB_Supp_F
*
* FUNCTION ARGUMENTS:
*    COREFCFVDFCFVDAEBSuppF * pFCF_VD_AEB_Supp_F - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_AEB_Supp_F
*    FCF_VD_AEB_Supp_F returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_AEB_Supp_F signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_AEB_Supp_F( COREFCFVDFCFVDAEBSuppF * pFCF_VD_AEB_Supp_F )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVDFCFVDAEBSuppF signal_value;
   
   if( pFCF_VD_AEB_Supp_F != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_AEB_Supp_F_b16;
      * pFCF_VD_AEB_Supp_F = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_Safety_Suppressed_F
*
* FUNCTION ARGUMENTS:
*    COREFCFVDFCFVDSafetySuppressedF * pFCF_VD_Safety_Suppressed_F - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_Safety_Suppressed_F
*    FCF_VD_Safety_Suppressed_F returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_Safety_Suppressed_F signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_Safety_Suppressed_F( COREFCFVDFCFVDSafetySuppressedF * pFCF_VD_Safety_Suppressed_F )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVDFCFVDSafetySuppressedF signal_value;
   
   if( pFCF_VD_Safety_Suppressed_F != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_Safety_Suppressed_F_b1;
      * pFCF_VD_Safety_Suppressed_F = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_Reserved_8
*
* FUNCTION ARGUMENTS:
*    uint16 * pReserved_8 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_8
*    Reserved_8 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_8 signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_Reserved_8( uint16 * pReserved_8 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pReserved_8 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.Reserved_8_b15;
      * pReserved_8 = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVD_RESERVED_8_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_FCW_Supp_F
*
* FUNCTION ARGUMENTS:
*    COREFCFVDFCFVDFCWSuppF * pFCF_VD_FCW_Supp_F - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_FCW_Supp_F
*    FCF_VD_FCW_Supp_F returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_FCW_Supp_F signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_FCW_Supp_F( COREFCFVDFCFVDFCWSuppF * pFCF_VD_FCW_Supp_F )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVDFCFVDFCWSuppF signal_value;
   
   if( pFCF_VD_FCW_Supp_F != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_FCW_Supp_F_b32;
      * pFCF_VD_FCW_Supp_F = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_Set_Type_F
*
* FUNCTION ARGUMENTS:
*    COREFCFVDFCFVDSetTypeF * pFCF_VD_Set_Type_F - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_Set_Type_F
*    FCF_VD_Set_Type_F returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_Set_Type_F signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_Set_Type_F( COREFCFVDFCFVDSetTypeF * pFCF_VD_Set_Type_F )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVDFCFVDSetTypeF signal_value;
   
   if( pFCF_VD_Set_Type_F != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_Set_Type_F_b2;
      * pFCF_VD_Set_Type_F = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_TTC_Thresh_F
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCF_VD_TTC_Thresh_F - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_TTC_Thresh_F
*    FCF_VD_TTC_Thresh_F returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_TTC_Thresh_F signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_TTC_Thresh_F( uint16 * pFCF_VD_TTC_Thresh_F )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCF_VD_TTC_Thresh_F != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_TTC_Thresh_F_b10;
      * pFCF_VD_TTC_Thresh_F = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVD_FCF_VD_TTC_THRESH_F_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_TTC_F
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCF_VD_TTC_F - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_TTC_F
*    FCF_VD_TTC_F returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_TTC_F signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_TTC_F( uint16 * pFCF_VD_TTC_F )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCF_VD_TTC_F != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_TTC_F_b10;
      * pFCF_VD_TTC_F = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVD_FCF_VD_TTC_F_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_Buffer_F
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCF_VD_Buffer_F - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_Buffer_F
*    FCF_VD_Buffer_F returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_Buffer_F signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_Buffer_F( uint16 * pFCF_VD_Buffer_F )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCF_VD_Buffer_F != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_Buffer_F_b10;
      * pFCF_VD_Buffer_F = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVD_FCF_VD_BUFFER_F_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_CRC_G
*
* FUNCTION ARGUMENTS:
*    uint32 * pFCF_VD_CRC_G - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_CRC_G
*    FCF_VD_CRC_G returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_CRC_G signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_CRC_G( uint32 * pFCF_VD_CRC_G )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pFCF_VD_CRC_G != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_CRC_G_b32;
      * pFCF_VD_CRC_G = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_Alert_G
*
* FUNCTION ARGUMENTS:
*    COREFCFVDFCFVDAlertG * pFCF_VD_Alert_G - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_Alert_G
*    FCF_VD_Alert_G returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_Alert_G signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_Alert_G( COREFCFVDFCFVDAlertG * pFCF_VD_Alert_G )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVDFCFVDAlertG signal_value;
   
   if( pFCF_VD_Alert_G != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_Alert_G_b16;
      * pFCF_VD_Alert_G = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_ID_G
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_VD_ID_G - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_ID_G
*    FCF_VD_ID_G returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_ID_G signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_ID_G( uint8 * pFCF_VD_ID_G )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_VD_ID_G != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_ID_G_b8;
      * pFCF_VD_ID_G = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_Brake_Decel_Req_G
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_VD_Brake_Decel_Req_G - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_Brake_Decel_Req_G
*    FCF_VD_Brake_Decel_Req_G returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_Brake_Decel_Req_G signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_Brake_Decel_Req_G( uint8 * pFCF_VD_Brake_Decel_Req_G )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_VD_Brake_Decel_Req_G != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_Brake_Decel_Req_G_b8;
      * pFCF_VD_Brake_Decel_Req_G = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_AEB_Supp_G
*
* FUNCTION ARGUMENTS:
*    COREFCFVDFCFVDAEBSuppG * pFCF_VD_AEB_Supp_G - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_AEB_Supp_G
*    FCF_VD_AEB_Supp_G returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_AEB_Supp_G signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_AEB_Supp_G( COREFCFVDFCFVDAEBSuppG * pFCF_VD_AEB_Supp_G )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVDFCFVDAEBSuppG signal_value;
   
   if( pFCF_VD_AEB_Supp_G != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_AEB_Supp_G_b16;
      * pFCF_VD_AEB_Supp_G = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_Safety_Suppressed_G
*
* FUNCTION ARGUMENTS:
*    COREFCFVDFCFVDSafetySuppressedG * pFCF_VD_Safety_Suppressed_G - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_Safety_Suppressed_G
*    FCF_VD_Safety_Suppressed_G returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_Safety_Suppressed_G signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_Safety_Suppressed_G( COREFCFVDFCFVDSafetySuppressedG * pFCF_VD_Safety_Suppressed_G )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVDFCFVDSafetySuppressedG signal_value;
   
   if( pFCF_VD_Safety_Suppressed_G != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_Safety_Suppressed_G_b1;
      * pFCF_VD_Safety_Suppressed_G = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_Reserved_9
*
* FUNCTION ARGUMENTS:
*    uint16 * pReserved_9 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_9
*    Reserved_9 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_9 signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_Reserved_9( uint16 * pReserved_9 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pReserved_9 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.Reserved_9_b15;
      * pReserved_9 = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVD_RESERVED_9_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_FCW_Supp_G
*
* FUNCTION ARGUMENTS:
*    COREFCFVDFCFVDFCWSuppG * pFCF_VD_FCW_Supp_G - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_FCW_Supp_G
*    FCF_VD_FCW_Supp_G returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_FCW_Supp_G signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_FCW_Supp_G( COREFCFVDFCFVDFCWSuppG * pFCF_VD_FCW_Supp_G )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVDFCFVDFCWSuppG signal_value;
   
   if( pFCF_VD_FCW_Supp_G != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_FCW_Supp_G_b32;
      * pFCF_VD_FCW_Supp_G = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_Set_Type_G
*
* FUNCTION ARGUMENTS:
*    COREFCFVDFCFVDSetTypeG * pFCF_VD_Set_Type_G - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_Set_Type_G
*    FCF_VD_Set_Type_G returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_Set_Type_G signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_Set_Type_G( COREFCFVDFCFVDSetTypeG * pFCF_VD_Set_Type_G )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVDFCFVDSetTypeG signal_value;
   
   if( pFCF_VD_Set_Type_G != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_Set_Type_G_b2;
      * pFCF_VD_Set_Type_G = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_TTC_Thresh_G
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCF_VD_TTC_Thresh_G - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_TTC_Thresh_G
*    FCF_VD_TTC_Thresh_G returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_TTC_Thresh_G signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_TTC_Thresh_G( uint16 * pFCF_VD_TTC_Thresh_G )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCF_VD_TTC_Thresh_G != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_TTC_Thresh_G_b10;
      * pFCF_VD_TTC_Thresh_G = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVD_FCF_VD_TTC_THRESH_G_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_TTC_G
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCF_VD_TTC_G - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_TTC_G
*    FCF_VD_TTC_G returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_TTC_G signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_TTC_G( uint16 * pFCF_VD_TTC_G )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCF_VD_TTC_G != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_TTC_G_b10;
      * pFCF_VD_TTC_G = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVD_FCF_VD_TTC_G_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_Buffer_G
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCF_VD_Buffer_G - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_Buffer_G
*    FCF_VD_Buffer_G returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_Buffer_G signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_Buffer_G( uint16 * pFCF_VD_Buffer_G )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCF_VD_Buffer_G != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_Buffer_G_b10;
      * pFCF_VD_Buffer_G = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVD_FCF_VD_BUFFER_G_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_CRC_H
*
* FUNCTION ARGUMENTS:
*    uint32 * pFCF_VD_CRC_H - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_CRC_H
*    FCF_VD_CRC_H returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_CRC_H signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_CRC_H( uint32 * pFCF_VD_CRC_H )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pFCF_VD_CRC_H != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_CRC_H_b32;
      * pFCF_VD_CRC_H = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_Alert_H
*
* FUNCTION ARGUMENTS:
*    COREFCFVDFCFVDAlertH * pFCF_VD_Alert_H - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_Alert_H
*    FCF_VD_Alert_H returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_Alert_H signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_Alert_H( COREFCFVDFCFVDAlertH * pFCF_VD_Alert_H )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVDFCFVDAlertH signal_value;
   
   if( pFCF_VD_Alert_H != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_Alert_H_b16;
      * pFCF_VD_Alert_H = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_ID_H
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_VD_ID_H - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_ID_H
*    FCF_VD_ID_H returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_ID_H signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_ID_H( uint8 * pFCF_VD_ID_H )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_VD_ID_H != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_ID_H_b8;
      * pFCF_VD_ID_H = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_Brake_Decel_Req_H
*
* FUNCTION ARGUMENTS:
*    uint8 * pFCF_VD_Brake_Decel_Req_H - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_Brake_Decel_Req_H
*    FCF_VD_Brake_Decel_Req_H returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_Brake_Decel_Req_H signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_Brake_Decel_Req_H( uint8 * pFCF_VD_Brake_Decel_Req_H )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFCF_VD_Brake_Decel_Req_H != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_Brake_Decel_Req_H_b8;
      * pFCF_VD_Brake_Decel_Req_H = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_AEB_Supp_H
*
* FUNCTION ARGUMENTS:
*    COREFCFVDFCFVDAEBSuppH * pFCF_VD_AEB_Supp_H - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_AEB_Supp_H
*    FCF_VD_AEB_Supp_H returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_AEB_Supp_H signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_AEB_Supp_H( COREFCFVDFCFVDAEBSuppH * pFCF_VD_AEB_Supp_H )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVDFCFVDAEBSuppH signal_value;
   
   if( pFCF_VD_AEB_Supp_H != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_AEB_Supp_H_b16;
      * pFCF_VD_AEB_Supp_H = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_Safety_Suppressed_H
*
* FUNCTION ARGUMENTS:
*    COREFCFVDFCFVDSafetySuppressedH * pFCF_VD_Safety_Suppressed_H - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_Safety_Suppressed_H
*    FCF_VD_Safety_Suppressed_H returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_Safety_Suppressed_H signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_Safety_Suppressed_H( COREFCFVDFCFVDSafetySuppressedH * pFCF_VD_Safety_Suppressed_H )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVDFCFVDSafetySuppressedH signal_value;
   
   if( pFCF_VD_Safety_Suppressed_H != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_Safety_Suppressed_H_b1;
      * pFCF_VD_Safety_Suppressed_H = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_Reserved_10
*
* FUNCTION ARGUMENTS:
*    uint16 * pReserved_10 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_10
*    Reserved_10 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_10 signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_Reserved_10( uint16 * pReserved_10 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pReserved_10 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.Reserved_10_b15;
      * pReserved_10 = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVD_RESERVED_10_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_FCW_Supp_H
*
* FUNCTION ARGUMENTS:
*    COREFCFVDFCFVDFCWSuppH * pFCF_VD_FCW_Supp_H - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_FCW_Supp_H
*    FCF_VD_FCW_Supp_H returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_FCW_Supp_H signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_FCW_Supp_H( COREFCFVDFCFVDFCWSuppH * pFCF_VD_FCW_Supp_H )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVDFCFVDFCWSuppH signal_value;
   
   if( pFCF_VD_FCW_Supp_H != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_FCW_Supp_H_b32;
      * pFCF_VD_FCW_Supp_H = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_Set_Type_H
*
* FUNCTION ARGUMENTS:
*    COREFCFVDFCFVDSetTypeH * pFCF_VD_Set_Type_H - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_Set_Type_H
*    FCF_VD_Set_Type_H returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_Set_Type_H signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_Set_Type_H( COREFCFVDFCFVDSetTypeH * pFCF_VD_Set_Type_H )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFCFVDFCFVDSetTypeH signal_value;
   
   if( pFCF_VD_Set_Type_H != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_Set_Type_H_b2;
      * pFCF_VD_Set_Type_H = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_TTC_Thresh_H
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCF_VD_TTC_Thresh_H - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_TTC_Thresh_H
*    FCF_VD_TTC_Thresh_H returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_TTC_Thresh_H signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_TTC_Thresh_H( uint16 * pFCF_VD_TTC_Thresh_H )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCF_VD_TTC_Thresh_H != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_TTC_Thresh_H_b10;
      * pFCF_VD_TTC_Thresh_H = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVD_FCF_VD_TTC_THRESH_H_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_TTC_H
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCF_VD_TTC_H - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_TTC_H
*    FCF_VD_TTC_H returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_TTC_H signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_TTC_H( uint16 * pFCF_VD_TTC_H )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCF_VD_TTC_H != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_TTC_H_b10;
      * pFCF_VD_TTC_H = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVD_FCF_VD_TTC_H_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFCFVD_FCF_VD_Buffer_H
*
* FUNCTION ARGUMENTS:
*    uint16 * pFCF_VD_Buffer_H - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FCF_VD_Buffer_H
*    FCF_VD_Buffer_H returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FCF_VD_Buffer_H signal value of Core_FCF_VD_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFCFVD_FCF_VD_Buffer_H( uint16 * pFCF_VD_Buffer_H )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pFCF_VD_Buffer_H != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFCFVD_ParamsApp_s.FCF_VD_Buffer_H_b10;
      * pFCF_VD_Buffer_H = signal_value;
      if( signal_value <= C_EYEQMSG_COREFCFVD_FCF_VD_BUFFER_H_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

