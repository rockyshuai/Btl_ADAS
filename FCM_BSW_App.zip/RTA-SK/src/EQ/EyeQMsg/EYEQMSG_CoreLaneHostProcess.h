#ifndef _EYEQMSG_CORELANEHOSTPROCESS_H_
#define _EYEQMSG_CORELANEHOSTPROCESS_H_

/*****************************************************************************
                  Included header files
*****************************************************************************/
#include <Std_Types.h>

/*****************************************************************************
                  Include files
*****************************************************************************/
/*****************************************************************************
                  Exported symbolic constants
*****************************************************************************/
#define C_EYEQMSG_CORELANEHOSTvH_VIRTUAL_OBJECT_INDEX_RMAX ( 6U )

/* Datagram message ID */
#define C_EYEQMSG_CORELANEHOSTvH_MSG_ID                       ( 0x8EU )
#define C_EYEQMSG_CORELANEHOSTvO_MSG_ID                       ( 0x8EU )
#define C_EYEQMSG_CORELANEHOST_MSG_ID                         ( 0x8EU )

/* Datagram message lengths */
#define C_EYEQMSG_CORELANEHOSTvH_MSG_LEN                      ( sizeof(EYEQMSG_CORELANEHOSTvH_Params_t) )
#define C_EYEQMSG_CORELANEHOSTvO_MSG_LEN                      ( sizeof(EYEQMSG_CORELANEHOSTvO_Params_t) )
#define C_EYEQMSG_CORELANEHOST_MSG_LEN                        ( sizeof(EYEQMSG_CORELANEHOST_Params_t) )

/* Protocol ENUMs */

/* MCU output messages */

/* Virtual_HEADER_msg_Core_Lanes_Host_protocol Enums */
/* Reserved_2_b22 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEHOSTvH_RESERVED_2_RMIN              ( 0U )
#define C_EYEQMSG_CORELANEHOSTvH_RESERVED_2_RMAX              ( 0U )
#define C_EYEQMSG_CORELANEHOSTvH_RESERVED_2_NUMR              ( 1U )
#define C_EYEQMSG_CORELANEHOSTvH_RESERVED_2_DEMNR             ( 1U )
#define C_EYEQMSG_CORELANEHOSTvH_RESERVED_2_OFFSET            ( 0U )

/* LH_Estimated_Width_b10 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEHOSTvH_LH_ESTIMATED_WIDTH_RMIN      ( 0U )
#define C_EYEQMSG_CORELANEHOSTvH_LH_ESTIMATED_WIDTH_RMAX      ( 1000U )
#define C_EYEQMSG_CORELANEHOSTvH_LH_ESTIMATED_WIDTH_NUMR      ( 1U )
#define C_EYEQMSG_CORELANEHOSTvH_LH_ESTIMATED_WIDTH_DEMNR     ( 100U )
#define C_EYEQMSG_CORELANEHOSTvH_LH_ESTIMATED_WIDTH_OFFSET    ( 0U )

/* Reserved_1_b5 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEHOSTvH_RESERVED_1_RMIN              ( 0U )
#define C_EYEQMSG_CORELANEHOSTvH_RESERVED_1_RMAX              ( 0U )
#define C_EYEQMSG_CORELANEHOSTvH_RESERVED_1_NUMR              ( 1U )
#define C_EYEQMSG_CORELANEHOSTvH_RESERVED_1_DEMNR             ( 1U )
#define C_EYEQMSG_CORELANEHOSTvH_RESERVED_1_OFFSET            ( 0U )

/* LH_Lanes_Count_b3 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEHOSTvH_LH_LANES_COUNT_RMIN          ( 0U )
#define C_EYEQMSG_CORELANEHOSTvH_LH_LANES_COUNT_RMAX          ( 6U )
#define C_EYEQMSG_CORELANEHOSTvH_LH_LANES_COUNT_NUMR          ( 1U )
#define C_EYEQMSG_CORELANEHOSTvH_LH_LANES_COUNT_DEMNR         ( 1U )
#define C_EYEQMSG_CORELANEHOSTvH_LH_LANES_COUNT_OFFSET        ( 0U )

/* LH_Sync_ID_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEHOSTvH_LH_SYNC_ID_RMIN              ( 0U )
#define C_EYEQMSG_CORELANEHOSTvH_LH_SYNC_ID_RMAX              ( 255U )
#define C_EYEQMSG_CORELANEHOSTvH_LH_SYNC_ID_NUMR              ( 1U )
#define C_EYEQMSG_CORELANEHOSTvH_LH_SYNC_ID_DEMNR             ( 1U )
#define C_EYEQMSG_CORELANEHOSTvH_LH_SYNC_ID_OFFSET            ( 0U )

/* LH_Protocol_Version_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEHOSTvH_LH_PROTOCOL_VERSION_RMIN     ( 7U )
#define C_EYEQMSG_CORELANEHOSTvH_LH_PROTOCOL_VERSION_RMAX     ( 7U )
#define C_EYEQMSG_CORELANEHOSTvH_LH_PROTOCOL_VERSION_NUMR     ( 1U )
#define C_EYEQMSG_CORELANEHOSTvH_LH_PROTOCOL_VERSION_DEMNR    ( 1U )
#define C_EYEQMSG_CORELANEHOSTvH_LH_PROTOCOL_VERSION_OFFSET   ( 0U )

/* LH_Zero_byte_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEHOSTvH_LH_ZERO_BYTE_RMIN            ( 0U )
#define C_EYEQMSG_CORELANEHOSTvH_LH_ZERO_BYTE_RMAX            ( 255U )
#define C_EYEQMSG_CORELANEHOSTvH_LH_ZERO_BYTE_NUMR            ( 1U )
#define C_EYEQMSG_CORELANEHOSTvH_LH_ZERO_BYTE_DEMNR           ( 1U )
#define C_EYEQMSG_CORELANEHOSTvH_LH_ZERO_BYTE_OFFSET          ( 0U )


/* Virtual_OBJECT_msg_Core_Lanes_Host_protocol Enums */
/* LH_Detection_Source_0_b2 signal Enums */
typedef uint8 CORELANEHOSTvOLHDetectionSource0;
#define C_EYEQMSG_CORELANEHOSTvO_LH_DETECTION_SOURCE_0_UNKNOWN ( CORELANEHOSTvOLHDetectionSource0 ) ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_DETECTION_SOURCE_0_FRONT  ( CORELANEHOSTvOLHDetectionSource0 ) ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_DETECTION_SOURCE_0_REAR   ( CORELANEHOSTvOLHDetectionSource0 ) ( 2U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_DETECTION_SOURCE_0_SIDE   ( CORELANEHOSTvOLHDetectionSource0 ) ( 3U )

/* LH_Detection_Source_0_b2 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEHOSTvO_LH_DETECTION_SOURCE_0_RMIN   ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_DETECTION_SOURCE_0_RMAX   ( 3U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_DETECTION_SOURCE_0_NUMR   ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_DETECTION_SOURCE_0_DEMNR  ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_DETECTION_SOURCE_0_OFFSET ( 0U )

/* LH_Second_VR_End_0_b15 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEHOSTvO_LH_SECOND_VR_END_0_RMIN      ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_SECOND_VR_END_0_RMAX      ( 20000U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_SECOND_VR_END_0_NUMR      ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_SECOND_VR_END_0_DEMNR     ( 100U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_SECOND_VR_END_0_OFFSET    ( 0U )

/* LH_Second_VR_Start_0_b15 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEHOSTvO_LH_SECOND_VR_START_0_RMIN    ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_SECOND_VR_START_0_RMAX    ( 20000U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_SECOND_VR_START_0_NUMR    ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_SECOND_VR_START_0_DEMNR   ( 100U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_SECOND_VR_START_0_OFFSET  ( 0U )

/* LH_Line_Second_C3_0_sb32 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEHOSTvO_LH_LINE_SECOND_C3_0_RMIN     ( -0.004 )
#define C_EYEQMSG_CORELANEHOSTvO_LH_LINE_SECOND_C3_0_RMAX     ( 0.004 )
#define C_EYEQMSG_CORELANEHOSTvO_LH_LINE_SECOND_C3_0_NUMR     ( 1 )
#define C_EYEQMSG_CORELANEHOSTvO_LH_LINE_SECOND_C3_0_DEMNR    ( 1 )
#define C_EYEQMSG_CORELANEHOSTvO_LH_LINE_SECOND_C3_0_OFFSET   ( 0U )

/* LH_Line_Second_C2_0_sb32 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEHOSTvO_LH_LINE_SECOND_C2_0_RMIN     ( -0.125 )
#define C_EYEQMSG_CORELANEHOSTvO_LH_LINE_SECOND_C2_0_RMAX     ( 0.125 )
#define C_EYEQMSG_CORELANEHOSTvO_LH_LINE_SECOND_C2_0_NUMR     ( 1 )
#define C_EYEQMSG_CORELANEHOSTvO_LH_LINE_SECOND_C2_0_DEMNR    ( 1 )
#define C_EYEQMSG_CORELANEHOSTvO_LH_LINE_SECOND_C2_0_OFFSET   ( 0U )

/* LH_Line_Second_C1_0_sb32 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEHOSTvO_LH_LINE_SECOND_C1_0_RMIN     ( -2 )
#define C_EYEQMSG_CORELANEHOSTvO_LH_LINE_SECOND_C1_0_RMAX     ( 2 )
#define C_EYEQMSG_CORELANEHOSTvO_LH_LINE_SECOND_C1_0_NUMR     ( 1 )
#define C_EYEQMSG_CORELANEHOSTvO_LH_LINE_SECOND_C1_0_DEMNR    ( 1 )
#define C_EYEQMSG_CORELANEHOSTvO_LH_LINE_SECOND_C1_0_OFFSET   ( 0U )

/* LH_Line_Second_C0_0_sb32 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEHOSTvO_LH_LINE_SECOND_C0_0_RMIN     ( -30 )
#define C_EYEQMSG_CORELANEHOSTvO_LH_LINE_SECOND_C0_0_RMAX     ( 30 )
#define C_EYEQMSG_CORELANEHOSTvO_LH_LINE_SECOND_C0_0_NUMR     ( 1 )
#define C_EYEQMSG_CORELANEHOSTvO_LH_LINE_SECOND_C0_0_DEMNR    ( 1 )
#define C_EYEQMSG_CORELANEHOSTvO_LH_LINE_SECOND_C0_0_OFFSET   ( 0U )

/* Reserved_8_0_b2 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEHOSTvO_RESERVED_8_0_RMIN            ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_RESERVED_8_0_RMAX            ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_RESERVED_8_0_NUMR            ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_RESERVED_8_0_DEMNR           ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_RESERVED_8_0_OFFSET          ( 0U )

/* LH_Second_Measured_VR_End_0_b15 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEHOSTvO_LH_SECOND_MEASURED_VR_END_0_RMIN ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_SECOND_MEASURED_VR_END_0_RMAX ( 20000U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_SECOND_MEASURED_VR_END_0_NUMR ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_SECOND_MEASURED_VR_END_0_DEMNR ( 100U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_SECOND_MEASURED_VR_END_0_OFFSET ( 0U )

/* LH_First_Measured_VR_End_0_b15 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEHOSTvO_LH_FIRST_MEASURED_VR_END_0_RMIN ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_FIRST_MEASURED_VR_END_0_RMAX ( 20000U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_FIRST_MEASURED_VR_END_0_NUMR ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_FIRST_MEASURED_VR_END_0_DEMNR ( 100U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_FIRST_MEASURED_VR_END_0_OFFSET ( 0U )

/* Reserved_7_0_b2 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEHOSTvO_RESERVED_7_0_RMIN            ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_RESERVED_7_0_RMAX            ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_RESERVED_7_0_NUMR            ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_RESERVED_7_0_DEMNR           ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_RESERVED_7_0_OFFSET          ( 0U )

/* LH_First_VR_End_0_b15 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEHOSTvO_LH_FIRST_VR_END_0_RMIN       ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_FIRST_VR_END_0_RMAX       ( 20000U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_FIRST_VR_END_0_NUMR       ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_FIRST_VR_END_0_DEMNR      ( 100U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_FIRST_VR_END_0_OFFSET     ( 0U )

/* LH_First_VR_Start_0_b15 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEHOSTvO_LH_FIRST_VR_START_0_RMIN     ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_FIRST_VR_START_0_RMAX     ( 20000U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_FIRST_VR_START_0_NUMR     ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_FIRST_VR_START_0_DEMNR    ( 100U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_FIRST_VR_START_0_OFFSET   ( 0U )

/* LH_Line_First_C3_0_sb32 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEHOSTvO_LH_LINE_FIRST_C3_0_RMIN      ( -0.004 )
#define C_EYEQMSG_CORELANEHOSTvO_LH_LINE_FIRST_C3_0_RMAX      ( 0.004 )
#define C_EYEQMSG_CORELANEHOSTvO_LH_LINE_FIRST_C3_0_NUMR      ( 1 )
#define C_EYEQMSG_CORELANEHOSTvO_LH_LINE_FIRST_C3_0_DEMNR     ( 1 )
#define C_EYEQMSG_CORELANEHOSTvO_LH_LINE_FIRST_C3_0_OFFSET    ( 0U )

/* LH_Line_First_C2_0_sb32 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEHOSTvO_LH_LINE_FIRST_C2_0_RMIN      ( -0.125 )
#define C_EYEQMSG_CORELANEHOSTvO_LH_LINE_FIRST_C2_0_RMAX      ( 0.125 )
#define C_EYEQMSG_CORELANEHOSTvO_LH_LINE_FIRST_C2_0_NUMR      ( 1 )
#define C_EYEQMSG_CORELANEHOSTvO_LH_LINE_FIRST_C2_0_DEMNR     ( 1 )
#define C_EYEQMSG_CORELANEHOSTvO_LH_LINE_FIRST_C2_0_OFFSET    ( 0U )

/* LH_Line_First_C1_0_sb32 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEHOSTvO_LH_LINE_FIRST_C1_0_RMIN      ( -2 )
#define C_EYEQMSG_CORELANEHOSTvO_LH_LINE_FIRST_C1_0_RMAX      ( 2 )
#define C_EYEQMSG_CORELANEHOSTvO_LH_LINE_FIRST_C1_0_NUMR      ( 1 )
#define C_EYEQMSG_CORELANEHOSTvO_LH_LINE_FIRST_C1_0_DEMNR     ( 1 )
#define C_EYEQMSG_CORELANEHOSTvO_LH_LINE_FIRST_C1_0_OFFSET    ( 0U )

/* LH_Line_First_C0_0_sb32 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEHOSTvO_LH_LINE_FIRST_C0_0_RMIN      ( -30 )
#define C_EYEQMSG_CORELANEHOSTvO_LH_LINE_FIRST_C0_0_RMAX      ( 30 )
#define C_EYEQMSG_CORELANEHOSTvO_LH_LINE_FIRST_C0_0_NUMR      ( 1 )
#define C_EYEQMSG_CORELANEHOSTvO_LH_LINE_FIRST_C0_0_DEMNR     ( 1 )
#define C_EYEQMSG_CORELANEHOSTvO_LH_LINE_FIRST_C0_0_OFFSET    ( 0U )

/* Reserved_6_0_b15 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEHOSTvO_RESERVED_6_0_RMIN            ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_RESERVED_6_0_RMAX            ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_RESERVED_6_0_NUMR            ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_RESERVED_6_0_DEMNR           ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_RESERVED_6_0_OFFSET          ( 0U )

/* LH_Is_Multi_Clothoid_0_b1 signal Enums */
typedef boolean CORELANEHOSTvOLHIsMultiClothoid0;
#define C_EYEQMSG_CORELANEHOSTvO_LH_IS_MULTI_CLOTHOID_0_FALSE ( CORELANEHOSTvOLHIsMultiClothoid0 ) ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_IS_MULTI_CLOTHOID_0_TRUE  ( CORELANEHOSTvOLHIsMultiClothoid0 ) ( 1U )

/* LH_Is_Multi_Clothoid_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEHOSTvO_LH_IS_MULTI_CLOTHOID_0_RMIN  ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_IS_MULTI_CLOTHOID_0_RMAX  ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_IS_MULTI_CLOTHOID_0_NUMR  ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_IS_MULTI_CLOTHOID_0_DEMNR ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_IS_MULTI_CLOTHOID_0_OFFSET ( 0U )

/* LH_Dash_Average_Gap_0_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEHOSTvO_LH_DASH_AVERAGE_GAP_0_RMIN   ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_DASH_AVERAGE_GAP_0_RMAX   ( 200U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_DASH_AVERAGE_GAP_0_NUMR   ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_DASH_AVERAGE_GAP_0_DEMNR  ( 10U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_DASH_AVERAGE_GAP_0_OFFSET ( 0U )

/* LH_Dash_Average_Length_0_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEHOSTvO_LH_DASH_AVERAGE_LENGTH_0_RMIN ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_DASH_AVERAGE_LENGTH_0_RMAX ( 200U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_DASH_AVERAGE_LENGTH_0_NUMR ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_DASH_AVERAGE_LENGTH_0_DEMNR ( 10U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_DASH_AVERAGE_LENGTH_0_OFFSET ( 0U )

/* Reserved_5_0_b7 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEHOSTvO_RESERVED_5_0_RMIN            ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_RESERVED_5_0_RMAX            ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_RESERVED_5_0_NUMR            ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_RESERVED_5_0_DEMNR           ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_RESERVED_5_0_OFFSET          ( 0U )

/* LH_Marker_Width_STD_0_b7 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEHOSTvO_LH_MARKER_WIDTH_STD_0_RMIN   ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_MARKER_WIDTH_STD_0_RMAX   ( 100U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_MARKER_WIDTH_STD_0_NUMR   ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_MARKER_WIDTH_STD_0_DEMNR  ( 200U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_MARKER_WIDTH_STD_0_OFFSET ( 0U )

/* LH_Marker_Width_0_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEHOSTvO_LH_MARKER_WIDTH_0_RMIN       ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_MARKER_WIDTH_0_RMAX       ( 70U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_MARKER_WIDTH_0_NUMR       ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_MARKER_WIDTH_0_DEMNR      ( 100U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_MARKER_WIDTH_0_OFFSET     ( 0U )

/* LH_Crossing_0_b1 signal Enums */
typedef boolean CORELANEHOSTvOLHCrossing0;
#define C_EYEQMSG_CORELANEHOSTvO_LH_CROSSING_0_FALSE          ( CORELANEHOSTvOLHCrossing0 ) ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_CROSSING_0_TRUE           ( CORELANEHOSTvOLHCrossing0 ) ( 1U )

/* LH_Crossing_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEHOSTvO_LH_CROSSING_0_RMIN           ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_CROSSING_0_RMAX           ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_CROSSING_0_NUMR           ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_CROSSING_0_DEMNR          ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_CROSSING_0_OFFSET         ( 0U )

/* LH_Side_0_b2 signal Enums */
typedef uint8 CORELANEHOSTvOLHSide0;
#define C_EYEQMSG_CORELANEHOSTvO_LH_SIDE_0_UNKNOWN            ( CORELANEHOSTvOLHSide0 ) ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_SIDE_0_LEFT               ( CORELANEHOSTvOLHSide0 ) ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_SIDE_0_RIGHT              ( CORELANEHOSTvOLHSide0 ) ( 2U )

/* LH_Side_0_b2 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEHOSTvO_LH_SIDE_0_RMIN               ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_SIDE_0_RMAX               ( 2U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_SIDE_0_NUMR               ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_SIDE_0_DEMNR              ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_SIDE_0_OFFSET             ( 0U )

/* LH_Lanemark_Type_Conf_0_b7 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEHOSTvO_LH_LANEMARK_TYPE_CONF_0_RMIN ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_LANEMARK_TYPE_CONF_0_RMAX ( 100U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_LANEMARK_TYPE_CONF_0_NUMR ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_LANEMARK_TYPE_CONF_0_DEMNR ( 100U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_LANEMARK_TYPE_CONF_0_OFFSET ( 0U )

/* Reserved_4_0_b5 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEHOSTvO_RESERVED_4_0_RMIN            ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_RESERVED_4_0_RMAX            ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_RESERVED_4_0_NUMR            ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_RESERVED_4_0_DEMNR           ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_RESERVED_4_0_OFFSET          ( 0U )

/* LH_DECEL_Type_0_b3 signal Enums */
typedef uint8 CORELANEHOSTvOLHDECELType0;
#define C_EYEQMSG_CORELANEHOSTvO_LH_DECEL_TYPE_0_NO_DECEL     ( CORELANEHOSTvOLHDECELType0 ) ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_DECEL_TYPE_0_SOLID        ( CORELANEHOSTvOLHDECELType0 ) ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_DECEL_TYPE_0_DASHED       ( CORELANEHOSTvOLHDECELType0 ) ( 2U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_DECEL_TYPE_0_UNDECIDED    ( CORELANEHOSTvOLHDECELType0 ) ( 3U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_DECEL_TYPE_0_RESERVED_2   ( CORELANEHOSTvOLHDECELType0 ) ( 4U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_DECEL_TYPE_0_RESERVED_3   ( CORELANEHOSTvOLHDECELType0 ) ( 5U )

/* LH_DECEL_Type_0_b3 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEHOSTvO_LH_DECEL_TYPE_0_RMIN         ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_DECEL_TYPE_0_RMAX         ( 5U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_DECEL_TYPE_0_NUMR         ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_DECEL_TYPE_0_DEMNR        ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_DECEL_TYPE_0_OFFSET       ( 0U )

/* LH_DLM_Type_0_b3 signal Enums */
typedef uint8 CORELANEHOSTvOLHDLMType0;
#define C_EYEQMSG_CORELANEHOSTvO_LH_DLM_TYPE_0_NOT_DLM        ( CORELANEHOSTvOLHDLMType0 ) ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_DLM_TYPE_0_SOLID_DASHED   ( CORELANEHOSTvOLHDLMType0 ) ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_DLM_TYPE_0_DASHED_SOLID   ( CORELANEHOSTvOLHDLMType0 ) ( 2U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_DLM_TYPE_0_SOLID_SOLID    ( CORELANEHOSTvOLHDLMType0 ) ( 3U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_DLM_TYPE_0_DASHED_DASHED  ( CORELANEHOSTvOLHDLMType0 ) ( 4U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_DLM_TYPE_0_UNDECIDED      ( CORELANEHOSTvOLHDLMType0 ) ( 5U )

/* LH_DLM_Type_0_b3 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEHOSTvO_LH_DLM_TYPE_0_RMIN           ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_DLM_TYPE_0_RMAX           ( 5U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_DLM_TYPE_0_NUMR           ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_DLM_TYPE_0_DEMNR          ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_DLM_TYPE_0_OFFSET         ( 0U )

/* LH_Lanemark_Type_0_b4 signal Enums */
typedef uint8 CORELANEHOSTvOLHLanemarkType0;
#define C_EYEQMSG_CORELANEHOSTvO_LH_LANEMARK_TYPE_0_UNDECIDED ( CORELANEHOSTvOLHLanemarkType0 ) ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_LANEMARK_TYPE_0_SOLID     ( CORELANEHOSTvOLHLanemarkType0 ) ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_LANEMARK_TYPE_0_DASHED    ( CORELANEHOSTvOLHLanemarkType0 ) ( 2U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_LANEMARK_TYPE_0_DLM       ( CORELANEHOSTvOLHLanemarkType0 ) ( 3U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_LANEMARK_TYPE_0_BOTTS     ( CORELANEHOSTvOLHLanemarkType0 ) ( 4U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_LANEMARK_TYPE_0_DECELERATION ( CORELANEHOSTvOLHLanemarkType0 ) ( 5U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_LANEMARK_TYPE_0_HOV_LANE  ( CORELANEHOSTvOLHLanemarkType0 ) ( 6U )

/* LH_Lanemark_Type_0_b4 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEHOSTvO_LH_LANEMARK_TYPE_0_RMIN      ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_LANEMARK_TYPE_0_RMAX      ( 6U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_LANEMARK_TYPE_0_NUMR      ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_LANEMARK_TYPE_0_DEMNR     ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_LANEMARK_TYPE_0_OFFSET    ( 0U )

/* LH_Color_Confidence_0_b7 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEHOSTvO_LH_COLOR_CONFIDENCE_0_RMIN   ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_COLOR_CONFIDENCE_0_RMAX   ( 100U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_COLOR_CONFIDENCE_0_NUMR   ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_COLOR_CONFIDENCE_0_DEMNR  ( 100U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_COLOR_CONFIDENCE_0_OFFSET ( 0U )

/* LH_Color_0_b2 signal Enums */
typedef uint8 CORELANEHOSTvOLHColor0;
#define C_EYEQMSG_CORELANEHOSTvO_LH_COLOR_0_UNDECIDED         ( CORELANEHOSTvOLHColor0 ) ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_COLOR_0_WHITE             ( CORELANEHOSTvOLHColor0 ) ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_COLOR_0_YELLOW            ( CORELANEHOSTvOLHColor0 ) ( 2U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_COLOR_0_BLUE              ( CORELANEHOSTvOLHColor0 ) ( 3U )

/* LH_Color_0_b2 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEHOSTvO_LH_COLOR_0_RMIN              ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_COLOR_0_RMAX              ( 3U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_COLOR_0_NUMR              ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_COLOR_0_DEMNR             ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_COLOR_0_OFFSET            ( 0U )

/* LH_Availability_State_0_b2 signal Enums */
typedef uint8 CORELANEHOSTvOLHAvailabilityState0;
#define C_EYEQMSG_CORELANEHOSTvO_LH_AVAILABILITY_STATE_0_NOT_AVAILABLE ( CORELANEHOSTvOLHAvailabilityState0 ) ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_AVAILABILITY_STATE_0_PREDICATED ( CORELANEHOSTvOLHAvailabilityState0 ) ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_AVAILABILITY_STATE_0_DETECTED ( CORELANEHOSTvOLHAvailabilityState0 ) ( 2U )

/* LH_Availability_State_0_b2 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEHOSTvO_LH_AVAILABILITY_STATE_0_RMIN ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_AVAILABILITY_STATE_0_RMAX ( 2U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_AVAILABILITY_STATE_0_NUMR ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_AVAILABILITY_STATE_0_DEMNR ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_AVAILABILITY_STATE_0_OFFSET ( 0U )

/* LH_Prediction_Reason_0_b6 signal Enums */
typedef uint8 CORELANEHOSTvOLHPredictionReason0;
#define C_EYEQMSG_CORELANEHOSTvO_LH_PREDICTION_REASON_0__BIT_0_LOSS ( CORELANEHOSTvOLHPredictionReason0 ) ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_PREDICTION_REASON_0__BIT_1_MERGE ( CORELANEHOSTvOLHPredictionReason0 ) ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_PREDICTION_REASON_0__BIT_2_SHADOW ( CORELANEHOSTvOLHPredictionReason0 ) ( 2U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_PREDICTION_REASON_0__BIT_3_DIVERGING ( CORELANEHOSTvOLHPredictionReason0 ) ( 3U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_PREDICTION_REASON_0__BIT_4_OCCLUDED ( CORELANEHOSTvOLHPredictionReason0 ) ( 4U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_PREDICTION_REASON_0__BIT_5_HEADWAY ( CORELANEHOSTvOLHPredictionReason0 ) ( 5U )

/* LH_Prediction_Reason_0_b6 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEHOSTvO_LH_PREDICTION_REASON_0_RMIN  ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_PREDICTION_REASON_0_RMAX  ( 63U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_PREDICTION_REASON_0_NUMR  ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_PREDICTION_REASON_0_DEMNR ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_PREDICTION_REASON_0_OFFSET ( 0U )

/* Reserved_3_0_b5 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEHOSTvO_RESERVED_3_0_RMIN            ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_RESERVED_3_0_RMAX            ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_RESERVED_3_0_NUMR            ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_RESERVED_3_0_DEMNR           ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_RESERVED_3_0_OFFSET          ( 0U )

/* LH_Confidence_0_b7 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEHOSTvO_LH_CONFIDENCE_0_RMIN         ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_CONFIDENCE_0_RMAX         ( 100U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_CONFIDENCE_0_NUMR         ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_CONFIDENCE_0_DEMNR        ( 100U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_CONFIDENCE_0_OFFSET       ( 0U )

/* LH_Age_0_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEHOSTvO_LH_AGE_0_RMIN                ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_AGE_0_RMAX                ( 255U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_AGE_0_NUMR                ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_AGE_0_DEMNR               ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_AGE_0_OFFSET              ( 0U )

/* LH_Track_ID_0_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEHOSTvO_LH_TRACK_ID_0_RMIN           ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_TRACK_ID_0_RMAX           ( 255U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_TRACK_ID_0_NUMR           ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_TRACK_ID_0_DEMNR          ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_TRACK_ID_0_OFFSET         ( 0U )

/* LH_Is_Triggered_SDM_Model_0_b2 signal Enums */
typedef uint8 CORELANEHOSTvOLHIsTriggeredSDMModel0;
#define C_EYEQMSG_CORELANEHOSTvO_LH_IS_TRIGGERED_SDM_MODEL_0_NOT_AVAILABLE ( CORELANEHOSTvOLHIsTriggeredSDMModel0 ) ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_IS_TRIGGERED_SDM_MODEL_0_TRIGGERED ( CORELANEHOSTvOLHIsTriggeredSDMModel0 ) ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_IS_TRIGGERED_SDM_MODEL_0_NOT_TRIGGERED ( CORELANEHOSTvOLHIsTriggeredSDMModel0 ) ( 2U )

/* LH_Is_Triggered_SDM_Model_0_b2 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEHOSTvO_LH_IS_TRIGGERED_SDM_MODEL_0_RMIN ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_IS_TRIGGERED_SDM_MODEL_0_RMAX ( 2U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_IS_TRIGGERED_SDM_MODEL_0_NUMR ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_IS_TRIGGERED_SDM_MODEL_0_DEMNR ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_IS_TRIGGERED_SDM_MODEL_0_OFFSET ( 0U )

/* LH_Is_Triggered_SDM_Type_0_b2 signal Enums */
typedef uint8 CORELANEHOSTvOLHIsTriggeredSDMType0;
#define C_EYEQMSG_CORELANEHOSTvO_LH_IS_TRIGGERED_SDM_TYPE_0_NOT_AVAILABLE ( CORELANEHOSTvOLHIsTriggeredSDMType0 ) ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_IS_TRIGGERED_SDM_TYPE_0_TRIGGERED ( CORELANEHOSTvOLHIsTriggeredSDMType0 ) ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_IS_TRIGGERED_SDM_TYPE_0_NOT_TRIGGERED ( CORELANEHOSTvOLHIsTriggeredSDMType0 ) ( 2U )

/* LH_Is_Triggered_SDM_Type_0_b2 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEHOSTvO_LH_IS_TRIGGERED_SDM_TYPE_0_RMIN ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_IS_TRIGGERED_SDM_TYPE_0_RMAX ( 2U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_IS_TRIGGERED_SDM_TYPE_0_NUMR ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_IS_TRIGGERED_SDM_TYPE_0_DEMNR ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_IS_TRIGGERED_SDM_TYPE_0_OFFSET ( 0U )

/* LH_CRC_0_b32 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEHOSTvO_LH_CRC_0_RMIN                ( 0U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_CRC_0_RMAX                ( 4294967295U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_CRC_0_NUMR                ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_CRC_0_DEMNR               ( 1U )
#define C_EYEQMSG_CORELANEHOSTvO_LH_CRC_0_OFFSET              ( 0U )


/*****************************************************************************
                  Exported function-like macros
*****************************************************************************/
/*****************************************************************************
                  Exported defined macros
*****************************************************************************/
/*****************************************************************************
                  Exported types, enums definitions
*****************************************************************************/
typedef struct
{
   #if ENABLE_BIG_ENDIAN_FORMAT
      uint32        LH_Zero_byte_b8                              : 8U;
      
      uint32        LH_Protocol_Version_b8                       : 8U;
      
      uint32        LH_Sync_ID_b8                                : 8U;
      
      uint32        unused1_b5                                   : 5;
      uint32        LH_Lanes_Count_b3                            : 3U;
      
      uint32        Reserved_1_b5                                : 5U;
      
      uint32        LH_Estimated_Width_1_b8                      : 8U;
      
      uint32        unused2_b1                                   : 1;
      uint32        LH_Estimated_Width_2_b2                      : 2U;
      
      uint32        Reserved_2_1_b6                              : 6U;
      
      uint32        Reserved_2_2_b8                              : 8U;
      
      uint32        Reserved_2_3_b8                              : 8U;
      
   #else
      uint32        LH_Zero_byte_b8                              : 8U;
      
      uint32        LH_Protocol_Version_b8                       : 8U;
      
      uint32        LH_Sync_ID_b8                                : 8U;
      
      uint32        LH_Lanes_Count_b3                            : 3U;
      
      uint32        Reserved_1_b5                                : 5U;
      
      uint32        LH_Estimated_Width_b10                       : 10U;
      
      uint32        Reserved_2_b22                               : 22U;
      
   #endif
} EYEQMSG_CORELANEHOSTvH_Params_t;


typedef struct
{
   #if ENABLE_BIG_ENDIAN_FORMAT
      uint32        unused1_b64                                  : 64;
      uint32        LH_CRC_0_1_b8                                : 8U;
      
      uint32        LH_CRC_0_2_b8                                : 8U;
      
      uint32        LH_CRC_0_3_b8                                : 8U;
      
      uint32        LH_CRC_0_4_b8                                : 8U;
      
      uint32        unused2_b6                                   : 6;
      uint32        LH_Is_Triggered_SDM_Type_0_b2                : 2U;
      
      uint32        LH_Is_Triggered_SDM_Model_0_b2               : 2U;
      
      uint32        LH_Track_ID_0_1_b4                           : 4U;
      
      uint32        LH_Track_ID_0_2_b4                           : 4U;
      
      uint32        LH_Age_0_1_b4                                : 4U;
      
      uint32        LH_Age_0_2_b4                                : 4U;
      
      uint32        LH_Confidence_0_1_b4                         : 4U;
      
      uint32        LH_Confidence_0_2_b3                         : 3U;
      
      uint32        Reserved_3_0_b5                              : 5U;
      
      uint32        LH_Prediction_Reason_0_b6                    : 6U;
      
      uint32        LH_Availability_State_0_b2                   : 2U;
      
      uint32        LH_Color_0_b2                                : 2U;
      
      uint32        LH_Color_Confidence_0_1_b6                   : 6U;
      
      uint32        unused3_b1                                   : 1;
      uint32        LH_Color_Confidence_0_2_b1                   : 1U;
      
      uint32        LH_Lanemark_Type_0_b4                        : 4U;
      
      uint32        LH_DLM_Type_0_b3                             : 3U;
      
      uint32        LH_DECEL_Type_0_b3                           : 3U;
      
      uint32        Reserved_4_0_b5                              : 5U;
      
      uint32        LH_Lanemark_Type_Conf_0_b7                   : 7U;
      
      uint32        LH_Side_0_1_b1                               : 1U;
      
      uint32        LH_Side_0_2_b1                               : 1U;
      
      uint32        LH_Crossing_0_b1                             : 1U;
      
      uint32        LH_Marker_Width_0_1_b6                       : 6U;
      
      uint32        LH_Marker_Width_0_2_b2                       : 2U;
      
      uint32        LH_Marker_Width_STD_0_1_b6                   : 6U;
      
      uint32        LH_Marker_Width_STD_0_2_b1                   : 1U;
      
      uint32        Reserved_5_0_b7                              : 7U;
      
      uint32        LH_Dash_Average_Length_0_b8                  : 8U;
      
      uint32        LH_Dash_Average_Gap_0_b8                     : 8U;
      
      uint32        LH_Is_Multi_Clothoid_0_b1                    : 1U;
      
      uint32        Reserved_6_0_1_b7                            : 7U;
      
      uint32        Reserved_6_0_2_b8                            : 8U;
      
      uint32        LH_Line_First_C0_0_1_sb8                     : 8U;
      
      uint32        LH_Line_First_C0_0_2_sb8                     : 8U;
      
      uint32        LH_Line_First_C0_0_3_sb8                     : 8U;
      
      uint32        LH_Line_First_C0_0_4_sb8                     : 8U;
      
      uint32        LH_Line_First_C1_0_1_sb8                     : 8U;
      
      uint32        LH_Line_First_C1_0_2_sb8                     : 8U;
      
      uint32        LH_Line_First_C1_0_3_sb8                     : 8U;
      
      uint32        LH_Line_First_C1_0_4_sb8                     : 8U;
      
      uint32        LH_Line_First_C2_0_1_sb8                     : 8U;
      
      uint32        LH_Line_First_C2_0_2_sb8                     : 8U;
      
      uint32        LH_Line_First_C2_0_3_sb8                     : 8U;
      
      uint32        LH_Line_First_C2_0_4_sb8                     : 8U;
      
      uint32        LH_Line_First_C3_0_1_sb8                     : 8U;
      
      uint32        LH_Line_First_C3_0_2_sb8                     : 8U;
      
      uint32        LH_Line_First_C3_0_3_sb8                     : 8U;
      
      uint32        LH_Line_First_C3_0_4_sb8                     : 8U;
      
      uint32        LH_First_VR_Start_0_1_b8                     : 8U;
      
      uint32        LH_First_VR_Start_0_2_b7                     : 7U;
      
      uint32        LH_First_VR_End_0_1_b1                       : 1U;
      
      uint32        LH_First_VR_End_0_2_b8                       : 8U;
      
      uint32        LH_First_VR_End_0_3_b6                       : 6U;
      
      uint32        Reserved_7_0_b2                              : 2U;
      
      uint32        LH_First_Measured_VR_End_0_1_b8              : 8U;
      
      uint32        LH_First_Measured_VR_End_0_2_b7              : 7U;
      
      uint32        LH_Second_Measured_VR_End_0_1_b1             : 1U;
      
      uint32        LH_Second_Measured_VR_End_0_2_b8             : 8U;
      
      uint32        LH_Second_Measured_VR_End_0_3_b6             : 6U;
      
      uint32        Reserved_8_0_b2                              : 2U;
      
      uint32        LH_Line_Second_C0_0_1_sb8                    : 8U;
      
      uint32        LH_Line_Second_C0_0_2_sb8                    : 8U;
      
      uint32        LH_Line_Second_C0_0_3_sb8                    : 8U;
      
      uint32        LH_Line_Second_C0_0_4_sb8                    : 8U;
      
      uint32        LH_Line_Second_C1_0_1_sb8                    : 8U;
      
      uint32        LH_Line_Second_C1_0_2_sb8                    : 8U;
      
      uint32        LH_Line_Second_C1_0_3_sb8                    : 8U;
      
      uint32        LH_Line_Second_C1_0_4_sb8                    : 8U;
      
      uint32        LH_Line_Second_C2_0_1_sb8                    : 8U;
      
      uint32        LH_Line_Second_C2_0_2_sb8                    : 8U;
      
      uint32        LH_Line_Second_C2_0_3_sb8                    : 8U;
      
      uint32        LH_Line_Second_C2_0_4_sb8                    : 8U;
      
      uint32        LH_Line_Second_C3_0_1_sb8                    : 8U;
      
      uint32        LH_Line_Second_C3_0_2_sb8                    : 8U;
      
      uint32        LH_Line_Second_C3_0_3_sb8                    : 8U;
      
      uint32        LH_Line_Second_C3_0_4_sb8                    : 8U;
      
      uint32        LH_Second_VR_Start_0_1_b8                    : 8U;
      
      uint32        LH_Second_VR_Start_0_2_b7                    : 7U;
      
      uint32        LH_Second_VR_End_0_1_b1                      : 1U;
      
      uint32        LH_Second_VR_End_0_2_b8                      : 8U;
      
      uint32        LH_Second_VR_End_0_3_b6                      : 6U;
      
      uint32        LH_Detection_Source_0_b2                     : 2U;
      
   #else
      uint32        LH_CRC_0_b32                                 : 32U;
      
      uint32        LH_Is_Triggered_SDM_Type_0_b2                : 2U;
      
      uint32        LH_Is_Triggered_SDM_Model_0_b2               : 2U;
      
      uint32        LH_Track_ID_0_b8                             : 8U;
      
      uint32        LH_Age_0_b8                                  : 8U;
      
      uint32        LH_Confidence_0_b7                           : 7U;
      
      uint32        Reserved_3_0_b5                              : 5U;
      
      uint32        LH_Prediction_Reason_0_b6                    : 6U;
      
      uint32        LH_Availability_State_0_b2                   : 2U;
      
      uint32        LH_Color_0_b2                                : 2U;
      
      uint32        LH_Color_Confidence_0_b7                     : 7U;
      
      uint32        LH_Lanemark_Type_0_b4                        : 4U;
      
      uint32        LH_DLM_Type_0_b3                             : 3U;
      
      uint32        LH_DECEL_Type_0_b3                           : 3U;
      
      uint32        Reserved_4_0_b5                              : 5U;
      
      uint32        LH_Lanemark_Type_Conf_0_b7                   : 7U;
      
      uint32        LH_Side_0_b2                                 : 2U;
      
      uint32        LH_Crossing_0_b1                             : 1U;
      
      uint32        LH_Marker_Width_0_b8                         : 8U;
      
      uint32        LH_Marker_Width_STD_0_b7                     : 7U;
      
      uint32        Reserved_5_0_b7                              : 7U;
      
      uint32        LH_Dash_Average_Length_0_b8                  : 8U;
      
      uint32        LH_Dash_Average_Gap_0_b8                     : 8U;
      
      uint32        LH_Is_Multi_Clothoid_0_b1                    : 1U;
      
      uint32        Reserved_6_0_b15                             : 15U;
      
      sint32        LH_Line_First_C0_0_sb32                      : 32;
      
      sint32        LH_Line_First_C1_0_sb32                      : 32;
      
      sint32        LH_Line_First_C2_0_sb32                      : 32;
      
      sint32        LH_Line_First_C3_0_sb32                      : 32;
      
      uint32        LH_First_VR_Start_0_b15                      : 15U;
      
      uint32        LH_First_VR_End_0_b15                        : 15U;
      
      uint32        Reserved_7_0_b2                              : 2U;
      
      uint32        LH_First_Measured_VR_End_0_b15               : 15U;
      
      uint32        LH_Second_Measured_VR_End_0_b15              : 15U;
      
      uint32        Reserved_8_0_b2                              : 2U;
      
      sint32        LH_Line_Second_C0_0_sb32                     : 32;
      
      sint32        LH_Line_Second_C1_0_sb32                     : 32;
      
      sint32        LH_Line_Second_C2_0_sb32                     : 32;
      
      sint32        LH_Line_Second_C3_0_sb32                     : 32;
      
      uint32        LH_Second_VR_Start_0_b15                     : 15U;
      
      uint32        LH_Second_VR_End_0_b15                       : 15U;
      
      uint32        LH_Detection_Source_0_b2                     : 2U;
      
   #endif
} EYEQMSG_CORELANEHOSTvO_Params_t;


typedef struct
{
   EYEQMSG_CORELANEHOSTvH_Params_t EYEQMSG_CORELANEHOSTvH_Params_s;
   EYEQMSG_CORELANEHOSTvO_Params_t EYEQMSG_CORELANEHOSTvO_Params_as[C_EYEQMSG_CORELANEHOSTvH_VIRTUAL_OBJECT_INDEX_RMAX];
} EYEQMSG_CORELANEHOST_Params_t;


/*****************************************************************************
                  Exported function prototypes
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvH_LH_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pLH_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Zero_byte
*    LH_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Zero_byte signal value of Virtual_HEADER_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvH_LH_Zero_byte( uint8 * pLH_Zero_byte );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvH_LH_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pLH_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Protocol_Version
*    LH_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Protocol_Version signal value of Virtual_HEADER_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvH_LH_Protocol_Version( uint8 * pLH_Protocol_Version );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvH_LH_Sync_ID
*
* FUNCTION ARGUMENTS:
*    uint8 * pLH_Sync_ID - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Sync_ID
*    LH_Sync_ID returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Sync_ID signal value of Virtual_HEADER_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvH_LH_Sync_ID( uint8 * pLH_Sync_ID );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvH_LH_Lanes_Count
*
* FUNCTION ARGUMENTS:
*    uint8 * pLH_Lanes_Count - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Lanes_Count
*    LH_Lanes_Count returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Lanes_Count signal value of Virtual_HEADER_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvH_LH_Lanes_Count( uint8 * pLH_Lanes_Count );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvH_Reserved_1
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1
*    Reserved_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1 signal value of Virtual_HEADER_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvH_Reserved_1( uint8 * pReserved_1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvH_LH_Estimated_Width
*
* FUNCTION ARGUMENTS:
*    uint16 * pLH_Estimated_Width - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Estimated_Width
*    LH_Estimated_Width returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Estimated_Width signal value of Virtual_HEADER_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvH_LH_Estimated_Width( uint16 * pLH_Estimated_Width );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvH_Reserved_2
*
* FUNCTION ARGUMENTS:
*    uint32 * pReserved_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_2
*    Reserved_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_2 signal value of Virtual_HEADER_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvH_Reserved_2( uint32 * pReserved_2 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_CRC_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint32 * pLH_CRC_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_CRC_0
*    LH_CRC_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_CRC_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_CRC_0( uint8 objIndx_u8, uint32 * pLH_CRC_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Is_Triggered_SDM_Type_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANEHOSTvOLHIsTriggeredSDMType0 * pLH_Is_Triggered_SDM_Type_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Is_Triggered_SDM_Type_0
*    LH_Is_Triggered_SDM_Type_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Is_Triggered_SDM_Type_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Is_Triggered_SDM_Type_0( uint8 objIndx_u8, CORELANEHOSTvOLHIsTriggeredSDMType0 * pLH_Is_Triggered_SDM_Type_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Is_Triggered_SDM_Model_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANEHOSTvOLHIsTriggeredSDMModel0 * pLH_Is_Triggered_SDM_Model_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Is_Triggered_SDM_Model_0
*    LH_Is_Triggered_SDM_Model_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Is_Triggered_SDM_Model_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Is_Triggered_SDM_Model_0( uint8 objIndx_u8, CORELANEHOSTvOLHIsTriggeredSDMModel0 * pLH_Is_Triggered_SDM_Model_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Track_ID_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLH_Track_ID_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Track_ID_0
*    LH_Track_ID_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Track_ID_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Track_ID_0( uint8 objIndx_u8, uint8 * pLH_Track_ID_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Age_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLH_Age_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Age_0
*    LH_Age_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Age_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Age_0( uint8 objIndx_u8, uint8 * pLH_Age_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Confidence_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLH_Confidence_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Confidence_0
*    LH_Confidence_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Confidence_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Confidence_0( uint8 objIndx_u8, uint8 * pLH_Confidence_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_Reserved_3_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_3_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_3_0
*    Reserved_3_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_3_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_Reserved_3_0( uint8 objIndx_u8, uint8 * pReserved_3_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Prediction_Reason_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANEHOSTvOLHPredictionReason0 * pLH_Prediction_Reason_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Prediction_Reason_0
*    LH_Prediction_Reason_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Prediction_Reason_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Prediction_Reason_0( uint8 objIndx_u8, CORELANEHOSTvOLHPredictionReason0 * pLH_Prediction_Reason_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Availability_State_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANEHOSTvOLHAvailabilityState0 * pLH_Availability_State_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Availability_State_0
*    LH_Availability_State_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Availability_State_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Availability_State_0( uint8 objIndx_u8, CORELANEHOSTvOLHAvailabilityState0 * pLH_Availability_State_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Color_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANEHOSTvOLHColor0 * pLH_Color_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Color_0
*    LH_Color_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Color_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Color_0( uint8 objIndx_u8, CORELANEHOSTvOLHColor0 * pLH_Color_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Color_Confidence_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLH_Color_Confidence_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Color_Confidence_0
*    LH_Color_Confidence_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Color_Confidence_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Color_Confidence_0( uint8 objIndx_u8, uint8 * pLH_Color_Confidence_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Lanemark_Type_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANEHOSTvOLHLanemarkType0 * pLH_Lanemark_Type_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Lanemark_Type_0
*    LH_Lanemark_Type_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Lanemark_Type_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Lanemark_Type_0( uint8 objIndx_u8, CORELANEHOSTvOLHLanemarkType0 * pLH_Lanemark_Type_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_DLM_Type_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANEHOSTvOLHDLMType0 * pLH_DLM_Type_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_DLM_Type_0
*    LH_DLM_Type_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_DLM_Type_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_DLM_Type_0( uint8 objIndx_u8, CORELANEHOSTvOLHDLMType0 * pLH_DLM_Type_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_DECEL_Type_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANEHOSTvOLHDECELType0 * pLH_DECEL_Type_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_DECEL_Type_0
*    LH_DECEL_Type_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_DECEL_Type_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_DECEL_Type_0( uint8 objIndx_u8, CORELANEHOSTvOLHDECELType0 * pLH_DECEL_Type_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_Reserved_4_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_4_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_4_0
*    Reserved_4_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_4_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_Reserved_4_0( uint8 objIndx_u8, uint8 * pReserved_4_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Lanemark_Type_Conf_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLH_Lanemark_Type_Conf_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Lanemark_Type_Conf_0
*    LH_Lanemark_Type_Conf_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Lanemark_Type_Conf_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Lanemark_Type_Conf_0( uint8 objIndx_u8, uint8 * pLH_Lanemark_Type_Conf_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Side_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANEHOSTvOLHSide0 * pLH_Side_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Side_0
*    LH_Side_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Side_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Side_0( uint8 objIndx_u8, CORELANEHOSTvOLHSide0 * pLH_Side_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Crossing_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANEHOSTvOLHCrossing0 * pLH_Crossing_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Crossing_0
*    LH_Crossing_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Crossing_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Crossing_0( uint8 objIndx_u8, CORELANEHOSTvOLHCrossing0 * pLH_Crossing_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Marker_Width_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLH_Marker_Width_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Marker_Width_0
*    LH_Marker_Width_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Marker_Width_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Marker_Width_0( uint8 objIndx_u8, uint8 * pLH_Marker_Width_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Marker_Width_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLH_Marker_Width_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Marker_Width_STD_0
*    LH_Marker_Width_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Marker_Width_STD_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Marker_Width_STD_0( uint8 objIndx_u8, uint8 * pLH_Marker_Width_STD_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_Reserved_5_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_5_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_5_0
*    Reserved_5_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_5_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_Reserved_5_0( uint8 objIndx_u8, uint8 * pReserved_5_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Dash_Average_Length_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLH_Dash_Average_Length_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Dash_Average_Length_0
*    LH_Dash_Average_Length_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Dash_Average_Length_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Dash_Average_Length_0( uint8 objIndx_u8, uint8 * pLH_Dash_Average_Length_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Dash_Average_Gap_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLH_Dash_Average_Gap_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Dash_Average_Gap_0
*    LH_Dash_Average_Gap_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Dash_Average_Gap_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Dash_Average_Gap_0( uint8 objIndx_u8, uint8 * pLH_Dash_Average_Gap_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Is_Multi_Clothoid_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANEHOSTvOLHIsMultiClothoid0 * pLH_Is_Multi_Clothoid_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Is_Multi_Clothoid_0
*    LH_Is_Multi_Clothoid_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Is_Multi_Clothoid_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Is_Multi_Clothoid_0( uint8 objIndx_u8, CORELANEHOSTvOLHIsMultiClothoid0 * pLH_Is_Multi_Clothoid_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_Reserved_6_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pReserved_6_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_6_0
*    Reserved_6_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_6_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_Reserved_6_0( uint8 objIndx_u8, uint16 * pReserved_6_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Line_First_C0_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    float32 * pLH_Line_First_C0_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Line_First_C0_0
*    LH_Line_First_C0_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Line_First_C0_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Line_First_C0_0( uint8 objIndx_u8, float32 * pLH_Line_First_C0_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Line_First_C1_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    float32 * pLH_Line_First_C1_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Line_First_C1_0
*    LH_Line_First_C1_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Line_First_C1_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Line_First_C1_0( uint8 objIndx_u8, float32 * pLH_Line_First_C1_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Line_First_C2_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    float32 * pLH_Line_First_C2_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Line_First_C2_0
*    LH_Line_First_C2_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Line_First_C2_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Line_First_C2_0( uint8 objIndx_u8, float32 * pLH_Line_First_C2_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Line_First_C3_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    float32 * pLH_Line_First_C3_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Line_First_C3_0
*    LH_Line_First_C3_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Line_First_C3_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Line_First_C3_0( uint8 objIndx_u8, float32 * pLH_Line_First_C3_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_First_VR_Start_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLH_First_VR_Start_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_First_VR_Start_0
*    LH_First_VR_Start_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_First_VR_Start_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_First_VR_Start_0( uint8 objIndx_u8, uint16 * pLH_First_VR_Start_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_First_VR_End_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLH_First_VR_End_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_First_VR_End_0
*    LH_First_VR_End_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_First_VR_End_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_First_VR_End_0( uint8 objIndx_u8, uint16 * pLH_First_VR_End_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_Reserved_7_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_7_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_7_0
*    Reserved_7_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_7_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_Reserved_7_0( uint8 objIndx_u8, uint8 * pReserved_7_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_First_Measured_VR_End_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLH_First_Measured_VR_End_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_First_Measured_VR_End_0
*    LH_First_Measured_VR_End_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_First_Measured_VR_End_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_First_Measured_VR_End_0( uint8 objIndx_u8, uint16 * pLH_First_Measured_VR_End_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Second_Measured_VR_End_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLH_Second_Measured_VR_End_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Second_Measured_VR_End_0
*    LH_Second_Measured_VR_End_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Second_Measured_VR_End_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Second_Measured_VR_End_0( uint8 objIndx_u8, uint16 * pLH_Second_Measured_VR_End_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_Reserved_8_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_8_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_8_0
*    Reserved_8_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_8_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_Reserved_8_0( uint8 objIndx_u8, uint8 * pReserved_8_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Line_Second_C0_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    float32 * pLH_Line_Second_C0_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Line_Second_C0_0
*    LH_Line_Second_C0_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Line_Second_C0_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Line_Second_C0_0( uint8 objIndx_u8, float32 * pLH_Line_Second_C0_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Line_Second_C1_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    float32 * pLH_Line_Second_C1_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Line_Second_C1_0
*    LH_Line_Second_C1_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Line_Second_C1_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Line_Second_C1_0( uint8 objIndx_u8, float32 * pLH_Line_Second_C1_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Line_Second_C2_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    float32 * pLH_Line_Second_C2_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Line_Second_C2_0
*    LH_Line_Second_C2_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Line_Second_C2_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Line_Second_C2_0( uint8 objIndx_u8, float32 * pLH_Line_Second_C2_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Line_Second_C3_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    float32 * pLH_Line_Second_C3_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Line_Second_C3_0
*    LH_Line_Second_C3_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Line_Second_C3_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Line_Second_C3_0( uint8 objIndx_u8, float32 * pLH_Line_Second_C3_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Second_VR_Start_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLH_Second_VR_Start_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Second_VR_Start_0
*    LH_Second_VR_Start_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Second_VR_Start_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Second_VR_Start_0( uint8 objIndx_u8, uint16 * pLH_Second_VR_Start_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Second_VR_End_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLH_Second_VR_End_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Second_VR_End_0
*    LH_Second_VR_End_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Second_VR_End_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Second_VR_End_0( uint8 objIndx_u8, uint16 * pLH_Second_VR_End_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Detection_Source_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANEHOSTvOLHDetectionSource0 * pLH_Detection_Source_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Detection_Source_0
*    LH_Detection_Source_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Detection_Source_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Detection_Source_0( uint8 objIndx_u8, CORELANEHOSTvOLHDetectionSource0 * pLH_Detection_Source_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_CORELANEHOST_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_CORELANEHOST_Params_t * pCore_Lanes_Host_protocol - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_Lanes_Host_protocol message 
*    Core_Lanes_Host_protocol message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_Lanes_Host_protocol message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_CORELANEHOST_ParamsApp_MsgDataStruct( EYEQMSG_CORELANEHOST_Params_t * pCore_Lanes_Host_protocol );
/*****************************************************************************
                  Exported object declarations
*****************************************************************************/
extern EYEQMSG_CORELANEHOST_Params_t   EYEQMSG_CORELANEHOST_Params_s;
extern EYEQMSG_CORELANEHOST_Params_t   EYEQMSG_CORELANEHOST_ParamsApp_s;
/****************************************************************************/
#endif /* _EYEQMSG_CORELANEHOSTPROCESS_H_ */


