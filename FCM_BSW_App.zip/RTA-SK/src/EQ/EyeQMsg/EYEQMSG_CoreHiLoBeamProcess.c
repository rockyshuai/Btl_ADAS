

/*****************************************************************************
                  Include files
*****************************************************************************/
/* The suggested include file order is: */
#include "EyeQ_defs.h"    /* EyeQ project common definitions file    */

#include "EYEQMSG_CoreHiLoBeamProcess.h"

/*****************************************************************************
                  Local symbolic constants
*****************************************************************************/
/*****************************************************************************
                  Local types, enums definitions
*****************************************************************************/
/*****************************************************************************
                  Local function prototypes
*****************************************************************************/
/*****************************************************************************
                  Local object definitions
*****************************************************************************/
/*****************************************************************************
                  Exported object definitions
*****************************************************************************/
EYEQMSG_COREHILOBEAM_Params_t   EYEQMSG_COREHILOBEAM_Params_s;
EYEQMSG_COREHILOBEAM_Params_t   EYEQMSG_COREHILOBEAM_ParamsApp_s;
/*****************************************************************************
                  Local function-like macros
*****************************************************************************/
/*****************************************************************************
                  Local defined macros
*****************************************************************************/
/*****************************************************************************
                  Function definitions
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_COREHILOBEAM_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_COREHILOBEAM_Params_t * pCore_High_Low_Beam_protocol - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_High_Low_Beam_protocol message 
*    Core_High_Low_Beam_protocol message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_High_Low_Beam_protocol message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_COREHILOBEAM_ParamsApp_MsgDataStruct( EYEQMSG_COREHILOBEAM_Params_t * pCore_High_Low_Beam_protocol )
{
   Std_ReturnType status = C_SIG_INVALID;
   if( pCore_High_Low_Beam_protocol != C_NULL_P )
   {
      status = C_SIG_VALID;
      * pCore_High_Low_Beam_protocol = EYEQMSG_COREHILOBEAM_ParamsApp_s;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREHILOBEAM_HLB_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pHLB_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of HLB_Zero_byte
*    HLB_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns HLB_Zero_byte signal value of Core_High_Low_Beam_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREHILOBEAM_HLB_Zero_byte( uint8 * pHLB_Zero_byte )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pHLB_Zero_byte != C_NULL_P )
   {
      signal_value = EYEQMSG_COREHILOBEAM_ParamsApp_s.HLB_Zero_byte_b8;
      * pHLB_Zero_byte = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREHILOBEAM_HLB_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pHLB_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of HLB_Protocol_Version
*    HLB_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns HLB_Protocol_Version signal value of Core_High_Low_Beam_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREHILOBEAM_HLB_Protocol_Version( uint8 * pHLB_Protocol_Version )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pHLB_Protocol_Version != C_NULL_P )
   {
      signal_value = EYEQMSG_COREHILOBEAM_ParamsApp_s.HLB_Protocol_Version_b8;
      * pHLB_Protocol_Version = signal_value;
      if( (signal_value >= C_EYEQMSG_COREHILOBEAM_HLB_PROTOCOL_VERSION_RMIN ) 
          && (signal_value <= C_EYEQMSG_COREHILOBEAM_HLB_PROTOCOL_VERSION_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREHILOBEAM_HLB_Sync_ID
*
* FUNCTION ARGUMENTS:
*    uint8 * pHLB_Sync_ID - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of HLB_Sync_ID
*    HLB_Sync_ID returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns HLB_Sync_ID signal value of Core_High_Low_Beam_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREHILOBEAM_HLB_Sync_ID( uint8 * pHLB_Sync_ID )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pHLB_Sync_ID != C_NULL_P )
   {
      signal_value = EYEQMSG_COREHILOBEAM_ParamsApp_s.HLB_Sync_ID_b8;
      * pHLB_Sync_ID = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREHILOBEAM_HLB_Running_Mode
*
* FUNCTION ARGUMENTS:
*    COREHILOBEAMHLBRunningMode * pHLB_Running_Mode - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of HLB_Running_Mode
*    HLB_Running_Mode returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns HLB_Running_Mode signal value of Core_High_Low_Beam_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREHILOBEAM_HLB_Running_Mode( COREHILOBEAMHLBRunningMode * pHLB_Running_Mode )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREHILOBEAMHLBRunningMode signal_value;
   
   if( pHLB_Running_Mode != C_NULL_P )
   {
      signal_value = EYEQMSG_COREHILOBEAM_ParamsApp_s.HLB_Running_Mode_b2;
      * pHLB_Running_Mode = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREHILOBEAM_HLB_Inactive_Reason
*
* FUNCTION ARGUMENTS:
*    COREHILOBEAMHLBInactiveReason * pHLB_Inactive_Reason - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of HLB_Inactive_Reason
*    HLB_Inactive_Reason returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns HLB_Inactive_Reason signal value of Core_High_Low_Beam_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREHILOBEAM_HLB_Inactive_Reason( COREHILOBEAMHLBInactiveReason * pHLB_Inactive_Reason )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREHILOBEAMHLBInactiveReason signal_value;
   
   if( pHLB_Inactive_Reason != C_NULL_P )
   {
      signal_value = EYEQMSG_COREHILOBEAM_ParamsApp_s.HLB_Inactive_Reason_b3;
      * pHLB_Inactive_Reason = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREHILOBEAM_HLB_Decision
*
* FUNCTION ARGUMENTS:
*    COREHILOBEAMHLBDecision * pHLB_Decision - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of HLB_Decision
*    HLB_Decision returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns HLB_Decision signal value of Core_High_Low_Beam_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREHILOBEAM_HLB_Decision( COREHILOBEAMHLBDecision * pHLB_Decision )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREHILOBEAMHLBDecision signal_value;
   
   if( pHLB_Decision != C_NULL_P )
   {
      signal_value = EYEQMSG_COREHILOBEAM_ParamsApp_s.HLB_Decision_b2;
      * pHLB_Decision = signal_value;
      if( signal_value <= C_EYEQMSG_COREHILOBEAM_HLB_DECISION_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREHILOBEAM_HLB_Lane_Not_Dark
*
* FUNCTION ARGUMENTS:
*    COREHILOBEAMHLBLaneNotDark * pHLB_Lane_Not_Dark - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of HLB_Lane_Not_Dark
*    HLB_Lane_Not_Dark returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns HLB_Lane_Not_Dark signal value of Core_High_Low_Beam_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREHILOBEAM_HLB_Lane_Not_Dark( COREHILOBEAMHLBLaneNotDark * pHLB_Lane_Not_Dark )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREHILOBEAMHLBLaneNotDark signal_value;
   
   if( pHLB_Lane_Not_Dark != C_NULL_P )
   {
      signal_value = EYEQMSG_COREHILOBEAM_ParamsApp_s.HLB_Lane_Not_Dark_b1;
      * pHLB_Lane_Not_Dark = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREHILOBEAM_HLB_Reason
*
* FUNCTION ARGUMENTS:
*    COREHILOBEAMHLBReason * pHLB_Reason - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of HLB_Reason
*    HLB_Reason returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns HLB_Reason signal value of Core_High_Low_Beam_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREHILOBEAM_HLB_Reason( COREHILOBEAMHLBReason * pHLB_Reason )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREHILOBEAMHLBReason signal_value;
   
   if( pHLB_Reason != C_NULL_P )
   {
      signal_value = EYEQMSG_COREHILOBEAM_ParamsApp_s.HLB_Reason_b32;
      * pHLB_Reason = signal_value;
      if( signal_value <= C_EYEQMSG_COREHILOBEAM_HLB_REASON_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREHILOBEAM_HLB_Brightness_Score
*
* FUNCTION ARGUMENTS:
*    uint32 * pHLB_Brightness_Score - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of HLB_Brightness_Score
*    HLB_Brightness_Score returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns HLB_Brightness_Score signal value of Core_High_Low_Beam_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREHILOBEAM_HLB_Brightness_Score( uint32 * pHLB_Brightness_Score )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pHLB_Brightness_Score != C_NULL_P )
   {
      signal_value = EYEQMSG_COREHILOBEAM_ParamsApp_s.HLB_Brightness_Score_b32;
      * pHLB_Brightness_Score = signal_value;
      if( signal_value <= C_EYEQMSG_COREHILOBEAM_HLB_BRIGHTNESS_SCORE_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

