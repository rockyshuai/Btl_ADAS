

/*****************************************************************************
                  Include files
*****************************************************************************/
/* The suggested include file order is: */
#include "EyeQ_defs.h"    /* EyeQ project common definitions file    */

#include "EYEQMSG_CoreSPCInitProcess.h"

/*****************************************************************************
                  Local symbolic constants
*****************************************************************************/
/*****************************************************************************
                  Local types, enums definitions
*****************************************************************************/
/*****************************************************************************
                  Local function prototypes
*****************************************************************************/
/*****************************************************************************
                  Local object definitions
*****************************************************************************/
/*****************************************************************************
                  Exported object definitions
*****************************************************************************/
EYEQMSG_CORESPCINIT_Params_t   EYEQMSG_CORESPCINIT_Params_s;
EYEQMSG_CORESPCINIT_Params_t   EYEQMSG_CORESPCINIT_ParamsApp_s;
/*****************************************************************************
                  Local function-like macros
*****************************************************************************/
/*****************************************************************************
                  Local defined macros
*****************************************************************************/
/*****************************************************************************
                  Function definitions
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_CORESPCINIT_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_CORESPCINIT_Params_t * pCore_SPC_Init - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_SPC_Init message 
*    Core_SPC_Init message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_SPC_Init message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_CORESPCINIT_ParamsApp_MsgDataStruct( EYEQMSG_CORESPCINIT_Params_t * pCore_SPC_Init )
{
   Std_ReturnType status = C_SIG_INVALID;
   if( pCore_SPC_Init != C_NULL_P )
   {
      status = C_SIG_VALID;
      * pCore_SPC_Init = EYEQMSG_CORESPCINIT_ParamsApp_s;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESPCINIT_ISPC_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pISPC_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ISPC_Zero_byte
*    ISPC_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ISPC_Zero_byte signal value of Core_SPC_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESPCINIT_ISPC_Zero_byte( uint8 * pISPC_Zero_byte )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pISPC_Zero_byte != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESPCINIT_ParamsApp_s.ISPC_Zero_byte_b8;
      * pISPC_Zero_byte = signal_value;
      if( signal_value <= C_EYEQMSG_CORESPCINIT_ISPC_ZERO_BYTE_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESPCINIT_ISPC_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pISPC_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ISPC_Protocol_Version
*    ISPC_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ISPC_Protocol_Version signal value of Core_SPC_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESPCINIT_ISPC_Protocol_Version( uint8 * pISPC_Protocol_Version )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pISPC_Protocol_Version != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESPCINIT_ParamsApp_s.ISPC_Protocol_Version_b8;
      * pISPC_Protocol_Version = signal_value;
      if( (signal_value >= C_EYEQMSG_CORESPCINIT_ISPC_PROTOCOL_VERSION_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORESPCINIT_ISPC_PROTOCOL_VERSION_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESPCINIT_ISPC_Optional_Signals
*
* FUNCTION ARGUMENTS:
*    uint16 * pISPC_Optional_Signals - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ISPC_Optional_Signals
*    ISPC_Optional_Signals returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ISPC_Optional_Signals signal value of Core_SPC_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESPCINIT_ISPC_Optional_Signals( uint16 * pISPC_Optional_Signals )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pISPC_Optional_Signals != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESPCINIT_ParamsApp_s.ISPC_Optional_Signals_b16;
      * pISPC_Optional_Signals = signal_value;
      if( signal_value <= C_EYEQMSG_CORESPCINIT_ISPC_OPTIONAL_SIGNALS_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESPCINIT_ISPC_Slow_Mode
*
* FUNCTION ARGUMENTS:
*    CORESPCINITISPCSlowMode * pISPC_Slow_Mode - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ISPC_Slow_Mode
*    ISPC_Slow_Mode returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ISPC_Slow_Mode signal value of Core_SPC_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESPCINIT_ISPC_Slow_Mode( CORESPCINITISPCSlowMode * pISPC_Slow_Mode )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESPCINITISPCSlowMode signal_value;
   
   if( pISPC_Slow_Mode != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESPCINIT_ParamsApp_s.ISPC_Slow_Mode_b1;
      * pISPC_Slow_Mode = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESPCINIT_Reserved_1
*
* FUNCTION ARGUMENTS:
*    uint32 * pReserved_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1
*    Reserved_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1 signal value of Core_SPC_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESPCINIT_Reserved_1( uint32 * pReserved_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pReserved_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESPCINIT_ParamsApp_s.Reserved_1_b31;
      * pReserved_1 = signal_value;
      if( signal_value <= C_EYEQMSG_CORESPCINIT_RESERVED_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

