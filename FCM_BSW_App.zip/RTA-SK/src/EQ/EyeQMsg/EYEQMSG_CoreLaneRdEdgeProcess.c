

/*****************************************************************************
                  Include files
*****************************************************************************/
/* The suggested include file order is: */
#include "EyeQ_defs.h"    /* EyeQ project common definitions file    */

#include "EYEQMSG_CoreLaneRdEdgeProcess.h"

/*****************************************************************************
                  Local symbolic constants
*****************************************************************************/
/*****************************************************************************
                  Local types, enums definitions
*****************************************************************************/
/*****************************************************************************
                  Local function prototypes
*****************************************************************************/
/*****************************************************************************
                  Local object definitions
*****************************************************************************/
/*****************************************************************************
                  Exported object definitions
*****************************************************************************/
EYEQMSG_CORELANERDEDGE_Params_t   EYEQMSG_CORELANERDEDGE_Params_s;
EYEQMSG_CORELANERDEDGE_Params_t   EYEQMSG_CORELANERDEDGE_ParamsApp_s;
/*****************************************************************************
                  Local function-like macros
*****************************************************************************/
/*****************************************************************************
                  Local defined macros
*****************************************************************************/
/*****************************************************************************
                  Function definitions
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvH_LRE_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pLRE_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_Zero_byte
*    LRE_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_Zero_byte signal value of Virtual_HEADER_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvH_LRE_Zero_byte( uint8 * pLRE_Zero_byte )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pLRE_Zero_byte != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELANERDEDGE_ParamsApp_s.EYEQMSG_CORELANERDEDGEvH_Params_s.LRE_Zero_byte_b8;
      * pLRE_Zero_byte = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvH_Reserved_1
*
* FUNCTION ARGUMENTS:
*    uint32 * pReserved_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1
*    Reserved_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1 signal value of Virtual_HEADER_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvH_Reserved_1( uint32 * pReserved_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pReserved_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELANERDEDGE_ParamsApp_s.EYEQMSG_CORELANERDEDGEvH_Params_s.Reserved_1_b24;
      * pReserved_1 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELANERDEDGEvH_RESERVED_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvH_LRE_Header_CRC
*
* FUNCTION ARGUMENTS:
*    uint32 * pLRE_Header_CRC - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_Header_CRC
*    LRE_Header_CRC returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_Header_CRC signal value of Virtual_HEADER_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvH_LRE_Header_CRC( uint32 * pLRE_Header_CRC )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pLRE_Header_CRC != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELANERDEDGE_ParamsApp_s.EYEQMSG_CORELANERDEDGEvH_Params_s.LRE_Header_CRC_b32;
      * pLRE_Header_CRC = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvH_LRE_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pLRE_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_Protocol_Version
*    LRE_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_Protocol_Version signal value of Virtual_HEADER_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvH_LRE_Protocol_Version( uint8 * pLRE_Protocol_Version )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pLRE_Protocol_Version != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELANERDEDGE_ParamsApp_s.EYEQMSG_CORELANERDEDGEvH_Params_s.LRE_Protocol_Version_b8;
      * pLRE_Protocol_Version = signal_value;
      if( (signal_value >= C_EYEQMSG_CORELANERDEDGEvH_LRE_PROTOCOL_VERSION_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORELANERDEDGEvH_LRE_PROTOCOL_VERSION_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvH_LRE_Sync_ID
*
* FUNCTION ARGUMENTS:
*    uint8 * pLRE_Sync_ID - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_Sync_ID
*    LRE_Sync_ID returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_Sync_ID signal value of Virtual_HEADER_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvH_LRE_Sync_ID( uint8 * pLRE_Sync_ID )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pLRE_Sync_ID != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELANERDEDGE_ParamsApp_s.EYEQMSG_CORELANERDEDGEvH_Params_s.LRE_Sync_ID_b8;
      * pLRE_Sync_ID = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvH_LRE_Count
*
* FUNCTION ARGUMENTS:
*    uint8 * pLRE_Count - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_Count
*    LRE_Count returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_Count signal value of Virtual_HEADER_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvH_LRE_Count( uint8 * pLRE_Count )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pLRE_Count != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELANERDEDGE_ParamsApp_s.EYEQMSG_CORELANERDEDGEvH_Params_s.LRE_Count_b3;
      * pLRE_Count = signal_value;
      if( signal_value <= C_EYEQMSG_CORELANERDEDGEvH_LRE_COUNT_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvH_LRE_Header_Buffer
*
* FUNCTION ARGUMENTS:
*    uint16 * pLRE_Header_Buffer - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_Header_Buffer
*    LRE_Header_Buffer returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_Header_Buffer signal value of Virtual_HEADER_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvH_LRE_Header_Buffer( uint16 * pLRE_Header_Buffer )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pLRE_Header_Buffer != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELANERDEDGE_ParamsApp_s.EYEQMSG_CORELANERDEDGEvH_Params_s.LRE_Header_Buffer_b13;
      * pLRE_Header_Buffer = signal_value;
      if( signal_value <= C_EYEQMSG_CORELANERDEDGEvH_LRE_HEADER_BUFFER_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvO_LRE_Element_CRC_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint32 * pLRE_Element_CRC_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_Element_CRC_0
*    LRE_Element_CRC_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_Element_CRC_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvO_LRE_Element_CRC_0( uint8 objIndx_u8, uint32 * pLRE_Element_CRC_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANERDEDGEvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLRE_Element_CRC_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANERDEDGE_ParamsApp_s.EYEQMSG_CORELANERDEDGEvO_Params_as[objIndx_u8].LRE_Element_CRC_0_b32;
         * pLRE_Element_CRC_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvO_LRE_ID_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLRE_ID_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_ID_0
*    LRE_ID_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_ID_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvO_LRE_ID_0( uint8 objIndx_u8, uint8 * pLRE_ID_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANERDEDGEvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLRE_ID_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANERDEDGE_ParamsApp_s.EYEQMSG_CORELANERDEDGEvO_Params_as[objIndx_u8].LRE_ID_0_b8;
         * pLRE_ID_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvO_LRE_Age_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLRE_Age_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_Age_0
*    LRE_Age_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_Age_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvO_LRE_Age_0( uint8 objIndx_u8, uint8 * pLRE_Age_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANERDEDGEvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLRE_Age_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANERDEDGE_ParamsApp_s.EYEQMSG_CORELANERDEDGEvO_Params_as[objIndx_u8].LRE_Age_0_b8;
         * pLRE_Age_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvO_LRE_Confidence_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLRE_Confidence_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_Confidence_0
*    LRE_Confidence_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_Confidence_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvO_LRE_Confidence_0( uint8 objIndx_u8, uint8 * pLRE_Confidence_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANERDEDGEvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLRE_Confidence_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANERDEDGE_ParamsApp_s.EYEQMSG_CORELANERDEDGEvO_Params_as[objIndx_u8].LRE_Confidence_0_b8;
         * pLRE_Confidence_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANERDEDGEvO_LRE_CONFIDENCE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvO_LRE_Type_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANERDEDGEvOLREType0 * pLRE_Type_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_Type_0
*    LRE_Type_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_Type_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvO_LRE_Type_0( uint8 objIndx_u8, CORELANERDEDGEvOLREType0 * pLRE_Type_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELANERDEDGEvOLREType0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANERDEDGEvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLRE_Type_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANERDEDGE_ParamsApp_s.EYEQMSG_CORELANERDEDGEvO_Params_as[objIndx_u8].LRE_Type_0_b4;
         * pLRE_Type_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANERDEDGEvO_LRE_TYPE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvO_Reserved_2_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_2_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_2_0
*    Reserved_2_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_2_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvO_Reserved_2_0( uint8 objIndx_u8, uint8 * pReserved_2_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANERDEDGEvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_2_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANERDEDGE_ParamsApp_s.EYEQMSG_CORELANERDEDGEvO_Params_as[objIndx_u8].Reserved_2_0_b4;
         * pReserved_2_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANERDEDGEvO_RESERVED_2_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvO_LRE_Prediction_Reason_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANERDEDGEvOLREPredictionReason0 * pLRE_Prediction_Reason_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_Prediction_Reason_0
*    LRE_Prediction_Reason_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_Prediction_Reason_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvO_LRE_Prediction_Reason_0( uint8 objIndx_u8, CORELANERDEDGEvOLREPredictionReason0 * pLRE_Prediction_Reason_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELANERDEDGEvOLREPredictionReason0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANERDEDGEvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLRE_Prediction_Reason_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANERDEDGE_ParamsApp_s.EYEQMSG_CORELANERDEDGEvO_Params_as[objIndx_u8].LRE_Prediction_Reason_0_b6;
         * pLRE_Prediction_Reason_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvO_LRE_Availability_State_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANERDEDGEvOLREAvailabilityState0 * pLRE_Availability_State_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_Availability_State_0
*    LRE_Availability_State_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_Availability_State_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvO_LRE_Availability_State_0( uint8 objIndx_u8, CORELANERDEDGEvOLREAvailabilityState0 * pLRE_Availability_State_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELANERDEDGEvOLREAvailabilityState0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANERDEDGEvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLRE_Availability_State_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANERDEDGE_ParamsApp_s.EYEQMSG_CORELANERDEDGEvO_Params_as[objIndx_u8].LRE_Availability_State_0_b2;
         * pLRE_Availability_State_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANERDEDGEvO_LRE_AVAILABILITY_STATE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvO_LRE_Height_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLRE_Height_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_Height_0
*    LRE_Height_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_Height_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvO_LRE_Height_0( uint8 objIndx_u8, uint8 * pLRE_Height_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANERDEDGEvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLRE_Height_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANERDEDGE_ParamsApp_s.EYEQMSG_CORELANERDEDGEvO_Params_as[objIndx_u8].LRE_Height_0_b8;
         * pLRE_Height_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANERDEDGEvO_LRE_HEIGHT_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvO_LRE_Height_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLRE_Height_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_Height_STD_0
*    LRE_Height_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_Height_STD_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvO_LRE_Height_STD_0( uint8 objIndx_u8, uint8 * pLRE_Height_STD_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANERDEDGEvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLRE_Height_STD_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANERDEDGE_ParamsApp_s.EYEQMSG_CORELANERDEDGEvO_Params_as[objIndx_u8].LRE_Height_STD_0_b8;
         * pLRE_Height_STD_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANERDEDGEvO_LRE_HEIGHT_STD_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvO_Reserved_3_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_3_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_3_0
*    Reserved_3_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_3_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvO_Reserved_3_0( uint8 objIndx_u8, uint8 * pReserved_3_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANERDEDGEvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_3_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANERDEDGE_ParamsApp_s.EYEQMSG_CORELANERDEDGEvO_Params_as[objIndx_u8].Reserved_3_0_b8;
         * pReserved_3_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANERDEDGEvO_RESERVED_3_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvO_LRE_View_Range_Start_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLRE_View_Range_Start_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_View_Range_Start_0
*    LRE_View_Range_Start_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_View_Range_Start_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvO_LRE_View_Range_Start_0( uint8 objIndx_u8, uint16 * pLRE_View_Range_Start_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANERDEDGEvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLRE_View_Range_Start_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANERDEDGE_ParamsApp_s.EYEQMSG_CORELANERDEDGEvO_Params_as[objIndx_u8].LRE_View_Range_Start_0_b15;
         * pLRE_View_Range_Start_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANERDEDGEvO_LRE_VIEW_RANGE_START_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvO_LRE_View_Range_End_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLRE_View_Range_End_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_View_Range_End_0
*    LRE_View_Range_End_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_View_Range_End_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvO_LRE_View_Range_End_0( uint8 objIndx_u8, uint16 * pLRE_View_Range_End_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANERDEDGEvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLRE_View_Range_End_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANERDEDGE_ParamsApp_s.EYEQMSG_CORELANERDEDGEvO_Params_as[objIndx_u8].LRE_View_Range_End_0_b15;
         * pLRE_View_Range_End_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANERDEDGEvO_LRE_VIEW_RANGE_END_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvO_Reserved_4_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_4_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_4_0
*    Reserved_4_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_4_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvO_Reserved_4_0( uint8 objIndx_u8, uint8 * pReserved_4_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANERDEDGEvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_4_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANERDEDGE_ParamsApp_s.EYEQMSG_CORELANERDEDGEvO_Params_as[objIndx_u8].Reserved_4_0_b2;
         * pReserved_4_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANERDEDGEvO_RESERVED_4_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvO_LRE_Measured_VR_End_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLRE_Measured_VR_End_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_Measured_VR_End_0
*    LRE_Measured_VR_End_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_Measured_VR_End_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvO_LRE_Measured_VR_End_0( uint8 objIndx_u8, uint16 * pLRE_Measured_VR_End_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANERDEDGEvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLRE_Measured_VR_End_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANERDEDGE_ParamsApp_s.EYEQMSG_CORELANERDEDGEvO_Params_as[objIndx_u8].LRE_Measured_VR_End_0_b15;
         * pLRE_Measured_VR_End_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANERDEDGEvO_LRE_MEASURED_VR_END_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvO_LRE_Side_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANERDEDGEvOLRESide0 * pLRE_Side_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_Side_0
*    LRE_Side_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_Side_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvO_LRE_Side_0( uint8 objIndx_u8, CORELANERDEDGEvOLRESide0 * pLRE_Side_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELANERDEDGEvOLRESide0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANERDEDGEvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLRE_Side_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANERDEDGE_ParamsApp_s.EYEQMSG_CORELANERDEDGEvO_Params_as[objIndx_u8].LRE_Side_0_b2;
         * pLRE_Side_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANERDEDGEvO_LRE_SIDE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvO_LRE_Is_Triggered_SDM_Model_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANERDEDGEvOLREIsTriggeredSDMModel0 * pLRE_Is_Triggered_SDM_Model_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_Is_Triggered_SDM_Model_0
*    LRE_Is_Triggered_SDM_Model_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_Is_Triggered_SDM_Model_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvO_LRE_Is_Triggered_SDM_Model_0( uint8 objIndx_u8, CORELANERDEDGEvOLREIsTriggeredSDMModel0 * pLRE_Is_Triggered_SDM_Model_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELANERDEDGEvOLREIsTriggeredSDMModel0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANERDEDGEvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLRE_Is_Triggered_SDM_Model_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANERDEDGE_ParamsApp_s.EYEQMSG_CORELANERDEDGEvO_Params_as[objIndx_u8].LRE_Is_Triggered_SDM_Model_0_b2;
         * pLRE_Is_Triggered_SDM_Model_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANERDEDGEvO_LRE_IS_TRIGGERED_SDM_MODEL_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvO_Reserved_5_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pReserved_5_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_5_0
*    Reserved_5_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_5_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvO_Reserved_5_0( uint8 objIndx_u8, uint16 * pReserved_5_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANERDEDGEvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_5_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANERDEDGE_ParamsApp_s.EYEQMSG_CORELANERDEDGEvO_Params_as[objIndx_u8].Reserved_5_0_b13;
         * pReserved_5_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANERDEDGEvO_RESERVED_5_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvO_LRE_Line_C3_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    float32 * pLRE_Line_C3_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_Line_C3_0
*    LRE_Line_C3_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_Line_C3_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvO_LRE_Line_C3_0( uint8 objIndx_u8, float32 * pLRE_Line_C3_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float32SigDataType signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANERDEDGEvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLRE_Line_C3_0 != C_NULL_P )
      {
         signal_value.u = EYEQMSG_CORELANERDEDGE_ParamsApp_s.EYEQMSG_CORELANERDEDGEvO_Params_as[objIndx_u8].LRE_Line_C3_0_sb32;
         * pLRE_Line_C3_0 = signal_value.f;
         if( (signal_value.f >= C_EYEQMSG_CORELANERDEDGEvO_LRE_LINE_C3_0_RMIN ) 
             && (signal_value.f <= C_EYEQMSG_CORELANERDEDGEvO_LRE_LINE_C3_0_RMAX ) )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvO_LRE_Line_C2_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    float32 * pLRE_Line_C2_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_Line_C2_0
*    LRE_Line_C2_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_Line_C2_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvO_LRE_Line_C2_0( uint8 objIndx_u8, float32 * pLRE_Line_C2_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float32SigDataType signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANERDEDGEvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLRE_Line_C2_0 != C_NULL_P )
      {
         signal_value.u = EYEQMSG_CORELANERDEDGE_ParamsApp_s.EYEQMSG_CORELANERDEDGEvO_Params_as[objIndx_u8].LRE_Line_C2_0_sb32;
         * pLRE_Line_C2_0 = signal_value.f;
         if( (signal_value.f >= C_EYEQMSG_CORELANERDEDGEvO_LRE_LINE_C2_0_RMIN ) 
             && (signal_value.f <= C_EYEQMSG_CORELANERDEDGEvO_LRE_LINE_C2_0_RMAX ) )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvO_LRE_Line_C1_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    float32 * pLRE_Line_C1_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_Line_C1_0
*    LRE_Line_C1_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_Line_C1_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvO_LRE_Line_C1_0( uint8 objIndx_u8, float32 * pLRE_Line_C1_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float32SigDataType signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANERDEDGEvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLRE_Line_C1_0 != C_NULL_P )
      {
         signal_value.u = EYEQMSG_CORELANERDEDGE_ParamsApp_s.EYEQMSG_CORELANERDEDGEvO_Params_as[objIndx_u8].LRE_Line_C1_0_sb32;
         * pLRE_Line_C1_0 = signal_value.f;
         if( (signal_value.f >= C_EYEQMSG_CORELANERDEDGEvO_LRE_LINE_C1_0_RMIN ) 
             && (signal_value.f <= C_EYEQMSG_CORELANERDEDGEvO_LRE_LINE_C1_0_RMAX ) )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvO_LRE_Line_C0_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    float32 * pLRE_Line_C0_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_Line_C0_0
*    LRE_Line_C0_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_Line_C0_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvO_LRE_Line_C0_0( uint8 objIndx_u8, float32 * pLRE_Line_C0_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float32SigDataType signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANERDEDGEvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLRE_Line_C0_0 != C_NULL_P )
      {
         signal_value.u = EYEQMSG_CORELANERDEDGE_ParamsApp_s.EYEQMSG_CORELANERDEDGEvO_Params_as[objIndx_u8].LRE_Line_C0_0_sb32;
         * pLRE_Line_C0_0 = signal_value.f;
         if( (signal_value.f >= C_EYEQMSG_CORELANERDEDGEvO_LRE_LINE_C0_0_RMIN ) 
             && (signal_value.f <= C_EYEQMSG_CORELANERDEDGEvO_LRE_LINE_C0_0_RMAX ) )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvO_LRE_Detection_Source_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANERDEDGEvOLREDetectionSource0 * pLRE_Detection_Source_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_Detection_Source_0
*    LRE_Detection_Source_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_Detection_Source_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvO_LRE_Detection_Source_0( uint8 objIndx_u8, CORELANERDEDGEvOLREDetectionSource0 * pLRE_Detection_Source_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELANERDEDGEvOLREDetectionSource0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANERDEDGEvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLRE_Detection_Source_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANERDEDGE_ParamsApp_s.EYEQMSG_CORELANERDEDGEvO_Params_as[objIndx_u8].LRE_Detection_Source_0_b2;
         * pLRE_Detection_Source_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvO_LRE_Element_Buffer_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint32 * pLRE_Element_Buffer_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_Element_Buffer_0
*    LRE_Element_Buffer_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_Element_Buffer_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvO_LRE_Element_Buffer_0( uint8 objIndx_u8, uint32 * pLRE_Element_Buffer_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANERDEDGEvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLRE_Element_Buffer_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANERDEDGE_ParamsApp_s.EYEQMSG_CORELANERDEDGEvO_Params_as[objIndx_u8].LRE_Element_Buffer_0_b30;
         * pLRE_Element_Buffer_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANERDEDGEvO_LRE_ELEMENT_BUFFER_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_CORELANERDEDGE_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_CORELANERDEDGE_Params_t * pCore_Lanes_Road_Edge_protocol - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_Lanes_Road_Edge_protocol message 
*    Core_Lanes_Road_Edge_protocol message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_Lanes_Road_Edge_protocol message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_CORELANERDEDGE_ParamsApp_MsgDataStruct( EYEQMSG_CORELANERDEDGE_Params_t * pCore_Lanes_Road_Edge_protocol )
{
   Std_ReturnType status = C_SIG_INVALID;
   if( pCore_Lanes_Road_Edge_protocol != C_NULL_P )
   {
      status = C_SIG_VALID;
      * pCore_Lanes_Road_Edge_protocol = EYEQMSG_CORELANERDEDGE_ParamsApp_s;
   }
   return ( status );
}

