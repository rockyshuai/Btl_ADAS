#ifndef _EYEQMSG_APPMSGPROCESS_H_
#define _EYEQMSG_APPMSGPROCESS_H_

/*****************************************************************************
                  Included header files
*****************************************************************************/
#include <Std_Types.h>

/*****************************************************************************
                  Include files
*****************************************************************************/
/*****************************************************************************
                  Exported symbolic constants
*****************************************************************************/

/* Datagram message ID */
#define C_EYEQMSG_APPMSG_MSG_ID                               ( 0x41U )

/* Datagram message lengths */
#define C_EYEQMSG_APPMSG_MSG_LEN                              ( sizeof(EYEQMSG_APPMSG_Params_t) )

/* Protocol ENUMs */

/* MCU output messages */

/* Core_Application_Message_protocol Enums */
/* App_CRC32_b32 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_CRC32_RMIN                       ( 0U )
#define C_EYEQMSG_APPMSG_APP_CRC32_RMAX                       ( 4294967295U )
#define C_EYEQMSG_APPMSG_APP_CRC32_NUMR                       ( 1U )
#define C_EYEQMSG_APPMSG_APP_CRC32_DEMNR                      ( 1U )
#define C_EYEQMSG_APPMSG_APP_CRC32_OFFSET                     ( 0U )

/* App_RSRV_14_b32 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_RSRV_14_RMIN                     ( 0U )
#define C_EYEQMSG_APPMSG_APP_RSRV_14_RMAX                     ( 4294967295U )
#define C_EYEQMSG_APPMSG_APP_RSRV_14_NUMR                     ( 1U )
#define C_EYEQMSG_APPMSG_APP_RSRV_14_DEMNR                    ( 1U )
#define C_EYEQMSG_APPMSG_APP_RSRV_14_OFFSET                   ( 0U )

/* APP_SPI_Retransmit_Tx_b32 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_SPI_RETRANSMIT_TX_RMIN           ( 0U )
#define C_EYEQMSG_APPMSG_APP_SPI_RETRANSMIT_TX_RMAX           ( 4294967295U )
#define C_EYEQMSG_APPMSG_APP_SPI_RETRANSMIT_TX_NUMR           ( 1U )
#define C_EYEQMSG_APPMSG_APP_SPI_RETRANSMIT_TX_DEMNR          ( 1U )
#define C_EYEQMSG_APPMSG_APP_SPI_RETRANSMIT_TX_OFFSET         ( 0U )

/* APP_SPI_Bus_Load_Rx_b32 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_SPI_BUS_LOAD_RX_RMIN             ( 0U )
#define C_EYEQMSG_APPMSG_APP_SPI_BUS_LOAD_RX_RMAX             ( 4294967295U )
#define C_EYEQMSG_APPMSG_APP_SPI_BUS_LOAD_RX_NUMR             ( 1U )
#define C_EYEQMSG_APPMSG_APP_SPI_BUS_LOAD_RX_DEMNR            ( 1U )
#define C_EYEQMSG_APPMSG_APP_SPI_BUS_LOAD_RX_OFFSET           ( 0U )

/* APP_SPI_Bus_Load_Tx_b32 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_SPI_BUS_LOAD_TX_RMIN             ( 0U )
#define C_EYEQMSG_APPMSG_APP_SPI_BUS_LOAD_TX_RMAX             ( 4294967295U )
#define C_EYEQMSG_APPMSG_APP_SPI_BUS_LOAD_TX_NUMR             ( 1U )
#define C_EYEQMSG_APPMSG_APP_SPI_BUS_LOAD_TX_DEMNR            ( 1U )
#define C_EYEQMSG_APPMSG_APP_SPI_BUS_LOAD_TX_OFFSET           ( 0U )

/* APP_Camera3_VideoErrorFlags_pt2_b32 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_CAMERA3_VIDEOERRORFLAGS_PT2_RMIN ( 0U )
#define C_EYEQMSG_APPMSG_APP_CAMERA3_VIDEOERRORFLAGS_PT2_RMAX ( 4294967295U )
#define C_EYEQMSG_APPMSG_APP_CAMERA3_VIDEOERRORFLAGS_PT2_NUMR ( 1U )
#define C_EYEQMSG_APPMSG_APP_CAMERA3_VIDEOERRORFLAGS_PT2_DEMNR ( 1U )
#define C_EYEQMSG_APPMSG_APP_CAMERA3_VIDEOERRORFLAGS_PT2_OFFSET ( 0U )

/* APP_Camera2_VideoErrorFlags_pt2_b32 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_CAMERA2_VIDEOERRORFLAGS_PT2_RMIN ( 0U )
#define C_EYEQMSG_APPMSG_APP_CAMERA2_VIDEOERRORFLAGS_PT2_RMAX ( 4294967295U )
#define C_EYEQMSG_APPMSG_APP_CAMERA2_VIDEOERRORFLAGS_PT2_NUMR ( 1U )
#define C_EYEQMSG_APPMSG_APP_CAMERA2_VIDEOERRORFLAGS_PT2_DEMNR ( 1U )
#define C_EYEQMSG_APPMSG_APP_CAMERA2_VIDEOERRORFLAGS_PT2_OFFSET ( 0U )

/* APP_Camera1_VideoErrorFlags_pt2_b32 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_CAMERA1_VIDEOERRORFLAGS_PT2_RMIN ( 0U )
#define C_EYEQMSG_APPMSG_APP_CAMERA1_VIDEOERRORFLAGS_PT2_RMAX ( 4294967295U )
#define C_EYEQMSG_APPMSG_APP_CAMERA1_VIDEOERRORFLAGS_PT2_NUMR ( 1U )
#define C_EYEQMSG_APPMSG_APP_CAMERA1_VIDEOERRORFLAGS_PT2_DEMNR ( 1U )
#define C_EYEQMSG_APPMSG_APP_CAMERA1_VIDEOERRORFLAGS_PT2_OFFSET ( 0U )

/* App_RSRV_13_b32 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_RSRV_13_RMIN                     ( 0U )
#define C_EYEQMSG_APPMSG_APP_RSRV_13_RMAX                     ( 4294967295U )
#define C_EYEQMSG_APPMSG_APP_RSRV_13_NUMR                     ( 1U )
#define C_EYEQMSG_APPMSG_APP_RSRV_13_DEMNR                    ( 1U )
#define C_EYEQMSG_APPMSG_APP_RSRV_13_OFFSET                   ( 0U )

/* App_RSRV_12_b32 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_RSRV_12_RMIN                     ( 0U )
#define C_EYEQMSG_APPMSG_APP_RSRV_12_RMAX                     ( 4294967295U )
#define C_EYEQMSG_APPMSG_APP_RSRV_12_NUMR                     ( 1U )
#define C_EYEQMSG_APPMSG_APP_RSRV_12_DEMNR                    ( 1U )
#define C_EYEQMSG_APPMSG_APP_RSRV_12_OFFSET                   ( 0U )

/* APP_Application_ver_b32 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_APPLICATION_VER_RMIN             ( 0U )
#define C_EYEQMSG_APPMSG_APP_APPLICATION_VER_RMAX             ( 4294967295U )
#define C_EYEQMSG_APPMSG_APP_APPLICATION_VER_NUMR             ( 1U )
#define C_EYEQMSG_APPMSG_APP_APPLICATION_VER_DEMNR            ( 1U )
#define C_EYEQMSG_APPMSG_APP_APPLICATION_VER_OFFSET           ( 0U )

/* APP_appMode_b32 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_APPMODE_RMIN                     ( 0U )
#define C_EYEQMSG_APPMSG_APP_APPMODE_RMAX                     ( 4294967295U )
#define C_EYEQMSG_APPMSG_APP_APPMODE_NUMR                     ( 1U )
#define C_EYEQMSG_APPMSG_APP_APPMODE_DEMNR                    ( 1U )
#define C_EYEQMSG_APPMSG_APP_APPMODE_OFFSET                   ( 0U )

/* APP_Brain_drops_counter_b32 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_BRAIN_DROPS_COUNTER_RMIN         ( 0U )
#define C_EYEQMSG_APPMSG_APP_BRAIN_DROPS_COUNTER_RMAX         ( 4294967295U )
#define C_EYEQMSG_APPMSG_APP_BRAIN_DROPS_COUNTER_NUMR         ( 1U )
#define C_EYEQMSG_APPMSG_APP_BRAIN_DROPS_COUNTER_DEMNR        ( 1U )
#define C_EYEQMSG_APPMSG_APP_BRAIN_DROPS_COUNTER_OFFSET       ( 0U )

/* APP_Camera3_VideoErrorFlags_pt1_b32 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_CAMERA3_VIDEOERRORFLAGS_PT1_RMIN ( 0U )
#define C_EYEQMSG_APPMSG_APP_CAMERA3_VIDEOERRORFLAGS_PT1_RMAX ( 4294967295U )
#define C_EYEQMSG_APPMSG_APP_CAMERA3_VIDEOERRORFLAGS_PT1_NUMR ( 1U )
#define C_EYEQMSG_APPMSG_APP_CAMERA3_VIDEOERRORFLAGS_PT1_DEMNR ( 1U )
#define C_EYEQMSG_APPMSG_APP_CAMERA3_VIDEOERRORFLAGS_PT1_OFFSET ( 0U )

/* APP_Camera2_VideoErrorFlags_pt1_b32 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_CAMERA2_VIDEOERRORFLAGS_PT1_RMIN ( 0U )
#define C_EYEQMSG_APPMSG_APP_CAMERA2_VIDEOERRORFLAGS_PT1_RMAX ( 4294967295U )
#define C_EYEQMSG_APPMSG_APP_CAMERA2_VIDEOERRORFLAGS_PT1_NUMR ( 1U )
#define C_EYEQMSG_APPMSG_APP_CAMERA2_VIDEOERRORFLAGS_PT1_DEMNR ( 1U )
#define C_EYEQMSG_APPMSG_APP_CAMERA2_VIDEOERRORFLAGS_PT1_OFFSET ( 0U )

/* APP_Camera1_VideoErrorFlags_pt1_b32 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_CAMERA1_VIDEOERRORFLAGS_PT1_RMIN ( 0U )
#define C_EYEQMSG_APPMSG_APP_CAMERA1_VIDEOERRORFLAGS_PT1_RMAX ( 4294967295U )
#define C_EYEQMSG_APPMSG_APP_CAMERA1_VIDEOERRORFLAGS_PT1_NUMR ( 1U )
#define C_EYEQMSG_APPMSG_APP_CAMERA1_VIDEOERRORFLAGS_PT1_DEMNR ( 1U )
#define C_EYEQMSG_APPMSG_APP_CAMERA1_VIDEOERRORFLAGS_PT1_OFFSET ( 0U )

/* App_RSRV_11_b8 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_RSRV_11_RMIN                     ( 0U )
#define C_EYEQMSG_APPMSG_APP_RSRV_11_RMAX                     ( 255U )
#define C_EYEQMSG_APPMSG_APP_RSRV_11_NUMR                     ( 1U )
#define C_EYEQMSG_APPMSG_APP_RSRV_11_DEMNR                    ( 1U )
#define C_EYEQMSG_APPMSG_APP_RSRV_11_OFFSET                   ( 0U )

/* App_RSRV_10_b8 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_RSRV_10_RMIN                     ( 0U )
#define C_EYEQMSG_APPMSG_APP_RSRV_10_RMAX                     ( 255U )
#define C_EYEQMSG_APPMSG_APP_RSRV_10_NUMR                     ( 1U )
#define C_EYEQMSG_APPMSG_APP_RSRV_10_DEMNR                    ( 1U )
#define C_EYEQMSG_APPMSG_APP_RSRV_10_OFFSET                   ( 0U )

/* App_RSRV_9_b8 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_RSRV_9_RMIN                      ( 0U )
#define C_EYEQMSG_APPMSG_APP_RSRV_9_RMAX                      ( 255U )
#define C_EYEQMSG_APPMSG_APP_RSRV_9_NUMR                      ( 1U )
#define C_EYEQMSG_APPMSG_APP_RSRV_9_DEMNR                     ( 1U )
#define C_EYEQMSG_APPMSG_APP_RSRV_9_OFFSET                    ( 0U )

/* App_RSRV_8_b8 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_RSRV_8_RMIN                      ( 0U )
#define C_EYEQMSG_APPMSG_APP_RSRV_8_RMAX                      ( 255U )
#define C_EYEQMSG_APPMSG_APP_RSRV_8_NUMR                      ( 1U )
#define C_EYEQMSG_APPMSG_APP_RSRV_8_DEMNR                     ( 1U )
#define C_EYEQMSG_APPMSG_APP_RSRV_8_OFFSET                    ( 0U )

/* App_RSRV_7_b8 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_RSRV_7_RMIN                      ( 0U )
#define C_EYEQMSG_APPMSG_APP_RSRV_7_RMAX                      ( 255U )
#define C_EYEQMSG_APPMSG_APP_RSRV_7_NUMR                      ( 1U )
#define C_EYEQMSG_APPMSG_APP_RSRV_7_DEMNR                     ( 1U )
#define C_EYEQMSG_APPMSG_APP_RSRV_7_OFFSET                    ( 0U )

/* APP_Camera3_VideoErrorRange_b8 signal Enums */
typedef uint8 APPMSGAPPCamera3VideoErrorRange;
#define C_EYEQMSG_APPMSG_APP_CAMERA3_VIDEOERRORRANGE__BIT_0_VALID ( APPMSGAPPCamera3VideoErrorRange ) ( 0U )

/* APP_Camera3_VideoErrorRange_b8 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_CAMERA3_VIDEOERRORRANGE_RMIN     ( 0U )
#define C_EYEQMSG_APPMSG_APP_CAMERA3_VIDEOERRORRANGE_RMAX     ( 255U )
#define C_EYEQMSG_APPMSG_APP_CAMERA3_VIDEOERRORRANGE_NUMR     ( 1U )
#define C_EYEQMSG_APPMSG_APP_CAMERA3_VIDEOERRORRANGE_DEMNR    ( 1U )
#define C_EYEQMSG_APPMSG_APP_CAMERA3_VIDEOERRORRANGE_OFFSET   ( 0U )

/* APP_Camera2_VideoErrorRange_b8 signal Enums */
typedef uint8 APPMSGAPPCamera2VideoErrorRange;
#define C_EYEQMSG_APPMSG_APP_CAMERA2_VIDEOERRORRANGE__BIT_0_VALID ( APPMSGAPPCamera2VideoErrorRange ) ( 0U )

/* APP_Camera2_VideoErrorRange_b8 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_CAMERA2_VIDEOERRORRANGE_RMIN     ( 0U )
#define C_EYEQMSG_APPMSG_APP_CAMERA2_VIDEOERRORRANGE_RMAX     ( 255U )
#define C_EYEQMSG_APPMSG_APP_CAMERA2_VIDEOERRORRANGE_NUMR     ( 1U )
#define C_EYEQMSG_APPMSG_APP_CAMERA2_VIDEOERRORRANGE_DEMNR    ( 1U )
#define C_EYEQMSG_APPMSG_APP_CAMERA2_VIDEOERRORRANGE_OFFSET   ( 0U )

/* APP_Camera1_VideoErrorRange_b8 signal Enums */
typedef uint8 APPMSGAPPCamera1VideoErrorRange;
#define C_EYEQMSG_APPMSG_APP_CAMERA1_VIDEOERRORRANGE__BIT_0_CRC ( APPMSGAPPCamera1VideoErrorRange ) ( 0U )
#define C_EYEQMSG_APPMSG_APP_CAMERA1_VIDEOERRORRANGE__BIT_1_SPI_CRC_CONTINUOUS_BIT ( APPMSGAPPCamera1VideoErrorRange ) ( 1U )
#define C_EYEQMSG_APPMSG_APP_CAMERA1_VIDEOERRORRANGE__BIT_2_SPI_SEQ_BIT ( APPMSGAPPCamera1VideoErrorRange ) ( 2U )
#define C_EYEQMSG_APPMSG_APP_CAMERA1_VIDEOERRORRANGE__BIT_3_SPI_SEQ_CONTINUOUS_BIT ( APPMSGAPPCamera1VideoErrorRange ) ( 3U )

/* APP_Camera1_VideoErrorRange_b8 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_CAMERA1_VIDEOERRORRANGE_RMIN     ( 0U )
#define C_EYEQMSG_APPMSG_APP_CAMERA1_VIDEOERRORRANGE_RMAX     ( 255U )
#define C_EYEQMSG_APPMSG_APP_CAMERA1_VIDEOERRORRANGE_NUMR     ( 1U )
#define C_EYEQMSG_APPMSG_APP_CAMERA1_VIDEOERRORRANGE_DEMNR    ( 1U )
#define C_EYEQMSG_APPMSG_APP_CAMERA1_VIDEOERRORRANGE_OFFSET   ( 0U )

/* App_RSRV_6_sb8 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_RSRV_6_RMIN                      ( -128 )
#define C_EYEQMSG_APPMSG_APP_RSRV_6_RMAX                      ( 127 )
#define C_EYEQMSG_APPMSG_APP_RSRV_6_NUMR                      ( 1 )
#define C_EYEQMSG_APPMSG_APP_RSRV_6_DEMNR                     ( 1 )
#define C_EYEQMSG_APPMSG_APP_RSRV_6_OFFSET                    ( 0U )

/* App_RSRV_5_sb8 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_RSRV_5_RMIN                      ( -128 )
#define C_EYEQMSG_APPMSG_APP_RSRV_5_RMAX                      ( 127 )
#define C_EYEQMSG_APPMSG_APP_RSRV_5_NUMR                      ( 1 )
#define C_EYEQMSG_APPMSG_APP_RSRV_5_DEMNR                     ( 1 )
#define C_EYEQMSG_APPMSG_APP_RSRV_5_OFFSET                    ( 0U )

/* APP_Camera3_temperature_2_sb8 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_CAMERA3_TEMPERATURE_2_RMIN       ( -128 )
#define C_EYEQMSG_APPMSG_APP_CAMERA3_TEMPERATURE_2_RMAX       ( 127 )
#define C_EYEQMSG_APPMSG_APP_CAMERA3_TEMPERATURE_2_NUMR       ( 1 )
#define C_EYEQMSG_APPMSG_APP_CAMERA3_TEMPERATURE_2_DEMNR      ( 1 )
#define C_EYEQMSG_APPMSG_APP_CAMERA3_TEMPERATURE_2_OFFSET     ( 0U )

/* APP_Camera2_temperature_2_sb8 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_CAMERA2_TEMPERATURE_2_RMIN       ( -128 )
#define C_EYEQMSG_APPMSG_APP_CAMERA2_TEMPERATURE_2_RMAX       ( 127 )
#define C_EYEQMSG_APPMSG_APP_CAMERA2_TEMPERATURE_2_NUMR       ( 1 )
#define C_EYEQMSG_APPMSG_APP_CAMERA2_TEMPERATURE_2_DEMNR      ( 1 )
#define C_EYEQMSG_APPMSG_APP_CAMERA2_TEMPERATURE_2_OFFSET     ( 0U )

/* APP_Camera1_temperature_2_sb8 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_CAMERA1_TEMPERATURE_2_RMIN       ( -128 )
#define C_EYEQMSG_APPMSG_APP_CAMERA1_TEMPERATURE_2_RMAX       ( 127 )
#define C_EYEQMSG_APPMSG_APP_CAMERA1_TEMPERATURE_2_NUMR       ( 1 )
#define C_EYEQMSG_APPMSG_APP_CAMERA1_TEMPERATURE_2_DEMNR      ( 1 )
#define C_EYEQMSG_APPMSG_APP_CAMERA1_TEMPERATURE_2_OFFSET     ( 0U )

/* APP_Camera3_temperature_1_sb8 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_CAMERA3_TEMPERATURE_1_RMIN       ( -128 )
#define C_EYEQMSG_APPMSG_APP_CAMERA3_TEMPERATURE_1_RMAX       ( 127 )
#define C_EYEQMSG_APPMSG_APP_CAMERA3_TEMPERATURE_1_NUMR       ( 1 )
#define C_EYEQMSG_APPMSG_APP_CAMERA3_TEMPERATURE_1_DEMNR      ( 1 )
#define C_EYEQMSG_APPMSG_APP_CAMERA3_TEMPERATURE_1_OFFSET     ( 0U )

/* APP_Camera2_temperature_1_sb8 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_CAMERA2_TEMPERATURE_1_RMIN       ( -128 )
#define C_EYEQMSG_APPMSG_APP_CAMERA2_TEMPERATURE_1_RMAX       ( 127 )
#define C_EYEQMSG_APPMSG_APP_CAMERA2_TEMPERATURE_1_NUMR       ( 1 )
#define C_EYEQMSG_APPMSG_APP_CAMERA2_TEMPERATURE_1_DEMNR      ( 1 )
#define C_EYEQMSG_APPMSG_APP_CAMERA2_TEMPERATURE_1_OFFSET     ( 0U )

/* APP_Camera1_temperature_1_sb8 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_CAMERA1_TEMPERATURE_1_RMIN       ( -128 )
#define C_EYEQMSG_APPMSG_APP_CAMERA1_TEMPERATURE_1_RMAX       ( 127 )
#define C_EYEQMSG_APPMSG_APP_CAMERA1_TEMPERATURE_1_NUMR       ( 1 )
#define C_EYEQMSG_APPMSG_APP_CAMERA1_TEMPERATURE_1_DEMNR      ( 1 )
#define C_EYEQMSG_APPMSG_APP_CAMERA1_TEMPERATURE_1_OFFSET     ( 0U )

/* APP_Valid_cameras_information_b8 signal Enums */
typedef uint8 APPMSGAPPValidCamerasInformation;
#define C_EYEQMSG_APPMSG_APP_VALID_CAMERAS_INFORMATION__BIT_0_VALID ( APPMSGAPPValidCamerasInformation ) ( 0U )

/* APP_Valid_cameras_information_b8 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_VALID_CAMERAS_INFORMATION_RMIN   ( 0U )
#define C_EYEQMSG_APPMSG_APP_VALID_CAMERAS_INFORMATION_RMAX   ( 255U )
#define C_EYEQMSG_APPMSG_APP_VALID_CAMERAS_INFORMATION_NUMR   ( 1U )
#define C_EYEQMSG_APPMSG_APP_VALID_CAMERAS_INFORMATION_DEMNR  ( 1U )
#define C_EYEQMSG_APPMSG_APP_VALID_CAMERAS_INFORMATION_OFFSET ( 0U )

/* APP_Valid_second_cam_temp_info_b8 signal Enums */
typedef uint8 APPMSGAPPValidSecondCamTempInfo;
#define C_EYEQMSG_APPMSG_APP_VALID_SECOND_CAM_TEMP_INFO__BIT_0_VALID ( APPMSGAPPValidSecondCamTempInfo ) ( 0U )

/* APP_Valid_second_cam_temp_info_b8 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_VALID_SECOND_CAM_TEMP_INFO_RMIN  ( 0U )
#define C_EYEQMSG_APPMSG_APP_VALID_SECOND_CAM_TEMP_INFO_RMAX  ( 255U )
#define C_EYEQMSG_APPMSG_APP_VALID_SECOND_CAM_TEMP_INFO_NUMR  ( 1U )
#define C_EYEQMSG_APPMSG_APP_VALID_SECOND_CAM_TEMP_INFO_DEMNR ( 1U )
#define C_EYEQMSG_APPMSG_APP_VALID_SECOND_CAM_TEMP_INFO_OFFSET ( 0U )

/* APP_spiErrors_b8 signal Enums */
typedef uint8 APPMSGAPPSpiErrors;
#define C_EYEQMSG_APPMSG_APP_SPIERRORS__BIT_0_CRC             ( APPMSGAPPSpiErrors ) ( 0U )
#define C_EYEQMSG_APPMSG_APP_SPIERRORS__BIT_1_SPI_CRC_CONTINUOUS_BIT ( APPMSGAPPSpiErrors ) ( 1U )
#define C_EYEQMSG_APPMSG_APP_SPIERRORS__BIT_2_SPI_SEQ_BIT     ( APPMSGAPPSpiErrors ) ( 2U )
#define C_EYEQMSG_APPMSG_APP_SPIERRORS__BIT_3_SPI_SEQ_CONTINUOUS_BIT ( APPMSGAPPSpiErrors ) ( 3U )

/* APP_spiErrors_b8 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_SPIERRORS_RMIN                   ( 0U )
#define C_EYEQMSG_APPMSG_APP_SPIERRORS_RMAX                   ( 255U )
#define C_EYEQMSG_APPMSG_APP_SPIERRORS_NUMR                   ( 1U )
#define C_EYEQMSG_APPMSG_APP_SPIERRORS_DEMNR                  ( 1U )
#define C_EYEQMSG_APPMSG_APP_SPIERRORS_OFFSET                 ( 0U )

/* App_RSRV_4_b8 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_RSRV_4_RMIN                      ( 0U )
#define C_EYEQMSG_APPMSG_APP_RSRV_4_RMAX                      ( 255U )
#define C_EYEQMSG_APPMSG_APP_RSRV_4_NUMR                      ( 1U )
#define C_EYEQMSG_APPMSG_APP_RSRV_4_DEMNR                     ( 1U )
#define C_EYEQMSG_APPMSG_APP_RSRV_4_OFFSET                    ( 0U )

/* App_RSRV_3_b16 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_RSRV_3_RMIN                      ( 0U )
#define C_EYEQMSG_APPMSG_APP_RSRV_3_RMAX                      ( 65535U )
#define C_EYEQMSG_APPMSG_APP_RSRV_3_NUMR                      ( 1U )
#define C_EYEQMSG_APPMSG_APP_RSRV_3_DEMNR                     ( 1U )
#define C_EYEQMSG_APPMSG_APP_RSRV_3_OFFSET                    ( 0U )

/* App_RSRV_2_b8 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_RSRV_2_RMIN                      ( 0U )
#define C_EYEQMSG_APPMSG_APP_RSRV_2_RMAX                      ( 0U )
#define C_EYEQMSG_APPMSG_APP_RSRV_2_NUMR                      ( 1U )
#define C_EYEQMSG_APPMSG_APP_RSRV_2_DEMNR                     ( 1U )
#define C_EYEQMSG_APPMSG_APP_RSRV_2_OFFSET                    ( 0U )

/* APP_Temperature_DDR_sb8 signal Enums */
typedef sint8 APPMSGAPPTemperatureDDR;
#define C_EYEQMSG_APPMSG_APP_TEMPERATURE_DDR_TEMP_ERROR       ( APPMSGAPPTemperatureDDR ) ( -1 )
#define C_EYEQMSG_APPMSG_APP_TEMPERATURE_DDR_RANGE_OK         ( APPMSGAPPTemperatureDDR ) ( 0 )
#define C_EYEQMSG_APPMSG_APP_TEMPERATURE_DDR_BELOW_SPEC       ( APPMSGAPPTemperatureDDR ) ( 1 )
#define C_EYEQMSG_APPMSG_APP_TEMPERATURE_DDR_ABOVE_SPEC       ( APPMSGAPPTemperatureDDR ) ( 2 )
#define C_EYEQMSG_APPMSG_APP_TEMPERATURE_DDR_ABOVE_85C        ( APPMSGAPPTemperatureDDR ) ( 3 )
#define C_EYEQMSG_APPMSG_APP_TEMPERATURE_DDR_TEMP_EVEN_COLDER ( APPMSGAPPTemperatureDDR ) ( 4 )
#define C_EYEQMSG_APPMSG_APP_TEMPERATURE_DDR_TEMP_COOL        ( APPMSGAPPTemperatureDDR ) ( 5 )
#define C_EYEQMSG_APPMSG_APP_TEMPERATURE_DDR_TEMP_RANGE_WARM  ( APPMSGAPPTemperatureDDR ) ( 6 )
#define C_EYEQMSG_APPMSG_APP_TEMPERATURE_DDR_TEMP_RANGE_EVEN_WARMER ( APPMSGAPPTemperatureDDR ) ( 7 )

/* APP_Temperature_DDR_sb8 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_TEMPERATURE_DDR_RMIN             ( -1 )
#define C_EYEQMSG_APPMSG_APP_TEMPERATURE_DDR_RMAX             ( 7 )
#define C_EYEQMSG_APPMSG_APP_TEMPERATURE_DDR_NUMR             ( 1 )
#define C_EYEQMSG_APPMSG_APP_TEMPERATURE_DDR_DEMNR            ( 1 )
#define C_EYEQMSG_APPMSG_APP_TEMPERATURE_DDR_OFFSET           ( 0U )

/* APP_EyeQTemperature2_sb16 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_EYEQTEMPERATURE2_RMIN            ( -128 )
#define C_EYEQMSG_APPMSG_APP_EYEQTEMPERATURE2_RMAX            ( 127 )
#define C_EYEQMSG_APPMSG_APP_EYEQTEMPERATURE2_NUMR            ( 1 )
#define C_EYEQMSG_APPMSG_APP_EYEQTEMPERATURE2_DEMNR           ( 1 )
#define C_EYEQMSG_APPMSG_APP_EYEQTEMPERATURE2_OFFSET          ( 0U )

/* APP_EyeQTemperature1_sb16 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_EYEQTEMPERATURE1_RMIN            ( -128 )
#define C_EYEQMSG_APPMSG_APP_EYEQTEMPERATURE1_RMAX            ( 127 )
#define C_EYEQMSG_APPMSG_APP_EYEQTEMPERATURE1_NUMR            ( 1 )
#define C_EYEQMSG_APPMSG_APP_EYEQTEMPERATURE1_DEMNR           ( 1 )
#define C_EYEQMSG_APPMSG_APP_EYEQTEMPERATURE1_OFFSET          ( 0U )

/* APP_Minor_Error_b16 signal Enums */
typedef uint16 APPMSGAPPMinorError;
#define C_EYEQMSG_APPMSG_APP_MINOR_ERROR_BM_OK                ( APPMSGAPPMinorError ) ( 0U )
#define C_EYEQMSG_APPMSG_APP_MINOR_ERROR_BM_ERROR             ( APPMSGAPPMinorError ) ( 1U )
#define C_EYEQMSG_APPMSG_APP_MINOR_ERROR_BM_EM_ERROR          ( APPMSGAPPMinorError ) ( 5001U )
#define C_EYEQMSG_APPMSG_APP_MINOR_ERROR_BM_EM_ERR_FAILED_LOAD_SETTING ( APPMSGAPPMinorError ) ( 5002U )
#define C_EYEQMSG_APPMSG_APP_MINOR_ERROR_BM_EM_ERR_FAILED_LOAD_REGISTRY ( APPMSGAPPMinorError ) ( 5003U )
#define C_EYEQMSG_APPMSG_APP_MINOR_ERROR_BM_EM_ERR_FAILED_INIT_REGISTRY ( APPMSGAPPMinorError ) ( 5004U )
#define C_EYEQMSG_APPMSG_APP_MINOR_ERROR_BM_EM_ERR_FAILED_INIT ( APPMSGAPPMinorError ) ( 5005U )
#define C_EYEQMSG_APPMSG_APP_MINOR_ERROR_BM_EM_ERR_FAILED_INIT_BB ( APPMSGAPPMinorError ) ( 5006U )
#define C_EYEQMSG_APPMSG_APP_MINOR_ERROR_BM_EM_ERR_FAILED_INIT_BB_REG ( APPMSGAPPMinorError ) ( 5007U )
#define C_EYEQMSG_APPMSG_APP_MINOR_ERROR_BM_EM_ERR_FAILED_OPEN_BLACKBOX ( APPMSGAPPMinorError ) ( 5008U )
#define C_EYEQMSG_APPMSG_APP_MINOR_ERROR_BM_EM_ERR_FAILED_INIT_EP ( APPMSGAPPMinorError ) ( 5009U )
#define C_EYEQMSG_APPMSG_APP_MINOR_ERROR_BM_EM_ERR_FAILED_POST_INIT_EP ( APPMSGAPPMinorError ) ( 5010U )
#define C_EYEQMSG_APPMSG_APP_MINOR_ERROR_BM_EM_ERR_FAILED_INIT_CREATE_LOGGER ( APPMSGAPPMinorError ) ( 5011U )
#define C_EYEQMSG_APPMSG_APP_MINOR_ERROR_BM_EM_ERR_FAILED_INIT_IL ( APPMSGAPPMinorError ) ( 5012U )
#define C_EYEQMSG_APPMSG_APP_MINOR_ERROR_BM_EM_ERR_FAILED_CHECK_REG_VERSIONS ( APPMSGAPPMinorError ) ( 5013U )
#define C_EYEQMSG_APPMSG_APP_MINOR_ERROR_BM_EM_ERR_FAILED_NB_OPERATION ( APPMSGAPPMinorError ) ( 5014U )

/* APP_Minor_Error_b16 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_MINOR_ERROR_RMIN                 ( 0U )
#define C_EYEQMSG_APPMSG_APP_MINOR_ERROR_RMAX                 ( 5014U )
#define C_EYEQMSG_APPMSG_APP_MINOR_ERROR_NUMR                 ( 1U )
#define C_EYEQMSG_APPMSG_APP_MINOR_ERROR_DEMNR                ( 1U )
#define C_EYEQMSG_APPMSG_APP_MINOR_ERROR_OFFSET               ( 0U )

/* App_RSRV_1_b8 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_RSRV_1_RMIN                      ( 0U )
#define C_EYEQMSG_APPMSG_APP_RSRV_1_RMAX                      ( 0U )
#define C_EYEQMSG_APPMSG_APP_RSRV_1_NUMR                      ( 1U )
#define C_EYEQMSG_APPMSG_APP_RSRV_1_DEMNR                     ( 1U )
#define C_EYEQMSG_APPMSG_APP_RSRV_1_OFFSET                    ( 0U )

/* APP_Fatal_Error_b8 signal Enums */
typedef uint8 APPMSGAPPFatalError;
#define C_EYEQMSG_APPMSG_APP_FATAL_ERROR_APP_OK               ( APPMSGAPPFatalError ) ( 0U )
#define C_EYEQMSG_APPMSG_APP_FATAL_ERROR_APP_ERROR            ( APPMSGAPPFatalError ) ( 1U )
#define C_EYEQMSG_APPMSG_APP_FATAL_ERROR_APP_FS_ERROR         ( APPMSGAPPFatalError ) ( 10U )
#define C_EYEQMSG_APPMSG_APP_FATAL_ERROR_APP_CONFIGURATION_ERROR ( APPMSGAPPFatalError ) ( 11U )
#define C_EYEQMSG_APPMSG_APP_FATAL_ERROR_APP_INIT_FAILED      ( APPMSGAPPFatalError ) ( 20U )
#define C_EYEQMSG_APPMSG_APP_FATAL_ERROR_APP_INIT_CAMERA_INIT ( APPMSGAPPFatalError ) ( 21U )
#define C_EYEQMSG_APPMSG_APP_FATAL_ERROR_APP_INIT_CAMERA_EEPROM ( APPMSGAPPFatalError ) ( 22U )
#define C_EYEQMSG_APPMSG_APP_FATAL_ERROR_APP_INIT_CAMERA_SER_CONNECTIVITY ( APPMSGAPPFatalError ) ( 23U )
#define C_EYEQMSG_APPMSG_APP_FATAL_ERROR_APP_INIT_CAMERA_SENSOR_ID_MISMATCH ( APPMSGAPPFatalError ) ( 24U )
#define C_EYEQMSG_APPMSG_APP_FATAL_ERROR_APP_GRAB_CAM_FAILED  ( APPMSGAPPFatalError ) ( 30U )
#define C_EYEQMSG_APPMSG_APP_FATAL_ERROR_APP_CODING_FROM_FLASH_FAILED ( APPMSGAPPFatalError ) ( 40U )
#define C_EYEQMSG_APPMSG_APP_FATAL_ERROR_APP_I2C_VIDEO_GRAB_FAILED ( APPMSGAPPFatalError ) ( 50U )
#define C_EYEQMSG_APPMSG_APP_FATAL_ERROR_APP_I2C_CAMERA_SELF_RESET ( APPMSGAPPFatalError ) ( 51U )
#define C_EYEQMSG_APPMSG_APP_FATAL_ERROR_APP_I2C_TIMEOUT_ERROR ( APPMSGAPPFatalError ) ( 52U )
#define C_EYEQMSG_APPMSG_APP_FATAL_ERROR_APP_PATTERN_TEST     ( APPMSGAPPFatalError ) ( 70U )
#define C_EYEQMSG_APPMSG_APP_FATAL_ERROR_APP_CAM_PARAMS_CCFT_CRC_FAILED ( APPMSGAPPFatalError ) ( 80U )
#define C_EYEQMSG_APPMSG_APP_FATAL_ERROR_PLL_COMPARISON_ERROR ( APPMSGAPPFatalError ) ( 81U )
#define C_EYEQMSG_APPMSG_APP_FATAL_ERROR_APP_CPS_STL_FAILED   ( APPMSGAPPFatalError ) ( 82U )
#define C_EYEQMSG_APPMSG_APP_FATAL_ERROR_APP_DDR_DRIFT_COMPARISON_FAILED ( APPMSGAPPFatalError ) ( 83U )
#define C_EYEQMSG_APPMSG_APP_FATAL_ERROR_PV_GENERAL_ERROR     ( APPMSGAPPFatalError ) ( 90U )
#define C_EYEQMSG_APPMSG_APP_FATAL_ERROR_PV_VERIFICATION_ERROR ( APPMSGAPPFatalError ) ( 91U )
#define C_EYEQMSG_APPMSG_APP_FATAL_ERROR_APP_GVPU_STATE_TERMINAL ( APPMSGAPPFatalError ) ( 127U )
#define C_EYEQMSG_APPMSG_APP_FATAL_ERROR_EDR_WROTE_TO_FLASH   ( APPMSGAPPFatalError ) ( 129U )

/* APP_Fatal_Error_b8 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_FATAL_ERROR_RMIN                 ( 0U )
#define C_EYEQMSG_APPMSG_APP_FATAL_ERROR_RMAX                 ( 129U )
#define C_EYEQMSG_APPMSG_APP_FATAL_ERROR_NUMR                 ( 1U )
#define C_EYEQMSG_APPMSG_APP_FATAL_ERROR_DEMNR                ( 1U )
#define C_EYEQMSG_APPMSG_APP_FATAL_ERROR_OFFSET               ( 0U )

/* APP_Diagnostics_part_2_b16 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_DIAGNOSTICS_PART_2_RMIN          ( 0U )
#define C_EYEQMSG_APPMSG_APP_DIAGNOSTICS_PART_2_RMAX          ( 65535U )
#define C_EYEQMSG_APPMSG_APP_DIAGNOSTICS_PART_2_NUMR          ( 1U )
#define C_EYEQMSG_APPMSG_APP_DIAGNOSTICS_PART_2_DEMNR         ( 1U )
#define C_EYEQMSG_APPMSG_APP_DIAGNOSTICS_PART_2_OFFSET        ( 0U )

/* APP_Diagnostics_part_1_b16 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_DIAGNOSTICS_PART_1_RMIN          ( 0U )
#define C_EYEQMSG_APPMSG_APP_DIAGNOSTICS_PART_1_RMAX          ( 65535U )
#define C_EYEQMSG_APPMSG_APP_DIAGNOSTICS_PART_1_NUMR          ( 1U )
#define C_EYEQMSG_APPMSG_APP_DIAGNOSTICS_PART_1_DEMNR         ( 1U )
#define C_EYEQMSG_APPMSG_APP_DIAGNOSTICS_PART_1_OFFSET        ( 0U )

/* APP_EyeQ_Current_Timestamp_b32 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_EYEQ_CURRENT_TIMESTAMP_RMIN      ( 0U )
#define C_EYEQMSG_APPMSG_APP_EYEQ_CURRENT_TIMESTAMP_RMAX      ( 4294967295U )
#define C_EYEQMSG_APPMSG_APP_EYEQ_CURRENT_TIMESTAMP_NUMR      ( 1U )
#define C_EYEQMSG_APPMSG_APP_EYEQ_CURRENT_TIMESTAMP_DEMNR     ( 1U )
#define C_EYEQMSG_APPMSG_APP_EYEQ_CURRENT_TIMESTAMP_OFFSET    ( 0U )

/* APP_EyeQ_Timestamp_b32 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_EYEQ_TIMESTAMP_RMIN              ( 0U )
#define C_EYEQMSG_APPMSG_APP_EYEQ_TIMESTAMP_RMAX              ( 4294967295U )
#define C_EYEQMSG_APPMSG_APP_EYEQ_TIMESTAMP_NUMR              ( 1U )
#define C_EYEQMSG_APPMSG_APP_EYEQ_TIMESTAMP_DEMNR             ( 1U )
#define C_EYEQMSG_APPMSG_APP_EYEQ_TIMESTAMP_OFFSET            ( 0U )

/* APP_EyeQ_Process_Index_b32 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_EYEQ_PROCESS_INDEX_RMIN          ( 0U )
#define C_EYEQMSG_APPMSG_APP_EYEQ_PROCESS_INDEX_RMAX          ( 4294967295U )
#define C_EYEQMSG_APPMSG_APP_EYEQ_PROCESS_INDEX_NUMR          ( 1U )
#define C_EYEQMSG_APPMSG_APP_EYEQ_PROCESS_INDEX_DEMNR         ( 1U )
#define C_EYEQMSG_APPMSG_APP_EYEQ_PROCESS_INDEX_OFFSET        ( 0U )

/* APP_Sub_State_b8 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_SUB_STATE_RMIN                   ( 0U )
#define C_EYEQMSG_APPMSG_APP_SUB_STATE_RMAX                   ( 255U )
#define C_EYEQMSG_APPMSG_APP_SUB_STATE_NUMR                   ( 1U )
#define C_EYEQMSG_APPMSG_APP_SUB_STATE_DEMNR                  ( 1U )
#define C_EYEQMSG_APPMSG_APP_SUB_STATE_OFFSET                 ( 0U )

/* APP_Main_State_b8 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_MAIN_STATE_RMIN                  ( 0U )
#define C_EYEQMSG_APPMSG_APP_MAIN_STATE_RMAX                  ( 255U )
#define C_EYEQMSG_APPMSG_APP_MAIN_STATE_NUMR                  ( 1U )
#define C_EYEQMSG_APPMSG_APP_MAIN_STATE_DEMNR                 ( 1U )
#define C_EYEQMSG_APPMSG_APP_MAIN_STATE_OFFSET                ( 0U )

/* Application_Message_Version_b8 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APPLICATION_MESSAGE_VERSION_RMIN     ( 16U )
#define C_EYEQMSG_APPMSG_APPLICATION_MESSAGE_VERSION_RMAX     ( 16U )
#define C_EYEQMSG_APPMSG_APPLICATION_MESSAGE_VERSION_NUMR     ( 1U )
#define C_EYEQMSG_APPMSG_APPLICATION_MESSAGE_VERSION_DEMNR    ( 1U )
#define C_EYEQMSG_APPMSG_APPLICATION_MESSAGE_VERSION_OFFSET   ( 0U )

/* APP_Zero_Byte_b8 signal Min & Max range limits */
#define C_EYEQMSG_APPMSG_APP_ZERO_BYTE_RMIN                   ( 0U )
#define C_EYEQMSG_APPMSG_APP_ZERO_BYTE_RMAX                   ( 0U )
#define C_EYEQMSG_APPMSG_APP_ZERO_BYTE_NUMR                   ( 1U )
#define C_EYEQMSG_APPMSG_APP_ZERO_BYTE_DEMNR                  ( 1U )
#define C_EYEQMSG_APPMSG_APP_ZERO_BYTE_OFFSET                 ( 0U )


/*****************************************************************************
                  Exported function-like macros
*****************************************************************************/
/*****************************************************************************
                  Exported defined macros
*****************************************************************************/
/*****************************************************************************
                  Exported types, enums definitions
*****************************************************************************/
typedef struct
{
   #if ENABLE_BIG_ENDIAN_FORMAT
      uint32        APP_Zero_Byte_b8                             : 8U;
      
      uint32        Application_Message_Version_b8               : 8U;
      
      uint32        APP_Main_State_b8                            : 8U;
      
      uint32        APP_Sub_State_b8                             : 8U;
      
      uint32        APP_EyeQ_Process_Index_1_b8                  : 8U;
      
      uint32        APP_EyeQ_Process_Index_2_b8                  : 8U;
      
      uint32        APP_EyeQ_Process_Index_3_b8                  : 8U;
      
      uint32        APP_EyeQ_Process_Index_4_b8                  : 8U;
      
      uint32        APP_EyeQ_Timestamp_1_b8                      : 8U;
      
      uint32        APP_EyeQ_Timestamp_2_b8                      : 8U;
      
      uint32        APP_EyeQ_Timestamp_3_b8                      : 8U;
      
      uint32        APP_EyeQ_Timestamp_4_b8                      : 8U;
      
      uint32        APP_EyeQ_Current_Timestamp_1_b8              : 8U;
      
      uint32        APP_EyeQ_Current_Timestamp_2_b8              : 8U;
      
      uint32        APP_EyeQ_Current_Timestamp_3_b8              : 8U;
      
      uint32        APP_EyeQ_Current_Timestamp_4_b8              : 8U;
      
      uint32        APP_Diagnostics_part_1_1_b8                  : 8U;
      
      uint32        APP_Diagnostics_part_1_2_b8                  : 8U;
      
      uint32        APP_Diagnostics_part_2_1_b8                  : 8U;
      
      uint32        APP_Diagnostics_part_2_2_b8                  : 8U;
      
      uint32        APP_Fatal_Error_b8                           : 8U;
      
      uint32        App_RSRV_1_b8                                : 8U;
      
      uint32        APP_Minor_Error_1_b8                         : 8U;
      
      uint32        APP_Minor_Error_2_b8                         : 8U;
      
      uint32        APP_EyeQTemperature1_1_sb8                   : 8U;
      
      uint32        APP_EyeQTemperature1_2_sb8                   : 8U;
      
      uint32        APP_EyeQTemperature2_1_sb8                   : 8U;
      
      uint32        APP_EyeQTemperature2_2_sb8                   : 8U;
      
      sint32        APP_Temperature_DDR_sb8                      : 8;
      
      uint32        App_RSRV_2_b8                                : 8U;
      
      uint32        App_RSRV_3_1_b8                              : 8U;
      
      uint32        App_RSRV_3_2_b8                              : 8U;
      
      uint32        App_RSRV_4_b8                                : 8U;
      
      uint32        APP_spiErrors_b8                             : 8U;
      
      uint32        APP_Valid_second_cam_temp_info_b8            : 8U;
      
      uint32        APP_Valid_cameras_information_b8             : 8U;
      
      sint32        APP_Camera1_temperature_1_sb8                : 8;
      
      sint32        APP_Camera2_temperature_1_sb8                : 8;
      
      sint32        APP_Camera3_temperature_1_sb8                : 8;
      
      sint32        APP_Camera1_temperature_2_sb8                : 8;
      
      sint32        APP_Camera2_temperature_2_sb8                : 8;
      
      sint32        APP_Camera3_temperature_2_sb8                : 8;
      
      sint32        App_RSRV_5_sb8                               : 8;
      
      sint32        App_RSRV_6_sb8                               : 8;
      
      uint32        APP_Camera1_VideoErrorRange_b8               : 8U;
      
      uint32        APP_Camera2_VideoErrorRange_b8               : 8U;
      
      uint32        APP_Camera3_VideoErrorRange_b8               : 8U;
      
      uint32        App_RSRV_7_b8                                : 8U;
      
      uint32        App_RSRV_8_b8                                : 8U;
      
      uint32        App_RSRV_9_b8                                : 8U;
      
      uint32        App_RSRV_10_b8                               : 8U;
      
      uint32        App_RSRV_11_b8                               : 8U;
      
      uint32        APP_Camera1_VideoErrorFlags_pt1_1_b8         : 8U;
      
      uint32        APP_Camera1_VideoErrorFlags_pt1_2_b8         : 8U;
      
      uint32        APP_Camera1_VideoErrorFlags_pt1_3_b8         : 8U;
      
      uint32        APP_Camera1_VideoErrorFlags_pt1_4_b8         : 8U;
      
      uint32        APP_Camera2_VideoErrorFlags_pt1_1_b8         : 8U;
      
      uint32        APP_Camera2_VideoErrorFlags_pt1_2_b8         : 8U;
      
      uint32        APP_Camera2_VideoErrorFlags_pt1_3_b8         : 8U;
      
      uint32        APP_Camera2_VideoErrorFlags_pt1_4_b8         : 8U;
      
      uint32        APP_Camera3_VideoErrorFlags_pt1_1_b8         : 8U;
      
      uint32        APP_Camera3_VideoErrorFlags_pt1_2_b8         : 8U;
      
      uint32        APP_Camera3_VideoErrorFlags_pt1_3_b8         : 8U;
      
      uint32        APP_Camera3_VideoErrorFlags_pt1_4_b8         : 8U;
      
      uint32        APP_Brain_drops_counter_1_b8                 : 8U;
      
      uint32        APP_Brain_drops_counter_2_b8                 : 8U;
      
      uint32        APP_Brain_drops_counter_3_b8                 : 8U;
      
      uint32        APP_Brain_drops_counter_4_b8                 : 8U;
      
      uint32        APP_appMode_1_b8                             : 8U;
      
      uint32        APP_appMode_2_b8                             : 8U;
      
      uint32        APP_appMode_3_b8                             : 8U;
      
      uint32        APP_appMode_4_b8                             : 8U;
      
      uint32        APP_Application_ver_1_b8                     : 8U;
      
      uint32        APP_Application_ver_2_b8                     : 8U;
      
      uint32        APP_Application_ver_3_b8                     : 8U;
      
      uint32        APP_Application_ver_4_b8                     : 8U;
      
      uint32        App_RSRV_12_1_b8                             : 8U;
      
      uint32        App_RSRV_12_2_b8                             : 8U;
      
      uint32        App_RSRV_12_3_b8                             : 8U;
      
      uint32        App_RSRV_12_4_b8                             : 8U;
      
      uint32        App_RSRV_13_1_b8                             : 8U;
      
      uint32        App_RSRV_13_2_b8                             : 8U;
      
      uint32        App_RSRV_13_3_b8                             : 8U;
      
      uint32        App_RSRV_13_4_b8                             : 8U;
      
      uint32        APP_Camera1_VideoErrorFlags_pt2_1_b8         : 8U;
      
      uint32        APP_Camera1_VideoErrorFlags_pt2_2_b8         : 8U;
      
      uint32        APP_Camera1_VideoErrorFlags_pt2_3_b8         : 8U;
      
      uint32        APP_Camera1_VideoErrorFlags_pt2_4_b8         : 8U;
      
      uint32        APP_Camera2_VideoErrorFlags_pt2_1_b8         : 8U;
      
      uint32        APP_Camera2_VideoErrorFlags_pt2_2_b8         : 8U;
      
      uint32        APP_Camera2_VideoErrorFlags_pt2_3_b8         : 8U;
      
      uint32        APP_Camera2_VideoErrorFlags_pt2_4_b8         : 8U;
      
      uint32        APP_Camera3_VideoErrorFlags_pt2_1_b8         : 8U;
      
      uint32        APP_Camera3_VideoErrorFlags_pt2_2_b8         : 8U;
      
      uint32        APP_Camera3_VideoErrorFlags_pt2_3_b8         : 8U;
      
      uint32        APP_Camera3_VideoErrorFlags_pt2_4_b8         : 8U;
      
      uint32        APP_SPI_Bus_Load_Tx_1_b8                     : 8U;
      
      uint32        APP_SPI_Bus_Load_Tx_2_b8                     : 8U;
      
      uint32        APP_SPI_Bus_Load_Tx_3_b8                     : 8U;
      
      uint32        APP_SPI_Bus_Load_Tx_4_b8                     : 8U;
      
      uint32        APP_SPI_Bus_Load_Rx_1_b8                     : 8U;
      
      uint32        APP_SPI_Bus_Load_Rx_2_b8                     : 8U;
      
      uint32        APP_SPI_Bus_Load_Rx_3_b8                     : 8U;
      
      uint32        APP_SPI_Bus_Load_Rx_4_b8                     : 8U;
      
      uint32        APP_SPI_Retransmit_Tx_1_b8                   : 8U;
      
      uint32        APP_SPI_Retransmit_Tx_2_b8                   : 8U;
      
      uint32        APP_SPI_Retransmit_Tx_3_b8                   : 8U;
      
      uint32        APP_SPI_Retransmit_Tx_4_b8                   : 8U;
      
      uint32        App_RSRV_14_1_b8                             : 8U;
      
      uint32        App_RSRV_14_2_b8                             : 8U;
      
      uint32        App_RSRV_14_3_b8                             : 8U;
      
      uint32        App_RSRV_14_4_b8                             : 8U;
      
      uint32        App_CRC32_1_b8                               : 8U;
      
      uint32        App_CRC32_2_b8                               : 8U;
      
      uint32        App_CRC32_3_b8                               : 8U;
      
      uint32        App_CRC32_4_b8                               : 8U;
      
   #else
      uint32        APP_Zero_Byte_b8                             : 8U;
      
      uint32        Application_Message_Version_b8               : 8U;
      
      uint32        APP_Main_State_b8                            : 8U;
      
      uint32        APP_Sub_State_b8                             : 8U;
      
      uint32        APP_EyeQ_Process_Index_b32                   : 32U;
      
      uint32        APP_EyeQ_Timestamp_b32                       : 32U;
      
      uint32        APP_EyeQ_Current_Timestamp_b32               : 32U;
      
      uint32        APP_Diagnostics_part_1_b16                   : 16U;
      
      uint32        APP_Diagnostics_part_2_b16                   : 16U;
      
      uint32        APP_Fatal_Error_b8                           : 8U;
      
      uint32        App_RSRV_1_b8                                : 8U;
      
      uint32        APP_Minor_Error_b16                          : 16U;
      
      sint32        APP_EyeQTemperature1_sb16                    : 16;
      
      sint32        APP_EyeQTemperature2_sb16                    : 16;
      
      sint32        APP_Temperature_DDR_sb8                      : 8;
      
      uint32        App_RSRV_2_b8                                : 8U;
      
      uint32        App_RSRV_3_b16                               : 16U;
      
      uint32        App_RSRV_4_b8                                : 8U;
      
      uint32        APP_spiErrors_b8                             : 8U;
      
      uint32        APP_Valid_second_cam_temp_info_b8            : 8U;
      
      uint32        APP_Valid_cameras_information_b8             : 8U;
      
      sint32        APP_Camera1_temperature_1_sb8                : 8;
      
      sint32        APP_Camera2_temperature_1_sb8                : 8;
      
      sint32        APP_Camera3_temperature_1_sb8                : 8;
      
      sint32        APP_Camera1_temperature_2_sb8                : 8;
      
      sint32        APP_Camera2_temperature_2_sb8                : 8;
      
      sint32        APP_Camera3_temperature_2_sb8                : 8;
      
      sint32        App_RSRV_5_sb8                               : 8;
      
      sint32        App_RSRV_6_sb8                               : 8;
      
      uint32        APP_Camera1_VideoErrorRange_b8               : 8U;
      
      uint32        APP_Camera2_VideoErrorRange_b8               : 8U;
      
      uint32        APP_Camera3_VideoErrorRange_b8               : 8U;
      
      uint32        App_RSRV_7_b8                                : 8U;
      
      uint32        App_RSRV_8_b8                                : 8U;
      
      uint32        App_RSRV_9_b8                                : 8U;
      
      uint32        App_RSRV_10_b8                               : 8U;
      
      uint32        App_RSRV_11_b8                               : 8U;
      
      uint32        APP_Camera1_VideoErrorFlags_pt1_b32          : 32U;
      
      uint32        APP_Camera2_VideoErrorFlags_pt1_b32          : 32U;
      
      uint32        APP_Camera3_VideoErrorFlags_pt1_b32          : 32U;
      
      uint32        APP_Brain_drops_counter_b32                  : 32U;
      
      uint32        APP_appMode_b32                              : 32U;
      
      uint32        APP_Application_ver_b32                      : 32U;
      
      uint32        App_RSRV_12_b32                              : 32U;
      
      uint32        App_RSRV_13_b32                              : 32U;
      
      uint32        APP_Camera1_VideoErrorFlags_pt2_b32          : 32U;
      
      uint32        APP_Camera2_VideoErrorFlags_pt2_b32          : 32U;
      
      uint32        APP_Camera3_VideoErrorFlags_pt2_b32          : 32U;
      
      uint32        APP_SPI_Bus_Load_Tx_b32                      : 32U;
      
      uint32        APP_SPI_Bus_Load_Rx_b32                      : 32U;
      
      uint32        APP_SPI_Retransmit_Tx_b32                    : 32U;
      
      uint32        App_RSRV_14_b32                              : 32U;
      
      uint32        App_CRC32_b32                                : 32U;
      
   #endif
} EYEQMSG_APPMSG_Params_t;


/*****************************************************************************
                  Exported function prototypes
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_APPMSG_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_APPMSG_Params_t * pCore_Application_Message_protocol - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_Application_Message_protocol message 
*    Core_Application_Message_protocol message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_Application_Message_protocol message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_APPMSG_ParamsApp_MsgDataStruct( EYEQMSG_APPMSG_Params_t * pCore_Application_Message_protocol );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Zero_Byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pAPP_Zero_Byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Zero_Byte
*    APP_Zero_Byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Zero_Byte signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Zero_Byte( uint8 * pAPP_Zero_Byte );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_Application_Message_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pApplication_Message_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Application_Message_Version
*    Application_Message_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Application_Message_Version signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_Application_Message_Version( uint8 * pApplication_Message_Version );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Main_State
*
* FUNCTION ARGUMENTS:
*    uint8 * pAPP_Main_State - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Main_State
*    APP_Main_State returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Main_State signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Main_State( uint8 * pAPP_Main_State );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Sub_State
*
* FUNCTION ARGUMENTS:
*    uint8 * pAPP_Sub_State - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Sub_State
*    APP_Sub_State returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Sub_State signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Sub_State( uint8 * pAPP_Sub_State );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_EyeQ_Process_Index
*
* FUNCTION ARGUMENTS:
*    uint32 * pAPP_EyeQ_Process_Index - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_EyeQ_Process_Index
*    APP_EyeQ_Process_Index returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_EyeQ_Process_Index signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_EyeQ_Process_Index( uint32 * pAPP_EyeQ_Process_Index );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_EyeQ_Timestamp
*
* FUNCTION ARGUMENTS:
*    uint32 * pAPP_EyeQ_Timestamp - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_EyeQ_Timestamp
*    APP_EyeQ_Timestamp returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_EyeQ_Timestamp signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_EyeQ_Timestamp( uint32 * pAPP_EyeQ_Timestamp );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_EyeQ_Current_Timestamp
*
* FUNCTION ARGUMENTS:
*    uint32 * pAPP_EyeQ_Current_Timestamp - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_EyeQ_Current_Timestamp
*    APP_EyeQ_Current_Timestamp returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_EyeQ_Current_Timestamp signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_EyeQ_Current_Timestamp( uint32 * pAPP_EyeQ_Current_Timestamp );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Diagnostics_part_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pAPP_Diagnostics_part_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Diagnostics_part_1
*    APP_Diagnostics_part_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Diagnostics_part_1 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Diagnostics_part_1( uint16 * pAPP_Diagnostics_part_1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Diagnostics_part_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pAPP_Diagnostics_part_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Diagnostics_part_2
*    APP_Diagnostics_part_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Diagnostics_part_2 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Diagnostics_part_2( uint16 * pAPP_Diagnostics_part_2 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Fatal_Error
*
* FUNCTION ARGUMENTS:
*    APPMSGAPPFatalError * pAPP_Fatal_Error - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Fatal_Error
*    APP_Fatal_Error returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Fatal_Error signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Fatal_Error( APPMSGAPPFatalError * pAPP_Fatal_Error );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_App_RSRV_1
*
* FUNCTION ARGUMENTS:
*    uint8 * pApp_RSRV_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of App_RSRV_1
*    App_RSRV_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns App_RSRV_1 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_App_RSRV_1( uint8 * pApp_RSRV_1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Minor_Error
*
* FUNCTION ARGUMENTS:
*    APPMSGAPPMinorError * pAPP_Minor_Error - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Minor_Error
*    APP_Minor_Error returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Minor_Error signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Minor_Error( APPMSGAPPMinorError * pAPP_Minor_Error );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_EyeQTemperature1
*
* FUNCTION ARGUMENTS:
*    sint16 * pAPP_EyeQTemperature1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_EyeQTemperature1
*    APP_EyeQTemperature1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_EyeQTemperature1 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_EyeQTemperature1( sint16 * pAPP_EyeQTemperature1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_EyeQTemperature2
*
* FUNCTION ARGUMENTS:
*    sint16 * pAPP_EyeQTemperature2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_EyeQTemperature2
*    APP_EyeQTemperature2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_EyeQTemperature2 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_EyeQTemperature2( sint16 * pAPP_EyeQTemperature2 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Temperature_DDR
*
* FUNCTION ARGUMENTS:
*    APPMSGAPPTemperatureDDR * pAPP_Temperature_DDR - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Temperature_DDR
*    APP_Temperature_DDR returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Temperature_DDR signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Temperature_DDR( APPMSGAPPTemperatureDDR * pAPP_Temperature_DDR );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_App_RSRV_2
*
* FUNCTION ARGUMENTS:
*    uint8 * pApp_RSRV_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of App_RSRV_2
*    App_RSRV_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns App_RSRV_2 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_App_RSRV_2( uint8 * pApp_RSRV_2 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_App_RSRV_3
*
* FUNCTION ARGUMENTS:
*    uint16 * pApp_RSRV_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of App_RSRV_3
*    App_RSRV_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns App_RSRV_3 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_App_RSRV_3( uint16 * pApp_RSRV_3 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_App_RSRV_4
*
* FUNCTION ARGUMENTS:
*    uint8 * pApp_RSRV_4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of App_RSRV_4
*    App_RSRV_4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns App_RSRV_4 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_App_RSRV_4( uint8 * pApp_RSRV_4 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_spiErrors
*
* FUNCTION ARGUMENTS:
*    APPMSGAPPSpiErrors * pAPP_spiErrors - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_spiErrors
*    APP_spiErrors returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_spiErrors signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_spiErrors( APPMSGAPPSpiErrors * pAPP_spiErrors );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Valid_second_cam_temp_info
*
* FUNCTION ARGUMENTS:
*    APPMSGAPPValidSecondCamTempInfo * pAPP_Valid_second_cam_temp_info - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Valid_second_cam_temp_info
*    APP_Valid_second_cam_temp_info returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Valid_second_cam_temp_info signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Valid_second_cam_temp_info( APPMSGAPPValidSecondCamTempInfo * pAPP_Valid_second_cam_temp_info );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Valid_cameras_information
*
* FUNCTION ARGUMENTS:
*    APPMSGAPPValidCamerasInformation * pAPP_Valid_cameras_information - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Valid_cameras_information
*    APP_Valid_cameras_information returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Valid_cameras_information signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Valid_cameras_information( APPMSGAPPValidCamerasInformation * pAPP_Valid_cameras_information );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Camera1_temperature_1
*
* FUNCTION ARGUMENTS:
*    sint8 * pAPP_Camera1_temperature_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Camera1_temperature_1
*    APP_Camera1_temperature_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Camera1_temperature_1 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Camera1_temperature_1( sint8 * pAPP_Camera1_temperature_1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Camera2_temperature_1
*
* FUNCTION ARGUMENTS:
*    sint8 * pAPP_Camera2_temperature_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Camera2_temperature_1
*    APP_Camera2_temperature_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Camera2_temperature_1 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Camera2_temperature_1( sint8 * pAPP_Camera2_temperature_1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Camera3_temperature_1
*
* FUNCTION ARGUMENTS:
*    sint8 * pAPP_Camera3_temperature_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Camera3_temperature_1
*    APP_Camera3_temperature_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Camera3_temperature_1 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Camera3_temperature_1( sint8 * pAPP_Camera3_temperature_1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Camera1_temperature_2
*
* FUNCTION ARGUMENTS:
*    sint8 * pAPP_Camera1_temperature_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Camera1_temperature_2
*    APP_Camera1_temperature_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Camera1_temperature_2 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Camera1_temperature_2( sint8 * pAPP_Camera1_temperature_2 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Camera2_temperature_2
*
* FUNCTION ARGUMENTS:
*    sint8 * pAPP_Camera2_temperature_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Camera2_temperature_2
*    APP_Camera2_temperature_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Camera2_temperature_2 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Camera2_temperature_2( sint8 * pAPP_Camera2_temperature_2 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Camera3_temperature_2
*
* FUNCTION ARGUMENTS:
*    sint8 * pAPP_Camera3_temperature_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Camera3_temperature_2
*    APP_Camera3_temperature_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Camera3_temperature_2 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Camera3_temperature_2( sint8 * pAPP_Camera3_temperature_2 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_App_RSRV_5
*
* FUNCTION ARGUMENTS:
*    sint8 * pApp_RSRV_5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of App_RSRV_5
*    App_RSRV_5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns App_RSRV_5 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_App_RSRV_5( sint8 * pApp_RSRV_5 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_App_RSRV_6
*
* FUNCTION ARGUMENTS:
*    sint8 * pApp_RSRV_6 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of App_RSRV_6
*    App_RSRV_6 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns App_RSRV_6 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_App_RSRV_6( sint8 * pApp_RSRV_6 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Camera1_VideoErrorRange
*
* FUNCTION ARGUMENTS:
*    APPMSGAPPCamera1VideoErrorRange * pAPP_Camera1_VideoErrorRange - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Camera1_VideoErrorRange
*    APP_Camera1_VideoErrorRange returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Camera1_VideoErrorRange signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Camera1_VideoErrorRange( APPMSGAPPCamera1VideoErrorRange * pAPP_Camera1_VideoErrorRange );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Camera2_VideoErrorRange
*
* FUNCTION ARGUMENTS:
*    APPMSGAPPCamera2VideoErrorRange * pAPP_Camera2_VideoErrorRange - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Camera2_VideoErrorRange
*    APP_Camera2_VideoErrorRange returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Camera2_VideoErrorRange signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Camera2_VideoErrorRange( APPMSGAPPCamera2VideoErrorRange * pAPP_Camera2_VideoErrorRange );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Camera3_VideoErrorRange
*
* FUNCTION ARGUMENTS:
*    APPMSGAPPCamera3VideoErrorRange * pAPP_Camera3_VideoErrorRange - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Camera3_VideoErrorRange
*    APP_Camera3_VideoErrorRange returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Camera3_VideoErrorRange signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Camera3_VideoErrorRange( APPMSGAPPCamera3VideoErrorRange * pAPP_Camera3_VideoErrorRange );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_App_RSRV_7
*
* FUNCTION ARGUMENTS:
*    uint8 * pApp_RSRV_7 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of App_RSRV_7
*    App_RSRV_7 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns App_RSRV_7 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_App_RSRV_7( uint8 * pApp_RSRV_7 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_App_RSRV_8
*
* FUNCTION ARGUMENTS:
*    uint8 * pApp_RSRV_8 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of App_RSRV_8
*    App_RSRV_8 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns App_RSRV_8 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_App_RSRV_8( uint8 * pApp_RSRV_8 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_App_RSRV_9
*
* FUNCTION ARGUMENTS:
*    uint8 * pApp_RSRV_9 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of App_RSRV_9
*    App_RSRV_9 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns App_RSRV_9 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_App_RSRV_9( uint8 * pApp_RSRV_9 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_App_RSRV_10
*
* FUNCTION ARGUMENTS:
*    uint8 * pApp_RSRV_10 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of App_RSRV_10
*    App_RSRV_10 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns App_RSRV_10 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_App_RSRV_10( uint8 * pApp_RSRV_10 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_App_RSRV_11
*
* FUNCTION ARGUMENTS:
*    uint8 * pApp_RSRV_11 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of App_RSRV_11
*    App_RSRV_11 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns App_RSRV_11 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_App_RSRV_11( uint8 * pApp_RSRV_11 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Camera1_VideoErrorFlags_pt1
*
* FUNCTION ARGUMENTS:
*    uint32 * pAPP_Camera1_VideoErrorFlags_pt1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Camera1_VideoErrorFlags_pt1
*    APP_Camera1_VideoErrorFlags_pt1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Camera1_VideoErrorFlags_pt1 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Camera1_VideoErrorFlags_pt1( uint32 * pAPP_Camera1_VideoErrorFlags_pt1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Camera2_VideoErrorFlags_pt1
*
* FUNCTION ARGUMENTS:
*    uint32 * pAPP_Camera2_VideoErrorFlags_pt1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Camera2_VideoErrorFlags_pt1
*    APP_Camera2_VideoErrorFlags_pt1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Camera2_VideoErrorFlags_pt1 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Camera2_VideoErrorFlags_pt1( uint32 * pAPP_Camera2_VideoErrorFlags_pt1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Camera3_VideoErrorFlags_pt1
*
* FUNCTION ARGUMENTS:
*    uint32 * pAPP_Camera3_VideoErrorFlags_pt1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Camera3_VideoErrorFlags_pt1
*    APP_Camera3_VideoErrorFlags_pt1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Camera3_VideoErrorFlags_pt1 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Camera3_VideoErrorFlags_pt1( uint32 * pAPP_Camera3_VideoErrorFlags_pt1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Brain_drops_counter
*
* FUNCTION ARGUMENTS:
*    uint32 * pAPP_Brain_drops_counter - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Brain_drops_counter
*    APP_Brain_drops_counter returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Brain_drops_counter signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Brain_drops_counter( uint32 * pAPP_Brain_drops_counter );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_appMode
*
* FUNCTION ARGUMENTS:
*    uint32 * pAPP_appMode - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_appMode
*    APP_appMode returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_appMode signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_appMode( uint32 * pAPP_appMode );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Application_ver
*
* FUNCTION ARGUMENTS:
*    uint32 * pAPP_Application_ver - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Application_ver
*    APP_Application_ver returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Application_ver signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Application_ver( uint32 * pAPP_Application_ver );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_App_RSRV_12
*
* FUNCTION ARGUMENTS:
*    uint32 * pApp_RSRV_12 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of App_RSRV_12
*    App_RSRV_12 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns App_RSRV_12 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_App_RSRV_12( uint32 * pApp_RSRV_12 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_App_RSRV_13
*
* FUNCTION ARGUMENTS:
*    uint32 * pApp_RSRV_13 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of App_RSRV_13
*    App_RSRV_13 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns App_RSRV_13 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_App_RSRV_13( uint32 * pApp_RSRV_13 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Camera1_VideoErrorFlags_pt2
*
* FUNCTION ARGUMENTS:
*    uint32 * pAPP_Camera1_VideoErrorFlags_pt2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Camera1_VideoErrorFlags_pt2
*    APP_Camera1_VideoErrorFlags_pt2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Camera1_VideoErrorFlags_pt2 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Camera1_VideoErrorFlags_pt2( uint32 * pAPP_Camera1_VideoErrorFlags_pt2 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Camera2_VideoErrorFlags_pt2
*
* FUNCTION ARGUMENTS:
*    uint32 * pAPP_Camera2_VideoErrorFlags_pt2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Camera2_VideoErrorFlags_pt2
*    APP_Camera2_VideoErrorFlags_pt2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Camera2_VideoErrorFlags_pt2 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Camera2_VideoErrorFlags_pt2( uint32 * pAPP_Camera2_VideoErrorFlags_pt2 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_Camera3_VideoErrorFlags_pt2
*
* FUNCTION ARGUMENTS:
*    uint32 * pAPP_Camera3_VideoErrorFlags_pt2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_Camera3_VideoErrorFlags_pt2
*    APP_Camera3_VideoErrorFlags_pt2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_Camera3_VideoErrorFlags_pt2 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_Camera3_VideoErrorFlags_pt2( uint32 * pAPP_Camera3_VideoErrorFlags_pt2 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_SPI_Bus_Load_Tx
*
* FUNCTION ARGUMENTS:
*    uint32 * pAPP_SPI_Bus_Load_Tx - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_SPI_Bus_Load_Tx
*    APP_SPI_Bus_Load_Tx returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_SPI_Bus_Load_Tx signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_SPI_Bus_Load_Tx( uint32 * pAPP_SPI_Bus_Load_Tx );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_SPI_Bus_Load_Rx
*
* FUNCTION ARGUMENTS:
*    uint32 * pAPP_SPI_Bus_Load_Rx - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_SPI_Bus_Load_Rx
*    APP_SPI_Bus_Load_Rx returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_SPI_Bus_Load_Rx signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_SPI_Bus_Load_Rx( uint32 * pAPP_SPI_Bus_Load_Rx );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_APP_SPI_Retransmit_Tx
*
* FUNCTION ARGUMENTS:
*    uint32 * pAPP_SPI_Retransmit_Tx - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of APP_SPI_Retransmit_Tx
*    APP_SPI_Retransmit_Tx returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns APP_SPI_Retransmit_Tx signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_APP_SPI_Retransmit_Tx( uint32 * pAPP_SPI_Retransmit_Tx );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_App_RSRV_14
*
* FUNCTION ARGUMENTS:
*    uint32 * pApp_RSRV_14 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of App_RSRV_14
*    App_RSRV_14 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns App_RSRV_14 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_App_RSRV_14( uint32 * pApp_RSRV_14 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_APPMSG_App_CRC32
*
* FUNCTION ARGUMENTS:
*    uint32 * pApp_CRC32 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of App_CRC32
*    App_CRC32 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns App_CRC32 signal value of Core_Application_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_APPMSG_App_CRC32( uint32 * pApp_CRC32 );
/*****************************************************************************
                  Exported object declarations
*****************************************************************************/
extern EYEQMSG_APPMSG_Params_t   EYEQMSG_APPMSG_Params_s;
extern EYEQMSG_APPMSG_Params_t   EYEQMSG_APPMSG_ParamsApp_s;
/****************************************************************************/
#endif /* _EYEQMSG_APPMSGPROCESS_H_ */


