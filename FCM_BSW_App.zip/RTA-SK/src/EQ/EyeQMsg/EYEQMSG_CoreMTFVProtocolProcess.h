#ifndef _EYEQMSG_COREMTFVPROTOCOLPROCESS_H_
#define _EYEQMSG_COREMTFVPROTOCOLPROCESS_H_

/*****************************************************************************
                  Included header files
*****************************************************************************/
#include <Std_Types.h>

/*****************************************************************************
                  Include files
*****************************************************************************/
/*****************************************************************************
                  Exported symbolic constants
*****************************************************************************/
#define C_EYEQMSG_COREMTFVvH_VIRTUAL_OBJECT_INDEX_RMAX ( 13U )

/* Datagram message ID */
#define C_EYEQMSG_COREMTFVvH_MSG_ID                           ( 0xDFU )
#define C_EYEQMSG_COREMTFVvO_MSG_ID                           ( 0xDFU )
#define C_EYEQMSG_COREMTFV_MSG_ID                             ( 0xDFU )

/* Datagram message lengths */
#define C_EYEQMSG_COREMTFVvH_MSG_LEN                          ( sizeof(EYEQMSG_COREMTFVvH_Params_t) )
#define C_EYEQMSG_COREMTFVvO_MSG_LEN                          ( sizeof(EYEQMSG_COREMTFVvO_Params_t) )
#define C_EYEQMSG_COREMTFV_MSG_LEN                            ( sizeof(EYEQMSG_COREMTFV_Params_t) )

/* Protocol ENUMs */

/* MCU output messages */

/* Virtual_HEADER_msg_Core_MTFV_protocol Enums */
/* Reserved_2_b12 signal Min & Max range limits */
#define C_EYEQMSG_COREMTFVvH_RESERVED_2_RMIN                  ( 0U )
#define C_EYEQMSG_COREMTFVvH_RESERVED_2_RMAX                  ( 0U )
#define C_EYEQMSG_COREMTFVvH_RESERVED_2_NUMR                  ( 1U )
#define C_EYEQMSG_COREMTFVvH_RESERVED_2_DEMNR                 ( 1U )
#define C_EYEQMSG_COREMTFVvH_RESERVED_2_OFFSET                ( 0U )

/* MTFV_Num_Saturated_Pixels_b5 signal Min & Max range limits */
#define C_EYEQMSG_COREMTFVvH_MTFV_NUM_SATURATED_PIXELS_RMIN   ( 0U )
#define C_EYEQMSG_COREMTFVvH_MTFV_NUM_SATURATED_PIXELS_RMAX   ( 31U )
#define C_EYEQMSG_COREMTFVvH_MTFV_NUM_SATURATED_PIXELS_NUMR   ( 1U )
#define C_EYEQMSG_COREMTFVvH_MTFV_NUM_SATURATED_PIXELS_DEMNR  ( 1U )
#define C_EYEQMSG_COREMTFVvH_MTFV_NUM_SATURATED_PIXELS_OFFSET ( 0U )

/* MTFV_Average_Image_Intensity_b12 signal Min & Max range limits */
#define C_EYEQMSG_COREMTFVvH_MTFV_AVERAGE_IMAGE_INTENSITY_RMIN ( 0U )
#define C_EYEQMSG_COREMTFVvH_MTFV_AVERAGE_IMAGE_INTENSITY_RMAX ( 4095U )
#define C_EYEQMSG_COREMTFVvH_MTFV_AVERAGE_IMAGE_INTENSITY_NUMR ( 1U )
#define C_EYEQMSG_COREMTFVvH_MTFV_AVERAGE_IMAGE_INTENSITY_DEMNR ( 1U )
#define C_EYEQMSG_COREMTFVvH_MTFV_AVERAGE_IMAGE_INTENSITY_OFFSET ( 0U )

/* MTFV_Camera_Source_b3 signal Enums */
typedef uint8 COREMTFVvHMTFVCameraSource;
#define C_EYEQMSG_COREMTFVvH_MTFV_CAMERA_SOURCE_FRONT_MAIN    ( COREMTFVvHMTFVCameraSource ) ( 0U )
#define C_EYEQMSG_COREMTFVvH_MTFV_CAMERA_SOURCE_FRONT_NARROW  ( COREMTFVvHMTFVCameraSource ) ( 1U )
#define C_EYEQMSG_COREMTFVvH_MTFV_CAMERA_SOURCE_FRONT_FISHEYE ( COREMTFVvHMTFVCameraSource ) ( 2U )

/* MTFV_Camera_Source_b3 signal Min & Max range limits */
#define C_EYEQMSG_COREMTFVvH_MTFV_CAMERA_SOURCE_RMIN          ( 0U )
#define C_EYEQMSG_COREMTFVvH_MTFV_CAMERA_SOURCE_RMAX          ( 2U )
#define C_EYEQMSG_COREMTFVvH_MTFV_CAMERA_SOURCE_NUMR          ( 1U )
#define C_EYEQMSG_COREMTFVvH_MTFV_CAMERA_SOURCE_DEMNR         ( 1U )
#define C_EYEQMSG_COREMTFVvH_MTFV_CAMERA_SOURCE_OFFSET        ( 0U )

/* Reserved_1_b1 signal Min & Max range limits */
#define C_EYEQMSG_COREMTFVvH_RESERVED_1_RMIN                  ( 0U )
#define C_EYEQMSG_COREMTFVvH_RESERVED_1_RMAX                  ( 0U )
#define C_EYEQMSG_COREMTFVvH_RESERVED_1_NUMR                  ( 1U )
#define C_EYEQMSG_COREMTFVvH_RESERVED_1_DEMNR                 ( 1U )
#define C_EYEQMSG_COREMTFVvH_RESERVED_1_OFFSET                ( 0U )

/* MTFV_Status_b3 signal Enums */
typedef uint8 COREMTFVvHMTFVStatus;
#define C_EYEQMSG_COREMTFVvH_MTFV_STATUS_UNINITIALIZED        ( COREMTFVvHMTFVStatus ) ( 0U )
#define C_EYEQMSG_COREMTFVvH_MTFV_STATUS_RESERVED_2           ( COREMTFVvHMTFVStatus ) ( 1U )
#define C_EYEQMSG_COREMTFVvH_MTFV_STATUS_RESERVED_1           ( COREMTFVvHMTFVStatus ) ( 2U )
#define C_EYEQMSG_COREMTFVvH_MTFV_STATUS_RAN_SUCCESSFULLY     ( COREMTFVvHMTFVStatus ) ( 3U )
#define C_EYEQMSG_COREMTFVvH_MTFV_STATUS_RUNNING_FAILED       ( COREMTFVvHMTFVStatus ) ( 4U )

/* MTFV_Status_b3 signal Min & Max range limits */
#define C_EYEQMSG_COREMTFVvH_MTFV_STATUS_RMIN                 ( 0U )
#define C_EYEQMSG_COREMTFVvH_MTFV_STATUS_RMAX                 ( 4U )
#define C_EYEQMSG_COREMTFVvH_MTFV_STATUS_NUMR                 ( 1U )
#define C_EYEQMSG_COREMTFVvH_MTFV_STATUS_DEMNR                ( 1U )
#define C_EYEQMSG_COREMTFVvH_MTFV_STATUS_OFFSET               ( 0U )

/* MTFV_Number_of_points_b4 signal Min & Max range limits */
#define C_EYEQMSG_COREMTFVvH_MTFV_NUMBER_OF_POINTS_RMIN       ( 0U )
#define C_EYEQMSG_COREMTFVvH_MTFV_NUMBER_OF_POINTS_RMAX       ( 13U )
#define C_EYEQMSG_COREMTFVvH_MTFV_NUMBER_OF_POINTS_NUMR       ( 1U )
#define C_EYEQMSG_COREMTFVvH_MTFV_NUMBER_OF_POINTS_DEMNR      ( 1U )
#define C_EYEQMSG_COREMTFVvH_MTFV_NUMBER_OF_POINTS_OFFSET     ( 0U )

/* MTFV_Sync_ID_b8 signal Min & Max range limits */
#define C_EYEQMSG_COREMTFVvH_MTFV_SYNC_ID_RMIN                ( 0U )
#define C_EYEQMSG_COREMTFVvH_MTFV_SYNC_ID_RMAX                ( 255U )
#define C_EYEQMSG_COREMTFVvH_MTFV_SYNC_ID_NUMR                ( 1U )
#define C_EYEQMSG_COREMTFVvH_MTFV_SYNC_ID_DEMNR               ( 1U )
#define C_EYEQMSG_COREMTFVvH_MTFV_SYNC_ID_OFFSET              ( 0U )

/* MTFV_Protocol_Version_b8 signal Min & Max range limits */
#define C_EYEQMSG_COREMTFVvH_MTFV_PROTOCOL_VERSION_RMIN       ( 1U )
#define C_EYEQMSG_COREMTFVvH_MTFV_PROTOCOL_VERSION_RMAX       ( 1U )
#define C_EYEQMSG_COREMTFVvH_MTFV_PROTOCOL_VERSION_NUMR       ( 1U )
#define C_EYEQMSG_COREMTFVvH_MTFV_PROTOCOL_VERSION_DEMNR      ( 1U )
#define C_EYEQMSG_COREMTFVvH_MTFV_PROTOCOL_VERSION_OFFSET     ( 0U )

/* MTFV_Zero_byte_b8 signal Min & Max range limits */
#define C_EYEQMSG_COREMTFVvH_MTFV_ZERO_BYTE_RMIN              ( 0U )
#define C_EYEQMSG_COREMTFVvH_MTFV_ZERO_BYTE_RMAX              ( 255U )
#define C_EYEQMSG_COREMTFVvH_MTFV_ZERO_BYTE_NUMR              ( 1U )
#define C_EYEQMSG_COREMTFVvH_MTFV_ZERO_BYTE_DEMNR             ( 1U )
#define C_EYEQMSG_COREMTFVvH_MTFV_ZERO_BYTE_OFFSET            ( 0U )


/* Virtual_OBJECT_msg_Core_MTFV_protocol Enums */
/* MTFV_Point_Status_0_b2 signal Enums */
typedef uint8 COREMTFVvOMTFVPointStatus0;
#define C_EYEQMSG_COREMTFVvO_MTFV_POINT_STATUS_0_TARGET_OK    ( COREMTFVvOMTFVPointStatus0 ) ( 0U )
#define C_EYEQMSG_COREMTFVvO_MTFV_POINT_STATUS_0_TARGET_NOK   ( COREMTFVvOMTFVPointStatus0 ) ( 1U )
#define C_EYEQMSG_COREMTFVvO_MTFV_POINT_STATUS_0_RESERVED     ( COREMTFVvOMTFVPointStatus0 ) ( 2U )

/* MTFV_Point_Status_0_b2 signal Min & Max range limits */
#define C_EYEQMSG_COREMTFVvO_MTFV_POINT_STATUS_0_RMIN         ( 0U )
#define C_EYEQMSG_COREMTFVvO_MTFV_POINT_STATUS_0_RMAX         ( 2U )
#define C_EYEQMSG_COREMTFVvO_MTFV_POINT_STATUS_0_NUMR         ( 1U )
#define C_EYEQMSG_COREMTFVvO_MTFV_POINT_STATUS_0_DEMNR        ( 1U )
#define C_EYEQMSG_COREMTFVvO_MTFV_POINT_STATUS_0_OFFSET       ( 0U )

/* MTFV_Point_Value_0_b8 signal Min & Max range limits */
#define C_EYEQMSG_COREMTFVvO_MTFV_POINT_VALUE_0_RMIN          ( 0U )
#define C_EYEQMSG_COREMTFVvO_MTFV_POINT_VALUE_0_RMAX          ( 255U )
#define C_EYEQMSG_COREMTFVvO_MTFV_POINT_VALUE_0_NUMR          ( 1U )
#define C_EYEQMSG_COREMTFVvO_MTFV_POINT_VALUE_0_DEMNR         ( 256U )
#define C_EYEQMSG_COREMTFVvO_MTFV_POINT_VALUE_0_OFFSET        ( 0U )

/* MTFV_Point_TargetCenter_Y_0_b11 signal Min & Max range limits */
#define C_EYEQMSG_COREMTFVvO_MTFV_POINT_TARGETCENTER_Y_0_RMIN ( 0U )
#define C_EYEQMSG_COREMTFVvO_MTFV_POINT_TARGETCENTER_Y_0_RMAX ( 1079U )
#define C_EYEQMSG_COREMTFVvO_MTFV_POINT_TARGETCENTER_Y_0_NUMR ( 1U )
#define C_EYEQMSG_COREMTFVvO_MTFV_POINT_TARGETCENTER_Y_0_DEMNR ( 1U )
#define C_EYEQMSG_COREMTFVvO_MTFV_POINT_TARGETCENTER_Y_0_OFFSET ( 0U )

/* MTFV_Point_TargetCenter_X_0_b11 signal Min & Max range limits */
#define C_EYEQMSG_COREMTFVvO_MTFV_POINT_TARGETCENTER_X_0_RMIN ( 0U )
#define C_EYEQMSG_COREMTFVvO_MTFV_POINT_TARGETCENTER_X_0_RMAX ( 1824U )
#define C_EYEQMSG_COREMTFVvO_MTFV_POINT_TARGETCENTER_X_0_NUMR ( 1U )
#define C_EYEQMSG_COREMTFVvO_MTFV_POINT_TARGETCENTER_X_0_DEMNR ( 1U )
#define C_EYEQMSG_COREMTFVvO_MTFV_POINT_TARGETCENTER_X_0_OFFSET ( 0U )


/*****************************************************************************
                  Exported function-like macros
*****************************************************************************/
/*****************************************************************************
                  Exported defined macros
*****************************************************************************/
/*****************************************************************************
                  Exported types, enums definitions
*****************************************************************************/
typedef struct
{
   #if ENABLE_BIG_ENDIAN_FORMAT
      uint32        MTFV_Zero_byte_b8                            : 8U;
      
      uint32        MTFV_Protocol_Version_b8                     : 8U;
      
      uint32        MTFV_Sync_ID_b8                              : 8U;
      
      uint32        unused1_b4                                   : 4;
      uint32        MTFV_Number_of_points_b4                     : 4U;
      
      uint32        MTFV_Status_b3                               : 3U;
      
      uint32        Reserved_1_b1                                : 1U;
      
      uint32        unused2_b1                                   : 1;
      uint32        MTFV_Camera_Source_b3                        : 3U;
      
      uint32        MTFV_Average_Image_Intensity_1_b5            : 5U;
      
      uint32        MTFV_Average_Image_Intensity_2_b7            : 7U;
      
      uint32        MTFV_Num_Saturated_Pixels_1_b1               : 1U;
      
      uint32        MTFV_Num_Saturated_Pixels_2_b4               : 4U;
      
      uint32        Reserved_2_1_b4                              : 4U;
      
      uint32        Reserved_2_2_b8                              : 8U;
      
   #else
      uint32        MTFV_Zero_byte_b8                            : 8U;
      
      uint32        MTFV_Protocol_Version_b8                     : 8U;
      
      uint32        MTFV_Sync_ID_b8                              : 8U;
      
      uint32        MTFV_Number_of_points_b4                     : 4U;
      
      uint32        MTFV_Status_b3                               : 3U;
      
      uint32        Reserved_1_b1                                : 1U;
      
      uint32        MTFV_Camera_Source_b3                        : 3U;
      
      uint32        MTFV_Average_Image_Intensity_b12             : 12U;
      
      uint32        MTFV_Num_Saturated_Pixels_b5                 : 5U;
      
      uint32        Reserved_2_b12                               : 12U;
      
   #endif
} EYEQMSG_COREMTFVvH_Params_t;


typedef struct
{
   #if ENABLE_BIG_ENDIAN_FORMAT
      uint32        unused1_b64                                  : 64;
      uint32        MTFV_Point_TargetCenter_X_0_1_b8             : 8U;
      
      uint32        unused2_b5                                   : 5;
      uint32        MTFV_Point_TargetCenter_X_0_2_b3             : 3U;
      
      uint32        MTFV_Point_TargetCenter_Y_0_1_b5             : 5U;
      
      uint32        MTFV_Point_TargetCenter_Y_0_2_b6             : 6U;
      
      uint32        MTFV_Point_Value_0_1_b2                      : 2U;
      
      uint32        MTFV_Point_Value_0_2_b6                      : 6U;
      
      uint32        MTFV_Point_Status_0_b2                       : 2U;
      
   #else
      uint32        MTFV_Point_TargetCenter_X_0_b11              : 11U;
      
      uint32        MTFV_Point_TargetCenter_Y_0_b11              : 11U;
      
      uint32        MTFV_Point_Value_0_b8                        : 8U;
      
      uint32        MTFV_Point_Status_0_b2                       : 2U;
      
   #endif
} EYEQMSG_COREMTFVvO_Params_t;


typedef struct
{
   EYEQMSG_COREMTFVvH_Params_t EYEQMSG_COREMTFVvH_Params_s;
   EYEQMSG_COREMTFVvO_Params_t EYEQMSG_COREMTFVvO_Params_as[C_EYEQMSG_COREMTFVvH_VIRTUAL_OBJECT_INDEX_RMAX];
} EYEQMSG_COREMTFV_Params_t;


/*****************************************************************************
                  Exported function prototypes
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREMTFVvH_MTFV_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pMTFV_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MTFV_Zero_byte
*    MTFV_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MTFV_Zero_byte signal value of Virtual_HEADER_msg_Core_MTFV_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREMTFVvH_MTFV_Zero_byte( uint8 * pMTFV_Zero_byte );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREMTFVvH_MTFV_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pMTFV_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MTFV_Protocol_Version
*    MTFV_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MTFV_Protocol_Version signal value of Virtual_HEADER_msg_Core_MTFV_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREMTFVvH_MTFV_Protocol_Version( uint8 * pMTFV_Protocol_Version );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREMTFVvH_MTFV_Sync_ID
*
* FUNCTION ARGUMENTS:
*    uint8 * pMTFV_Sync_ID - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MTFV_Sync_ID
*    MTFV_Sync_ID returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MTFV_Sync_ID signal value of Virtual_HEADER_msg_Core_MTFV_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREMTFVvH_MTFV_Sync_ID( uint8 * pMTFV_Sync_ID );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREMTFVvH_MTFV_Number_of_points
*
* FUNCTION ARGUMENTS:
*    uint8 * pMTFV_Number_of_points - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MTFV_Number_of_points
*    MTFV_Number_of_points returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MTFV_Number_of_points signal value of Virtual_HEADER_msg_Core_MTFV_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREMTFVvH_MTFV_Number_of_points( uint8 * pMTFV_Number_of_points );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREMTFVvH_MTFV_Status
*
* FUNCTION ARGUMENTS:
*    COREMTFVvHMTFVStatus * pMTFV_Status - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MTFV_Status
*    MTFV_Status returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MTFV_Status signal value of Virtual_HEADER_msg_Core_MTFV_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREMTFVvH_MTFV_Status( COREMTFVvHMTFVStatus * pMTFV_Status );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREMTFVvH_Reserved_1
*
* FUNCTION ARGUMENTS:
*    boolean * pReserved_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1
*    Reserved_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1 signal value of Virtual_HEADER_msg_Core_MTFV_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREMTFVvH_Reserved_1( boolean * pReserved_1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREMTFVvH_MTFV_Camera_Source
*
* FUNCTION ARGUMENTS:
*    COREMTFVvHMTFVCameraSource * pMTFV_Camera_Source - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MTFV_Camera_Source
*    MTFV_Camera_Source returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MTFV_Camera_Source signal value of Virtual_HEADER_msg_Core_MTFV_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREMTFVvH_MTFV_Camera_Source( COREMTFVvHMTFVCameraSource * pMTFV_Camera_Source );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREMTFVvH_MTFV_Average_Image_Intensity
*
* FUNCTION ARGUMENTS:
*    uint16 * pMTFV_Average_Image_Intensity - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MTFV_Average_Image_Intensity
*    MTFV_Average_Image_Intensity returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MTFV_Average_Image_Intensity signal value of Virtual_HEADER_msg_Core_MTFV_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREMTFVvH_MTFV_Average_Image_Intensity( uint16 * pMTFV_Average_Image_Intensity );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREMTFVvH_MTFV_Num_Saturated_Pixels
*
* FUNCTION ARGUMENTS:
*    uint8 * pMTFV_Num_Saturated_Pixels - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MTFV_Num_Saturated_Pixels
*    MTFV_Num_Saturated_Pixels returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MTFV_Num_Saturated_Pixels signal value of Virtual_HEADER_msg_Core_MTFV_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREMTFVvH_MTFV_Num_Saturated_Pixels( uint8 * pMTFV_Num_Saturated_Pixels );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREMTFVvH_Reserved_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pReserved_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_2
*    Reserved_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_2 signal value of Virtual_HEADER_msg_Core_MTFV_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREMTFVvH_Reserved_2( uint16 * pReserved_2 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREMTFVvO_MTFV_Point_TargetCenter_X_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pMTFV_Point_TargetCenter_X_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MTFV_Point_TargetCenter_X_0
*    MTFV_Point_TargetCenter_X_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MTFV_Point_TargetCenter_X_0 signal value of Virtual_OBJECT_msg_Core_MTFV_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREMTFVvO_MTFV_Point_TargetCenter_X_0( uint8 objIndx_u8, uint16 * pMTFV_Point_TargetCenter_X_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREMTFVvO_MTFV_Point_TargetCenter_Y_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pMTFV_Point_TargetCenter_Y_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MTFV_Point_TargetCenter_Y_0
*    MTFV_Point_TargetCenter_Y_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MTFV_Point_TargetCenter_Y_0 signal value of Virtual_OBJECT_msg_Core_MTFV_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREMTFVvO_MTFV_Point_TargetCenter_Y_0( uint8 objIndx_u8, uint16 * pMTFV_Point_TargetCenter_Y_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREMTFVvO_MTFV_Point_Value_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pMTFV_Point_Value_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MTFV_Point_Value_0
*    MTFV_Point_Value_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MTFV_Point_Value_0 signal value of Virtual_OBJECT_msg_Core_MTFV_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREMTFVvO_MTFV_Point_Value_0( uint8 objIndx_u8, uint8 * pMTFV_Point_Value_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREMTFVvO_MTFV_Point_Status_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREMTFVvOMTFVPointStatus0 * pMTFV_Point_Status_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of MTFV_Point_Status_0
*    MTFV_Point_Status_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns MTFV_Point_Status_0 signal value of Virtual_OBJECT_msg_Core_MTFV_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREMTFVvO_MTFV_Point_Status_0( uint8 objIndx_u8, COREMTFVvOMTFVPointStatus0 * pMTFV_Point_Status_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_COREMTFV_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_COREMTFV_Params_t * pCore_MTFV_protocol - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_MTFV_protocol message 
*    Core_MTFV_protocol message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_MTFV_protocol message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_COREMTFV_ParamsApp_MsgDataStruct( EYEQMSG_COREMTFV_Params_t * pCore_MTFV_protocol );
/*****************************************************************************
                  Exported object declarations
*****************************************************************************/
extern EYEQMSG_COREMTFV_Params_t   EYEQMSG_COREMTFV_Params_s;
extern EYEQMSG_COREMTFV_Params_t   EYEQMSG_COREMTFV_ParamsApp_s;
/****************************************************************************/
#endif /* _EYEQMSG_COREMTFVPROTOCOLPROCESS_H_ */


