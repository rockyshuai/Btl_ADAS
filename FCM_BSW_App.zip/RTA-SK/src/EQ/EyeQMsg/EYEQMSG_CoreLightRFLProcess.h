#ifndef _EYEQMSG_CORELIGHTRFLPROCESS_H_
#define _EYEQMSG_CORELIGHTRFLPROCESS_H_

/*****************************************************************************
                  Included header files
*****************************************************************************/
#include <Std_Types.h>

/*****************************************************************************
                  Include files
*****************************************************************************/
/*****************************************************************************
                  Exported symbolic constants
*****************************************************************************/
#define C_EYEQMSG_CORELIGHTRFLvH_VIRTUAL_OBJECT_INDEX_RMAX ( 15U )

/* Datagram message ID */
#define C_EYEQMSG_CORELIGHTRFLvH_MSG_ID                       ( 0x7EU )
#define C_EYEQMSG_CORELIGHTRFLvO_MSG_ID                       ( 0x7EU )
#define C_EYEQMSG_CORELIGHTRFL_MSG_ID                         ( 0x7EU )

/* Datagram message lengths */
#define C_EYEQMSG_CORELIGHTRFLvH_MSG_LEN                      ( sizeof(EYEQMSG_CORELIGHTRFLvH_Params_t) )
#define C_EYEQMSG_CORELIGHTRFLvO_MSG_LEN                      ( sizeof(EYEQMSG_CORELIGHTRFLvO_Params_t) )
#define C_EYEQMSG_CORELIGHTRFL_MSG_LEN                        ( sizeof(EYEQMSG_CORELIGHTRFL_Params_t) )

/* Protocol ENUMs */

/* MCU output messages */

/* Virtual_HEADER_msg_Core_Light_Scene_RFL_protocol Enums */
/* LSR_Strong_Reflectors_Count_b4 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTRFLvH_LSR_STRONG_REFLECTORS_COUNT_RMIN ( 0U )
#define C_EYEQMSG_CORELIGHTRFLvH_LSR_STRONG_REFLECTORS_COUNT_RMAX ( 15U )
#define C_EYEQMSG_CORELIGHTRFLvH_LSR_STRONG_REFLECTORS_COUNT_NUMR ( 1U )
#define C_EYEQMSG_CORELIGHTRFLvH_LSR_STRONG_REFLECTORS_COUNT_DEMNR ( 1U )
#define C_EYEQMSG_CORELIGHTRFLvH_LSR_STRONG_REFLECTORS_COUNT_OFFSET ( 0U )

/* LSR_Inactive_Reason_b3 signal Enums */
typedef uint8 CORELIGHTRFLvHLSRInactiveReason;
#define C_EYEQMSG_CORELIGHTRFLvH_LSR_INACTIVE_REASON_INVALID_REASON ( CORELIGHTRFLvHLSRInactiveReason ) ( 0U )
#define C_EYEQMSG_CORELIGHTRFLvH_LSR_INACTIVE_REASON_OBVIOUSLY_BRIGHT ( CORELIGHTRFLvHLSRInactiveReason ) ( 1U )
#define C_EYEQMSG_CORELIGHTRFLvH_LSR_INACTIVE_REASON_LOW_DETECTION_RATE ( CORELIGHTRFLvHLSRInactiveReason ) ( 2U )
#define C_EYEQMSG_CORELIGHTRFLvH_LSR_INACTIVE_REASON_OVER_FLOW ( CORELIGHTRFLvHLSRInactiveReason ) ( 3U )
#define C_EYEQMSG_CORELIGHTRFLvH_LSR_INACTIVE_REASON_IN_GRACE ( CORELIGHTRFLvHLSRInactiveReason ) ( 4U )
#define C_EYEQMSG_CORELIGHTRFLvH_LSR_INACTIVE_REASON_DEACTIVATED ( CORELIGHTRFLvHLSRInactiveReason ) ( 5U )
#define C_EYEQMSG_CORELIGHTRFLvH_LSR_INACTIVE_REASON_DUSK_DELAY ( CORELIGHTRFLvHLSRInactiveReason ) ( 6U )

/* LSR_Inactive_Reason_b3 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTRFLvH_LSR_INACTIVE_REASON_RMIN     ( 0U )
#define C_EYEQMSG_CORELIGHTRFLvH_LSR_INACTIVE_REASON_RMAX     ( 6U )
#define C_EYEQMSG_CORELIGHTRFLvH_LSR_INACTIVE_REASON_NUMR     ( 1U )
#define C_EYEQMSG_CORELIGHTRFLvH_LSR_INACTIVE_REASON_DEMNR    ( 1U )
#define C_EYEQMSG_CORELIGHTRFLvH_LSR_INACTIVE_REASON_OFFSET   ( 0U )

/* LSR_Running_Mode_b2 signal Enums */
typedef uint8 CORELIGHTRFLvHLSRRunningMode;
#define C_EYEQMSG_CORELIGHTRFLvH_LSR_RUNNING_MODE_INVALID_MODE ( CORELIGHTRFLvHLSRRunningMode ) ( 0U )
#define C_EYEQMSG_CORELIGHTRFLvH_LSR_RUNNING_MODE_LS_OFF      ( CORELIGHTRFLvHLSRRunningMode ) ( 1U )
#define C_EYEQMSG_CORELIGHTRFLvH_LSR_RUNNING_MODE_LS_INACTIVE ( CORELIGHTRFLvHLSRRunningMode ) ( 2U )
#define C_EYEQMSG_CORELIGHTRFLvH_LSR_RUNNING_MODE_LS_FULL     ( CORELIGHTRFLvHLSRRunningMode ) ( 3U )

/* LSR_Running_Mode_b2 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTRFLvH_LSR_RUNNING_MODE_RMIN        ( 0U )
#define C_EYEQMSG_CORELIGHTRFLvH_LSR_RUNNING_MODE_RMAX        ( 3U )
#define C_EYEQMSG_CORELIGHTRFLvH_LSR_RUNNING_MODE_NUMR        ( 1U )
#define C_EYEQMSG_CORELIGHTRFLvH_LSR_RUNNING_MODE_DEMNR       ( 1U )
#define C_EYEQMSG_CORELIGHTRFLvH_LSR_RUNNING_MODE_OFFSET      ( 0U )

/* LSR_Sync_ID_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTRFLvH_LSR_SYNC_ID_RMIN             ( 0U )
#define C_EYEQMSG_CORELIGHTRFLvH_LSR_SYNC_ID_RMAX             ( 255U )
#define C_EYEQMSG_CORELIGHTRFLvH_LSR_SYNC_ID_NUMR             ( 1U )
#define C_EYEQMSG_CORELIGHTRFLvH_LSR_SYNC_ID_DEMNR            ( 1U )
#define C_EYEQMSG_CORELIGHTRFLvH_LSR_SYNC_ID_OFFSET           ( 0U )

/* LSR_Protocol_Version_b7 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTRFLvH_LSR_PROTOCOL_VERSION_RMIN    ( 5U )
#define C_EYEQMSG_CORELIGHTRFLvH_LSR_PROTOCOL_VERSION_RMAX    ( 5U )
#define C_EYEQMSG_CORELIGHTRFLvH_LSR_PROTOCOL_VERSION_NUMR    ( 1U )
#define C_EYEQMSG_CORELIGHTRFLvH_LSR_PROTOCOL_VERSION_DEMNR   ( 1U )
#define C_EYEQMSG_CORELIGHTRFLvH_LSR_PROTOCOL_VERSION_OFFSET  ( 0U )

/* LSR_Zero_byte_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTRFLvH_LSR_ZERO_BYTE_RMIN           ( 0U )
#define C_EYEQMSG_CORELIGHTRFLvH_LSR_ZERO_BYTE_RMAX           ( 255U )
#define C_EYEQMSG_CORELIGHTRFLvH_LSR_ZERO_BYTE_NUMR           ( 1U )
#define C_EYEQMSG_CORELIGHTRFLvH_LSR_ZERO_BYTE_DEMNR          ( 1U )
#define C_EYEQMSG_CORELIGHTRFLvH_LSR_ZERO_BYTE_OFFSET         ( 0U )


/* Virtual_OBJECT_msg_Core_Light_Scene_RFL_protocol Enums */
/* LSR_Buffer_0_b5 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_BUFFER_0_RMIN            ( 0U )
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_BUFFER_0_RMAX            ( 0U )
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_BUFFER_0_NUMR            ( 1U )
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_BUFFER_0_DEMNR           ( 1U )
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_BUFFER_0_OFFSET          ( 0U )

/* LSR_Atten_Cent_Angle_Lat_0_b13 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_ATTEN_CENT_ANGLE_LAT_0_RMIN ( 0U )
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_ATTEN_CENT_ANGLE_LAT_0_RMAX ( 8000U )
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_ATTEN_CENT_ANGLE_LAT_0_NUMR ( 1 )
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_ATTEN_CENT_ANGLE_LAT_0_DEMNR ( 100 )
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_ATTEN_CENT_ANGLE_LAT_0_OFFSET ( -40 )

/* LSR_Is_Cluster_0_b1 signal Enums */
typedef boolean CORELIGHTRFLvOLSRIsCluster0;
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_IS_CLUSTER_0_FALSE       ( CORELIGHTRFLvOLSRIsCluster0 ) ( 0U )
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_IS_CLUSTER_0_TRUE        ( CORELIGHTRFLvOLSRIsCluster0 ) ( 1U )

/* LSR_Is_Cluster_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_IS_CLUSTER_0_RMIN        ( 0U )
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_IS_CLUSTER_0_RMAX        ( 1U )
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_IS_CLUSTER_0_NUMR        ( 1U )
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_IS_CLUSTER_0_DEMNR       ( 1U )
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_IS_CLUSTER_0_OFFSET      ( 0U )

/* LSR_Atten_Cent_Angle_H_0_b13 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_ATTEN_CENT_ANGLE_H_0_RMIN ( 0U )
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_ATTEN_CENT_ANGLE_H_0_RMAX ( 2000U )
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_ATTEN_CENT_ANGLE_H_0_NUMR ( 1 )
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_ATTEN_CENT_ANGLE_H_0_DEMNR ( 100 )
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_ATTEN_CENT_ANGLE_H_0_OFFSET ( -10 )

/* Reserved_3_0_b7 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTRFLvO_RESERVED_3_0_RMIN            ( 0U )
#define C_EYEQMSG_CORELIGHTRFLvO_RESERVED_3_0_RMAX            ( 0U )
#define C_EYEQMSG_CORELIGHTRFLvO_RESERVED_3_0_NUMR            ( 1U )
#define C_EYEQMSG_CORELIGHTRFLvO_RESERVED_3_0_DEMNR           ( 1U )
#define C_EYEQMSG_CORELIGHTRFLvO_RESERVED_3_0_OFFSET          ( 0U )

/* LSR_Left_Angle_0_b13 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_LEFT_ANGLE_0_RMIN        ( 0U )
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_LEFT_ANGLE_0_RMAX        ( 8000U )
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_LEFT_ANGLE_0_NUMR        ( 1 )
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_LEFT_ANGLE_0_DEMNR       ( 100 )
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_LEFT_ANGLE_0_OFFSET      ( -40 )

/* LSR_Bottom_Angle_0_b12 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_BOTTOM_ANGLE_0_RMIN      ( 0U )
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_BOTTOM_ANGLE_0_RMAX      ( 2000U )
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_BOTTOM_ANGLE_0_NUMR      ( 1 )
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_BOTTOM_ANGLE_0_DEMNR     ( 100 )
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_BOTTOM_ANGLE_0_OFFSET    ( -10 )

/* Reserved_2_0_b7 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTRFLvO_RESERVED_2_0_RMIN            ( 0U )
#define C_EYEQMSG_CORELIGHTRFLvO_RESERVED_2_0_RMAX            ( 0U )
#define C_EYEQMSG_CORELIGHTRFLvO_RESERVED_2_0_NUMR            ( 1U )
#define C_EYEQMSG_CORELIGHTRFLvO_RESERVED_2_0_DEMNR           ( 1U )
#define C_EYEQMSG_CORELIGHTRFLvO_RESERVED_2_0_OFFSET          ( 0U )

/* LSR_Right_Angle_0_b13 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_RIGHT_ANGLE_0_RMIN       ( 0U )
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_RIGHT_ANGLE_0_RMAX       ( 8000U )
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_RIGHT_ANGLE_0_NUMR       ( 1 )
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_RIGHT_ANGLE_0_DEMNR      ( 100 )
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_RIGHT_ANGLE_0_OFFSET     ( -40 )

/* LSR_Top_Angle_0_b12 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_TOP_ANGLE_0_RMIN         ( 0U )
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_TOP_ANGLE_0_RMAX         ( 2000U )
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_TOP_ANGLE_0_NUMR         ( 1 )
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_TOP_ANGLE_0_DEMNR        ( 100 )
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_TOP_ANGLE_0_OFFSET       ( -10 )

/* Reserved_1_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTRFLvO_RESERVED_1_0_RMIN            ( 0U )
#define C_EYEQMSG_CORELIGHTRFLvO_RESERVED_1_0_RMAX            ( 0U )
#define C_EYEQMSG_CORELIGHTRFLvO_RESERVED_1_0_NUMR            ( 1U )
#define C_EYEQMSG_CORELIGHTRFLvO_RESERVED_1_0_DEMNR           ( 1U )
#define C_EYEQMSG_CORELIGHTRFLvO_RESERVED_1_0_OFFSET          ( 0U )

/* LSR_Distance_0_b9 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_DISTANCE_0_RMIN          ( 0U )
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_DISTANCE_0_RMAX          ( 500U )
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_DISTANCE_0_NUMR          ( 1U )
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_DISTANCE_0_DEMNR         ( 1U )
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_DISTANCE_0_OFFSET        ( 0U )

/* LSR_Max_Brightness_0_b7 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_MAX_BRIGHTNESS_0_RMIN    ( 0U )
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_MAX_BRIGHTNESS_0_RMAX    ( 100U )
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_MAX_BRIGHTNESS_0_NUMR    ( 1U )
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_MAX_BRIGHTNESS_0_DEMNR   ( 100U )
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_MAX_BRIGHTNESS_0_OFFSET  ( 0U )

/* LSR_Brightness_0_b7 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_BRIGHTNESS_0_RMIN        ( 0U )
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_BRIGHTNESS_0_RMAX        ( 100U )
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_BRIGHTNESS_0_NUMR        ( 1U )
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_BRIGHTNESS_0_DEMNR       ( 100U )
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_BRIGHTNESS_0_OFFSET      ( 0U )

/* LSR_ID_0_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_ID_0_RMIN                ( 0U )
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_ID_0_RMAX                ( 255U )
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_ID_0_NUMR                ( 1U )
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_ID_0_DEMNR               ( 1U )
#define C_EYEQMSG_CORELIGHTRFLvO_LSR_ID_0_OFFSET              ( 0U )


/*****************************************************************************
                  Exported function-like macros
*****************************************************************************/
/*****************************************************************************
                  Exported defined macros
*****************************************************************************/
/*****************************************************************************
                  Exported types, enums definitions
*****************************************************************************/
typedef struct
{
   #if ENABLE_BIG_ENDIAN_FORMAT
      uint32        LSR_Zero_byte_b8                             : 8U;
      
      uint32        unused1_b1                                   : 1;
      uint32        LSR_Protocol_Version_b7                      : 7U;
      
      uint32        LSR_Sync_ID_1_b1                             : 1U;
      
      uint32        LSR_Sync_ID_2_b7                             : 7U;
      
      uint32        LSR_Running_Mode_1_b1                        : 1U;
      
      uint32        unused2_b6                                   : 6;
      uint32        LSR_Running_Mode_2_b1                        : 1U;
      
      uint32        LSR_Inactive_Reason_b3                       : 3U;
      
      uint32        LSR_Strong_Reflectors_Count_b4               : 4U;
      
   #else
      uint32        LSR_Zero_byte_b8                             : 8U;
      
      uint32        LSR_Protocol_Version_b7                      : 7U;
      
      uint32        LSR_Sync_ID_b8                               : 8U;
      
      uint32        LSR_Running_Mode_b2                          : 2U;
      
      uint32        LSR_Inactive_Reason_b3                       : 3U;
      
      uint32        LSR_Strong_Reflectors_Count_b4               : 4U;
      
   #endif
} EYEQMSG_CORELIGHTRFLvH_Params_t;


typedef struct
{
   #if ENABLE_BIG_ENDIAN_FORMAT
      uint32        unused1_b32                                  : 32;
      uint32        LSR_ID_0_b8                                  : 8U;
      
      uint32        unused2_b1                                   : 1;
      uint32        LSR_Brightness_0_b7                          : 7U;
      
      uint32        LSR_Max_Brightness_0_1_b1                    : 1U;
      
      uint32        unused3_b1                                   : 1;
      uint32        LSR_Max_Brightness_0_2_b6                    : 6U;
      
      uint32        LSR_Distance_0_1_b2                          : 2U;
      
      uint32        LSR_Distance_0_2_b7                          : 7U;
      
      uint32        Reserved_1_0_b1                              : 1U;
      
      uint32        LSR_Top_Angle_0_1_b8                         : 8U;
      
      uint32        unused4_b2                                   : 2;
      uint32        LSR_Top_Angle_0_2_b4                         : 4U;
      
      uint32        LSR_Right_Angle_0_1_b4                       : 4U;
      
      uint32        LSR_Right_Angle_0_2_b8                       : 8U;
      
      uint32        unused5_b3                                   : 3;
      uint32        LSR_Right_Angle_0_3_b1                       : 1U;
      
      uint32        Reserved_2_0_b7                              : 7U;
      
      uint32        LSR_Bottom_Angle_0_1_b8                      : 8U;
      
      uint32        LSR_Bottom_Angle_0_2_b4                      : 4U;
      
      uint32        LSR_Left_Angle_0_1_b4                        : 4U;
      
      uint32        LSR_Left_Angle_0_2_b8                        : 8U;
      
      uint32        LSR_Left_Angle_0_3_b1                        : 1U;
      
      uint32        Reserved_3_0_b7                              : 7U;
      
      uint32        LSR_Atten_Cent_Angle_H_0_1_b8                : 8U;
      
      uint32        LSR_Atten_Cent_Angle_H_0_2_b5                : 5U;
      
      uint32        LSR_Is_Cluster_0_b1                          : 1U;
      
      uint32        LSR_Atten_Cent_Angle_Lat_0_1_b2              : 2U;
      
      uint32        LSR_Atten_Cent_Angle_Lat_0_2_b8              : 8U;
      
      uint32        LSR_Atten_Cent_Angle_Lat_0_3_b3              : 3U;
      
      uint32        LSR_Buffer_0_b5                              : 5U;
      
   #else
      uint32        LSR_ID_0_b8                                  : 8U;
      
      uint32        LSR_Brightness_0_b7                          : 7U;
      
      uint32        LSR_Max_Brightness_0_b7                      : 7U;
      
      uint32        LSR_Distance_0_b9                            : 9U;
      
      uint32        Reserved_1_0_b1                              : 1U;
      
      uint32        LSR_Top_Angle_0_b12                          : 12U;
      
      uint32        LSR_Right_Angle_0_b13                        : 13U;
      
      uint32        Reserved_2_0_b7                              : 7U;
      
      uint32        LSR_Bottom_Angle_0_b12                       : 12U;
      
      uint32        LSR_Left_Angle_0_b13                         : 13U;
      
      uint32        Reserved_3_0_b7                              : 7U;
      
      uint32        LSR_Atten_Cent_Angle_H_0_b13                 : 13U;
      
      uint32        LSR_Is_Cluster_0_b1                          : 1U;
      
      uint32        LSR_Atten_Cent_Angle_Lat_0_b13               : 13U;
      
      uint32        LSR_Buffer_0_b5                              : 5U;
      
   #endif
} EYEQMSG_CORELIGHTRFLvO_Params_t;


typedef struct
{
   EYEQMSG_CORELIGHTRFLvH_Params_t EYEQMSG_CORELIGHTRFLvH_Params_s;
   EYEQMSG_CORELIGHTRFLvO_Params_t EYEQMSG_CORELIGHTRFLvO_Params_as[C_EYEQMSG_CORELIGHTRFLvH_VIRTUAL_OBJECT_INDEX_RMAX];
} EYEQMSG_CORELIGHTRFL_Params_t;


/*****************************************************************************
                  Exported function prototypes
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTRFLvH_LSR_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pLSR_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSR_Zero_byte
*    LSR_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSR_Zero_byte signal value of Virtual_HEADER_msg_Core_Light_Scene_RFL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTRFLvH_LSR_Zero_byte( uint8 * pLSR_Zero_byte );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTRFLvH_LSR_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pLSR_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSR_Protocol_Version
*    LSR_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSR_Protocol_Version signal value of Virtual_HEADER_msg_Core_Light_Scene_RFL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTRFLvH_LSR_Protocol_Version( uint8 * pLSR_Protocol_Version );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTRFLvH_LSR_Sync_ID
*
* FUNCTION ARGUMENTS:
*    uint8 * pLSR_Sync_ID - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSR_Sync_ID
*    LSR_Sync_ID returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSR_Sync_ID signal value of Virtual_HEADER_msg_Core_Light_Scene_RFL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTRFLvH_LSR_Sync_ID( uint8 * pLSR_Sync_ID );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTRFLvH_LSR_Running_Mode
*
* FUNCTION ARGUMENTS:
*    CORELIGHTRFLvHLSRRunningMode * pLSR_Running_Mode - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSR_Running_Mode
*    LSR_Running_Mode returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSR_Running_Mode signal value of Virtual_HEADER_msg_Core_Light_Scene_RFL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTRFLvH_LSR_Running_Mode( CORELIGHTRFLvHLSRRunningMode * pLSR_Running_Mode );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTRFLvH_LSR_Inactive_Reason
*
* FUNCTION ARGUMENTS:
*    CORELIGHTRFLvHLSRInactiveReason * pLSR_Inactive_Reason - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSR_Inactive_Reason
*    LSR_Inactive_Reason returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSR_Inactive_Reason signal value of Virtual_HEADER_msg_Core_Light_Scene_RFL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTRFLvH_LSR_Inactive_Reason( CORELIGHTRFLvHLSRInactiveReason * pLSR_Inactive_Reason );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTRFLvH_LSR_Strong_Reflectors_Count
*
* FUNCTION ARGUMENTS:
*    uint8 * pLSR_Strong_Reflectors_Count - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSR_Strong_Reflectors_Count
*    LSR_Strong_Reflectors_Count returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSR_Strong_Reflectors_Count signal value of Virtual_HEADER_msg_Core_Light_Scene_RFL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTRFLvH_LSR_Strong_Reflectors_Count( uint8 * pLSR_Strong_Reflectors_Count );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTRFLvO_LSR_ID_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLSR_ID_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSR_ID_0
*    LSR_ID_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSR_ID_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_RFL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTRFLvO_LSR_ID_0( uint8 objIndx_u8, uint8 * pLSR_ID_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTRFLvO_LSR_Brightness_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLSR_Brightness_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSR_Brightness_0
*    LSR_Brightness_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSR_Brightness_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_RFL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTRFLvO_LSR_Brightness_0( uint8 objIndx_u8, uint8 * pLSR_Brightness_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTRFLvO_LSR_Max_Brightness_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLSR_Max_Brightness_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSR_Max_Brightness_0
*    LSR_Max_Brightness_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSR_Max_Brightness_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_RFL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTRFLvO_LSR_Max_Brightness_0( uint8 objIndx_u8, uint8 * pLSR_Max_Brightness_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTRFLvO_LSR_Distance_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLSR_Distance_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSR_Distance_0
*    LSR_Distance_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSR_Distance_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_RFL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTRFLvO_LSR_Distance_0( uint8 objIndx_u8, uint16 * pLSR_Distance_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTRFLvO_Reserved_1_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    boolean * pReserved_1_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1_0
*    Reserved_1_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_RFL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTRFLvO_Reserved_1_0( uint8 objIndx_u8, boolean * pReserved_1_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTRFLvO_LSR_Top_Angle_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLSR_Top_Angle_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSR_Top_Angle_0
*    LSR_Top_Angle_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSR_Top_Angle_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_RFL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTRFLvO_LSR_Top_Angle_0( uint8 objIndx_u8, uint16 * pLSR_Top_Angle_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTRFLvO_LSR_Right_Angle_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLSR_Right_Angle_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSR_Right_Angle_0
*    LSR_Right_Angle_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSR_Right_Angle_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_RFL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTRFLvO_LSR_Right_Angle_0( uint8 objIndx_u8, uint16 * pLSR_Right_Angle_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTRFLvO_Reserved_2_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_2_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_2_0
*    Reserved_2_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_2_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_RFL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTRFLvO_Reserved_2_0( uint8 objIndx_u8, uint8 * pReserved_2_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTRFLvO_LSR_Bottom_Angle_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLSR_Bottom_Angle_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSR_Bottom_Angle_0
*    LSR_Bottom_Angle_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSR_Bottom_Angle_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_RFL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTRFLvO_LSR_Bottom_Angle_0( uint8 objIndx_u8, uint16 * pLSR_Bottom_Angle_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTRFLvO_LSR_Left_Angle_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLSR_Left_Angle_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSR_Left_Angle_0
*    LSR_Left_Angle_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSR_Left_Angle_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_RFL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTRFLvO_LSR_Left_Angle_0( uint8 objIndx_u8, uint16 * pLSR_Left_Angle_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTRFLvO_Reserved_3_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_3_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_3_0
*    Reserved_3_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_3_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_RFL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTRFLvO_Reserved_3_0( uint8 objIndx_u8, uint8 * pReserved_3_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTRFLvO_LSR_Atten_Cent_Angle_H_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLSR_Atten_Cent_Angle_H_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSR_Atten_Cent_Angle_H_0
*    LSR_Atten_Cent_Angle_H_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSR_Atten_Cent_Angle_H_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_RFL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTRFLvO_LSR_Atten_Cent_Angle_H_0( uint8 objIndx_u8, uint16 * pLSR_Atten_Cent_Angle_H_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTRFLvO_LSR_Is_Cluster_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELIGHTRFLvOLSRIsCluster0 * pLSR_Is_Cluster_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSR_Is_Cluster_0
*    LSR_Is_Cluster_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSR_Is_Cluster_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_RFL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTRFLvO_LSR_Is_Cluster_0( uint8 objIndx_u8, CORELIGHTRFLvOLSRIsCluster0 * pLSR_Is_Cluster_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTRFLvO_LSR_Atten_Cent_Angle_Lat_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLSR_Atten_Cent_Angle_Lat_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSR_Atten_Cent_Angle_Lat_0
*    LSR_Atten_Cent_Angle_Lat_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSR_Atten_Cent_Angle_Lat_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_RFL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTRFLvO_LSR_Atten_Cent_Angle_Lat_0( uint8 objIndx_u8, uint16 * pLSR_Atten_Cent_Angle_Lat_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTRFLvO_LSR_Buffer_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLSR_Buffer_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSR_Buffer_0
*    LSR_Buffer_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSR_Buffer_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_RFL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTRFLvO_LSR_Buffer_0( uint8 objIndx_u8, uint8 * pLSR_Buffer_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_CORELIGHTRFL_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_CORELIGHTRFL_Params_t * pCore_Light_Scene_RFL_protocol - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_Light_Scene_RFL_protocol message 
*    Core_Light_Scene_RFL_protocol message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_Light_Scene_RFL_protocol message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_CORELIGHTRFL_ParamsApp_MsgDataStruct( EYEQMSG_CORELIGHTRFL_Params_t * pCore_Light_Scene_RFL_protocol );
/*****************************************************************************
                  Exported object declarations
*****************************************************************************/
extern EYEQMSG_CORELIGHTRFL_Params_t   EYEQMSG_CORELIGHTRFL_Params_s;
extern EYEQMSG_CORELIGHTRFL_Params_t   EYEQMSG_CORELIGHTRFL_ParamsApp_s;
/****************************************************************************/
#endif /* _EYEQMSG_CORELIGHTRFLPROCESS_H_ */


