

/*****************************************************************************
                  Include files
*****************************************************************************/
/* The suggested include file order is: */
#include "EyeQ_defs.h"    /* EyeQ project common definitions file    */

#include "EYEQMSG_CoreFailSafeProcess.h"

/*****************************************************************************
                  Local symbolic constants
*****************************************************************************/
/*****************************************************************************
                  Local types, enums definitions
*****************************************************************************/
/*****************************************************************************
                  Local function prototypes
*****************************************************************************/
/*****************************************************************************
                  Local object definitions
*****************************************************************************/
/*****************************************************************************
                  Exported object definitions
*****************************************************************************/
EYEQMSG_COREFAILSAFE_Params_t   EYEQMSG_COREFAILSAFE_Params_s;
EYEQMSG_COREFAILSAFE_Params_t   EYEQMSG_COREFAILSAFE_ParamsApp_s;
/*****************************************************************************
                  Local function-like macros
*****************************************************************************/
/*****************************************************************************
                  Local defined macros
*****************************************************************************/
/*****************************************************************************
                  Function definitions
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvH_FSP_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pFSP_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FSP_Zero_byte
*    FSP_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FSP_Zero_byte signal value of Virtual_HEADER_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvH_FSP_Zero_byte( uint8 * pFSP_Zero_byte )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFSP_Zero_byte != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFAILSAFE_ParamsApp_s.EYEQMSG_COREFAILSAFEvH_Params_s.FSP_Zero_byte_b8;
      * pFSP_Zero_byte = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvH_Reserved_1
*
* FUNCTION ARGUMENTS:
*    uint32 * pReserved_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1
*    Reserved_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1 signal value of Virtual_HEADER_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvH_Reserved_1( uint32 * pReserved_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pReserved_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFAILSAFE_ParamsApp_s.EYEQMSG_COREFAILSAFEvH_Params_s.Reserved_1_b24;
      * pReserved_1 = signal_value;
      if( signal_value <= C_EYEQMSG_COREFAILSAFEvH_RESERVED_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvH_FS_Header_CRC
*
* FUNCTION ARGUMENTS:
*    uint32 * pFS_Header_CRC - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FS_Header_CRC
*    FS_Header_CRC returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FS_Header_CRC signal value of Virtual_HEADER_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvH_FS_Header_CRC( uint32 * pFS_Header_CRC )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pFS_Header_CRC != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFAILSAFE_ParamsApp_s.EYEQMSG_COREFAILSAFEvH_Params_s.FS_Header_CRC_b32;
      * pFS_Header_CRC = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvH_FS_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pFS_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FS_Protocol_Version
*    FS_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FS_Protocol_Version signal value of Virtual_HEADER_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvH_FS_Protocol_Version( uint8 * pFS_Protocol_Version )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFS_Protocol_Version != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFAILSAFE_ParamsApp_s.EYEQMSG_COREFAILSAFEvH_Params_s.FS_Protocol_Version_b8;
      * pFS_Protocol_Version = signal_value;
      if( (signal_value >= C_EYEQMSG_COREFAILSAFEvH_FS_PROTOCOL_VERSION_RMIN ) 
          && (signal_value <= C_EYEQMSG_COREFAILSAFEvH_FS_PROTOCOL_VERSION_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvH_FS_Sync_ID
*
* FUNCTION ARGUMENTS:
*    uint8 * pFS_Sync_ID - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FS_Sync_ID
*    FS_Sync_ID returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FS_Sync_ID signal value of Virtual_HEADER_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvH_FS_Sync_ID( uint8 * pFS_Sync_ID )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFS_Sync_ID != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFAILSAFE_ParamsApp_s.EYEQMSG_COREFAILSAFEvH_Params_s.FS_Sync_ID_b8;
      * pFS_Sync_ID = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvH_FS_Cameras_Number
*
* FUNCTION ARGUMENTS:
*    uint8 * pFS_Cameras_Number - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FS_Cameras_Number
*    FS_Cameras_Number returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FS_Cameras_Number signal value of Virtual_HEADER_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvH_FS_Cameras_Number( uint8 * pFS_Cameras_Number )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pFS_Cameras_Number != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFAILSAFE_ParamsApp_s.EYEQMSG_COREFAILSAFEvH_Params_s.FS_Cameras_Number_b4;
      * pFS_Cameras_Number = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvH_FS_TSR_Out_OF_Calib
*
* FUNCTION ARGUMENTS:
*    COREFAILSAFEvHFSTSROutOFCalib * pFS_TSR_Out_OF_Calib - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FS_TSR_Out_OF_Calib
*    FS_TSR_Out_OF_Calib returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FS_TSR_Out_OF_Calib signal value of Virtual_HEADER_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvH_FS_TSR_Out_OF_Calib( COREFAILSAFEvHFSTSROutOFCalib * pFS_TSR_Out_OF_Calib )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFAILSAFEvHFSTSROutOFCalib signal_value;
   
   if( pFS_TSR_Out_OF_Calib != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFAILSAFE_ParamsApp_s.EYEQMSG_COREFAILSAFEvH_Params_s.FS_TSR_Out_OF_Calib_b8;
      * pFS_TSR_Out_OF_Calib = signal_value;
      if( signal_value <= C_EYEQMSG_COREFAILSAFEvH_FS_TSR_OUT_OF_CALIB_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvH_FS_Out_Of_Calib
*
* FUNCTION ARGUMENTS:
*    COREFAILSAFEvHFSOutOfCalib * pFS_Out_Of_Calib - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FS_Out_Of_Calib
*    FS_Out_Of_Calib returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FS_Out_Of_Calib signal value of Virtual_HEADER_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvH_FS_Out_Of_Calib( COREFAILSAFEvHFSOutOfCalib * pFS_Out_Of_Calib )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFAILSAFEvHFSOutOfCalib signal_value;
   
   if( pFS_Out_Of_Calib != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFAILSAFE_ParamsApp_s.EYEQMSG_COREFAILSAFEvH_Params_s.FS_Out_Of_Calib_b3;
      * pFS_Out_Of_Calib = signal_value;
      if( signal_value <= C_EYEQMSG_COREFAILSAFEvH_FS_OUT_OF_CALIB_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvH_Reserved_2
*
* FUNCTION ARGUMENTS:
*    boolean * pReserved_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_2
*    Reserved_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_2 signal value of Virtual_HEADER_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvH_Reserved_2( boolean * pReserved_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pReserved_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFAILSAFE_ParamsApp_s.EYEQMSG_COREFAILSAFEvH_Params_s.Reserved_2_b1;
      * pReserved_2 = signal_value;
      if( signal_value <= C_EYEQMSG_COREFAILSAFEvH_RESERVED_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvH_FS_Impacted_Technologies
*
* FUNCTION ARGUMENTS:
*    COREFAILSAFEvHFSImpactedTechnologies * pFS_Impacted_Technologies - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FS_Impacted_Technologies
*    FS_Impacted_Technologies returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FS_Impacted_Technologies signal value of Virtual_HEADER_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvH_FS_Impacted_Technologies( COREFAILSAFEvHFSImpactedTechnologies * pFS_Impacted_Technologies )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFAILSAFEvHFSImpactedTechnologies signal_value;
   
   if( pFS_Impacted_Technologies != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFAILSAFE_ParamsApp_s.EYEQMSG_COREFAILSAFEvH_Params_s.FS_Impacted_Technologies_b16;
      * pFS_Impacted_Technologies = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvH_FS_Impacted_Technologies_Surround
*
* FUNCTION ARGUMENTS:
*    COREFAILSAFEvHFSImpactedTechnologiesSurround * pFS_Impacted_Technologies_Surround - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FS_Impacted_Technologies_Surround
*    FS_Impacted_Technologies_Surround returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FS_Impacted_Technologies_Surround signal value of Virtual_HEADER_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvH_FS_Impacted_Technologies_Surround( COREFAILSAFEvHFSImpactedTechnologiesSurround * pFS_Impacted_Technologies_Surround )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFAILSAFEvHFSImpactedTechnologiesSurround signal_value;
   
   if( pFS_Impacted_Technologies_Surround != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFAILSAFE_ParamsApp_s.EYEQMSG_COREFAILSAFEvH_Params_s.FS_Impacted_Technologies_Surround_b16;
      * pFS_Impacted_Technologies_Surround = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvH_FS_Rain
*
* FUNCTION ARGUMENTS:
*    COREFAILSAFEvHFSRain * pFS_Rain - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FS_Rain
*    FS_Rain returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FS_Rain signal value of Virtual_HEADER_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvH_FS_Rain( COREFAILSAFEvHFSRain * pFS_Rain )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFAILSAFEvHFSRain signal_value;
   
   if( pFS_Rain != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFAILSAFE_ParamsApp_s.EYEQMSG_COREFAILSAFEvH_Params_s.FS_Rain_b3;
      * pFS_Rain = signal_value;
      if( signal_value <= C_EYEQMSG_COREFAILSAFEvH_FS_RAIN_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvH_FS_Fog
*
* FUNCTION ARGUMENTS:
*    COREFAILSAFEvHFSFog * pFS_Fog - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FS_Fog
*    FS_Fog returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FS_Fog signal value of Virtual_HEADER_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvH_FS_Fog( COREFAILSAFEvHFSFog * pFS_Fog )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFAILSAFEvHFSFog signal_value;
   
   if( pFS_Fog != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFAILSAFE_ParamsApp_s.EYEQMSG_COREFAILSAFEvH_Params_s.FS_Fog_b3;
      * pFS_Fog = signal_value;
      if( signal_value <= C_EYEQMSG_COREFAILSAFEvH_FS_FOG_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvH_FS_Calibration_Misalignment
*
* FUNCTION ARGUMENTS:
*    COREFAILSAFEvHFSCalibrationMisalignment * pFS_Calibration_Misalignment - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FS_Calibration_Misalignment
*    FS_Calibration_Misalignment returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FS_Calibration_Misalignment signal value of Virtual_HEADER_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvH_FS_Calibration_Misalignment( COREFAILSAFEvHFSCalibrationMisalignment * pFS_Calibration_Misalignment )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFAILSAFEvHFSCalibrationMisalignment signal_value;
   
   if( pFS_Calibration_Misalignment != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFAILSAFE_ParamsApp_s.EYEQMSG_COREFAILSAFEvH_Params_s.FS_Calibration_Misalignment_b3;
      * pFS_Calibration_Misalignment = signal_value;
      if( signal_value <= C_EYEQMSG_COREFAILSAFEvH_FS_CALIBRATION_MISALIGNMENT_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvH_FS_C2W_OOR
*
* FUNCTION ARGUMENTS:
*    COREFAILSAFEvHFSC2WOOR * pFS_C2W_OOR - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FS_C2W_OOR
*    FS_C2W_OOR returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FS_C2W_OOR signal value of Virtual_HEADER_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvH_FS_C2W_OOR( COREFAILSAFEvHFSC2WOOR * pFS_C2W_OOR )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFAILSAFEvHFSC2WOOR signal_value;
   
   if( pFS_C2W_OOR != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFAILSAFE_ParamsApp_s.EYEQMSG_COREFAILSAFEvH_Params_s.FS_C2W_OOR_b3;
      * pFS_C2W_OOR = signal_value;
      if( signal_value <= C_EYEQMSG_COREFAILSAFEvH_FS_C2W_OOR_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvH_Reserved_3
*
* FUNCTION ARGUMENTS:
*    uint32 * pReserved_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_3
*    Reserved_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_3 signal value of Virtual_HEADER_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvH_Reserved_3( uint32 * pReserved_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pReserved_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREFAILSAFE_ParamsApp_s.EYEQMSG_COREFAILSAFEvH_Params_s.Reserved_3_b20;
      * pReserved_3 = signal_value;
      if( signal_value <= C_EYEQMSG_COREFAILSAFEvH_RESERVED_3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvO_FS_CRC_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint32 * pFS_CRC_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FS_CRC_0
*    FS_CRC_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FS_CRC_0 signal value of Virtual_OBJECT_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvO_FS_CRC_0( uint8 objIndx_u8, uint32 * pFS_CRC_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Failsafe_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREFAILSAFEvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pFS_CRC_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREFAILSAFE_ParamsApp_s.EYEQMSG_COREFAILSAFEvO_Params_as[objIndx_u8].FS_CRC_0_b32;
         * pFS_CRC_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvO_FS_Camera_ID_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pFS_Camera_ID_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FS_Camera_ID_0
*    FS_Camera_ID_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FS_Camera_ID_0 signal value of Virtual_OBJECT_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvO_FS_Camera_ID_0( uint8 objIndx_u8, uint8 * pFS_Camera_ID_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Failsafe_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREFAILSAFEvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pFS_Camera_ID_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREFAILSAFE_ParamsApp_s.EYEQMSG_COREFAILSAFEvO_Params_as[objIndx_u8].FS_Camera_ID_0_b4;
         * pFS_Camera_ID_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREFAILSAFEvO_FS_CAMERA_ID_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvO_FS_Free_Sight_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREFAILSAFEvOFSFreeSight0 * pFS_Free_Sight_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FS_Free_Sight_0
*    FS_Free_Sight_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FS_Free_Sight_0 signal value of Virtual_OBJECT_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvO_FS_Free_Sight_0( uint8 objIndx_u8, COREFAILSAFEvOFSFreeSight0 * pFS_Free_Sight_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFAILSAFEvOFSFreeSight0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Failsafe_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREFAILSAFEvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pFS_Free_Sight_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREFAILSAFE_ParamsApp_s.EYEQMSG_COREFAILSAFEvO_Params_as[objIndx_u8].FS_Free_Sight_0_b1;
         * pFS_Free_Sight_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvO_FS_Splashes_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREFAILSAFEvOFSSplashes0 * pFS_Splashes_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FS_Splashes_0
*    FS_Splashes_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FS_Splashes_0 signal value of Virtual_OBJECT_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvO_FS_Splashes_0( uint8 objIndx_u8, COREFAILSAFEvOFSSplashes0 * pFS_Splashes_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFAILSAFEvOFSSplashes0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Failsafe_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREFAILSAFEvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pFS_Splashes_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREFAILSAFE_ParamsApp_s.EYEQMSG_COREFAILSAFEvO_Params_as[objIndx_u8].FS_Splashes_0_b3;
         * pFS_Splashes_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREFAILSAFEvO_FS_SPLASHES_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvO_FS_Sun_Ray_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREFAILSAFEvOFSSunRay0 * pFS_Sun_Ray_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FS_Sun_Ray_0
*    FS_Sun_Ray_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FS_Sun_Ray_0 signal value of Virtual_OBJECT_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvO_FS_Sun_Ray_0( uint8 objIndx_u8, COREFAILSAFEvOFSSunRay0 * pFS_Sun_Ray_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFAILSAFEvOFSSunRay0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Failsafe_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREFAILSAFEvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pFS_Sun_Ray_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREFAILSAFE_ParamsApp_s.EYEQMSG_COREFAILSAFEvO_Params_as[objIndx_u8].FS_Sun_Ray_0_b3;
         * pFS_Sun_Ray_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREFAILSAFEvO_FS_SUN_RAY_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvO_FS_Low_Sun_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREFAILSAFEvOFSLowSun0 * pFS_Low_Sun_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FS_Low_Sun_0
*    FS_Low_Sun_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FS_Low_Sun_0 signal value of Virtual_OBJECT_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvO_FS_Low_Sun_0( uint8 objIndx_u8, COREFAILSAFEvOFSLowSun0 * pFS_Low_Sun_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFAILSAFEvOFSLowSun0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Failsafe_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREFAILSAFEvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pFS_Low_Sun_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREFAILSAFE_ParamsApp_s.EYEQMSG_COREFAILSAFEvO_Params_as[objIndx_u8].FS_Low_Sun_0_b3;
         * pFS_Low_Sun_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREFAILSAFEvO_FS_LOW_SUN_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvO_FS_Blur_Image_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREFAILSAFEvOFSBlurImage0 * pFS_Blur_Image_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FS_Blur_Image_0
*    FS_Blur_Image_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FS_Blur_Image_0 signal value of Virtual_OBJECT_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvO_FS_Blur_Image_0( uint8 objIndx_u8, COREFAILSAFEvOFSBlurImage0 * pFS_Blur_Image_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFAILSAFEvOFSBlurImage0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Failsafe_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREFAILSAFEvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pFS_Blur_Image_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREFAILSAFE_ParamsApp_s.EYEQMSG_COREFAILSAFEvO_Params_as[objIndx_u8].FS_Blur_Image_0_b3;
         * pFS_Blur_Image_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREFAILSAFEvO_FS_BLUR_IMAGE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvO_FS_Partial_Blockage_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREFAILSAFEvOFSPartialBlockage0 * pFS_Partial_Blockage_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FS_Partial_Blockage_0
*    FS_Partial_Blockage_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FS_Partial_Blockage_0 signal value of Virtual_OBJECT_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvO_FS_Partial_Blockage_0( uint8 objIndx_u8, COREFAILSAFEvOFSPartialBlockage0 * pFS_Partial_Blockage_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFAILSAFEvOFSPartialBlockage0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Failsafe_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREFAILSAFEvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pFS_Partial_Blockage_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREFAILSAFE_ParamsApp_s.EYEQMSG_COREFAILSAFEvO_Params_as[objIndx_u8].FS_Partial_Blockage_0_b3;
         * pFS_Partial_Blockage_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREFAILSAFEvO_FS_PARTIAL_BLOCKAGE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvO_FS_Full_Blockage_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREFAILSAFEvOFSFullBlockage0 * pFS_Full_Blockage_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FS_Full_Blockage_0
*    FS_Full_Blockage_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FS_Full_Blockage_0 signal value of Virtual_OBJECT_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvO_FS_Full_Blockage_0( uint8 objIndx_u8, COREFAILSAFEvOFSFullBlockage0 * pFS_Full_Blockage_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFAILSAFEvOFSFullBlockage0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Failsafe_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREFAILSAFEvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pFS_Full_Blockage_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREFAILSAFE_ParamsApp_s.EYEQMSG_COREFAILSAFEvO_Params_as[objIndx_u8].FS_Full_Blockage_0_b3;
         * pFS_Full_Blockage_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREFAILSAFEvO_FS_FULL_BLOCKAGE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvO_FS_Frozen_Windshield_Lens_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREFAILSAFEvOFSFrozenWindshieldLens0 * pFS_Frozen_Windshield_Lens_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FS_Frozen_Windshield_Lens_0
*    FS_Frozen_Windshield_Lens_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FS_Frozen_Windshield_Lens_0 signal value of Virtual_OBJECT_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvO_FS_Frozen_Windshield_Lens_0( uint8 objIndx_u8, COREFAILSAFEvOFSFrozenWindshieldLens0 * pFS_Frozen_Windshield_Lens_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFAILSAFEvOFSFrozenWindshieldLens0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Failsafe_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREFAILSAFEvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pFS_Frozen_Windshield_Lens_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREFAILSAFE_ParamsApp_s.EYEQMSG_COREFAILSAFEvO_Params_as[objIndx_u8].FS_Frozen_Windshield_Lens_0_b3;
         * pFS_Frozen_Windshield_Lens_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREFAILSAFEvO_FS_FROZEN_WINDSHIELD_LENS_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvO_FS_Out_Of_Focus_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREFAILSAFEvOFSOutOfFocus0 * pFS_Out_Of_Focus_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FS_Out_Of_Focus_0
*    FS_Out_Of_Focus_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FS_Out_Of_Focus_0 signal value of Virtual_OBJECT_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvO_FS_Out_Of_Focus_0( uint8 objIndx_u8, COREFAILSAFEvOFSOutOfFocus0 * pFS_Out_Of_Focus_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFAILSAFEvOFSOutOfFocus0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Failsafe_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREFAILSAFEvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pFS_Out_Of_Focus_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREFAILSAFE_ParamsApp_s.EYEQMSG_COREFAILSAFEvO_Params_as[objIndx_u8].FS_Out_Of_Focus_0_b3;
         * pFS_Out_Of_Focus_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREFAILSAFEvO_FS_OUT_OF_FOCUS_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREFAILSAFEvO_FS_C2C_Out_Of_Calib_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    COREFAILSAFEvOFSC2COutOfCalib0 * pFS_C2C_Out_Of_Calib_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of FS_C2C_Out_Of_Calib_0
*    FS_C2C_Out_Of_Calib_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns FS_C2C_Out_Of_Calib_0 signal value of Virtual_OBJECT_msg_Core_Failsafe_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREFAILSAFEvO_FS_C2C_Out_Of_Calib_0( uint8 objIndx_u8, COREFAILSAFEvOFSC2COutOfCalib0 * pFS_C2C_Out_Of_Calib_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREFAILSAFEvOFSC2COutOfCalib0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Failsafe_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_COREFAILSAFEvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pFS_C2C_Out_Of_Calib_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_COREFAILSAFE_ParamsApp_s.EYEQMSG_COREFAILSAFEvO_Params_as[objIndx_u8].FS_C2C_Out_Of_Calib_0_b3;
         * pFS_C2C_Out_Of_Calib_0 = signal_value;
         if( signal_value <= C_EYEQMSG_COREFAILSAFEvO_FS_C2C_OUT_OF_CALIB_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_COREFAILSAFE_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_COREFAILSAFE_Params_t * pCore_Failsafe_protocol - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_Failsafe_protocol message 
*    Core_Failsafe_protocol message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_Failsafe_protocol message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_COREFAILSAFE_ParamsApp_MsgDataStruct( EYEQMSG_COREFAILSAFE_Params_t * pCore_Failsafe_protocol )
{
   Std_ReturnType status = C_SIG_INVALID;
   if( pCore_Failsafe_protocol != C_NULL_P )
   {
      status = C_SIG_VALID;
      * pCore_Failsafe_protocol = EYEQMSG_COREFAILSAFE_ParamsApp_s;
   }
   return ( status );
}

