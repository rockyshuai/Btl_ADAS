#ifndef _EYEQMSG_COREMTFVINITPROCESS_H_
#define _EYEQMSG_COREMTFVINITPROCESS_H_

/*****************************************************************************
                  Included header files
*****************************************************************************/
#include <Std_Types.h>

/*****************************************************************************
                  Include files
*****************************************************************************/
/*****************************************************************************
                  Exported symbolic constants
*****************************************************************************/

/* Datagram message ID */
#define C_EYEQMSG_COREMTFVINIT_MSG_ID                         ( 0x83U )

/* Datagram message lengths */
#define C_EYEQMSG_COREMTFVINIT_MSG_LEN                        ( sizeof(EYEQMSG_COREMTFVINIT_Params_t) )

/* Protocol ENUMs */

/* MCU output messages */

/* Core_MTFV_Init Enums */
/* Reserved_1_b10 signal Min & Max range limits */
#define C_EYEQMSG_COREMTFVINIT_RESERVED_1_RMIN                ( 0U )
#define C_EYEQMSG_COREMTFVINIT_RESERVED_1_RMAX                ( 0U )
#define C_EYEQMSG_COREMTFVINIT_RESERVED_1_NUMR                ( 1U )
#define C_EYEQMSG_COREMTFVINIT_RESERVED_1_DEMNR               ( 1U )
#define C_EYEQMSG_COREMTFVINIT_RESERVED_1_OFFSET              ( 0U )

/* IMTFV_Mode_b3 signal Enums */
typedef uint8 COREMTFVINITIMTFVMode;
#define C_EYEQMSG_COREMTFVINIT_IMTFV_MODE_RESERVED_3          ( COREMTFVINITIMTFVMode ) ( 0U )
#define C_EYEQMSG_COREMTFVINIT_IMTFV_MODE_MTFV_52_11_W_T_L    ( COREMTFVINITIMTFVMode ) ( 1U )
#define C_EYEQMSG_COREMTFVINIT_IMTFV_MODE_MTFV_52_11_B_T_L    ( COREMTFVINITIMTFVMode ) ( 2U )
#define C_EYEQMSG_COREMTFVINIT_IMTFV_MODE_RESERVED_2          ( COREMTFVINITIMTFVMode ) ( 3U )
#define C_EYEQMSG_COREMTFVINIT_IMTFV_MODE_RESERVED_1          ( COREMTFVINITIMTFVMode ) ( 4U )
#define C_EYEQMSG_COREMTFVINIT_IMTFV_MODE_MTFV_100_13_W_T_L   ( COREMTFVINITIMTFVMode ) ( 5U )
#define C_EYEQMSG_COREMTFVINIT_IMTFV_MODE_MTFV_100_13_B_T_L   ( COREMTFVINITIMTFVMode ) ( 6U )

/* IMTFV_Mode_b3 signal Min & Max range limits */
#define C_EYEQMSG_COREMTFVINIT_IMTFV_MODE_RMIN                ( 0U )
#define C_EYEQMSG_COREMTFVINIT_IMTFV_MODE_RMAX                ( 6U )
#define C_EYEQMSG_COREMTFVINIT_IMTFV_MODE_NUMR                ( 1U )
#define C_EYEQMSG_COREMTFVINIT_IMTFV_MODE_DEMNR               ( 1U )
#define C_EYEQMSG_COREMTFVINIT_IMTFV_MODE_OFFSET              ( 0U )

/* IMTFV_Fixed_Exposure_b16 signal Min & Max range limits */
#define C_EYEQMSG_COREMTFVINIT_IMTFV_FIXED_EXPOSURE_RMIN      ( 0U )
#define C_EYEQMSG_COREMTFVINIT_IMTFV_FIXED_EXPOSURE_RMAX      ( 65535U )
#define C_EYEQMSG_COREMTFVINIT_IMTFV_FIXED_EXPOSURE_NUMR      ( 1U )
#define C_EYEQMSG_COREMTFVINIT_IMTFV_FIXED_EXPOSURE_DEMNR     ( 1U )
#define C_EYEQMSG_COREMTFVINIT_IMTFV_FIXED_EXPOSURE_OFFSET    ( 0U )

/* IMTFV_Cmera_Ientity_b3 signal Enums */
typedef uint8 COREMTFVINITIMTFVCmeraIentity;
#define C_EYEQMSG_COREMTFVINIT_IMTFV_CMERA_IENTITY_ITERATE    ( COREMTFVINITIMTFVCmeraIentity ) ( -1U )
#define C_EYEQMSG_COREMTFVINIT_IMTFV_CMERA_IENTITY_NA         ( COREMTFVINITIMTFVCmeraIentity ) ( 0U )
#define C_EYEQMSG_COREMTFVINIT_IMTFV_CMERA_IENTITY_MAIN       ( COREMTFVINITIMTFVCmeraIentity ) ( 1U )
#define C_EYEQMSG_COREMTFVINIT_IMTFV_CMERA_IENTITY_NARROW     ( COREMTFVINITIMTFVCmeraIentity ) ( 2U )
#define C_EYEQMSG_COREMTFVINIT_IMTFV_CMERA_IENTITY_FISHEYE    ( COREMTFVINITIMTFVCmeraIentity ) ( 3U )

/* IMTFV_Cmera_Ientity_b3 signal Min & Max range limits */
#define C_EYEQMSG_COREMTFVINIT_IMTFV_CMERA_IENTITY_RMIN       ( 0U )
#define C_EYEQMSG_COREMTFVINIT_IMTFV_CMERA_IENTITY_RMAX       ( 4U )
#define C_EYEQMSG_COREMTFVINIT_IMTFV_CMERA_IENTITY_NUMR       ( 1 )
#define C_EYEQMSG_COREMTFVINIT_IMTFV_CMERA_IENTITY_DEMNR      ( 1 )
#define C_EYEQMSG_COREMTFVINIT_IMTFV_CMERA_IENTITY_OFFSET     ( -1 )

/* IMTFV_Optional_Signals_b16 signal Min & Max range limits */
#define C_EYEQMSG_COREMTFVINIT_IMTFV_OPTIONAL_SIGNALS_RMIN    ( 0U )
#define C_EYEQMSG_COREMTFVINIT_IMTFV_OPTIONAL_SIGNALS_RMAX    ( 0U )
#define C_EYEQMSG_COREMTFVINIT_IMTFV_OPTIONAL_SIGNALS_NUMR    ( 1U )
#define C_EYEQMSG_COREMTFVINIT_IMTFV_OPTIONAL_SIGNALS_DEMNR   ( 1U )
#define C_EYEQMSG_COREMTFVINIT_IMTFV_OPTIONAL_SIGNALS_OFFSET  ( 0U )

/* IMTFV_Protocol_Version_b8 signal Min & Max range limits */
#define C_EYEQMSG_COREMTFVINIT_IMTFV_PROTOCOL_VERSION_RMIN    ( 1U )
#define C_EYEQMSG_COREMTFVINIT_IMTFV_PROTOCOL_VERSION_RMAX    ( 1U )
#define C_EYEQMSG_COREMTFVINIT_IMTFV_PROTOCOL_VERSION_NUMR    ( 1U )
#define C_EYEQMSG_COREMTFVINIT_IMTFV_PROTOCOL_VERSION_DEMNR   ( 1U )
#define C_EYEQMSG_COREMTFVINIT_IMTFV_PROTOCOL_VERSION_OFFSET  ( 0U )

/* IMTFV_Zero_byte_b8 signal Min & Max range limits */
#define C_EYEQMSG_COREMTFVINIT_IMTFV_ZERO_BYTE_RMIN           ( 0U )
#define C_EYEQMSG_COREMTFVINIT_IMTFV_ZERO_BYTE_RMAX           ( 0U )
#define C_EYEQMSG_COREMTFVINIT_IMTFV_ZERO_BYTE_NUMR           ( 1U )
#define C_EYEQMSG_COREMTFVINIT_IMTFV_ZERO_BYTE_DEMNR          ( 1U )
#define C_EYEQMSG_COREMTFVINIT_IMTFV_ZERO_BYTE_OFFSET         ( 0U )


/*****************************************************************************
                  Exported function-like macros
*****************************************************************************/
/*****************************************************************************
                  Exported defined macros
*****************************************************************************/
/*****************************************************************************
                  Exported types, enums definitions
*****************************************************************************/
typedef struct
{
   #if ENABLE_BIG_ENDIAN_FORMAT
      uint32        IMTFV_Zero_byte_b8                           : 8U;
      
      uint32        IMTFV_Protocol_Version_b8                    : 8U;
      
      uint32        IMTFV_Optional_Signals_1_b8                  : 8U;
      
      uint32        IMTFV_Optional_Signals_2_b8                  : 8U;
      
      uint32        unused1_b5                                   : 5;
      uint32        IMTFV_Cmera_Ientity_b3                       : 3U;
      
      uint32        IMTFV_Fixed_Exposure_1_b5                    : 5U;
      
      uint32        IMTFV_Fixed_Exposure_2_b8                    : 8U;
      
      uint32        IMTFV_Fixed_Exposure_3_b3                    : 3U;
      
      uint32        IMTFV_Mode_b3                                : 3U;
      
      uint32        Reserved_1_1_b2                              : 2U;
      
      uint32        Reserved_1_2_b8                              : 8U;
      
   #else
      uint32        IMTFV_Zero_byte_b8                           : 8U;
      
      uint32        IMTFV_Protocol_Version_b8                    : 8U;
      
      uint32        IMTFV_Optional_Signals_b16                   : 16U;
      
      uint32        IMTFV_Cmera_Ientity_b3                       : 3U;
      
      uint32        IMTFV_Fixed_Exposure_b16                     : 16U;
      
      uint32        IMTFV_Mode_b3                                : 3U;
      
      uint32        Reserved_1_b10                               : 10U;
      
   #endif
} EYEQMSG_COREMTFVINIT_Params_t;


/*****************************************************************************
                  Exported function prototypes
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_COREMTFVINIT_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_COREMTFVINIT_Params_t * pCore_MTFV_Init - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_MTFV_Init message 
*    Core_MTFV_Init message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_MTFV_Init message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_COREMTFVINIT_ParamsApp_MsgDataStruct( EYEQMSG_COREMTFVINIT_Params_t * pCore_MTFV_Init );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREMTFVINIT_IMTFV_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pIMTFV_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IMTFV_Zero_byte
*    IMTFV_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IMTFV_Zero_byte signal value of Core_MTFV_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREMTFVINIT_IMTFV_Zero_byte( uint8 * pIMTFV_Zero_byte );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREMTFVINIT_IMTFV_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pIMTFV_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IMTFV_Protocol_Version
*    IMTFV_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IMTFV_Protocol_Version signal value of Core_MTFV_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREMTFVINIT_IMTFV_Protocol_Version( uint8 * pIMTFV_Protocol_Version );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREMTFVINIT_IMTFV_Optional_Signals
*
* FUNCTION ARGUMENTS:
*    uint16 * pIMTFV_Optional_Signals - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IMTFV_Optional_Signals
*    IMTFV_Optional_Signals returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IMTFV_Optional_Signals signal value of Core_MTFV_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREMTFVINIT_IMTFV_Optional_Signals( uint16 * pIMTFV_Optional_Signals );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREMTFVINIT_IMTFV_Cmera_Ientity
*
* FUNCTION ARGUMENTS:
*    COREMTFVINITIMTFVCmeraIentity * pIMTFV_Cmera_Ientity - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IMTFV_Cmera_Ientity
*    IMTFV_Cmera_Ientity returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IMTFV_Cmera_Ientity signal value of Core_MTFV_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREMTFVINIT_IMTFV_Cmera_Ientity( COREMTFVINITIMTFVCmeraIentity * pIMTFV_Cmera_Ientity );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREMTFVINIT_IMTFV_Fixed_Exposure
*
* FUNCTION ARGUMENTS:
*    uint16 * pIMTFV_Fixed_Exposure - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IMTFV_Fixed_Exposure
*    IMTFV_Fixed_Exposure returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IMTFV_Fixed_Exposure signal value of Core_MTFV_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREMTFVINIT_IMTFV_Fixed_Exposure( uint16 * pIMTFV_Fixed_Exposure );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREMTFVINIT_IMTFV_Mode
*
* FUNCTION ARGUMENTS:
*    COREMTFVINITIMTFVMode * pIMTFV_Mode - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IMTFV_Mode
*    IMTFV_Mode returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IMTFV_Mode signal value of Core_MTFV_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREMTFVINIT_IMTFV_Mode( COREMTFVINITIMTFVMode * pIMTFV_Mode );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREMTFVINIT_Reserved_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pReserved_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1
*    Reserved_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1 signal value of Core_MTFV_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREMTFVINIT_Reserved_1( uint16 * pReserved_1 );
/*****************************************************************************
                  Exported object declarations
*****************************************************************************/
extern EYEQMSG_COREMTFVINIT_Params_t   EYEQMSG_COREMTFVINIT_Params_s;
extern EYEQMSG_COREMTFVINIT_Params_t   EYEQMSG_COREMTFVINIT_ParamsApp_s;
/****************************************************************************/
#endif /* _EYEQMSG_COREMTFVINITPROCESS_H_ */


