

/*****************************************************************************
                  Include files
*****************************************************************************/
/* The suggested include file order is: */
#include "EyeQ_defs.h"    /* EyeQ project common definitions file    */

#include "EYEQMSG_CalDynProcess.h"

/*****************************************************************************
                  Local symbolic constants
*****************************************************************************/
/*****************************************************************************
                  Local types, enums definitions
*****************************************************************************/
/*****************************************************************************
                  Local function prototypes
*****************************************************************************/
/*****************************************************************************
                  Local object definitions
*****************************************************************************/
/*****************************************************************************
                  Exported object definitions
*****************************************************************************/
EYEQMSG_CALDYN_Params_t   EYEQMSG_CALDYN_Params_s;
EYEQMSG_CALDYN_Params_t   EYEQMSG_CALDYN_ParamsApp_s;
/*****************************************************************************
                  Local function-like macros
*****************************************************************************/
/*****************************************************************************
                  Local defined macros
*****************************************************************************/
/*****************************************************************************
                  Function definitions
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_CALDYN_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_CALDYN_Params_t * pCore_Calibration_Dynamic_protocol - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_Calibration_Dynamic_protocol message 
*    Core_Calibration_Dynamic_protocol message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_Calibration_Dynamic_protocol message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_CALDYN_ParamsApp_MsgDataStruct( EYEQMSG_CALDYN_Params_t * pCore_Calibration_Dynamic_protocol )
{
   Std_ReturnType status = C_SIG_INVALID;
   if( pCore_Calibration_Dynamic_protocol != C_NULL_P )
   {
      status = C_SIG_VALID;
      * pCore_Calibration_Dynamic_protocol = EYEQMSG_CALDYN_ParamsApp_s;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pCLB_DYN_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Zero_byte
*    CLB_DYN_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Zero_byte signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Zero_byte( uint8 * pCLB_DYN_Zero_byte )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pCLB_DYN_Zero_byte != C_NULL_P )
   {
      signal_value = EYEQMSG_CALDYN_ParamsApp_s.CLB_DYN_Zero_byte_b8;
      * pCLB_DYN_Zero_byte = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_Reserved_1
*
* FUNCTION ARGUMENTS:
*    uint32 * pReserved_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1
*    Reserved_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1 signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_Reserved_1( uint32 * pReserved_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pReserved_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_CALDYN_ParamsApp_s.Reserved_1_b24;
      * pReserved_1 = signal_value;
      if( signal_value <= C_EYEQMSG_CALDYN_RESERVED_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Header_CRC
*
* FUNCTION ARGUMENTS:
*    uint32 * pCLB_DYN_Header_CRC - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Header_CRC
*    CLB_DYN_Header_CRC returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Header_CRC signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Header_CRC( uint32 * pCLB_DYN_Header_CRC )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pCLB_DYN_Header_CRC != C_NULL_P )
   {
      signal_value = EYEQMSG_CALDYN_ParamsApp_s.CLB_DYN_Header_CRC_b32;
      * pCLB_DYN_Header_CRC = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pCLB_DYN_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Protocol_Version
*    CLB_DYN_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Protocol_Version signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Protocol_Version( uint8 * pCLB_DYN_Protocol_Version )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pCLB_DYN_Protocol_Version != C_NULL_P )
   {
      signal_value = EYEQMSG_CALDYN_ParamsApp_s.CLB_DYN_Protocol_Version_b8;
      * pCLB_DYN_Protocol_Version = signal_value;
      if( (signal_value >= C_EYEQMSG_CALDYN_CLB_DYN_PROTOCOL_VERSION_RMIN ) 
          && (signal_value <= C_EYEQMSG_CALDYN_CLB_DYN_PROTOCOL_VERSION_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Sync_ID
*
* FUNCTION ARGUMENTS:
*    uint8 * pCLB_DYN_Sync_ID - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Sync_ID
*    CLB_DYN_Sync_ID returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Sync_ID signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Sync_ID( uint8 * pCLB_DYN_Sync_ID )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pCLB_DYN_Sync_ID != C_NULL_P )
   {
      signal_value = EYEQMSG_CALDYN_ParamsApp_s.CLB_DYN_Sync_ID_b8;
      * pCLB_DYN_Sync_ID = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Run_Mode
*
* FUNCTION ARGUMENTS:
*    CALDYNCLBDYNRunMode * pCLB_DYN_Run_Mode - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Run_Mode
*    CLB_DYN_Run_Mode returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Run_Mode signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Run_Mode( CALDYNCLBDYNRunMode * pCLB_DYN_Run_Mode )
{
   Std_ReturnType status = C_SIG_INVALID;
   CALDYNCLBDYNRunMode signal_value;
   
   if( pCLB_DYN_Run_Mode != C_NULL_P )
   {
      signal_value = EYEQMSG_CALDYN_ParamsApp_s.CLB_DYN_Run_Mode_b3;
      * pCLB_DYN_Run_Mode = signal_value;
      if( signal_value <= C_EYEQMSG_CALDYN_CLB_DYN_RUN_MODE_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Cam_Height_Status
*
* FUNCTION ARGUMENTS:
*    CALDYNCLBDYNCamHeightStatus * pCLB_DYN_Cam_Height_Status - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Cam_Height_Status
*    CLB_DYN_Cam_Height_Status returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Cam_Height_Status signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Cam_Height_Status( CALDYNCLBDYNCamHeightStatus * pCLB_DYN_Cam_Height_Status )
{
   Std_ReturnType status = C_SIG_INVALID;
   CALDYNCLBDYNCamHeightStatus signal_value;
   
   if( pCLB_DYN_Cam_Height_Status != C_NULL_P )
   {
      signal_value = EYEQMSG_CALDYN_ParamsApp_s.CLB_DYN_Cam_Height_Status_b2;
      * pCLB_DYN_Cam_Height_Status = signal_value;
      if( signal_value <= C_EYEQMSG_CALDYN_CLB_DYN_CAM_HEIGHT_STATUS_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Yaw_Status
*
* FUNCTION ARGUMENTS:
*    CALDYNCLBDYNYawStatus * pCLB_DYN_Yaw_Status - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Yaw_Status
*    CLB_DYN_Yaw_Status returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Yaw_Status signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Yaw_Status( CALDYNCLBDYNYawStatus * pCLB_DYN_Yaw_Status )
{
   Std_ReturnType status = C_SIG_INVALID;
   CALDYNCLBDYNYawStatus signal_value;
   
   if( pCLB_DYN_Yaw_Status != C_NULL_P )
   {
      signal_value = EYEQMSG_CALDYN_ParamsApp_s.CLB_DYN_Yaw_Status_b2;
      * pCLB_DYN_Yaw_Status = signal_value;
      if( signal_value <= C_EYEQMSG_CALDYN_CLB_DYN_YAW_STATUS_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Pitch_Status
*
* FUNCTION ARGUMENTS:
*    CALDYNCLBDYNPitchStatus * pCLB_DYN_Pitch_Status - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Pitch_Status
*    CLB_DYN_Pitch_Status returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Pitch_Status signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Pitch_Status( CALDYNCLBDYNPitchStatus * pCLB_DYN_Pitch_Status )
{
   Std_ReturnType status = C_SIG_INVALID;
   CALDYNCLBDYNPitchStatus signal_value;
   
   if( pCLB_DYN_Pitch_Status != C_NULL_P )
   {
      signal_value = EYEQMSG_CALDYN_ParamsApp_s.CLB_DYN_Pitch_Status_b2;
      * pCLB_DYN_Pitch_Status = signal_value;
      if( signal_value <= C_EYEQMSG_CALDYN_CLB_DYN_PITCH_STATUS_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Roll_Status
*
* FUNCTION ARGUMENTS:
*    CALDYNCLBDYNRollStatus * pCLB_DYN_Roll_Status - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Roll_Status
*    CLB_DYN_Roll_Status returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Roll_Status signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Roll_Status( CALDYNCLBDYNRollStatus * pCLB_DYN_Roll_Status )
{
   Std_ReturnType status = C_SIG_INVALID;
   CALDYNCLBDYNRollStatus signal_value;
   
   if( pCLB_DYN_Roll_Status != C_NULL_P )
   {
      signal_value = EYEQMSG_CALDYN_ParamsApp_s.CLB_DYN_Roll_Status_b2;
      * pCLB_DYN_Roll_Status = signal_value;
      if( signal_value <= C_EYEQMSG_CALDYN_CLB_DYN_ROLL_STATUS_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Cam_Height_Error
*
* FUNCTION ARGUMENTS:
*    CALDYNCLBDYNCamHeightError * pCLB_DYN_Cam_Height_Error - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Cam_Height_Error
*    CLB_DYN_Cam_Height_Error returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Cam_Height_Error signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Cam_Height_Error( CALDYNCLBDYNCamHeightError * pCLB_DYN_Cam_Height_Error )
{
   Std_ReturnType status = C_SIG_INVALID;
   CALDYNCLBDYNCamHeightError signal_value;
   
   if( pCLB_DYN_Cam_Height_Error != C_NULL_P )
   {
      signal_value = EYEQMSG_CALDYN_ParamsApp_s.CLB_DYN_Cam_Height_Error_b2;
      * pCLB_DYN_Cam_Height_Error = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Yaw_Error
*
* FUNCTION ARGUMENTS:
*    CALDYNCLBDYNYawError * pCLB_DYN_Yaw_Error - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Yaw_Error
*    CLB_DYN_Yaw_Error returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Yaw_Error signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Yaw_Error( CALDYNCLBDYNYawError * pCLB_DYN_Yaw_Error )
{
   Std_ReturnType status = C_SIG_INVALID;
   CALDYNCLBDYNYawError signal_value;
   
   if( pCLB_DYN_Yaw_Error != C_NULL_P )
   {
      signal_value = EYEQMSG_CALDYN_ParamsApp_s.CLB_DYN_Yaw_Error_b2;
      * pCLB_DYN_Yaw_Error = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_Reserved_2
*
* FUNCTION ARGUMENTS:
*    boolean * pReserved_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_2
*    Reserved_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_2 signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_Reserved_2( boolean * pReserved_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pReserved_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_CALDYN_ParamsApp_s.Reserved_2_b1;
      * pReserved_2 = signal_value;
      if( signal_value <= C_EYEQMSG_CALDYN_RESERVED_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Pitch_Error
*
* FUNCTION ARGUMENTS:
*    CALDYNCLBDYNPitchError * pCLB_DYN_Pitch_Error - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Pitch_Error
*    CLB_DYN_Pitch_Error returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Pitch_Error signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Pitch_Error( CALDYNCLBDYNPitchError * pCLB_DYN_Pitch_Error )
{
   Std_ReturnType status = C_SIG_INVALID;
   CALDYNCLBDYNPitchError signal_value;
   
   if( pCLB_DYN_Pitch_Error != C_NULL_P )
   {
      signal_value = EYEQMSG_CALDYN_ParamsApp_s.CLB_DYN_Pitch_Error_b2;
      * pCLB_DYN_Pitch_Error = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Roll_Error
*
* FUNCTION ARGUMENTS:
*    CALDYNCLBDYNRollError * pCLB_DYN_Roll_Error - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Roll_Error
*    CLB_DYN_Roll_Error returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Roll_Error signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Roll_Error( CALDYNCLBDYNRollError * pCLB_DYN_Roll_Error )
{
   Std_ReturnType status = C_SIG_INVALID;
   CALDYNCLBDYNRollError signal_value;
   
   if( pCLB_DYN_Roll_Error != C_NULL_P )
   {
      signal_value = EYEQMSG_CALDYN_ParamsApp_s.CLB_DYN_Roll_Error_b2;
      * pCLB_DYN_Roll_Error = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Pause_Reason
*
* FUNCTION ARGUMENTS:
*    CALDYNCLBDYNPauseReason * pCLB_DYN_Pause_Reason - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Pause_Reason
*    CLB_DYN_Pause_Reason returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Pause_Reason signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Pause_Reason( CALDYNCLBDYNPauseReason * pCLB_DYN_Pause_Reason )
{
   Std_ReturnType status = C_SIG_INVALID;
   CALDYNCLBDYNPauseReason signal_value;
   
   if( pCLB_DYN_Pause_Reason != C_NULL_P )
   {
      signal_value = EYEQMSG_CALDYN_ParamsApp_s.CLB_DYN_Pause_Reason_b5;
      * pCLB_DYN_Pause_Reason = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Cam_Height_Confidence
*
* FUNCTION ARGUMENTS:
*    uint8 * pCLB_DYN_Cam_Height_Confidence - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Cam_Height_Confidence
*    CLB_DYN_Cam_Height_Confidence returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Cam_Height_Confidence signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Cam_Height_Confidence( uint8 * pCLB_DYN_Cam_Height_Confidence )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pCLB_DYN_Cam_Height_Confidence != C_NULL_P )
   {
      signal_value = EYEQMSG_CALDYN_ParamsApp_s.CLB_DYN_Cam_Height_Confidence_b7;
      * pCLB_DYN_Cam_Height_Confidence = signal_value;
      if( signal_value <= C_EYEQMSG_CALDYN_CLB_DYN_CAM_HEIGHT_CONFIDENCE_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Yaw_Confidence
*
* FUNCTION ARGUMENTS:
*    uint8 * pCLB_DYN_Yaw_Confidence - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Yaw_Confidence
*    CLB_DYN_Yaw_Confidence returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Yaw_Confidence signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Yaw_Confidence( uint8 * pCLB_DYN_Yaw_Confidence )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pCLB_DYN_Yaw_Confidence != C_NULL_P )
   {
      signal_value = EYEQMSG_CALDYN_ParamsApp_s.CLB_DYN_Yaw_Confidence_b7;
      * pCLB_DYN_Yaw_Confidence = signal_value;
      if( signal_value <= C_EYEQMSG_CALDYN_CLB_DYN_YAW_CONFIDENCE_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Pitch_Confidence
*
* FUNCTION ARGUMENTS:
*    uint8 * pCLB_DYN_Pitch_Confidence - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Pitch_Confidence
*    CLB_DYN_Pitch_Confidence returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Pitch_Confidence signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Pitch_Confidence( uint8 * pCLB_DYN_Pitch_Confidence )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pCLB_DYN_Pitch_Confidence != C_NULL_P )
   {
      signal_value = EYEQMSG_CALDYN_ParamsApp_s.CLB_DYN_Pitch_Confidence_b7;
      * pCLB_DYN_Pitch_Confidence = signal_value;
      if( signal_value <= C_EYEQMSG_CALDYN_CLB_DYN_PITCH_CONFIDENCE_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_Reserved_3
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_3
*    Reserved_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_3 signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_Reserved_3( uint8 * pReserved_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pReserved_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_CALDYN_ParamsApp_s.Reserved_3_b2;
      * pReserved_3 = signal_value;
      if( signal_value <= C_EYEQMSG_CALDYN_RESERVED_3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Roll_Confidence
*
* FUNCTION ARGUMENTS:
*    uint8 * pCLB_DYN_Roll_Confidence - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Roll_Confidence
*    CLB_DYN_Roll_Confidence returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Roll_Confidence signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Roll_Confidence( uint8 * pCLB_DYN_Roll_Confidence )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pCLB_DYN_Roll_Confidence != C_NULL_P )
   {
      signal_value = EYEQMSG_CALDYN_ParamsApp_s.CLB_DYN_Roll_Confidence_b7;
      * pCLB_DYN_Roll_Confidence = signal_value;
      if( signal_value <= C_EYEQMSG_CALDYN_CLB_DYN_ROLL_CONFIDENCE_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Cam_Height_Progress
*
* FUNCTION ARGUMENTS:
*    uint8 * pCLB_DYN_Cam_Height_Progress - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Cam_Height_Progress
*    CLB_DYN_Cam_Height_Progress returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Cam_Height_Progress signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Cam_Height_Progress( uint8 * pCLB_DYN_Cam_Height_Progress )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pCLB_DYN_Cam_Height_Progress != C_NULL_P )
   {
      signal_value = EYEQMSG_CALDYN_ParamsApp_s.CLB_DYN_Cam_Height_Progress_b7;
      * pCLB_DYN_Cam_Height_Progress = signal_value;
      if( signal_value <= C_EYEQMSG_CALDYN_CLB_DYN_CAM_HEIGHT_PROGRESS_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Yaw_Progress
*
* FUNCTION ARGUMENTS:
*    uint8 * pCLB_DYN_Yaw_Progress - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Yaw_Progress
*    CLB_DYN_Yaw_Progress returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Yaw_Progress signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Yaw_Progress( uint8 * pCLB_DYN_Yaw_Progress )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pCLB_DYN_Yaw_Progress != C_NULL_P )
   {
      signal_value = EYEQMSG_CALDYN_ParamsApp_s.CLB_DYN_Yaw_Progress_b7;
      * pCLB_DYN_Yaw_Progress = signal_value;
      if( signal_value <= C_EYEQMSG_CALDYN_CLB_DYN_YAW_PROGRESS_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Pitch_Progress
*
* FUNCTION ARGUMENTS:
*    uint8 * pCLB_DYN_Pitch_Progress - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Pitch_Progress
*    CLB_DYN_Pitch_Progress returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Pitch_Progress signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Pitch_Progress( uint8 * pCLB_DYN_Pitch_Progress )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pCLB_DYN_Pitch_Progress != C_NULL_P )
   {
      signal_value = EYEQMSG_CALDYN_ParamsApp_s.CLB_DYN_Pitch_Progress_b7;
      * pCLB_DYN_Pitch_Progress = signal_value;
      if( signal_value <= C_EYEQMSG_CALDYN_CLB_DYN_PITCH_PROGRESS_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_Reserved_4
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_4
*    Reserved_4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_4 signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_Reserved_4( uint8 * pReserved_4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pReserved_4 != C_NULL_P )
   {
      signal_value = EYEQMSG_CALDYN_ParamsApp_s.Reserved_4_b4;
      * pReserved_4 = signal_value;
      if( signal_value <= C_EYEQMSG_CALDYN_RESERVED_4_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Roll_Progress
*
* FUNCTION ARGUMENTS:
*    uint8 * pCLB_DYN_Roll_Progress - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Roll_Progress
*    CLB_DYN_Roll_Progress returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Roll_Progress signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Roll_Progress( uint8 * pCLB_DYN_Roll_Progress )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pCLB_DYN_Roll_Progress != C_NULL_P )
   {
      signal_value = EYEQMSG_CALDYN_ParamsApp_s.CLB_DYN_Roll_Progress_b7;
      * pCLB_DYN_Roll_Progress = signal_value;
      if( signal_value <= C_EYEQMSG_CALDYN_CLB_DYN_ROLL_PROGRESS_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Total_Cam_Height_Time
*
* FUNCTION ARGUMENTS:
*    uint16 * pCLB_DYN_Total_Cam_Height_Time - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Total_Cam_Height_Time
*    CLB_DYN_Total_Cam_Height_Time returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Total_Cam_Height_Time signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Total_Cam_Height_Time( uint16 * pCLB_DYN_Total_Cam_Height_Time )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pCLB_DYN_Total_Cam_Height_Time != C_NULL_P )
   {
      signal_value = EYEQMSG_CALDYN_ParamsApp_s.CLB_DYN_Total_Cam_Height_Time_b12;
      * pCLB_DYN_Total_Cam_Height_Time = signal_value;
      if( signal_value <= C_EYEQMSG_CALDYN_CLB_DYN_TOTAL_CAM_HEIGHT_TIME_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_Reserved_5
*
* FUNCTION ARGUMENTS:
*    uint16 * pReserved_5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_5
*    Reserved_5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_5 signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_Reserved_5( uint16 * pReserved_5 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pReserved_5 != C_NULL_P )
   {
      signal_value = EYEQMSG_CALDYN_ParamsApp_s.Reserved_5_b13;
      * pReserved_5 = signal_value;
      if( signal_value <= C_EYEQMSG_CALDYN_RESERVED_5_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Total_Cam_Height_Dist
*
* FUNCTION ARGUMENTS:
*    uint16 * pCLB_DYN_Total_Cam_Height_Dist - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Total_Cam_Height_Dist
*    CLB_DYN_Total_Cam_Height_Dist returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Total_Cam_Height_Dist signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Total_Cam_Height_Dist( uint16 * pCLB_DYN_Total_Cam_Height_Dist )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pCLB_DYN_Total_Cam_Height_Dist != C_NULL_P )
   {
      signal_value = EYEQMSG_CALDYN_ParamsApp_s.CLB_DYN_Total_Cam_Height_Dist_b15;
      * pCLB_DYN_Total_Cam_Height_Dist = signal_value;
      if( signal_value <= C_EYEQMSG_CALDYN_CLB_DYN_TOTAL_CAM_HEIGHT_DIST_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Total_Yaw_Time
*
* FUNCTION ARGUMENTS:
*    uint16 * pCLB_DYN_Total_Yaw_Time - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Total_Yaw_Time
*    CLB_DYN_Total_Yaw_Time returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Total_Yaw_Time signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Total_Yaw_Time( uint16 * pCLB_DYN_Total_Yaw_Time )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pCLB_DYN_Total_Yaw_Time != C_NULL_P )
   {
      signal_value = EYEQMSG_CALDYN_ParamsApp_s.CLB_DYN_Total_Yaw_Time_b12;
      * pCLB_DYN_Total_Yaw_Time = signal_value;
      if( signal_value <= C_EYEQMSG_CALDYN_CLB_DYN_TOTAL_YAW_TIME_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_Reserved_6
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_6 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_6
*    Reserved_6 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_6 signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_Reserved_6( uint8 * pReserved_6 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pReserved_6 != C_NULL_P )
   {
      signal_value = EYEQMSG_CALDYN_ParamsApp_s.Reserved_6_b5;
      * pReserved_6 = signal_value;
      if( signal_value <= C_EYEQMSG_CALDYN_RESERVED_6_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Total_Yaw_Dist
*
* FUNCTION ARGUMENTS:
*    uint16 * pCLB_DYN_Total_Yaw_Dist - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Total_Yaw_Dist
*    CLB_DYN_Total_Yaw_Dist returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Total_Yaw_Dist signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Total_Yaw_Dist( uint16 * pCLB_DYN_Total_Yaw_Dist )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pCLB_DYN_Total_Yaw_Dist != C_NULL_P )
   {
      signal_value = EYEQMSG_CALDYN_ParamsApp_s.CLB_DYN_Total_Yaw_Dist_b15;
      * pCLB_DYN_Total_Yaw_Dist = signal_value;
      if( signal_value <= C_EYEQMSG_CALDYN_CLB_DYN_TOTAL_YAW_DIST_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Total_Pitch_Time
*
* FUNCTION ARGUMENTS:
*    uint16 * pCLB_DYN_Total_Pitch_Time - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Total_Pitch_Time
*    CLB_DYN_Total_Pitch_Time returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Total_Pitch_Time signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Total_Pitch_Time( uint16 * pCLB_DYN_Total_Pitch_Time )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pCLB_DYN_Total_Pitch_Time != C_NULL_P )
   {
      signal_value = EYEQMSG_CALDYN_ParamsApp_s.CLB_DYN_Total_Pitch_Time_b12;
      * pCLB_DYN_Total_Pitch_Time = signal_value;
      if( signal_value <= C_EYEQMSG_CALDYN_CLB_DYN_TOTAL_PITCH_TIME_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_Reserved_7
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_7 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_7
*    Reserved_7 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_7 signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_Reserved_7( uint8 * pReserved_7 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pReserved_7 != C_NULL_P )
   {
      signal_value = EYEQMSG_CALDYN_ParamsApp_s.Reserved_7_b5;
      * pReserved_7 = signal_value;
      if( signal_value <= C_EYEQMSG_CALDYN_RESERVED_7_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Total_Pitch_Dist
*
* FUNCTION ARGUMENTS:
*    uint16 * pCLB_DYN_Total_Pitch_Dist - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Total_Pitch_Dist
*    CLB_DYN_Total_Pitch_Dist returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Total_Pitch_Dist signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Total_Pitch_Dist( uint16 * pCLB_DYN_Total_Pitch_Dist )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pCLB_DYN_Total_Pitch_Dist != C_NULL_P )
   {
      signal_value = EYEQMSG_CALDYN_ParamsApp_s.CLB_DYN_Total_Pitch_Dist_b15;
      * pCLB_DYN_Total_Pitch_Dist = signal_value;
      if( signal_value <= C_EYEQMSG_CALDYN_CLB_DYN_TOTAL_PITCH_DIST_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Total_Roll_Time
*
* FUNCTION ARGUMENTS:
*    uint16 * pCLB_DYN_Total_Roll_Time - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Total_Roll_Time
*    CLB_DYN_Total_Roll_Time returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Total_Roll_Time signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Total_Roll_Time( uint16 * pCLB_DYN_Total_Roll_Time )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pCLB_DYN_Total_Roll_Time != C_NULL_P )
   {
      signal_value = EYEQMSG_CALDYN_ParamsApp_s.CLB_DYN_Total_Roll_Time_b12;
      * pCLB_DYN_Total_Roll_Time = signal_value;
      if( signal_value <= C_EYEQMSG_CALDYN_CLB_DYN_TOTAL_ROLL_TIME_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_Reserved_8
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_8 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_8
*    Reserved_8 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_8 signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_Reserved_8( uint8 * pReserved_8 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pReserved_8 != C_NULL_P )
   {
      signal_value = EYEQMSG_CALDYN_ParamsApp_s.Reserved_8_b5;
      * pReserved_8 = signal_value;
      if( signal_value <= C_EYEQMSG_CALDYN_RESERVED_8_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Total_Roll_Dist
*
* FUNCTION ARGUMENTS:
*    uint16 * pCLB_DYN_Total_Roll_Dist - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Total_Roll_Dist
*    CLB_DYN_Total_Roll_Dist returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Total_Roll_Dist signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Total_Roll_Dist( uint16 * pCLB_DYN_Total_Roll_Dist )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pCLB_DYN_Total_Roll_Dist != C_NULL_P )
   {
      signal_value = EYEQMSG_CALDYN_ParamsApp_s.CLB_DYN_Total_Roll_Dist_b15;
      * pCLB_DYN_Total_Roll_Dist = signal_value;
      if( signal_value <= C_EYEQMSG_CALDYN_CLB_DYN_TOTAL_ROLL_DIST_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Header_Buffer
*
* FUNCTION ARGUMENTS:
*    uint32 * pCLB_DYN_Header_Buffer - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Header_Buffer
*    CLB_DYN_Header_Buffer returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Header_Buffer signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Header_Buffer( uint32 * pCLB_DYN_Header_Buffer )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pCLB_DYN_Header_Buffer != C_NULL_P )
   {
      signal_value = EYEQMSG_CALDYN_ParamsApp_s.CLB_DYN_Header_Buffer_b17;
      * pCLB_DYN_Header_Buffer = signal_value;
      if( signal_value <= C_EYEQMSG_CALDYN_CLB_DYN_HEADER_BUFFER_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_CRC
*
* FUNCTION ARGUMENTS:
*    uint32 * pCLB_DYN_CRC - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_CRC
*    CLB_DYN_CRC returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_CRC signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_CRC( uint32 * pCLB_DYN_CRC )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pCLB_DYN_CRC != C_NULL_P )
   {
      signal_value = EYEQMSG_CALDYN_ParamsApp_s.CLB_DYN_CRC_b32;
      * pCLB_DYN_CRC = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Yaw_Deg
*
* FUNCTION ARGUMENTS:
*    float32 * pCLB_DYN_Yaw_Deg - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Yaw_Deg
*    CLB_DYN_Yaw_Deg returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Yaw_Deg signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Yaw_Deg( float32 * pCLB_DYN_Yaw_Deg )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float32SigDataType signal_value;
   
   if( pCLB_DYN_Yaw_Deg != C_NULL_P )
   {
      signal_value.u = EYEQMSG_CALDYN_ParamsApp_s.CLB_DYN_Yaw_Deg_sb32;
      * pCLB_DYN_Yaw_Deg = signal_value.f;
      if( (signal_value.f >= C_EYEQMSG_CALDYN_CLB_DYN_YAW_DEG_RMIN ) 
          && (signal_value.f <= C_EYEQMSG_CALDYN_CLB_DYN_YAW_DEG_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Pitch_Deg
*
* FUNCTION ARGUMENTS:
*    float32 * pCLB_DYN_Pitch_Deg - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Pitch_Deg
*    CLB_DYN_Pitch_Deg returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Pitch_Deg signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Pitch_Deg( float32 * pCLB_DYN_Pitch_Deg )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float32SigDataType signal_value;
   
   if( pCLB_DYN_Pitch_Deg != C_NULL_P )
   {
      signal_value.u = EYEQMSG_CALDYN_ParamsApp_s.CLB_DYN_Pitch_Deg_sb32;
      * pCLB_DYN_Pitch_Deg = signal_value.f;
      if( (signal_value.f >= C_EYEQMSG_CALDYN_CLB_DYN_PITCH_DEG_RMIN ) 
          && (signal_value.f <= C_EYEQMSG_CALDYN_CLB_DYN_PITCH_DEG_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Yaw_Px
*
* FUNCTION ARGUMENTS:
*    uint16 * pCLB_DYN_Yaw_Px - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Yaw_Px
*    CLB_DYN_Yaw_Px returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Yaw_Px signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Yaw_Px( uint16 * pCLB_DYN_Yaw_Px )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pCLB_DYN_Yaw_Px != C_NULL_P )
   {
      signal_value = EYEQMSG_CALDYN_ParamsApp_s.CLB_DYN_Yaw_Px_b16;
      * pCLB_DYN_Yaw_Px = signal_value;
      if( signal_value <= C_EYEQMSG_CALDYN_CLB_DYN_YAW_PX_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Pitch_Px
*
* FUNCTION ARGUMENTS:
*    uint16 * pCLB_DYN_Pitch_Px - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Pitch_Px
*    CLB_DYN_Pitch_Px returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Pitch_Px signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Pitch_Px( uint16 * pCLB_DYN_Pitch_Px )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pCLB_DYN_Pitch_Px != C_NULL_P )
   {
      signal_value = EYEQMSG_CALDYN_ParamsApp_s.CLB_DYN_Pitch_Px_b16;
      * pCLB_DYN_Pitch_Px = signal_value;
      if( signal_value <= C_EYEQMSG_CALDYN_CLB_DYN_PITCH_PX_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Roll
*
* FUNCTION ARGUMENTS:
*    float32 * pCLB_DYN_Roll - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Roll
*    CLB_DYN_Roll returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Roll signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Roll( float32 * pCLB_DYN_Roll )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float32SigDataType signal_value;
   
   if( pCLB_DYN_Roll != C_NULL_P )
   {
      signal_value.u = EYEQMSG_CALDYN_ParamsApp_s.CLB_DYN_Roll_sb32;
      * pCLB_DYN_Roll = signal_value.f;
      if( (signal_value.f >= C_EYEQMSG_CALDYN_CLB_DYN_ROLL_RMIN ) 
          && (signal_value.f <= C_EYEQMSG_CALDYN_CLB_DYN_ROLL_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Cam_Height
*
* FUNCTION ARGUMENTS:
*    uint16 * pCLB_DYN_Cam_Height - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Cam_Height
*    CLB_DYN_Cam_Height returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Cam_Height signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Cam_Height( uint16 * pCLB_DYN_Cam_Height )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pCLB_DYN_Cam_Height != C_NULL_P )
   {
      signal_value = EYEQMSG_CALDYN_ParamsApp_s.CLB_DYN_Cam_Height_b16;
      * pCLB_DYN_Cam_Height = signal_value;
      if( (signal_value >= C_EYEQMSG_CALDYN_CLB_DYN_CAM_HEIGHT_RMIN ) 
          && (signal_value <= C_EYEQMSG_CALDYN_CLB_DYN_CAM_HEIGHT_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Buffer
*
* FUNCTION ARGUMENTS:
*    uint16 * pCLB_DYN_Buffer - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Buffer
*    CLB_DYN_Buffer returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Buffer signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Buffer( uint16 * pCLB_DYN_Buffer )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pCLB_DYN_Buffer != C_NULL_P )
   {
      signal_value = EYEQMSG_CALDYN_ParamsApp_s.CLB_DYN_Buffer_b16;
      * pCLB_DYN_Buffer = signal_value;
      if( signal_value <= C_EYEQMSG_CALDYN_CLB_DYN_BUFFER_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

