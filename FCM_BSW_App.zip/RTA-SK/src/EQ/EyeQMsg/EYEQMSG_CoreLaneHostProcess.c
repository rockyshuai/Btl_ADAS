

/*****************************************************************************
                  Include files
*****************************************************************************/
/* The suggested include file order is: */
#include "EyeQ_defs.h"    /* EyeQ project common definitions file    */

#include "EYEQMSG_CoreLaneHostProcess.h"

/*****************************************************************************
                  Local symbolic constants
*****************************************************************************/
/*****************************************************************************
                  Local types, enums definitions
*****************************************************************************/
/*****************************************************************************
                  Local function prototypes
*****************************************************************************/
/*****************************************************************************
                  Local object definitions
*****************************************************************************/
/*****************************************************************************
                  Exported object definitions
*****************************************************************************/
EYEQMSG_CORELANEHOST_Params_t   EYEQMSG_CORELANEHOST_Params_s;
EYEQMSG_CORELANEHOST_Params_t   EYEQMSG_CORELANEHOST_ParamsApp_s;
/*****************************************************************************
                  Local function-like macros
*****************************************************************************/
/*****************************************************************************
                  Local defined macros
*****************************************************************************/
/*****************************************************************************
                  Function definitions
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvH_LH_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pLH_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Zero_byte
*    LH_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Zero_byte signal value of Virtual_HEADER_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvH_LH_Zero_byte( uint8 * pLH_Zero_byte )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pLH_Zero_byte != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELANEHOST_ParamsApp_s.EYEQMSG_CORELANEHOSTvH_Params_s.LH_Zero_byte_b8;
      * pLH_Zero_byte = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvH_LH_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pLH_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Protocol_Version
*    LH_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Protocol_Version signal value of Virtual_HEADER_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvH_LH_Protocol_Version( uint8 * pLH_Protocol_Version )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pLH_Protocol_Version != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELANEHOST_ParamsApp_s.EYEQMSG_CORELANEHOSTvH_Params_s.LH_Protocol_Version_b8;
      * pLH_Protocol_Version = signal_value;
      if( (signal_value >= C_EYEQMSG_CORELANEHOSTvH_LH_PROTOCOL_VERSION_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORELANEHOSTvH_LH_PROTOCOL_VERSION_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvH_LH_Sync_ID
*
* FUNCTION ARGUMENTS:
*    uint8 * pLH_Sync_ID - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Sync_ID
*    LH_Sync_ID returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Sync_ID signal value of Virtual_HEADER_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvH_LH_Sync_ID( uint8 * pLH_Sync_ID )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pLH_Sync_ID != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELANEHOST_ParamsApp_s.EYEQMSG_CORELANEHOSTvH_Params_s.LH_Sync_ID_b8;
      * pLH_Sync_ID = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvH_LH_Lanes_Count
*
* FUNCTION ARGUMENTS:
*    uint8 * pLH_Lanes_Count - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Lanes_Count
*    LH_Lanes_Count returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Lanes_Count signal value of Virtual_HEADER_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvH_LH_Lanes_Count( uint8 * pLH_Lanes_Count )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pLH_Lanes_Count != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELANEHOST_ParamsApp_s.EYEQMSG_CORELANEHOSTvH_Params_s.LH_Lanes_Count_b3;
      * pLH_Lanes_Count = signal_value;
      if( signal_value <= C_EYEQMSG_CORELANEHOSTvH_LH_LANES_COUNT_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvH_Reserved_1
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1
*    Reserved_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1 signal value of Virtual_HEADER_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvH_Reserved_1( uint8 * pReserved_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pReserved_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELANEHOST_ParamsApp_s.EYEQMSG_CORELANEHOSTvH_Params_s.Reserved_1_b5;
      * pReserved_1 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELANEHOSTvH_RESERVED_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvH_LH_Estimated_Width
*
* FUNCTION ARGUMENTS:
*    uint16 * pLH_Estimated_Width - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Estimated_Width
*    LH_Estimated_Width returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Estimated_Width signal value of Virtual_HEADER_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvH_LH_Estimated_Width( uint16 * pLH_Estimated_Width )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pLH_Estimated_Width != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELANEHOST_ParamsApp_s.EYEQMSG_CORELANEHOSTvH_Params_s.LH_Estimated_Width_b10;
      * pLH_Estimated_Width = signal_value;
      if( signal_value <= C_EYEQMSG_CORELANEHOSTvH_LH_ESTIMATED_WIDTH_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvH_Reserved_2
*
* FUNCTION ARGUMENTS:
*    uint32 * pReserved_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_2
*    Reserved_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_2 signal value of Virtual_HEADER_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvH_Reserved_2( uint32 * pReserved_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pReserved_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELANEHOST_ParamsApp_s.EYEQMSG_CORELANEHOSTvH_Params_s.Reserved_2_b22;
      * pReserved_2 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELANEHOSTvH_RESERVED_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_CRC_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint32 * pLH_CRC_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_CRC_0
*    LH_CRC_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_CRC_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_CRC_0( uint8 objIndx_u8, uint32 * pLH_CRC_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Host_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEHOSTvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLH_CRC_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEHOST_ParamsApp_s.EYEQMSG_CORELANEHOSTvO_Params_as[objIndx_u8].LH_CRC_0_b32;
         * pLH_CRC_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Is_Triggered_SDM_Type_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANEHOSTvOLHIsTriggeredSDMType0 * pLH_Is_Triggered_SDM_Type_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Is_Triggered_SDM_Type_0
*    LH_Is_Triggered_SDM_Type_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Is_Triggered_SDM_Type_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Is_Triggered_SDM_Type_0( uint8 objIndx_u8, CORELANEHOSTvOLHIsTriggeredSDMType0 * pLH_Is_Triggered_SDM_Type_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELANEHOSTvOLHIsTriggeredSDMType0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Host_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEHOSTvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLH_Is_Triggered_SDM_Type_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEHOST_ParamsApp_s.EYEQMSG_CORELANEHOSTvO_Params_as[objIndx_u8].LH_Is_Triggered_SDM_Type_0_b2;
         * pLH_Is_Triggered_SDM_Type_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEHOSTvO_LH_IS_TRIGGERED_SDM_TYPE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Is_Triggered_SDM_Model_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANEHOSTvOLHIsTriggeredSDMModel0 * pLH_Is_Triggered_SDM_Model_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Is_Triggered_SDM_Model_0
*    LH_Is_Triggered_SDM_Model_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Is_Triggered_SDM_Model_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Is_Triggered_SDM_Model_0( uint8 objIndx_u8, CORELANEHOSTvOLHIsTriggeredSDMModel0 * pLH_Is_Triggered_SDM_Model_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELANEHOSTvOLHIsTriggeredSDMModel0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Host_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEHOSTvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLH_Is_Triggered_SDM_Model_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEHOST_ParamsApp_s.EYEQMSG_CORELANEHOSTvO_Params_as[objIndx_u8].LH_Is_Triggered_SDM_Model_0_b2;
         * pLH_Is_Triggered_SDM_Model_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEHOSTvO_LH_IS_TRIGGERED_SDM_MODEL_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Track_ID_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLH_Track_ID_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Track_ID_0
*    LH_Track_ID_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Track_ID_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Track_ID_0( uint8 objIndx_u8, uint8 * pLH_Track_ID_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Host_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEHOSTvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLH_Track_ID_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEHOST_ParamsApp_s.EYEQMSG_CORELANEHOSTvO_Params_as[objIndx_u8].LH_Track_ID_0_b8;
         * pLH_Track_ID_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Age_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLH_Age_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Age_0
*    LH_Age_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Age_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Age_0( uint8 objIndx_u8, uint8 * pLH_Age_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Host_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEHOSTvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLH_Age_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEHOST_ParamsApp_s.EYEQMSG_CORELANEHOSTvO_Params_as[objIndx_u8].LH_Age_0_b8;
         * pLH_Age_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Confidence_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLH_Confidence_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Confidence_0
*    LH_Confidence_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Confidence_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Confidence_0( uint8 objIndx_u8, uint8 * pLH_Confidence_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Host_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEHOSTvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLH_Confidence_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEHOST_ParamsApp_s.EYEQMSG_CORELANEHOSTvO_Params_as[objIndx_u8].LH_Confidence_0_b7;
         * pLH_Confidence_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEHOSTvO_LH_CONFIDENCE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_Reserved_3_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_3_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_3_0
*    Reserved_3_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_3_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_Reserved_3_0( uint8 objIndx_u8, uint8 * pReserved_3_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Host_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEHOSTvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_3_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEHOST_ParamsApp_s.EYEQMSG_CORELANEHOSTvO_Params_as[objIndx_u8].Reserved_3_0_b5;
         * pReserved_3_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEHOSTvO_RESERVED_3_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Prediction_Reason_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANEHOSTvOLHPredictionReason0 * pLH_Prediction_Reason_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Prediction_Reason_0
*    LH_Prediction_Reason_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Prediction_Reason_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Prediction_Reason_0( uint8 objIndx_u8, CORELANEHOSTvOLHPredictionReason0 * pLH_Prediction_Reason_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELANEHOSTvOLHPredictionReason0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Host_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEHOSTvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLH_Prediction_Reason_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEHOST_ParamsApp_s.EYEQMSG_CORELANEHOSTvO_Params_as[objIndx_u8].LH_Prediction_Reason_0_b6;
         * pLH_Prediction_Reason_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Availability_State_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANEHOSTvOLHAvailabilityState0 * pLH_Availability_State_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Availability_State_0
*    LH_Availability_State_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Availability_State_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Availability_State_0( uint8 objIndx_u8, CORELANEHOSTvOLHAvailabilityState0 * pLH_Availability_State_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELANEHOSTvOLHAvailabilityState0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Host_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEHOSTvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLH_Availability_State_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEHOST_ParamsApp_s.EYEQMSG_CORELANEHOSTvO_Params_as[objIndx_u8].LH_Availability_State_0_b2;
         * pLH_Availability_State_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEHOSTvO_LH_AVAILABILITY_STATE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Color_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANEHOSTvOLHColor0 * pLH_Color_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Color_0
*    LH_Color_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Color_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Color_0( uint8 objIndx_u8, CORELANEHOSTvOLHColor0 * pLH_Color_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELANEHOSTvOLHColor0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Host_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEHOSTvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLH_Color_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEHOST_ParamsApp_s.EYEQMSG_CORELANEHOSTvO_Params_as[objIndx_u8].LH_Color_0_b2;
         * pLH_Color_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Color_Confidence_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLH_Color_Confidence_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Color_Confidence_0
*    LH_Color_Confidence_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Color_Confidence_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Color_Confidence_0( uint8 objIndx_u8, uint8 * pLH_Color_Confidence_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Host_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEHOSTvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLH_Color_Confidence_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEHOST_ParamsApp_s.EYEQMSG_CORELANEHOSTvO_Params_as[objIndx_u8].LH_Color_Confidence_0_b7;
         * pLH_Color_Confidence_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEHOSTvO_LH_COLOR_CONFIDENCE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Lanemark_Type_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANEHOSTvOLHLanemarkType0 * pLH_Lanemark_Type_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Lanemark_Type_0
*    LH_Lanemark_Type_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Lanemark_Type_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Lanemark_Type_0( uint8 objIndx_u8, CORELANEHOSTvOLHLanemarkType0 * pLH_Lanemark_Type_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELANEHOSTvOLHLanemarkType0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Host_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEHOSTvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLH_Lanemark_Type_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEHOST_ParamsApp_s.EYEQMSG_CORELANEHOSTvO_Params_as[objIndx_u8].LH_Lanemark_Type_0_b4;
         * pLH_Lanemark_Type_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEHOSTvO_LH_LANEMARK_TYPE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_DLM_Type_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANEHOSTvOLHDLMType0 * pLH_DLM_Type_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_DLM_Type_0
*    LH_DLM_Type_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_DLM_Type_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_DLM_Type_0( uint8 objIndx_u8, CORELANEHOSTvOLHDLMType0 * pLH_DLM_Type_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELANEHOSTvOLHDLMType0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Host_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEHOSTvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLH_DLM_Type_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEHOST_ParamsApp_s.EYEQMSG_CORELANEHOSTvO_Params_as[objIndx_u8].LH_DLM_Type_0_b3;
         * pLH_DLM_Type_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEHOSTvO_LH_DLM_TYPE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_DECEL_Type_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANEHOSTvOLHDECELType0 * pLH_DECEL_Type_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_DECEL_Type_0
*    LH_DECEL_Type_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_DECEL_Type_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_DECEL_Type_0( uint8 objIndx_u8, CORELANEHOSTvOLHDECELType0 * pLH_DECEL_Type_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELANEHOSTvOLHDECELType0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Host_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEHOSTvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLH_DECEL_Type_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEHOST_ParamsApp_s.EYEQMSG_CORELANEHOSTvO_Params_as[objIndx_u8].LH_DECEL_Type_0_b3;
         * pLH_DECEL_Type_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEHOSTvO_LH_DECEL_TYPE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_Reserved_4_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_4_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_4_0
*    Reserved_4_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_4_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_Reserved_4_0( uint8 objIndx_u8, uint8 * pReserved_4_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Host_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEHOSTvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_4_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEHOST_ParamsApp_s.EYEQMSG_CORELANEHOSTvO_Params_as[objIndx_u8].Reserved_4_0_b5;
         * pReserved_4_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEHOSTvO_RESERVED_4_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Lanemark_Type_Conf_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLH_Lanemark_Type_Conf_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Lanemark_Type_Conf_0
*    LH_Lanemark_Type_Conf_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Lanemark_Type_Conf_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Lanemark_Type_Conf_0( uint8 objIndx_u8, uint8 * pLH_Lanemark_Type_Conf_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Host_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEHOSTvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLH_Lanemark_Type_Conf_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEHOST_ParamsApp_s.EYEQMSG_CORELANEHOSTvO_Params_as[objIndx_u8].LH_Lanemark_Type_Conf_0_b7;
         * pLH_Lanemark_Type_Conf_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEHOSTvO_LH_LANEMARK_TYPE_CONF_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Side_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANEHOSTvOLHSide0 * pLH_Side_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Side_0
*    LH_Side_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Side_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Side_0( uint8 objIndx_u8, CORELANEHOSTvOLHSide0 * pLH_Side_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELANEHOSTvOLHSide0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Host_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEHOSTvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLH_Side_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEHOST_ParamsApp_s.EYEQMSG_CORELANEHOSTvO_Params_as[objIndx_u8].LH_Side_0_b2;
         * pLH_Side_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEHOSTvO_LH_SIDE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Crossing_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANEHOSTvOLHCrossing0 * pLH_Crossing_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Crossing_0
*    LH_Crossing_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Crossing_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Crossing_0( uint8 objIndx_u8, CORELANEHOSTvOLHCrossing0 * pLH_Crossing_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELANEHOSTvOLHCrossing0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Host_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEHOSTvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLH_Crossing_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEHOST_ParamsApp_s.EYEQMSG_CORELANEHOSTvO_Params_as[objIndx_u8].LH_Crossing_0_b1;
         * pLH_Crossing_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Marker_Width_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLH_Marker_Width_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Marker_Width_0
*    LH_Marker_Width_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Marker_Width_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Marker_Width_0( uint8 objIndx_u8, uint8 * pLH_Marker_Width_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Host_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEHOSTvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLH_Marker_Width_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEHOST_ParamsApp_s.EYEQMSG_CORELANEHOSTvO_Params_as[objIndx_u8].LH_Marker_Width_0_b8;
         * pLH_Marker_Width_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEHOSTvO_LH_MARKER_WIDTH_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Marker_Width_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLH_Marker_Width_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Marker_Width_STD_0
*    LH_Marker_Width_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Marker_Width_STD_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Marker_Width_STD_0( uint8 objIndx_u8, uint8 * pLH_Marker_Width_STD_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Host_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEHOSTvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLH_Marker_Width_STD_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEHOST_ParamsApp_s.EYEQMSG_CORELANEHOSTvO_Params_as[objIndx_u8].LH_Marker_Width_STD_0_b7;
         * pLH_Marker_Width_STD_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEHOSTvO_LH_MARKER_WIDTH_STD_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_Reserved_5_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_5_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_5_0
*    Reserved_5_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_5_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_Reserved_5_0( uint8 objIndx_u8, uint8 * pReserved_5_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Host_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEHOSTvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_5_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEHOST_ParamsApp_s.EYEQMSG_CORELANEHOSTvO_Params_as[objIndx_u8].Reserved_5_0_b7;
         * pReserved_5_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEHOSTvO_RESERVED_5_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Dash_Average_Length_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLH_Dash_Average_Length_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Dash_Average_Length_0
*    LH_Dash_Average_Length_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Dash_Average_Length_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Dash_Average_Length_0( uint8 objIndx_u8, uint8 * pLH_Dash_Average_Length_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Host_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEHOSTvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLH_Dash_Average_Length_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEHOST_ParamsApp_s.EYEQMSG_CORELANEHOSTvO_Params_as[objIndx_u8].LH_Dash_Average_Length_0_b8;
         * pLH_Dash_Average_Length_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEHOSTvO_LH_DASH_AVERAGE_LENGTH_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Dash_Average_Gap_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLH_Dash_Average_Gap_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Dash_Average_Gap_0
*    LH_Dash_Average_Gap_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Dash_Average_Gap_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Dash_Average_Gap_0( uint8 objIndx_u8, uint8 * pLH_Dash_Average_Gap_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Host_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEHOSTvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLH_Dash_Average_Gap_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEHOST_ParamsApp_s.EYEQMSG_CORELANEHOSTvO_Params_as[objIndx_u8].LH_Dash_Average_Gap_0_b8;
         * pLH_Dash_Average_Gap_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEHOSTvO_LH_DASH_AVERAGE_GAP_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Is_Multi_Clothoid_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANEHOSTvOLHIsMultiClothoid0 * pLH_Is_Multi_Clothoid_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Is_Multi_Clothoid_0
*    LH_Is_Multi_Clothoid_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Is_Multi_Clothoid_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Is_Multi_Clothoid_0( uint8 objIndx_u8, CORELANEHOSTvOLHIsMultiClothoid0 * pLH_Is_Multi_Clothoid_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELANEHOSTvOLHIsMultiClothoid0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Host_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEHOSTvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLH_Is_Multi_Clothoid_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEHOST_ParamsApp_s.EYEQMSG_CORELANEHOSTvO_Params_as[objIndx_u8].LH_Is_Multi_Clothoid_0_b1;
         * pLH_Is_Multi_Clothoid_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_Reserved_6_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pReserved_6_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_6_0
*    Reserved_6_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_6_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_Reserved_6_0( uint8 objIndx_u8, uint16 * pReserved_6_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Host_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEHOSTvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_6_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEHOST_ParamsApp_s.EYEQMSG_CORELANEHOSTvO_Params_as[objIndx_u8].Reserved_6_0_b15;
         * pReserved_6_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEHOSTvO_RESERVED_6_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Line_First_C0_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    float32 * pLH_Line_First_C0_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Line_First_C0_0
*    LH_Line_First_C0_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Line_First_C0_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Line_First_C0_0( uint8 objIndx_u8, float32 * pLH_Line_First_C0_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float32SigDataType signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Host_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEHOSTvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLH_Line_First_C0_0 != C_NULL_P )
      {
         signal_value.u = EYEQMSG_CORELANEHOST_ParamsApp_s.EYEQMSG_CORELANEHOSTvO_Params_as[objIndx_u8].LH_Line_First_C0_0_sb32;
         * pLH_Line_First_C0_0 = signal_value.f;
         if( (signal_value.f >= C_EYEQMSG_CORELANEHOSTvO_LH_LINE_FIRST_C0_0_RMIN ) 
             && (signal_value.f <= C_EYEQMSG_CORELANEHOSTvO_LH_LINE_FIRST_C0_0_RMAX ) )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Line_First_C1_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    float32 * pLH_Line_First_C1_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Line_First_C1_0
*    LH_Line_First_C1_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Line_First_C1_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Line_First_C1_0( uint8 objIndx_u8, float32 * pLH_Line_First_C1_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float32SigDataType signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Host_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEHOSTvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLH_Line_First_C1_0 != C_NULL_P )
      {
         signal_value.u = EYEQMSG_CORELANEHOST_ParamsApp_s.EYEQMSG_CORELANEHOSTvO_Params_as[objIndx_u8].LH_Line_First_C1_0_sb32;
         * pLH_Line_First_C1_0 = signal_value.f;
         if( (signal_value.f >= C_EYEQMSG_CORELANEHOSTvO_LH_LINE_FIRST_C1_0_RMIN ) 
             && (signal_value.f <= C_EYEQMSG_CORELANEHOSTvO_LH_LINE_FIRST_C1_0_RMAX ) )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Line_First_C2_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    float32 * pLH_Line_First_C2_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Line_First_C2_0
*    LH_Line_First_C2_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Line_First_C2_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Line_First_C2_0( uint8 objIndx_u8, float32 * pLH_Line_First_C2_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float32SigDataType signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Host_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEHOSTvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLH_Line_First_C2_0 != C_NULL_P )
      {
         signal_value.u = EYEQMSG_CORELANEHOST_ParamsApp_s.EYEQMSG_CORELANEHOSTvO_Params_as[objIndx_u8].LH_Line_First_C2_0_sb32;
         * pLH_Line_First_C2_0 = signal_value.f;
         if( (signal_value.f >= C_EYEQMSG_CORELANEHOSTvO_LH_LINE_FIRST_C2_0_RMIN ) 
             && (signal_value.f <= C_EYEQMSG_CORELANEHOSTvO_LH_LINE_FIRST_C2_0_RMAX ) )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Line_First_C3_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    float32 * pLH_Line_First_C3_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Line_First_C3_0
*    LH_Line_First_C3_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Line_First_C3_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Line_First_C3_0( uint8 objIndx_u8, float32 * pLH_Line_First_C3_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float32SigDataType signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Host_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEHOSTvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLH_Line_First_C3_0 != C_NULL_P )
      {
         signal_value.u = EYEQMSG_CORELANEHOST_ParamsApp_s.EYEQMSG_CORELANEHOSTvO_Params_as[objIndx_u8].LH_Line_First_C3_0_sb32;
         * pLH_Line_First_C3_0 = signal_value.f;
         if( (signal_value.f >= C_EYEQMSG_CORELANEHOSTvO_LH_LINE_FIRST_C3_0_RMIN ) 
             && (signal_value.f <= C_EYEQMSG_CORELANEHOSTvO_LH_LINE_FIRST_C3_0_RMAX ) )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_First_VR_Start_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLH_First_VR_Start_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_First_VR_Start_0
*    LH_First_VR_Start_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_First_VR_Start_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_First_VR_Start_0( uint8 objIndx_u8, uint16 * pLH_First_VR_Start_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Host_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEHOSTvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLH_First_VR_Start_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEHOST_ParamsApp_s.EYEQMSG_CORELANEHOSTvO_Params_as[objIndx_u8].LH_First_VR_Start_0_b15;
         * pLH_First_VR_Start_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEHOSTvO_LH_FIRST_VR_START_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_First_VR_End_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLH_First_VR_End_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_First_VR_End_0
*    LH_First_VR_End_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_First_VR_End_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_First_VR_End_0( uint8 objIndx_u8, uint16 * pLH_First_VR_End_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Host_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEHOSTvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLH_First_VR_End_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEHOST_ParamsApp_s.EYEQMSG_CORELANEHOSTvO_Params_as[objIndx_u8].LH_First_VR_End_0_b15;
         * pLH_First_VR_End_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEHOSTvO_LH_FIRST_VR_END_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_Reserved_7_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_7_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_7_0
*    Reserved_7_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_7_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_Reserved_7_0( uint8 objIndx_u8, uint8 * pReserved_7_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Host_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEHOSTvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_7_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEHOST_ParamsApp_s.EYEQMSG_CORELANEHOSTvO_Params_as[objIndx_u8].Reserved_7_0_b2;
         * pReserved_7_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEHOSTvO_RESERVED_7_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_First_Measured_VR_End_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLH_First_Measured_VR_End_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_First_Measured_VR_End_0
*    LH_First_Measured_VR_End_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_First_Measured_VR_End_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_First_Measured_VR_End_0( uint8 objIndx_u8, uint16 * pLH_First_Measured_VR_End_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Host_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEHOSTvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLH_First_Measured_VR_End_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEHOST_ParamsApp_s.EYEQMSG_CORELANEHOSTvO_Params_as[objIndx_u8].LH_First_Measured_VR_End_0_b15;
         * pLH_First_Measured_VR_End_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEHOSTvO_LH_FIRST_MEASURED_VR_END_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Second_Measured_VR_End_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLH_Second_Measured_VR_End_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Second_Measured_VR_End_0
*    LH_Second_Measured_VR_End_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Second_Measured_VR_End_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Second_Measured_VR_End_0( uint8 objIndx_u8, uint16 * pLH_Second_Measured_VR_End_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Host_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEHOSTvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLH_Second_Measured_VR_End_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEHOST_ParamsApp_s.EYEQMSG_CORELANEHOSTvO_Params_as[objIndx_u8].LH_Second_Measured_VR_End_0_b15;
         * pLH_Second_Measured_VR_End_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEHOSTvO_LH_SECOND_MEASURED_VR_END_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_Reserved_8_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_8_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_8_0
*    Reserved_8_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_8_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_Reserved_8_0( uint8 objIndx_u8, uint8 * pReserved_8_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Host_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEHOSTvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_8_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEHOST_ParamsApp_s.EYEQMSG_CORELANEHOSTvO_Params_as[objIndx_u8].Reserved_8_0_b2;
         * pReserved_8_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEHOSTvO_RESERVED_8_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Line_Second_C0_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    float32 * pLH_Line_Second_C0_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Line_Second_C0_0
*    LH_Line_Second_C0_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Line_Second_C0_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Line_Second_C0_0( uint8 objIndx_u8, float32 * pLH_Line_Second_C0_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float32SigDataType signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Host_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEHOSTvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLH_Line_Second_C0_0 != C_NULL_P )
      {
         signal_value.u = EYEQMSG_CORELANEHOST_ParamsApp_s.EYEQMSG_CORELANEHOSTvO_Params_as[objIndx_u8].LH_Line_Second_C0_0_sb32;
         * pLH_Line_Second_C0_0 = signal_value.f;
         if( (signal_value.f >= C_EYEQMSG_CORELANEHOSTvO_LH_LINE_SECOND_C0_0_RMIN ) 
             && (signal_value.f <= C_EYEQMSG_CORELANEHOSTvO_LH_LINE_SECOND_C0_0_RMAX ) )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Line_Second_C1_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    float32 * pLH_Line_Second_C1_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Line_Second_C1_0
*    LH_Line_Second_C1_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Line_Second_C1_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Line_Second_C1_0( uint8 objIndx_u8, float32 * pLH_Line_Second_C1_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float32SigDataType signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Host_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEHOSTvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLH_Line_Second_C1_0 != C_NULL_P )
      {
         signal_value.u = EYEQMSG_CORELANEHOST_ParamsApp_s.EYEQMSG_CORELANEHOSTvO_Params_as[objIndx_u8].LH_Line_Second_C1_0_sb32;
         * pLH_Line_Second_C1_0 = signal_value.f;
         if( (signal_value.f >= C_EYEQMSG_CORELANEHOSTvO_LH_LINE_SECOND_C1_0_RMIN ) 
             && (signal_value.f <= C_EYEQMSG_CORELANEHOSTvO_LH_LINE_SECOND_C1_0_RMAX ) )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Line_Second_C2_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    float32 * pLH_Line_Second_C2_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Line_Second_C2_0
*    LH_Line_Second_C2_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Line_Second_C2_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Line_Second_C2_0( uint8 objIndx_u8, float32 * pLH_Line_Second_C2_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float32SigDataType signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Host_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEHOSTvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLH_Line_Second_C2_0 != C_NULL_P )
      {
         signal_value.u = EYEQMSG_CORELANEHOST_ParamsApp_s.EYEQMSG_CORELANEHOSTvO_Params_as[objIndx_u8].LH_Line_Second_C2_0_sb32;
         * pLH_Line_Second_C2_0 = signal_value.f;
         if( (signal_value.f >= C_EYEQMSG_CORELANEHOSTvO_LH_LINE_SECOND_C2_0_RMIN ) 
             && (signal_value.f <= C_EYEQMSG_CORELANEHOSTvO_LH_LINE_SECOND_C2_0_RMAX ) )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Line_Second_C3_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    float32 * pLH_Line_Second_C3_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Line_Second_C3_0
*    LH_Line_Second_C3_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Line_Second_C3_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Line_Second_C3_0( uint8 objIndx_u8, float32 * pLH_Line_Second_C3_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float32SigDataType signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Host_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEHOSTvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLH_Line_Second_C3_0 != C_NULL_P )
      {
         signal_value.u = EYEQMSG_CORELANEHOST_ParamsApp_s.EYEQMSG_CORELANEHOSTvO_Params_as[objIndx_u8].LH_Line_Second_C3_0_sb32;
         * pLH_Line_Second_C3_0 = signal_value.f;
         if( (signal_value.f >= C_EYEQMSG_CORELANEHOSTvO_LH_LINE_SECOND_C3_0_RMIN ) 
             && (signal_value.f <= C_EYEQMSG_CORELANEHOSTvO_LH_LINE_SECOND_C3_0_RMAX ) )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Second_VR_Start_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLH_Second_VR_Start_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Second_VR_Start_0
*    LH_Second_VR_Start_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Second_VR_Start_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Second_VR_Start_0( uint8 objIndx_u8, uint16 * pLH_Second_VR_Start_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Host_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEHOSTvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLH_Second_VR_Start_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEHOST_ParamsApp_s.EYEQMSG_CORELANEHOSTvO_Params_as[objIndx_u8].LH_Second_VR_Start_0_b15;
         * pLH_Second_VR_Start_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEHOSTvO_LH_SECOND_VR_START_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Second_VR_End_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLH_Second_VR_End_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Second_VR_End_0
*    LH_Second_VR_End_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Second_VR_End_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Second_VR_End_0( uint8 objIndx_u8, uint16 * pLH_Second_VR_End_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Host_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEHOSTvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLH_Second_VR_End_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEHOST_ParamsApp_s.EYEQMSG_CORELANEHOSTvO_Params_as[objIndx_u8].LH_Second_VR_End_0_b15;
         * pLH_Second_VR_End_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEHOSTvO_LH_SECOND_VR_END_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEHOSTvO_LH_Detection_Source_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANEHOSTvOLHDetectionSource0 * pLH_Detection_Source_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LH_Detection_Source_0
*    LH_Detection_Source_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LH_Detection_Source_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Host_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEHOSTvO_LH_Detection_Source_0( uint8 objIndx_u8, CORELANEHOSTvOLHDetectionSource0 * pLH_Detection_Source_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELANEHOSTvOLHDetectionSource0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Host_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEHOSTvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLH_Detection_Source_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEHOST_ParamsApp_s.EYEQMSG_CORELANEHOSTvO_Params_as[objIndx_u8].LH_Detection_Source_0_b2;
         * pLH_Detection_Source_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_CORELANEHOST_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_CORELANEHOST_Params_t * pCore_Lanes_Host_protocol - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_Lanes_Host_protocol message 
*    Core_Lanes_Host_protocol message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_Lanes_Host_protocol message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_CORELANEHOST_ParamsApp_MsgDataStruct( EYEQMSG_CORELANEHOST_Params_t * pCore_Lanes_Host_protocol )
{
   Std_ReturnType status = C_SIG_INVALID;
   if( pCore_Lanes_Host_protocol != C_NULL_P )
   {
      status = C_SIG_VALID;
      * pCore_Lanes_Host_protocol = EYEQMSG_CORELANEHOST_ParamsApp_s;
   }
   return ( status );
}

