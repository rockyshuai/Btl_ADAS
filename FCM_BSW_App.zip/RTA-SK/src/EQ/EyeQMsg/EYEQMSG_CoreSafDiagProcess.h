#ifndef _EYEQMSG_CORESAFDIAGPROCESS_H_
#define _EYEQMSG_CORESAFDIAGPROCESS_H_

/*****************************************************************************
                  Included header files
*****************************************************************************/
#include <Std_Types.h>

/*****************************************************************************
                  Include files
*****************************************************************************/
/*****************************************************************************
                  Exported symbolic constants
*****************************************************************************/

/* Datagram message ID */
#define C_EYEQMSG_CORESAFDIAG_MSG_ID                          ( 0x74U )

/* Datagram message lengths */
#define C_EYEQMSG_CORESAFDIAG_MSG_LEN                         ( sizeof(EYEQMSG_CORESAFDIAG_Params_t) )

/* Protocol ENUMs */

/* MCU output messages */

/* Core_Safety_Diagnostics_protocol Enums */
/* SD_Bit_63_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit63;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_63_OK                    ( CORESAFDIAGSDBit63 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_63_ERROR                 ( CORESAFDIAGSDBit63 ) ( 1U )

/* SD_Bit_63_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_63_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_63_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_63_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_63_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_63_OFFSET                ( 0U )

/* SD_Bit_62_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit62;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_62_OK                    ( CORESAFDIAGSDBit62 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_62_ERROR                 ( CORESAFDIAGSDBit62 ) ( 1U )

/* SD_Bit_62_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_62_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_62_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_62_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_62_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_62_OFFSET                ( 0U )

/* SD_Bit_61_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit61;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_61_OK                    ( CORESAFDIAGSDBit61 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_61_ERROR                 ( CORESAFDIAGSDBit61 ) ( 1U )

/* SD_Bit_61_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_61_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_61_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_61_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_61_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_61_OFFSET                ( 0U )

/* SD_Bit_60_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit60;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_60_OK                    ( CORESAFDIAGSDBit60 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_60_ERROR                 ( CORESAFDIAGSDBit60 ) ( 1U )

/* SD_Bit_60_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_60_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_60_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_60_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_60_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_60_OFFSET                ( 0U )

/* SD_Bit_59_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit59;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_59_OK                    ( CORESAFDIAGSDBit59 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_59_ERROR                 ( CORESAFDIAGSDBit59 ) ( 1U )

/* SD_Bit_59_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_59_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_59_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_59_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_59_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_59_OFFSET                ( 0U )

/* SD_Bit_58_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit58;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_58_OK                    ( CORESAFDIAGSDBit58 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_58_ERROR                 ( CORESAFDIAGSDBit58 ) ( 1U )

/* SD_Bit_58_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_58_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_58_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_58_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_58_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_58_OFFSET                ( 0U )

/* SD_Bit_57_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit57;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_57_OK                    ( CORESAFDIAGSDBit57 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_57_ERROR                 ( CORESAFDIAGSDBit57 ) ( 1U )

/* SD_Bit_57_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_57_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_57_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_57_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_57_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_57_OFFSET                ( 0U )

/* SD_Bit_56_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit56;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_56_OK                    ( CORESAFDIAGSDBit56 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_56_ERROR                 ( CORESAFDIAGSDBit56 ) ( 1U )

/* SD_Bit_56_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_56_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_56_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_56_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_56_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_56_OFFSET                ( 0U )

/* SD_Bit_55_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit55;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_55_OK                    ( CORESAFDIAGSDBit55 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_55_ERROR                 ( CORESAFDIAGSDBit55 ) ( 1U )

/* SD_Bit_55_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_55_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_55_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_55_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_55_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_55_OFFSET                ( 0U )

/* SD_Bit_54_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit54;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_54_OK                    ( CORESAFDIAGSDBit54 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_54_ERROR                 ( CORESAFDIAGSDBit54 ) ( 1U )

/* SD_Bit_54_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_54_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_54_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_54_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_54_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_54_OFFSET                ( 0U )

/* SD_Bit_53_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit53;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_53_OK                    ( CORESAFDIAGSDBit53 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_53_ERROR                 ( CORESAFDIAGSDBit53 ) ( 1U )

/* SD_Bit_53_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_53_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_53_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_53_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_53_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_53_OFFSET                ( 0U )

/* SD_Bit_52_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit52;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_52_OK                    ( CORESAFDIAGSDBit52 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_52_ERROR                 ( CORESAFDIAGSDBit52 ) ( 1U )

/* SD_Bit_52_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_52_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_52_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_52_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_52_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_52_OFFSET                ( 0U )

/* SD_Bit_51_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit51;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_51_OK                    ( CORESAFDIAGSDBit51 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_51_ERROR                 ( CORESAFDIAGSDBit51 ) ( 1U )

/* SD_Bit_51_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_51_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_51_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_51_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_51_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_51_OFFSET                ( 0U )

/* SD_Bit_50_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit50;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_50_OK                    ( CORESAFDIAGSDBit50 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_50_ERROR                 ( CORESAFDIAGSDBit50 ) ( 1U )

/* SD_Bit_50_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_50_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_50_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_50_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_50_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_50_OFFSET                ( 0U )

/* SD_Bit_49_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit49;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_49_OK                    ( CORESAFDIAGSDBit49 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_49_ERROR                 ( CORESAFDIAGSDBit49 ) ( 1U )

/* SD_Bit_49_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_49_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_49_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_49_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_49_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_49_OFFSET                ( 0U )

/* SD_Bit_48_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit48;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_48_OK                    ( CORESAFDIAGSDBit48 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_48_ERROR                 ( CORESAFDIAGSDBit48 ) ( 1U )

/* SD_Bit_48_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_48_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_48_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_48_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_48_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_48_OFFSET                ( 0U )

/* SD_Bit_47_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit47;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_47_OK                    ( CORESAFDIAGSDBit47 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_47_ERROR                 ( CORESAFDIAGSDBit47 ) ( 1U )

/* SD_Bit_47_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_47_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_47_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_47_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_47_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_47_OFFSET                ( 0U )

/* SD_Bit_46_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit46;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_46_OK                    ( CORESAFDIAGSDBit46 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_46_ERROR                 ( CORESAFDIAGSDBit46 ) ( 1U )

/* SD_Bit_46_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_46_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_46_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_46_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_46_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_46_OFFSET                ( 0U )

/* SD_Bit_45_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit45;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_45_OK                    ( CORESAFDIAGSDBit45 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_45_ERROR                 ( CORESAFDIAGSDBit45 ) ( 1U )

/* SD_Bit_45_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_45_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_45_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_45_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_45_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_45_OFFSET                ( 0U )

/* SD_Bit_44_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit44;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_44_OK                    ( CORESAFDIAGSDBit44 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_44_ERROR                 ( CORESAFDIAGSDBit44 ) ( 1U )

/* SD_Bit_44_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_44_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_44_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_44_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_44_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_44_OFFSET                ( 0U )

/* SD_Bit_43_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit43;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_43_OK                    ( CORESAFDIAGSDBit43 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_43_ERROR                 ( CORESAFDIAGSDBit43 ) ( 1U )

/* SD_Bit_43_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_43_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_43_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_43_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_43_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_43_OFFSET                ( 0U )

/* SD_Bit_42_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit42;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_42_OK                    ( CORESAFDIAGSDBit42 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_42_ERROR                 ( CORESAFDIAGSDBit42 ) ( 1U )

/* SD_Bit_42_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_42_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_42_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_42_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_42_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_42_OFFSET                ( 0U )

/* SD_Bit_41_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit41;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_41_OK                    ( CORESAFDIAGSDBit41 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_41_ERROR                 ( CORESAFDIAGSDBit41 ) ( 1U )

/* SD_Bit_41_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_41_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_41_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_41_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_41_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_41_OFFSET                ( 0U )

/* SD_Bit_40_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit40;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_40_OK                    ( CORESAFDIAGSDBit40 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_40_ERROR                 ( CORESAFDIAGSDBit40 ) ( 1U )

/* SD_Bit_40_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_40_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_40_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_40_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_40_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_40_OFFSET                ( 0U )

/* SD_Bit_39_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit39;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_39_OK                    ( CORESAFDIAGSDBit39 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_39_ERROR                 ( CORESAFDIAGSDBit39 ) ( 1U )

/* SD_Bit_39_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_39_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_39_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_39_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_39_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_39_OFFSET                ( 0U )

/* SD_Bit_38_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit38;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_38_OK                    ( CORESAFDIAGSDBit38 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_38_ERROR                 ( CORESAFDIAGSDBit38 ) ( 1U )

/* SD_Bit_38_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_38_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_38_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_38_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_38_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_38_OFFSET                ( 0U )

/* SD_Bit_37_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit37;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_37_OK                    ( CORESAFDIAGSDBit37 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_37_ERROR                 ( CORESAFDIAGSDBit37 ) ( 1U )

/* SD_Bit_37_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_37_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_37_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_37_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_37_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_37_OFFSET                ( 0U )

/* SD_Bit_36_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit36;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_36_OK                    ( CORESAFDIAGSDBit36 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_36_ERROR                 ( CORESAFDIAGSDBit36 ) ( 1U )

/* SD_Bit_36_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_36_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_36_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_36_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_36_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_36_OFFSET                ( 0U )

/* SD_Bit_35_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit35;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_35_OK                    ( CORESAFDIAGSDBit35 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_35_ERROR                 ( CORESAFDIAGSDBit35 ) ( 1U )

/* SD_Bit_35_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_35_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_35_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_35_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_35_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_35_OFFSET                ( 0U )

/* SD_Bit_34_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit34;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_34_OK                    ( CORESAFDIAGSDBit34 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_34_ERROR                 ( CORESAFDIAGSDBit34 ) ( 1U )

/* SD_Bit_34_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_34_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_34_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_34_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_34_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_34_OFFSET                ( 0U )

/* SD_Bit_33_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit33;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_33_OK                    ( CORESAFDIAGSDBit33 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_33_ERROR                 ( CORESAFDIAGSDBit33 ) ( 1U )

/* SD_Bit_33_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_33_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_33_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_33_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_33_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_33_OFFSET                ( 0U )

/* SD_Bit_32_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit32;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_32_OK                    ( CORESAFDIAGSDBit32 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_32_ERROR                 ( CORESAFDIAGSDBit32 ) ( 1U )

/* SD_Bit_32_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_32_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_32_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_32_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_32_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_32_OFFSET                ( 0U )

/* SD_Bit_31_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit31;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_31_OK                    ( CORESAFDIAGSDBit31 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_31_ERROR                 ( CORESAFDIAGSDBit31 ) ( 1U )

/* SD_Bit_31_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_31_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_31_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_31_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_31_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_31_OFFSET                ( 0U )

/* SD_Bit_30_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit30;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_30_OK                    ( CORESAFDIAGSDBit30 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_30_ERROR                 ( CORESAFDIAGSDBit30 ) ( 1U )

/* SD_Bit_30_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_30_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_30_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_30_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_30_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_30_OFFSET                ( 0U )

/* SD_Bit_29_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit29;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_29_OK                    ( CORESAFDIAGSDBit29 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_29_ERROR                 ( CORESAFDIAGSDBit29 ) ( 1U )

/* SD_Bit_29_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_29_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_29_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_29_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_29_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_29_OFFSET                ( 0U )

/* SD_Bit_28_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit28;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_28_OK                    ( CORESAFDIAGSDBit28 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_28_ERROR                 ( CORESAFDIAGSDBit28 ) ( 1U )

/* SD_Bit_28_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_28_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_28_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_28_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_28_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_28_OFFSET                ( 0U )

/* SD_Bit_27_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit27;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_27_OK                    ( CORESAFDIAGSDBit27 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_27_ERROR                 ( CORESAFDIAGSDBit27 ) ( 1U )

/* SD_Bit_27_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_27_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_27_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_27_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_27_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_27_OFFSET                ( 0U )

/* SD_Bit_26_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit26;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_26_OK                    ( CORESAFDIAGSDBit26 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_26_ERROR                 ( CORESAFDIAGSDBit26 ) ( 1U )

/* SD_Bit_26_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_26_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_26_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_26_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_26_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_26_OFFSET                ( 0U )

/* SD_Bit_25_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit25;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_25_OK                    ( CORESAFDIAGSDBit25 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_25_ERROR                 ( CORESAFDIAGSDBit25 ) ( 1U )

/* SD_Bit_25_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_25_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_25_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_25_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_25_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_25_OFFSET                ( 0U )

/* SD_Bit_24_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit24;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_24_OK                    ( CORESAFDIAGSDBit24 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_24_ERROR                 ( CORESAFDIAGSDBit24 ) ( 1U )

/* SD_Bit_24_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_24_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_24_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_24_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_24_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_24_OFFSET                ( 0U )

/* SD_Bit_23_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit23;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_23_OK                    ( CORESAFDIAGSDBit23 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_23_ERROR                 ( CORESAFDIAGSDBit23 ) ( 1U )

/* SD_Bit_23_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_23_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_23_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_23_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_23_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_23_OFFSET                ( 0U )

/* SD_Bit_22_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit22;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_22_OK                    ( CORESAFDIAGSDBit22 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_22_ERROR                 ( CORESAFDIAGSDBit22 ) ( 1U )

/* SD_Bit_22_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_22_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_22_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_22_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_22_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_22_OFFSET                ( 0U )

/* SD_Bit_21_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit21;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_21_OK                    ( CORESAFDIAGSDBit21 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_21_ERROR                 ( CORESAFDIAGSDBit21 ) ( 1U )

/* SD_Bit_21_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_21_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_21_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_21_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_21_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_21_OFFSET                ( 0U )

/* SD_Bit_20_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit20;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_20_OK                    ( CORESAFDIAGSDBit20 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_20_ERROR                 ( CORESAFDIAGSDBit20 ) ( 1U )

/* SD_Bit_20_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_20_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_20_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_20_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_20_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_20_OFFSET                ( 0U )

/* SD_Bit_19_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit19;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_19_OK                    ( CORESAFDIAGSDBit19 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_19_ERROR                 ( CORESAFDIAGSDBit19 ) ( 1U )

/* SD_Bit_19_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_19_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_19_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_19_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_19_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_19_OFFSET                ( 0U )

/* SD_Bit_18_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit18;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_18_OK                    ( CORESAFDIAGSDBit18 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_18_ERROR                 ( CORESAFDIAGSDBit18 ) ( 1U )

/* SD_Bit_18_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_18_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_18_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_18_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_18_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_18_OFFSET                ( 0U )

/* SD_Bit_17_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit17;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_17_OK                    ( CORESAFDIAGSDBit17 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_17_ERROR                 ( CORESAFDIAGSDBit17 ) ( 1U )

/* SD_Bit_17_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_17_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_17_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_17_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_17_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_17_OFFSET                ( 0U )

/* SD_Bit_16_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit16;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_16_OK                    ( CORESAFDIAGSDBit16 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_16_ERROR                 ( CORESAFDIAGSDBit16 ) ( 1U )

/* SD_Bit_16_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_16_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_16_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_16_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_16_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_16_OFFSET                ( 0U )

/* SD_Bit_15_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit15;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_15_OK                    ( CORESAFDIAGSDBit15 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_15_ERROR                 ( CORESAFDIAGSDBit15 ) ( 1U )

/* SD_Bit_15_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_15_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_15_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_15_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_15_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_15_OFFSET                ( 0U )

/* SD_Bit_14_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit14;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_14_OK                    ( CORESAFDIAGSDBit14 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_14_ERROR                 ( CORESAFDIAGSDBit14 ) ( 1U )

/* SD_Bit_14_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_14_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_14_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_14_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_14_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_14_OFFSET                ( 0U )

/* SD_Bit_13_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit13;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_13_OK                    ( CORESAFDIAGSDBit13 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_13_ERROR                 ( CORESAFDIAGSDBit13 ) ( 1U )

/* SD_Bit_13_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_13_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_13_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_13_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_13_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_13_OFFSET                ( 0U )

/* SD_Bit_12_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit12;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_12_OK                    ( CORESAFDIAGSDBit12 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_12_ERROR                 ( CORESAFDIAGSDBit12 ) ( 1U )

/* SD_Bit_12_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_12_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_12_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_12_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_12_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_12_OFFSET                ( 0U )

/* SD_Bit_11_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit11;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_11_OK                    ( CORESAFDIAGSDBit11 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_11_ERROR                 ( CORESAFDIAGSDBit11 ) ( 1U )

/* SD_Bit_11_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_11_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_11_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_11_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_11_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_11_OFFSET                ( 0U )

/* SD_Bit_10_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit10;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_10_OK                    ( CORESAFDIAGSDBit10 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_10_ERROR                 ( CORESAFDIAGSDBit10 ) ( 1U )

/* SD_Bit_10_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_10_RMIN                  ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_10_RMAX                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_10_NUMR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_10_DEMNR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_10_OFFSET                ( 0U )

/* SD_Bit_9_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit9;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_9_OK                     ( CORESAFDIAGSDBit9 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_9_ERROR                  ( CORESAFDIAGSDBit9 ) ( 1U )

/* SD_Bit_9_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_9_RMIN                   ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_9_RMAX                   ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_9_NUMR                   ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_9_DEMNR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_9_OFFSET                 ( 0U )

/* SD_Bit_8_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit8;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_8_OK                     ( CORESAFDIAGSDBit8 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_8_ERROR                  ( CORESAFDIAGSDBit8 ) ( 1U )

/* SD_Bit_8_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_8_RMIN                   ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_8_RMAX                   ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_8_NUMR                   ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_8_DEMNR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_8_OFFSET                 ( 0U )

/* SD_Bit_7_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit7;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_7_OK                     ( CORESAFDIAGSDBit7 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_7_ERROR                  ( CORESAFDIAGSDBit7 ) ( 1U )

/* SD_Bit_7_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_7_RMIN                   ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_7_RMAX                   ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_7_NUMR                   ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_7_DEMNR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_7_OFFSET                 ( 0U )

/* SD_Bit_6_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit6;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_6_OK                     ( CORESAFDIAGSDBit6 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_6_ERROR                  ( CORESAFDIAGSDBit6 ) ( 1U )

/* SD_Bit_6_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_6_RMIN                   ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_6_RMAX                   ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_6_NUMR                   ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_6_DEMNR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_6_OFFSET                 ( 0U )

/* SD_Bit_5_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit5;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_5_OK                     ( CORESAFDIAGSDBit5 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_5_ERROR                  ( CORESAFDIAGSDBit5 ) ( 1U )

/* SD_Bit_5_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_5_RMIN                   ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_5_RMAX                   ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_5_NUMR                   ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_5_DEMNR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_5_OFFSET                 ( 0U )

/* SD_Bit_4_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit4;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_4_OK                     ( CORESAFDIAGSDBit4 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_4_ERROR                  ( CORESAFDIAGSDBit4 ) ( 1U )

/* SD_Bit_4_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_4_RMIN                   ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_4_RMAX                   ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_4_NUMR                   ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_4_DEMNR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_4_OFFSET                 ( 0U )

/* SD_Bit_3_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit3;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_3_OK                     ( CORESAFDIAGSDBit3 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_3_ERROR                  ( CORESAFDIAGSDBit3 ) ( 1U )

/* SD_Bit_3_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_3_RMIN                   ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_3_RMAX                   ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_3_NUMR                   ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_3_DEMNR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_3_OFFSET                 ( 0U )

/* SD_Bit_2_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit2;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_2_OK                     ( CORESAFDIAGSDBit2 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_2_ERROR                  ( CORESAFDIAGSDBit2 ) ( 1U )

/* SD_Bit_2_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_2_RMIN                   ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_2_RMAX                   ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_2_NUMR                   ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_2_DEMNR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_2_OFFSET                 ( 0U )

/* SD_Bit_1_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit1;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_1_OK                     ( CORESAFDIAGSDBit1 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_1_ERROR                  ( CORESAFDIAGSDBit1 ) ( 1U )

/* SD_Bit_1_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_1_RMIN                   ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_1_RMAX                   ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_1_NUMR                   ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_1_DEMNR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_1_OFFSET                 ( 0U )

/* SD_Bit_0_b1 signal Enums */
typedef boolean CORESAFDIAGSDBit0;
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_0_OK                     ( CORESAFDIAGSDBit0 ) ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_0_ERROR                  ( CORESAFDIAGSDBit0 ) ( 1U )

/* SD_Bit_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_0_RMIN                   ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_0_RMAX                   ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_0_NUMR                   ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_0_DEMNR                  ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_BIT_0_OFFSET                 ( 0U )

/* Reserved_2_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_RESERVED_2_RMIN                 ( 0U )
#define C_EYEQMSG_CORESAFDIAG_RESERVED_2_RMAX                 ( 0U )
#define C_EYEQMSG_CORESAFDIAG_RESERVED_2_NUMR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_RESERVED_2_DEMNR                ( 1U )
#define C_EYEQMSG_CORESAFDIAG_RESERVED_2_OFFSET               ( 0U )

/* SD_Challenge_Identifier_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_CHALLENGE_IDENTIFIER_RMIN    ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_CHALLENGE_IDENTIFIER_RMAX    ( 255U )
#define C_EYEQMSG_CORESAFDIAG_SD_CHALLENGE_IDENTIFIER_NUMR    ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_CHALLENGE_IDENTIFIER_DEMNR   ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_CHALLENGE_IDENTIFIER_OFFSET  ( 0U )

/* SD_Challenge_Response4_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_CHALLENGE_RESPONSE4_RMIN     ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_CHALLENGE_RESPONSE4_RMAX     ( 255U )
#define C_EYEQMSG_CORESAFDIAG_SD_CHALLENGE_RESPONSE4_NUMR     ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_CHALLENGE_RESPONSE4_DEMNR    ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_CHALLENGE_RESPONSE4_OFFSET   ( 0U )

/* SD_Challenge_Response3_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_CHALLENGE_RESPONSE3_RMIN     ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_CHALLENGE_RESPONSE3_RMAX     ( 255U )
#define C_EYEQMSG_CORESAFDIAG_SD_CHALLENGE_RESPONSE3_NUMR     ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_CHALLENGE_RESPONSE3_DEMNR    ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_CHALLENGE_RESPONSE3_OFFSET   ( 0U )

/* SD_Challenge_Response2_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_CHALLENGE_RESPONSE2_RMIN     ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_CHALLENGE_RESPONSE2_RMAX     ( 255U )
#define C_EYEQMSG_CORESAFDIAG_SD_CHALLENGE_RESPONSE2_NUMR     ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_CHALLENGE_RESPONSE2_DEMNR    ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_CHALLENGE_RESPONSE2_OFFSET   ( 0U )

/* SD_Challenge_Response1_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_CHALLENGE_RESPONSE1_RMIN     ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_CHALLENGE_RESPONSE1_RMAX     ( 255U )
#define C_EYEQMSG_CORESAFDIAG_SD_CHALLENGE_RESPONSE1_NUMR     ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_CHALLENGE_RESPONSE1_DEMNR    ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_CHALLENGE_RESPONSE1_OFFSET   ( 0U )

/* SD_Sync_ID_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_SYNC_ID_RMIN                 ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_SYNC_ID_RMAX                 ( 255U )
#define C_EYEQMSG_CORESAFDIAG_SD_SYNC_ID_NUMR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_SYNC_ID_DEMNR                ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_SYNC_ID_OFFSET               ( 0U )

/* SD_Protocol_Version_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_PROTOCOL_VERSION_RMIN        ( 2U )
#define C_EYEQMSG_CORESAFDIAG_SD_PROTOCOL_VERSION_RMAX        ( 2U )
#define C_EYEQMSG_CORESAFDIAG_SD_PROTOCOL_VERSION_NUMR        ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_PROTOCOL_VERSION_DEMNR       ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_PROTOCOL_VERSION_OFFSET      ( 0U )

/* SD_CRC_b32 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_CRC_RMIN                     ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_CRC_RMAX                     ( 4294967295U )
#define C_EYEQMSG_CORESAFDIAG_SD_CRC_NUMR                     ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_CRC_DEMNR                    ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_CRC_OFFSET                   ( 0U )

/* Reserved_1_b24 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_RESERVED_1_RMIN                 ( 0U )
#define C_EYEQMSG_CORESAFDIAG_RESERVED_1_RMAX                 ( 0U )
#define C_EYEQMSG_CORESAFDIAG_RESERVED_1_NUMR                 ( 1U )
#define C_EYEQMSG_CORESAFDIAG_RESERVED_1_DEMNR                ( 1U )
#define C_EYEQMSG_CORESAFDIAG_RESERVED_1_OFFSET               ( 0U )

/* SD_Zero_byte_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORESAFDIAG_SD_ZERO_BYTE_RMIN               ( 0U )
#define C_EYEQMSG_CORESAFDIAG_SD_ZERO_BYTE_RMAX               ( 255U )
#define C_EYEQMSG_CORESAFDIAG_SD_ZERO_BYTE_NUMR               ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_ZERO_BYTE_DEMNR              ( 1U )
#define C_EYEQMSG_CORESAFDIAG_SD_ZERO_BYTE_OFFSET             ( 0U )


/*****************************************************************************
                  Exported function-like macros
*****************************************************************************/
/*****************************************************************************
                  Exported defined macros
*****************************************************************************/
/*****************************************************************************
                  Exported types, enums definitions
*****************************************************************************/
typedef struct
{
   #if ENABLE_BIG_ENDIAN_FORMAT
      uint32        SD_Zero_byte_b8                              : 8U;
      
      uint32        Reserved_1_1_b8                              : 8U;
      
      uint32        Reserved_1_2_b8                              : 8U;
      
      uint32        Reserved_1_3_b8                              : 8U;
      
      uint32        SD_CRC_1_b8                                  : 8U;
      
      uint32        SD_CRC_2_b8                                  : 8U;
      
      uint32        SD_CRC_3_b8                                  : 8U;
      
      uint32        SD_CRC_4_b8                                  : 8U;
      
      uint32        SD_Protocol_Version_b8                       : 8U;
      
      uint32        SD_Sync_ID_b8                                : 8U;
      
      uint32        SD_Challenge_Response1_b8                    : 8U;
      
      uint32        SD_Challenge_Response2_b8                    : 8U;
      
      uint32        SD_Challenge_Response3_b8                    : 8U;
      
      uint32        SD_Challenge_Response4_b8                    : 8U;
      
      uint32        SD_Challenge_Identifier_b8                   : 8U;
      
      uint32        Reserved_2_b8                                : 8U;
      
      uint32        unused1_b7                                   : 7;
      uint32        SD_Bit_0_b1                                  : 1U;
      
      uint32        SD_Bit_1_b1                                  : 1U;
      
      uint32        SD_Bit_2_b1                                  : 1U;
      
      uint32        SD_Bit_3_b1                                  : 1U;
      
      uint32        SD_Bit_4_b1                                  : 1U;
      
      uint32        SD_Bit_5_b1                                  : 1U;
      
      uint32        SD_Bit_6_b1                                  : 1U;
      
      uint32        SD_Bit_7_b1                                  : 1U;
      
      uint32        SD_Bit_8_b1                                  : 1U;
      
      uint32        SD_Bit_9_b1                                  : 1U;
      
      uint32        SD_Bit_10_b1                                 : 1U;
      
      uint32        SD_Bit_11_b1                                 : 1U;
      
      uint32        SD_Bit_12_b1                                 : 1U;
      
      uint32        SD_Bit_13_b1                                 : 1U;
      
      uint32        SD_Bit_14_b1                                 : 1U;
      
      uint32        SD_Bit_15_b1                                 : 1U;
      
      uint32        SD_Bit_16_b1                                 : 1U;
      
      uint32        SD_Bit_17_b1                                 : 1U;
      
      uint32        SD_Bit_18_b1                                 : 1U;
      
      uint32        SD_Bit_19_b1                                 : 1U;
      
      uint32        SD_Bit_20_b1                                 : 1U;
      
      uint32        SD_Bit_21_b1                                 : 1U;
      
      uint32        SD_Bit_22_b1                                 : 1U;
      
      uint32        SD_Bit_23_b1                                 : 1U;
      
      uint32        SD_Bit_24_b1                                 : 1U;
      
      uint32        SD_Bit_25_b1                                 : 1U;
      
      uint32        SD_Bit_26_b1                                 : 1U;
      
      uint32        SD_Bit_27_b1                                 : 1U;
      
      uint32        SD_Bit_28_b1                                 : 1U;
      
      uint32        SD_Bit_29_b1                                 : 1U;
      
      uint32        SD_Bit_30_b1                                 : 1U;
      
      uint32        SD_Bit_31_b1                                 : 1U;
      
      uint32        SD_Bit_32_b1                                 : 1U;
      
      uint32        SD_Bit_33_b1                                 : 1U;
      
      uint32        SD_Bit_34_b1                                 : 1U;
      
      uint32        SD_Bit_35_b1                                 : 1U;
      
      uint32        SD_Bit_36_b1                                 : 1U;
      
      uint32        SD_Bit_37_b1                                 : 1U;
      
      uint32        SD_Bit_38_b1                                 : 1U;
      
      uint32        SD_Bit_39_b1                                 : 1U;
      
      uint32        SD_Bit_40_b1                                 : 1U;
      
      uint32        SD_Bit_41_b1                                 : 1U;
      
      uint32        SD_Bit_42_b1                                 : 1U;
      
      uint32        SD_Bit_43_b1                                 : 1U;
      
      uint32        SD_Bit_44_b1                                 : 1U;
      
      uint32        SD_Bit_45_b1                                 : 1U;
      
      uint32        SD_Bit_46_b1                                 : 1U;
      
      uint32        SD_Bit_47_b1                                 : 1U;
      
      uint32        SD_Bit_48_b1                                 : 1U;
      
      uint32        SD_Bit_49_b1                                 : 1U;
      
      uint32        SD_Bit_50_b1                                 : 1U;
      
      uint32        SD_Bit_51_b1                                 : 1U;
      
      uint32        SD_Bit_52_b1                                 : 1U;
      
      uint32        SD_Bit_53_b1                                 : 1U;
      
      uint32        SD_Bit_54_b1                                 : 1U;
      
      uint32        SD_Bit_55_b1                                 : 1U;
      
      uint32        SD_Bit_56_b1                                 : 1U;
      
      uint32        SD_Bit_57_b1                                 : 1U;
      
      uint32        SD_Bit_58_b1                                 : 1U;
      
      uint32        SD_Bit_59_b1                                 : 1U;
      
      uint32        SD_Bit_60_b1                                 : 1U;
      
      uint32        SD_Bit_61_b1                                 : 1U;
      
      uint32        SD_Bit_62_b1                                 : 1U;
      
      uint32        SD_Bit_63_b1                                 : 1U;
      
   #else
      uint32        SD_Zero_byte_b8                              : 8U;
      
      uint32        Reserved_1_b24                               : 24U;
      
      uint32        SD_CRC_b32                                   : 32U;
      
      uint32        SD_Protocol_Version_b8                       : 8U;
      
      uint32        SD_Sync_ID_b8                                : 8U;
      
      uint32        SD_Challenge_Response1_b8                    : 8U;
      
      uint32        SD_Challenge_Response2_b8                    : 8U;
      
      uint32        SD_Challenge_Response3_b8                    : 8U;
      
      uint32        SD_Challenge_Response4_b8                    : 8U;
      
      uint32        SD_Challenge_Identifier_b8                   : 8U;
      
      uint32        Reserved_2_b8                                : 8U;
      
      uint32        SD_Bit_0_b1                                  : 1U;
      
      uint32        SD_Bit_1_b1                                  : 1U;
      
      uint32        SD_Bit_2_b1                                  : 1U;
      
      uint32        SD_Bit_3_b1                                  : 1U;
      
      uint32        SD_Bit_4_b1                                  : 1U;
      
      uint32        SD_Bit_5_b1                                  : 1U;
      
      uint32        SD_Bit_6_b1                                  : 1U;
      
      uint32        SD_Bit_7_b1                                  : 1U;
      
      uint32        SD_Bit_8_b1                                  : 1U;
      
      uint32        SD_Bit_9_b1                                  : 1U;
      
      uint32        SD_Bit_10_b1                                 : 1U;
      
      uint32        SD_Bit_11_b1                                 : 1U;
      
      uint32        SD_Bit_12_b1                                 : 1U;
      
      uint32        SD_Bit_13_b1                                 : 1U;
      
      uint32        SD_Bit_14_b1                                 : 1U;
      
      uint32        SD_Bit_15_b1                                 : 1U;
      
      uint32        SD_Bit_16_b1                                 : 1U;
      
      uint32        SD_Bit_17_b1                                 : 1U;
      
      uint32        SD_Bit_18_b1                                 : 1U;
      
      uint32        SD_Bit_19_b1                                 : 1U;
      
      uint32        SD_Bit_20_b1                                 : 1U;
      
      uint32        SD_Bit_21_b1                                 : 1U;
      
      uint32        SD_Bit_22_b1                                 : 1U;
      
      uint32        SD_Bit_23_b1                                 : 1U;
      
      uint32        SD_Bit_24_b1                                 : 1U;
      
      uint32        SD_Bit_25_b1                                 : 1U;
      
      uint32        SD_Bit_26_b1                                 : 1U;
      
      uint32        SD_Bit_27_b1                                 : 1U;
      
      uint32        SD_Bit_28_b1                                 : 1U;
      
      uint32        SD_Bit_29_b1                                 : 1U;
      
      uint32        SD_Bit_30_b1                                 : 1U;
      
      uint32        SD_Bit_31_b1                                 : 1U;
      
      uint32        SD_Bit_32_b1                                 : 1U;
      
      uint32        SD_Bit_33_b1                                 : 1U;
      
      uint32        SD_Bit_34_b1                                 : 1U;
      
      uint32        SD_Bit_35_b1                                 : 1U;
      
      uint32        SD_Bit_36_b1                                 : 1U;
      
      uint32        SD_Bit_37_b1                                 : 1U;
      
      uint32        SD_Bit_38_b1                                 : 1U;
      
      uint32        SD_Bit_39_b1                                 : 1U;
      
      uint32        SD_Bit_40_b1                                 : 1U;
      
      uint32        SD_Bit_41_b1                                 : 1U;
      
      uint32        SD_Bit_42_b1                                 : 1U;
      
      uint32        SD_Bit_43_b1                                 : 1U;
      
      uint32        SD_Bit_44_b1                                 : 1U;
      
      uint32        SD_Bit_45_b1                                 : 1U;
      
      uint32        SD_Bit_46_b1                                 : 1U;
      
      uint32        SD_Bit_47_b1                                 : 1U;
      
      uint32        SD_Bit_48_b1                                 : 1U;
      
      uint32        SD_Bit_49_b1                                 : 1U;
      
      uint32        SD_Bit_50_b1                                 : 1U;
      
      uint32        SD_Bit_51_b1                                 : 1U;
      
      uint32        SD_Bit_52_b1                                 : 1U;
      
      uint32        SD_Bit_53_b1                                 : 1U;
      
      uint32        SD_Bit_54_b1                                 : 1U;
      
      uint32        SD_Bit_55_b1                                 : 1U;
      
      uint32        SD_Bit_56_b1                                 : 1U;
      
      uint32        SD_Bit_57_b1                                 : 1U;
      
      uint32        SD_Bit_58_b1                                 : 1U;
      
      uint32        SD_Bit_59_b1                                 : 1U;
      
      uint32        SD_Bit_60_b1                                 : 1U;
      
      uint32        SD_Bit_61_b1                                 : 1U;
      
      uint32        SD_Bit_62_b1                                 : 1U;
      
      uint32        SD_Bit_63_b1                                 : 1U;
      
   #endif
} EYEQMSG_CORESAFDIAG_Params_t;


/*****************************************************************************
                  Exported function prototypes
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_CORESAFDIAG_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_CORESAFDIAG_Params_t * pCore_Safety_Diagnostics_protocol - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_Safety_Diagnostics_protocol message 
*    Core_Safety_Diagnostics_protocol message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_Safety_Diagnostics_protocol message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_CORESAFDIAG_ParamsApp_MsgDataStruct( EYEQMSG_CORESAFDIAG_Params_t * pCore_Safety_Diagnostics_protocol );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pSD_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Zero_byte
*    SD_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Zero_byte signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Zero_byte( uint8 * pSD_Zero_byte );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_Reserved_1
*
* FUNCTION ARGUMENTS:
*    uint32 * pReserved_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1
*    Reserved_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_Reserved_1( uint32 * pReserved_1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_CRC
*
* FUNCTION ARGUMENTS:
*    uint32 * pSD_CRC - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_CRC
*    SD_CRC returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_CRC signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_CRC( uint32 * pSD_CRC );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pSD_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Protocol_Version
*    SD_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Protocol_Version signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Protocol_Version( uint8 * pSD_Protocol_Version );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Sync_ID
*
* FUNCTION ARGUMENTS:
*    uint8 * pSD_Sync_ID - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Sync_ID
*    SD_Sync_ID returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Sync_ID signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Sync_ID( uint8 * pSD_Sync_ID );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Challenge_Response1
*
* FUNCTION ARGUMENTS:
*    uint8 * pSD_Challenge_Response1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Challenge_Response1
*    SD_Challenge_Response1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Challenge_Response1 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Challenge_Response1( uint8 * pSD_Challenge_Response1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Challenge_Response2
*
* FUNCTION ARGUMENTS:
*    uint8 * pSD_Challenge_Response2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Challenge_Response2
*    SD_Challenge_Response2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Challenge_Response2 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Challenge_Response2( uint8 * pSD_Challenge_Response2 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Challenge_Response3
*
* FUNCTION ARGUMENTS:
*    uint8 * pSD_Challenge_Response3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Challenge_Response3
*    SD_Challenge_Response3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Challenge_Response3 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Challenge_Response3( uint8 * pSD_Challenge_Response3 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Challenge_Response4
*
* FUNCTION ARGUMENTS:
*    uint8 * pSD_Challenge_Response4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Challenge_Response4
*    SD_Challenge_Response4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Challenge_Response4 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Challenge_Response4( uint8 * pSD_Challenge_Response4 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Challenge_Identifier
*
* FUNCTION ARGUMENTS:
*    uint8 * pSD_Challenge_Identifier - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Challenge_Identifier
*    SD_Challenge_Identifier returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Challenge_Identifier signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Challenge_Identifier( uint8 * pSD_Challenge_Identifier );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_Reserved_2
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_2
*    Reserved_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_2 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_Reserved_2( uint8 * pReserved_2 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_0
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit0 * pSD_Bit_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_0
*    SD_Bit_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_0 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_0( CORESAFDIAGSDBit0 * pSD_Bit_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_1
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit1 * pSD_Bit_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_1
*    SD_Bit_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_1 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_1( CORESAFDIAGSDBit1 * pSD_Bit_1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_2
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit2 * pSD_Bit_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_2
*    SD_Bit_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_2 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_2( CORESAFDIAGSDBit2 * pSD_Bit_2 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_3
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit3 * pSD_Bit_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_3
*    SD_Bit_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_3 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_3( CORESAFDIAGSDBit3 * pSD_Bit_3 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_4
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit4 * pSD_Bit_4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_4
*    SD_Bit_4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_4 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_4( CORESAFDIAGSDBit4 * pSD_Bit_4 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_5
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit5 * pSD_Bit_5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_5
*    SD_Bit_5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_5 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_5( CORESAFDIAGSDBit5 * pSD_Bit_5 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_6
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit6 * pSD_Bit_6 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_6
*    SD_Bit_6 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_6 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_6( CORESAFDIAGSDBit6 * pSD_Bit_6 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_7
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit7 * pSD_Bit_7 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_7
*    SD_Bit_7 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_7 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_7( CORESAFDIAGSDBit7 * pSD_Bit_7 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_8
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit8 * pSD_Bit_8 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_8
*    SD_Bit_8 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_8 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_8( CORESAFDIAGSDBit8 * pSD_Bit_8 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_9
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit9 * pSD_Bit_9 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_9
*    SD_Bit_9 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_9 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_9( CORESAFDIAGSDBit9 * pSD_Bit_9 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_10
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit10 * pSD_Bit_10 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_10
*    SD_Bit_10 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_10 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_10( CORESAFDIAGSDBit10 * pSD_Bit_10 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_11
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit11 * pSD_Bit_11 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_11
*    SD_Bit_11 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_11 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_11( CORESAFDIAGSDBit11 * pSD_Bit_11 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_12
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit12 * pSD_Bit_12 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_12
*    SD_Bit_12 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_12 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_12( CORESAFDIAGSDBit12 * pSD_Bit_12 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_13
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit13 * pSD_Bit_13 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_13
*    SD_Bit_13 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_13 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_13( CORESAFDIAGSDBit13 * pSD_Bit_13 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_14
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit14 * pSD_Bit_14 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_14
*    SD_Bit_14 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_14 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_14( CORESAFDIAGSDBit14 * pSD_Bit_14 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_15
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit15 * pSD_Bit_15 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_15
*    SD_Bit_15 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_15 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_15( CORESAFDIAGSDBit15 * pSD_Bit_15 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_16
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit16 * pSD_Bit_16 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_16
*    SD_Bit_16 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_16 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_16( CORESAFDIAGSDBit16 * pSD_Bit_16 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_17
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit17 * pSD_Bit_17 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_17
*    SD_Bit_17 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_17 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_17( CORESAFDIAGSDBit17 * pSD_Bit_17 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_18
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit18 * pSD_Bit_18 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_18
*    SD_Bit_18 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_18 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_18( CORESAFDIAGSDBit18 * pSD_Bit_18 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_19
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit19 * pSD_Bit_19 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_19
*    SD_Bit_19 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_19 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_19( CORESAFDIAGSDBit19 * pSD_Bit_19 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_20
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit20 * pSD_Bit_20 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_20
*    SD_Bit_20 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_20 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_20( CORESAFDIAGSDBit20 * pSD_Bit_20 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_21
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit21 * pSD_Bit_21 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_21
*    SD_Bit_21 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_21 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_21( CORESAFDIAGSDBit21 * pSD_Bit_21 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_22
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit22 * pSD_Bit_22 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_22
*    SD_Bit_22 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_22 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_22( CORESAFDIAGSDBit22 * pSD_Bit_22 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_23
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit23 * pSD_Bit_23 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_23
*    SD_Bit_23 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_23 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_23( CORESAFDIAGSDBit23 * pSD_Bit_23 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_24
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit24 * pSD_Bit_24 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_24
*    SD_Bit_24 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_24 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_24( CORESAFDIAGSDBit24 * pSD_Bit_24 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_25
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit25 * pSD_Bit_25 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_25
*    SD_Bit_25 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_25 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_25( CORESAFDIAGSDBit25 * pSD_Bit_25 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_26
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit26 * pSD_Bit_26 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_26
*    SD_Bit_26 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_26 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_26( CORESAFDIAGSDBit26 * pSD_Bit_26 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_27
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit27 * pSD_Bit_27 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_27
*    SD_Bit_27 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_27 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_27( CORESAFDIAGSDBit27 * pSD_Bit_27 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_28
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit28 * pSD_Bit_28 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_28
*    SD_Bit_28 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_28 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_28( CORESAFDIAGSDBit28 * pSD_Bit_28 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_29
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit29 * pSD_Bit_29 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_29
*    SD_Bit_29 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_29 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_29( CORESAFDIAGSDBit29 * pSD_Bit_29 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_30
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit30 * pSD_Bit_30 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_30
*    SD_Bit_30 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_30 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_30( CORESAFDIAGSDBit30 * pSD_Bit_30 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_31
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit31 * pSD_Bit_31 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_31
*    SD_Bit_31 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_31 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_31( CORESAFDIAGSDBit31 * pSD_Bit_31 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_32
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit32 * pSD_Bit_32 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_32
*    SD_Bit_32 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_32 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_32( CORESAFDIAGSDBit32 * pSD_Bit_32 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_33
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit33 * pSD_Bit_33 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_33
*    SD_Bit_33 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_33 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_33( CORESAFDIAGSDBit33 * pSD_Bit_33 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_34
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit34 * pSD_Bit_34 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_34
*    SD_Bit_34 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_34 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_34( CORESAFDIAGSDBit34 * pSD_Bit_34 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_35
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit35 * pSD_Bit_35 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_35
*    SD_Bit_35 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_35 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_35( CORESAFDIAGSDBit35 * pSD_Bit_35 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_36
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit36 * pSD_Bit_36 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_36
*    SD_Bit_36 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_36 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_36( CORESAFDIAGSDBit36 * pSD_Bit_36 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_37
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit37 * pSD_Bit_37 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_37
*    SD_Bit_37 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_37 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_37( CORESAFDIAGSDBit37 * pSD_Bit_37 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_38
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit38 * pSD_Bit_38 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_38
*    SD_Bit_38 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_38 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_38( CORESAFDIAGSDBit38 * pSD_Bit_38 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_39
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit39 * pSD_Bit_39 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_39
*    SD_Bit_39 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_39 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_39( CORESAFDIAGSDBit39 * pSD_Bit_39 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_40
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit40 * pSD_Bit_40 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_40
*    SD_Bit_40 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_40 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_40( CORESAFDIAGSDBit40 * pSD_Bit_40 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_41
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit41 * pSD_Bit_41 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_41
*    SD_Bit_41 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_41 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_41( CORESAFDIAGSDBit41 * pSD_Bit_41 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_42
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit42 * pSD_Bit_42 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_42
*    SD_Bit_42 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_42 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_42( CORESAFDIAGSDBit42 * pSD_Bit_42 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_43
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit43 * pSD_Bit_43 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_43
*    SD_Bit_43 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_43 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_43( CORESAFDIAGSDBit43 * pSD_Bit_43 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_44
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit44 * pSD_Bit_44 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_44
*    SD_Bit_44 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_44 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_44( CORESAFDIAGSDBit44 * pSD_Bit_44 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_45
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit45 * pSD_Bit_45 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_45
*    SD_Bit_45 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_45 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_45( CORESAFDIAGSDBit45 * pSD_Bit_45 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_46
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit46 * pSD_Bit_46 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_46
*    SD_Bit_46 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_46 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_46( CORESAFDIAGSDBit46 * pSD_Bit_46 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_47
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit47 * pSD_Bit_47 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_47
*    SD_Bit_47 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_47 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_47( CORESAFDIAGSDBit47 * pSD_Bit_47 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_48
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit48 * pSD_Bit_48 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_48
*    SD_Bit_48 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_48 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_48( CORESAFDIAGSDBit48 * pSD_Bit_48 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_49
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit49 * pSD_Bit_49 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_49
*    SD_Bit_49 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_49 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_49( CORESAFDIAGSDBit49 * pSD_Bit_49 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_50
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit50 * pSD_Bit_50 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_50
*    SD_Bit_50 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_50 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_50( CORESAFDIAGSDBit50 * pSD_Bit_50 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_51
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit51 * pSD_Bit_51 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_51
*    SD_Bit_51 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_51 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_51( CORESAFDIAGSDBit51 * pSD_Bit_51 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_52
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit52 * pSD_Bit_52 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_52
*    SD_Bit_52 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_52 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_52( CORESAFDIAGSDBit52 * pSD_Bit_52 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_53
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit53 * pSD_Bit_53 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_53
*    SD_Bit_53 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_53 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_53( CORESAFDIAGSDBit53 * pSD_Bit_53 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_54
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit54 * pSD_Bit_54 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_54
*    SD_Bit_54 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_54 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_54( CORESAFDIAGSDBit54 * pSD_Bit_54 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_55
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit55 * pSD_Bit_55 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_55
*    SD_Bit_55 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_55 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_55( CORESAFDIAGSDBit55 * pSD_Bit_55 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_56
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit56 * pSD_Bit_56 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_56
*    SD_Bit_56 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_56 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_56( CORESAFDIAGSDBit56 * pSD_Bit_56 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_57
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit57 * pSD_Bit_57 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_57
*    SD_Bit_57 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_57 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_57( CORESAFDIAGSDBit57 * pSD_Bit_57 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_58
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit58 * pSD_Bit_58 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_58
*    SD_Bit_58 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_58 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_58( CORESAFDIAGSDBit58 * pSD_Bit_58 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_59
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit59 * pSD_Bit_59 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_59
*    SD_Bit_59 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_59 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_59( CORESAFDIAGSDBit59 * pSD_Bit_59 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_60
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit60 * pSD_Bit_60 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_60
*    SD_Bit_60 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_60 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_60( CORESAFDIAGSDBit60 * pSD_Bit_60 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_61
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit61 * pSD_Bit_61 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_61
*    SD_Bit_61 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_61 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_61( CORESAFDIAGSDBit61 * pSD_Bit_61 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_62
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit62 * pSD_Bit_62 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_62
*    SD_Bit_62 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_62 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_62( CORESAFDIAGSDBit62 * pSD_Bit_62 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_63
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit63 * pSD_Bit_63 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_63
*    SD_Bit_63 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_63 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_63( CORESAFDIAGSDBit63 * pSD_Bit_63 );
/*****************************************************************************
                  Exported object declarations
*****************************************************************************/
extern EYEQMSG_CORESAFDIAG_Params_t   EYEQMSG_CORESAFDIAG_Params_s;
extern EYEQMSG_CORESAFDIAG_Params_t   EYEQMSG_CORESAFDIAG_ParamsApp_s;
/****************************************************************************/
#endif /* _EYEQMSG_CORESAFDIAGPROCESS_H_ */


