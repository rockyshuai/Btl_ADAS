#ifndef _EYEQMSG_CORESPCINITPROCESS_H_
#define _EYEQMSG_CORESPCINITPROCESS_H_

/*****************************************************************************
                  Included header files
*****************************************************************************/
#include <Std_Types.h>

/*****************************************************************************
                  Include files
*****************************************************************************/
/*****************************************************************************
                  Exported symbolic constants
*****************************************************************************/

/* Datagram message ID */
#define C_EYEQMSG_CORESPCINIT_MSG_ID                          ( 0x82U )

/* Datagram message lengths */
#define C_EYEQMSG_CORESPCINIT_MSG_LEN                         ( sizeof(EYEQMSG_CORESPCINIT_Params_t) )

/* Protocol ENUMs */

/* MCU output messages */

/* Core_SPC_Init Enums */
/* Reserved_1_b31 signal Min & Max range limits */
#define C_EYEQMSG_CORESPCINIT_RESERVED_1_RMIN                 ( 0U )
#define C_EYEQMSG_CORESPCINIT_RESERVED_1_RMAX                 ( 0U )
#define C_EYEQMSG_CORESPCINIT_RESERVED_1_NUMR                 ( 1U )
#define C_EYEQMSG_CORESPCINIT_RESERVED_1_DEMNR                ( 1U )
#define C_EYEQMSG_CORESPCINIT_RESERVED_1_OFFSET               ( 0U )

/* ISPC_Slow_Mode_b1 signal Enums */
typedef boolean CORESPCINITISPCSlowMode;
#define C_EYEQMSG_CORESPCINIT_ISPC_SLOW_MODE_FALSE            ( CORESPCINITISPCSlowMode ) ( 0U )
#define C_EYEQMSG_CORESPCINIT_ISPC_SLOW_MODE_TRUE             ( CORESPCINITISPCSlowMode ) ( 1U )

/* ISPC_Slow_Mode_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORESPCINIT_ISPC_SLOW_MODE_RMIN             ( 0U )
#define C_EYEQMSG_CORESPCINIT_ISPC_SLOW_MODE_RMAX             ( 1U )
#define C_EYEQMSG_CORESPCINIT_ISPC_SLOW_MODE_NUMR             ( 1U )
#define C_EYEQMSG_CORESPCINIT_ISPC_SLOW_MODE_DEMNR            ( 1U )
#define C_EYEQMSG_CORESPCINIT_ISPC_SLOW_MODE_OFFSET           ( 0U )

/* ISPC_Optional_Signals_b16 signal Min & Max range limits */
#define C_EYEQMSG_CORESPCINIT_ISPC_OPTIONAL_SIGNALS_RMIN      ( 0U )
#define C_EYEQMSG_CORESPCINIT_ISPC_OPTIONAL_SIGNALS_RMAX      ( 0U )
#define C_EYEQMSG_CORESPCINIT_ISPC_OPTIONAL_SIGNALS_NUMR      ( 1U )
#define C_EYEQMSG_CORESPCINIT_ISPC_OPTIONAL_SIGNALS_DEMNR     ( 1U )
#define C_EYEQMSG_CORESPCINIT_ISPC_OPTIONAL_SIGNALS_OFFSET    ( 0U )

/* ISPC_Protocol_Version_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORESPCINIT_ISPC_PROTOCOL_VERSION_RMIN      ( 4U )
#define C_EYEQMSG_CORESPCINIT_ISPC_PROTOCOL_VERSION_RMAX      ( 4U )
#define C_EYEQMSG_CORESPCINIT_ISPC_PROTOCOL_VERSION_NUMR      ( 1U )
#define C_EYEQMSG_CORESPCINIT_ISPC_PROTOCOL_VERSION_DEMNR     ( 1U )
#define C_EYEQMSG_CORESPCINIT_ISPC_PROTOCOL_VERSION_OFFSET    ( 0U )

/* ISPC_Zero_byte_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORESPCINIT_ISPC_ZERO_BYTE_RMIN             ( 0U )
#define C_EYEQMSG_CORESPCINIT_ISPC_ZERO_BYTE_RMAX             ( 0U )
#define C_EYEQMSG_CORESPCINIT_ISPC_ZERO_BYTE_NUMR             ( 1U )
#define C_EYEQMSG_CORESPCINIT_ISPC_ZERO_BYTE_DEMNR            ( 1U )
#define C_EYEQMSG_CORESPCINIT_ISPC_ZERO_BYTE_OFFSET           ( 0U )


/*****************************************************************************
                  Exported function-like macros
*****************************************************************************/
/*****************************************************************************
                  Exported defined macros
*****************************************************************************/
/*****************************************************************************
                  Exported types, enums definitions
*****************************************************************************/
typedef struct
{
   #if ENABLE_BIG_ENDIAN_FORMAT
      uint32        ISPC_Zero_byte_b8                            : 8U;
      
      uint32        ISPC_Protocol_Version_b8                     : 8U;
      
      uint32        ISPC_Optional_Signals_1_b8                   : 8U;
      
      uint32        ISPC_Optional_Signals_2_b8                   : 8U;
      
      uint32        unused1_b7                                   : 7;
      uint32        ISPC_Slow_Mode_b1                            : 1U;
      
      uint32        Reserved_1_1_b7                              : 7U;
      
      uint32        Reserved_1_2_b8                              : 8U;
      
      uint32        Reserved_1_3_b8                              : 8U;
      
      uint32        Reserved_1_4_b8                              : 8U;
      
   #else
      uint32        ISPC_Zero_byte_b8                            : 8U;
      
      uint32        ISPC_Protocol_Version_b8                     : 8U;
      
      uint32        ISPC_Optional_Signals_b16                    : 16U;
      
      uint32        ISPC_Slow_Mode_b1                            : 1U;
      
      uint32        Reserved_1_b31                               : 31U;
      
   #endif
} EYEQMSG_CORESPCINIT_Params_t;


/*****************************************************************************
                  Exported function prototypes
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_CORESPCINIT_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_CORESPCINIT_Params_t * pCore_SPC_Init - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_SPC_Init message 
*    Core_SPC_Init message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_SPC_Init message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_CORESPCINIT_ParamsApp_MsgDataStruct( EYEQMSG_CORESPCINIT_Params_t * pCore_SPC_Init );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESPCINIT_ISPC_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pISPC_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ISPC_Zero_byte
*    ISPC_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ISPC_Zero_byte signal value of Core_SPC_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESPCINIT_ISPC_Zero_byte( uint8 * pISPC_Zero_byte );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESPCINIT_ISPC_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pISPC_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ISPC_Protocol_Version
*    ISPC_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ISPC_Protocol_Version signal value of Core_SPC_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESPCINIT_ISPC_Protocol_Version( uint8 * pISPC_Protocol_Version );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESPCINIT_ISPC_Optional_Signals
*
* FUNCTION ARGUMENTS:
*    uint16 * pISPC_Optional_Signals - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ISPC_Optional_Signals
*    ISPC_Optional_Signals returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ISPC_Optional_Signals signal value of Core_SPC_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESPCINIT_ISPC_Optional_Signals( uint16 * pISPC_Optional_Signals );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESPCINIT_ISPC_Slow_Mode
*
* FUNCTION ARGUMENTS:
*    CORESPCINITISPCSlowMode * pISPC_Slow_Mode - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ISPC_Slow_Mode
*    ISPC_Slow_Mode returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ISPC_Slow_Mode signal value of Core_SPC_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESPCINIT_ISPC_Slow_Mode( CORESPCINITISPCSlowMode * pISPC_Slow_Mode );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESPCINIT_Reserved_1
*
* FUNCTION ARGUMENTS:
*    uint32 * pReserved_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1
*    Reserved_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1 signal value of Core_SPC_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESPCINIT_Reserved_1( uint32 * pReserved_1 );
/*****************************************************************************
                  Exported object declarations
*****************************************************************************/
extern EYEQMSG_CORESPCINIT_Params_t   EYEQMSG_CORESPCINIT_Params_s;
extern EYEQMSG_CORESPCINIT_Params_t   EYEQMSG_CORESPCINIT_ParamsApp_s;
/****************************************************************************/
#endif /* _EYEQMSG_CORESPCINITPROCESS_H_ */


