#ifndef _EYEQMSG_CORETRAFFICSIGNPROCESS_H_
#define _EYEQMSG_CORETRAFFICSIGNPROCESS_H_

/*****************************************************************************
                  Included header files
*****************************************************************************/
#include <Std_Types.h>

/*****************************************************************************
                  Include files
*****************************************************************************/
/*****************************************************************************
                  Exported symbolic constants
*****************************************************************************/
#define C_EYEQMSG_CORETRAFFICSIGNvH_VIRTUAL_OBJECT_INDEX_RMAX ( 20U )

/* Datagram message ID */
#define C_EYEQMSG_CORETRAFFICSIGNvH_MSG_ID                    ( 0x56U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_MSG_ID                    ( 0x56U )
#define C_EYEQMSG_CORETRAFFICSIGN_MSG_ID                      ( 0x56U )

/* Datagram message lengths */
#define C_EYEQMSG_CORETRAFFICSIGNvH_MSG_LEN                   ( sizeof(EYEQMSG_CORETRAFFICSIGNvH_Params_t) )
#define C_EYEQMSG_CORETRAFFICSIGNvO_MSG_LEN                   ( sizeof(EYEQMSG_CORETRAFFICSIGNvO_Params_t) )
#define C_EYEQMSG_CORETRAFFICSIGN_MSG_LEN                     ( sizeof(EYEQMSG_CORETRAFFICSIGN_Params_t) )

/* Protocol ENUMs */

/* MCU output messages */

/* Virtual_HEADER_msg_Core_Traffic_Signs_protocol Enums */
/* Reserved_1_b27 signal Min & Max range limits */
#define C_EYEQMSG_CORETRAFFICSIGNvH_RESERVED_1_RMIN           ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvH_RESERVED_1_RMAX           ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvH_RESERVED_1_NUMR           ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvH_RESERVED_1_DEMNR          ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvH_RESERVED_1_OFFSET         ( 0U )

/* TSR_UnderTracking_Sign_Count_b5 signal Min & Max range limits */
#define C_EYEQMSG_CORETRAFFICSIGNvH_TSR_UNDERTRACKING_SIGN_COUNT_RMIN ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvH_TSR_UNDERTRACKING_SIGN_COUNT_RMAX ( 20U )
#define C_EYEQMSG_CORETRAFFICSIGNvH_TSR_UNDERTRACKING_SIGN_COUNT_NUMR ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvH_TSR_UNDERTRACKING_SIGN_COUNT_DEMNR ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvH_TSR_UNDERTRACKING_SIGN_COUNT_OFFSET ( 0U )

/* TSR_Filtered_Sign_Count_b3 signal Min & Max range limits */
#define C_EYEQMSG_CORETRAFFICSIGNvH_TSR_FILTERED_SIGN_COUNT_RMIN ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvH_TSR_FILTERED_SIGN_COUNT_RMAX ( 5U )
#define C_EYEQMSG_CORETRAFFICSIGNvH_TSR_FILTERED_SIGN_COUNT_NUMR ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvH_TSR_FILTERED_SIGN_COUNT_DEMNR ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvH_TSR_FILTERED_SIGN_COUNT_OFFSET ( 0U )

/* TSR_Approved_Sign_Count_b5 signal Min & Max range limits */
#define C_EYEQMSG_CORETRAFFICSIGNvH_TSR_APPROVED_SIGN_COUNT_RMIN ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvH_TSR_APPROVED_SIGN_COUNT_RMAX ( 20U )
#define C_EYEQMSG_CORETRAFFICSIGNvH_TSR_APPROVED_SIGN_COUNT_NUMR ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvH_TSR_APPROVED_SIGN_COUNT_DEMNR ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvH_TSR_APPROVED_SIGN_COUNT_OFFSET ( 0U )

/* TSR_Sync_ID_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORETRAFFICSIGNvH_TSR_SYNC_ID_RMIN          ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvH_TSR_SYNC_ID_RMAX          ( 255U )
#define C_EYEQMSG_CORETRAFFICSIGNvH_TSR_SYNC_ID_NUMR          ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvH_TSR_SYNC_ID_DEMNR         ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvH_TSR_SYNC_ID_OFFSET        ( 0U )

/* TSR_Protocol_Version_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORETRAFFICSIGNvH_TSR_PROTOCOL_VERSION_RMIN ( 10U )
#define C_EYEQMSG_CORETRAFFICSIGNvH_TSR_PROTOCOL_VERSION_RMAX ( 10U )
#define C_EYEQMSG_CORETRAFFICSIGNvH_TSR_PROTOCOL_VERSION_NUMR ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvH_TSR_PROTOCOL_VERSION_DEMNR ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvH_TSR_PROTOCOL_VERSION_OFFSET ( 0U )

/* TSR_Zero_byte_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORETRAFFICSIGNvH_TSR_ZERO_BYTE_RMIN        ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvH_TSR_ZERO_BYTE_RMAX        ( 255U )
#define C_EYEQMSG_CORETRAFFICSIGNvH_TSR_ZERO_BYTE_NUMR        ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvH_TSR_ZERO_BYTE_DEMNR       ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvH_TSR_ZERO_BYTE_OFFSET      ( 0U )


/* Virtual_OBJECT_msg_Core_Traffic_Signs_protocol Enums */
/* Reserved_10_0_b12 signal Min & Max range limits */
#define C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_10_0_RMIN        ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_10_0_RMAX        ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_10_0_NUMR        ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_10_0_DEMNR       ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_10_0_OFFSET      ( 0U )

/* TSR_Relevancy_Confidence_0_b7 signal Min & Max range limits */
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_RELEVANCY_CONFIDENCE_0_RMIN ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_RELEVANCY_CONFIDENCE_0_RMAX ( 100U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_RELEVANCY_CONFIDENCE_0_NUMR ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_RELEVANCY_CONFIDENCE_0_DEMNR ( 100U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_RELEVANCY_CONFIDENCE_0_OFFSET ( 0U )

/* TSR_AngleZ_0_b10 signal Min & Max range limits */
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_ANGLEZ_0_RMIN         ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_ANGLEZ_0_RMAX         ( 314U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_ANGLEZ_0_NUMR         ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_ANGLEZ_0_DEMNR        ( 100U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_ANGLEZ_0_OFFSET       ( 0U )

/* TSR_Measurement_Status_0_b3 signal Enums */
typedef uint8 CORETRAFFICSIGNvOTSRMeasurementStatus0;
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_MEASUREMENT_STATUS_0_INVALID ( CORETRAFFICSIGNvOTSRMeasurementStatus0 ) ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_MEASUREMENT_STATUS_0_VISIBLE ( CORETRAFFICSIGNvOTSRMeasurementStatus0 ) ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_MEASUREMENT_STATUS_0_PARTIALLY_OCCLUDED ( CORETRAFFICSIGNvOTSRMeasurementStatus0 ) ( 2U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_MEASUREMENT_STATUS_0_OCCLUDED ( CORETRAFFICSIGNvOTSRMeasurementStatus0 ) ( 3U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_MEASUREMENT_STATUS_0_OUT_OF_IMAGE ( CORETRAFFICSIGNvOTSRMeasurementStatus0 ) ( 4U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_MEASUREMENT_STATUS_0_EXPELLED ( CORETRAFFICSIGNvOTSRMeasurementStatus0 ) ( 5U )

/* TSR_Measurement_Status_0_b3 signal Min & Max range limits */
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_MEASUREMENT_STATUS_0_RMIN ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_MEASUREMENT_STATUS_0_RMAX ( 5U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_MEASUREMENT_STATUS_0_NUMR ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_MEASUREMENT_STATUS_0_DEMNR ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_MEASUREMENT_STATUS_0_OFFSET ( 0U )

/* Reserved_9_0_b2 signal Min & Max range limits */
#define C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_9_0_RMIN         ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_9_0_RMAX         ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_9_0_NUMR         ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_9_0_DEMNR        ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_9_0_OFFSET       ( 0U )

/* TSR_Sign_Panel_Width_STD_0_b10 signal Min & Max range limits */
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_PANEL_WIDTH_STD_0_RMIN ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_PANEL_WIDTH_STD_0_RMAX ( 800U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_PANEL_WIDTH_STD_0_NUMR ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_PANEL_WIDTH_STD_0_DEMNR ( 100U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_PANEL_WIDTH_STD_0_OFFSET ( 0U )

/* TSR_Sign_Panel_Height_0_b10 signal Min & Max range limits */
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_PANEL_HEIGHT_0_RMIN ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_PANEL_HEIGHT_0_RMAX ( 800U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_PANEL_HEIGHT_0_NUMR ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_PANEL_HEIGHT_0_DEMNR ( 100U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_PANEL_HEIGHT_0_OFFSET ( 0U )

/* TSR_Sign_Panel_Width_0_b10 signal Min & Max range limits */
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_PANEL_WIDTH_0_RMIN ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_PANEL_WIDTH_0_RMAX ( 800U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_PANEL_WIDTH_0_NUMR ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_PANEL_WIDTH_0_DEMNR ( 100U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_PANEL_WIDTH_0_OFFSET ( 0U )

/* Reserved_8_0_b7 signal Min & Max range limits */
#define C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_8_0_RMIN         ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_8_0_RMAX         ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_8_0_NUMR         ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_8_0_DEMNR        ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_8_0_OFFSET       ( 0U )

/* TSR_Sign_Height_STD_0_b15 signal Min & Max range limits */
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_HEIGHT_STD_0_RMIN ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_HEIGHT_STD_0_RMAX ( 3000U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_HEIGHT_STD_0_NUMR ( 1 )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_HEIGHT_STD_0_DEMNR ( 100 )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_HEIGHT_STD_0_OFFSET ( -15 )

/* TSR_Sign_Panel_Height_STD_0_b10 signal Min & Max range limits */
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_PANEL_HEIGHT_STD_0_RMIN ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_PANEL_HEIGHT_STD_0_RMAX ( 800U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_PANEL_HEIGHT_STD_0_NUMR ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_PANEL_HEIGHT_STD_0_DEMNR ( 100U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_PANEL_HEIGHT_STD_0_OFFSET ( 0U )

/* Reserved_7_0_b4 signal Min & Max range limits */
#define C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_7_0_RMIN         ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_7_0_RMAX         ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_7_0_NUMR         ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_7_0_DEMNR        ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_7_0_OFFSET       ( 0U )

/* TSR_Sign_Height_0_b15 signal Min & Max range limits */
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_HEIGHT_0_RMIN    ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_HEIGHT_0_RMAX    ( 3000U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_HEIGHT_0_NUMR    ( 1 )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_HEIGHT_0_DEMNR   ( 100 )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_HEIGHT_0_OFFSET  ( -15 )

/* TSR_Sign_Lat_Distance_STD_0_b13 signal Min & Max range limits */
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_LAT_DISTANCE_STD_0_RMIN ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_LAT_DISTANCE_STD_0_RMAX ( 6300U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_LAT_DISTANCE_STD_0_NUMR ( 1 )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_LAT_DISTANCE_STD_0_DEMNR ( 100 )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_LAT_DISTANCE_STD_0_OFFSET ( -32 )

/* Reserved_6_0_b4 signal Min & Max range limits */
#define C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_6_0_RMIN         ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_6_0_RMAX         ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_6_0_NUMR         ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_6_0_DEMNR        ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_6_0_OFFSET       ( 0U )

/* TSR_Sign_Lateral_Distance_0_b13 signal Min & Max range limits */
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_LATERAL_DISTANCE_0_RMIN ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_LATERAL_DISTANCE_0_RMAX ( 6300U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_LATERAL_DISTANCE_0_NUMR ( 1 )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_LATERAL_DISTANCE_0_DEMNR ( 100 )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_LATERAL_DISTANCE_0_OFFSET ( -32 )

/* TSR_Sign_Long_Distance_STD_0_b15 signal Min & Max range limits */
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_LONG_DISTANCE_STD_0_RMIN ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_LONG_DISTANCE_STD_0_RMAX ( 20000U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_LONG_DISTANCE_STD_0_NUMR ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_LONG_DISTANCE_STD_0_DEMNR ( 100U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_LONG_DISTANCE_STD_0_OFFSET ( 0U )

/* Reserved_5_0_b7 signal Min & Max range limits */
#define C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_5_0_RMIN         ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_5_0_RMAX         ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_5_0_NUMR         ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_5_0_DEMNR        ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_5_0_OFFSET       ( 0U )

/* TSR_Sign_Long_Distance_0_b15 signal Min & Max range limits */
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_LONG_DISTANCE_0_RMIN ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_LONG_DISTANCE_0_RMAX ( 25000U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_LONG_DISTANCE_0_NUMR ( 1 )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_LONG_DISTANCE_0_DEMNR ( 100 )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_LONG_DISTANCE_0_OFFSET ( -50 )

/* TSR_Tracking_Age_0_b10 signal Min & Max range limits */
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_TRACKING_AGE_0_RMIN   ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_TRACKING_AGE_0_RMAX   ( 1000U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_TRACKING_AGE_0_NUMR   ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_TRACKING_AGE_0_DEMNR  ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_TRACKING_AGE_0_OFFSET ( 0U )

/* Reserved_4_0_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_4_0_RMIN         ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_4_0_RMAX         ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_4_0_NUMR         ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_4_0_DEMNR        ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_4_0_OFFSET       ( 0U )

/* TSR_Sign_Structure_0_b3 signal Enums */
typedef uint8 CORETRAFFICSIGNvOTSRSignStructure0;
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_STRUCTURE_0_UNKNOWN ( CORETRAFFICSIGNvOTSRSignStructure0 ) ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_STRUCTURE_0_STANDARD ( CORETRAFFICSIGNvOTSRSignStructure0 ) ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_STRUCTURE_0_RESERVED ( CORETRAFFICSIGNvOTSRSignStructure0 ) ( 2U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_STRUCTURE_0_ELECTRONIC ( CORETRAFFICSIGNvOTSRSignStructure0 ) ( 3U )

/* TSR_Sign_Structure_0_b3 signal Min & Max range limits */
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_STRUCTURE_0_RMIN ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_STRUCTURE_0_RMAX ( 3U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_STRUCTURE_0_NUMR ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_STRUCTURE_0_DEMNR ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_STRUCTURE_0_OFFSET ( 0U )

/* TSR_Sign_Shape_0_b4 signal Enums */
typedef uint8 CORETRAFFICSIGNvOTSRSignShape0;
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_SHAPE_0_UNKNOWN  ( CORETRAFFICSIGNvOTSRSignShape0 ) ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_SHAPE_0_CIRCLE   ( CORETRAFFICSIGNvOTSRSignShape0 ) ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_SHAPE_0_RECTANGLE ( CORETRAFFICSIGNvOTSRSignShape0 ) ( 2U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_SHAPE_0_TRIANGLE_UP ( CORETRAFFICSIGNvOTSRSignShape0 ) ( 3U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_SHAPE_0_TRIANGLE_DOWN ( CORETRAFFICSIGNvOTSRSignShape0 ) ( 4U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_SHAPE_0_DIAMOND  ( CORETRAFFICSIGNvOTSRSignShape0 ) ( 5U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_SHAPE_0_PENTAGON ( CORETRAFFICSIGNvOTSRSignShape0 ) ( 6U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_SHAPE_0_RESERVED_2 ( CORETRAFFICSIGNvOTSRSignShape0 ) ( 7U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_SHAPE_0_RESERVED_3 ( CORETRAFFICSIGNvOTSRSignShape0 ) ( 8U )

/* TSR_Sign_Shape_0_b4 signal Min & Max range limits */
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_SHAPE_0_RMIN     ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_SHAPE_0_RMAX     ( 8U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_SHAPE_0_NUMR     ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_SHAPE_0_DEMNR    ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_SHAPE_0_OFFSET   ( 0U )

/* TSR_Confidence_0_b7 signal Min & Max range limits */
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_CONFIDENCE_0_RMIN     ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_CONFIDENCE_0_RMAX     ( 100U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_CONFIDENCE_0_NUMR     ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_CONFIDENCE_0_DEMNR    ( 100U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_CONFIDENCE_0_OFFSET   ( 0U )

/* TSR_Sup2_Position_0_b3 signal Enums */
typedef uint8 CORETRAFFICSIGNvOTSRSup2Position0;
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SUP2_POSITION_0_INVALID ( CORETRAFFICSIGNvOTSRSup2Position0 ) ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SUP2_POSITION_0_LEFT  ( CORETRAFFICSIGNvOTSRSup2Position0 ) ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SUP2_POSITION_0_RIGHT ( CORETRAFFICSIGNvOTSRSup2Position0 ) ( 2U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SUP2_POSITION_0_TOP   ( CORETRAFFICSIGNvOTSRSup2Position0 ) ( 3U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SUP2_POSITION_0_BOTTOM ( CORETRAFFICSIGNvOTSRSup2Position0 ) ( 4U )

/* TSR_Sup2_Position_0_b3 signal Min & Max range limits */
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SUP2_POSITION_0_RMIN  ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SUP2_POSITION_0_RMAX  ( 4U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SUP2_POSITION_0_NUMR  ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SUP2_POSITION_0_DEMNR ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SUP2_POSITION_0_OFFSET ( 0U )

/* TSR_Sup2_Confidence_0_b7 signal Min & Max range limits */
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SUP2_CONFIDENCE_0_RMIN ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SUP2_CONFIDENCE_0_RMAX ( 100U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SUP2_CONFIDENCE_0_NUMR ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SUP2_CONFIDENCE_0_DEMNR ( 100U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SUP2_CONFIDENCE_0_OFFSET ( 0U )

/* Reserved_3_0_b2 signal Min & Max range limits */
#define C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_3_0_RMIN         ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_3_0_RMAX         ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_3_0_NUMR         ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_3_0_DEMNR        ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_3_0_OFFSET       ( 0U )

/* TSR_Sup2_SignName_0_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SUP2_SIGNNAME_0_RMIN  ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SUP2_SIGNNAME_0_RMAX  ( 255U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SUP2_SIGNNAME_0_NUMR  ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SUP2_SIGNNAME_0_DEMNR ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SUP2_SIGNNAME_0_OFFSET ( 0U )

/* TSR_Sup1_Position_0_b3 signal Enums */
typedef uint8 CORETRAFFICSIGNvOTSRSup1Position0;
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SUP1_POSITION_0_INVALID ( CORETRAFFICSIGNvOTSRSup1Position0 ) ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SUP1_POSITION_0_LEFT  ( CORETRAFFICSIGNvOTSRSup1Position0 ) ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SUP1_POSITION_0_RIGHT ( CORETRAFFICSIGNvOTSRSup1Position0 ) ( 2U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SUP1_POSITION_0_TOP   ( CORETRAFFICSIGNvOTSRSup1Position0 ) ( 3U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SUP1_POSITION_0_BOTTOM ( CORETRAFFICSIGNvOTSRSup1Position0 ) ( 4U )

/* TSR_Sup1_Position_0_b3 signal Min & Max range limits */
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SUP1_POSITION_0_RMIN  ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SUP1_POSITION_0_RMAX  ( 4U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SUP1_POSITION_0_NUMR  ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SUP1_POSITION_0_DEMNR ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SUP1_POSITION_0_OFFSET ( 0U )

/* TSR_Sup1_Confidence_0_b7 signal Min & Max range limits */
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SUP1_CONFIDENCE_0_RMIN ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SUP1_CONFIDENCE_0_RMAX ( 100U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SUP1_CONFIDENCE_0_NUMR ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SUP1_CONFIDENCE_0_DEMNR ( 100U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SUP1_CONFIDENCE_0_OFFSET ( 0U )

/* TSR_Sup1_SignName_0_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SUP1_SIGNNAME_0_RMIN  ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SUP1_SIGNNAME_0_RMAX  ( 255U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SUP1_SIGNNAME_0_NUMR  ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SUP1_SIGNNAME_0_DEMNR ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SUP1_SIGNNAME_0_OFFSET ( 0U )

/* TSR_Filter_Type_0_b4 signal Enums */
typedef uint8 CORETRAFFICSIGNvOTSRFilterType0;
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_FILTER_TYPE_0_NO_SLI_FILTER ( CORETRAFFICSIGNvOTSRFilterType0 ) ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_FILTER_TYPE_0_TRUCK   ( CORETRAFFICSIGNvOTSRFilterType0 ) ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_FILTER_TYPE_0_EMBEDDED ( CORETRAFFICSIGNvOTSRFilterType0 ) ( 2U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_FILTER_TYPE_0_MINIMUM ( CORETRAFFICSIGNvOTSRFilterType0 ) ( 3U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_FILTER_TYPE_0_ROAD_NUMBER ( CORETRAFFICSIGNvOTSRFilterType0 ) ( 4U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_FILTER_TYPE_0_RESERVED_1 ( CORETRAFFICSIGNvOTSRFilterType0 ) ( 5U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_FILTER_TYPE_0_RESERVED_2 ( CORETRAFFICSIGNvOTSRFilterType0 ) ( 6U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_FILTER_TYPE_0_RESERVED_3 ( CORETRAFFICSIGNvOTSRFilterType0 ) ( 7U )

/* TSR_Filter_Type_0_b4 signal Min & Max range limits */
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_FILTER_TYPE_0_RMIN    ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_FILTER_TYPE_0_RMAX    ( 7U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_FILTER_TYPE_0_NUMR    ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_FILTER_TYPE_0_DEMNR   ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_FILTER_TYPE_0_OFFSET  ( 0U )

/* Reserved_2_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_2_0_RMIN         ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_2_0_RMAX         ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_2_0_NUMR         ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_2_0_DEMNR        ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_RESERVED_2_0_OFFSET       ( 0U )

/* TSR_Relevancy_0_b5 signal Enums */
typedef uint8 CORETRAFFICSIGNvOTSRRelevancy0;
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_RELEVANCY_0_RELEVANT_SIGN ( CORETRAFFICSIGNvOTSRRelevancy0 ) ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_RELEVANCY_0_HIGHWAY_EXIT_SIGN ( CORETRAFFICSIGNvOTSRRelevancy0 ) ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_RELEVANCY_0_LANE_ASSIGNMENT_SIGN ( CORETRAFFICSIGNvOTSRRelevancy0 ) ( 2U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_RELEVANCY_0_PARALLEL_ROAD_SIGN ( CORETRAFFICSIGNvOTSRRelevancy0 ) ( 3U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_RELEVANCY_0_SIGN_ON_TURN ( CORETRAFFICSIGNvOTSRRelevancy0 ) ( 4U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_RELEVANCY_0_FAR_IRRELEVANT_SIGN ( CORETRAFFICSIGNvOTSRRelevancy0 ) ( 5U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_RELEVANCY_0_INTERNAL_SIGN_CONTRADICTION ( CORETRAFFICSIGNvOTSRRelevancy0 ) ( 6U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_RELEVANCY_0_ERROR_SIGN_CODE ( CORETRAFFICSIGNvOTSRRelevancy0 ) ( 7U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_RELEVANCY_0_CIPV_IN_FRONT ( CORETRAFFICSIGNvOTSRRelevancy0 ) ( 8U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_RELEVANCY_0_CONTRADICT_ARROW_SIGN ( CORETRAFFICSIGNvOTSRRelevancy0 ) ( 9U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_RELEVANCY_0_OTHER_FILTER_REASON ( CORETRAFFICSIGNvOTSRRelevancy0 ) ( 10U )

/* TSR_Relevancy_0_b5 signal Min & Max range limits */
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_RELEVANCY_0_RMIN      ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_RELEVANCY_0_RMAX      ( 13U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_RELEVANCY_0_NUMR      ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_RELEVANCY_0_DEMNR     ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_RELEVANCY_0_OFFSET    ( 0U )

/* TSR_Sign_Name_0_b10 signal Min & Max range limits */
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_NAME_0_RMIN      ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_NAME_0_RMAX      ( 1023U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_NAME_0_NUMR      ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_NAME_0_DEMNR     ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_SIGN_NAME_0_OFFSET    ( 0U )

/* TSR_Camera_Source_0_b8 signal Enums */
typedef uint8 CORETRAFFICSIGNvOTSRCameraSource0;
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_CAMERA_SOURCE_0_FRONT_MAIN ( CORETRAFFICSIGNvOTSRCameraSource0 ) ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_CAMERA_SOURCE_0_FRONT_NARROW ( CORETRAFFICSIGNvOTSRCameraSource0 ) ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_CAMERA_SOURCE_0_FRONT_FISHEYE ( CORETRAFFICSIGNvOTSRCameraSource0 ) ( 2U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_CAMERA_SOURCE_0_REAR  ( CORETRAFFICSIGNvOTSRCameraSource0 ) ( 3U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_CAMERA_SOURCE_0_REAR_CORNER_LEFT ( CORETRAFFICSIGNvOTSRCameraSource0 ) ( 4U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_CAMERA_SOURCE_0_REAR_CORNER_RIGHT ( CORETRAFFICSIGNvOTSRCameraSource0 ) ( 5U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_CAMERA_SOURCE_0_FRONT_CORNER_LEFT ( CORETRAFFICSIGNvOTSRCameraSource0 ) ( 6U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_CAMERA_SOURCE_0_FRONT_CORNER_RIGHT ( CORETRAFFICSIGNvOTSRCameraSource0 ) ( 7U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_CAMERA_SOURCE_0_PARKING_FRONT ( CORETRAFFICSIGNvOTSRCameraSource0 ) ( 8U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_CAMERA_SOURCE_0_PARKING_REAR ( CORETRAFFICSIGNvOTSRCameraSource0 ) ( 9U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_CAMERA_SOURCE_0_PARKING_LEFT ( CORETRAFFICSIGNvOTSRCameraSource0 ) ( 10U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_CAMERA_SOURCE_0_PARKING_RIGHT ( CORETRAFFICSIGNvOTSRCameraSource0 ) ( 11U )

/* TSR_Camera_Source_0_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_CAMERA_SOURCE_0_RMIN  ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_CAMERA_SOURCE_0_RMAX  ( 255U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_CAMERA_SOURCE_0_NUMR  ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_CAMERA_SOURCE_0_DEMNR ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_CAMERA_SOURCE_0_OFFSET ( 0U )

/* TSR_ID_0_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_ID_0_RMIN             ( 0U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_ID_0_RMAX             ( 255U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_ID_0_NUMR             ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_ID_0_DEMNR            ( 1U )
#define C_EYEQMSG_CORETRAFFICSIGNvO_TSR_ID_0_OFFSET           ( 0U )


/*****************************************************************************
                  Exported function-like macros
*****************************************************************************/
/*****************************************************************************
                  Exported defined macros
*****************************************************************************/
/*****************************************************************************
                  Exported types, enums definitions
*****************************************************************************/
typedef struct
{
   #if ENABLE_BIG_ENDIAN_FORMAT
      uint32        TSR_Zero_byte_b8                             : 8U;
      
      uint32        TSR_Protocol_Version_b8                      : 8U;
      
      uint32        TSR_Sync_ID_b8                               : 8U;
      
      uint32        unused1_b3                                   : 3;
      uint32        TSR_Approved_Sign_Count_b5                   : 5U;
      
      uint32        TSR_Filtered_Sign_Count_b3                   : 3U;
      
      uint32        TSR_UnderTracking_Sign_Count_b5              : 5U;
      
      uint32        Reserved_1_1_b3                              : 3U;
      
      uint32        Reserved_1_2_b8                              : 8U;
      
      uint32        Reserved_1_3_b8                              : 8U;
      
      uint32        Reserved_1_4_b8                              : 8U;
      
   #else
      uint32        TSR_Zero_byte_b8                             : 8U;
      
      uint32        TSR_Protocol_Version_b8                      : 8U;
      
      uint32        TSR_Sync_ID_b8                               : 8U;
      
      uint32        TSR_Approved_Sign_Count_b5                   : 5U;
      
      uint32        TSR_Filtered_Sign_Count_b3                   : 3U;
      
      uint32        TSR_UnderTracking_Sign_Count_b5              : 5U;
      
      uint32        Reserved_1_b27                               : 27U;
      
   #endif
} EYEQMSG_CORETRAFFICSIGNvH_Params_t;


typedef struct
{
   #if ENABLE_BIG_ENDIAN_FORMAT
      uint32        unused1_b64                                  : 64;
      uint32        TSR_ID_0_b8                                  : 8U;
      
      uint32        TSR_Camera_Source_0_b8                       : 8U;
      
      uint32        TSR_Sign_Name_0_1_b8                         : 8U;
      
      uint32        unused2_b6                                   : 6;
      uint32        TSR_Sign_Name_0_2_b2                         : 2U;
      
      uint32        TSR_Relevancy_0_b5                           : 5U;
      
      uint32        Reserved_2_0_b1                              : 1U;
      
      uint32        TSR_Filter_Type_0_b4                         : 4U;
      
      uint32        TSR_Sup1_SignName_0_1_b4                     : 4U;
      
      uint32        TSR_Sup1_SignName_0_2_b4                     : 4U;
      
      uint32        TSR_Sup1_Confidence_0_1_b4                   : 4U;
      
      uint32        TSR_Sup1_Confidence_0_2_b3                   : 3U;
      
      uint32        TSR_Sup1_Position_0_b3                       : 3U;
      
      uint32        TSR_Sup2_SignName_0_1_b2                     : 2U;
      
      uint32        TSR_Sup2_SignName_0_2_b6                     : 6U;
      
      uint32        Reserved_3_0_b2                              : 2U;
      
      uint32        TSR_Sup2_Confidence_0_b7                     : 7U;
      
      uint32        TSR_Sup2_Position_0_1_b1                     : 1U;
      
      uint32        TSR_Sup2_Position_0_2_b2                     : 2U;
      
      uint32        TSR_Confidence_0_1_b6                        : 6U;
      
      uint32        unused3_b1                                   : 1;
      uint32        TSR_Confidence_0_2_b1                        : 1U;
      
      uint32        TSR_Sign_Shape_0_b4                          : 4U;
      
      uint32        TSR_Sign_Structure_0_b3                      : 3U;
      
      uint32        Reserved_4_0_b8                              : 8U;
      
      uint32        TSR_Tracking_Age_0_1_b8                      : 8U;
      
      uint32        TSR_Tracking_Age_0_2_b2                      : 2U;
      
      uint32        TSR_Sign_Long_Distance_0_1_b6                : 6U;
      
      uint32        TSR_Sign_Long_Distance_0_2_b8                : 8U;
      
      uint32        TSR_Sign_Long_Distance_0_3_b1                : 1U;
      
      uint32        Reserved_5_0_b7                              : 7U;
      
      uint32        TSR_Sign_Long_Distance_STD_0_1_b8            : 8U;
      
      uint32        TSR_Sign_Long_Distance_STD_0_2_b7            : 7U;
      
      uint32        TSR_Sign_Lateral_Distance_0_1_b1             : 1U;
      
      uint32        TSR_Sign_Lateral_Distance_0_2_b8             : 8U;
      
      uint32        TSR_Sign_Lateral_Distance_0_3_b4             : 4U;
      
      uint32        Reserved_6_0_b4                              : 4U;
      
      uint32        TSR_Sign_Lat_Distance_STD_0_1_b8             : 8U;
      
      uint32        TSR_Sign_Lat_Distance_STD_0_2_b5             : 5U;
      
      uint32        TSR_Sign_Height_0_1_b3                       : 3U;
      
      uint32        TSR_Sign_Height_0_2_b8                       : 8U;
      
      uint32        TSR_Sign_Height_0_3_b4                       : 4U;
      
      uint32        Reserved_7_0_b4                              : 4U;
      
      uint32        TSR_Sign_Panel_Height_STD_0_1_b8             : 8U;
      
      uint32        TSR_Sign_Panel_Height_STD_0_2_b2             : 2U;
      
      uint32        TSR_Sign_Height_STD_0_1_b6                   : 6U;
      
      uint32        TSR_Sign_Height_STD_0_2_b8                   : 8U;
      
      uint32        TSR_Sign_Height_STD_0_3_b1                   : 1U;
      
      uint32        Reserved_8_0_b7                              : 7U;
      
      uint32        TSR_Sign_Panel_Width_0_1_b8                  : 8U;
      
      uint32        TSR_Sign_Panel_Width_0_2_b2                  : 2U;
      
      uint32        TSR_Sign_Panel_Height_0_1_b6                 : 6U;
      
      uint32        TSR_Sign_Panel_Height_0_2_b4                 : 4U;
      
      uint32        TSR_Sign_Panel_Width_STD_0_1_b4              : 4U;
      
      uint32        TSR_Sign_Panel_Width_STD_0_2_b6              : 6U;
      
      uint32        Reserved_9_0_b2                              : 2U;
      
      uint32        TSR_Measurement_Status_0_b3                  : 3U;
      
      uint32        TSR_AngleZ_0_1_b5                            : 5U;
      
      uint32        TSR_AngleZ_0_2_b5                            : 5U;
      
      uint32        TSR_Relevancy_Confidence_0_1_b3              : 3U;
      
      uint32        TSR_Relevancy_Confidence_0_2_b4              : 4U;
      
      uint32        Reserved_10_0_1_b4                           : 4U;
      
      uint32        Reserved_10_0_2_b8                           : 8U;
      
   #else
      uint32        TSR_ID_0_b8                                  : 8U;
      
      uint32        TSR_Camera_Source_0_b8                       : 8U;
      
      uint32        TSR_Sign_Name_0_b10                          : 10U;
      
      uint32        TSR_Relevancy_0_b5                           : 5U;
      
      uint32        Reserved_2_0_b1                              : 1U;
      
      uint32        TSR_Filter_Type_0_b4                         : 4U;
      
      uint32        TSR_Sup1_SignName_0_b8                       : 8U;
      
      uint32        TSR_Sup1_Confidence_0_b7                     : 7U;
      
      uint32        TSR_Sup1_Position_0_b3                       : 3U;
      
      uint32        TSR_Sup2_SignName_0_b8                       : 8U;
      
      uint32        Reserved_3_0_b2                              : 2U;
      
      uint32        TSR_Sup2_Confidence_0_b7                     : 7U;
      
      uint32        TSR_Sup2_Position_0_b3                       : 3U;
      
      uint32        TSR_Confidence_0_b7                          : 7U;
      
      uint32        TSR_Sign_Shape_0_b4                          : 4U;
      
      uint32        TSR_Sign_Structure_0_b3                      : 3U;
      
      uint32        Reserved_4_0_b8                              : 8U;
      
      uint32        TSR_Tracking_Age_0_b10                       : 10U;
      
      uint32        TSR_Sign_Long_Distance_0_b15                 : 15U;
      
      uint32        Reserved_5_0_b7                              : 7U;
      
      uint32        TSR_Sign_Long_Distance_STD_0_b15             : 15U;
      
      uint32        TSR_Sign_Lateral_Distance_0_b13              : 13U;
      
      uint32        Reserved_6_0_b4                              : 4U;
      
      uint32        TSR_Sign_Lat_Distance_STD_0_b13              : 13U;
      
      uint32        TSR_Sign_Height_0_b15                        : 15U;
      
      uint32        Reserved_7_0_b4                              : 4U;
      
      uint32        TSR_Sign_Panel_Height_STD_0_b10              : 10U;
      
      uint32        TSR_Sign_Height_STD_0_b15                    : 15U;
      
      uint32        Reserved_8_0_b7                              : 7U;
      
      uint32        TSR_Sign_Panel_Width_0_b10                   : 10U;
      
      uint32        TSR_Sign_Panel_Height_0_b10                  : 10U;
      
      uint32        TSR_Sign_Panel_Width_STD_0_b10               : 10U;
      
      uint32        Reserved_9_0_b2                              : 2U;
      
      uint32        TSR_Measurement_Status_0_b3                  : 3U;
      
      uint32        TSR_AngleZ_0_b10                             : 10U;
      
      uint32        TSR_Relevancy_Confidence_0_b7                : 7U;
      
      uint32        Reserved_10_0_b12                            : 12U;
      
   #endif
} EYEQMSG_CORETRAFFICSIGNvO_Params_t;


typedef struct
{
   EYEQMSG_CORETRAFFICSIGNvH_Params_t EYEQMSG_CORETRAFFICSIGNvH_Params_s;
   EYEQMSG_CORETRAFFICSIGNvO_Params_t EYEQMSG_CORETRAFFICSIGNvO_Params_as[C_EYEQMSG_CORETRAFFICSIGNvH_VIRTUAL_OBJECT_INDEX_RMAX];
} EYEQMSG_CORETRAFFICSIGN_Params_t;


/*****************************************************************************
                  Exported function prototypes
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvH_TSR_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pTSR_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Zero_byte
*    TSR_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Zero_byte signal value of Virtual_HEADER_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvH_TSR_Zero_byte( uint8 * pTSR_Zero_byte );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvH_TSR_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pTSR_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Protocol_Version
*    TSR_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Protocol_Version signal value of Virtual_HEADER_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvH_TSR_Protocol_Version( uint8 * pTSR_Protocol_Version );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvH_TSR_Sync_ID
*
* FUNCTION ARGUMENTS:
*    uint8 * pTSR_Sync_ID - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Sync_ID
*    TSR_Sync_ID returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Sync_ID signal value of Virtual_HEADER_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvH_TSR_Sync_ID( uint8 * pTSR_Sync_ID );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvH_TSR_Approved_Sign_Count
*
* FUNCTION ARGUMENTS:
*    uint8 * pTSR_Approved_Sign_Count - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Approved_Sign_Count
*    TSR_Approved_Sign_Count returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Approved_Sign_Count signal value of Virtual_HEADER_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvH_TSR_Approved_Sign_Count( uint8 * pTSR_Approved_Sign_Count );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvH_TSR_Filtered_Sign_Count
*
* FUNCTION ARGUMENTS:
*    uint8 * pTSR_Filtered_Sign_Count - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Filtered_Sign_Count
*    TSR_Filtered_Sign_Count returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Filtered_Sign_Count signal value of Virtual_HEADER_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvH_TSR_Filtered_Sign_Count( uint8 * pTSR_Filtered_Sign_Count );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvH_TSR_UnderTracking_Sign_Count
*
* FUNCTION ARGUMENTS:
*    uint8 * pTSR_UnderTracking_Sign_Count - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_UnderTracking_Sign_Count
*    TSR_UnderTracking_Sign_Count returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_UnderTracking_Sign_Count signal value of Virtual_HEADER_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvH_TSR_UnderTracking_Sign_Count( uint8 * pTSR_UnderTracking_Sign_Count );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvH_Reserved_1
*
* FUNCTION ARGUMENTS:
*    uint32 * pReserved_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1
*    Reserved_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1 signal value of Virtual_HEADER_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvH_Reserved_1( uint32 * pReserved_1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_ID_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pTSR_ID_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_ID_0
*    TSR_ID_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_ID_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_ID_0( uint8 objIndx_u8, uint8 * pTSR_ID_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Camera_Source_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORETRAFFICSIGNvOTSRCameraSource0 * pTSR_Camera_Source_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Camera_Source_0
*    TSR_Camera_Source_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Camera_Source_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Camera_Source_0( uint8 objIndx_u8, CORETRAFFICSIGNvOTSRCameraSource0 * pTSR_Camera_Source_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Name_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pTSR_Sign_Name_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Sign_Name_0
*    TSR_Sign_Name_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Sign_Name_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Name_0( uint8 objIndx_u8, uint16 * pTSR_Sign_Name_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Relevancy_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORETRAFFICSIGNvOTSRRelevancy0 * pTSR_Relevancy_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Relevancy_0
*    TSR_Relevancy_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Relevancy_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Relevancy_0( uint8 objIndx_u8, CORETRAFFICSIGNvOTSRRelevancy0 * pTSR_Relevancy_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_Reserved_2_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    boolean * pReserved_2_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_2_0
*    Reserved_2_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_2_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_Reserved_2_0( uint8 objIndx_u8, boolean * pReserved_2_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Filter_Type_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORETRAFFICSIGNvOTSRFilterType0 * pTSR_Filter_Type_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Filter_Type_0
*    TSR_Filter_Type_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Filter_Type_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Filter_Type_0( uint8 objIndx_u8, CORETRAFFICSIGNvOTSRFilterType0 * pTSR_Filter_Type_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sup1_SignName_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pTSR_Sup1_SignName_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Sup1_SignName_0
*    TSR_Sup1_SignName_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Sup1_SignName_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sup1_SignName_0( uint8 objIndx_u8, uint8 * pTSR_Sup1_SignName_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sup1_Confidence_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pTSR_Sup1_Confidence_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Sup1_Confidence_0
*    TSR_Sup1_Confidence_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Sup1_Confidence_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sup1_Confidence_0( uint8 objIndx_u8, uint8 * pTSR_Sup1_Confidence_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sup1_Position_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORETRAFFICSIGNvOTSRSup1Position0 * pTSR_Sup1_Position_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Sup1_Position_0
*    TSR_Sup1_Position_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Sup1_Position_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sup1_Position_0( uint8 objIndx_u8, CORETRAFFICSIGNvOTSRSup1Position0 * pTSR_Sup1_Position_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sup2_SignName_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pTSR_Sup2_SignName_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Sup2_SignName_0
*    TSR_Sup2_SignName_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Sup2_SignName_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sup2_SignName_0( uint8 objIndx_u8, uint8 * pTSR_Sup2_SignName_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_Reserved_3_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_3_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_3_0
*    Reserved_3_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_3_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_Reserved_3_0( uint8 objIndx_u8, uint8 * pReserved_3_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sup2_Confidence_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pTSR_Sup2_Confidence_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Sup2_Confidence_0
*    TSR_Sup2_Confidence_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Sup2_Confidence_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sup2_Confidence_0( uint8 objIndx_u8, uint8 * pTSR_Sup2_Confidence_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sup2_Position_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORETRAFFICSIGNvOTSRSup2Position0 * pTSR_Sup2_Position_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Sup2_Position_0
*    TSR_Sup2_Position_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Sup2_Position_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sup2_Position_0( uint8 objIndx_u8, CORETRAFFICSIGNvOTSRSup2Position0 * pTSR_Sup2_Position_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Confidence_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pTSR_Confidence_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Confidence_0
*    TSR_Confidence_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Confidence_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Confidence_0( uint8 objIndx_u8, uint8 * pTSR_Confidence_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Shape_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORETRAFFICSIGNvOTSRSignShape0 * pTSR_Sign_Shape_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Sign_Shape_0
*    TSR_Sign_Shape_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Sign_Shape_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Shape_0( uint8 objIndx_u8, CORETRAFFICSIGNvOTSRSignShape0 * pTSR_Sign_Shape_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Structure_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORETRAFFICSIGNvOTSRSignStructure0 * pTSR_Sign_Structure_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Sign_Structure_0
*    TSR_Sign_Structure_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Sign_Structure_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Structure_0( uint8 objIndx_u8, CORETRAFFICSIGNvOTSRSignStructure0 * pTSR_Sign_Structure_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_Reserved_4_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_4_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_4_0
*    Reserved_4_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_4_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_Reserved_4_0( uint8 objIndx_u8, uint8 * pReserved_4_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Tracking_Age_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pTSR_Tracking_Age_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Tracking_Age_0
*    TSR_Tracking_Age_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Tracking_Age_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Tracking_Age_0( uint8 objIndx_u8, uint16 * pTSR_Tracking_Age_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Long_Distance_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pTSR_Sign_Long_Distance_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Sign_Long_Distance_0
*    TSR_Sign_Long_Distance_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Sign_Long_Distance_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Long_Distance_0( uint8 objIndx_u8, uint16 * pTSR_Sign_Long_Distance_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_Reserved_5_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_5_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_5_0
*    Reserved_5_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_5_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_Reserved_5_0( uint8 objIndx_u8, uint8 * pReserved_5_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Long_Distance_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pTSR_Sign_Long_Distance_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Sign_Long_Distance_STD_0
*    TSR_Sign_Long_Distance_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Sign_Long_Distance_STD_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Long_Distance_STD_0( uint8 objIndx_u8, uint16 * pTSR_Sign_Long_Distance_STD_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Lateral_Distance_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pTSR_Sign_Lateral_Distance_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Sign_Lateral_Distance_0
*    TSR_Sign_Lateral_Distance_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Sign_Lateral_Distance_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Lateral_Distance_0( uint8 objIndx_u8, uint16 * pTSR_Sign_Lateral_Distance_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_Reserved_6_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_6_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_6_0
*    Reserved_6_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_6_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_Reserved_6_0( uint8 objIndx_u8, uint8 * pReserved_6_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Lat_Distance_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pTSR_Sign_Lat_Distance_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Sign_Lat_Distance_STD_0
*    TSR_Sign_Lat_Distance_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Sign_Lat_Distance_STD_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Lat_Distance_STD_0( uint8 objIndx_u8, uint16 * pTSR_Sign_Lat_Distance_STD_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Height_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pTSR_Sign_Height_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Sign_Height_0
*    TSR_Sign_Height_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Sign_Height_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Height_0( uint8 objIndx_u8, uint16 * pTSR_Sign_Height_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_Reserved_7_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_7_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_7_0
*    Reserved_7_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_7_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_Reserved_7_0( uint8 objIndx_u8, uint8 * pReserved_7_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Panel_Height_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pTSR_Sign_Panel_Height_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Sign_Panel_Height_STD_0
*    TSR_Sign_Panel_Height_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Sign_Panel_Height_STD_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Panel_Height_STD_0( uint8 objIndx_u8, uint16 * pTSR_Sign_Panel_Height_STD_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Height_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pTSR_Sign_Height_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Sign_Height_STD_0
*    TSR_Sign_Height_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Sign_Height_STD_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Height_STD_0( uint8 objIndx_u8, uint16 * pTSR_Sign_Height_STD_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_Reserved_8_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_8_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_8_0
*    Reserved_8_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_8_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_Reserved_8_0( uint8 objIndx_u8, uint8 * pReserved_8_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Panel_Width_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pTSR_Sign_Panel_Width_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Sign_Panel_Width_0
*    TSR_Sign_Panel_Width_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Sign_Panel_Width_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Panel_Width_0( uint8 objIndx_u8, uint16 * pTSR_Sign_Panel_Width_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Panel_Height_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pTSR_Sign_Panel_Height_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Sign_Panel_Height_0
*    TSR_Sign_Panel_Height_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Sign_Panel_Height_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Panel_Height_0( uint8 objIndx_u8, uint16 * pTSR_Sign_Panel_Height_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Panel_Width_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pTSR_Sign_Panel_Width_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Sign_Panel_Width_STD_0
*    TSR_Sign_Panel_Width_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Sign_Panel_Width_STD_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Sign_Panel_Width_STD_0( uint8 objIndx_u8, uint16 * pTSR_Sign_Panel_Width_STD_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_Reserved_9_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_9_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_9_0
*    Reserved_9_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_9_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_Reserved_9_0( uint8 objIndx_u8, uint8 * pReserved_9_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Measurement_Status_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORETRAFFICSIGNvOTSRMeasurementStatus0 * pTSR_Measurement_Status_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Measurement_Status_0
*    TSR_Measurement_Status_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Measurement_Status_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Measurement_Status_0( uint8 objIndx_u8, CORETRAFFICSIGNvOTSRMeasurementStatus0 * pTSR_Measurement_Status_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_AngleZ_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pTSR_AngleZ_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_AngleZ_0
*    TSR_AngleZ_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_AngleZ_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_AngleZ_0( uint8 objIndx_u8, uint16 * pTSR_AngleZ_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Relevancy_Confidence_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pTSR_Relevancy_Confidence_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TSR_Relevancy_Confidence_0
*    TSR_Relevancy_Confidence_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TSR_Relevancy_Confidence_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_TSR_Relevancy_Confidence_0( uint8 objIndx_u8, uint8 * pTSR_Relevancy_Confidence_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETRAFFICSIGNvO_Reserved_10_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pReserved_10_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_10_0
*    Reserved_10_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_10_0 signal value of Virtual_OBJECT_msg_Core_Traffic_Signs_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETRAFFICSIGNvO_Reserved_10_0( uint8 objIndx_u8, uint16 * pReserved_10_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_CORETRAFFICSIGN_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_CORETRAFFICSIGN_Params_t * pCore_Traffic_Signs_protocol - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_Traffic_Signs_protocol message 
*    Core_Traffic_Signs_protocol message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_Traffic_Signs_protocol message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_CORETRAFFICSIGN_ParamsApp_MsgDataStruct( EYEQMSG_CORETRAFFICSIGN_Params_t * pCore_Traffic_Signs_protocol );
/*****************************************************************************
                  Exported object declarations
*****************************************************************************/
extern EYEQMSG_CORETRAFFICSIGN_Params_t   EYEQMSG_CORETRAFFICSIGN_Params_s;
extern EYEQMSG_CORETRAFFICSIGN_Params_t   EYEQMSG_CORETRAFFICSIGN_ParamsApp_s;
/****************************************************************************/
#endif /* _EYEQMSG_CORETRAFFICSIGNPROCESS_H_ */


