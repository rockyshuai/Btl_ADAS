

/*****************************************************************************
                  Include files
*****************************************************************************/
/* The suggested include file order is: */
#include "EyeQ_defs.h"    /* EyeQ project common definitions file    */

#include "EYEQMSG_CoreLaneApplProcess.h"

/*****************************************************************************
                  Local symbolic constants
*****************************************************************************/
/*****************************************************************************
                  Local types, enums definitions
*****************************************************************************/
/*****************************************************************************
                  Local function prototypes
*****************************************************************************/
/*****************************************************************************
                  Local object definitions
*****************************************************************************/
/*****************************************************************************
                  Exported object definitions
*****************************************************************************/
EYEQMSG_CORELANEAPPL_Params_t   EYEQMSG_CORELANEAPPL_Params_s;
EYEQMSG_CORELANEAPPL_Params_t   EYEQMSG_CORELANEAPPL_ParamsApp_s;
/*****************************************************************************
                  Local function-like macros
*****************************************************************************/
/*****************************************************************************
                  Local defined macros
*****************************************************************************/
/*****************************************************************************
                  Function definitions
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pLAP_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Zero_byte
*    LAP_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Zero_byte signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Zero_byte( uint8 * pLAP_Zero_byte )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pLAP_Zero_byte != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvH_Params_s.LAP_Zero_byte_b8;
      * pLAP_Zero_byte = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pLAP_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Protocol_Version
*    LAP_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Protocol_Version signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Protocol_Version( uint8 * pLAP_Protocol_Version )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pLAP_Protocol_Version != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvH_Params_s.LAP_Protocol_Version_b8;
      * pLAP_Protocol_Version = signal_value;
      if( (signal_value >= C_EYEQMSG_CORELANEAPPLvH_LAP_PROTOCOL_VERSION_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORELANEAPPLvH_LAP_PROTOCOL_VERSION_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Sync_ID
*
* FUNCTION ARGUMENTS:
*    uint8 * pLAP_Sync_ID - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Sync_ID
*    LAP_Sync_ID returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Sync_ID signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Sync_ID( uint8 * pLAP_Sync_ID )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pLAP_Sync_ID != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvH_Params_s.LAP_Sync_ID_b8;
      * pLAP_Sync_ID = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Is_Construction_Area
*
* FUNCTION ARGUMENTS:
*    CORELANEAPPLvHLAPIsConstructionArea * pLAP_Is_Construction_Area - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Is_Construction_Area
*    LAP_Is_Construction_Area returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Is_Construction_Area signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Is_Construction_Area( CORELANEAPPLvHLAPIsConstructionArea * pLAP_Is_Construction_Area )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELANEAPPLvHLAPIsConstructionArea signal_value;
   
   if( pLAP_Is_Construction_Area != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvH_Params_s.LAP_Is_Construction_Area_b1;
      * pLAP_Is_Construction_Area = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Snow_On_Road
*
* FUNCTION ARGUMENTS:
*    CORELANEAPPLvHLAPSnowOnRoad * pLAP_Snow_On_Road - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Snow_On_Road
*    LAP_Snow_On_Road returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Snow_On_Road signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Snow_On_Road( CORELANEAPPLvHLAPSnowOnRoad * pLAP_Snow_On_Road )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELANEAPPLvHLAPSnowOnRoad signal_value;
   
   if( pLAP_Snow_On_Road != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvH_Params_s.LAP_Snow_On_Road_b7;
      * pLAP_Snow_On_Road = signal_value;
      if( signal_value <= C_EYEQMSG_CORELANEAPPLvH_LAP_SNOW_ON_ROAD_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_INTP_Available
*
* FUNCTION ARGUMENTS:
*    CORELANEAPPLvHLAPINTPAvailable * pLAP_INTP_Available - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_INTP_Available
*    LAP_INTP_Available returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_INTP_Available signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_INTP_Available( CORELANEAPPLvHLAPINTPAvailable * pLAP_INTP_Available )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELANEAPPLvHLAPINTPAvailable signal_value;
   
   if( pLAP_INTP_Available != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvH_Params_s.LAP_INTP_Available_b1;
      * pLAP_INTP_Available = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_INTP_Count
*
* FUNCTION ARGUMENTS:
*    uint8 * pLAP_INTP_Count - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_INTP_Count
*    LAP_INTP_Count returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_INTP_Count signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_INTP_Count( uint8 * pLAP_INTP_Count )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pLAP_INTP_Count != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvH_Params_s.LAP_INTP_Count_b4;
      * pLAP_INTP_Count = signal_value;
      if( signal_value <= C_EYEQMSG_CORELANEAPPLvH_LAP_INTP_COUNT_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Exit_Merge_Available
*
* FUNCTION ARGUMENTS:
*    CORELANEAPPLvHLAPExitMergeAvailable * pLAP_Exit_Merge_Available - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Exit_Merge_Available
*    LAP_Exit_Merge_Available returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Exit_Merge_Available signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Exit_Merge_Available( CORELANEAPPLvHLAPExitMergeAvailable * pLAP_Exit_Merge_Available )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELANEAPPLvHLAPExitMergeAvailable signal_value;
   
   if( pLAP_Exit_Merge_Available != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvH_Params_s.LAP_Exit_Merge_Available_b1;
      * pLAP_Exit_Merge_Available = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Is_Highway_Merge_Left
*
* FUNCTION ARGUMENTS:
*    CORELANEAPPLvHLAPIsHighwayMergeLeft * pLAP_Is_Highway_Merge_Left - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Is_Highway_Merge_Left
*    LAP_Is_Highway_Merge_Left returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Is_Highway_Merge_Left signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Is_Highway_Merge_Left( CORELANEAPPLvHLAPIsHighwayMergeLeft * pLAP_Is_Highway_Merge_Left )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELANEAPPLvHLAPIsHighwayMergeLeft signal_value;
   
   if( pLAP_Is_Highway_Merge_Left != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvH_Params_s.LAP_Is_Highway_Merge_Left_b1;
      * pLAP_Is_Highway_Merge_Left = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Is_Highway_Merge_Right
*
* FUNCTION ARGUMENTS:
*    CORELANEAPPLvHLAPIsHighwayMergeRight * pLAP_Is_Highway_Merge_Right - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Is_Highway_Merge_Right
*    LAP_Is_Highway_Merge_Right returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Is_Highway_Merge_Right signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Is_Highway_Merge_Right( CORELANEAPPLvHLAPIsHighwayMergeRight * pLAP_Is_Highway_Merge_Right )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELANEAPPLvHLAPIsHighwayMergeRight signal_value;
   
   if( pLAP_Is_Highway_Merge_Right != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvH_Params_s.LAP_Is_Highway_Merge_Right_b1;
      * pLAP_Is_Highway_Merge_Right = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Is_Highway_Exit_Left
*
* FUNCTION ARGUMENTS:
*    CORELANEAPPLvHLAPIsHighwayExitLeft * pLAP_Is_Highway_Exit_Left - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Is_Highway_Exit_Left
*    LAP_Is_Highway_Exit_Left returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Is_Highway_Exit_Left signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Is_Highway_Exit_Left( CORELANEAPPLvHLAPIsHighwayExitLeft * pLAP_Is_Highway_Exit_Left )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELANEAPPLvHLAPIsHighwayExitLeft signal_value;
   
   if( pLAP_Is_Highway_Exit_Left != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvH_Params_s.LAP_Is_Highway_Exit_Left_b1;
      * pLAP_Is_Highway_Exit_Left = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Is_Highway_Exit_Right
*
* FUNCTION ARGUMENTS:
*    CORELANEAPPLvHLAPIsHighwayExitRight * pLAP_Is_Highway_Exit_Right - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Is_Highway_Exit_Right
*    LAP_Is_Highway_Exit_Right returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Is_Highway_Exit_Right signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Is_Highway_Exit_Right( CORELANEAPPLvHLAPIsHighwayExitRight * pLAP_Is_Highway_Exit_Right )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELANEAPPLvHLAPIsHighwayExitRight signal_value;
   
   if( pLAP_Is_Highway_Exit_Right != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvH_Params_s.LAP_Is_Highway_Exit_Right_b1;
      * pLAP_Is_Highway_Exit_Right = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Vertical_Surface_Available
*
* FUNCTION ARGUMENTS:
*    CORELANEAPPLvHLAPVerticalSurfaceAvailable * pLAP_Vertical_Surface_Available - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Vertical_Surface_Available
*    LAP_Vertical_Surface_Available returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Vertical_Surface_Available signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Vertical_Surface_Available( CORELANEAPPLvHLAPVerticalSurfaceAvailable * pLAP_Vertical_Surface_Available )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELANEAPPLvHLAPVerticalSurfaceAvailable signal_value;
   
   if( pLAP_Vertical_Surface_Available != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvH_Params_s.LAP_Vertical_Surface_Available_b1;
      * pLAP_Vertical_Surface_Available = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Vertical_Surface_VR_End
*
* FUNCTION ARGUMENTS:
*    uint16 * pLAP_Vertical_Surface_VR_End - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Vertical_Surface_VR_End
*    LAP_Vertical_Surface_VR_End returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Vertical_Surface_VR_End signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Vertical_Surface_VR_End( uint16 * pLAP_Vertical_Surface_VR_End )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pLAP_Vertical_Surface_VR_End != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvH_Params_s.LAP_Vertical_Surface_VR_End_b15;
      * pLAP_Vertical_Surface_VR_End = signal_value;
      if( signal_value <= C_EYEQMSG_CORELANEAPPLvH_LAP_VERTICAL_SURFACE_VR_END_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_Reserved_1
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1
*    Reserved_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1 signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_Reserved_1( uint8 * pReserved_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pReserved_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvH_Params_s.Reserved_1_b6;
      * pReserved_1 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELANEAPPLvH_RESERVED_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Vertical_Surface_C0
*
* FUNCTION ARGUMENTS:
*    float32 * pLAP_Vertical_Surface_C0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Vertical_Surface_C0
*    LAP_Vertical_Surface_C0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Vertical_Surface_C0 signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Vertical_Surface_C0( float32 * pLAP_Vertical_Surface_C0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float32SigDataType signal_value;
   
   if( pLAP_Vertical_Surface_C0 != C_NULL_P )
   {
      signal_value.u = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvH_Params_s.LAP_Vertical_Surface_C0_sb32;
      * pLAP_Vertical_Surface_C0 = signal_value.f;
      if( (signal_value.f >= C_EYEQMSG_CORELANEAPPLvH_LAP_VERTICAL_SURFACE_C0_RMIN ) 
          && (signal_value.f <= C_EYEQMSG_CORELANEAPPLvH_LAP_VERTICAL_SURFACE_C0_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Vertical_Surface_C1
*
* FUNCTION ARGUMENTS:
*    float32 * pLAP_Vertical_Surface_C1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Vertical_Surface_C1
*    LAP_Vertical_Surface_C1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Vertical_Surface_C1 signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Vertical_Surface_C1( float32 * pLAP_Vertical_Surface_C1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float32SigDataType signal_value;
   
   if( pLAP_Vertical_Surface_C1 != C_NULL_P )
   {
      signal_value.u = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvH_Params_s.LAP_Vertical_Surface_C1_sb32;
      * pLAP_Vertical_Surface_C1 = signal_value.f;
      if( (signal_value.f >= C_EYEQMSG_CORELANEAPPLvH_LAP_VERTICAL_SURFACE_C1_RMIN ) 
          && (signal_value.f <= C_EYEQMSG_CORELANEAPPLvH_LAP_VERTICAL_SURFACE_C1_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Vertical_Surface_C2
*
* FUNCTION ARGUMENTS:
*    float32 * pLAP_Vertical_Surface_C2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Vertical_Surface_C2
*    LAP_Vertical_Surface_C2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Vertical_Surface_C2 signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Vertical_Surface_C2( float32 * pLAP_Vertical_Surface_C2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float32SigDataType signal_value;
   
   if( pLAP_Vertical_Surface_C2 != C_NULL_P )
   {
      signal_value.u = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvH_Params_s.LAP_Vertical_Surface_C2_sb32;
      * pLAP_Vertical_Surface_C2 = signal_value.f;
      if( (signal_value.f >= C_EYEQMSG_CORELANEAPPLvH_LAP_VERTICAL_SURFACE_C2_RMIN ) 
          && (signal_value.f <= C_EYEQMSG_CORELANEAPPLvH_LAP_VERTICAL_SURFACE_C2_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Vertical_Surface_C3
*
* FUNCTION ARGUMENTS:
*    float32 * pLAP_Vertical_Surface_C3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Vertical_Surface_C3
*    LAP_Vertical_Surface_C3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Vertical_Surface_C3 signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Vertical_Surface_C3( float32 * pLAP_Vertical_Surface_C3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float32SigDataType signal_value;
   
   if( pLAP_Vertical_Surface_C3 != C_NULL_P )
   {
      signal_value.u = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvH_Params_s.LAP_Vertical_Surface_C3_sb32;
      * pLAP_Vertical_Surface_C3 = signal_value.f;
      if( (signal_value.f >= C_EYEQMSG_CORELANEAPPLvH_LAP_VERTICAL_SURFACE_C3_RMIN ) 
          && (signal_value.f <= C_EYEQMSG_CORELANEAPPLvH_LAP_VERTICAL_SURFACE_C3_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_CRC
*
* FUNCTION ARGUMENTS:
*    uint32 * pLAP_Path_Pred_CRC - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Path_Pred_CRC
*    LAP_Path_Pred_CRC returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Path_Pred_CRC signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_CRC( uint32 * pLAP_Path_Pred_CRC )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pLAP_Path_Pred_CRC != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvH_Params_s.LAP_Path_Pred_CRC_b32;
      * pLAP_Path_Pred_CRC = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_Available
*
* FUNCTION ARGUMENTS:
*    CORELANEAPPLvHLAPPathPredAvailable * pLAP_Path_Pred_Available - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Path_Pred_Available
*    LAP_Path_Pred_Available returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Path_Pred_Available signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_Available( CORELANEAPPLvHLAPPathPredAvailable * pLAP_Path_Pred_Available )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELANEAPPLvHLAPPathPredAvailable signal_value;
   
   if( pLAP_Path_Pred_Available != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvH_Params_s.LAP_Path_Pred_Available_b1;
      * pLAP_Path_Pred_Available = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_First_Valid
*
* FUNCTION ARGUMENTS:
*    CORELANEAPPLvHLAPPathPredFirstValid * pLAP_Path_Pred_First_Valid - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Path_Pred_First_Valid
*    LAP_Path_Pred_First_Valid returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Path_Pred_First_Valid signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_First_Valid( CORELANEAPPLvHLAPPathPredFirstValid * pLAP_Path_Pred_First_Valid )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELANEAPPLvHLAPPathPredFirstValid signal_value;
   
   if( pLAP_Path_Pred_First_Valid != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvH_Params_s.LAP_Path_Pred_First_Valid_b1;
      * pLAP_Path_Pred_First_Valid = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_Second_Valid
*
* FUNCTION ARGUMENTS:
*    CORELANEAPPLvHLAPPathPredSecondValid * pLAP_Path_Pred_Second_Valid - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Path_Pred_Second_Valid
*    LAP_Path_Pred_Second_Valid returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Path_Pred_Second_Valid signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_Second_Valid( CORELANEAPPLvHLAPPathPredSecondValid * pLAP_Path_Pred_Second_Valid )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELANEAPPLvHLAPPathPredSecondValid signal_value;
   
   if( pLAP_Path_Pred_Second_Valid != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvH_Params_s.LAP_Path_Pred_Second_Valid_b1;
      * pLAP_Path_Pred_Second_Valid = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_Half_Width
*
* FUNCTION ARGUMENTS:
*    uint16 * pLAP_Path_Pred_Half_Width - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Path_Pred_Half_Width
*    LAP_Path_Pred_Half_Width returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Path_Pred_Half_Width signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_Half_Width( uint16 * pLAP_Path_Pred_Half_Width )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pLAP_Path_Pred_Half_Width != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvH_Params_s.LAP_Path_Pred_Half_Width_b9;
      * pLAP_Path_Pred_Half_Width = signal_value;
      if( signal_value <= C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_HALF_WIDTH_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_Conf
*
* FUNCTION ARGUMENTS:
*    uint8 * pLAP_Path_Pred_Conf - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Path_Pred_Conf
*    LAP_Path_Pred_Conf returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Path_Pred_Conf signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_Conf( uint8 * pLAP_Path_Pred_Conf )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pLAP_Path_Pred_Conf != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvH_Params_s.LAP_Path_Pred_Conf_b7;
      * pLAP_Path_Pred_Conf = signal_value;
      if( signal_value <= C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_CONF_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Is_Triggered_SDM_Model
*
* FUNCTION ARGUMENTS:
*    CORELANEAPPLvHLAPIsTriggeredSDMModel * pLAP_Is_Triggered_SDM_Model - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Is_Triggered_SDM_Model
*    LAP_Is_Triggered_SDM_Model returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Is_Triggered_SDM_Model signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Is_Triggered_SDM_Model( CORELANEAPPLvHLAPIsTriggeredSDMModel * pLAP_Is_Triggered_SDM_Model )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELANEAPPLvHLAPIsTriggeredSDMModel signal_value;
   
   if( pLAP_Is_Triggered_SDM_Model != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvH_Params_s.LAP_Is_Triggered_SDM_Model_b2;
      * pLAP_Is_Triggered_SDM_Model = signal_value;
      if( signal_value <= C_EYEQMSG_CORELANEAPPLvH_LAP_IS_TRIGGERED_SDM_MODEL_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_Reserved_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pReserved_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_2
*    Reserved_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_2 signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_Reserved_2( uint16 * pReserved_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pReserved_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvH_Params_s.Reserved_2_b11;
      * pReserved_2 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELANEAPPLvH_RESERVED_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_First_VR_End
*
* FUNCTION ARGUMENTS:
*    uint16 * pLAP_Path_Pred_First_VR_End - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Path_Pred_First_VR_End
*    LAP_Path_Pred_First_VR_End returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Path_Pred_First_VR_End signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_First_VR_End( uint16 * pLAP_Path_Pred_First_VR_End )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pLAP_Path_Pred_First_VR_End != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvH_Params_s.LAP_Path_Pred_First_VR_End_b15;
      * pLAP_Path_Pred_First_VR_End = signal_value;
      if( signal_value <= C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_FIRST_VR_END_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_second_VR_End
*
* FUNCTION ARGUMENTS:
*    uint16 * pLAP_Path_Pred_second_VR_End - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Path_Pred_second_VR_End
*    LAP_Path_Pred_second_VR_End returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Path_Pred_second_VR_End signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_second_VR_End( uint16 * pLAP_Path_Pred_second_VR_End )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pLAP_Path_Pred_second_VR_End != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvH_Params_s.LAP_Path_Pred_second_VR_End_b15;
      * pLAP_Path_Pred_second_VR_End = signal_value;
      if( signal_value <= C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_SECOND_VR_END_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_Reserved_3
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_3
*    Reserved_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_3 signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_Reserved_3( uint8 * pReserved_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pReserved_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvH_Params_s.Reserved_3_b2;
      * pReserved_3 = signal_value;
      if( signal_value <= C_EYEQMSG_CORELANEAPPLvH_RESERVED_3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_First_C0
*
* FUNCTION ARGUMENTS:
*    float32 * pLAP_Path_Pred_First_C0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Path_Pred_First_C0
*    LAP_Path_Pred_First_C0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Path_Pred_First_C0 signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_First_C0( float32 * pLAP_Path_Pred_First_C0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float32SigDataType signal_value;
   
   if( pLAP_Path_Pred_First_C0 != C_NULL_P )
   {
      signal_value.u = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvH_Params_s.LAP_Path_Pred_First_C0_sb32;
      * pLAP_Path_Pred_First_C0 = signal_value.f;
      if( (signal_value.f >= C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_FIRST_C0_RMIN ) 
          && (signal_value.f <= C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_FIRST_C0_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_First_C1
*
* FUNCTION ARGUMENTS:
*    float32 * pLAP_Path_Pred_First_C1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Path_Pred_First_C1
*    LAP_Path_Pred_First_C1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Path_Pred_First_C1 signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_First_C1( float32 * pLAP_Path_Pred_First_C1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float32SigDataType signal_value;
   
   if( pLAP_Path_Pred_First_C1 != C_NULL_P )
   {
      signal_value.u = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvH_Params_s.LAP_Path_Pred_First_C1_sb32;
      * pLAP_Path_Pred_First_C1 = signal_value.f;
      if( (signal_value.f >= C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_FIRST_C1_RMIN ) 
          && (signal_value.f <= C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_FIRST_C1_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_First_C2
*
* FUNCTION ARGUMENTS:
*    float32 * pLAP_Path_Pred_First_C2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Path_Pred_First_C2
*    LAP_Path_Pred_First_C2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Path_Pred_First_C2 signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_First_C2( float32 * pLAP_Path_Pred_First_C2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float32SigDataType signal_value;
   
   if( pLAP_Path_Pred_First_C2 != C_NULL_P )
   {
      signal_value.u = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvH_Params_s.LAP_Path_Pred_First_C2_sb32;
      * pLAP_Path_Pred_First_C2 = signal_value.f;
      if( (signal_value.f >= C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_FIRST_C2_RMIN ) 
          && (signal_value.f <= C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_FIRST_C2_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_First_C3
*
* FUNCTION ARGUMENTS:
*    float32 * pLAP_Path_Pred_First_C3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Path_Pred_First_C3
*    LAP_Path_Pred_First_C3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Path_Pred_First_C3 signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_First_C3( float32 * pLAP_Path_Pred_First_C3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float32SigDataType signal_value;
   
   if( pLAP_Path_Pred_First_C3 != C_NULL_P )
   {
      signal_value.u = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvH_Params_s.LAP_Path_Pred_First_C3_sb32;
      * pLAP_Path_Pred_First_C3 = signal_value.f;
      if( (signal_value.f >= C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_FIRST_C3_RMIN ) 
          && (signal_value.f <= C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_FIRST_C3_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_Second_C0
*
* FUNCTION ARGUMENTS:
*    float32 * pLAP_Path_Pred_Second_C0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Path_Pred_Second_C0
*    LAP_Path_Pred_Second_C0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Path_Pred_Second_C0 signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_Second_C0( float32 * pLAP_Path_Pred_Second_C0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float32SigDataType signal_value;
   
   if( pLAP_Path_Pred_Second_C0 != C_NULL_P )
   {
      signal_value.u = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvH_Params_s.LAP_Path_Pred_Second_C0_sb32;
      * pLAP_Path_Pred_Second_C0 = signal_value.f;
      if( (signal_value.f >= C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_SECOND_C0_RMIN ) 
          && (signal_value.f <= C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_SECOND_C0_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_Second_C1
*
* FUNCTION ARGUMENTS:
*    float32 * pLAP_Path_Pred_Second_C1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Path_Pred_Second_C1
*    LAP_Path_Pred_Second_C1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Path_Pred_Second_C1 signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_Second_C1( float32 * pLAP_Path_Pred_Second_C1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float32SigDataType signal_value;
   
   if( pLAP_Path_Pred_Second_C1 != C_NULL_P )
   {
      signal_value.u = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvH_Params_s.LAP_Path_Pred_Second_C1_sb32;
      * pLAP_Path_Pred_Second_C1 = signal_value.f;
      if( (signal_value.f >= C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_SECOND_C1_RMIN ) 
          && (signal_value.f <= C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_SECOND_C1_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_Second_C2
*
* FUNCTION ARGUMENTS:
*    float32 * pLAP_Path_Pred_Second_C2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Path_Pred_Second_C2
*    LAP_Path_Pred_Second_C2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Path_Pred_Second_C2 signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_Second_C2( float32 * pLAP_Path_Pred_Second_C2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float32SigDataType signal_value;
   
   if( pLAP_Path_Pred_Second_C2 != C_NULL_P )
   {
      signal_value.u = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvH_Params_s.LAP_Path_Pred_Second_C2_sb32;
      * pLAP_Path_Pred_Second_C2 = signal_value.f;
      if( (signal_value.f >= C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_SECOND_C2_RMIN ) 
          && (signal_value.f <= C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_SECOND_C2_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_Second_C3
*
* FUNCTION ARGUMENTS:
*    float32 * pLAP_Path_Pred_Second_C3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Path_Pred_Second_C3
*    LAP_Path_Pred_Second_C3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Path_Pred_Second_C3 signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_Second_C3( float32 * pLAP_Path_Pred_Second_C3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float32SigDataType signal_value;
   
   if( pLAP_Path_Pred_Second_C3 != C_NULL_P )
   {
      signal_value.u = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvH_Params_s.LAP_Path_Pred_Second_C3_sb32;
      * pLAP_Path_Pred_Second_C3 = signal_value.f;
      if( (signal_value.f >= C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_SECOND_C3_RMIN ) 
          && (signal_value.f <= C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_SECOND_C3_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvO_LAP_INTP_ID_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLAP_INTP_ID_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_INTP_ID_0
*    LAP_INTP_ID_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_INTP_ID_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvO_LAP_INTP_ID_0( uint8 objIndx_u8, uint8 * pLAP_INTP_ID_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Applications_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEAPPLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLAP_INTP_ID_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvO_Params_as[objIndx_u8].LAP_INTP_ID_0_b8;
         * pLAP_INTP_ID_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvO_LAP_INTP_Distance_Age_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLAP_INTP_Distance_Age_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_INTP_Distance_Age_0
*    LAP_INTP_Distance_Age_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_INTP_Distance_Age_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvO_LAP_INTP_Distance_Age_0( uint8 objIndx_u8, uint16 * pLAP_INTP_Distance_Age_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Applications_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEAPPLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLAP_INTP_Distance_Age_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvO_Params_as[objIndx_u8].LAP_INTP_Distance_Age_0_b12;
         * pLAP_INTP_Distance_Age_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_DISTANCE_AGE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvO_LAP_INTP_Confidence_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLAP_INTP_Confidence_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_INTP_Confidence_0
*    LAP_INTP_Confidence_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_INTP_Confidence_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvO_LAP_INTP_Confidence_0( uint8 objIndx_u8, uint8 * pLAP_INTP_Confidence_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Applications_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEAPPLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLAP_INTP_Confidence_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvO_Params_as[objIndx_u8].LAP_INTP_Confidence_0_b7;
         * pLAP_INTP_Confidence_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_CONFIDENCE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvO_LAP_INTP_Is_Valid_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANEAPPLvOLAPINTPIsValid0 * pLAP_INTP_Is_Valid_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_INTP_Is_Valid_0
*    LAP_INTP_Is_Valid_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_INTP_Is_Valid_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvO_LAP_INTP_Is_Valid_0( uint8 objIndx_u8, CORELANEAPPLvOLAPINTPIsValid0 * pLAP_INTP_Is_Valid_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELANEAPPLvOLAPINTPIsValid0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Applications_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEAPPLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLAP_INTP_Is_Valid_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvO_Params_as[objIndx_u8].LAP_INTP_Is_Valid_0_b1;
         * pLAP_INTP_Is_Valid_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvO_LAP_INTP_Type_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANEAPPLvOLAPINTPType0 * pLAP_INTP_Type_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_INTP_Type_0
*    LAP_INTP_Type_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_INTP_Type_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvO_LAP_INTP_Type_0( uint8 objIndx_u8, CORELANEAPPLvOLAPINTPType0 * pLAP_INTP_Type_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELANEAPPLvOLAPINTPType0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Applications_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEAPPLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLAP_INTP_Type_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvO_Params_as[objIndx_u8].LAP_INTP_Type_0_b1;
         * pLAP_INTP_Type_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvO_LAP_INTP_Is_Start_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANEAPPLvOLAPINTPIsStart0 * pLAP_INTP_Is_Start_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_INTP_Is_Start_0
*    LAP_INTP_Is_Start_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_INTP_Is_Start_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvO_LAP_INTP_Is_Start_0( uint8 objIndx_u8, CORELANEAPPLvOLAPINTPIsStart0 * pLAP_INTP_Is_Start_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELANEAPPLvOLAPINTPIsStart0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Applications_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEAPPLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLAP_INTP_Is_Start_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvO_Params_as[objIndx_u8].LAP_INTP_Is_Start_0_b1;
         * pLAP_INTP_Is_Start_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvO_Reserved_4_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_4_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_4_0
*    Reserved_4_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_4_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvO_Reserved_4_0( uint8 objIndx_u8, uint8 * pReserved_4_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Applications_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEAPPLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_4_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvO_Params_as[objIndx_u8].Reserved_4_0_b2;
         * pReserved_4_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEAPPLvO_RESERVED_4_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvO_LAP_INTP_Lat_Distance_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLAP_INTP_Lat_Distance_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_INTP_Lat_Distance_0
*    LAP_INTP_Lat_Distance_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_INTP_Lat_Distance_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvO_LAP_INTP_Lat_Distance_0( uint8 objIndx_u8, uint16 * pLAP_INTP_Lat_Distance_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Applications_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEAPPLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLAP_INTP_Lat_Distance_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvO_Params_as[objIndx_u8].LAP_INTP_Lat_Distance_0_b14;
         * pLAP_INTP_Lat_Distance_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_LAT_DISTANCE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvO_LAP_INTP_Long_Distance_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLAP_INTP_Long_Distance_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_INTP_Long_Distance_0
*    LAP_INTP_Long_Distance_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_INTP_Long_Distance_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvO_LAP_INTP_Long_Distance_0( uint8 objIndx_u8, uint16 * pLAP_INTP_Long_Distance_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Applications_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEAPPLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLAP_INTP_Long_Distance_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvO_Params_as[objIndx_u8].LAP_INTP_Long_Distance_0_b15;
         * pLAP_INTP_Long_Distance_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_LONG_DISTANCE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvO_Reserved_5_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_5_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_5_0
*    Reserved_5_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_5_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvO_Reserved_5_0( uint8 objIndx_u8, uint8 * pReserved_5_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Applications_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEAPPLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_5_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvO_Params_as[objIndx_u8].Reserved_5_0_b3;
         * pReserved_5_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEAPPLvO_RESERVED_5_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvO_LAP_INTP_SRD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANEAPPLvOLAPINTPSRD0 * pLAP_INTP_SRD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_INTP_SRD_0
*    LAP_INTP_SRD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_INTP_SRD_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvO_LAP_INTP_SRD_0( uint8 objIndx_u8, CORELANEAPPLvOLAPINTPSRD0 * pLAP_INTP_SRD_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELANEAPPLvOLAPINTPSRD0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Applications_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEAPPLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLAP_INTP_SRD_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvO_Params_as[objIndx_u8].LAP_INTP_SRD_0_b4;
         * pLAP_INTP_SRD_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_SRD_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvO_LAP_INTP_Role_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANEAPPLvOLAPINTPRole0 * pLAP_INTP_Role_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_INTP_Role_0
*    LAP_INTP_Role_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_INTP_Role_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvO_LAP_INTP_Role_0( uint8 objIndx_u8, CORELANEAPPLvOLAPINTPRole0 * pLAP_INTP_Role_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELANEAPPLvOLAPINTPRole0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Applications_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEAPPLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLAP_INTP_Role_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvO_Params_as[objIndx_u8].LAP_INTP_Role_0_b4;
         * pLAP_INTP_Role_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_ROLE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvO_Reserved_6_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint32 * pReserved_6_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_6_0
*    Reserved_6_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_6_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvO_Reserved_6_0( uint8 objIndx_u8, uint32 * pReserved_6_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Lanes_Applications_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELANEAPPLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_6_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELANEAPPL_ParamsApp_s.EYEQMSG_CORELANEAPPLvO_Params_as[objIndx_u8].Reserved_6_0_b24;
         * pReserved_6_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELANEAPPLvO_RESERVED_6_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_CORELANEAPPL_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_CORELANEAPPL_Params_t * pCore_Lanes_Applications_protocol - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_Lanes_Applications_protocol message 
*    Core_Lanes_Applications_protocol message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_Lanes_Applications_protocol message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_CORELANEAPPL_ParamsApp_MsgDataStruct( EYEQMSG_CORELANEAPPL_Params_t * pCore_Lanes_Applications_protocol )
{
   Std_ReturnType status = C_SIG_INVALID;
   if( pCore_Lanes_Applications_protocol != C_NULL_P )
   {
      status = C_SIG_VALID;
      * pCore_Lanes_Applications_protocol = EYEQMSG_CORELANEAPPL_ParamsApp_s;
   }
   return ( status );
}

