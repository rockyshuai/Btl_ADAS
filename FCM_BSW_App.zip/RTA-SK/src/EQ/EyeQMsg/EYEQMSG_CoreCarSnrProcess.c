

/*****************************************************************************
                  Include files
*****************************************************************************/
/* The suggested include file order is: */
#include "EyeQ_defs.h"    /* EyeQ project common definitions file    */

#include "EYEQMSG_CoreCarSnrProcess.h"

/*****************************************************************************
                  Local symbolic constants
*****************************************************************************/
/*****************************************************************************
                  Local types, enums definitions
*****************************************************************************/
/*****************************************************************************
                  Local function prototypes
*****************************************************************************/
/*****************************************************************************
                  Local object definitions
*****************************************************************************/
/*****************************************************************************
                  Exported object definitions
*****************************************************************************/
EYEQMSG_CORECARSNR_Params_t   EYEQMSG_CORECARSNR_Params_s;
EYEQMSG_CORECARSNR_Params_t   EYEQMSG_CORECARSNR_ParamsApp_s;
/*****************************************************************************
                  Local function-like macros
*****************************************************************************/
/*****************************************************************************
                  Local defined macros
*****************************************************************************/
/*****************************************************************************
                  Function definitions
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_CORECARSNR_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_CORECARSNR_Params_t * pCore_Car_sensor - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_Car_sensor message 
*    Core_Car_sensor message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_Car_sensor message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_CORECARSNR_ParamsApp_MsgDataStruct( EYEQMSG_CORECARSNR_Params_t * pCore_Car_sensor )
{
   Std_ReturnType status = C_SIG_INVALID;
   if( pCore_Car_sensor != C_NULL_P )
   {
      status = C_SIG_VALID;
      * pCore_Car_sensor = EYEQMSG_CORECARSNR_ParamsApp_s;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Zero_Byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pCIN_Zero_Byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Zero_Byte
*    CIN_Zero_Byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Zero_Byte signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Zero_Byte( uint8 * pCIN_Zero_Byte )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pCIN_Zero_Byte != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Zero_Byte_b8;
      * pCIN_Zero_Byte = signal_value;
      if( signal_value <= C_EYEQMSG_CORECARSNR_CIN_ZERO_BYTE_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_Reserved_1
*
* FUNCTION ARGUMENTS:
*    uint32 * pReserved_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1
*    Reserved_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1 signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_Reserved_1( uint32 * pReserved_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pReserved_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.Reserved_1_b24;
      * pReserved_1 = signal_value;
      if( signal_value <= C_EYEQMSG_CORECARSNR_RESERVED_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_CRC
*
* FUNCTION ARGUMENTS:
*    uint32 * pCIN_CRC - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_CRC
*    CIN_CRC returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_CRC signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_CRC( uint32 * pCIN_CRC )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pCIN_CRC != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_CRC_b32;
      * pCIN_CRC = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pCIN_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Protocol_Version
*    CIN_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Protocol_Version signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Protocol_Version( uint8 * pCIN_Protocol_Version )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pCIN_Protocol_Version != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Protocol_Version_b8;
      * pCIN_Protocol_Version = signal_value;
      if( (signal_value >= C_EYEQMSG_CORECARSNR_CIN_PROTOCOL_VERSION_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORECARSNR_CIN_PROTOCOL_VERSION_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Vehicle_Code
*
* FUNCTION ARGUMENTS:
*    uint8 * pCIN_Vehicle_Code - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Vehicle_Code
*    CIN_Vehicle_Code returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Vehicle_Code signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Vehicle_Code( uint8 * pCIN_Vehicle_Code )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pCIN_Vehicle_Code != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Vehicle_Code_b8;
      * pCIN_Vehicle_Code = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Sync_Frame_Index
*
* FUNCTION ARGUMENTS:
*    uint8 * pCIN_Sync_Frame_Index - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Sync_Frame_Index
*    CIN_Sync_Frame_Index returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Sync_Frame_Index signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Sync_Frame_Index( uint8 * pCIN_Sync_Frame_Index )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pCIN_Sync_Frame_Index != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Sync_Frame_Index_b8;
      * pCIN_Sync_Frame_Index = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_Reserved_2
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_2
*    Reserved_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_2 signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_Reserved_2( uint8 * pReserved_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pReserved_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.Reserved_2_b8;
      * pReserved_2 = signal_value;
      if( signal_value <= C_EYEQMSG_CORECARSNR_RESERVED_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Vehicle_Speed
*
* FUNCTION ARGUMENTS:
*    uint16 * pCIN_Vehicle_Speed - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Vehicle_Speed
*    CIN_Vehicle_Speed returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Vehicle_Speed signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Vehicle_Speed( uint16 * pCIN_Vehicle_Speed )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pCIN_Vehicle_Speed != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Vehicle_Speed_b15;
      * pCIN_Vehicle_Speed = signal_value;
      if( signal_value <= C_EYEQMSG_CORECARSNR_CIN_VEHICLE_SPEED_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Vehicle_Speed_Valid
*
* FUNCTION ARGUMENTS:
*    CORECARSNRCINVehicleSpeedValid * pCIN_Vehicle_Speed_Valid - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Vehicle_Speed_Valid
*    CIN_Vehicle_Speed_Valid returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Vehicle_Speed_Valid signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Vehicle_Speed_Valid( CORECARSNRCINVehicleSpeedValid * pCIN_Vehicle_Speed_Valid )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRCINVehicleSpeedValid signal_value;
   
   if( pCIN_Vehicle_Speed_Valid != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Vehicle_Speed_Valid_b1;
      * pCIN_Vehicle_Speed_Valid = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Vehicle_Yaw
*
* FUNCTION ARGUMENTS:
*    uint16 * pCIN_Vehicle_Yaw - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Vehicle_Yaw
*    CIN_Vehicle_Yaw returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Vehicle_Yaw signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Vehicle_Yaw( uint16 * pCIN_Vehicle_Yaw )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pCIN_Vehicle_Yaw != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Vehicle_Yaw_b12;
      * pCIN_Vehicle_Yaw = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Vehicle_Yaw_Valid
*
* FUNCTION ARGUMENTS:
*    CORECARSNRCINVehicleYawValid * pCIN_Vehicle_Yaw_Valid - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Vehicle_Yaw_Valid
*    CIN_Vehicle_Yaw_Valid returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Vehicle_Yaw_Valid signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Vehicle_Yaw_Valid( CORECARSNRCINVehicleYawValid * pCIN_Vehicle_Yaw_Valid )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRCINVehicleYawValid signal_value;
   
   if( pCIN_Vehicle_Yaw_Valid != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Vehicle_Yaw_Valid_b1;
      * pCIN_Vehicle_Yaw_Valid = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_Reserved_3
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_3
*    Reserved_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_3 signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_Reserved_3( uint8 * pReserved_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pReserved_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.Reserved_3_b3;
      * pReserved_3 = signal_value;
      if( signal_value <= C_EYEQMSG_CORECARSNR_RESERVED_3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Lat_Accel
*
* FUNCTION ARGUMENTS:
*    uint16 * pCIN_Lat_Accel - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Lat_Accel
*    CIN_Lat_Accel returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Lat_Accel signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Lat_Accel( uint16 * pCIN_Lat_Accel )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pCIN_Lat_Accel != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Lat_Accel_b16;
      * pCIN_Lat_Accel = signal_value;
      if( signal_value <= C_EYEQMSG_CORECARSNR_CIN_LAT_ACCEL_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Lat_Accel_Valid
*
* FUNCTION ARGUMENTS:
*    CORECARSNRCINLatAccelValid * pCIN_Lat_Accel_Valid - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Lat_Accel_Valid
*    CIN_Lat_Accel_Valid returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Lat_Accel_Valid signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Lat_Accel_Valid( CORECARSNRCINLatAccelValid * pCIN_Lat_Accel_Valid )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRCINLatAccelValid signal_value;
   
   if( pCIN_Lat_Accel_Valid != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Lat_Accel_Valid_b1;
      * pCIN_Lat_Accel_Valid = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Wiper_Status_Valid
*
* FUNCTION ARGUMENTS:
*    CORECARSNRCINWiperStatusValid * pCIN_Wiper_Status_Valid - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Wiper_Status_Valid
*    CIN_Wiper_Status_Valid returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Wiper_Status_Valid signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Wiper_Status_Valid( CORECARSNRCINWiperStatusValid * pCIN_Wiper_Status_Valid )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRCINWiperStatusValid signal_value;
   
   if( pCIN_Wiper_Status_Valid != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Wiper_Status_Valid_b1;
      * pCIN_Wiper_Status_Valid = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Wiper_Status
*
* FUNCTION ARGUMENTS:
*    CORECARSNRCINWiperStatus * pCIN_Wiper_Status - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Wiper_Status
*    CIN_Wiper_Status returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Wiper_Status signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Wiper_Status( CORECARSNRCINWiperStatus * pCIN_Wiper_Status )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRCINWiperStatus signal_value;
   
   if( pCIN_Wiper_Status != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Wiper_Status_b3;
      * pCIN_Wiper_Status = signal_value;
      if( signal_value <= C_EYEQMSG_CORECARSNR_CIN_WIPER_STATUS_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Reverse_Indicator
*
* FUNCTION ARGUMENTS:
*    CORECARSNRCINReverseIndicator * pCIN_Reverse_Indicator - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Reverse_Indicator
*    CIN_Reverse_Indicator returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Reverse_Indicator signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Reverse_Indicator( CORECARSNRCINReverseIndicator * pCIN_Reverse_Indicator )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRCINReverseIndicator signal_value;
   
   if( pCIN_Reverse_Indicator != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Reverse_Indicator_b1;
      * pCIN_Reverse_Indicator = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Reverse_Indicator_Valid
*
* FUNCTION ARGUMENTS:
*    CORECARSNRCINReverseIndicatorValid * pCIN_Reverse_Indicator_Valid - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Reverse_Indicator_Valid
*    CIN_Reverse_Indicator_Valid returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Reverse_Indicator_Valid signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Reverse_Indicator_Valid( CORECARSNRCINReverseIndicatorValid * pCIN_Reverse_Indicator_Valid )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRCINReverseIndicatorValid signal_value;
   
   if( pCIN_Reverse_Indicator_Valid != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Reverse_Indicator_Valid_b1;
      * pCIN_Reverse_Indicator_Valid = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_Reserved_4
*
* FUNCTION ARGUMENTS:
*    uint16 * pReserved_4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_4
*    Reserved_4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_4 signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_Reserved_4( uint16 * pReserved_4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pReserved_4 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.Reserved_4_b9;
      * pReserved_4 = signal_value;
      if( signal_value <= C_EYEQMSG_CORECARSNR_RESERVED_4_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Steering_Wheel_Angle
*
* FUNCTION ARGUMENTS:
*    sint16 * pCIN_Steering_Wheel_Angle - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Steering_Wheel_Angle
*    CIN_Steering_Wheel_Angle returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Steering_Wheel_Angle signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Steering_Wheel_Angle( sint16 * pCIN_Steering_Wheel_Angle )
{
   Std_ReturnType status = C_SIG_INVALID;
   sint16 signal_value;
   
   if( pCIN_Steering_Wheel_Angle != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Steering_Wheel_Angle_sb16;
      * pCIN_Steering_Wheel_Angle = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Steering_Wheel_Angle_Valid
*
* FUNCTION ARGUMENTS:
*    CORECARSNRCINSteeringWheelAngleValid * pCIN_Steering_Wheel_Angle_Valid - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Steering_Wheel_Angle_Valid
*    CIN_Steering_Wheel_Angle_Valid returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Steering_Wheel_Angle_Valid signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Steering_Wheel_Angle_Valid( CORECARSNRCINSteeringWheelAngleValid * pCIN_Steering_Wheel_Angle_Valid )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRCINSteeringWheelAngleValid signal_value;
   
   if( pCIN_Steering_Wheel_Angle_Valid != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Steering_Wheel_Angle_Valid_b1;
      * pCIN_Steering_Wheel_Angle_Valid = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Turn_Switch_Status
*
* FUNCTION ARGUMENTS:
*    CORECARSNRCINTurnSwitchStatus * pCIN_Turn_Switch_Status - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Turn_Switch_Status
*    CIN_Turn_Switch_Status returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Turn_Switch_Status signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Turn_Switch_Status( CORECARSNRCINTurnSwitchStatus * pCIN_Turn_Switch_Status )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRCINTurnSwitchStatus signal_value;
   
   if( pCIN_Turn_Switch_Status != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Turn_Switch_Status_b2;
      * pCIN_Turn_Switch_Status = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_High_Beam_Active
*
* FUNCTION ARGUMENTS:
*    CORECARSNRCINHighBeamActive * pCIN_High_Beam_Active - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_High_Beam_Active
*    CIN_High_Beam_Active returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_High_Beam_Active signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_High_Beam_Active( CORECARSNRCINHighBeamActive * pCIN_High_Beam_Active )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRCINHighBeamActive signal_value;
   
   if( pCIN_High_Beam_Active != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_High_Beam_Active_b1;
      * pCIN_High_Beam_Active = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Fog_Light_Active
*
* FUNCTION ARGUMENTS:
*    CORECARSNRCINFogLightActive * pCIN_Fog_Light_Active - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Fog_Light_Active
*    CIN_Fog_Light_Active returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Fog_Light_Active signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Fog_Light_Active( CORECARSNRCINFogLightActive * pCIN_Fog_Light_Active )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRCINFogLightActive signal_value;
   
   if( pCIN_Fog_Light_Active != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Fog_Light_Active_b1;
      * pCIN_Fog_Light_Active = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Accel_Pedal_Value
*
* FUNCTION ARGUMENTS:
*    uint8 * pCIN_Accel_Pedal_Value - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Accel_Pedal_Value
*    CIN_Accel_Pedal_Value returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Accel_Pedal_Value signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Accel_Pedal_Value( uint8 * pCIN_Accel_Pedal_Value )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pCIN_Accel_Pedal_Value != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Accel_Pedal_Value_b8;
      * pCIN_Accel_Pedal_Value = signal_value;
      if( signal_value <= C_EYEQMSG_CORECARSNR_CIN_ACCEL_PEDAL_VALUE_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Accel_Pedal_Valid
*
* FUNCTION ARGUMENTS:
*    CORECARSNRCINAccelPedalValid * pCIN_Accel_Pedal_Valid - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Accel_Pedal_Valid
*    CIN_Accel_Pedal_Valid returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Accel_Pedal_Valid signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Accel_Pedal_Valid( CORECARSNRCINAccelPedalValid * pCIN_Accel_Pedal_Valid )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRCINAccelPedalValid signal_value;
   
   if( pCIN_Accel_Pedal_Valid != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Accel_Pedal_Valid_b1;
      * pCIN_Accel_Pedal_Valid = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_Reserved_5
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_5
*    Reserved_5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_5 signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_Reserved_5( uint8 * pReserved_5 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pReserved_5 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.Reserved_5_b2;
      * pReserved_5 = signal_value;
      if( signal_value <= C_EYEQMSG_CORECARSNR_RESERVED_5_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Accel_Rate
*
* FUNCTION ARGUMENTS:
*    uint16 * pCIN_Accel_Rate - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Accel_Rate
*    CIN_Accel_Rate returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Accel_Rate signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Accel_Rate( uint16 * pCIN_Accel_Rate )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pCIN_Accel_Rate != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Accel_Rate_b15;
      * pCIN_Accel_Rate = signal_value;
      if( signal_value <= C_EYEQMSG_CORECARSNR_CIN_ACCEL_RATE_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Accel_Rate_Valid
*
* FUNCTION ARGUMENTS:
*    CORECARSNRCINAccelRateValid * pCIN_Accel_Rate_Valid - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Accel_Rate_Valid
*    CIN_Accel_Rate_Valid returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Accel_Rate_Valid signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Accel_Rate_Valid( CORECARSNRCINAccelRateValid * pCIN_Accel_Rate_Valid )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRCINAccelRateValid signal_value;
   
   if( pCIN_Accel_Rate_Valid != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Accel_Rate_Valid_b1;
      * pCIN_Accel_Rate_Valid = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Ambient_Light_Level
*
* FUNCTION ARGUMENTS:
*    uint16 * pCIN_Ambient_Light_Level - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Ambient_Light_Level
*    CIN_Ambient_Light_Level returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Ambient_Light_Level signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Ambient_Light_Level( uint16 * pCIN_Ambient_Light_Level )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pCIN_Ambient_Light_Level != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Ambient_Light_Level_b14;
      * pCIN_Ambient_Light_Level = signal_value;
      if( signal_value <= C_EYEQMSG_CORECARSNR_CIN_AMBIENT_LIGHT_LEVEL_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Ambient_Light_Level_Valid
*
* FUNCTION ARGUMENTS:
*    CORECARSNRCINAmbientLightLevelValid * pCIN_Ambient_Light_Level_Valid - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Ambient_Light_Level_Valid
*    CIN_Ambient_Light_Level_Valid returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Ambient_Light_Level_Valid signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Ambient_Light_Level_Valid( CORECARSNRCINAmbientLightLevelValid * pCIN_Ambient_Light_Level_Valid )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRCINAmbientLightLevelValid signal_value;
   
   if( pCIN_Ambient_Light_Level_Valid != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Ambient_Light_Level_Valid_b1;
      * pCIN_Ambient_Light_Level_Valid = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_Reserved_6
*
* FUNCTION ARGUMENTS:
*    boolean * pReserved_6 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_6
*    Reserved_6 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_6 signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_Reserved_6( boolean * pReserved_6 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pReserved_6 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.Reserved_6_b1;
      * pReserved_6 = signal_value;
      if( signal_value <= C_EYEQMSG_CORECARSNR_RESERVED_6_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Brake_Pedal_Position
*
* FUNCTION ARGUMENTS:
*    uint8 * pCIN_Brake_Pedal_Position - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Brake_Pedal_Position
*    CIN_Brake_Pedal_Position returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Brake_Pedal_Position signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Brake_Pedal_Position( uint8 * pCIN_Brake_Pedal_Position )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pCIN_Brake_Pedal_Position != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Brake_Pedal_Position_b8;
      * pCIN_Brake_Pedal_Position = signal_value;
      if( signal_value <= C_EYEQMSG_CORECARSNR_CIN_BRAKE_PEDAL_POSITION_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Brake_Pedal_Pressed
*
* FUNCTION ARGUMENTS:
*    CORECARSNRCINBrakePedalPressed * pCIN_Brake_Pedal_Pressed - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Brake_Pedal_Pressed
*    CIN_Brake_Pedal_Pressed returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Brake_Pedal_Pressed signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Brake_Pedal_Pressed( CORECARSNRCINBrakePedalPressed * pCIN_Brake_Pedal_Pressed )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRCINBrakePedalPressed signal_value;
   
   if( pCIN_Brake_Pedal_Pressed != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Brake_Pedal_Pressed_b1;
      * pCIN_Brake_Pedal_Pressed = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Brake_Pedal_Pressed_Valid
*
* FUNCTION ARGUMENTS:
*    CORECARSNRCINBrakePedalPressedValid * pCIN_Brake_Pedal_Pressed_Valid - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Brake_Pedal_Pressed_Valid
*    CIN_Brake_Pedal_Pressed_Valid returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Brake_Pedal_Pressed_Valid signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Brake_Pedal_Pressed_Valid( CORECARSNRCINBrakePedalPressedValid * pCIN_Brake_Pedal_Pressed_Valid )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRCINBrakePedalPressedValid signal_value;
   
   if( pCIN_Brake_Pedal_Pressed_Valid != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Brake_Pedal_Pressed_Valid_b1;
      * pCIN_Brake_Pedal_Pressed_Valid = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Vehicle_Display_Speed
*
* FUNCTION ARGUMENTS:
*    uint16 * pCIN_Vehicle_Display_Speed - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Vehicle_Display_Speed
*    CIN_Vehicle_Display_Speed returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Vehicle_Display_Speed signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Vehicle_Display_Speed( uint16 * pCIN_Vehicle_Display_Speed )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pCIN_Vehicle_Display_Speed != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Vehicle_Display_Speed_b15;
      * pCIN_Vehicle_Display_Speed = signal_value;
      if( signal_value <= C_EYEQMSG_CORECARSNR_CIN_VEHICLE_DISPLAY_SPEED_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Vehicle_Display_Speed_Valid
*
* FUNCTION ARGUMENTS:
*    CORECARSNRCINVehicleDisplaySpeedValid * pCIN_Vehicle_Display_Speed_Valid - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Vehicle_Display_Speed_Valid
*    CIN_Vehicle_Display_Speed_Valid returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Vehicle_Display_Speed_Valid signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Vehicle_Display_Speed_Valid( CORECARSNRCINVehicleDisplaySpeedValid * pCIN_Vehicle_Display_Speed_Valid )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRCINVehicleDisplaySpeedValid signal_value;
   
   if( pCIN_Vehicle_Display_Speed_Valid != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Vehicle_Display_Speed_Valid_b1;
      * pCIN_Vehicle_Display_Speed_Valid = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_Reserved_7
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_7 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_7
*    Reserved_7 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_7 signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_Reserved_7( uint8 * pReserved_7 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pReserved_7 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.Reserved_7_b6;
      * pReserved_7 = signal_value;
      if( signal_value <= C_EYEQMSG_CORECARSNR_RESERVED_7_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Effective_Steer_Axle_Angle
*
* FUNCTION ARGUMENTS:
*    sint16 * pCIN_Effective_Steer_Axle_Angle - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Effective_Steer_Axle_Angle
*    CIN_Effective_Steer_Axle_Angle returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Effective_Steer_Axle_Angle signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Effective_Steer_Axle_Angle( sint16 * pCIN_Effective_Steer_Axle_Angle )
{
   Std_ReturnType status = C_SIG_INVALID;
   sint16 signal_value;
   
   if( pCIN_Effective_Steer_Axle_Angle != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Effective_Steer_Axle_Angle_sb16;
      * pCIN_Effective_Steer_Axle_Angle = signal_value;
      if( (signal_value >= C_EYEQMSG_CORECARSNR_CIN_EFFECTIVE_STEER_AXLE_ANGLE_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORECARSNR_CIN_EFFECTIVE_STEER_AXLE_ANGLE_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_Reserved_8
*
* FUNCTION ARGUMENTS:
*    uint16 * pReserved_8 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_8
*    Reserved_8 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_8 signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_Reserved_8( uint16 * pReserved_8 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pReserved_8 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.Reserved_8_b16;
      * pReserved_8 = signal_value;
      if( signal_value <= C_EYEQMSG_CORECARSNR_RESERVED_8_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_MCU_Sync_Timestamp
*
* FUNCTION ARGUMENTS:
*    uint64 * pCIN_MCU_Sync_Timestamp - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_MCU_Sync_Timestamp
*    CIN_MCU_Sync_Timestamp returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_MCU_Sync_Timestamp signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_MCU_Sync_Timestamp( uint64 * pCIN_MCU_Sync_Timestamp )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint64 signal_value;
   
   if( pCIN_MCU_Sync_Timestamp != C_NULL_P )
   {
      signal_value = (uint64) (EYEQMSG_CORECARSNR_ParamsApp_s.CIN_MCU_Sync_Timestamp_1_b32|((uint64)EYEQMSG_CORECARSNR_ParamsApp_s.CIN_MCU_Sync_Timestamp_2_b32<<32));
      * pCIN_MCU_Sync_Timestamp = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_MCU_Sync_Timestamp_Valid
*
* FUNCTION ARGUMENTS:
*    CORECARSNRCINMCUSyncTimestampValid * pCIN_MCU_Sync_Timestamp_Valid - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_MCU_Sync_Timestamp_Valid
*    CIN_MCU_Sync_Timestamp_Valid returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_MCU_Sync_Timestamp_Valid signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_MCU_Sync_Timestamp_Valid( CORECARSNRCINMCUSyncTimestampValid * pCIN_MCU_Sync_Timestamp_Valid )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRCINMCUSyncTimestampValid signal_value;
   
   if( pCIN_MCU_Sync_Timestamp_Valid != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_MCU_Sync_Timestamp_Valid_b1;
      * pCIN_MCU_Sync_Timestamp_Valid = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Susp_Height_Delta
*
* FUNCTION ARGUMENTS:
*    sint16 * pCIN_Susp_Height_Delta - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Susp_Height_Delta
*    CIN_Susp_Height_Delta returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Susp_Height_Delta signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Susp_Height_Delta( sint16 * pCIN_Susp_Height_Delta )
{
   Std_ReturnType status = C_SIG_INVALID;
   sint16 signal_value;
   
   if( pCIN_Susp_Height_Delta != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Susp_Height_Delta_sb12;
      * pCIN_Susp_Height_Delta = signal_value;
      if( (signal_value >= C_EYEQMSG_CORECARSNR_CIN_SUSP_HEIGHT_DELTA_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORECARSNR_CIN_SUSP_HEIGHT_DELTA_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Susp_Height_Delta_Valid
*
* FUNCTION ARGUMENTS:
*    CORECARSNRCINSuspHeightDeltaValid * pCIN_Susp_Height_Delta_Valid - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Susp_Height_Delta_Valid
*    CIN_Susp_Height_Delta_Valid returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Susp_Height_Delta_Valid signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Susp_Height_Delta_Valid( CORECARSNRCINSuspHeightDeltaValid * pCIN_Susp_Height_Delta_Valid )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRCINSuspHeightDeltaValid signal_value;
   
   if( pCIN_Susp_Height_Delta_Valid != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Susp_Height_Delta_Valid_b1;
      * pCIN_Susp_Height_Delta_Valid = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Susp_Height_Change_Active
*
* FUNCTION ARGUMENTS:
*    CORECARSNRCINSuspHeightChangeActive * pCIN_Susp_Height_Change_Active - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Susp_Height_Change_Active
*    CIN_Susp_Height_Change_Active returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Susp_Height_Change_Active signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Susp_Height_Change_Active( CORECARSNRCINSuspHeightChangeActive * pCIN_Susp_Height_Change_Active )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRCINSuspHeightChangeActive signal_value;
   
   if( pCIN_Susp_Height_Change_Active != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Susp_Height_Change_Active_b1;
      * pCIN_Susp_Height_Change_Active = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_VSpeed_HiPrecision
*
* FUNCTION ARGUMENTS:
*    uint16 * pCIN_VSpeed_HiPrecision - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_VSpeed_HiPrecision
*    CIN_VSpeed_HiPrecision returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_VSpeed_HiPrecision signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_VSpeed_HiPrecision( uint16 * pCIN_VSpeed_HiPrecision )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pCIN_VSpeed_HiPrecision != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_VSpeed_HiPrecision_b15;
      * pCIN_VSpeed_HiPrecision = signal_value;
      if( signal_value <= C_EYEQMSG_CORECARSNR_CIN_VSPEED_HIPRECISION_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_VSpeed_HiPrecision_Valid
*
* FUNCTION ARGUMENTS:
*    CORECARSNRCINVSpeedHiPrecisionValid * pCIN_VSpeed_HiPrecision_Valid - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_VSpeed_HiPrecision_Valid
*    CIN_VSpeed_HiPrecision_Valid returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_VSpeed_HiPrecision_Valid signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_VSpeed_HiPrecision_Valid( CORECARSNRCINVSpeedHiPrecisionValid * pCIN_VSpeed_HiPrecision_Valid )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRCINVSpeedHiPrecisionValid signal_value;
   
   if( pCIN_VSpeed_HiPrecision_Valid != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_VSpeed_HiPrecision_Valid_b2;
      * pCIN_VSpeed_HiPrecision_Valid = signal_value;
      if( signal_value <= C_EYEQMSG_CORECARSNR_CIN_VSPEED_HIPRECISION_VALID_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_gpsCountryCode_Capital
*
* FUNCTION ARGUMENTS:
*    CORECARSNRCINGpsCountryCodeCapital * pCIN_gpsCountryCode_Capital - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_gpsCountryCode_Capital
*    CIN_gpsCountryCode_Capital returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_gpsCountryCode_Capital signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_gpsCountryCode_Capital( CORECARSNRCINGpsCountryCodeCapital * pCIN_gpsCountryCode_Capital )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRCINGpsCountryCodeCapital signal_value;
   
   if( pCIN_gpsCountryCode_Capital != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_gpsCountryCode_Capital_b2;
      * pCIN_gpsCountryCode_Capital = signal_value;
      if( signal_value <= C_EYEQMSG_CORECARSNR_CIN_GPSCOUNTRYCODE_CAPITAL_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_gpsCountryCode_FirstChar
*
* FUNCTION ARGUMENTS:
*    CORECARSNRCINGpsCountryCodeFirstChar * pCIN_gpsCountryCode_FirstChar - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_gpsCountryCode_FirstChar
*    CIN_gpsCountryCode_FirstChar returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_gpsCountryCode_FirstChar signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_gpsCountryCode_FirstChar( CORECARSNRCINGpsCountryCodeFirstChar * pCIN_gpsCountryCode_FirstChar )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRCINGpsCountryCodeFirstChar signal_value;
   
   if( pCIN_gpsCountryCode_FirstChar != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_gpsCountryCode_FirstChar_b5;
      * pCIN_gpsCountryCode_FirstChar = signal_value;
      if( signal_value <= C_EYEQMSG_CORECARSNR_CIN_GPSCOUNTRYCODE_FIRSTCHAR_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_gpsCountryCode_SecondChar
*
* FUNCTION ARGUMENTS:
*    CORECARSNRCINGpsCountryCodeSecondChar * pCIN_gpsCountryCode_SecondChar - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_gpsCountryCode_SecondChar
*    CIN_gpsCountryCode_SecondChar returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_gpsCountryCode_SecondChar signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_gpsCountryCode_SecondChar( CORECARSNRCINGpsCountryCodeSecondChar * pCIN_gpsCountryCode_SecondChar )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRCINGpsCountryCodeSecondChar signal_value;
   
   if( pCIN_gpsCountryCode_SecondChar != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_gpsCountryCode_SecondChar_b5;
      * pCIN_gpsCountryCode_SecondChar = signal_value;
      if( signal_value <= C_EYEQMSG_CORECARSNR_CIN_GPSCOUNTRYCODE_SECONDCHAR_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_AEB_Brake_Activated
*
* FUNCTION ARGUMENTS:
*    CORECARSNRCINAEBBrakeActivated * pCIN_AEB_Brake_Activated - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_AEB_Brake_Activated
*    CIN_AEB_Brake_Activated returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_AEB_Brake_Activated signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_AEB_Brake_Activated( CORECARSNRCINAEBBrakeActivated * pCIN_AEB_Brake_Activated )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRCINAEBBrakeActivated signal_value;
   
   if( pCIN_AEB_Brake_Activated != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_AEB_Brake_Activated_b1;
      * pCIN_AEB_Brake_Activated = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_AEB_BrakeValid
*
* FUNCTION ARGUMENTS:
*    CORECARSNRCINAEBBrakeValid * pCIN_AEB_BrakeValid - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_AEB_BrakeValid
*    CIN_AEB_BrakeValid returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_AEB_BrakeValid signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_AEB_BrakeValid( CORECARSNRCINAEBBrakeValid * pCIN_AEB_BrakeValid )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRCINAEBBrakeValid signal_value;
   
   if( pCIN_AEB_BrakeValid != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_AEB_BrakeValid_b1;
      * pCIN_AEB_BrakeValid = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_Tire_Preassure_Psi_FL_V
*
* FUNCTION ARGUMENTS:
*    boolean * pGSensor_Tire_Preassure_Psi_FL_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_Tire_Preassure_Psi_FL_V
*    GSensor_Tire_Preassure_Psi_FL_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_Tire_Preassure_Psi_FL_V signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_Tire_Preassure_Psi_FL_V( boolean * pGSensor_Tire_Preassure_Psi_FL_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pGSensor_Tire_Preassure_Psi_FL_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_Tire_Preassure_Psi_FL_V_b1;
      * pGSensor_Tire_Preassure_Psi_FL_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_Tire_Preassure_Psi_FR_V
*
* FUNCTION ARGUMENTS:
*    boolean * pGSensor_Tire_Preassure_Psi_FR_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_Tire_Preassure_Psi_FR_V
*    GSensor_Tire_Preassure_Psi_FR_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_Tire_Preassure_Psi_FR_V signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_Tire_Preassure_Psi_FR_V( boolean * pGSensor_Tire_Preassure_Psi_FR_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pGSensor_Tire_Preassure_Psi_FR_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_Tire_Preassure_Psi_FR_V_b1;
      * pGSensor_Tire_Preassure_Psi_FR_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_Tire_Preassure_Psi_RL_V
*
* FUNCTION ARGUMENTS:
*    boolean * pGSensor_Tire_Preassure_Psi_RL_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_Tire_Preassure_Psi_RL_V
*    GSensor_Tire_Preassure_Psi_RL_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_Tire_Preassure_Psi_RL_V signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_Tire_Preassure_Psi_RL_V( boolean * pGSensor_Tire_Preassure_Psi_RL_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pGSensor_Tire_Preassure_Psi_RL_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_Tire_Preassure_Psi_RL_V_b1;
      * pGSensor_Tire_Preassure_Psi_RL_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_Tire_Preassure_Psi_RR_V
*
* FUNCTION ARGUMENTS:
*    boolean * pGSensor_Tire_Preassure_Psi_RR_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_Tire_Preassure_Psi_RR_V
*    GSensor_Tire_Preassure_Psi_RR_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_Tire_Preassure_Psi_RR_V signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_Tire_Preassure_Psi_RR_V( boolean * pGSensor_Tire_Preassure_Psi_RR_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pGSensor_Tire_Preassure_Psi_RR_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_Tire_Preassure_Psi_RR_V_b1;
      * pGSensor_Tire_Preassure_Psi_RR_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_Tire_Preassure_Psi_FL
*
* FUNCTION ARGUMENTS:
*    uint8 * pGSensor_Tire_Preassure_Psi_FL - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_Tire_Preassure_Psi_FL
*    GSensor_Tire_Preassure_Psi_FL returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_Tire_Preassure_Psi_FL signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_Tire_Preassure_Psi_FL( uint8 * pGSensor_Tire_Preassure_Psi_FL )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pGSensor_Tire_Preassure_Psi_FL != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_Tire_Preassure_Psi_FL_b6;
      * pGSensor_Tire_Preassure_Psi_FL = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_Tire_Preassure_Psi_FR
*
* FUNCTION ARGUMENTS:
*    uint8 * pGSensor_Tire_Preassure_Psi_FR - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_Tire_Preassure_Psi_FR
*    GSensor_Tire_Preassure_Psi_FR returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_Tire_Preassure_Psi_FR signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_Tire_Preassure_Psi_FR( uint8 * pGSensor_Tire_Preassure_Psi_FR )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pGSensor_Tire_Preassure_Psi_FR != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_Tire_Preassure_Psi_FR_b6;
      * pGSensor_Tire_Preassure_Psi_FR = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_Reserved_9
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_9 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_9
*    Reserved_9 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_9 signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_Reserved_9( uint8 * pReserved_9 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pReserved_9 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.Reserved_9_b2;
      * pReserved_9 = signal_value;
      if( signal_value <= C_EYEQMSG_CORECARSNR_RESERVED_9_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_Tire_Preassure_Psi_RL
*
* FUNCTION ARGUMENTS:
*    uint8 * pGSensor_Tire_Preassure_Psi_RL - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_Tire_Preassure_Psi_RL
*    GSensor_Tire_Preassure_Psi_RL returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_Tire_Preassure_Psi_RL signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_Tire_Preassure_Psi_RL( uint8 * pGSensor_Tire_Preassure_Psi_RL )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pGSensor_Tire_Preassure_Psi_RL != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_Tire_Preassure_Psi_RL_b6;
      * pGSensor_Tire_Preassure_Psi_RL = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_Tire_Preassure_Psi_RR
*
* FUNCTION ARGUMENTS:
*    uint8 * pGSensor_Tire_Preassure_Psi_RR - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_Tire_Preassure_Psi_RR
*    GSensor_Tire_Preassure_Psi_RR returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_Tire_Preassure_Psi_RR signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_Tire_Preassure_Psi_RR( uint8 * pGSensor_Tire_Preassure_Psi_RR )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pGSensor_Tire_Preassure_Psi_RR != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_Tire_Preassure_Psi_RR_b6;
      * pGSensor_Tire_Preassure_Psi_RR = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_Acc_Pitch_V
*
* FUNCTION ARGUMENTS:
*    CORECARSNRGSensorAccPitchV * pGSensor_Acc_Pitch_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_Acc_Pitch_V
*    GSensor_Acc_Pitch_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_Acc_Pitch_V signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_Acc_Pitch_V( CORECARSNRGSensorAccPitchV * pGSensor_Acc_Pitch_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRGSensorAccPitchV signal_value;
   
   if( pGSensor_Acc_Pitch_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_Acc_Pitch_V_b1;
      * pGSensor_Acc_Pitch_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_Acc_Pitch
*
* FUNCTION ARGUMENTS:
*    uint16 * pGSensor_Acc_Pitch - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_Acc_Pitch
*    GSensor_Acc_Pitch returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_Acc_Pitch signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_Acc_Pitch( uint16 * pGSensor_Acc_Pitch )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pGSensor_Acc_Pitch != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_Acc_Pitch_b16;
      * pGSensor_Acc_Pitch = signal_value;
      if( signal_value <= C_EYEQMSG_CORECARSNR_GSENSOR_ACC_PITCH_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_Gyro_PitchRate_V
*
* FUNCTION ARGUMENTS:
*    CORECARSNRGSensorGyroPitchRateV * pGSensor_Gyro_PitchRate_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_Gyro_PitchRate_V
*    GSensor_Gyro_PitchRate_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_Gyro_PitchRate_V signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_Gyro_PitchRate_V( CORECARSNRGSensorGyroPitchRateV * pGSensor_Gyro_PitchRate_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRGSensorGyroPitchRateV signal_value;
   
   if( pGSensor_Gyro_PitchRate_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_Gyro_PitchRate_V_b1;
      * pGSensor_Gyro_PitchRate_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_Reserved_10
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_10 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_10
*    Reserved_10 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_10 signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_Reserved_10( uint8 * pReserved_10 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pReserved_10 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.Reserved_10_b2;
      * pReserved_10 = signal_value;
      if( signal_value <= C_EYEQMSG_CORECARSNR_RESERVED_10_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_Gyro_PitchRate
*
* FUNCTION ARGUMENTS:
*    uint16 * pGSensor_Gyro_PitchRate - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_Gyro_PitchRate
*    GSensor_Gyro_PitchRate returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_Gyro_PitchRate signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_Gyro_PitchRate( uint16 * pGSensor_Gyro_PitchRate )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pGSensor_Gyro_PitchRate != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_Gyro_PitchRate_b16;
      * pGSensor_Gyro_PitchRate = signal_value;
      if( signal_value <= C_EYEQMSG_CORECARSNR_GSENSOR_GYRO_PITCHRATE_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_Gyro_RollRate_V
*
* FUNCTION ARGUMENTS:
*    CORECARSNRGSensorGyroRollRateV * pGSensor_Gyro_RollRate_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_Gyro_RollRate_V
*    GSensor_Gyro_RollRate_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_Gyro_RollRate_V signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_Gyro_RollRate_V( CORECARSNRGSensorGyroRollRateV * pGSensor_Gyro_RollRate_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRGSensorGyroRollRateV signal_value;
   
   if( pGSensor_Gyro_RollRate_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_Gyro_RollRate_V_b1;
      * pGSensor_Gyro_RollRate_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_Reserved_11
*
* FUNCTION ARGUMENTS:
*    uint16 * pReserved_11 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_11
*    Reserved_11 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_11 signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_Reserved_11( uint16 * pReserved_11 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pReserved_11 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.Reserved_11_b15;
      * pReserved_11 = signal_value;
      if( signal_value <= C_EYEQMSG_CORECARSNR_RESERVED_11_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_Gyro_RollRate
*
* FUNCTION ARGUMENTS:
*    uint16 * pGSensor_Gyro_RollRate - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_Gyro_RollRate
*    GSensor_Gyro_RollRate returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_Gyro_RollRate signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_Gyro_RollRate( uint16 * pGSensor_Gyro_RollRate )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pGSensor_Gyro_RollRate != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_Gyro_RollRate_b16;
      * pGSensor_Gyro_RollRate = signal_value;
      if( signal_value <= C_EYEQMSG_CORECARSNR_GSENSOR_GYRO_ROLLRATE_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_WheelSpeed_FL_V
*
* FUNCTION ARGUMENTS:
*    CORECARSNRGSensorWheelSpeedFLV * pGSensor_WheelSpeed_FL_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_WheelSpeed_FL_V
*    GSensor_WheelSpeed_FL_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_WheelSpeed_FL_V signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_WheelSpeed_FL_V( CORECARSNRGSensorWheelSpeedFLV * pGSensor_WheelSpeed_FL_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRGSensorWheelSpeedFLV signal_value;
   
   if( pGSensor_WheelSpeed_FL_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_WheelSpeed_FL_V_b1;
      * pGSensor_WheelSpeed_FL_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_WheelSpeed_FR_V
*
* FUNCTION ARGUMENTS:
*    CORECARSNRGSensorWheelSpeedFRV * pGSensor_WheelSpeed_FR_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_WheelSpeed_FR_V
*    GSensor_WheelSpeed_FR_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_WheelSpeed_FR_V signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_WheelSpeed_FR_V( CORECARSNRGSensorWheelSpeedFRV * pGSensor_WheelSpeed_FR_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRGSensorWheelSpeedFRV signal_value;
   
   if( pGSensor_WheelSpeed_FR_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_WheelSpeed_FR_V_b1;
      * pGSensor_WheelSpeed_FR_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_WheelSpeed_RL_V
*
* FUNCTION ARGUMENTS:
*    CORECARSNRGSensorWheelSpeedRLV * pGSensor_WheelSpeed_RL_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_WheelSpeed_RL_V
*    GSensor_WheelSpeed_RL_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_WheelSpeed_RL_V signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_WheelSpeed_RL_V( CORECARSNRGSensorWheelSpeedRLV * pGSensor_WheelSpeed_RL_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRGSensorWheelSpeedRLV signal_value;
   
   if( pGSensor_WheelSpeed_RL_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_WheelSpeed_RL_V_b1;
      * pGSensor_WheelSpeed_RL_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_WheelSpeed_RR_V
*
* FUNCTION ARGUMENTS:
*    CORECARSNRGSensorWheelSpeedRRV * pGSensor_WheelSpeed_RR_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_WheelSpeed_RR_V
*    GSensor_WheelSpeed_RR_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_WheelSpeed_RR_V signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_WheelSpeed_RR_V( CORECARSNRGSensorWheelSpeedRRV * pGSensor_WheelSpeed_RR_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRGSensorWheelSpeedRRV signal_value;
   
   if( pGSensor_WheelSpeed_RR_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_WheelSpeed_RR_V_b1;
      * pGSensor_WheelSpeed_RR_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_Reserved_12
*
* FUNCTION ARGUMENTS:
*    uint16 * pReserved_12 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_12
*    Reserved_12 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_12 signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_Reserved_12( uint16 * pReserved_12 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pReserved_12 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.Reserved_12_b12;
      * pReserved_12 = signal_value;
      if( signal_value <= C_EYEQMSG_CORECARSNR_RESERVED_12_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_WheelSpeed_FL
*
* FUNCTION ARGUMENTS:
*    uint16 * pGSensor_WheelSpeed_FL - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_WheelSpeed_FL
*    GSensor_WheelSpeed_FL returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_WheelSpeed_FL signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_WheelSpeed_FL( uint16 * pGSensor_WheelSpeed_FL )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pGSensor_WheelSpeed_FL != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_WheelSpeed_FL_b16;
      * pGSensor_WheelSpeed_FL = signal_value;
      if( signal_value <= C_EYEQMSG_CORECARSNR_GSENSOR_WHEELSPEED_FL_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_WheelSpeed_FR
*
* FUNCTION ARGUMENTS:
*    uint16 * pGSensor_WheelSpeed_FR - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_WheelSpeed_FR
*    GSensor_WheelSpeed_FR returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_WheelSpeed_FR signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_WheelSpeed_FR( uint16 * pGSensor_WheelSpeed_FR )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pGSensor_WheelSpeed_FR != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_WheelSpeed_FR_b16;
      * pGSensor_WheelSpeed_FR = signal_value;
      if( signal_value <= C_EYEQMSG_CORECARSNR_GSENSOR_WHEELSPEED_FR_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_WheelSpeed_RL
*
* FUNCTION ARGUMENTS:
*    uint16 * pGSensor_WheelSpeed_RL - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_WheelSpeed_RL
*    GSensor_WheelSpeed_RL returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_WheelSpeed_RL signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_WheelSpeed_RL( uint16 * pGSensor_WheelSpeed_RL )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pGSensor_WheelSpeed_RL != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_WheelSpeed_RL_b16;
      * pGSensor_WheelSpeed_RL = signal_value;
      if( signal_value <= C_EYEQMSG_CORECARSNR_GSENSOR_WHEELSPEED_RL_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_WheelSpeed_RR
*
* FUNCTION ARGUMENTS:
*    uint16 * pGSensor_WheelSpeed_RR - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_WheelSpeed_RR
*    GSensor_WheelSpeed_RR returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_WheelSpeed_RR signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_WheelSpeed_RR( uint16 * pGSensor_WheelSpeed_RR )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pGSensor_WheelSpeed_RR != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_WheelSpeed_RR_b16;
      * pGSensor_WheelSpeed_RR = signal_value;
      if( signal_value <= C_EYEQMSG_CORECARSNR_GSENSOR_WHEELSPEED_RR_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_Wheel_Direction_FL_V
*
* FUNCTION ARGUMENTS:
*    CORECARSNRGSensorWheelDirectionFLV * pGSensor_Wheel_Direction_FL_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_Wheel_Direction_FL_V
*    GSensor_Wheel_Direction_FL_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_Wheel_Direction_FL_V signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_Wheel_Direction_FL_V( CORECARSNRGSensorWheelDirectionFLV * pGSensor_Wheel_Direction_FL_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRGSensorWheelDirectionFLV signal_value;
   
   if( pGSensor_Wheel_Direction_FL_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_Wheel_Direction_FL_V_b1;
      * pGSensor_Wheel_Direction_FL_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_Wheel_Direction_FR_V
*
* FUNCTION ARGUMENTS:
*    CORECARSNRGSensorWheelDirectionFRV * pGSensor_Wheel_Direction_FR_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_Wheel_Direction_FR_V
*    GSensor_Wheel_Direction_FR_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_Wheel_Direction_FR_V signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_Wheel_Direction_FR_V( CORECARSNRGSensorWheelDirectionFRV * pGSensor_Wheel_Direction_FR_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRGSensorWheelDirectionFRV signal_value;
   
   if( pGSensor_Wheel_Direction_FR_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_Wheel_Direction_FR_V_b1;
      * pGSensor_Wheel_Direction_FR_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_Wheel_Direction_RL_V
*
* FUNCTION ARGUMENTS:
*    CORECARSNRGSensorWheelDirectionRLV * pGSensor_Wheel_Direction_RL_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_Wheel_Direction_RL_V
*    GSensor_Wheel_Direction_RL_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_Wheel_Direction_RL_V signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_Wheel_Direction_RL_V( CORECARSNRGSensorWheelDirectionRLV * pGSensor_Wheel_Direction_RL_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRGSensorWheelDirectionRLV signal_value;
   
   if( pGSensor_Wheel_Direction_RL_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_Wheel_Direction_RL_V_b1;
      * pGSensor_Wheel_Direction_RL_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_Wheel_Direction_RR_V
*
* FUNCTION ARGUMENTS:
*    CORECARSNRGSensorWheelDirectionRRV * pGSensor_Wheel_Direction_RR_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_Wheel_Direction_RR_V
*    GSensor_Wheel_Direction_RR_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_Wheel_Direction_RR_V signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_Wheel_Direction_RR_V( CORECARSNRGSensorWheelDirectionRRV * pGSensor_Wheel_Direction_RR_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRGSensorWheelDirectionRRV signal_value;
   
   if( pGSensor_Wheel_Direction_RR_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_Wheel_Direction_RR_V_b1;
      * pGSensor_Wheel_Direction_RR_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_Wheel_Direction_FL
*
* FUNCTION ARGUMENTS:
*    CORECARSNRGSensorWheelDirectionFL * pGSensor_Wheel_Direction_FL - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_Wheel_Direction_FL
*    GSensor_Wheel_Direction_FL returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_Wheel_Direction_FL signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_Wheel_Direction_FL( CORECARSNRGSensorWheelDirectionFL * pGSensor_Wheel_Direction_FL )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRGSensorWheelDirectionFL signal_value;
   
   if( pGSensor_Wheel_Direction_FL != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_Wheel_Direction_FL_b2;
      * pGSensor_Wheel_Direction_FL = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_Wheel_Direction_FR
*
* FUNCTION ARGUMENTS:
*    CORECARSNRGSensorWheelDirectionFR * pGSensor_Wheel_Direction_FR - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_Wheel_Direction_FR
*    GSensor_Wheel_Direction_FR returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_Wheel_Direction_FR signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_Wheel_Direction_FR( CORECARSNRGSensorWheelDirectionFR * pGSensor_Wheel_Direction_FR )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRGSensorWheelDirectionFR signal_value;
   
   if( pGSensor_Wheel_Direction_FR != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_Wheel_Direction_FR_b2;
      * pGSensor_Wheel_Direction_FR = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_Wheel_Direction_RL
*
* FUNCTION ARGUMENTS:
*    CORECARSNRGSensorWheelDirectionRL * pGSensor_Wheel_Direction_RL - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_Wheel_Direction_RL
*    GSensor_Wheel_Direction_RL returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_Wheel_Direction_RL signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_Wheel_Direction_RL( CORECARSNRGSensorWheelDirectionRL * pGSensor_Wheel_Direction_RL )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRGSensorWheelDirectionRL signal_value;
   
   if( pGSensor_Wheel_Direction_RL != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_Wheel_Direction_RL_b2;
      * pGSensor_Wheel_Direction_RL = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_Wheel_Direction_RR
*
* FUNCTION ARGUMENTS:
*    CORECARSNRGSensorWheelDirectionRR * pGSensor_Wheel_Direction_RR - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_Wheel_Direction_RR
*    GSensor_Wheel_Direction_RR returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_Wheel_Direction_RR signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_Wheel_Direction_RR( CORECARSNRGSensorWheelDirectionRR * pGSensor_Wheel_Direction_RR )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRGSensorWheelDirectionRR signal_value;
   
   if( pGSensor_Wheel_Direction_RR != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_Wheel_Direction_RR_b2;
      * pGSensor_Wheel_Direction_RR = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_WheelTicks_FL_V_deprecated
*
* FUNCTION ARGUMENTS:
*    CORECARSNRGSensorWheelTicksFLVDeprecated * pGSensor_WheelTicks_FL_V_deprecated - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_WheelTicks_FL_V_deprecated
*    GSensor_WheelTicks_FL_V_deprecated returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_WheelTicks_FL_V_deprecated signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_WheelTicks_FL_V_deprecated( CORECARSNRGSensorWheelTicksFLVDeprecated * pGSensor_WheelTicks_FL_V_deprecated )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRGSensorWheelTicksFLVDeprecated signal_value;
   
   if( pGSensor_WheelTicks_FL_V_deprecated != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_WheelTicks_FL_V_deprecated_b1;
      * pGSensor_WheelTicks_FL_V_deprecated = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_WheelTicks_FR_V_deprecated
*
* FUNCTION ARGUMENTS:
*    CORECARSNRGSensorWheelTicksFRVDeprecated * pGSensor_WheelTicks_FR_V_deprecated - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_WheelTicks_FR_V_deprecated
*    GSensor_WheelTicks_FR_V_deprecated returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_WheelTicks_FR_V_deprecated signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_WheelTicks_FR_V_deprecated( CORECARSNRGSensorWheelTicksFRVDeprecated * pGSensor_WheelTicks_FR_V_deprecated )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRGSensorWheelTicksFRVDeprecated signal_value;
   
   if( pGSensor_WheelTicks_FR_V_deprecated != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_WheelTicks_FR_V_deprecated_b1;
      * pGSensor_WheelTicks_FR_V_deprecated = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_WheelTicks_RL_V_deprecated
*
* FUNCTION ARGUMENTS:
*    CORECARSNRGSensorWheelTicksRLVDeprecated * pGSensor_WheelTicks_RL_V_deprecated - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_WheelTicks_RL_V_deprecated
*    GSensor_WheelTicks_RL_V_deprecated returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_WheelTicks_RL_V_deprecated signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_WheelTicks_RL_V_deprecated( CORECARSNRGSensorWheelTicksRLVDeprecated * pGSensor_WheelTicks_RL_V_deprecated )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRGSensorWheelTicksRLVDeprecated signal_value;
   
   if( pGSensor_WheelTicks_RL_V_deprecated != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_WheelTicks_RL_V_deprecated_b1;
      * pGSensor_WheelTicks_RL_V_deprecated = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_WheelTicks_RR_V_deprecated
*
* FUNCTION ARGUMENTS:
*    CORECARSNRGSensorWheelTicksRRVDeprecated * pGSensor_WheelTicks_RR_V_deprecated - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_WheelTicks_RR_V_deprecated
*    GSensor_WheelTicks_RR_V_deprecated returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_WheelTicks_RR_V_deprecated signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_WheelTicks_RR_V_deprecated( CORECARSNRGSensorWheelTicksRRVDeprecated * pGSensor_WheelTicks_RR_V_deprecated )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRGSensorWheelTicksRRVDeprecated signal_value;
   
   if( pGSensor_WheelTicks_RR_V_deprecated != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_WheelTicks_RR_V_deprecated_b1;
      * pGSensor_WheelTicks_RR_V_deprecated = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_WheelTicks_FL_deprecated
*
* FUNCTION ARGUMENTS:
*    uint8 * pGSensor_WheelTicks_FL_deprecated - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_WheelTicks_FL_deprecated
*    GSensor_WheelTicks_FL_deprecated returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_WheelTicks_FL_deprecated signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_WheelTicks_FL_deprecated( uint8 * pGSensor_WheelTicks_FL_deprecated )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pGSensor_WheelTicks_FL_deprecated != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_WheelTicks_FL_deprecated_b8;
      * pGSensor_WheelTicks_FL_deprecated = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_WheelTicks_FR_deprecated
*
* FUNCTION ARGUMENTS:
*    uint8 * pGSensor_WheelTicks_FR_deprecated - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_WheelTicks_FR_deprecated
*    GSensor_WheelTicks_FR_deprecated returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_WheelTicks_FR_deprecated signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_WheelTicks_FR_deprecated( uint8 * pGSensor_WheelTicks_FR_deprecated )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pGSensor_WheelTicks_FR_deprecated != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_WheelTicks_FR_deprecated_b8;
      * pGSensor_WheelTicks_FR_deprecated = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_WheelTicks_RL_deprecated
*
* FUNCTION ARGUMENTS:
*    uint8 * pGSensor_WheelTicks_RL_deprecated - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_WheelTicks_RL_deprecated
*    GSensor_WheelTicks_RL_deprecated returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_WheelTicks_RL_deprecated signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_WheelTicks_RL_deprecated( uint8 * pGSensor_WheelTicks_RL_deprecated )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pGSensor_WheelTicks_RL_deprecated != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_WheelTicks_RL_deprecated_b8;
      * pGSensor_WheelTicks_RL_deprecated = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_WheelTicks_RR_deprecated
*
* FUNCTION ARGUMENTS:
*    uint8 * pGSensor_WheelTicks_RR_deprecated - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_WheelTicks_RR_deprecated
*    GSensor_WheelTicks_RR_deprecated returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_WheelTicks_RR_deprecated signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_WheelTicks_RR_deprecated( uint8 * pGSensor_WheelTicks_RR_deprecated )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pGSensor_WheelTicks_RR_deprecated != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_WheelTicks_RR_deprecated_b8;
      * pGSensor_WheelTicks_RR_deprecated = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_fcaGapSensitivityValid
*
* FUNCTION ARGUMENTS:
*    CORECARSNRFcaGapSensitivityValid * pfcaGapSensitivityValid - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of fcaGapSensitivityValid
*    fcaGapSensitivityValid returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns fcaGapSensitivityValid signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_fcaGapSensitivityValid( CORECARSNRFcaGapSensitivityValid * pfcaGapSensitivityValid )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRFcaGapSensitivityValid signal_value;
   
   if( pfcaGapSensitivityValid != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.fcaGapSensitivityValid_b1;
      * pfcaGapSensitivityValid = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_fcaGapSensitivity
*
* FUNCTION ARGUMENTS:
*    CORECARSNRFcaGapSensitivity * pfcaGapSensitivity - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of fcaGapSensitivity
*    fcaGapSensitivity returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns fcaGapSensitivity signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_fcaGapSensitivity( CORECARSNRFcaGapSensitivity * pfcaGapSensitivity )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRFcaGapSensitivity signal_value;
   
   if( pfcaGapSensitivity != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.fcaGapSensitivity_b2;
      * pfcaGapSensitivity = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_pcwGapSensitivityValid
*
* FUNCTION ARGUMENTS:
*    CORECARSNRPcwGapSensitivityValid * ppcwGapSensitivityValid - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of pcwGapSensitivityValid
*    pcwGapSensitivityValid returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns pcwGapSensitivityValid signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_pcwGapSensitivityValid( CORECARSNRPcwGapSensitivityValid * ppcwGapSensitivityValid )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRPcwGapSensitivityValid signal_value;
   
   if( ppcwGapSensitivityValid != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.pcwGapSensitivityValid_b1;
      * ppcwGapSensitivityValid = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_pcwGapSensitivity
*
* FUNCTION ARGUMENTS:
*    CORECARSNRPcwGapSensitivity * ppcwGapSensitivity - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of pcwGapSensitivity
*    pcwGapSensitivity returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns pcwGapSensitivity signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_pcwGapSensitivity( CORECARSNRPcwGapSensitivity * ppcwGapSensitivity )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRPcwGapSensitivity signal_value;
   
   if( ppcwGapSensitivity != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.pcwGapSensitivity_b2;
      * ppcwGapSensitivity = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_Driver_Awareness_Valid
*
* FUNCTION ARGUMENTS:
*    CORECARSNRDriverAwarenessValid * pDriver_Awareness_Valid - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Driver_Awareness_Valid
*    Driver_Awareness_Valid returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Driver_Awareness_Valid signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_Driver_Awareness_Valid( CORECARSNRDriverAwarenessValid * pDriver_Awareness_Valid )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRDriverAwarenessValid signal_value;
   
   if( pDriver_Awareness_Valid != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.Driver_Awareness_Valid_b1;
      * pDriver_Awareness_Valid = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_Driver_Awareness
*
* FUNCTION ARGUMENTS:
*    uint8 * pDriver_Awareness - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Driver_Awareness
*    Driver_Awareness returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Driver_Awareness signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_Driver_Awareness( uint8 * pDriver_Awareness )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pDriver_Awareness != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.Driver_Awareness_b7;
      * pDriver_Awareness = signal_value;
      if( signal_value <= C_EYEQMSG_CORECARSNR_DRIVER_AWARENESS_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_External_Temp_Valid
*
* FUNCTION ARGUMENTS:
*    CORECARSNRExternalTempValid * pExternal_Temp_Valid - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of External_Temp_Valid
*    External_Temp_Valid returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns External_Temp_Valid signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_External_Temp_Valid( CORECARSNRExternalTempValid * pExternal_Temp_Valid )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRExternalTempValid signal_value;
   
   if( pExternal_Temp_Valid != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.External_Temp_Valid_b1;
      * pExternal_Temp_Valid = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_Reserved_13
*
* FUNCTION ARGUMENTS:
*    boolean * pReserved_13 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_13
*    Reserved_13 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_13 signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_Reserved_13( boolean * pReserved_13 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pReserved_13 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.Reserved_13_b1;
      * pReserved_13 = signal_value;
      if( signal_value <= C_EYEQMSG_CORECARSNR_RESERVED_13_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_External_Temp
*
* FUNCTION ARGUMENTS:
*    uint16 * pExternal_Temp - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of External_Temp
*    External_Temp returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns External_Temp signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_External_Temp( uint16 * pExternal_Temp )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pExternal_Temp != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.External_Temp_b14;
      * pExternal_Temp = signal_value;
      if( signal_value <= C_EYEQMSG_CORECARSNR_EXTERNAL_TEMP_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_ACTIVE_STATIONARY_TESTING_Valid
*
* FUNCTION ARGUMENTS:
*    CORECARSNRACTIVESTATIONARYTESTINGValid * pACTIVE_STATIONARY_TESTING_Valid - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ACTIVE_STATIONARY_TESTING_Valid
*    ACTIVE_STATIONARY_TESTING_Valid returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ACTIVE_STATIONARY_TESTING_Valid signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_ACTIVE_STATIONARY_TESTING_Valid( CORECARSNRACTIVESTATIONARYTESTINGValid * pACTIVE_STATIONARY_TESTING_Valid )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRACTIVESTATIONARYTESTINGValid signal_value;
   
   if( pACTIVE_STATIONARY_TESTING_Valid != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.ACTIVE_STATIONARY_TESTING_Valid_b1;
      * pACTIVE_STATIONARY_TESTING_Valid = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_ACTIVE_STATIONARY_TESTING
*
* FUNCTION ARGUMENTS:
*    CORECARSNRACTIVESTATIONARYTESTING * pACTIVE_STATIONARY_TESTING - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ACTIVE_STATIONARY_TESTING
*    ACTIVE_STATIONARY_TESTING returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ACTIVE_STATIONARY_TESTING signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_ACTIVE_STATIONARY_TESTING( CORECARSNRACTIVESTATIONARYTESTING * pACTIVE_STATIONARY_TESTING )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRACTIVESTATIONARYTESTING signal_value;
   
   if( pACTIVE_STATIONARY_TESTING != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.ACTIVE_STATIONARY_TESTING_b1;
      * pACTIVE_STATIONARY_TESTING = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_Reduce_Sense_Force_Activation_Valid
*
* FUNCTION ARGUMENTS:
*    CORECARSNRReduceSenseForceActivationValid * pReduce_Sense_Force_Activation_Valid - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reduce_Sense_Force_Activation_Valid
*    Reduce_Sense_Force_Activation_Valid returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reduce_Sense_Force_Activation_Valid signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_Reduce_Sense_Force_Activation_Valid( CORECARSNRReduceSenseForceActivationValid * pReduce_Sense_Force_Activation_Valid )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRReduceSenseForceActivationValid signal_value;
   
   if( pReduce_Sense_Force_Activation_Valid != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.Reduce_Sense_Force_Activation_Valid_b1;
      * pReduce_Sense_Force_Activation_Valid = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_Reduce_Sense_Force_Activation
*
* FUNCTION ARGUMENTS:
*    CORECARSNRReduceSenseForceActivation * pReduce_Sense_Force_Activation - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reduce_Sense_Force_Activation
*    Reduce_Sense_Force_Activation returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reduce_Sense_Force_Activation signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_Reduce_Sense_Force_Activation( CORECARSNRReduceSenseForceActivation * pReduce_Sense_Force_Activation )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRReduceSenseForceActivation signal_value;
   
   if( pReduce_Sense_Force_Activation != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.Reduce_Sense_Force_Activation_b1;
      * pReduce_Sense_Force_Activation = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_StandStill_V
*
* FUNCTION ARGUMENTS:
*    CORECARSNRCINStandStillV * pCIN_StandStill_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_StandStill_V
*    CIN_StandStill_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_StandStill_V signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_StandStill_V( CORECARSNRCINStandStillV * pCIN_StandStill_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRCINStandStillV signal_value;
   
   if( pCIN_StandStill_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_StandStill_V_b1;
      * pCIN_StandStill_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_StandStill
*
* FUNCTION ARGUMENTS:
*    CORECARSNRCINStandStill * pCIN_StandStill - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_StandStill
*    CIN_StandStill returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_StandStill signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_StandStill( CORECARSNRCINStandStill * pCIN_StandStill )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRCINStandStill signal_value;
   
   if( pCIN_StandStill != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_StandStill_b1;
      * pCIN_StandStill = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_FrontWheelsAngle_V
*
* FUNCTION ARGUMENTS:
*    CORECARSNRCINFrontWheelsAngleV * pCIN_FrontWheelsAngle_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_FrontWheelsAngle_V
*    CIN_FrontWheelsAngle_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_FrontWheelsAngle_V signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_FrontWheelsAngle_V( CORECARSNRCINFrontWheelsAngleV * pCIN_FrontWheelsAngle_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRCINFrontWheelsAngleV signal_value;
   
   if( pCIN_FrontWheelsAngle_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_FrontWheelsAngle_V_b1;
      * pCIN_FrontWheelsAngle_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_FrontWheelsAngle
*
* FUNCTION ARGUMENTS:
*    sint16 * pCIN_FrontWheelsAngle - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_FrontWheelsAngle
*    CIN_FrontWheelsAngle returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_FrontWheelsAngle signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_FrontWheelsAngle( sint16 * pCIN_FrontWheelsAngle )
{
   Std_ReturnType status = C_SIG_INVALID;
   sint16 signal_value;
   
   if( pCIN_FrontWheelsAngle != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_FrontWheelsAngle_sb11;
      * pCIN_FrontWheelsAngle = signal_value;
      if( (signal_value >= C_EYEQMSG_CORECARSNR_CIN_FRONTWHEELSANGLE_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORECARSNR_CIN_FRONTWHEELSANGLE_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Susp_Pitch_Delta_V
*
* FUNCTION ARGUMENTS:
*    CORECARSNRCINSuspPitchDeltaV * pCIN_Susp_Pitch_Delta_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Susp_Pitch_Delta_V
*    CIN_Susp_Pitch_Delta_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Susp_Pitch_Delta_V signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Susp_Pitch_Delta_V( CORECARSNRCINSuspPitchDeltaV * pCIN_Susp_Pitch_Delta_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRCINSuspPitchDeltaV signal_value;
   
   if( pCIN_Susp_Pitch_Delta_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Susp_Pitch_Delta_V_b1;
      * pCIN_Susp_Pitch_Delta_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Susp_Pitch_Delta
*
* FUNCTION ARGUMENTS:
*    sint8 * pCIN_Susp_Pitch_Delta - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Susp_Pitch_Delta
*    CIN_Susp_Pitch_Delta returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Susp_Pitch_Delta signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Susp_Pitch_Delta( sint8 * pCIN_Susp_Pitch_Delta )
{
   Std_ReturnType status = C_SIG_INVALID;
   sint8 signal_value;
   
   if( pCIN_Susp_Pitch_Delta != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Susp_Pitch_Delta_sb8;
      * pCIN_Susp_Pitch_Delta = signal_value;
      if( (signal_value >= C_EYEQMSG_CORECARSNR_CIN_SUSP_PITCH_DELTA_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORECARSNR_CIN_SUSP_PITCH_DELTA_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Susp_Roll_Delta_V
*
* FUNCTION ARGUMENTS:
*    CORECARSNRCINSuspRollDeltaV * pCIN_Susp_Roll_Delta_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Susp_Roll_Delta_V
*    CIN_Susp_Roll_Delta_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Susp_Roll_Delta_V signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Susp_Roll_Delta_V( CORECARSNRCINSuspRollDeltaV * pCIN_Susp_Roll_Delta_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRCINSuspRollDeltaV signal_value;
   
   if( pCIN_Susp_Roll_Delta_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Susp_Roll_Delta_V_b1;
      * pCIN_Susp_Roll_Delta_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Susp_Roll_Delta
*
* FUNCTION ARGUMENTS:
*    sint8 * pCIN_Susp_Roll_Delta - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Susp_Roll_Delta
*    CIN_Susp_Roll_Delta returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Susp_Roll_Delta signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Susp_Roll_Delta( sint8 * pCIN_Susp_Roll_Delta )
{
   Std_ReturnType status = C_SIG_INVALID;
   sint8 signal_value;
   
   if( pCIN_Susp_Roll_Delta != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Susp_Roll_Delta_sb8;
      * pCIN_Susp_Roll_Delta = signal_value;
      if( (signal_value >= C_EYEQMSG_CORECARSNR_CIN_SUSP_ROLL_DELTA_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORECARSNR_CIN_SUSP_ROLL_DELTA_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Susp_FR_V
*
* FUNCTION ARGUMENTS:
*    CORECARSNRCINSuspFRV * pCIN_Susp_FR_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Susp_FR_V
*    CIN_Susp_FR_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Susp_FR_V signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Susp_FR_V( CORECARSNRCINSuspFRV * pCIN_Susp_FR_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRCINSuspFRV signal_value;
   
   if( pCIN_Susp_FR_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Susp_FR_V_b1;
      * pCIN_Susp_FR_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Susp_FR
*
* FUNCTION ARGUMENTS:
*    uint16 * pCIN_Susp_FR - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Susp_FR
*    CIN_Susp_FR returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Susp_FR signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Susp_FR( uint16 * pCIN_Susp_FR )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pCIN_Susp_FR != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Susp_FR_b10;
      * pCIN_Susp_FR = signal_value;
      if( signal_value <= C_EYEQMSG_CORECARSNR_CIN_SUSP_FR_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Susp_FL_V
*
* FUNCTION ARGUMENTS:
*    CORECARSNRCINSuspFLV * pCIN_Susp_FL_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Susp_FL_V
*    CIN_Susp_FL_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Susp_FL_V signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Susp_FL_V( CORECARSNRCINSuspFLV * pCIN_Susp_FL_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRCINSuspFLV signal_value;
   
   if( pCIN_Susp_FL_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Susp_FL_V_b1;
      * pCIN_Susp_FL_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_Reserved_14
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_14 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_14
*    Reserved_14 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_14 signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_Reserved_14( uint8 * pReserved_14 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pReserved_14 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.Reserved_14_b2;
      * pReserved_14 = signal_value;
      if( signal_value <= C_EYEQMSG_CORECARSNR_RESERVED_14_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Susp_FL
*
* FUNCTION ARGUMENTS:
*    uint16 * pCIN_Susp_FL - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Susp_FL
*    CIN_Susp_FL returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Susp_FL signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Susp_FL( uint16 * pCIN_Susp_FL )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pCIN_Susp_FL != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Susp_FL_b10;
      * pCIN_Susp_FL = signal_value;
      if( signal_value <= C_EYEQMSG_CORECARSNR_CIN_SUSP_FL_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Susp_RR_V
*
* FUNCTION ARGUMENTS:
*    CORECARSNRCINSuspRRV * pCIN_Susp_RR_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Susp_RR_V
*    CIN_Susp_RR_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Susp_RR_V signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Susp_RR_V( CORECARSNRCINSuspRRV * pCIN_Susp_RR_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRCINSuspRRV signal_value;
   
   if( pCIN_Susp_RR_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Susp_RR_V_b1;
      * pCIN_Susp_RR_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Susp_RR
*
* FUNCTION ARGUMENTS:
*    uint16 * pCIN_Susp_RR - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Susp_RR
*    CIN_Susp_RR returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Susp_RR signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Susp_RR( uint16 * pCIN_Susp_RR )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pCIN_Susp_RR != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Susp_RR_b10;
      * pCIN_Susp_RR = signal_value;
      if( signal_value <= C_EYEQMSG_CORECARSNR_CIN_SUSP_RR_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Susp_RL_V
*
* FUNCTION ARGUMENTS:
*    CORECARSNRCINSuspRLV * pCIN_Susp_RL_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Susp_RL_V
*    CIN_Susp_RL_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Susp_RL_V signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Susp_RL_V( CORECARSNRCINSuspRLV * pCIN_Susp_RL_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRCINSuspRLV signal_value;
   
   if( pCIN_Susp_RL_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Susp_RL_V_b1;
      * pCIN_Susp_RL_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Susp_RL
*
* FUNCTION ARGUMENTS:
*    uint16 * pCIN_Susp_RL - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Susp_RL
*    CIN_Susp_RL returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Susp_RL signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Susp_RL( uint16 * pCIN_Susp_RL )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pCIN_Susp_RL != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Susp_RL_b10;
      * pCIN_Susp_RL = signal_value;
      if( signal_value <= C_EYEQMSG_CORECARSNR_CIN_SUSP_RL_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_WheelTicks_FL
*
* FUNCTION ARGUMENTS:
*    uint16 * pGSensor_WheelTicks_FL - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_WheelTicks_FL
*    GSensor_WheelTicks_FL returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_WheelTicks_FL signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_WheelTicks_FL( uint16 * pGSensor_WheelTicks_FL )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pGSensor_WheelTicks_FL != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_WheelTicks_FL_b10;
      * pGSensor_WheelTicks_FL = signal_value;
      if( signal_value <= C_EYEQMSG_CORECARSNR_GSENSOR_WHEELTICKS_FL_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_WheelTicks_FR
*
* FUNCTION ARGUMENTS:
*    uint16 * pGSensor_WheelTicks_FR - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_WheelTicks_FR
*    GSensor_WheelTicks_FR returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_WheelTicks_FR signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_WheelTicks_FR( uint16 * pGSensor_WheelTicks_FR )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pGSensor_WheelTicks_FR != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_WheelTicks_FR_b10;
      * pGSensor_WheelTicks_FR = signal_value;
      if( signal_value <= C_EYEQMSG_CORECARSNR_GSENSOR_WHEELTICKS_FR_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_WheelTicks_RL
*
* FUNCTION ARGUMENTS:
*    uint16 * pGSensor_WheelTicks_RL - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_WheelTicks_RL
*    GSensor_WheelTicks_RL returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_WheelTicks_RL signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_WheelTicks_RL( uint16 * pGSensor_WheelTicks_RL )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pGSensor_WheelTicks_RL != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_WheelTicks_RL_b10;
      * pGSensor_WheelTicks_RL = signal_value;
      if( signal_value <= C_EYEQMSG_CORECARSNR_GSENSOR_WHEELTICKS_RL_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_Reserved_15
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_15 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_15
*    Reserved_15 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_15 signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_Reserved_15( uint8 * pReserved_15 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pReserved_15 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.Reserved_15_b2;
      * pReserved_15 = signal_value;
      if( signal_value <= C_EYEQMSG_CORECARSNR_RESERVED_15_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_WheelTicks_RR
*
* FUNCTION ARGUMENTS:
*    uint16 * pGSensor_WheelTicks_RR - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_WheelTicks_RR
*    GSensor_WheelTicks_RR returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_WheelTicks_RR signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_WheelTicks_RR( uint16 * pGSensor_WheelTicks_RR )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pGSensor_WheelTicks_RR != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_WheelTicks_RR_b10;
      * pGSensor_WheelTicks_RR = signal_value;
      if( signal_value <= C_EYEQMSG_CORECARSNR_GSENSOR_WHEELTICKS_RR_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_WheelTicks_FL_V
*
* FUNCTION ARGUMENTS:
*    CORECARSNRGSensorWheelTicksFLV * pGSensor_WheelTicks_FL_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_WheelTicks_FL_V
*    GSensor_WheelTicks_FL_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_WheelTicks_FL_V signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_WheelTicks_FL_V( CORECARSNRGSensorWheelTicksFLV * pGSensor_WheelTicks_FL_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRGSensorWheelTicksFLV signal_value;
   
   if( pGSensor_WheelTicks_FL_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_WheelTicks_FL_V_b1;
      * pGSensor_WheelTicks_FL_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_WheelTicks_FR_V
*
* FUNCTION ARGUMENTS:
*    CORECARSNRGSensorWheelTicksFRV * pGSensor_WheelTicks_FR_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_WheelTicks_FR_V
*    GSensor_WheelTicks_FR_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_WheelTicks_FR_V signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_WheelTicks_FR_V( CORECARSNRGSensorWheelTicksFRV * pGSensor_WheelTicks_FR_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRGSensorWheelTicksFRV signal_value;
   
   if( pGSensor_WheelTicks_FR_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_WheelTicks_FR_V_b1;
      * pGSensor_WheelTicks_FR_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_WheelTicks_RL_V
*
* FUNCTION ARGUMENTS:
*    CORECARSNRGSensorWheelTicksRLV * pGSensor_WheelTicks_RL_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_WheelTicks_RL_V
*    GSensor_WheelTicks_RL_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_WheelTicks_RL_V signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_WheelTicks_RL_V( CORECARSNRGSensorWheelTicksRLV * pGSensor_WheelTicks_RL_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRGSensorWheelTicksRLV signal_value;
   
   if( pGSensor_WheelTicks_RL_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_WheelTicks_RL_V_b1;
      * pGSensor_WheelTicks_RL_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_WheelTicks_RR_V
*
* FUNCTION ARGUMENTS:
*    CORECARSNRGSensorWheelTicksRRV * pGSensor_WheelTicks_RR_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_WheelTicks_RR_V
*    GSensor_WheelTicks_RR_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_WheelTicks_RR_V signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_WheelTicks_RR_V( CORECARSNRGSensorWheelTicksRRV * pGSensor_WheelTicks_RR_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRGSensorWheelTicksRRV signal_value;
   
   if( pGSensor_WheelTicks_RR_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_WheelTicks_RR_V_b1;
      * pGSensor_WheelTicks_RR_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_Reserved_16
*
* FUNCTION ARGUMENTS:
*    uint32 * pReserved_16 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_16
*    Reserved_16 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_16 signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_Reserved_16( uint32 * pReserved_16 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pReserved_16 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.Reserved_16_b18;
      * pReserved_16 = signal_value;
      if( signal_value <= C_EYEQMSG_CORECARSNR_RESERVED_16_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_WheelTicks_timestamp_FL
*
* FUNCTION ARGUMENTS:
*    uint32 * pGSensor_WheelTicks_timestamp_FL - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_WheelTicks_timestamp_FL
*    GSensor_WheelTicks_timestamp_FL returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_WheelTicks_timestamp_FL signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_WheelTicks_timestamp_FL( uint32 * pGSensor_WheelTicks_timestamp_FL )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pGSensor_WheelTicks_timestamp_FL != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_WheelTicks_timestamp_FL_b32;
      * pGSensor_WheelTicks_timestamp_FL = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_WheelTicks_timestamp_FR
*
* FUNCTION ARGUMENTS:
*    uint32 * pGSensor_WheelTicks_timestamp_FR - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_WheelTicks_timestamp_FR
*    GSensor_WheelTicks_timestamp_FR returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_WheelTicks_timestamp_FR signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_WheelTicks_timestamp_FR( uint32 * pGSensor_WheelTicks_timestamp_FR )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pGSensor_WheelTicks_timestamp_FR != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_WheelTicks_timestamp_FR_b32;
      * pGSensor_WheelTicks_timestamp_FR = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_WheelTicks_timestamp_RL
*
* FUNCTION ARGUMENTS:
*    uint32 * pGSensor_WheelTicks_timestamp_RL - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_WheelTicks_timestamp_RL
*    GSensor_WheelTicks_timestamp_RL returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_WheelTicks_timestamp_RL signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_WheelTicks_timestamp_RL( uint32 * pGSensor_WheelTicks_timestamp_RL )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pGSensor_WheelTicks_timestamp_RL != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_WheelTicks_timestamp_RL_b32;
      * pGSensor_WheelTicks_timestamp_RL = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_WheelTicks_timestamp_RR
*
* FUNCTION ARGUMENTS:
*    uint32 * pGSensor_WheelTicks_timestamp_RR - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_WheelTicks_timestamp_RR
*    GSensor_WheelTicks_timestamp_RR returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_WheelTicks_timestamp_RR signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_WheelTicks_timestamp_RR( uint32 * pGSensor_WheelTicks_timestamp_RR )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pGSensor_WheelTicks_timestamp_RR != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_WheelTicks_timestamp_RR_b32;
      * pGSensor_WheelTicks_timestamp_RR = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_WheelTicks_timestamp_FL_V
*
* FUNCTION ARGUMENTS:
*    CORECARSNRGSensorWheelTicksTimestampFLV * pGSensor_WheelTicks_timestamp_FL_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_WheelTicks_timestamp_FL_V
*    GSensor_WheelTicks_timestamp_FL_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_WheelTicks_timestamp_FL_V signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_WheelTicks_timestamp_FL_V( CORECARSNRGSensorWheelTicksTimestampFLV * pGSensor_WheelTicks_timestamp_FL_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRGSensorWheelTicksTimestampFLV signal_value;
   
   if( pGSensor_WheelTicks_timestamp_FL_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_WheelTicks_timestamp_FL_V_b1;
      * pGSensor_WheelTicks_timestamp_FL_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_WheelTicks_timestamp_FR_V
*
* FUNCTION ARGUMENTS:
*    CORECARSNRGSensorWheelTicksTimestampFRV * pGSensor_WheelTicks_timestamp_FR_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_WheelTicks_timestamp_FR_V
*    GSensor_WheelTicks_timestamp_FR_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_WheelTicks_timestamp_FR_V signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_WheelTicks_timestamp_FR_V( CORECARSNRGSensorWheelTicksTimestampFRV * pGSensor_WheelTicks_timestamp_FR_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRGSensorWheelTicksTimestampFRV signal_value;
   
   if( pGSensor_WheelTicks_timestamp_FR_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_WheelTicks_timestamp_FR_V_b1;
      * pGSensor_WheelTicks_timestamp_FR_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_WheelTicks_timestamp_RL_V
*
* FUNCTION ARGUMENTS:
*    CORECARSNRGSensorWheelTicksTimestampRLV * pGSensor_WheelTicks_timestamp_RL_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_WheelTicks_timestamp_RL_V
*    GSensor_WheelTicks_timestamp_RL_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_WheelTicks_timestamp_RL_V signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_WheelTicks_timestamp_RL_V( CORECARSNRGSensorWheelTicksTimestampRLV * pGSensor_WheelTicks_timestamp_RL_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRGSensorWheelTicksTimestampRLV signal_value;
   
   if( pGSensor_WheelTicks_timestamp_RL_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_WheelTicks_timestamp_RL_V_b1;
      * pGSensor_WheelTicks_timestamp_RL_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_GSensor_WheelTicks_timestamp_RR_V
*
* FUNCTION ARGUMENTS:
*    CORECARSNRGSensorWheelTicksTimestampRRV * pGSensor_WheelTicks_timestamp_RR_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of GSensor_WheelTicks_timestamp_RR_V
*    GSensor_WheelTicks_timestamp_RR_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns GSensor_WheelTicks_timestamp_RR_V signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_GSensor_WheelTicks_timestamp_RR_V( CORECARSNRGSensorWheelTicksTimestampRRV * pGSensor_WheelTicks_timestamp_RR_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRGSensorWheelTicksTimestampRRV signal_value;
   
   if( pGSensor_WheelTicks_timestamp_RR_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.GSensor_WheelTicks_timestamp_RR_V_b1;
      * pGSensor_WheelTicks_timestamp_RR_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Acc_Is_On
*
* FUNCTION ARGUMENTS:
*    CORECARSNRCINAccIsOn * pCIN_Acc_Is_On - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Acc_Is_On
*    CIN_Acc_Is_On returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Acc_Is_On signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Acc_Is_On( CORECARSNRCINAccIsOn * pCIN_Acc_Is_On )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRCINAccIsOn signal_value;
   
   if( pCIN_Acc_Is_On != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Acc_Is_On_b1;
      * pCIN_Acc_Is_On = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Acc_Is_On_Valid
*
* FUNCTION ARGUMENTS:
*    CORECARSNRCINAccIsOnValid * pCIN_Acc_Is_On_Valid - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Acc_Is_On_Valid
*    CIN_Acc_Is_On_Valid returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Acc_Is_On_Valid signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Acc_Is_On_Valid( CORECARSNRCINAccIsOnValid * pCIN_Acc_Is_On_Valid )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRCINAccIsOnValid signal_value;
   
   if( pCIN_Acc_Is_On_Valid != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Acc_Is_On_Valid_b1;
      * pCIN_Acc_Is_On_Valid = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Acc_Status_Available
*
* FUNCTION ARGUMENTS:
*    CORECARSNRCINAccStatusAvailable * pCIN_Acc_Status_Available - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Acc_Status_Available
*    CIN_Acc_Status_Available returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Acc_Status_Available signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Acc_Status_Available( CORECARSNRCINAccStatusAvailable * pCIN_Acc_Status_Available )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRCINAccStatusAvailable signal_value;
   
   if( pCIN_Acc_Status_Available != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Acc_Status_Available_b1;
      * pCIN_Acc_Status_Available = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Acc_Status_Available_Valid
*
* FUNCTION ARGUMENTS:
*    CORECARSNRCINAccStatusAvailableValid * pCIN_Acc_Status_Available_Valid - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Acc_Status_Available_Valid
*    CIN_Acc_Status_Available_Valid returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Acc_Status_Available_Valid signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Acc_Status_Available_Valid( CORECARSNRCINAccStatusAvailableValid * pCIN_Acc_Status_Available_Valid )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRCINAccStatusAvailableValid signal_value;
   
   if( pCIN_Acc_Status_Available_Valid != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Acc_Status_Available_Valid_b1;
      * pCIN_Acc_Status_Available_Valid = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Acc_Braking
*
* FUNCTION ARGUMENTS:
*    CORECARSNRCINAccBraking * pCIN_Acc_Braking - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Acc_Braking
*    CIN_Acc_Braking returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Acc_Braking signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Acc_Braking( CORECARSNRCINAccBraking * pCIN_Acc_Braking )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRCINAccBraking signal_value;
   
   if( pCIN_Acc_Braking != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Acc_Braking_b1;
      * pCIN_Acc_Braking = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_CIN_Acc_Braking_Valid
*
* FUNCTION ARGUMENTS:
*    CORECARSNRCINAccBrakingValid * pCIN_Acc_Braking_Valid - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CIN_Acc_Braking_Valid
*    CIN_Acc_Braking_Valid returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CIN_Acc_Braking_Valid signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_CIN_Acc_Braking_Valid( CORECARSNRCINAccBrakingValid * pCIN_Acc_Braking_Valid )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECARSNRCINAccBrakingValid signal_value;
   
   if( pCIN_Acc_Braking_Valid != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.CIN_Acc_Braking_Valid_b1;
      * pCIN_Acc_Braking_Valid = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECARSNR_Reserved_17
*
* FUNCTION ARGUMENTS:
*    uint32 * pReserved_17 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_17
*    Reserved_17 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_17 signal value of Core_Car_sensor message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECARSNR_Reserved_17( uint32 * pReserved_17 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pReserved_17 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECARSNR_ParamsApp_s.Reserved_17_b22;
      * pReserved_17 = signal_value;
      if( signal_value <= C_EYEQMSG_CORECARSNR_RESERVED_17_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

