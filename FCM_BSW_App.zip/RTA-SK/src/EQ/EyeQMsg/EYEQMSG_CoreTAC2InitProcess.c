

/*****************************************************************************
                  Include files
*****************************************************************************/
/* The suggested include file order is: */
#include "EyeQ_defs.h"    /* EyeQ project common definitions file    */

#include "EYEQMSG_CoreTAC2InitProcess.h"

/*****************************************************************************
                  Local symbolic constants
*****************************************************************************/
/*****************************************************************************
                  Local types, enums definitions
*****************************************************************************/
/*****************************************************************************
                  Local function prototypes
*****************************************************************************/
/*****************************************************************************
                  Local object definitions
*****************************************************************************/
/*****************************************************************************
                  Exported object definitions
*****************************************************************************/
EYEQMSG_CORETAC2INIT_Params_t   EYEQMSG_CORETAC2INIT_Params_s;
EYEQMSG_CORETAC2INIT_Params_t   EYEQMSG_CORETAC2INIT_ParamsApp_s;
/*****************************************************************************
                  Local function-like macros
*****************************************************************************/
/*****************************************************************************
                  Local defined macros
*****************************************************************************/
/*****************************************************************************
                  Function definitions
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_CORETAC2INIT_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_CORETAC2INIT_Params_t * pCore_TAC2_Init - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_TAC2_Init message 
*    Core_TAC2_Init message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_TAC2_Init message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_CORETAC2INIT_ParamsApp_MsgDataStruct( EYEQMSG_CORETAC2INIT_Params_t * pCore_TAC2_Init )
{
   Std_ReturnType status = C_SIG_INVALID;
   if( pCore_TAC2_Init != C_NULL_P )
   {
      status = C_SIG_VALID;
      * pCore_TAC2_Init = EYEQMSG_CORETAC2INIT_ParamsApp_s;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_TAC_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pTAC_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TAC_Zero_byte
*    TAC_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TAC_Zero_byte signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_TAC_Zero_byte( uint8 * pTAC_Zero_byte )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pTAC_Zero_byte != C_NULL_P )
   {
      signal_value = EYEQMSG_CORETAC2INIT_ParamsApp_s.TAC_Zero_byte_b8;
      * pTAC_Zero_byte = signal_value;
      if( signal_value <= C_EYEQMSG_CORETAC2INIT_TAC_ZERO_BYTE_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_TAC_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pTAC_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TAC_Protocol_Version
*    TAC_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TAC_Protocol_Version signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_TAC_Protocol_Version( uint8 * pTAC_Protocol_Version )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pTAC_Protocol_Version != C_NULL_P )
   {
      signal_value = EYEQMSG_CORETAC2INIT_ParamsApp_s.TAC_Protocol_Version_b8;
      * pTAC_Protocol_Version = signal_value;
      if( (signal_value >= C_EYEQMSG_CORETAC2INIT_TAC_PROTOCOL_VERSION_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORETAC2INIT_TAC_PROTOCOL_VERSION_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_TAC_Optional_Signals
*
* FUNCTION ARGUMENTS:
*    uint16 * pTAC_Optional_Signals - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TAC_Optional_Signals
*    TAC_Optional_Signals returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TAC_Optional_Signals signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_TAC_Optional_Signals( uint16 * pTAC_Optional_Signals )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pTAC_Optional_Signals != C_NULL_P )
   {
      signal_value = EYEQMSG_CORETAC2INIT_ParamsApp_s.TAC_Optional_Signals_b16;
      * pTAC_Optional_Signals = signal_value;
      if( signal_value <= C_EYEQMSG_CORETAC2INIT_TAC_OPTIONAL_SIGNALS_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_TAC_Mode
*
* FUNCTION ARGUMENTS:
*    uint8 * pTAC_Mode - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TAC_Mode
*    TAC_Mode returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TAC_Mode signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_TAC_Mode( uint8 * pTAC_Mode )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pTAC_Mode != C_NULL_P )
   {
      signal_value = EYEQMSG_CORETAC2INIT_ParamsApp_s.TAC_Mode_b8;
      * pTAC_Mode = signal_value;
      if( signal_value <= C_EYEQMSG_CORETAC2INIT_TAC_MODE_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_TAC_BottomLeftSquare_0
*
* FUNCTION ARGUMENTS:
*    uint8 * pTAC_BottomLeftSquare_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TAC_BottomLeftSquare_0
*    TAC_BottomLeftSquare_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TAC_BottomLeftSquare_0 signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_TAC_BottomLeftSquare_0( uint8 * pTAC_BottomLeftSquare_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pTAC_BottomLeftSquare_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORETAC2INIT_ParamsApp_s.TAC_BottomLeftSquare_0_b2;
      * pTAC_BottomLeftSquare_0 = signal_value;
      if( signal_value <= C_EYEQMSG_CORETAC2INIT_TAC_BOTTOMLEFTSQUARE_0_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_TAC_BottomLeftSquare_1
*
* FUNCTION ARGUMENTS:
*    uint8 * pTAC_BottomLeftSquare_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TAC_BottomLeftSquare_1
*    TAC_BottomLeftSquare_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TAC_BottomLeftSquare_1 signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_TAC_BottomLeftSquare_1( uint8 * pTAC_BottomLeftSquare_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pTAC_BottomLeftSquare_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORETAC2INIT_ParamsApp_s.TAC_BottomLeftSquare_1_b2;
      * pTAC_BottomLeftSquare_1 = signal_value;
      if( signal_value <= C_EYEQMSG_CORETAC2INIT_TAC_BOTTOMLEFTSQUARE_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_TAC_BottomLeftSquare_2
*
* FUNCTION ARGUMENTS:
*    uint8 * pTAC_BottomLeftSquare_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TAC_BottomLeftSquare_2
*    TAC_BottomLeftSquare_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TAC_BottomLeftSquare_2 signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_TAC_BottomLeftSquare_2( uint8 * pTAC_BottomLeftSquare_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pTAC_BottomLeftSquare_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORETAC2INIT_ParamsApp_s.TAC_BottomLeftSquare_2_b2;
      * pTAC_BottomLeftSquare_2 = signal_value;
      if( signal_value <= C_EYEQMSG_CORETAC2INIT_TAC_BOTTOMLEFTSQUARE_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_TAC_TargetInfo_Lat_Distance_0
*
* FUNCTION ARGUMENTS:
*    uint16 * pTAC_TargetInfo_Lat_Distance_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TAC_TargetInfo_Lat_Distance_0
*    TAC_TargetInfo_Lat_Distance_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TAC_TargetInfo_Lat_Distance_0 signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_TAC_TargetInfo_Lat_Distance_0( uint16 * pTAC_TargetInfo_Lat_Distance_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pTAC_TargetInfo_Lat_Distance_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORETAC2INIT_ParamsApp_s.TAC_TargetInfo_Lat_Distance_0_b16;
      * pTAC_TargetInfo_Lat_Distance_0 = signal_value;
      if( signal_value <= C_EYEQMSG_CORETAC2INIT_TAC_TARGETINFO_LAT_DISTANCE_0_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_Reserved_1
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1
*    Reserved_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1 signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_Reserved_1( uint8 * pReserved_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pReserved_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORETAC2INIT_ParamsApp_s.Reserved_1_b2;
      * pReserved_1 = signal_value;
      if( signal_value <= C_EYEQMSG_CORETAC2INIT_RESERVED_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_TAC_TargetInfo_Lat_Distance_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pTAC_TargetInfo_Lat_Distance_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TAC_TargetInfo_Lat_Distance_1
*    TAC_TargetInfo_Lat_Distance_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TAC_TargetInfo_Lat_Distance_1 signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_TAC_TargetInfo_Lat_Distance_1( uint16 * pTAC_TargetInfo_Lat_Distance_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pTAC_TargetInfo_Lat_Distance_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORETAC2INIT_ParamsApp_s.TAC_TargetInfo_Lat_Distance_1_b16;
      * pTAC_TargetInfo_Lat_Distance_1 = signal_value;
      if( signal_value <= C_EYEQMSG_CORETAC2INIT_TAC_TARGETINFO_LAT_DISTANCE_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_TAC_TargetInfo_Lat_Distance_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pTAC_TargetInfo_Lat_Distance_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TAC_TargetInfo_Lat_Distance_2
*    TAC_TargetInfo_Lat_Distance_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TAC_TargetInfo_Lat_Distance_2 signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_TAC_TargetInfo_Lat_Distance_2( uint16 * pTAC_TargetInfo_Lat_Distance_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pTAC_TargetInfo_Lat_Distance_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORETAC2INIT_ParamsApp_s.TAC_TargetInfo_Lat_Distance_2_b16;
      * pTAC_TargetInfo_Lat_Distance_2 = signal_value;
      if( signal_value <= C_EYEQMSG_CORETAC2INIT_TAC_TARGETINFO_LAT_DISTANCE_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_TAC_TargetInfo_Height_0
*
* FUNCTION ARGUMENTS:
*    uint16 * pTAC_TargetInfo_Height_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TAC_TargetInfo_Height_0
*    TAC_TargetInfo_Height_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TAC_TargetInfo_Height_0 signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_TAC_TargetInfo_Height_0( uint16 * pTAC_TargetInfo_Height_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pTAC_TargetInfo_Height_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORETAC2INIT_ParamsApp_s.TAC_TargetInfo_Height_0_b16;
      * pTAC_TargetInfo_Height_0 = signal_value;
      if( signal_value <= C_EYEQMSG_CORETAC2INIT_TAC_TARGETINFO_HEIGHT_0_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_TAC_TargetInfo_Height_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pTAC_TargetInfo_Height_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TAC_TargetInfo_Height_1
*    TAC_TargetInfo_Height_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TAC_TargetInfo_Height_1 signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_TAC_TargetInfo_Height_1( uint16 * pTAC_TargetInfo_Height_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pTAC_TargetInfo_Height_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORETAC2INIT_ParamsApp_s.TAC_TargetInfo_Height_1_b16;
      * pTAC_TargetInfo_Height_1 = signal_value;
      if( signal_value <= C_EYEQMSG_CORETAC2INIT_TAC_TARGETINFO_HEIGHT_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_TAC_TargetInfo_Height_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pTAC_TargetInfo_Height_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TAC_TargetInfo_Height_2
*    TAC_TargetInfo_Height_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TAC_TargetInfo_Height_2 signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_TAC_TargetInfo_Height_2( uint16 * pTAC_TargetInfo_Height_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pTAC_TargetInfo_Height_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORETAC2INIT_ParamsApp_s.TAC_TargetInfo_Height_2_b16;
      * pTAC_TargetInfo_Height_2 = signal_value;
      if( signal_value <= C_EYEQMSG_CORETAC2INIT_TAC_TARGETINFO_HEIGHT_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_TAC_Camera_Height
*
* FUNCTION ARGUMENTS:
*    uint16 * pTAC_Camera_Height - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TAC_Camera_Height
*    TAC_Camera_Height returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TAC_Camera_Height signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_TAC_Camera_Height( uint16 * pTAC_Camera_Height )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pTAC_Camera_Height != C_NULL_P )
   {
      signal_value = EYEQMSG_CORETAC2INIT_ParamsApp_s.TAC_Camera_Height_b16;
      * pTAC_Camera_Height = signal_value;
      if( (signal_value >= C_EYEQMSG_CORETAC2INIT_TAC_CAMERA_HEIGHT_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORETAC2INIT_TAC_CAMERA_HEIGHT_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_TAC_Camera_Z
*
* FUNCTION ARGUMENTS:
*    uint16 * pTAC_Camera_Z - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TAC_Camera_Z
*    TAC_Camera_Z returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TAC_Camera_Z signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_TAC_Camera_Z( uint16 * pTAC_Camera_Z )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pTAC_Camera_Z != C_NULL_P )
   {
      signal_value = EYEQMSG_CORETAC2INIT_ParamsApp_s.TAC_Camera_Z_b16;
      * pTAC_Camera_Z = signal_value;
      if( signal_value <= C_EYEQMSG_CORETAC2INIT_TAC_CAMERA_Z_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_TAC_Max_Horizon
*
* FUNCTION ARGUMENTS:
*    uint8 * pTAC_Max_Horizon - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TAC_Max_Horizon
*    TAC_Max_Horizon returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TAC_Max_Horizon signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_TAC_Max_Horizon( uint8 * pTAC_Max_Horizon )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pTAC_Max_Horizon != C_NULL_P )
   {
      signal_value = EYEQMSG_CORETAC2INIT_ParamsApp_s.TAC_Max_Horizon_b8;
      * pTAC_Max_Horizon = signal_value;
      if( signal_value <= C_EYEQMSG_CORETAC2INIT_TAC_MAX_HORIZON_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_TAC_Min_Horizon
*
* FUNCTION ARGUMENTS:
*    uint8 * pTAC_Min_Horizon - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TAC_Min_Horizon
*    TAC_Min_Horizon returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TAC_Min_Horizon signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_TAC_Min_Horizon( uint8 * pTAC_Min_Horizon )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pTAC_Min_Horizon != C_NULL_P )
   {
      signal_value = EYEQMSG_CORETAC2INIT_ParamsApp_s.TAC_Min_Horizon_b8;
      * pTAC_Min_Horizon = signal_value;
      if( signal_value <= C_EYEQMSG_CORETAC2INIT_TAC_MIN_HORIZON_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_TAC_Max_Yaw
*
* FUNCTION ARGUMENTS:
*    uint8 * pTAC_Max_Yaw - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TAC_Max_Yaw
*    TAC_Max_Yaw returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TAC_Max_Yaw signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_TAC_Max_Yaw( uint8 * pTAC_Max_Yaw )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pTAC_Max_Yaw != C_NULL_P )
   {
      signal_value = EYEQMSG_CORETAC2INIT_ParamsApp_s.TAC_Max_Yaw_b8;
      * pTAC_Max_Yaw = signal_value;
      if( signal_value <= C_EYEQMSG_CORETAC2INIT_TAC_MAX_YAW_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_TAC_Min_Yaw
*
* FUNCTION ARGUMENTS:
*    uint8 * pTAC_Min_Yaw - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TAC_Min_Yaw
*    TAC_Min_Yaw returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TAC_Min_Yaw signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_TAC_Min_Yaw( uint8 * pTAC_Min_Yaw )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pTAC_Min_Yaw != C_NULL_P )
   {
      signal_value = EYEQMSG_CORETAC2INIT_ParamsApp_s.TAC_Min_Yaw_b8;
      * pTAC_Min_Yaw = signal_value;
      if( signal_value <= C_EYEQMSG_CORETAC2INIT_TAC_MIN_YAW_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_TAC_Max_RollAngle
*
* FUNCTION ARGUMENTS:
*    uint8 * pTAC_Max_RollAngle - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TAC_Max_RollAngle
*    TAC_Max_RollAngle returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TAC_Max_RollAngle signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_TAC_Max_RollAngle( uint8 * pTAC_Max_RollAngle )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pTAC_Max_RollAngle != C_NULL_P )
   {
      signal_value = EYEQMSG_CORETAC2INIT_ParamsApp_s.TAC_Max_RollAngle_b8;
      * pTAC_Max_RollAngle = signal_value;
      if( signal_value <= C_EYEQMSG_CORETAC2INIT_TAC_MAX_ROLLANGLE_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_Reserved_2
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_2
*    Reserved_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_2 signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_Reserved_2( uint8 * pReserved_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pReserved_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORETAC2INIT_ParamsApp_s.Reserved_2_b8;
      * pReserved_2 = signal_value;
      if( signal_value <= C_EYEQMSG_CORETAC2INIT_RESERVED_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_TAC_SquareSideSize
*
* FUNCTION ARGUMENTS:
*    uint16 * pTAC_SquareSideSize - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TAC_SquareSideSize
*    TAC_SquareSideSize returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TAC_SquareSideSize signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_TAC_SquareSideSize( uint16 * pTAC_SquareSideSize )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pTAC_SquareSideSize != C_NULL_P )
   {
      signal_value = EYEQMSG_CORETAC2INIT_ParamsApp_s.TAC_SquareSideSize_b9;
      * pTAC_SquareSideSize = signal_value;
      if( signal_value <= C_EYEQMSG_CORETAC2INIT_TAC_SQUARESIDESIZE_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_TAC_Bottom
*
* FUNCTION ARGUMENTS:
*    uint8 * pTAC_Bottom - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TAC_Bottom
*    TAC_Bottom returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TAC_Bottom signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_TAC_Bottom( uint8 * pTAC_Bottom )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pTAC_Bottom != C_NULL_P )
   {
      signal_value = EYEQMSG_CORETAC2INIT_ParamsApp_s.TAC_Bottom_b8;
      * pTAC_Bottom = signal_value;
      if( signal_value <= C_EYEQMSG_CORETAC2INIT_TAC_BOTTOM_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_TAC_Targets_Num
*
* FUNCTION ARGUMENTS:
*    uint8 * pTAC_Targets_Num - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of TAC_Targets_Num
*    TAC_Targets_Num returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns TAC_Targets_Num signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_TAC_Targets_Num( uint8 * pTAC_Targets_Num )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pTAC_Targets_Num != C_NULL_P )
   {
      signal_value = EYEQMSG_CORETAC2INIT_ParamsApp_s.TAC_Targets_Num_b2;
      * pTAC_Targets_Num = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORETAC2INIT_Reserved_3
*
* FUNCTION ARGUMENTS:
*    uint16 * pReserved_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_3
*    Reserved_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_3 signal value of Core_TAC2_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORETAC2INIT_Reserved_3( uint16 * pReserved_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pReserved_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORETAC2INIT_ParamsApp_s.Reserved_3_b13;
      * pReserved_3 = signal_value;
      if( signal_value <= C_EYEQMSG_CORETAC2INIT_RESERVED_3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

