#ifndef _EYEQMSG_BOOTDIAGMSGPROCESS_H_
#define _EYEQMSG_BOOTDIAGMSGPROCESS_H_

/*****************************************************************************
                  Included header files
*****************************************************************************/
#include <Std_Types.h>

/*****************************************************************************
                  Include files
*****************************************************************************/
/*****************************************************************************
                  Exported symbolic constants
*****************************************************************************/

/* Datagram message ID */
#define C_EYEQMSG_BOOTDIAGMSG_MSG_ID                          ( 0x10U )

/* Datagram message lengths */
#define C_EYEQMSG_BOOTDIAGMSG_MSG_LEN                         ( sizeof(EYEQMSG_BOOTDIAGMSG_Params_t) )

/* Protocol ENUMs */

/* MCU output messages */

/* Core_Boot_Diagnostics_Message_protocol Enums */
/* BOOT_Failure_info_7_b32 signal Min & Max range limits */
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FAILURE_INFO_7_RMIN        ( 0U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FAILURE_INFO_7_RMAX        ( 4294967295U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FAILURE_INFO_7_NUMR        ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FAILURE_INFO_7_DEMNR       ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FAILURE_INFO_7_OFFSET      ( 0U )

/* BOOT_Failure_info_6_b32 signal Min & Max range limits */
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FAILURE_INFO_6_RMIN        ( 0U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FAILURE_INFO_6_RMAX        ( 4294967295U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FAILURE_INFO_6_NUMR        ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FAILURE_INFO_6_DEMNR       ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FAILURE_INFO_6_OFFSET      ( 0U )

/* BOOT_Failure_info_5_b32 signal Min & Max range limits */
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FAILURE_INFO_5_RMIN        ( 0U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FAILURE_INFO_5_RMAX        ( 4294967295U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FAILURE_INFO_5_NUMR        ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FAILURE_INFO_5_DEMNR       ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FAILURE_INFO_5_OFFSET      ( 0U )

/* BOOT_Failure_info_4_b32 signal Min & Max range limits */
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FAILURE_INFO_4_RMIN        ( 0U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FAILURE_INFO_4_RMAX        ( 4294967295U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FAILURE_INFO_4_NUMR        ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FAILURE_INFO_4_DEMNR       ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FAILURE_INFO_4_OFFSET      ( 0U )

/* BOOT_Failure_info_3_b32 signal Min & Max range limits */
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FAILURE_INFO_3_RMIN        ( 0U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FAILURE_INFO_3_RMAX        ( 4294967295U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FAILURE_INFO_3_NUMR        ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FAILURE_INFO_3_DEMNR       ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FAILURE_INFO_3_OFFSET      ( 0U )

/* BOOT_Failure_info_2_b32 signal Min & Max range limits */
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FAILURE_INFO_2_RMIN        ( 0U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FAILURE_INFO_2_RMAX        ( 4294967295U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FAILURE_INFO_2_NUMR        ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FAILURE_INFO_2_DEMNR       ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FAILURE_INFO_2_OFFSET      ( 0U )

/* BOOT_Failure_info_1_b32 signal Min & Max range limits */
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FAILURE_INFO_1_RMIN        ( 0U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FAILURE_INFO_1_RMAX        ( 4294967295U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FAILURE_INFO_1_NUMR        ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FAILURE_INFO_1_DEMNR       ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FAILURE_INFO_1_OFFSET      ( 0U )

/* BOOT_Failure_info_0_b24 signal Min & Max range limits */
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FAILURE_INFO_0_RMIN        ( 0U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FAILURE_INFO_0_RMAX        ( 16777215U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FAILURE_INFO_0_NUMR        ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FAILURE_INFO_0_DEMNR       ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FAILURE_INFO_0_OFFSET      ( 0U )

/* Boot_Stage_b8 signal Enums */
typedef uint8 BOOTDIAGMSGBootStage;
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_STAGE_RESERVED             ( BOOTDIAGMSGBootStage ) ( 0U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_STAGE_BIST_RESULTS         ( BOOTDIAGMSGBootStage ) ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_STAGE_BOOT_AUTH_RESULT     ( BOOTDIAGMSGBootStage ) ( 2U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_STAGE_DRAM_INIT_TRAINING_RESULT ( BOOTDIAGMSGBootStage ) ( 3U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_STAGE_DRAM_TEST_RESULT     ( BOOTDIAGMSGBootStage ) ( 4U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_STAGE_APP_AUTH_LOADING_RESULT ( BOOTDIAGMSGBootStage ) ( 5U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_STAGE_RESERVED_1           ( BOOTDIAGMSGBootStage ) ( 6U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_STAGE_RESERVED_2           ( BOOTDIAGMSGBootStage ) ( 7U )

/* Boot_Stage_b8 signal Min & Max range limits */
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_STAGE_RMIN                 ( 0U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_STAGE_RMAX                 ( 7U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_STAGE_NUMR                 ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_STAGE_DEMNR                ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_STAGE_OFFSET               ( 0U )

/* BOOT_Flash_2_Size_b24 signal Min & Max range limits */
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FLASH_2_SIZE_RMIN          ( 0U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FLASH_2_SIZE_RMAX          ( 16777215U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FLASH_2_SIZE_NUMR          ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FLASH_2_SIZE_DEMNR         ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FLASH_2_SIZE_OFFSET        ( 0U )

/* BOOT_Flash2_Man_Code_b8 signal Min & Max range limits */
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FLASH2_MAN_CODE_RMIN       ( 0U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FLASH2_MAN_CODE_RMAX       ( 255U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FLASH2_MAN_CODE_NUMR       ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FLASH2_MAN_CODE_DEMNR      ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FLASH2_MAN_CODE_OFFSET     ( 0U )

/* Reserved_2_b8 signal Min & Max range limits */
#define C_EYEQMSG_BOOTDIAGMSG_RESERVED_2_RMIN                 ( 0U )
#define C_EYEQMSG_BOOTDIAGMSG_RESERVED_2_RMAX                 ( 0U )
#define C_EYEQMSG_BOOTDIAGMSG_RESERVED_2_NUMR                 ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_RESERVED_2_DEMNR                ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_RESERVED_2_OFFSET               ( 0U )

/* BOOT_LPDDR4_Temperature_Status_b8 signal Enums */
typedef uint8 BOOTDIAGMSGBOOTLPDDR4TemperatureStatus;
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_LPDDR4_TEMPERATURE_STATUS_85_DEF ( BOOTDIAGMSGBOOTLPDDR4TemperatureStatus ) ( 0U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_LPDDR4_TEMPERATURE_STATUS_SDRAM_LOW_TEMP_EXCEEDED ( BOOTDIAGMSGBOOTLPDDR4TemperatureStatus ) ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_LPDDR4_TEMPERATURE_STATUS_SDRAM_HIGH_TEMP_EXCEEDED ( BOOTDIAGMSGBOOTLPDDR4TemperatureStatus ) ( 2U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_LPDDR4_TEMPERATURE_STATUS_DEVICE_MUCH_GREATER_85C_025X ( BOOTDIAGMSGBOOTLPDDR4TemperatureStatus ) ( 3U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_LPDDR4_TEMPERATURE_STATUS_DEVICE_MUCH_LESS_85C_DEF ( BOOTDIAGMSGBOOTLPDDR4TemperatureStatus ) ( 4U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_LPDDR4_TEMPERATURE_STATUS_DEVICE_LESS_85C_DEF ( BOOTDIAGMSGBOOTLPDDR4TemperatureStatus ) ( 5U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_LPDDR4_TEMPERATURE_STATUS_DEVICE_GREATER_85C_05X ( BOOTDIAGMSGBOOTLPDDR4TemperatureStatus ) ( 6U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_LPDDR4_TEMPERATURE_STATUS_DEVICE_GREATER_85C_025X ( BOOTDIAGMSGBOOTLPDDR4TemperatureStatus ) ( 7U )

/* BOOT_LPDDR4_Temperature_Status_b8 signal Min & Max range limits */
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_LPDDR4_TEMPERATURE_STATUS_RMIN ( 0U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_LPDDR4_TEMPERATURE_STATUS_RMAX ( 7U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_LPDDR4_TEMPERATURE_STATUS_NUMR ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_LPDDR4_TEMPERATURE_STATUS_DEMNR ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_LPDDR4_TEMPERATURE_STATUS_OFFSET ( 0U )

/* BOOT_VMP_Temperature_sb8 signal Min & Max range limits */
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_VMP_TEMPERATURE_RMIN       ( -128 )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_VMP_TEMPERATURE_RMAX       ( 127 )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_VMP_TEMPERATURE_NUMR       ( 1 )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_VMP_TEMPERATURE_DEMNR      ( 1 )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_VMP_TEMPERATURE_OFFSET     ( 0U )

/* BOOT_CPU_Temperature_sb8 signal Min & Max range limits */
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_CPU_TEMPERATURE_RMIN       ( -128 )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_CPU_TEMPERATURE_RMAX       ( 127 )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_CPU_TEMPERATURE_NUMR       ( 1 )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_CPU_TEMPERATURE_DEMNR      ( 1 )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_CPU_TEMPERATURE_OFFSET     ( 0U )

/* BOOT_Flash_Size_b24 signal Min & Max range limits */
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FLASH_SIZE_RMIN            ( 0U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FLASH_SIZE_RMAX            ( 16777215U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FLASH_SIZE_NUMR            ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FLASH_SIZE_DEMNR           ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FLASH_SIZE_OFFSET          ( 0U )

/* BOOT_Flash_Man_Code_b8 signal Min & Max range limits */
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FLASH_MAN_CODE_RMIN        ( 0U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FLASH_MAN_CODE_RMAX        ( 255U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FLASH_MAN_CODE_NUMR        ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FLASH_MAN_CODE_DEMNR       ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_FLASH_MAN_CODE_OFFSET      ( 0U )

/* BOOT_DDR_Size_b24 signal Min & Max range limits */
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_DDR_SIZE_RMIN              ( 0U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_DDR_SIZE_RMAX              ( 16777215U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_DDR_SIZE_NUMR              ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_DDR_SIZE_DEMNR             ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_DDR_SIZE_OFFSET            ( 0U )

/* BOOT_DDR_manufacturer_code_b8 signal Min & Max range limits */
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_DDR_MANUFACTURER_CODE_RMIN ( 0U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_DDR_MANUFACTURER_CODE_RMAX ( 255U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_DDR_MANUFACTURER_CODE_NUMR ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_DDR_MANUFACTURER_CODE_DEMNR ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_DDR_MANUFACTURER_CODE_OFFSET ( 0U )

/* BOOT_EyeQ_ID_b32 signal Min & Max range limits */
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_EYEQ_ID_RMIN               ( 0U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_EYEQ_ID_RMAX               ( 4294967295U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_EYEQ_ID_NUMR               ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_EYEQ_ID_DEMNR              ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_EYEQ_ID_OFFSET             ( 0U )

/* BOOT_EyeQ_Type_b32 signal Min & Max range limits */
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_EYEQ_TYPE_RMIN             ( 0U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_EYEQ_TYPE_RMAX             ( 4294967295U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_EYEQ_TYPE_NUMR             ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_EYEQ_TYPE_DEMNR            ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_EYEQ_TYPE_OFFSET           ( 0U )

/* BOOT_Application_ver_b32 signal Min & Max range limits */
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_APPLICATION_VER_RMIN       ( 0U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_APPLICATION_VER_RMAX       ( 4294967295U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_APPLICATION_VER_NUMR       ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_APPLICATION_VER_DEMNR      ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_APPLICATION_VER_OFFSET     ( 0U )

/* BOOT_Ver_b32 signal Min & Max range limits */
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_VER_RMIN                   ( 0U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_VER_RMAX                   ( 4294967295U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_VER_NUMR                   ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_VER_DEMNR                  ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_VER_OFFSET                 ( 0U )

/* BOOT_Board_revision_b8 signal Min & Max range limits */
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_BOARD_REVISION_RMIN        ( 0U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_BOARD_REVISION_RMAX        ( 255U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_BOARD_REVISION_NUMR        ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_BOARD_REVISION_DEMNR       ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_BOARD_REVISION_OFFSET      ( 0U )

/* BOOT_Board_project_code_b8 signal Min & Max range limits */
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_BOARD_PROJECT_CODE_RMIN    ( 0U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_BOARD_PROJECT_CODE_RMAX    ( 255U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_BOARD_PROJECT_CODE_NUMR    ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_BOARD_PROJECT_CODE_DEMNR   ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_BOARD_PROJECT_CODE_OFFSET  ( 0U )

/* BOOT_Test_results_b16 signal Enums */
typedef uint16 BOOTDIAGMSGBOOTTestResults;
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_TEST_RESULTS_EYEQ_OVER_TEMPERATURE ( BOOTDIAGMSGBOOTTestResults ) ( 0U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_TEST_RESULTS_BIST          ( BOOTDIAGMSGBOOTTestResults ) ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_TEST_RESULTS_PLL_INIT_FINISHED ( BOOTDIAGMSGBOOTTestResults ) ( 2U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_TEST_RESULTS_PARITY_CHECK  ( BOOTDIAGMSGBOOTTestResults ) ( 3U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_TEST_RESULTS_FLASH_CRC_OF_BOOT ( BOOTDIAGMSGBOOTTestResults ) ( 4U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_TEST_RESULTS_DDR_INIT_FINISHED ( BOOTDIAGMSGBOOTTestResults ) ( 5U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_TEST_RESULTS_DDR_TEMPERATURE ( BOOTDIAGMSGBOOTTestResults ) ( 6U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_TEST_RESULTS_DDR_TEST      ( BOOTDIAGMSGBOOTTestResults ) ( 7U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_TEST_RESULTS_FLASH_CRC_OF_APPLICATION ( BOOTDIAGMSGBOOTTestResults ) ( 8U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_TEST_RESULTS_FLASH_CRC_OF_FFS ( BOOTDIAGMSGBOOTTestResults ) ( 9U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_TEST_RESULTS_UNSUPPORTED_EYEQ_VERSION ( BOOTDIAGMSGBOOTTestResults ) ( 10U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_TEST_RESULTS_AUTHENTICATION_FAILURE ( BOOTDIAGMSGBOOTTestResults ) ( 11U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_TEST_RESULTS_RESERVED_1    ( BOOTDIAGMSGBOOTTestResults ) ( 12U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_TEST_RESULTS_RESERVED_2    ( BOOTDIAGMSGBOOTTestResults ) ( 13U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_TEST_RESULTS_RESERVED_3    ( BOOTDIAGMSGBOOTTestResults ) ( 14U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_TEST_RESULTS_RESERVED_4    ( BOOTDIAGMSGBOOTTestResults ) ( 15U )

/* BOOT_Test_results_b16 signal Min & Max range limits */
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_TEST_RESULTS_RMIN          ( 0U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_TEST_RESULTS_RMAX          ( 65535U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_TEST_RESULTS_NUMR          ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_TEST_RESULTS_DEMNR         ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_TEST_RESULTS_OFFSET        ( 0U )

/* Reserved_1_b16 signal Min & Max range limits */
#define C_EYEQMSG_BOOTDIAGMSG_RESERVED_1_RMIN                 ( 0U )
#define C_EYEQMSG_BOOTDIAGMSG_RESERVED_1_RMAX                 ( 0U )
#define C_EYEQMSG_BOOTDIAGMSG_RESERVED_1_NUMR                 ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_RESERVED_1_DEMNR                ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_RESERVED_1_OFFSET               ( 0U )

/* BootMsg_Protocol_Version_b8 signal Min & Max range limits */
#define C_EYEQMSG_BOOTDIAGMSG_BOOTMSG_PROTOCOL_VERSION_RMIN   ( 2U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOTMSG_PROTOCOL_VERSION_RMAX   ( 2U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOTMSG_PROTOCOL_VERSION_NUMR   ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOTMSG_PROTOCOL_VERSION_DEMNR  ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOTMSG_PROTOCOL_VERSION_OFFSET ( 0U )

/* BOOT_Zero_byte_b8 signal Min & Max range limits */
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_ZERO_BYTE_RMIN             ( 0U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_ZERO_BYTE_RMAX             ( 0U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_ZERO_BYTE_NUMR             ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_ZERO_BYTE_DEMNR            ( 1U )
#define C_EYEQMSG_BOOTDIAGMSG_BOOT_ZERO_BYTE_OFFSET           ( 0U )


/*****************************************************************************
                  Exported function-like macros
*****************************************************************************/
/*****************************************************************************
                  Exported defined macros
*****************************************************************************/
/*****************************************************************************
                  Exported types, enums definitions
*****************************************************************************/
typedef struct
{
   #if ENABLE_BIG_ENDIAN_FORMAT
      uint32        BOOT_Zero_byte_b8                            : 8U;
      
      uint32        BootMsg_Protocol_Version_b8                  : 8U;
      
      uint32        Reserved_1_1_b8                              : 8U;
      
      uint32        Reserved_1_2_b8                              : 8U;
      
      uint32        BOOT_Test_results_1_b8                       : 8U;
      
      uint32        BOOT_Test_results_2_b8                       : 8U;
      
      uint32        BOOT_Board_project_code_b8                   : 8U;
      
      uint32        BOOT_Board_revision_b8                       : 8U;
      
      uint32        BOOT_Ver_1_b8                                : 8U;
      
      uint32        BOOT_Ver_2_b8                                : 8U;
      
      uint32        BOOT_Ver_3_b8                                : 8U;
      
      uint32        BOOT_Ver_4_b8                                : 8U;
      
      uint32        BOOT_Application_ver_1_b8                    : 8U;
      
      uint32        BOOT_Application_ver_2_b8                    : 8U;
      
      uint32        BOOT_Application_ver_3_b8                    : 8U;
      
      uint32        BOOT_Application_ver_4_b8                    : 8U;
      
      uint32        BOOT_EyeQ_Type_1_b8                          : 8U;
      
      uint32        BOOT_EyeQ_Type_2_b8                          : 8U;
      
      uint32        BOOT_EyeQ_Type_3_b8                          : 8U;
      
      uint32        BOOT_EyeQ_Type_4_b8                          : 8U;
      
      uint32        BOOT_EyeQ_ID_1_b8                            : 8U;
      
      uint32        BOOT_EyeQ_ID_2_b8                            : 8U;
      
      uint32        BOOT_EyeQ_ID_3_b8                            : 8U;
      
      uint32        BOOT_EyeQ_ID_4_b8                            : 8U;
      
      uint32        BOOT_DDR_manufacturer_code_b8                : 8U;
      
      uint32        BOOT_DDR_Size_1_b8                           : 8U;
      
      uint32        BOOT_DDR_Size_2_b8                           : 8U;
      
      uint32        BOOT_DDR_Size_3_b8                           : 8U;
      
      uint32        BOOT_Flash_Man_Code_b8                       : 8U;
      
      uint32        BOOT_Flash_Size_1_b8                         : 8U;
      
      uint32        BOOT_Flash_Size_2_b8                         : 8U;
      
      uint32        BOOT_Flash_Size_3_b8                         : 8U;
      
      sint32        BOOT_CPU_Temperature_sb8                     : 8;
      
      sint32        BOOT_VMP_Temperature_sb8                     : 8;
      
      uint32        BOOT_LPDDR4_Temperature_Status_b8            : 8U;
      
      uint32        Reserved_2_b8                                : 8U;
      
      uint32        BOOT_Flash2_Man_Code_b8                      : 8U;
      
      uint32        BOOT_Flash_2_Size_1_b8                       : 8U;
      
      uint32        BOOT_Flash_2_Size_2_b8                       : 8U;
      
      uint32        BOOT_Flash_2_Size_3_b8                       : 8U;
      
      uint32        Boot_Stage_b8                                : 8U;
      
      uint32        BOOT_Failure_info_0_1_b8                     : 8U;
      
      uint32        BOOT_Failure_info_0_2_b8                     : 8U;
      
      uint32        BOOT_Failure_info_0_3_b8                     : 8U;
      
      uint32        BOOT_Failure_info_1_1_b8                     : 8U;
      
      uint32        BOOT_Failure_info_1_2_b8                     : 8U;
      
      uint32        BOOT_Failure_info_1_3_b8                     : 8U;
      
      uint32        BOOT_Failure_info_1_4_b8                     : 8U;
      
      uint32        BOOT_Failure_info_2_1_b8                     : 8U;
      
      uint32        BOOT_Failure_info_2_2_b8                     : 8U;
      
      uint32        BOOT_Failure_info_2_3_b8                     : 8U;
      
      uint32        BOOT_Failure_info_2_4_b8                     : 8U;
      
      uint32        BOOT_Failure_info_3_1_b8                     : 8U;
      
      uint32        BOOT_Failure_info_3_2_b8                     : 8U;
      
      uint32        BOOT_Failure_info_3_3_b8                     : 8U;
      
      uint32        BOOT_Failure_info_3_4_b8                     : 8U;
      
      uint32        BOOT_Failure_info_4_1_b8                     : 8U;
      
      uint32        BOOT_Failure_info_4_2_b8                     : 8U;
      
      uint32        BOOT_Failure_info_4_3_b8                     : 8U;
      
      uint32        BOOT_Failure_info_4_4_b8                     : 8U;
      
      uint32        BOOT_Failure_info_5_1_b8                     : 8U;
      
      uint32        BOOT_Failure_info_5_2_b8                     : 8U;
      
      uint32        BOOT_Failure_info_5_3_b8                     : 8U;
      
      uint32        BOOT_Failure_info_5_4_b8                     : 8U;
      
      uint32        BOOT_Failure_info_6_1_b8                     : 8U;
      
      uint32        BOOT_Failure_info_6_2_b8                     : 8U;
      
      uint32        BOOT_Failure_info_6_3_b8                     : 8U;
      
      uint32        BOOT_Failure_info_6_4_b8                     : 8U;
      
      uint32        BOOT_Failure_info_7_1_b8                     : 8U;
      
      uint32        BOOT_Failure_info_7_2_b8                     : 8U;
      
      uint32        BOOT_Failure_info_7_3_b8                     : 8U;
      
      uint32        BOOT_Failure_info_7_4_b8                     : 8U;
      
   #else
      uint32        BOOT_Zero_byte_b8                            : 8U;
      
      uint32        BootMsg_Protocol_Version_b8                  : 8U;
      
      uint32        Reserved_1_b16                               : 16U;
      
      uint32        BOOT_Test_results_b16                        : 16U;
      
      uint32        BOOT_Board_project_code_b8                   : 8U;
      
      uint32        BOOT_Board_revision_b8                       : 8U;
      
      uint32        BOOT_Ver_b32                                 : 32U;
      
      uint32        BOOT_Application_ver_b32                     : 32U;
      
      uint32        BOOT_EyeQ_Type_b32                           : 32U;
      
      uint32        BOOT_EyeQ_ID_b32                             : 32U;
      
      uint32        BOOT_DDR_manufacturer_code_b8                : 8U;
      
      uint32        BOOT_DDR_Size_b24                            : 24U;
      
      uint32        BOOT_Flash_Man_Code_b8                       : 8U;
      
      uint32        BOOT_Flash_Size_b24                          : 24U;
      
      sint32        BOOT_CPU_Temperature_sb8                     : 8;
      
      sint32        BOOT_VMP_Temperature_sb8                     : 8;
      
      uint32        BOOT_LPDDR4_Temperature_Status_b8            : 8U;
      
      uint32        Reserved_2_b8                                : 8U;
      
      uint32        BOOT_Flash2_Man_Code_b8                      : 8U;
      
      uint32        BOOT_Flash_2_Size_b24                        : 24U;
      
      uint32        Boot_Stage_b8                                : 8U;
      
      uint32        BOOT_Failure_info_0_b24                      : 24U;
      
      uint32        BOOT_Failure_info_1_b32                      : 32U;
      
      uint32        BOOT_Failure_info_2_b32                      : 32U;
      
      uint32        BOOT_Failure_info_3_b32                      : 32U;
      
      uint32        BOOT_Failure_info_4_b32                      : 32U;
      
      uint32        BOOT_Failure_info_5_b32                      : 32U;
      
      uint32        BOOT_Failure_info_6_b32                      : 32U;
      
      uint32        BOOT_Failure_info_7_b32                      : 32U;
      
   #endif
} EYEQMSG_BOOTDIAGMSG_Params_t;


/*****************************************************************************
                  Exported function prototypes
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_BOOTDIAGMSG_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_BOOTDIAGMSG_Params_t * pCore_Boot_Diagnostics_Message_protocol - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_Boot_Diagnostics_Message_protocol message 
*    Core_Boot_Diagnostics_Message_protocol message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_Boot_Diagnostics_Message_protocol message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_BOOTDIAGMSG_ParamsApp_MsgDataStruct( EYEQMSG_BOOTDIAGMSG_Params_t * pCore_Boot_Diagnostics_Message_protocol );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BOOT_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pBOOT_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BOOT_Zero_byte
*    BOOT_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BOOT_Zero_byte signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BOOT_Zero_byte( uint8 * pBOOT_Zero_byte );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BootMsg_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pBootMsg_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BootMsg_Protocol_Version
*    BootMsg_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BootMsg_Protocol_Version signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BootMsg_Protocol_Version( uint8 * pBootMsg_Protocol_Version );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_Reserved_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pReserved_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1
*    Reserved_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1 signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_Reserved_1( uint16 * pReserved_1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BOOT_Test_results
*
* FUNCTION ARGUMENTS:
*    BOOTDIAGMSGBOOTTestResults * pBOOT_Test_results - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BOOT_Test_results
*    BOOT_Test_results returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BOOT_Test_results signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BOOT_Test_results( BOOTDIAGMSGBOOTTestResults * pBOOT_Test_results );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BOOT_Board_project_code
*
* FUNCTION ARGUMENTS:
*    uint8 * pBOOT_Board_project_code - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BOOT_Board_project_code
*    BOOT_Board_project_code returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BOOT_Board_project_code signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BOOT_Board_project_code( uint8 * pBOOT_Board_project_code );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BOOT_Board_revision
*
* FUNCTION ARGUMENTS:
*    uint8 * pBOOT_Board_revision - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BOOT_Board_revision
*    BOOT_Board_revision returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BOOT_Board_revision signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BOOT_Board_revision( uint8 * pBOOT_Board_revision );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BOOT_Ver
*
* FUNCTION ARGUMENTS:
*    uint32 * pBOOT_Ver - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BOOT_Ver
*    BOOT_Ver returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BOOT_Ver signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BOOT_Ver( uint32 * pBOOT_Ver );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BOOT_Application_ver
*
* FUNCTION ARGUMENTS:
*    uint32 * pBOOT_Application_ver - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BOOT_Application_ver
*    BOOT_Application_ver returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BOOT_Application_ver signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BOOT_Application_ver( uint32 * pBOOT_Application_ver );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BOOT_EyeQ_Type
*
* FUNCTION ARGUMENTS:
*    uint32 * pBOOT_EyeQ_Type - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BOOT_EyeQ_Type
*    BOOT_EyeQ_Type returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BOOT_EyeQ_Type signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BOOT_EyeQ_Type( uint32 * pBOOT_EyeQ_Type );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BOOT_EyeQ_ID
*
* FUNCTION ARGUMENTS:
*    uint32 * pBOOT_EyeQ_ID - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BOOT_EyeQ_ID
*    BOOT_EyeQ_ID returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BOOT_EyeQ_ID signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BOOT_EyeQ_ID( uint32 * pBOOT_EyeQ_ID );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BOOT_DDR_manufacturer_code
*
* FUNCTION ARGUMENTS:
*    uint8 * pBOOT_DDR_manufacturer_code - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BOOT_DDR_manufacturer_code
*    BOOT_DDR_manufacturer_code returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BOOT_DDR_manufacturer_code signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BOOT_DDR_manufacturer_code( uint8 * pBOOT_DDR_manufacturer_code );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BOOT_DDR_Size
*
* FUNCTION ARGUMENTS:
*    uint32 * pBOOT_DDR_Size - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BOOT_DDR_Size
*    BOOT_DDR_Size returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BOOT_DDR_Size signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BOOT_DDR_Size( uint32 * pBOOT_DDR_Size );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BOOT_Flash_Man_Code
*
* FUNCTION ARGUMENTS:
*    uint8 * pBOOT_Flash_Man_Code - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BOOT_Flash_Man_Code
*    BOOT_Flash_Man_Code returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BOOT_Flash_Man_Code signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BOOT_Flash_Man_Code( uint8 * pBOOT_Flash_Man_Code );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BOOT_Flash_Size
*
* FUNCTION ARGUMENTS:
*    uint32 * pBOOT_Flash_Size - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BOOT_Flash_Size
*    BOOT_Flash_Size returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BOOT_Flash_Size signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BOOT_Flash_Size( uint32 * pBOOT_Flash_Size );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BOOT_CPU_Temperature
*
* FUNCTION ARGUMENTS:
*    sint8 * pBOOT_CPU_Temperature - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BOOT_CPU_Temperature
*    BOOT_CPU_Temperature returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BOOT_CPU_Temperature signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BOOT_CPU_Temperature( sint8 * pBOOT_CPU_Temperature );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BOOT_VMP_Temperature
*
* FUNCTION ARGUMENTS:
*    sint8 * pBOOT_VMP_Temperature - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BOOT_VMP_Temperature
*    BOOT_VMP_Temperature returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BOOT_VMP_Temperature signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BOOT_VMP_Temperature( sint8 * pBOOT_VMP_Temperature );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BOOT_LPDDR4_Temperature_Status
*
* FUNCTION ARGUMENTS:
*    BOOTDIAGMSGBOOTLPDDR4TemperatureStatus * pBOOT_LPDDR4_Temperature_Status - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BOOT_LPDDR4_Temperature_Status
*    BOOT_LPDDR4_Temperature_Status returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BOOT_LPDDR4_Temperature_Status signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BOOT_LPDDR4_Temperature_Status( BOOTDIAGMSGBOOTLPDDR4TemperatureStatus * pBOOT_LPDDR4_Temperature_Status );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_Reserved_2
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_2
*    Reserved_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_2 signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_Reserved_2( uint8 * pReserved_2 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BOOT_Flash2_Man_Code
*
* FUNCTION ARGUMENTS:
*    uint8 * pBOOT_Flash2_Man_Code - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BOOT_Flash2_Man_Code
*    BOOT_Flash2_Man_Code returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BOOT_Flash2_Man_Code signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BOOT_Flash2_Man_Code( uint8 * pBOOT_Flash2_Man_Code );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BOOT_Flash_2_Size
*
* FUNCTION ARGUMENTS:
*    uint32 * pBOOT_Flash_2_Size - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BOOT_Flash_2_Size
*    BOOT_Flash_2_Size returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BOOT_Flash_2_Size signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BOOT_Flash_2_Size( uint32 * pBOOT_Flash_2_Size );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_Boot_Stage
*
* FUNCTION ARGUMENTS:
*    BOOTDIAGMSGBootStage * pBoot_Stage - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Boot_Stage
*    Boot_Stage returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Boot_Stage signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_Boot_Stage( BOOTDIAGMSGBootStage * pBoot_Stage );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BOOT_Failure_info_0
*
* FUNCTION ARGUMENTS:
*    uint32 * pBOOT_Failure_info_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BOOT_Failure_info_0
*    BOOT_Failure_info_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BOOT_Failure_info_0 signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BOOT_Failure_info_0( uint32 * pBOOT_Failure_info_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BOOT_Failure_info_1
*
* FUNCTION ARGUMENTS:
*    uint32 * pBOOT_Failure_info_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BOOT_Failure_info_1
*    BOOT_Failure_info_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BOOT_Failure_info_1 signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BOOT_Failure_info_1( uint32 * pBOOT_Failure_info_1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BOOT_Failure_info_2
*
* FUNCTION ARGUMENTS:
*    uint32 * pBOOT_Failure_info_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BOOT_Failure_info_2
*    BOOT_Failure_info_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BOOT_Failure_info_2 signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BOOT_Failure_info_2( uint32 * pBOOT_Failure_info_2 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BOOT_Failure_info_3
*
* FUNCTION ARGUMENTS:
*    uint32 * pBOOT_Failure_info_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BOOT_Failure_info_3
*    BOOT_Failure_info_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BOOT_Failure_info_3 signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BOOT_Failure_info_3( uint32 * pBOOT_Failure_info_3 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BOOT_Failure_info_4
*
* FUNCTION ARGUMENTS:
*    uint32 * pBOOT_Failure_info_4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BOOT_Failure_info_4
*    BOOT_Failure_info_4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BOOT_Failure_info_4 signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BOOT_Failure_info_4( uint32 * pBOOT_Failure_info_4 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BOOT_Failure_info_5
*
* FUNCTION ARGUMENTS:
*    uint32 * pBOOT_Failure_info_5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BOOT_Failure_info_5
*    BOOT_Failure_info_5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BOOT_Failure_info_5 signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BOOT_Failure_info_5( uint32 * pBOOT_Failure_info_5 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BOOT_Failure_info_6
*
* FUNCTION ARGUMENTS:
*    uint32 * pBOOT_Failure_info_6 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BOOT_Failure_info_6
*    BOOT_Failure_info_6 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BOOT_Failure_info_6 signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BOOT_Failure_info_6( uint32 * pBOOT_Failure_info_6 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_BOOTDIAGMSG_BOOT_Failure_info_7
*
* FUNCTION ARGUMENTS:
*    uint32 * pBOOT_Failure_info_7 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of BOOT_Failure_info_7
*    BOOT_Failure_info_7 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns BOOT_Failure_info_7 signal value of Core_Boot_Diagnostics_Message_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_BOOTDIAGMSG_BOOT_Failure_info_7( uint32 * pBOOT_Failure_info_7 );
/*****************************************************************************
                  Exported object declarations
*****************************************************************************/
extern EYEQMSG_BOOTDIAGMSG_Params_t   EYEQMSG_BOOTDIAGMSG_Params_s;
extern EYEQMSG_BOOTDIAGMSG_Params_t   EYEQMSG_BOOTDIAGMSG_ParamsApp_s;
/****************************************************************************/
#endif /* _EYEQMSG_BOOTDIAGMSGPROCESS_H_ */


