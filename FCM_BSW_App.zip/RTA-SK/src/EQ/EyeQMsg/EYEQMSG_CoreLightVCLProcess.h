#ifndef _EYEQMSG_CORELIGHTVCLPROCESS_H_
#define _EYEQMSG_CORELIGHTVCLPROCESS_H_

/*****************************************************************************
                  Included header files
*****************************************************************************/
#include <Std_Types.h>

/*****************************************************************************
                  Include files
*****************************************************************************/
/*****************************************************************************
                  Exported symbolic constants
*****************************************************************************/
#define C_EYEQMSG_CORELIGHTVCLvH_VIRTUAL_OBJECT_INDEX_RMAX ( 15U )

/* Datagram message ID */
#define C_EYEQMSG_CORELIGHTVCLvH_MSG_ID                       ( 0x7DU )
#define C_EYEQMSG_CORELIGHTVCLvO_MSG_ID                       ( 0x7DU )
#define C_EYEQMSG_CORELIGHTVCL_MSG_ID                         ( 0x7DU )

/* Datagram message lengths */
#define C_EYEQMSG_CORELIGHTVCLvH_MSG_LEN                      ( sizeof(EYEQMSG_CORELIGHTVCLvH_Params_t) )
#define C_EYEQMSG_CORELIGHTVCLvO_MSG_LEN                      ( sizeof(EYEQMSG_CORELIGHTVCLvO_Params_t) )
#define C_EYEQMSG_CORELIGHTVCL_MSG_LEN                        ( sizeof(EYEQMSG_CORELIGHTVCL_Params_t) )

/* Protocol ENUMs */

/* MCU output messages */

/* Virtual_HEADER_msg_Core_Light_Scene_VCL_protocol Enums */
/* LSV_Brightness_Score_b32 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_BRIGHTNESS_SCORE_RMIN    ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_BRIGHTNESS_SCORE_RMAX    ( 2000U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_BRIGHTNESS_SCORE_NUMR    ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_BRIGHTNESS_SCORE_DEMNR   ( 100U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_BRIGHTNESS_SCORE_OFFSET  ( 0U )

/* LSV_Vehicles_Count_b4 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_VEHICLES_COUNT_RMIN      ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_VEHICLES_COUNT_RMAX      ( 15U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_VEHICLES_COUNT_NUMR      ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_VEHICLES_COUNT_DEMNR     ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_VEHICLES_COUNT_OFFSET    ( 0U )

/* LSV_HLB_Reason_b28 signal Enums */
typedef uint32 CORELIGHTVCLvHLSVHLBReason;
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_HLB_REASON__BIT_0_TAIL_LIGHT ( CORELIGHTVCLvHLSVHLBReason ) ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_HLB_REASON__BIT_1_ONCOMING ( CORELIGHTVCLvHLSVHLBReason ) ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_HLB_REASON__BIT_2_ONCOMING_GRACE ( CORELIGHTVCLvHLSVHLBReason ) ( 2U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_HLB_REASON__BIT_3_TAIL_LIGHT_GRACE ( CORELIGHTVCLvHLSVHLBReason ) ( 3U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_HLB_REASON__BIT_4_LOW_SPEED ( CORELIGHTVCLvHLSVHLBReason ) ( 4U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_HLB_REASON__BIT_5_STREET_LIGHTS ( CORELIGHTVCLvHLSVHLBReason ) ( 5U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_HLB_REASON__BIT_6_SL_SCENE_GRACE ( CORELIGHTVCLvHLSVHLBReason ) ( 6U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_HLB_REASON__BIT_7_BRIGHT_SCENE ( CORELIGHTVCLvHLSVHLBReason ) ( 7U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_HLB_REASON__BIT_8_OBVIOUSLY_BRIGHT_SCENE ( CORELIGHTVCLvHLSVHLBReason ) ( 8U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_HLB_REASON__BIT_9_LIT_NIGHT ( CORELIGHTVCLvHLSVHLBReason ) ( 9U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_HLB_REASON__BIT_10_LIT_NIGHT_US ( CORELIGHTVCLvHLSVHLBReason ) ( 10U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_HLB_REASON__BIT_11_LIT_NIGHT_ECE ( CORELIGHTVCLvHLSVHLBReason ) ( 11U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_HLB_REASON__BIT_12_IN_VERY_SHARPE_CURVE ( CORELIGHTVCLvHLSVHLBReason ) ( 12U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_HLB_REASON__BIT_13_IN_CURVE ( CORELIGHTVCLvHLSVHLBReason ) ( 13U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_HLB_REASON__BIT_14_IN_BLINKING_TRAFFICLIGHT_SCENE ( CORELIGHTVCLvHLSVHLBReason ) ( 14U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_HLB_REASON__BIT_15_APPROACHING_JUNCTION ( CORELIGHTVCLvHLSVHLBReason ) ( 15U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_HLB_REASON__BIT_16_APPROACHING_ROUNDABOUT ( CORELIGHTVCLvHLSVHLBReason ) ( 16U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_HLB_REASON__BIT_17_IN_ROUNDABOUT ( CORELIGHTVCLvHLSVHLBReason ) ( 17U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_HLB_REASON__BIT_18_TUNNEL ( CORELIGHTVCLvHLSVHLBReason ) ( 18U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_HLB_REASON__BIT_19_NOISY_SCENE ( CORELIGHTVCLvHLSVHLBReason ) ( 19U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_HLB_REASON__BIT_20_LIGHT_CONE ( CORELIGHTVCLvHLSVHLBReason ) ( 20U )

/* LSV_HLB_Reason_b28 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_HLB_REASON_RMIN          ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_HLB_REASON_RMAX          ( 2097151U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_HLB_REASON_NUMR          ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_HLB_REASON_DEMNR         ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_HLB_REASON_OFFSET        ( 0U )

/* LSV_HLB_Sensitivity_Mode_b1 signal Enums */
typedef boolean CORELIGHTVCLvHLSVHLBSensitivityMode;
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_HLB_SENSITIVITY_MODE_FALSE ( CORELIGHTVCLvHLSVHLBSensitivityMode ) ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_HLB_SENSITIVITY_MODE_TRUE ( CORELIGHTVCLvHLSVHLBSensitivityMode ) ( 1U )

/* LSV_HLB_Sensitivity_Mode_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_HLB_SENSITIVITY_MODE_RMIN ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_HLB_SENSITIVITY_MODE_RMAX ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_HLB_SENSITIVITY_MODE_NUMR ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_HLB_SENSITIVITY_MODE_DEMNR ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_HLB_SENSITIVITY_MODE_OFFSET ( 0U )

/* LSV_HLB_Decision_b2 signal Enums */
typedef uint8 CORELIGHTVCLvHLSVHLBDecision;
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_HLB_DECISION_UNFILLED    ( CORELIGHTVCLvHLSVHLBDecision ) ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_HLB_DECISION_HIGH        ( CORELIGHTVCLvHLSVHLBDecision ) ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_HLB_DECISION_LOW         ( CORELIGHTVCLvHLSVHLBDecision ) ( 2U )

/* LSV_HLB_Decision_b2 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_HLB_DECISION_RMIN        ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_HLB_DECISION_RMAX        ( 2U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_HLB_DECISION_NUMR        ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_HLB_DECISION_DEMNR       ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_HLB_DECISION_OFFSET      ( 0U )

/* LSV_Inactive_Reason_b3 signal Enums */
typedef uint8 CORELIGHTVCLvHLSVInactiveReason;
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_INACTIVE_REASON_INVALID_REASON ( CORELIGHTVCLvHLSVInactiveReason ) ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_INACTIVE_REASON_OBVIOUSLY_BRIGHT ( CORELIGHTVCLvHLSVInactiveReason ) ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_INACTIVE_REASON_LOW_DETECTION_RATE ( CORELIGHTVCLvHLSVInactiveReason ) ( 2U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_INACTIVE_REASON_OVER_FLOW ( CORELIGHTVCLvHLSVInactiveReason ) ( 3U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_INACTIVE_REASON_IN_GRACE ( CORELIGHTVCLvHLSVInactiveReason ) ( 4U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_INACTIVE_REASON_DEACTIVATED ( CORELIGHTVCLvHLSVInactiveReason ) ( 5U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_INACTIVE_REASON_DUSK_DELAY ( CORELIGHTVCLvHLSVInactiveReason ) ( 6U )

/* LSV_Inactive_Reason_b3 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_INACTIVE_REASON_RMIN     ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_INACTIVE_REASON_RMAX     ( 6U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_INACTIVE_REASON_NUMR     ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_INACTIVE_REASON_DEMNR    ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_INACTIVE_REASON_OFFSET   ( 0U )

/* LSV_Running_Mode_b2 signal Enums */
typedef uint8 CORELIGHTVCLvHLSVRunningMode;
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_RUNNING_MODE_INVALID_MODE ( CORELIGHTVCLvHLSVRunningMode ) ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_RUNNING_MODE_LS_OFF      ( CORELIGHTVCLvHLSVRunningMode ) ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_RUNNING_MODE_LS_INACTIVE ( CORELIGHTVCLvHLSVRunningMode ) ( 2U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_RUNNING_MODE_LS_FULL     ( CORELIGHTVCLvHLSVRunningMode ) ( 3U )

/* LSV_Running_Mode_b2 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_RUNNING_MODE_RMIN        ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_RUNNING_MODE_RMAX        ( 3U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_RUNNING_MODE_NUMR        ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_RUNNING_MODE_DEMNR       ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_RUNNING_MODE_OFFSET      ( 0U )

/* LSV_Sync_ID_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_SYNC_ID_RMIN             ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_SYNC_ID_RMAX             ( 255U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_SYNC_ID_NUMR             ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_SYNC_ID_DEMNR            ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_SYNC_ID_OFFSET           ( 0U )

/* LSV_Protocol_Version_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_PROTOCOL_VERSION_RMIN    ( 10U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_PROTOCOL_VERSION_RMAX    ( 10U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_PROTOCOL_VERSION_NUMR    ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_PROTOCOL_VERSION_DEMNR   ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_PROTOCOL_VERSION_OFFSET  ( 0U )

/* LSV_Zero_byte_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_ZERO_BYTE_RMIN           ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_ZERO_BYTE_RMAX           ( 255U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_ZERO_BYTE_NUMR           ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_ZERO_BYTE_DEMNR          ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvH_LSV_ZERO_BYTE_OFFSET         ( 0U )


/* Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol Enums */
/* Reserved_10_0_b19 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTVCLvO_RESERVED_10_0_RMIN           ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvO_RESERVED_10_0_RMAX           ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvO_RESERVED_10_0_NUMR           ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvO_RESERVED_10_0_DEMNR          ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvO_RESERVED_10_0_OFFSET         ( 0U )

/* LSV_Facade_Left_Angle_0_b13 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_FACADE_LEFT_ANGLE_0_RMIN ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_FACADE_LEFT_ANGLE_0_RMAX ( 8000U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_FACADE_LEFT_ANGLE_0_NUMR ( 1 )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_FACADE_LEFT_ANGLE_0_DEMNR ( 100 )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_FACADE_LEFT_ANGLE_0_OFFSET ( -40 )

/* Reserved_9_0_b7 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTVCLvO_RESERVED_9_0_RMIN            ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvO_RESERVED_9_0_RMAX            ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvO_RESERVED_9_0_NUMR            ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvO_RESERVED_9_0_DEMNR           ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvO_RESERVED_9_0_OFFSET          ( 0U )

/* LSV_Facade_Right_Angle_0_b13 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_FACADE_RIGHT_ANGLE_0_RMIN ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_FACADE_RIGHT_ANGLE_0_RMAX ( 8000U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_FACADE_RIGHT_ANGLE_0_NUMR ( 1 )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_FACADE_RIGHT_ANGLE_0_DEMNR ( 100 )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_FACADE_RIGHT_ANGLE_0_OFFSET ( -40 )

/* LSV_Facade_Top_Angle_0_b12 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_FACADE_TOP_ANGLE_0_RMIN  ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_FACADE_TOP_ANGLE_0_RMAX  ( 2000U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_FACADE_TOP_ANGLE_0_NUMR  ( 1 )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_FACADE_TOP_ANGLE_0_DEMNR ( 100 )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_FACADE_TOP_ANGLE_0_OFFSET ( -10 )

/* Reserved_8_0_b6 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTVCLvO_RESERVED_8_0_RMIN            ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvO_RESERVED_8_0_RMAX            ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvO_RESERVED_8_0_NUMR            ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvO_RESERVED_8_0_DEMNR           ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvO_RESERVED_8_0_OFFSET          ( 0U )

/* LSV_Atten_Cent_Angle_Lat_0_b13 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_ATTEN_CENT_ANGLE_LAT_0_RMIN ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_ATTEN_CENT_ANGLE_LAT_0_RMAX ( 8000U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_ATTEN_CENT_ANGLE_LAT_0_NUMR ( 1 )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_ATTEN_CENT_ANGLE_LAT_0_DEMNR ( 100 )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_ATTEN_CENT_ANGLE_LAT_0_OFFSET ( -40 )

/* LSV_Atten_Cent_Angle_H_0_b13 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_ATTEN_CENT_ANGLE_H_0_RMIN ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_ATTEN_CENT_ANGLE_H_0_RMAX ( 8000U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_ATTEN_CENT_ANGLE_H_0_NUMR ( 1 )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_ATTEN_CENT_ANGLE_H_0_DEMNR ( 100 )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_ATTEN_CENT_ANGLE_H_0_OFFSET ( -40 )

/* Reserved_7_0_b10 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTVCLvO_RESERVED_7_0_RMIN            ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvO_RESERVED_7_0_RMAX            ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvO_RESERVED_7_0_NUMR            ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvO_RESERVED_7_0_DEMNR           ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvO_RESERVED_7_0_OFFSET          ( 0U )

/* LSV_Angular_Velocity_Left_0_b11 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_ANGULAR_VELOCITY_LEFT_0_RMIN ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_ANGULAR_VELOCITY_LEFT_0_RMAX ( 2047U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_ANGULAR_VELOCITY_LEFT_0_NUMR ( 1 )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_ANGULAR_VELOCITY_LEFT_0_DEMNR ( 8 )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_ANGULAR_VELOCITY_LEFT_0_OFFSET ( -128 )

/* LSV_Angular_Velocity_Right_0_b11 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_ANGULAR_VELOCITY_RIGHT_0_RMIN ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_ANGULAR_VELOCITY_RIGHT_0_RMAX ( 2047U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_ANGULAR_VELOCITY_RIGHT_0_NUMR ( 1 )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_ANGULAR_VELOCITY_RIGHT_0_DEMNR ( 8 )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_ANGULAR_VELOCITY_RIGHT_0_OFFSET ( -128 )

/* Reserved_6_0_b6 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTVCLvO_RESERVED_6_0_RMIN            ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvO_RESERVED_6_0_RMAX            ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvO_RESERVED_6_0_NUMR            ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvO_RESERVED_6_0_DEMNR           ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvO_RESERVED_6_0_OFFSET          ( 0U )

/* LSV_Left_Angle_0_b13 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_LEFT_ANGLE_0_RMIN        ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_LEFT_ANGLE_0_RMAX        ( 8000U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_LEFT_ANGLE_0_NUMR        ( 1 )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_LEFT_ANGLE_0_DEMNR       ( 100 )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_LEFT_ANGLE_0_OFFSET      ( -40 )

/* LSV_Right_Angle_0_b13 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_RIGHT_ANGLE_0_RMIN       ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_RIGHT_ANGLE_0_RMAX       ( 8000U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_RIGHT_ANGLE_0_NUMR       ( 1 )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_RIGHT_ANGLE_0_DEMNR      ( 100 )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_RIGHT_ANGLE_0_OFFSET     ( -40 )

/* Reserved_5_0_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTVCLvO_RESERVED_5_0_RMIN            ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvO_RESERVED_5_0_RMAX            ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvO_RESERVED_5_0_NUMR            ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvO_RESERVED_5_0_DEMNR           ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvO_RESERVED_5_0_OFFSET          ( 0U )

/* LSV_Bottom_Angle_0_b12 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_BOTTOM_ANGLE_0_RMIN      ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_BOTTOM_ANGLE_0_RMAX      ( 2000U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_BOTTOM_ANGLE_0_NUMR      ( 1 )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_BOTTOM_ANGLE_0_DEMNR     ( 100 )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_BOTTOM_ANGLE_0_OFFSET    ( -10 )

/* LSV_Top_Angle_0_b12 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_TOP_ANGLE_0_RMIN         ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_TOP_ANGLE_0_RMAX         ( 2000U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_TOP_ANGLE_0_NUMR         ( 1 )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_TOP_ANGLE_0_DEMNR        ( 100 )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_TOP_ANGLE_0_OFFSET       ( -10 )

/* Reserved_4_0_b2 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTVCLvO_RESERVED_4_0_RMIN            ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvO_RESERVED_4_0_RMAX            ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvO_RESERVED_4_0_NUMR            ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvO_RESERVED_4_0_DEMNR           ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvO_RESERVED_4_0_OFFSET          ( 0U )

/* LSV_CL_Distance_Left_0_b11 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_CL_DISTANCE_LEFT_0_RMIN  ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_CL_DISTANCE_LEFT_0_RMAX  ( 1000U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_CL_DISTANCE_LEFT_0_NUMR  ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_CL_DISTANCE_LEFT_0_DEMNR ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_CL_DISTANCE_LEFT_0_OFFSET ( 0U )

/* LSV_CL_Distance_Right_0_b11 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_CL_DISTANCE_RIGHT_0_RMIN ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_CL_DISTANCE_RIGHT_0_RMAX ( 1000U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_CL_DISTANCE_RIGHT_0_NUMR ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_CL_DISTANCE_RIGHT_0_DEMNR ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_CL_DISTANCE_RIGHT_0_OFFSET ( 0U )

/* LSV_Distance_STD_0_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_DISTANCE_STD_0_RMIN      ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_DISTANCE_STD_0_RMAX      ( 200U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_DISTANCE_STD_0_NUMR      ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_DISTANCE_STD_0_DEMNR     ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_DISTANCE_STD_0_OFFSET    ( 0U )

/* Reserved_3_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTVCLvO_RESERVED_3_0_RMIN            ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvO_RESERVED_3_0_RMAX            ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvO_RESERVED_3_0_NUMR            ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvO_RESERVED_3_0_DEMNR           ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvO_RESERVED_3_0_OFFSET          ( 0U )

/* LSV_Distance_0_b11 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_DISTANCE_0_RMIN          ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_DISTANCE_0_RMAX          ( 1000U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_DISTANCE_0_NUMR          ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_DISTANCE_0_DEMNR         ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_DISTANCE_0_OFFSET        ( 0U )

/* LSV_Brightness_0_b20 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_BRIGHTNESS_0_RMIN        ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_BRIGHTNESS_0_RMAX        ( 900000U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_BRIGHTNESS_0_NUMR        ( 10U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_BRIGHTNESS_0_DEMNR       ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_BRIGHTNESS_0_OFFSET      ( 0U )

/* Reserved_2_0_b6 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTVCLvO_RESERVED_2_0_RMIN            ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvO_RESERVED_2_0_RMAX            ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvO_RESERVED_2_0_NUMR            ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvO_RESERVED_2_0_DEMNR           ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvO_RESERVED_2_0_OFFSET          ( 0U )

/* LSV_VD_ID_0_b9 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_VD_ID_0_RMIN             ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_VD_ID_0_RMAX             ( 255U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_VD_ID_0_NUMR             ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_VD_ID_0_DEMNR            ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_VD_ID_0_OFFSET           ( 0U )

/* LSV_Is_New_0_b1 signal Enums */
typedef boolean CORELIGHTVCLvOLSVIsNew0;
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_IS_NEW_0_FALSE           ( CORELIGHTVCLvOLSVIsNew0 ) ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_IS_NEW_0_TRUE            ( CORELIGHTVCLvOLSVIsNew0 ) ( 1U )

/* LSV_Is_New_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_IS_NEW_0_RMIN            ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_IS_NEW_0_RMAX            ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_IS_NEW_0_NUMR            ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_IS_NEW_0_DEMNR           ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_IS_NEW_0_OFFSET          ( 0U )

/* LSV_Confidence_0_b7 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_CONFIDENCE_0_RMIN        ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_CONFIDENCE_0_RMAX        ( 100U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_CONFIDENCE_0_NUMR        ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_CONFIDENCE_0_DEMNR       ( 100U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_CONFIDENCE_0_OFFSET      ( 0U )

/* LSV_Width_STD_0_b9 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_WIDTH_STD_0_RMIN         ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_WIDTH_STD_0_RMAX         ( 60U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_WIDTH_STD_0_NUMR         ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_WIDTH_STD_0_DEMNR        ( 20U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_WIDTH_STD_0_OFFSET       ( 0U )

/* Reserved_1_0_b3 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTVCLvO_RESERVED_1_0_RMIN            ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvO_RESERVED_1_0_RMAX            ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvO_RESERVED_1_0_NUMR            ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvO_RESERVED_1_0_DEMNR           ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvO_RESERVED_1_0_OFFSET          ( 0U )

/* LSV_Consecutive_Detection_0_b7 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_CONSECUTIVE_DETECTION_0_RMIN ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_CONSECUTIVE_DETECTION_0_RMAX ( 105U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_CONSECUTIVE_DETECTION_0_NUMR ( 1 )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_CONSECUTIVE_DETECTION_0_DEMNR ( 1 )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_CONSECUTIVE_DETECTION_0_OFFSET ( -5 )

/* LSV_CL_Sub_Type_0_b4 signal Enums */
typedef uint8 CORELIGHTVCLvOLSVCLSubType0;
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_CL_SUB_TYPE_0_INVALID    ( CORELIGHTVCLvOLSVCLSubType0 ) ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_CL_SUB_TYPE_0_ONCOMING   ( CORELIGHTVCLvOLSVCLSubType0 ) ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_CL_SUB_TYPE_0_TAILLIGHT  ( CORELIGHTVCLvOLSVCLSubType0 ) ( 2U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_CL_SUB_TYPE_0_LEFT_ONCOMING ( CORELIGHTVCLvOLSVCLSubType0 ) ( 3U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_CL_SUB_TYPE_0_RIGHT_ONCOMING ( CORELIGHTVCLvOLSVCLSubType0 ) ( 4U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_CL_SUB_TYPE_0_LEFT_AND_RIGHT_ONCOMING ( CORELIGHTVCLvOLSVCLSubType0 ) ( 5U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_CL_SUB_TYPE_0_LEFT_AND_RIGHT_TAILLIGHT ( CORELIGHTVCLvOLSVCLSubType0 ) ( 6U )

/* LSV_CL_Sub_Type_0_b4 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_CL_SUB_TYPE_0_RMIN       ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_CL_SUB_TYPE_0_RMAX       ( 6U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_CL_SUB_TYPE_0_NUMR       ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_CL_SUB_TYPE_0_DEMNR      ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_CL_SUB_TYPE_0_OFFSET     ( 0U )

/* LSV_Sub_Type_0_b6 signal Enums */
typedef uint8 CORELIGHTVCLvOLSVSubType0;
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_SUB_TYPE_0__000001_OVERTAKING ( CORELIGHTVCLvOLSVSubType0 ) ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_SUB_TYPE_0__000010_STATIONARY_CROSSING ( CORELIGHTVCLvOLSVSubType0 ) ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_SUB_TYPE_0__000100_EMERGENCY_VEHICLE ( CORELIGHTVCLvOLSVSubType0 ) ( 2U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_SUB_TYPE_0__001000_TRUCK ( CORELIGHTVCLvOLSVSubType0 ) ( 3U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_SUB_TYPE_0__010000_BIKE  ( CORELIGHTVCLvOLSVSubType0 ) ( 4U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_SUB_TYPE_0__100000_SINGLE_BAR ( CORELIGHTVCLvOLSVSubType0 ) ( 5U )

/* LSV_Sub_Type_0_b6 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_SUB_TYPE_0_RMIN          ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_SUB_TYPE_0_RMAX          ( 63U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_SUB_TYPE_0_NUMR          ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_SUB_TYPE_0_DEMNR         ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_SUB_TYPE_0_OFFSET        ( 0U )

/* LSV_Type_0_b4 signal Enums */
typedef uint8 CORELIGHTVCLvOLSVType0;
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_TYPE_0_INVALID           ( CORELIGHTVCLvOLSVType0 ) ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_TYPE_0_ONCOMING          ( CORELIGHTVCLvOLSVType0 ) ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_TYPE_0_COUPLE_ONCOMING   ( CORELIGHTVCLvOLSVType0 ) ( 2U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_TYPE_0_TAILLIGHT         ( CORELIGHTVCLvOLSVType0 ) ( 3U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_TYPE_0_COUPLE_TAILLIGHT  ( CORELIGHTVCLvOLSVType0 ) ( 4U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_TYPE_0_COUPLE_OC_CLEARANCE ( CORELIGHTVCLvOLSVType0 ) ( 5U )

/* LSV_Type_0_b4 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_TYPE_0_RMIN              ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_TYPE_0_RMAX              ( 6U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_TYPE_0_NUMR              ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_TYPE_0_DEMNR             ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_TYPE_0_OFFSET            ( 0U )

/* LSV_ID_0_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_ID_0_RMIN                ( 0U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_ID_0_RMAX                ( 255U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_ID_0_NUMR                ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_ID_0_DEMNR               ( 1U )
#define C_EYEQMSG_CORELIGHTVCLvO_LSV_ID_0_OFFSET              ( 0U )


/*****************************************************************************
                  Exported function-like macros
*****************************************************************************/
/*****************************************************************************
                  Exported defined macros
*****************************************************************************/
/*****************************************************************************
                  Exported types, enums definitions
*****************************************************************************/
typedef struct
{
   #if ENABLE_BIG_ENDIAN_FORMAT
      uint32        LSV_Zero_byte_b8                             : 8U;
      
      uint32        LSV_Protocol_Version_b8                      : 8U;
      
      uint32        LSV_Sync_ID_b8                               : 8U;
      
      uint32        unused1_b6                                   : 6;
      uint32        LSV_Running_Mode_b2                          : 2U;
      
      uint32        LSV_Inactive_Reason_b3                       : 3U;
      
      uint32        LSV_HLB_Decision_b2                          : 2U;
      
      uint32        LSV_HLB_Sensitivity_Mode_b1                  : 1U;
      
      uint32        LSV_HLB_Reason_1_b8                          : 8U;
      
      uint32        LSV_HLB_Reason_2_b8                          : 8U;
      
      uint32        LSV_HLB_Reason_3_b8                          : 8U;
      
      uint32        LSV_HLB_Reason_4_b4                          : 4U;
      
      uint32        LSV_Vehicles_Count_b4                        : 4U;
      
      uint32        LSV_Brightness_Score_1_b8                    : 8U;
      
      uint32        LSV_Brightness_Score_2_b8                    : 8U;
      
      uint32        LSV_Brightness_Score_3_b8                    : 8U;
      
      uint32        LSV_Brightness_Score_4_b8                    : 8U;
      
   #else
      uint32        LSV_Zero_byte_b8                             : 8U;
      
      uint32        LSV_Protocol_Version_b8                      : 8U;
      
      uint32        LSV_Sync_ID_b8                               : 8U;
      
      uint32        LSV_Running_Mode_b2                          : 2U;
      
      uint32        LSV_Inactive_Reason_b3                       : 3U;
      
      uint32        LSV_HLB_Decision_b2                          : 2U;
      
      uint32        LSV_HLB_Sensitivity_Mode_b1                  : 1U;
      
      uint32        LSV_HLB_Reason_b28                           : 28U;
      
      uint32        LSV_Vehicles_Count_b4                        : 4U;
      
      uint32        LSV_Brightness_Score_b32                     : 32U;
      
   #endif
} EYEQMSG_CORELIGHTVCLvH_Params_t;


typedef struct
{
   #if ENABLE_BIG_ENDIAN_FORMAT
      uint32        unused1_b96                                  : 96;
      uint32        LSV_ID_0_b8                                  : 8U;
      
      uint32        unused2_b4                                   : 4;
      uint32        LSV_Type_0_b4                                : 4U;
      
      uint32        LSV_Sub_Type_0_1_b4                          : 4U;
      
      uint32        unused3_b2                                   : 2;
      uint32        LSV_Sub_Type_0_2_b2                          : 2U;
      
      uint32        LSV_CL_Sub_Type_0_b4                         : 4U;
      
      uint32        LSV_Consecutive_Detection_0_1_b2             : 2U;
      
      uint32        LSV_Consecutive_Detection_0_2_b5             : 5U;
      
      uint32        Reserved_1_0_b3                              : 3U;
      
      uint32        LSV_Width_STD_0_1_b8                         : 8U;
      
      uint32        unused4_b1                                   : 1;
      uint32        LSV_Width_STD_0_2_b1                         : 1U;
      
      uint32        LSV_Confidence_0_b7                          : 7U;
      
      uint32        LSV_Is_New_0_b1                              : 1U;
      
      uint32        LSV_VD_ID_0_1_b7                             : 7U;
      
      uint32        LSV_VD_ID_0_2_b2                             : 2U;
      
      uint32        Reserved_2_0_b6                              : 6U;
      
      uint32        LSV_Brightness_0_1_b8                        : 8U;
      
      uint32        LSV_Brightness_0_2_b8                        : 8U;
      
      uint32        LSV_Brightness_0_3_b4                        : 4U;
      
      uint32        LSV_Distance_0_1_b4                          : 4U;
      
      uint32        LSV_Distance_0_2_b7                          : 7U;
      
      uint32        Reserved_3_0_b1                              : 1U;
      
      uint32        LSV_Distance_STD_0_b8                        : 8U;
      
      uint32        LSV_CL_Distance_Right_0_1_b8                 : 8U;
      
      uint32        LSV_CL_Distance_Right_0_2_b3                 : 3U;
      
      uint32        LSV_CL_Distance_Left_0_1_b5                  : 5U;
      
      uint32        LSV_CL_Distance_Left_0_2_b6                  : 6U;
      
      uint32        Reserved_4_0_b2                              : 2U;
      
      uint32        LSV_Top_Angle_0_1_b8                         : 8U;
      
      uint32        LSV_Top_Angle_0_2_b4                         : 4U;
      
      uint32        LSV_Bottom_Angle_0_1_b4                      : 4U;
      
      uint32        LSV_Bottom_Angle_0_2_b8                      : 8U;
      
      uint32        Reserved_5_0_b8                              : 8U;
      
      uint32        LSV_Right_Angle_0_1_b8                       : 8U;
      
      uint32        LSV_Right_Angle_0_2_b5                       : 5U;
      
      uint32        LSV_Left_Angle_0_1_b3                        : 3U;
      
      uint32        LSV_Left_Angle_0_2_b8                        : 8U;
      
      uint32        LSV_Left_Angle_0_3_b2                        : 2U;
      
      uint32        Reserved_6_0_b6                              : 6U;
      
      uint32        LSV_Angular_Velocity_Right_0_1_b8            : 8U;
      
      uint32        LSV_Angular_Velocity_Right_0_2_b3            : 3U;
      
      uint32        LSV_Angular_Velocity_Left_0_1_b5             : 5U;
      
      uint32        LSV_Angular_Velocity_Left_0_2_b6             : 6U;
      
      uint32        Reserved_7_0_1_b2                            : 2U;
      
      uint32        Reserved_7_0_2_b8                            : 8U;
      
      uint32        LSV_Atten_Cent_Angle_H_0_1_b8                : 8U;
      
      uint32        LSV_Atten_Cent_Angle_H_0_2_b5                : 5U;
      
      uint32        LSV_Atten_Cent_Angle_Lat_0_1_b3              : 3U;
      
      uint32        LSV_Atten_Cent_Angle_Lat_0_2_b8              : 8U;
      
      uint32        LSV_Atten_Cent_Angle_Lat_0_3_b2              : 2U;
      
      uint32        Reserved_8_0_b6                              : 6U;
      
      uint32        LSV_Facade_Top_Angle_0_1_b8                  : 8U;
      
      uint32        LSV_Facade_Top_Angle_0_2_b4                  : 4U;
      
      uint32        LSV_Facade_Right_Angle_0_1_b4                : 4U;
      
      uint32        LSV_Facade_Right_Angle_0_2_b8                : 8U;
      
      uint32        LSV_Facade_Right_Angle_0_3_b1                : 1U;
      
      uint32        Reserved_9_0_b7                              : 7U;
      
      uint32        LSV_Facade_Left_Angle_0_1_b8                 : 8U;
      
      uint32        LSV_Facade_Left_Angle_0_2_b5                 : 5U;
      
      uint32        Reserved_10_0_1_b3                           : 3U;
      
      uint32        Reserved_10_0_2_b8                           : 8U;
      
      uint32        Reserved_10_0_3_b8                           : 8U;
      
   #else
      uint32        LSV_ID_0_b8                                  : 8U;
      
      uint32        LSV_Type_0_b4                                : 4U;
      
      uint32        LSV_Sub_Type_0_b6                            : 6U;
      
      uint32        LSV_CL_Sub_Type_0_b4                         : 4U;
      
      uint32        LSV_Consecutive_Detection_0_b7               : 7U;
      
      uint32        Reserved_1_0_b3                              : 3U;
      
      uint32        LSV_Width_STD_0_b9                           : 9U;
      
      uint32        LSV_Confidence_0_b7                          : 7U;
      
      uint32        LSV_Is_New_0_b1                              : 1U;
      
      uint32        LSV_VD_ID_0_b9                               : 9U;
      
      uint32        Reserved_2_0_b6                              : 6U;
      
      uint32        LSV_Brightness_0_b20                         : 20U;
      
      uint32        LSV_Distance_0_b11                           : 11U;
      
      uint32        Reserved_3_0_b1                              : 1U;
      
      uint32        LSV_Distance_STD_0_b8                        : 8U;
      
      uint32        LSV_CL_Distance_Right_0_b11                  : 11U;
      
      uint32        LSV_CL_Distance_Left_0_b11                   : 11U;
      
      uint32        Reserved_4_0_b2                              : 2U;
      
      uint32        LSV_Top_Angle_0_b12                          : 12U;
      
      uint32        LSV_Bottom_Angle_0_b12                       : 12U;
      
      uint32        Reserved_5_0_b8                              : 8U;
      
      uint32        LSV_Right_Angle_0_b13                        : 13U;
      
      uint32        LSV_Left_Angle_0_b13                         : 13U;
      
      uint32        Reserved_6_0_b6                              : 6U;
      
      uint32        LSV_Angular_Velocity_Right_0_b11             : 11U;
      
      uint32        LSV_Angular_Velocity_Left_0_b11              : 11U;
      
      uint32        Reserved_7_0_b10                             : 10U;
      
      uint32        LSV_Atten_Cent_Angle_H_0_b13                 : 13U;
      
      uint32        LSV_Atten_Cent_Angle_Lat_0_b13               : 13U;
      
      uint32        Reserved_8_0_b6                              : 6U;
      
      uint32        LSV_Facade_Top_Angle_0_b12                   : 12U;
      
      uint32        LSV_Facade_Right_Angle_0_b13                 : 13U;
      
      uint32        Reserved_9_0_b7                              : 7U;
      
      uint32        LSV_Facade_Left_Angle_0_b13                  : 13U;
      
      uint32        Reserved_10_0_b19                            : 19U;
      
   #endif
} EYEQMSG_CORELIGHTVCLvO_Params_t;


typedef struct
{
   EYEQMSG_CORELIGHTVCLvH_Params_t EYEQMSG_CORELIGHTVCLvH_Params_s;
   EYEQMSG_CORELIGHTVCLvO_Params_t EYEQMSG_CORELIGHTVCLvO_Params_as[C_EYEQMSG_CORELIGHTVCLvH_VIRTUAL_OBJECT_INDEX_RMAX];
} EYEQMSG_CORELIGHTVCL_Params_t;


/*****************************************************************************
                  Exported function prototypes
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvH_LSV_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pLSV_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Zero_byte
*    LSV_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Zero_byte signal value of Virtual_HEADER_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvH_LSV_Zero_byte( uint8 * pLSV_Zero_byte );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvH_LSV_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pLSV_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Protocol_Version
*    LSV_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Protocol_Version signal value of Virtual_HEADER_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvH_LSV_Protocol_Version( uint8 * pLSV_Protocol_Version );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvH_LSV_Sync_ID
*
* FUNCTION ARGUMENTS:
*    uint8 * pLSV_Sync_ID - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Sync_ID
*    LSV_Sync_ID returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Sync_ID signal value of Virtual_HEADER_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvH_LSV_Sync_ID( uint8 * pLSV_Sync_ID );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvH_LSV_Running_Mode
*
* FUNCTION ARGUMENTS:
*    CORELIGHTVCLvHLSVRunningMode * pLSV_Running_Mode - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Running_Mode
*    LSV_Running_Mode returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Running_Mode signal value of Virtual_HEADER_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvH_LSV_Running_Mode( CORELIGHTVCLvHLSVRunningMode * pLSV_Running_Mode );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvH_LSV_Inactive_Reason
*
* FUNCTION ARGUMENTS:
*    CORELIGHTVCLvHLSVInactiveReason * pLSV_Inactive_Reason - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Inactive_Reason
*    LSV_Inactive_Reason returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Inactive_Reason signal value of Virtual_HEADER_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvH_LSV_Inactive_Reason( CORELIGHTVCLvHLSVInactiveReason * pLSV_Inactive_Reason );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvH_LSV_HLB_Decision
*
* FUNCTION ARGUMENTS:
*    CORELIGHTVCLvHLSVHLBDecision * pLSV_HLB_Decision - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_HLB_Decision
*    LSV_HLB_Decision returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_HLB_Decision signal value of Virtual_HEADER_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvH_LSV_HLB_Decision( CORELIGHTVCLvHLSVHLBDecision * pLSV_HLB_Decision );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvH_LSV_HLB_Sensitivity_Mode
*
* FUNCTION ARGUMENTS:
*    CORELIGHTVCLvHLSVHLBSensitivityMode * pLSV_HLB_Sensitivity_Mode - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_HLB_Sensitivity_Mode
*    LSV_HLB_Sensitivity_Mode returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_HLB_Sensitivity_Mode signal value of Virtual_HEADER_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvH_LSV_HLB_Sensitivity_Mode( CORELIGHTVCLvHLSVHLBSensitivityMode * pLSV_HLB_Sensitivity_Mode );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvH_LSV_HLB_Reason
*
* FUNCTION ARGUMENTS:
*    CORELIGHTVCLvHLSVHLBReason * pLSV_HLB_Reason - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_HLB_Reason
*    LSV_HLB_Reason returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_HLB_Reason signal value of Virtual_HEADER_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvH_LSV_HLB_Reason( CORELIGHTVCLvHLSVHLBReason * pLSV_HLB_Reason );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvH_LSV_Vehicles_Count
*
* FUNCTION ARGUMENTS:
*    uint8 * pLSV_Vehicles_Count - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Vehicles_Count
*    LSV_Vehicles_Count returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Vehicles_Count signal value of Virtual_HEADER_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvH_LSV_Vehicles_Count( uint8 * pLSV_Vehicles_Count );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvH_LSV_Brightness_Score
*
* FUNCTION ARGUMENTS:
*    uint32 * pLSV_Brightness_Score - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Brightness_Score
*    LSV_Brightness_Score returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Brightness_Score signal value of Virtual_HEADER_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvH_LSV_Brightness_Score( uint32 * pLSV_Brightness_Score );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_LSV_ID_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLSV_ID_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_ID_0
*    LSV_ID_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_ID_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_LSV_ID_0( uint8 objIndx_u8, uint8 * pLSV_ID_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_LSV_Type_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELIGHTVCLvOLSVType0 * pLSV_Type_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Type_0
*    LSV_Type_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Type_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_LSV_Type_0( uint8 objIndx_u8, CORELIGHTVCLvOLSVType0 * pLSV_Type_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_LSV_Sub_Type_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELIGHTVCLvOLSVSubType0 * pLSV_Sub_Type_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Sub_Type_0
*    LSV_Sub_Type_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Sub_Type_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_LSV_Sub_Type_0( uint8 objIndx_u8, CORELIGHTVCLvOLSVSubType0 * pLSV_Sub_Type_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_LSV_CL_Sub_Type_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELIGHTVCLvOLSVCLSubType0 * pLSV_CL_Sub_Type_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_CL_Sub_Type_0
*    LSV_CL_Sub_Type_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_CL_Sub_Type_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_LSV_CL_Sub_Type_0( uint8 objIndx_u8, CORELIGHTVCLvOLSVCLSubType0 * pLSV_CL_Sub_Type_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_LSV_Consecutive_Detection_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLSV_Consecutive_Detection_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Consecutive_Detection_0
*    LSV_Consecutive_Detection_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Consecutive_Detection_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_LSV_Consecutive_Detection_0( uint8 objIndx_u8, uint8 * pLSV_Consecutive_Detection_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_Reserved_1_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_1_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1_0
*    Reserved_1_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_Reserved_1_0( uint8 objIndx_u8, uint8 * pReserved_1_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_LSV_Width_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLSV_Width_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Width_STD_0
*    LSV_Width_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Width_STD_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_LSV_Width_STD_0( uint8 objIndx_u8, uint16 * pLSV_Width_STD_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_LSV_Confidence_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLSV_Confidence_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Confidence_0
*    LSV_Confidence_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Confidence_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_LSV_Confidence_0( uint8 objIndx_u8, uint8 * pLSV_Confidence_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_LSV_Is_New_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELIGHTVCLvOLSVIsNew0 * pLSV_Is_New_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Is_New_0
*    LSV_Is_New_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Is_New_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_LSV_Is_New_0( uint8 objIndx_u8, CORELIGHTVCLvOLSVIsNew0 * pLSV_Is_New_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_LSV_VD_ID_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLSV_VD_ID_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_VD_ID_0
*    LSV_VD_ID_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_VD_ID_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_LSV_VD_ID_0( uint8 objIndx_u8, uint16 * pLSV_VD_ID_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_Reserved_2_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_2_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_2_0
*    Reserved_2_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_2_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_Reserved_2_0( uint8 objIndx_u8, uint8 * pReserved_2_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_LSV_Brightness_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint32 * pLSV_Brightness_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Brightness_0
*    LSV_Brightness_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Brightness_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_LSV_Brightness_0( uint8 objIndx_u8, uint32 * pLSV_Brightness_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_LSV_Distance_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLSV_Distance_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Distance_0
*    LSV_Distance_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Distance_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_LSV_Distance_0( uint8 objIndx_u8, uint16 * pLSV_Distance_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_Reserved_3_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    boolean * pReserved_3_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_3_0
*    Reserved_3_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_3_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_Reserved_3_0( uint8 objIndx_u8, boolean * pReserved_3_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_LSV_Distance_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLSV_Distance_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Distance_STD_0
*    LSV_Distance_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Distance_STD_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_LSV_Distance_STD_0( uint8 objIndx_u8, uint8 * pLSV_Distance_STD_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_LSV_CL_Distance_Right_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLSV_CL_Distance_Right_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_CL_Distance_Right_0
*    LSV_CL_Distance_Right_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_CL_Distance_Right_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_LSV_CL_Distance_Right_0( uint8 objIndx_u8, uint16 * pLSV_CL_Distance_Right_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_LSV_CL_Distance_Left_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLSV_CL_Distance_Left_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_CL_Distance_Left_0
*    LSV_CL_Distance_Left_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_CL_Distance_Left_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_LSV_CL_Distance_Left_0( uint8 objIndx_u8, uint16 * pLSV_CL_Distance_Left_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_Reserved_4_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_4_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_4_0
*    Reserved_4_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_4_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_Reserved_4_0( uint8 objIndx_u8, uint8 * pReserved_4_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_LSV_Top_Angle_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLSV_Top_Angle_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Top_Angle_0
*    LSV_Top_Angle_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Top_Angle_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_LSV_Top_Angle_0( uint8 objIndx_u8, uint16 * pLSV_Top_Angle_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_LSV_Bottom_Angle_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLSV_Bottom_Angle_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Bottom_Angle_0
*    LSV_Bottom_Angle_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Bottom_Angle_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_LSV_Bottom_Angle_0( uint8 objIndx_u8, uint16 * pLSV_Bottom_Angle_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_Reserved_5_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_5_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_5_0
*    Reserved_5_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_5_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_Reserved_5_0( uint8 objIndx_u8, uint8 * pReserved_5_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_LSV_Right_Angle_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLSV_Right_Angle_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Right_Angle_0
*    LSV_Right_Angle_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Right_Angle_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_LSV_Right_Angle_0( uint8 objIndx_u8, uint16 * pLSV_Right_Angle_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_LSV_Left_Angle_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLSV_Left_Angle_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Left_Angle_0
*    LSV_Left_Angle_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Left_Angle_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_LSV_Left_Angle_0( uint8 objIndx_u8, uint16 * pLSV_Left_Angle_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_Reserved_6_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_6_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_6_0
*    Reserved_6_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_6_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_Reserved_6_0( uint8 objIndx_u8, uint8 * pReserved_6_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_LSV_Angular_Velocity_Right_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLSV_Angular_Velocity_Right_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Angular_Velocity_Right_0
*    LSV_Angular_Velocity_Right_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Angular_Velocity_Right_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_LSV_Angular_Velocity_Right_0( uint8 objIndx_u8, uint16 * pLSV_Angular_Velocity_Right_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_LSV_Angular_Velocity_Left_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLSV_Angular_Velocity_Left_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Angular_Velocity_Left_0
*    LSV_Angular_Velocity_Left_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Angular_Velocity_Left_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_LSV_Angular_Velocity_Left_0( uint8 objIndx_u8, uint16 * pLSV_Angular_Velocity_Left_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_Reserved_7_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pReserved_7_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_7_0
*    Reserved_7_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_7_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_Reserved_7_0( uint8 objIndx_u8, uint16 * pReserved_7_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_LSV_Atten_Cent_Angle_H_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLSV_Atten_Cent_Angle_H_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Atten_Cent_Angle_H_0
*    LSV_Atten_Cent_Angle_H_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Atten_Cent_Angle_H_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_LSV_Atten_Cent_Angle_H_0( uint8 objIndx_u8, uint16 * pLSV_Atten_Cent_Angle_H_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_LSV_Atten_Cent_Angle_Lat_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLSV_Atten_Cent_Angle_Lat_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Atten_Cent_Angle_Lat_0
*    LSV_Atten_Cent_Angle_Lat_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Atten_Cent_Angle_Lat_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_LSV_Atten_Cent_Angle_Lat_0( uint8 objIndx_u8, uint16 * pLSV_Atten_Cent_Angle_Lat_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_Reserved_8_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_8_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_8_0
*    Reserved_8_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_8_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_Reserved_8_0( uint8 objIndx_u8, uint8 * pReserved_8_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_LSV_Facade_Top_Angle_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLSV_Facade_Top_Angle_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Facade_Top_Angle_0
*    LSV_Facade_Top_Angle_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Facade_Top_Angle_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_LSV_Facade_Top_Angle_0( uint8 objIndx_u8, uint16 * pLSV_Facade_Top_Angle_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_LSV_Facade_Right_Angle_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLSV_Facade_Right_Angle_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Facade_Right_Angle_0
*    LSV_Facade_Right_Angle_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Facade_Right_Angle_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_LSV_Facade_Right_Angle_0( uint8 objIndx_u8, uint16 * pLSV_Facade_Right_Angle_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_Reserved_9_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_9_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_9_0
*    Reserved_9_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_9_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_Reserved_9_0( uint8 objIndx_u8, uint8 * pReserved_9_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_LSV_Facade_Left_Angle_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLSV_Facade_Left_Angle_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSV_Facade_Left_Angle_0
*    LSV_Facade_Left_Angle_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSV_Facade_Left_Angle_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_LSV_Facade_Left_Angle_0( uint8 objIndx_u8, uint16 * pLSV_Facade_Left_Angle_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTVCLvO_Reserved_10_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint32 * pReserved_10_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_10_0
*    Reserved_10_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_10_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_VCL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTVCLvO_Reserved_10_0( uint8 objIndx_u8, uint32 * pReserved_10_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_CORELIGHTVCL_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_CORELIGHTVCL_Params_t * pCore_Light_Scene_VCL_protocol - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_Light_Scene_VCL_protocol message 
*    Core_Light_Scene_VCL_protocol message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_Light_Scene_VCL_protocol message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_CORELIGHTVCL_ParamsApp_MsgDataStruct( EYEQMSG_CORELIGHTVCL_Params_t * pCore_Light_Scene_VCL_protocol );
/*****************************************************************************
                  Exported object declarations
*****************************************************************************/
extern EYEQMSG_CORELIGHTVCL_Params_t   EYEQMSG_CORELIGHTVCL_Params_s;
extern EYEQMSG_CORELIGHTVCL_Params_t   EYEQMSG_CORELIGHTVCL_ParamsApp_s;
/****************************************************************************/
#endif /* _EYEQMSG_CORELIGHTVCLPROCESS_H_ */


