#ifndef _EYEQMSG_CORELANERDEDGEPROCESS_H_
#define _EYEQMSG_CORELANERDEDGEPROCESS_H_

/*****************************************************************************
                  Included header files
*****************************************************************************/
#include <Std_Types.h>

/*****************************************************************************
                  Include files
*****************************************************************************/
/*****************************************************************************
                  Exported symbolic constants
*****************************************************************************/
#define C_EYEQMSG_CORELANERDEDGEvH_VIRTUAL_OBJECT_INDEX_RMAX ( 4U )

/* Datagram message ID */
#define C_EYEQMSG_CORELANERDEDGEvH_MSG_ID                     ( 0x8AU )
#define C_EYEQMSG_CORELANERDEDGEvO_MSG_ID                     ( 0x8AU )
#define C_EYEQMSG_CORELANERDEDGE_MSG_ID                       ( 0x8AU )

/* Datagram message lengths */
#define C_EYEQMSG_CORELANERDEDGEvH_MSG_LEN                    ( sizeof(EYEQMSG_CORELANERDEDGEvH_Params_t) )
#define C_EYEQMSG_CORELANERDEDGEvO_MSG_LEN                    ( sizeof(EYEQMSG_CORELANERDEDGEvO_Params_t) )
#define C_EYEQMSG_CORELANERDEDGE_MSG_LEN                      ( sizeof(EYEQMSG_CORELANERDEDGE_Params_t) )

/* Protocol ENUMs */

/* MCU output messages */

/* Virtual_HEADER_msg_Core_Lanes_Road_Edge_protocol Enums */
/* LRE_Header_Buffer_b13 signal Min & Max range limits */
#define C_EYEQMSG_CORELANERDEDGEvH_LRE_HEADER_BUFFER_RMIN     ( 0U )
#define C_EYEQMSG_CORELANERDEDGEvH_LRE_HEADER_BUFFER_RMAX     ( 0U )
#define C_EYEQMSG_CORELANERDEDGEvH_LRE_HEADER_BUFFER_NUMR     ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvH_LRE_HEADER_BUFFER_DEMNR    ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvH_LRE_HEADER_BUFFER_OFFSET   ( 0U )

/* LRE_Count_b3 signal Min & Max range limits */
#define C_EYEQMSG_CORELANERDEDGEvH_LRE_COUNT_RMIN             ( 0U )
#define C_EYEQMSG_CORELANERDEDGEvH_LRE_COUNT_RMAX             ( 4U )
#define C_EYEQMSG_CORELANERDEDGEvH_LRE_COUNT_NUMR             ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvH_LRE_COUNT_DEMNR            ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvH_LRE_COUNT_OFFSET           ( 0U )

/* LRE_Sync_ID_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORELANERDEDGEvH_LRE_SYNC_ID_RMIN           ( 0U )
#define C_EYEQMSG_CORELANERDEDGEvH_LRE_SYNC_ID_RMAX           ( 255U )
#define C_EYEQMSG_CORELANERDEDGEvH_LRE_SYNC_ID_NUMR           ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvH_LRE_SYNC_ID_DEMNR          ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvH_LRE_SYNC_ID_OFFSET         ( 0U )

/* LRE_Protocol_Version_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORELANERDEDGEvH_LRE_PROTOCOL_VERSION_RMIN  ( 11U )
#define C_EYEQMSG_CORELANERDEDGEvH_LRE_PROTOCOL_VERSION_RMAX  ( 11U )
#define C_EYEQMSG_CORELANERDEDGEvH_LRE_PROTOCOL_VERSION_NUMR  ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvH_LRE_PROTOCOL_VERSION_DEMNR ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvH_LRE_PROTOCOL_VERSION_OFFSET ( 0U )

/* LRE_Header_CRC_b32 signal Min & Max range limits */
#define C_EYEQMSG_CORELANERDEDGEvH_LRE_HEADER_CRC_RMIN        ( 0U )
#define C_EYEQMSG_CORELANERDEDGEvH_LRE_HEADER_CRC_RMAX        ( 4294967295U )
#define C_EYEQMSG_CORELANERDEDGEvH_LRE_HEADER_CRC_NUMR        ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvH_LRE_HEADER_CRC_DEMNR       ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvH_LRE_HEADER_CRC_OFFSET      ( 0U )

/* Reserved_1_b24 signal Min & Max range limits */
#define C_EYEQMSG_CORELANERDEDGEvH_RESERVED_1_RMIN            ( 0U )
#define C_EYEQMSG_CORELANERDEDGEvH_RESERVED_1_RMAX            ( 0U )
#define C_EYEQMSG_CORELANERDEDGEvH_RESERVED_1_NUMR            ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvH_RESERVED_1_DEMNR           ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvH_RESERVED_1_OFFSET          ( 0U )

/* LRE_Zero_byte_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORELANERDEDGEvH_LRE_ZERO_BYTE_RMIN         ( 0U )
#define C_EYEQMSG_CORELANERDEDGEvH_LRE_ZERO_BYTE_RMAX         ( 255U )
#define C_EYEQMSG_CORELANERDEDGEvH_LRE_ZERO_BYTE_NUMR         ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvH_LRE_ZERO_BYTE_DEMNR        ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvH_LRE_ZERO_BYTE_OFFSET       ( 0U )


/* Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol Enums */
/* LRE_Element_Buffer_0_b30 signal Min & Max range limits */
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_ELEMENT_BUFFER_0_RMIN  ( 0U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_ELEMENT_BUFFER_0_RMAX  ( 0U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_ELEMENT_BUFFER_0_NUMR  ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_ELEMENT_BUFFER_0_DEMNR ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_ELEMENT_BUFFER_0_OFFSET ( 0U )

/* LRE_Detection_Source_0_b2 signal Enums */
typedef uint8 CORELANERDEDGEvOLREDetectionSource0;
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_DETECTION_SOURCE_0_UNKNOWN ( CORELANERDEDGEvOLREDetectionSource0 ) ( 0U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_DETECTION_SOURCE_0_FRONT ( CORELANERDEDGEvOLREDetectionSource0 ) ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_DETECTION_SOURCE_0_REAR ( CORELANERDEDGEvOLREDetectionSource0 ) ( 2U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_DETECTION_SOURCE_0_SIDE ( CORELANERDEDGEvOLREDetectionSource0 ) ( 3U )

/* LRE_Detection_Source_0_b2 signal Min & Max range limits */
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_DETECTION_SOURCE_0_RMIN ( 0U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_DETECTION_SOURCE_0_RMAX ( 3U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_DETECTION_SOURCE_0_NUMR ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_DETECTION_SOURCE_0_DEMNR ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_DETECTION_SOURCE_0_OFFSET ( 0U )

/* LRE_Line_C0_0_sb32 signal Min & Max range limits */
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_LINE_C0_0_RMIN         ( -30 )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_LINE_C0_0_RMAX         ( 30 )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_LINE_C0_0_NUMR         ( 1 )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_LINE_C0_0_DEMNR        ( 1 )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_LINE_C0_0_OFFSET       ( 0U )

/* LRE_Line_C1_0_sb32 signal Min & Max range limits */
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_LINE_C1_0_RMIN         ( -2 )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_LINE_C1_0_RMAX         ( 2 )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_LINE_C1_0_NUMR         ( 1 )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_LINE_C1_0_DEMNR        ( 1 )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_LINE_C1_0_OFFSET       ( 0U )

/* LRE_Line_C2_0_sb32 signal Min & Max range limits */
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_LINE_C2_0_RMIN         ( -0.125 )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_LINE_C2_0_RMAX         ( 0.125 )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_LINE_C2_0_NUMR         ( 1 )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_LINE_C2_0_DEMNR        ( 1 )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_LINE_C2_0_OFFSET       ( 0U )

/* LRE_Line_C3_0_sb32 signal Min & Max range limits */
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_LINE_C3_0_RMIN         ( -0.004 )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_LINE_C3_0_RMAX         ( 0.004 )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_LINE_C3_0_NUMR         ( 1 )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_LINE_C3_0_DEMNR        ( 1 )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_LINE_C3_0_OFFSET       ( 0U )

/* Reserved_5_0_b13 signal Min & Max range limits */
#define C_EYEQMSG_CORELANERDEDGEvO_RESERVED_5_0_RMIN          ( 0U )
#define C_EYEQMSG_CORELANERDEDGEvO_RESERVED_5_0_RMAX          ( 0U )
#define C_EYEQMSG_CORELANERDEDGEvO_RESERVED_5_0_NUMR          ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvO_RESERVED_5_0_DEMNR         ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvO_RESERVED_5_0_OFFSET        ( 0U )

/* LRE_Is_Triggered_SDM_Model_0_b2 signal Enums */
typedef uint8 CORELANERDEDGEvOLREIsTriggeredSDMModel0;
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_IS_TRIGGERED_SDM_MODEL_0_NOT_AVAILABLE ( CORELANERDEDGEvOLREIsTriggeredSDMModel0 ) ( 0U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_IS_TRIGGERED_SDM_MODEL_0_TRIGGERED ( CORELANERDEDGEvOLREIsTriggeredSDMModel0 ) ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_IS_TRIGGERED_SDM_MODEL_0_NOT_TRIGGERED ( CORELANERDEDGEvOLREIsTriggeredSDMModel0 ) ( 2U )

/* LRE_Is_Triggered_SDM_Model_0_b2 signal Min & Max range limits */
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_IS_TRIGGERED_SDM_MODEL_0_RMIN ( 0U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_IS_TRIGGERED_SDM_MODEL_0_RMAX ( 2U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_IS_TRIGGERED_SDM_MODEL_0_NUMR ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_IS_TRIGGERED_SDM_MODEL_0_DEMNR ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_IS_TRIGGERED_SDM_MODEL_0_OFFSET ( 0U )

/* LRE_Side_0_b2 signal Enums */
typedef uint8 CORELANERDEDGEvOLRESide0;
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_SIDE_0_UNFILLED        ( CORELANERDEDGEvOLRESide0 ) ( 0U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_SIDE_0_LEFT            ( CORELANERDEDGEvOLRESide0 ) ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_SIDE_0_RIGHT           ( CORELANERDEDGEvOLRESide0 ) ( 2U )

/* LRE_Side_0_b2 signal Min & Max range limits */
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_SIDE_0_RMIN            ( 0U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_SIDE_0_RMAX            ( 2U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_SIDE_0_NUMR            ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_SIDE_0_DEMNR           ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_SIDE_0_OFFSET          ( 0U )

/* LRE_Measured_VR_End_0_b15 signal Min & Max range limits */
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_MEASURED_VR_END_0_RMIN ( 0U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_MEASURED_VR_END_0_RMAX ( 20000U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_MEASURED_VR_END_0_NUMR ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_MEASURED_VR_END_0_DEMNR ( 100U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_MEASURED_VR_END_0_OFFSET ( 0U )

/* Reserved_4_0_b2 signal Min & Max range limits */
#define C_EYEQMSG_CORELANERDEDGEvO_RESERVED_4_0_RMIN          ( 0U )
#define C_EYEQMSG_CORELANERDEDGEvO_RESERVED_4_0_RMAX          ( 0U )
#define C_EYEQMSG_CORELANERDEDGEvO_RESERVED_4_0_NUMR          ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvO_RESERVED_4_0_DEMNR         ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvO_RESERVED_4_0_OFFSET        ( 0U )

/* LRE_View_Range_End_0_b15 signal Min & Max range limits */
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_VIEW_RANGE_END_0_RMIN  ( 0U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_VIEW_RANGE_END_0_RMAX  ( 20000U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_VIEW_RANGE_END_0_NUMR  ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_VIEW_RANGE_END_0_DEMNR ( 100U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_VIEW_RANGE_END_0_OFFSET ( 0U )

/* LRE_View_Range_Start_0_b15 signal Min & Max range limits */
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_VIEW_RANGE_START_0_RMIN ( 0U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_VIEW_RANGE_START_0_RMAX ( 20000U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_VIEW_RANGE_START_0_NUMR ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_VIEW_RANGE_START_0_DEMNR ( 100U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_VIEW_RANGE_START_0_OFFSET ( 0U )

/* Reserved_3_0_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORELANERDEDGEvO_RESERVED_3_0_RMIN          ( 0U )
#define C_EYEQMSG_CORELANERDEDGEvO_RESERVED_3_0_RMAX          ( 0U )
#define C_EYEQMSG_CORELANERDEDGEvO_RESERVED_3_0_NUMR          ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvO_RESERVED_3_0_DEMNR         ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvO_RESERVED_3_0_OFFSET        ( 0U )

/* LRE_Height_STD_0_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_HEIGHT_STD_0_RMIN      ( 0U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_HEIGHT_STD_0_RMAX      ( 200U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_HEIGHT_STD_0_NUMR      ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_HEIGHT_STD_0_DEMNR     ( 100U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_HEIGHT_STD_0_OFFSET    ( 0U )

/* LRE_Height_0_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_HEIGHT_0_RMIN          ( 0U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_HEIGHT_0_RMAX          ( 200U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_HEIGHT_0_NUMR          ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_HEIGHT_0_DEMNR         ( 100U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_HEIGHT_0_OFFSET        ( 0U )

/* LRE_Availability_State_0_b2 signal Enums */
typedef uint8 CORELANERDEDGEvOLREAvailabilityState0;
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_AVAILABILITY_STATE_0_NOT_AVAILABLE ( CORELANERDEDGEvOLREAvailabilityState0 ) ( 0U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_AVAILABILITY_STATE_0_PREDICATED ( CORELANERDEDGEvOLREAvailabilityState0 ) ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_AVAILABILITY_STATE_0_DETECTED ( CORELANERDEDGEvOLREAvailabilityState0 ) ( 2U )

/* LRE_Availability_State_0_b2 signal Min & Max range limits */
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_AVAILABILITY_STATE_0_RMIN ( 0U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_AVAILABILITY_STATE_0_RMAX ( 2U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_AVAILABILITY_STATE_0_NUMR ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_AVAILABILITY_STATE_0_DEMNR ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_AVAILABILITY_STATE_0_OFFSET ( 0U )

/* LRE_Prediction_Reason_0_b6 signal Enums */
typedef uint8 CORELANERDEDGEvOLREPredictionReason0;
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_PREDICTION_REASON_0__BIT_0_LOSS ( CORELANERDEDGEvOLREPredictionReason0 ) ( 0U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_PREDICTION_REASON_0__BIT_1_MERGE ( CORELANERDEDGEvOLREPredictionReason0 ) ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_PREDICTION_REASON_0__BIT_2_SHADOW ( CORELANERDEDGEvOLREPredictionReason0 ) ( 2U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_PREDICTION_REASON_0__BIT_3_DIVERGING ( CORELANERDEDGEvOLREPredictionReason0 ) ( 3U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_PREDICTION_REASON_0__BIT_4_OCCLUDED ( CORELANERDEDGEvOLREPredictionReason0 ) ( 4U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_PREDICTION_REASON_0__BIT_5_HEADWAY ( CORELANERDEDGEvOLREPredictionReason0 ) ( 5U )

/* LRE_Prediction_Reason_0_b6 signal Min & Max range limits */
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_PREDICTION_REASON_0_RMIN ( 0U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_PREDICTION_REASON_0_RMAX ( 63U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_PREDICTION_REASON_0_NUMR ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_PREDICTION_REASON_0_DEMNR ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_PREDICTION_REASON_0_OFFSET ( 0U )

/* Reserved_2_0_b4 signal Min & Max range limits */
#define C_EYEQMSG_CORELANERDEDGEvO_RESERVED_2_0_RMIN          ( 0U )
#define C_EYEQMSG_CORELANERDEDGEvO_RESERVED_2_0_RMAX          ( 0U )
#define C_EYEQMSG_CORELANERDEDGEvO_RESERVED_2_0_NUMR          ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvO_RESERVED_2_0_DEMNR         ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvO_RESERVED_2_0_OFFSET        ( 0U )

/* LRE_Type_0_b4 signal Enums */
typedef uint8 CORELANERDEDGEvOLREType0;
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_TYPE_0_UNDECIDED       ( CORELANERDEDGEvOLREType0 ) ( 0U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_TYPE_0_FLAT            ( CORELANERDEDGEvOLREType0 ) ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_TYPE_0_ELEVATED_STRUCTURE ( CORELANERDEDGEvOLREType0 ) ( 2U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_TYPE_0_CURB            ( CORELANERDEDGEvOLREType0 ) ( 3U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_TYPE_0_CONES_POLES     ( CORELANERDEDGEvOLREType0 ) ( 4U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_TYPE_0_PARKING_CARS    ( CORELANERDEDGEvOLREType0 ) ( 5U )

/* LRE_Type_0_b4 signal Min & Max range limits */
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_TYPE_0_RMIN            ( 0U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_TYPE_0_RMAX            ( 5U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_TYPE_0_NUMR            ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_TYPE_0_DEMNR           ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_TYPE_0_OFFSET          ( 0U )

/* LRE_Confidence_0_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_CONFIDENCE_0_RMIN      ( 0U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_CONFIDENCE_0_RMAX      ( 200U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_CONFIDENCE_0_NUMR      ( 1 )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_CONFIDENCE_0_DEMNR     ( 100 )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_CONFIDENCE_0_OFFSET    ( -1 )

/* LRE_Age_0_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_AGE_0_RMIN             ( 0U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_AGE_0_RMAX             ( 255U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_AGE_0_NUMR             ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_AGE_0_DEMNR            ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_AGE_0_OFFSET           ( 0U )

/* LRE_ID_0_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_ID_0_RMIN              ( 0U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_ID_0_RMAX              ( 255U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_ID_0_NUMR              ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_ID_0_DEMNR             ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_ID_0_OFFSET            ( 0U )

/* LRE_Element_CRC_0_b32 signal Min & Max range limits */
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_ELEMENT_CRC_0_RMIN     ( 0U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_ELEMENT_CRC_0_RMAX     ( 4294967295U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_ELEMENT_CRC_0_NUMR     ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_ELEMENT_CRC_0_DEMNR    ( 1U )
#define C_EYEQMSG_CORELANERDEDGEvO_LRE_ELEMENT_CRC_0_OFFSET   ( 0U )


/*****************************************************************************
                  Exported function-like macros
*****************************************************************************/
/*****************************************************************************
                  Exported defined macros
*****************************************************************************/
/*****************************************************************************
                  Exported types, enums definitions
*****************************************************************************/
typedef struct
{
   #if ENABLE_BIG_ENDIAN_FORMAT
      uint32        LRE_Zero_byte_b8                             : 8U;
      
      uint32        Reserved_1_1_b8                              : 8U;
      
      uint32        Reserved_1_2_b8                              : 8U;
      
      uint32        Reserved_1_3_b8                              : 8U;
      
      uint32        LRE_Header_CRC_1_b8                          : 8U;
      
      uint32        LRE_Header_CRC_2_b8                          : 8U;
      
      uint32        LRE_Header_CRC_3_b8                          : 8U;
      
      uint32        LRE_Header_CRC_4_b8                          : 8U;
      
      uint32        LRE_Protocol_Version_b8                      : 8U;
      
      uint32        LRE_Sync_ID_b8                               : 8U;
      
      uint32        unused1_b5                                   : 5;
      uint32        LRE_Count_b3                                 : 3U;
      
      uint32        LRE_Header_Buffer_1_b5                       : 5U;
      
      uint32        LRE_Header_Buffer_2_b8                       : 8U;
      
   #else
      uint32        LRE_Zero_byte_b8                             : 8U;
      
      uint32        Reserved_1_b24                               : 24U;
      
      uint32        LRE_Header_CRC_b32                           : 32U;
      
      uint32        LRE_Protocol_Version_b8                      : 8U;
      
      uint32        LRE_Sync_ID_b8                               : 8U;
      
      uint32        LRE_Count_b3                                 : 3U;
      
      uint32        LRE_Header_Buffer_b13                        : 13U;
      
   #endif
} EYEQMSG_CORELANERDEDGEvH_Params_t;


typedef struct
{
   #if ENABLE_BIG_ENDIAN_FORMAT
      uint32        unused1_b96                                  : 96;
      uint32        LRE_Element_CRC_0_1_b8                       : 8U;
      
      uint32        LRE_Element_CRC_0_2_b8                       : 8U;
      
      uint32        LRE_Element_CRC_0_3_b8                       : 8U;
      
      uint32        LRE_Element_CRC_0_4_b8                       : 8U;
      
      uint32        LRE_ID_0_b8                                  : 8U;
      
      uint32        LRE_Age_0_b8                                 : 8U;
      
      uint32        LRE_Confidence_0_b8                          : 8U;
      
      uint32        unused2_b4                                   : 4;
      uint32        LRE_Type_0_b4                                : 4U;
      
      uint32        Reserved_2_0_b4                              : 4U;
      
      uint32        LRE_Prediction_Reason_0_b6                   : 6U;
      
      uint32        LRE_Availability_State_0_b2                  : 2U;
      
      uint32        LRE_Height_0_b8                              : 8U;
      
      uint32        LRE_Height_STD_0_b8                          : 8U;
      
      uint32        Reserved_3_0_b8                              : 8U;
      
      uint32        LRE_View_Range_Start_0_1_b8                  : 8U;
      
      uint32        LRE_View_Range_Start_0_2_b7                  : 7U;
      
      uint32        LRE_View_Range_End_0_1_b1                    : 1U;
      
      uint32        LRE_View_Range_End_0_2_b8                    : 8U;
      
      uint32        LRE_View_Range_End_0_3_b6                    : 6U;
      
      uint32        Reserved_4_0_b2                              : 2U;
      
      uint32        LRE_Measured_VR_End_0_1_b8                   : 8U;
      
      uint32        LRE_Measured_VR_End_0_2_b7                   : 7U;
      
      uint32        LRE_Side_0_1_b1                              : 1U;
      
      uint32        unused3_b3                                   : 3;
      uint32        LRE_Side_0_2_b1                              : 1U;
      
      uint32        LRE_Is_Triggered_SDM_Model_0_b2              : 2U;
      
      uint32        Reserved_5_0_1_b5                            : 5U;
      
      uint32        Reserved_5_0_2_b8                            : 8U;
      
      uint32        LRE_Line_C3_0_1_sb8                          : 8U;
      
      uint32        LRE_Line_C3_0_2_sb8                          : 8U;
      
      uint32        LRE_Line_C3_0_3_sb8                          : 8U;
      
      uint32        LRE_Line_C3_0_4_sb8                          : 8U;
      
      uint32        LRE_Line_C2_0_1_sb8                          : 8U;
      
      uint32        LRE_Line_C2_0_2_sb8                          : 8U;
      
      uint32        LRE_Line_C2_0_3_sb8                          : 8U;
      
      uint32        LRE_Line_C2_0_4_sb8                          : 8U;
      
      uint32        LRE_Line_C1_0_1_sb8                          : 8U;
      
      uint32        LRE_Line_C1_0_2_sb8                          : 8U;
      
      uint32        LRE_Line_C1_0_3_sb8                          : 8U;
      
      uint32        LRE_Line_C1_0_4_sb8                          : 8U;
      
      uint32        LRE_Line_C0_0_1_sb8                          : 8U;
      
      uint32        LRE_Line_C0_0_2_sb8                          : 8U;
      
      uint32        LRE_Line_C0_0_3_sb8                          : 8U;
      
      uint32        LRE_Line_C0_0_4_sb8                          : 8U;
      
      uint32        LRE_Detection_Source_0_b2                    : 2U;
      
      uint32        LRE_Element_Buffer_0_1_b6                    : 6U;
      
      uint32        LRE_Element_Buffer_0_2_b8                    : 8U;
      
      uint32        LRE_Element_Buffer_0_3_b8                    : 8U;
      
      uint32        LRE_Element_Buffer_0_4_b8                    : 8U;
      
   #else
      uint32        LRE_Element_CRC_0_b32                        : 32U;
      
      uint32        LRE_ID_0_b8                                  : 8U;
      
      uint32        LRE_Age_0_b8                                 : 8U;
      
      uint32        LRE_Confidence_0_b8                          : 8U;
      
      uint32        LRE_Type_0_b4                                : 4U;
      
      uint32        Reserved_2_0_b4                              : 4U;
      
      uint32        LRE_Prediction_Reason_0_b6                   : 6U;
      
      uint32        LRE_Availability_State_0_b2                  : 2U;
      
      uint32        LRE_Height_0_b8                              : 8U;
      
      uint32        LRE_Height_STD_0_b8                          : 8U;
      
      uint32        Reserved_3_0_b8                              : 8U;
      
      uint32        LRE_View_Range_Start_0_b15                   : 15U;
      
      uint32        LRE_View_Range_End_0_b15                     : 15U;
      
      uint32        Reserved_4_0_b2                              : 2U;
      
      uint32        LRE_Measured_VR_End_0_b15                    : 15U;
      
      uint32        LRE_Side_0_b2                                : 2U;
      
      uint32        LRE_Is_Triggered_SDM_Model_0_b2              : 2U;
      
      uint32        Reserved_5_0_b13                             : 13U;
      
      sint32        LRE_Line_C3_0_sb32                           : 32;
      
      sint32        LRE_Line_C2_0_sb32                           : 32;
      
      sint32        LRE_Line_C1_0_sb32                           : 32;
      
      sint32        LRE_Line_C0_0_sb32                           : 32;
      
      uint32        LRE_Detection_Source_0_b2                    : 2U;
      
      uint32        LRE_Element_Buffer_0_b30                     : 30U;
      
   #endif
} EYEQMSG_CORELANERDEDGEvO_Params_t;


typedef struct
{
   EYEQMSG_CORELANERDEDGEvH_Params_t EYEQMSG_CORELANERDEDGEvH_Params_s;
   EYEQMSG_CORELANERDEDGEvO_Params_t EYEQMSG_CORELANERDEDGEvO_Params_as[C_EYEQMSG_CORELANERDEDGEvH_VIRTUAL_OBJECT_INDEX_RMAX];
} EYEQMSG_CORELANERDEDGE_Params_t;


/*****************************************************************************
                  Exported function prototypes
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvH_LRE_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pLRE_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_Zero_byte
*    LRE_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_Zero_byte signal value of Virtual_HEADER_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvH_LRE_Zero_byte( uint8 * pLRE_Zero_byte );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvH_Reserved_1
*
* FUNCTION ARGUMENTS:
*    uint32 * pReserved_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1
*    Reserved_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1 signal value of Virtual_HEADER_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvH_Reserved_1( uint32 * pReserved_1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvH_LRE_Header_CRC
*
* FUNCTION ARGUMENTS:
*    uint32 * pLRE_Header_CRC - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_Header_CRC
*    LRE_Header_CRC returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_Header_CRC signal value of Virtual_HEADER_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvH_LRE_Header_CRC( uint32 * pLRE_Header_CRC );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvH_LRE_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pLRE_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_Protocol_Version
*    LRE_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_Protocol_Version signal value of Virtual_HEADER_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvH_LRE_Protocol_Version( uint8 * pLRE_Protocol_Version );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvH_LRE_Sync_ID
*
* FUNCTION ARGUMENTS:
*    uint8 * pLRE_Sync_ID - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_Sync_ID
*    LRE_Sync_ID returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_Sync_ID signal value of Virtual_HEADER_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvH_LRE_Sync_ID( uint8 * pLRE_Sync_ID );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvH_LRE_Count
*
* FUNCTION ARGUMENTS:
*    uint8 * pLRE_Count - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_Count
*    LRE_Count returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_Count signal value of Virtual_HEADER_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvH_LRE_Count( uint8 * pLRE_Count );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvH_LRE_Header_Buffer
*
* FUNCTION ARGUMENTS:
*    uint16 * pLRE_Header_Buffer - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_Header_Buffer
*    LRE_Header_Buffer returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_Header_Buffer signal value of Virtual_HEADER_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvH_LRE_Header_Buffer( uint16 * pLRE_Header_Buffer );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvO_LRE_Element_CRC_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint32 * pLRE_Element_CRC_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_Element_CRC_0
*    LRE_Element_CRC_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_Element_CRC_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvO_LRE_Element_CRC_0( uint8 objIndx_u8, uint32 * pLRE_Element_CRC_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvO_LRE_ID_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLRE_ID_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_ID_0
*    LRE_ID_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_ID_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvO_LRE_ID_0( uint8 objIndx_u8, uint8 * pLRE_ID_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvO_LRE_Age_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLRE_Age_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_Age_0
*    LRE_Age_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_Age_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvO_LRE_Age_0( uint8 objIndx_u8, uint8 * pLRE_Age_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvO_LRE_Confidence_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLRE_Confidence_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_Confidence_0
*    LRE_Confidence_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_Confidence_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvO_LRE_Confidence_0( uint8 objIndx_u8, uint8 * pLRE_Confidence_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvO_LRE_Type_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANERDEDGEvOLREType0 * pLRE_Type_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_Type_0
*    LRE_Type_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_Type_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvO_LRE_Type_0( uint8 objIndx_u8, CORELANERDEDGEvOLREType0 * pLRE_Type_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvO_Reserved_2_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_2_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_2_0
*    Reserved_2_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_2_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvO_Reserved_2_0( uint8 objIndx_u8, uint8 * pReserved_2_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvO_LRE_Prediction_Reason_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANERDEDGEvOLREPredictionReason0 * pLRE_Prediction_Reason_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_Prediction_Reason_0
*    LRE_Prediction_Reason_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_Prediction_Reason_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvO_LRE_Prediction_Reason_0( uint8 objIndx_u8, CORELANERDEDGEvOLREPredictionReason0 * pLRE_Prediction_Reason_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvO_LRE_Availability_State_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANERDEDGEvOLREAvailabilityState0 * pLRE_Availability_State_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_Availability_State_0
*    LRE_Availability_State_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_Availability_State_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvO_LRE_Availability_State_0( uint8 objIndx_u8, CORELANERDEDGEvOLREAvailabilityState0 * pLRE_Availability_State_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvO_LRE_Height_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLRE_Height_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_Height_0
*    LRE_Height_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_Height_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvO_LRE_Height_0( uint8 objIndx_u8, uint8 * pLRE_Height_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvO_LRE_Height_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLRE_Height_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_Height_STD_0
*    LRE_Height_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_Height_STD_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvO_LRE_Height_STD_0( uint8 objIndx_u8, uint8 * pLRE_Height_STD_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvO_Reserved_3_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_3_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_3_0
*    Reserved_3_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_3_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvO_Reserved_3_0( uint8 objIndx_u8, uint8 * pReserved_3_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvO_LRE_View_Range_Start_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLRE_View_Range_Start_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_View_Range_Start_0
*    LRE_View_Range_Start_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_View_Range_Start_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvO_LRE_View_Range_Start_0( uint8 objIndx_u8, uint16 * pLRE_View_Range_Start_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvO_LRE_View_Range_End_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLRE_View_Range_End_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_View_Range_End_0
*    LRE_View_Range_End_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_View_Range_End_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvO_LRE_View_Range_End_0( uint8 objIndx_u8, uint16 * pLRE_View_Range_End_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvO_Reserved_4_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_4_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_4_0
*    Reserved_4_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_4_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvO_Reserved_4_0( uint8 objIndx_u8, uint8 * pReserved_4_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvO_LRE_Measured_VR_End_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLRE_Measured_VR_End_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_Measured_VR_End_0
*    LRE_Measured_VR_End_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_Measured_VR_End_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvO_LRE_Measured_VR_End_0( uint8 objIndx_u8, uint16 * pLRE_Measured_VR_End_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvO_LRE_Side_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANERDEDGEvOLRESide0 * pLRE_Side_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_Side_0
*    LRE_Side_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_Side_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvO_LRE_Side_0( uint8 objIndx_u8, CORELANERDEDGEvOLRESide0 * pLRE_Side_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvO_LRE_Is_Triggered_SDM_Model_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANERDEDGEvOLREIsTriggeredSDMModel0 * pLRE_Is_Triggered_SDM_Model_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_Is_Triggered_SDM_Model_0
*    LRE_Is_Triggered_SDM_Model_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_Is_Triggered_SDM_Model_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvO_LRE_Is_Triggered_SDM_Model_0( uint8 objIndx_u8, CORELANERDEDGEvOLREIsTriggeredSDMModel0 * pLRE_Is_Triggered_SDM_Model_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvO_Reserved_5_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pReserved_5_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_5_0
*    Reserved_5_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_5_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvO_Reserved_5_0( uint8 objIndx_u8, uint16 * pReserved_5_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvO_LRE_Line_C3_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    float32 * pLRE_Line_C3_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_Line_C3_0
*    LRE_Line_C3_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_Line_C3_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvO_LRE_Line_C3_0( uint8 objIndx_u8, float32 * pLRE_Line_C3_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvO_LRE_Line_C2_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    float32 * pLRE_Line_C2_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_Line_C2_0
*    LRE_Line_C2_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_Line_C2_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvO_LRE_Line_C2_0( uint8 objIndx_u8, float32 * pLRE_Line_C2_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvO_LRE_Line_C1_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    float32 * pLRE_Line_C1_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_Line_C1_0
*    LRE_Line_C1_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_Line_C1_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvO_LRE_Line_C1_0( uint8 objIndx_u8, float32 * pLRE_Line_C1_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvO_LRE_Line_C0_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    float32 * pLRE_Line_C0_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_Line_C0_0
*    LRE_Line_C0_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_Line_C0_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvO_LRE_Line_C0_0( uint8 objIndx_u8, float32 * pLRE_Line_C0_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvO_LRE_Detection_Source_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANERDEDGEvOLREDetectionSource0 * pLRE_Detection_Source_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_Detection_Source_0
*    LRE_Detection_Source_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_Detection_Source_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvO_LRE_Detection_Source_0( uint8 objIndx_u8, CORELANERDEDGEvOLREDetectionSource0 * pLRE_Detection_Source_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANERDEDGEvO_LRE_Element_Buffer_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint32 * pLRE_Element_Buffer_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LRE_Element_Buffer_0
*    LRE_Element_Buffer_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LRE_Element_Buffer_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Road_Edge_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANERDEDGEvO_LRE_Element_Buffer_0( uint8 objIndx_u8, uint32 * pLRE_Element_Buffer_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_CORELANERDEDGE_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_CORELANERDEDGE_Params_t * pCore_Lanes_Road_Edge_protocol - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_Lanes_Road_Edge_protocol message 
*    Core_Lanes_Road_Edge_protocol message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_Lanes_Road_Edge_protocol message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_CORELANERDEDGE_ParamsApp_MsgDataStruct( EYEQMSG_CORELANERDEDGE_Params_t * pCore_Lanes_Road_Edge_protocol );
/*****************************************************************************
                  Exported object declarations
*****************************************************************************/
extern EYEQMSG_CORELANERDEDGE_Params_t   EYEQMSG_CORELANERDEDGE_Params_s;
extern EYEQMSG_CORELANERDEDGE_Params_t   EYEQMSG_CORELANERDEDGE_ParamsApp_s;
/****************************************************************************/
#endif /* _EYEQMSG_CORELANERDEDGEPROCESS_H_ */


