

/*****************************************************************************
                  Include files
*****************************************************************************/
/* The suggested include file order is: */
#include "EyeQ_defs.h"    /* EyeQ project common definitions file    */

#include "EYEQMSG_CoreCommonProcess.h"

/*****************************************************************************
                  Local symbolic constants
*****************************************************************************/
/*****************************************************************************
                  Local types, enums definitions
*****************************************************************************/
/*****************************************************************************
                  Local function prototypes
*****************************************************************************/
/*****************************************************************************
                  Local object definitions
*****************************************************************************/
/*****************************************************************************
                  Exported object definitions
*****************************************************************************/
EYEQMSG_CORECOMMON_Params_t   EYEQMSG_CORECOMMON_Params_s;
EYEQMSG_CORECOMMON_Params_t   EYEQMSG_CORECOMMON_ParamsApp_s;
/*****************************************************************************
                  Local function-like macros
*****************************************************************************/
/*****************************************************************************
                  Local defined macros
*****************************************************************************/
/*****************************************************************************
                  Function definitions
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_CORECOMMON_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_CORECOMMON_Params_t * pCore_Common_protocol - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_Common_protocol message 
*    Core_Common_protocol message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_Common_protocol message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_CORECOMMON_ParamsApp_MsgDataStruct( EYEQMSG_CORECOMMON_Params_t * pCore_Common_protocol )
{
   Std_ReturnType status = C_SIG_INVALID;
   if( pCore_Common_protocol != C_NULL_P )
   {
      status = C_SIG_VALID;
      * pCore_Common_protocol = EYEQMSG_CORECOMMON_ParamsApp_s;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECOMMON_COM_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pCOM_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of COM_Zero_byte
*    COM_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns COM_Zero_byte signal value of Core_Common_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECOMMON_COM_Zero_byte( uint8 * pCOM_Zero_byte )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pCOM_Zero_byte != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECOMMON_ParamsApp_s.COM_Zero_byte_b8;
      * pCOM_Zero_byte = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECOMMON_Reserved_1
*
* FUNCTION ARGUMENTS:
*    uint32 * pReserved_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1
*    Reserved_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1 signal value of Core_Common_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECOMMON_Reserved_1( uint32 * pReserved_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pReserved_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECOMMON_ParamsApp_s.Reserved_1_b24;
      * pReserved_1 = signal_value;
      if( signal_value <= C_EYEQMSG_CORECOMMON_RESERVED_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECOMMON_COM_CRC
*
* FUNCTION ARGUMENTS:
*    uint32 * pCOM_CRC - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of COM_CRC
*    COM_CRC returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns COM_CRC signal value of Core_Common_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECOMMON_COM_CRC( uint32 * pCOM_CRC )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pCOM_CRC != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECOMMON_ParamsApp_s.COM_CRC_b32;
      * pCOM_CRC = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECOMMON_COM_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pCOM_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of COM_Protocol_Version
*    COM_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns COM_Protocol_Version signal value of Core_Common_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECOMMON_COM_Protocol_Version( uint8 * pCOM_Protocol_Version )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pCOM_Protocol_Version != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECOMMON_ParamsApp_s.COM_Protocol_Version_b8;
      * pCOM_Protocol_Version = signal_value;
      if( (signal_value >= C_EYEQMSG_CORECOMMON_COM_PROTOCOL_VERSION_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORECOMMON_COM_PROTOCOL_VERSION_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECOMMON_COM_Sync_Frame_ID
*
* FUNCTION ARGUMENTS:
*    uint8 * pCOM_Sync_Frame_ID - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of COM_Sync_Frame_ID
*    COM_Sync_Frame_ID returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns COM_Sync_Frame_ID signal value of Core_Common_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECOMMON_COM_Sync_Frame_ID( uint8 * pCOM_Sync_Frame_ID )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pCOM_Sync_Frame_ID != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECOMMON_ParamsApp_s.COM_Sync_Frame_ID_b8;
      * pCOM_Sync_Frame_ID = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECOMMON_Reserved_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pReserved_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_2
*    Reserved_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_2 signal value of Core_Common_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECOMMON_Reserved_2( uint16 * pReserved_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pReserved_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECOMMON_ParamsApp_s.Reserved_2_b16;
      * pReserved_2 = signal_value;
      if( signal_value <= C_EYEQMSG_CORECOMMON_RESERVED_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECOMMON_COM_Frame_MCU_TS_Start
*
* FUNCTION ARGUMENTS:
*    uint64 * pCOM_Frame_MCU_TS_Start - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of COM_Frame_MCU_TS_Start
*    COM_Frame_MCU_TS_Start returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns COM_Frame_MCU_TS_Start signal value of Core_Common_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECOMMON_COM_Frame_MCU_TS_Start( uint64 * pCOM_Frame_MCU_TS_Start )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint64 signal_value;
   
   if( pCOM_Frame_MCU_TS_Start != C_NULL_P )
   {
      signal_value = (uint64) (EYEQMSG_CORECOMMON_ParamsApp_s.COM_Frame_MCU_TS_Start_1_b32|((uint64)EYEQMSG_CORECOMMON_ParamsApp_s.COM_Frame_MCU_TS_Start_2_b32<<32));
      * pCOM_Frame_MCU_TS_Start = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECOMMON_COM_Last_MCU_Sync_TS
*
* FUNCTION ARGUMENTS:
*    uint64 * pCOM_Last_MCU_Sync_TS - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of COM_Last_MCU_Sync_TS
*    COM_Last_MCU_Sync_TS returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns COM_Last_MCU_Sync_TS signal value of Core_Common_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECOMMON_COM_Last_MCU_Sync_TS( uint64 * pCOM_Last_MCU_Sync_TS )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint64 signal_value;
   
   if( pCOM_Last_MCU_Sync_TS != C_NULL_P )
   {
      signal_value = (uint64) (EYEQMSG_CORECOMMON_ParamsApp_s.COM_Last_MCU_Sync_TS_1_b32|((uint64)EYEQMSG_CORECOMMON_ParamsApp_s.COM_Last_MCU_Sync_TS_2_b32<<32));
      * pCOM_Last_MCU_Sync_TS = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECOMMON_COM_Last_Clock_Sync_Skew
*
* FUNCTION ARGUMENTS:
*    uint32 * pCOM_Last_Clock_Sync_Skew - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of COM_Last_Clock_Sync_Skew
*    COM_Last_Clock_Sync_Skew returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns COM_Last_Clock_Sync_Skew signal value of Core_Common_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECOMMON_COM_Last_Clock_Sync_Skew( uint32 * pCOM_Last_Clock_Sync_Skew )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pCOM_Last_Clock_Sync_Skew != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECOMMON_ParamsApp_s.COM_Last_Clock_Sync_Skew_b22;
      * pCOM_Last_Clock_Sync_Skew = signal_value;
      if( signal_value <= C_EYEQMSG_CORECOMMON_COM_LAST_CLOCK_SYNC_SKEW_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECOMMON_COM_Last_Clock_Sync_Error
*
* FUNCTION ARGUMENTS:
*    CORECOMMONCOMLastClockSyncError * pCOM_Last_Clock_Sync_Error - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of COM_Last_Clock_Sync_Error
*    COM_Last_Clock_Sync_Error returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns COM_Last_Clock_Sync_Error signal value of Core_Common_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECOMMON_COM_Last_Clock_Sync_Error( CORECOMMONCOMLastClockSyncError * pCOM_Last_Clock_Sync_Error )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECOMMONCOMLastClockSyncError signal_value;
   
   if( pCOM_Last_Clock_Sync_Error != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECOMMON_ParamsApp_s.COM_Last_Clock_Sync_Error_b1;
      * pCOM_Last_Clock_Sync_Error = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECOMMON_Reserved_3
*
* FUNCTION ARGUMENTS:
*    uint16 * pReserved_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_3
*    Reserved_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_3 signal value of Core_Common_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECOMMON_Reserved_3( uint16 * pReserved_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pReserved_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECOMMON_ParamsApp_s.Reserved_3_b9;
      * pReserved_3 = signal_value;
      if( signal_value <= C_EYEQMSG_CORECOMMON_RESERVED_3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECOMMON_COM_EyeQ_Frame_ID
*
* FUNCTION ARGUMENTS:
*    uint32 * pCOM_EyeQ_Frame_ID - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of COM_EyeQ_Frame_ID
*    COM_EyeQ_Frame_ID returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns COM_EyeQ_Frame_ID signal value of Core_Common_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECOMMON_COM_EyeQ_Frame_ID( uint32 * pCOM_EyeQ_Frame_ID )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pCOM_EyeQ_Frame_ID != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECOMMON_ParamsApp_s.COM_EyeQ_Frame_ID_b32;
      * pCOM_EyeQ_Frame_ID = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECOMMON_COM_Cam_Frame_ID
*
* FUNCTION ARGUMENTS:
*    uint32 * pCOM_Cam_Frame_ID - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of COM_Cam_Frame_ID
*    COM_Cam_Frame_ID returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns COM_Cam_Frame_ID signal value of Core_Common_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECOMMON_COM_Cam_Frame_ID( uint32 * pCOM_Cam_Frame_ID )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pCOM_Cam_Frame_ID != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECOMMON_ParamsApp_s.COM_Cam_Frame_ID_b32;
      * pCOM_Cam_Frame_ID = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECOMMON_COM_DayTime_Indicator
*
* FUNCTION ARGUMENTS:
*    CORECOMMONCOMDayTimeIndicator * pCOM_DayTime_Indicator - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of COM_DayTime_Indicator
*    COM_DayTime_Indicator returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns COM_DayTime_Indicator signal value of Core_Common_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECOMMON_COM_DayTime_Indicator( CORECOMMONCOMDayTimeIndicator * pCOM_DayTime_Indicator )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECOMMONCOMDayTimeIndicator signal_value;
   
   if( pCOM_DayTime_Indicator != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECOMMON_ParamsApp_s.COM_DayTime_Indicator_b2;
      * pCOM_DayTime_Indicator = signal_value;
      if( signal_value <= C_EYEQMSG_CORECOMMON_COM_DAYTIME_INDICATOR_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECOMMON_COM_HIL_Mode_Status
*
* FUNCTION ARGUMENTS:
*    CORECOMMONCOMHILModeStatus * pCOM_HIL_Mode_Status - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of COM_HIL_Mode_Status
*    COM_HIL_Mode_Status returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns COM_HIL_Mode_Status signal value of Core_Common_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECOMMON_COM_HIL_Mode_Status( CORECOMMONCOMHILModeStatus * pCOM_HIL_Mode_Status )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECOMMONCOMHILModeStatus signal_value;
   
   if( pCOM_HIL_Mode_Status != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECOMMON_ParamsApp_s.COM_HIL_Mode_Status_b1;
      * pCOM_HIL_Mode_Status = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECOMMON_COM_Exposure_Type
*
* FUNCTION ARGUMENTS:
*    CORECOMMONCOMExposureType * pCOM_Exposure_Type - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of COM_Exposure_Type
*    COM_Exposure_Type returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns COM_Exposure_Type signal value of Core_Common_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECOMMON_COM_Exposure_Type( CORECOMMONCOMExposureType * pCOM_Exposure_Type )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECOMMONCOMExposureType signal_value;
   
   if( pCOM_Exposure_Type != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECOMMON_ParamsApp_s.COM_Exposure_Type_b2;
      * pCOM_Exposure_Type = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECOMMON_COM_Region_Code_V
*
* FUNCTION ARGUMENTS:
*    CORECOMMONCOMRegionCodeV * pCOM_Region_Code_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of COM_Region_Code_V
*    COM_Region_Code_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns COM_Region_Code_V signal value of Core_Common_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECOMMON_COM_Region_Code_V( CORECOMMONCOMRegionCodeV * pCOM_Region_Code_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECOMMONCOMRegionCodeV signal_value;
   
   if( pCOM_Region_Code_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECOMMON_ParamsApp_s.COM_Region_Code_V_b1;
      * pCOM_Region_Code_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECOMMON_COM_Region_Code
*
* FUNCTION ARGUMENTS:
*    CORECOMMONCOMRegionCode * pCOM_Region_Code - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of COM_Region_Code
*    COM_Region_Code returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns COM_Region_Code signal value of Core_Common_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECOMMON_COM_Region_Code( CORECOMMONCOMRegionCode * pCOM_Region_Code )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECOMMONCOMRegionCode signal_value;
   
   if( pCOM_Region_Code != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECOMMON_ParamsApp_s.COM_Region_Code_b5;
      * pCOM_Region_Code = signal_value;
      if( signal_value <= C_EYEQMSG_CORECOMMON_COM_REGION_CODE_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECOMMON_COM_Driving_Side_V
*
* FUNCTION ARGUMENTS:
*    CORECOMMONCOMDrivingSideV * pCOM_Driving_Side_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of COM_Driving_Side_V
*    COM_Driving_Side_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns COM_Driving_Side_V signal value of Core_Common_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECOMMON_COM_Driving_Side_V( CORECOMMONCOMDrivingSideV * pCOM_Driving_Side_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECOMMONCOMDrivingSideV signal_value;
   
   if( pCOM_Driving_Side_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECOMMON_ParamsApp_s.COM_Driving_Side_V_b1;
      * pCOM_Driving_Side_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECOMMON_COM_Driving_Side
*
* FUNCTION ARGUMENTS:
*    CORECOMMONCOMDrivingSide * pCOM_Driving_Side - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of COM_Driving_Side
*    COM_Driving_Side returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns COM_Driving_Side signal value of Core_Common_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECOMMON_COM_Driving_Side( CORECOMMONCOMDrivingSide * pCOM_Driving_Side )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECOMMONCOMDrivingSide signal_value;
   
   if( pCOM_Driving_Side != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECOMMON_ParamsApp_s.COM_Driving_Side_b8;
      * pCOM_Driving_Side = signal_value;
      if( signal_value <= C_EYEQMSG_CORECOMMON_COM_DRIVING_SIDE_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECOMMON_COM_Is_HighSpeed_Road_V
*
* FUNCTION ARGUMENTS:
*    CORECOMMONCOMIsHighSpeedRoadV * pCOM_Is_HighSpeed_Road_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of COM_Is_HighSpeed_Road_V
*    COM_Is_HighSpeed_Road_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns COM_Is_HighSpeed_Road_V signal value of Core_Common_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECOMMON_COM_Is_HighSpeed_Road_V( CORECOMMONCOMIsHighSpeedRoadV * pCOM_Is_HighSpeed_Road_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECOMMONCOMIsHighSpeedRoadV signal_value;
   
   if( pCOM_Is_HighSpeed_Road_V != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECOMMON_ParamsApp_s.COM_Is_HighSpeed_Road_V_b1;
      * pCOM_Is_HighSpeed_Road_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECOMMON_COM_Is_HighSpeed_Road
*
* FUNCTION ARGUMENTS:
*    CORECOMMONCOMIsHighSpeedRoad * pCOM_Is_HighSpeed_Road - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of COM_Is_HighSpeed_Road
*    COM_Is_HighSpeed_Road returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns COM_Is_HighSpeed_Road signal value of Core_Common_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECOMMON_COM_Is_HighSpeed_Road( CORECOMMONCOMIsHighSpeedRoad * pCOM_Is_HighSpeed_Road )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECOMMONCOMIsHighSpeedRoad signal_value;
   
   if( pCOM_Is_HighSpeed_Road != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECOMMON_ParamsApp_s.COM_Is_HighSpeed_Road_b1;
      * pCOM_Is_HighSpeed_Road = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECOMMON_COM_Is_In_Tunnel
*
* FUNCTION ARGUMENTS:
*    CORECOMMONCOMIsInTunnel * pCOM_Is_In_Tunnel - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of COM_Is_In_Tunnel
*    COM_Is_In_Tunnel returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns COM_Is_In_Tunnel signal value of Core_Common_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECOMMON_COM_Is_In_Tunnel( CORECOMMONCOMIsInTunnel * pCOM_Is_In_Tunnel )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECOMMONCOMIsInTunnel signal_value;
   
   if( pCOM_Is_In_Tunnel != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECOMMON_ParamsApp_s.COM_Is_In_Tunnel_b2;
      * pCOM_Is_In_Tunnel = signal_value;
      if( signal_value <= C_EYEQMSG_CORECOMMON_COM_IS_IN_TUNNEL_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECOMMON_COM_Tunnel_Conf
*
* FUNCTION ARGUMENTS:
*    uint8 * pCOM_Tunnel_Conf - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of COM_Tunnel_Conf
*    COM_Tunnel_Conf returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns COM_Tunnel_Conf signal value of Core_Common_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECOMMON_COM_Tunnel_Conf( uint8 * pCOM_Tunnel_Conf )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pCOM_Tunnel_Conf != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECOMMON_ParamsApp_s.COM_Tunnel_Conf_b7;
      * pCOM_Tunnel_Conf = signal_value;
      if( signal_value <= C_EYEQMSG_CORECOMMON_COM_TUNNEL_CONF_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECOMMON_Reserved_4
*
* FUNCTION ARGUMENTS:
*    boolean * pReserved_4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_4
*    Reserved_4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_4 signal value of Core_Common_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECOMMON_Reserved_4( boolean * pReserved_4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pReserved_4 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECOMMON_ParamsApp_s.Reserved_4_b1;
      * pReserved_4 = signal_value;
      if( signal_value <= C_EYEQMSG_CORECOMMON_RESERVED_4_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

