#ifndef _EYEQMSG_CALDYNPROCESS_H_
#define _EYEQMSG_CALDYNPROCESS_H_

/*****************************************************************************
                  Included header files
*****************************************************************************/
#include <Std_Types.h>

/*****************************************************************************
                  Include files
*****************************************************************************/
/*****************************************************************************
                  Exported symbolic constants
*****************************************************************************/

/* Datagram message ID */
#define C_EYEQMSG_CALDYN_MSG_ID                               ( 0x63U )

/* Datagram message lengths */
#define C_EYEQMSG_CALDYN_MSG_LEN                              ( sizeof(EYEQMSG_CALDYN_Params_t) )

/* Protocol ENUMs */

/* MCU output messages */

/* Core_Calibration_Dynamic_protocol Enums */
/* CLB_DYN_Buffer_b16 signal Min & Max range limits */
#define C_EYEQMSG_CALDYN_CLB_DYN_BUFFER_RMIN                  ( 0U )
#define C_EYEQMSG_CALDYN_CLB_DYN_BUFFER_RMAX                  ( 0U )
#define C_EYEQMSG_CALDYN_CLB_DYN_BUFFER_NUMR                  ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_BUFFER_DEMNR                 ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_BUFFER_OFFSET                ( 0U )

/* CLB_DYN_Cam_Height_b16 signal Min & Max range limits */
#define C_EYEQMSG_CALDYN_CLB_DYN_CAM_HEIGHT_RMIN              ( 50U )
#define C_EYEQMSG_CALDYN_CLB_DYN_CAM_HEIGHT_RMAX              ( 300U )
#define C_EYEQMSG_CALDYN_CLB_DYN_CAM_HEIGHT_NUMR              ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_CAM_HEIGHT_DEMNR             ( 100U )
#define C_EYEQMSG_CALDYN_CLB_DYN_CAM_HEIGHT_OFFSET            ( 0U )

/* CLB_DYN_Roll_sb32 signal Min & Max range limits */
#define C_EYEQMSG_CALDYN_CLB_DYN_ROLL_RMIN                    ( -0.05 )
#define C_EYEQMSG_CALDYN_CLB_DYN_ROLL_RMAX                    ( 0.05 )
#define C_EYEQMSG_CALDYN_CLB_DYN_ROLL_NUMR                    ( 1 )
#define C_EYEQMSG_CALDYN_CLB_DYN_ROLL_DEMNR                   ( 1 )
#define C_EYEQMSG_CALDYN_CLB_DYN_ROLL_OFFSET                  ( 0U )

/* CLB_DYN_Pitch_Px_b16 signal Min & Max range limits */
#define C_EYEQMSG_CALDYN_CLB_DYN_PITCH_PX_RMIN                ( 0U )
#define C_EYEQMSG_CALDYN_CLB_DYN_PITCH_PX_RMAX                ( 1000U )
#define C_EYEQMSG_CALDYN_CLB_DYN_PITCH_PX_NUMR                ( 1 )
#define C_EYEQMSG_CALDYN_CLB_DYN_PITCH_PX_DEMNR               ( 1 )
#define C_EYEQMSG_CALDYN_CLB_DYN_PITCH_PX_OFFSET              ( -500 )

/* CLB_DYN_Yaw_Px_b16 signal Min & Max range limits */
#define C_EYEQMSG_CALDYN_CLB_DYN_YAW_PX_RMIN                  ( 0U )
#define C_EYEQMSG_CALDYN_CLB_DYN_YAW_PX_RMAX                  ( 1000U )
#define C_EYEQMSG_CALDYN_CLB_DYN_YAW_PX_NUMR                  ( 1 )
#define C_EYEQMSG_CALDYN_CLB_DYN_YAW_PX_DEMNR                 ( 1 )
#define C_EYEQMSG_CALDYN_CLB_DYN_YAW_PX_OFFSET                ( -500 )

/* CLB_DYN_Pitch_Deg_sb32 signal Min & Max range limits */
#define C_EYEQMSG_CALDYN_CLB_DYN_PITCH_DEG_RMIN               ( -180 )
#define C_EYEQMSG_CALDYN_CLB_DYN_PITCH_DEG_RMAX               ( 180 )
#define C_EYEQMSG_CALDYN_CLB_DYN_PITCH_DEG_NUMR               ( 1 )
#define C_EYEQMSG_CALDYN_CLB_DYN_PITCH_DEG_DEMNR              ( 1 )
#define C_EYEQMSG_CALDYN_CLB_DYN_PITCH_DEG_OFFSET             ( 0U )

/* CLB_DYN_Yaw_Deg_sb32 signal Min & Max range limits */
#define C_EYEQMSG_CALDYN_CLB_DYN_YAW_DEG_RMIN                 ( -180 )
#define C_EYEQMSG_CALDYN_CLB_DYN_YAW_DEG_RMAX                 ( 180 )
#define C_EYEQMSG_CALDYN_CLB_DYN_YAW_DEG_NUMR                 ( 1 )
#define C_EYEQMSG_CALDYN_CLB_DYN_YAW_DEG_DEMNR                ( 1 )
#define C_EYEQMSG_CALDYN_CLB_DYN_YAW_DEG_OFFSET               ( 0U )

/* CLB_DYN_CRC_b32 signal Min & Max range limits */
#define C_EYEQMSG_CALDYN_CLB_DYN_CRC_RMIN                     ( 0U )
#define C_EYEQMSG_CALDYN_CLB_DYN_CRC_RMAX                     ( 4294967295U )
#define C_EYEQMSG_CALDYN_CLB_DYN_CRC_NUMR                     ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_CRC_DEMNR                    ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_CRC_OFFSET                   ( 0U )

/* CLB_DYN_Header_Buffer_b17 signal Min & Max range limits */
#define C_EYEQMSG_CALDYN_CLB_DYN_HEADER_BUFFER_RMIN           ( 0U )
#define C_EYEQMSG_CALDYN_CLB_DYN_HEADER_BUFFER_RMAX           ( 0U )
#define C_EYEQMSG_CALDYN_CLB_DYN_HEADER_BUFFER_NUMR           ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_HEADER_BUFFER_DEMNR          ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_HEADER_BUFFER_OFFSET         ( 0U )

/* CLB_DYN_Total_Roll_Dist_b15 signal Min & Max range limits */
#define C_EYEQMSG_CALDYN_CLB_DYN_TOTAL_ROLL_DIST_RMIN         ( 0U )
#define C_EYEQMSG_CALDYN_CLB_DYN_TOTAL_ROLL_DIST_RMAX         ( 20000U )
#define C_EYEQMSG_CALDYN_CLB_DYN_TOTAL_ROLL_DIST_NUMR         ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_TOTAL_ROLL_DIST_DEMNR        ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_TOTAL_ROLL_DIST_OFFSET       ( 0U )

/* Reserved_8_b5 signal Min & Max range limits */
#define C_EYEQMSG_CALDYN_RESERVED_8_RMIN                      ( 0U )
#define C_EYEQMSG_CALDYN_RESERVED_8_RMAX                      ( 0U )
#define C_EYEQMSG_CALDYN_RESERVED_8_NUMR                      ( 1U )
#define C_EYEQMSG_CALDYN_RESERVED_8_DEMNR                     ( 1U )
#define C_EYEQMSG_CALDYN_RESERVED_8_OFFSET                    ( 0U )

/* CLB_DYN_Total_Roll_Time_b12 signal Min & Max range limits */
#define C_EYEQMSG_CALDYN_CLB_DYN_TOTAL_ROLL_TIME_RMIN         ( 0U )
#define C_EYEQMSG_CALDYN_CLB_DYN_TOTAL_ROLL_TIME_RMAX         ( 3600U )
#define C_EYEQMSG_CALDYN_CLB_DYN_TOTAL_ROLL_TIME_NUMR         ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_TOTAL_ROLL_TIME_DEMNR        ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_TOTAL_ROLL_TIME_OFFSET       ( 0U )

/* CLB_DYN_Total_Pitch_Dist_b15 signal Min & Max range limits */
#define C_EYEQMSG_CALDYN_CLB_DYN_TOTAL_PITCH_DIST_RMIN        ( 0U )
#define C_EYEQMSG_CALDYN_CLB_DYN_TOTAL_PITCH_DIST_RMAX        ( 20000U )
#define C_EYEQMSG_CALDYN_CLB_DYN_TOTAL_PITCH_DIST_NUMR        ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_TOTAL_PITCH_DIST_DEMNR       ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_TOTAL_PITCH_DIST_OFFSET      ( 0U )

/* Reserved_7_b5 signal Min & Max range limits */
#define C_EYEQMSG_CALDYN_RESERVED_7_RMIN                      ( 0U )
#define C_EYEQMSG_CALDYN_RESERVED_7_RMAX                      ( 0U )
#define C_EYEQMSG_CALDYN_RESERVED_7_NUMR                      ( 1U )
#define C_EYEQMSG_CALDYN_RESERVED_7_DEMNR                     ( 1U )
#define C_EYEQMSG_CALDYN_RESERVED_7_OFFSET                    ( 0U )

/* CLB_DYN_Total_Pitch_Time_b12 signal Min & Max range limits */
#define C_EYEQMSG_CALDYN_CLB_DYN_TOTAL_PITCH_TIME_RMIN        ( 0U )
#define C_EYEQMSG_CALDYN_CLB_DYN_TOTAL_PITCH_TIME_RMAX        ( 3600U )
#define C_EYEQMSG_CALDYN_CLB_DYN_TOTAL_PITCH_TIME_NUMR        ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_TOTAL_PITCH_TIME_DEMNR       ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_TOTAL_PITCH_TIME_OFFSET      ( 0U )

/* CLB_DYN_Total_Yaw_Dist_b15 signal Min & Max range limits */
#define C_EYEQMSG_CALDYN_CLB_DYN_TOTAL_YAW_DIST_RMIN          ( 0U )
#define C_EYEQMSG_CALDYN_CLB_DYN_TOTAL_YAW_DIST_RMAX          ( 20000U )
#define C_EYEQMSG_CALDYN_CLB_DYN_TOTAL_YAW_DIST_NUMR          ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_TOTAL_YAW_DIST_DEMNR         ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_TOTAL_YAW_DIST_OFFSET        ( 0U )

/* Reserved_6_b5 signal Min & Max range limits */
#define C_EYEQMSG_CALDYN_RESERVED_6_RMIN                      ( 0U )
#define C_EYEQMSG_CALDYN_RESERVED_6_RMAX                      ( 0U )
#define C_EYEQMSG_CALDYN_RESERVED_6_NUMR                      ( 1U )
#define C_EYEQMSG_CALDYN_RESERVED_6_DEMNR                     ( 1U )
#define C_EYEQMSG_CALDYN_RESERVED_6_OFFSET                    ( 0U )

/* CLB_DYN_Total_Yaw_Time_b12 signal Min & Max range limits */
#define C_EYEQMSG_CALDYN_CLB_DYN_TOTAL_YAW_TIME_RMIN          ( 0U )
#define C_EYEQMSG_CALDYN_CLB_DYN_TOTAL_YAW_TIME_RMAX          ( 3600U )
#define C_EYEQMSG_CALDYN_CLB_DYN_TOTAL_YAW_TIME_NUMR          ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_TOTAL_YAW_TIME_DEMNR         ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_TOTAL_YAW_TIME_OFFSET        ( 0U )

/* CLB_DYN_Total_Cam_Height_Dist_b15 signal Min & Max range limits */
#define C_EYEQMSG_CALDYN_CLB_DYN_TOTAL_CAM_HEIGHT_DIST_RMIN   ( 0U )
#define C_EYEQMSG_CALDYN_CLB_DYN_TOTAL_CAM_HEIGHT_DIST_RMAX   ( 20000U )
#define C_EYEQMSG_CALDYN_CLB_DYN_TOTAL_CAM_HEIGHT_DIST_NUMR   ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_TOTAL_CAM_HEIGHT_DIST_DEMNR  ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_TOTAL_CAM_HEIGHT_DIST_OFFSET ( 0U )

/* Reserved_5_b13 signal Min & Max range limits */
#define C_EYEQMSG_CALDYN_RESERVED_5_RMIN                      ( 0U )
#define C_EYEQMSG_CALDYN_RESERVED_5_RMAX                      ( 0U )
#define C_EYEQMSG_CALDYN_RESERVED_5_NUMR                      ( 1U )
#define C_EYEQMSG_CALDYN_RESERVED_5_DEMNR                     ( 1U )
#define C_EYEQMSG_CALDYN_RESERVED_5_OFFSET                    ( 0U )

/* CLB_DYN_Total_Cam_Height_Time_b12 signal Min & Max range limits */
#define C_EYEQMSG_CALDYN_CLB_DYN_TOTAL_CAM_HEIGHT_TIME_RMIN   ( 0U )
#define C_EYEQMSG_CALDYN_CLB_DYN_TOTAL_CAM_HEIGHT_TIME_RMAX   ( 3600U )
#define C_EYEQMSG_CALDYN_CLB_DYN_TOTAL_CAM_HEIGHT_TIME_NUMR   ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_TOTAL_CAM_HEIGHT_TIME_DEMNR  ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_TOTAL_CAM_HEIGHT_TIME_OFFSET ( 0U )

/* CLB_DYN_Roll_Progress_b7 signal Min & Max range limits */
#define C_EYEQMSG_CALDYN_CLB_DYN_ROLL_PROGRESS_RMIN           ( 0U )
#define C_EYEQMSG_CALDYN_CLB_DYN_ROLL_PROGRESS_RMAX           ( 100U )
#define C_EYEQMSG_CALDYN_CLB_DYN_ROLL_PROGRESS_NUMR           ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_ROLL_PROGRESS_DEMNR          ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_ROLL_PROGRESS_OFFSET         ( 0U )

/* Reserved_4_b4 signal Min & Max range limits */
#define C_EYEQMSG_CALDYN_RESERVED_4_RMIN                      ( 0U )
#define C_EYEQMSG_CALDYN_RESERVED_4_RMAX                      ( 0U )
#define C_EYEQMSG_CALDYN_RESERVED_4_NUMR                      ( 1U )
#define C_EYEQMSG_CALDYN_RESERVED_4_DEMNR                     ( 1U )
#define C_EYEQMSG_CALDYN_RESERVED_4_OFFSET                    ( 0U )

/* CLB_DYN_Pitch_Progress_b7 signal Min & Max range limits */
#define C_EYEQMSG_CALDYN_CLB_DYN_PITCH_PROGRESS_RMIN          ( 0U )
#define C_EYEQMSG_CALDYN_CLB_DYN_PITCH_PROGRESS_RMAX          ( 100U )
#define C_EYEQMSG_CALDYN_CLB_DYN_PITCH_PROGRESS_NUMR          ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_PITCH_PROGRESS_DEMNR         ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_PITCH_PROGRESS_OFFSET        ( 0U )

/* CLB_DYN_Yaw_Progress_b7 signal Min & Max range limits */
#define C_EYEQMSG_CALDYN_CLB_DYN_YAW_PROGRESS_RMIN            ( 0U )
#define C_EYEQMSG_CALDYN_CLB_DYN_YAW_PROGRESS_RMAX            ( 100U )
#define C_EYEQMSG_CALDYN_CLB_DYN_YAW_PROGRESS_NUMR            ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_YAW_PROGRESS_DEMNR           ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_YAW_PROGRESS_OFFSET          ( 0U )

/* CLB_DYN_Cam_Height_Progress_b7 signal Min & Max range limits */
#define C_EYEQMSG_CALDYN_CLB_DYN_CAM_HEIGHT_PROGRESS_RMIN     ( 0U )
#define C_EYEQMSG_CALDYN_CLB_DYN_CAM_HEIGHT_PROGRESS_RMAX     ( 100U )
#define C_EYEQMSG_CALDYN_CLB_DYN_CAM_HEIGHT_PROGRESS_NUMR     ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_CAM_HEIGHT_PROGRESS_DEMNR    ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_CAM_HEIGHT_PROGRESS_OFFSET   ( 0U )

/* CLB_DYN_Roll_Confidence_b7 signal Min & Max range limits */
#define C_EYEQMSG_CALDYN_CLB_DYN_ROLL_CONFIDENCE_RMIN         ( 0U )
#define C_EYEQMSG_CALDYN_CLB_DYN_ROLL_CONFIDENCE_RMAX         ( 100U )
#define C_EYEQMSG_CALDYN_CLB_DYN_ROLL_CONFIDENCE_NUMR         ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_ROLL_CONFIDENCE_DEMNR        ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_ROLL_CONFIDENCE_OFFSET       ( 0U )

/* Reserved_3_b2 signal Min & Max range limits */
#define C_EYEQMSG_CALDYN_RESERVED_3_RMIN                      ( 0U )
#define C_EYEQMSG_CALDYN_RESERVED_3_RMAX                      ( 0U )
#define C_EYEQMSG_CALDYN_RESERVED_3_NUMR                      ( 1U )
#define C_EYEQMSG_CALDYN_RESERVED_3_DEMNR                     ( 1U )
#define C_EYEQMSG_CALDYN_RESERVED_3_OFFSET                    ( 0U )

/* CLB_DYN_Pitch_Confidence_b7 signal Min & Max range limits */
#define C_EYEQMSG_CALDYN_CLB_DYN_PITCH_CONFIDENCE_RMIN        ( 0U )
#define C_EYEQMSG_CALDYN_CLB_DYN_PITCH_CONFIDENCE_RMAX        ( 100U )
#define C_EYEQMSG_CALDYN_CLB_DYN_PITCH_CONFIDENCE_NUMR        ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_PITCH_CONFIDENCE_DEMNR       ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_PITCH_CONFIDENCE_OFFSET      ( 0U )

/* CLB_DYN_Yaw_Confidence_b7 signal Min & Max range limits */
#define C_EYEQMSG_CALDYN_CLB_DYN_YAW_CONFIDENCE_RMIN          ( 0U )
#define C_EYEQMSG_CALDYN_CLB_DYN_YAW_CONFIDENCE_RMAX          ( 100U )
#define C_EYEQMSG_CALDYN_CLB_DYN_YAW_CONFIDENCE_NUMR          ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_YAW_CONFIDENCE_DEMNR         ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_YAW_CONFIDENCE_OFFSET        ( 0U )

/* CLB_DYN_Cam_Height_Confidence_b7 signal Min & Max range limits */
#define C_EYEQMSG_CALDYN_CLB_DYN_CAM_HEIGHT_CONFIDENCE_RMIN   ( 0U )
#define C_EYEQMSG_CALDYN_CLB_DYN_CAM_HEIGHT_CONFIDENCE_RMAX   ( 100U )
#define C_EYEQMSG_CALDYN_CLB_DYN_CAM_HEIGHT_CONFIDENCE_NUMR   ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_CAM_HEIGHT_CONFIDENCE_DEMNR  ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_CAM_HEIGHT_CONFIDENCE_OFFSET ( 0U )

/* CLB_DYN_Pause_Reason_b5 signal Enums */
typedef uint8 CALDYNCLBDYNPauseReason;
#define C_EYEQMSG_CALDYN_CLB_DYN_PAUSE_REASON__BIT_0_LOW_SPEED ( CALDYNCLBDYNPauseReason ) ( 0U )
#define C_EYEQMSG_CALDYN_CLB_DYN_PAUSE_REASON__BIT_1_HIGH_SPEED ( CALDYNCLBDYNPauseReason ) ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_PAUSE_REASON__BIT_2_RADIUS   ( CALDYNCLBDYNPauseReason ) ( 2U )
#define C_EYEQMSG_CALDYN_CLB_DYN_PAUSE_REASON__BIT_3_ACCELERATION ( CALDYNCLBDYNPauseReason ) ( 3U )
#define C_EYEQMSG_CALDYN_CLB_DYN_PAUSE_REASON__BIT_4_INTERNAL ( CALDYNCLBDYNPauseReason ) ( 4U )

/* CLB_DYN_Pause_Reason_b5 signal Min & Max range limits */
#define C_EYEQMSG_CALDYN_CLB_DYN_PAUSE_REASON_RMIN            ( 0U )
#define C_EYEQMSG_CALDYN_CLB_DYN_PAUSE_REASON_RMAX            ( 31U )
#define C_EYEQMSG_CALDYN_CLB_DYN_PAUSE_REASON_NUMR            ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_PAUSE_REASON_DEMNR           ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_PAUSE_REASON_OFFSET          ( 0U )

/* CLB_DYN_Roll_Error_b2 signal Enums */
typedef uint8 CALDYNCLBDYNRollError;
#define C_EYEQMSG_CALDYN_CLB_DYN_ROLL_ERROR_UNKNOWN           ( CALDYNCLBDYNRollError ) ( 0U )
#define C_EYEQMSG_CALDYN_CLB_DYN_ROLL_ERROR_TIMEOUT           ( CALDYNCLBDYNRollError ) ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_ROLL_ERROR_OOR               ( CALDYNCLBDYNRollError ) ( 2U )
#define C_EYEQMSG_CALDYN_CLB_DYN_ROLL_ERROR_OK                ( CALDYNCLBDYNRollError ) ( 3U )

/* CLB_DYN_Roll_Error_b2 signal Min & Max range limits */
#define C_EYEQMSG_CALDYN_CLB_DYN_ROLL_ERROR_RMIN              ( 0U )
#define C_EYEQMSG_CALDYN_CLB_DYN_ROLL_ERROR_RMAX              ( 3U )
#define C_EYEQMSG_CALDYN_CLB_DYN_ROLL_ERROR_NUMR              ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_ROLL_ERROR_DEMNR             ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_ROLL_ERROR_OFFSET            ( 0U )

/* CLB_DYN_Pitch_Error_b2 signal Enums */
typedef uint8 CALDYNCLBDYNPitchError;
#define C_EYEQMSG_CALDYN_CLB_DYN_PITCH_ERROR_UNKNOWN          ( CALDYNCLBDYNPitchError ) ( 0U )
#define C_EYEQMSG_CALDYN_CLB_DYN_PITCH_ERROR_TIMEOUT          ( CALDYNCLBDYNPitchError ) ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_PITCH_ERROR_OOR              ( CALDYNCLBDYNPitchError ) ( 2U )
#define C_EYEQMSG_CALDYN_CLB_DYN_PITCH_ERROR_OK               ( CALDYNCLBDYNPitchError ) ( 3U )

/* CLB_DYN_Pitch_Error_b2 signal Min & Max range limits */
#define C_EYEQMSG_CALDYN_CLB_DYN_PITCH_ERROR_RMIN             ( 0U )
#define C_EYEQMSG_CALDYN_CLB_DYN_PITCH_ERROR_RMAX             ( 3U )
#define C_EYEQMSG_CALDYN_CLB_DYN_PITCH_ERROR_NUMR             ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_PITCH_ERROR_DEMNR            ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_PITCH_ERROR_OFFSET           ( 0U )

/* Reserved_2_b1 signal Min & Max range limits */
#define C_EYEQMSG_CALDYN_RESERVED_2_RMIN                      ( 0U )
#define C_EYEQMSG_CALDYN_RESERVED_2_RMAX                      ( 0U )
#define C_EYEQMSG_CALDYN_RESERVED_2_NUMR                      ( 1U )
#define C_EYEQMSG_CALDYN_RESERVED_2_DEMNR                     ( 1U )
#define C_EYEQMSG_CALDYN_RESERVED_2_OFFSET                    ( 0U )

/* CLB_DYN_Yaw_Error_b2 signal Enums */
typedef uint8 CALDYNCLBDYNYawError;
#define C_EYEQMSG_CALDYN_CLB_DYN_YAW_ERROR_UNKNOWN            ( CALDYNCLBDYNYawError ) ( 0U )
#define C_EYEQMSG_CALDYN_CLB_DYN_YAW_ERROR_TIMEOUT            ( CALDYNCLBDYNYawError ) ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_YAW_ERROR_OOR                ( CALDYNCLBDYNYawError ) ( 2U )
#define C_EYEQMSG_CALDYN_CLB_DYN_YAW_ERROR_OK                 ( CALDYNCLBDYNYawError ) ( 3U )

/* CLB_DYN_Yaw_Error_b2 signal Min & Max range limits */
#define C_EYEQMSG_CALDYN_CLB_DYN_YAW_ERROR_RMIN               ( 0U )
#define C_EYEQMSG_CALDYN_CLB_DYN_YAW_ERROR_RMAX               ( 3U )
#define C_EYEQMSG_CALDYN_CLB_DYN_YAW_ERROR_NUMR               ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_YAW_ERROR_DEMNR              ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_YAW_ERROR_OFFSET             ( 0U )

/* CLB_DYN_Cam_Height_Error_b2 signal Enums */
typedef uint8 CALDYNCLBDYNCamHeightError;
#define C_EYEQMSG_CALDYN_CLB_DYN_CAM_HEIGHT_ERROR_UNKNOWN     ( CALDYNCLBDYNCamHeightError ) ( 0U )
#define C_EYEQMSG_CALDYN_CLB_DYN_CAM_HEIGHT_ERROR_TIMEOUT     ( CALDYNCLBDYNCamHeightError ) ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_CAM_HEIGHT_ERROR_OOR         ( CALDYNCLBDYNCamHeightError ) ( 2U )
#define C_EYEQMSG_CALDYN_CLB_DYN_CAM_HEIGHT_ERROR_OK          ( CALDYNCLBDYNCamHeightError ) ( 3U )

/* CLB_DYN_Cam_Height_Error_b2 signal Min & Max range limits */
#define C_EYEQMSG_CALDYN_CLB_DYN_CAM_HEIGHT_ERROR_RMIN        ( 0U )
#define C_EYEQMSG_CALDYN_CLB_DYN_CAM_HEIGHT_ERROR_RMAX        ( 3U )
#define C_EYEQMSG_CALDYN_CLB_DYN_CAM_HEIGHT_ERROR_NUMR        ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_CAM_HEIGHT_ERROR_DEMNR       ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_CAM_HEIGHT_ERROR_OFFSET      ( 0U )

/* CLB_DYN_Roll_Status_b2 signal Enums */
typedef uint8 CALDYNCLBDYNRollStatus;
#define C_EYEQMSG_CALDYN_CLB_DYN_ROLL_STATUS_INIT             ( CALDYNCLBDYNRollStatus ) ( 0U )
#define C_EYEQMSG_CALDYN_CLB_DYN_ROLL_STATUS_SUCCESS          ( CALDYNCLBDYNRollStatus ) ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_ROLL_STATUS_ERROR            ( CALDYNCLBDYNRollStatus ) ( 2U )

/* CLB_DYN_Roll_Status_b2 signal Min & Max range limits */
#define C_EYEQMSG_CALDYN_CLB_DYN_ROLL_STATUS_RMIN             ( 0U )
#define C_EYEQMSG_CALDYN_CLB_DYN_ROLL_STATUS_RMAX             ( 2U )
#define C_EYEQMSG_CALDYN_CLB_DYN_ROLL_STATUS_NUMR             ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_ROLL_STATUS_DEMNR            ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_ROLL_STATUS_OFFSET           ( 0U )

/* CLB_DYN_Pitch_Status_b2 signal Enums */
typedef uint8 CALDYNCLBDYNPitchStatus;
#define C_EYEQMSG_CALDYN_CLB_DYN_PITCH_STATUS_INIT            ( CALDYNCLBDYNPitchStatus ) ( 0U )
#define C_EYEQMSG_CALDYN_CLB_DYN_PITCH_STATUS_SUCCESS         ( CALDYNCLBDYNPitchStatus ) ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_PITCH_STATUS_ERROR           ( CALDYNCLBDYNPitchStatus ) ( 2U )

/* CLB_DYN_Pitch_Status_b2 signal Min & Max range limits */
#define C_EYEQMSG_CALDYN_CLB_DYN_PITCH_STATUS_RMIN            ( 0U )
#define C_EYEQMSG_CALDYN_CLB_DYN_PITCH_STATUS_RMAX            ( 2U )
#define C_EYEQMSG_CALDYN_CLB_DYN_PITCH_STATUS_NUMR            ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_PITCH_STATUS_DEMNR           ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_PITCH_STATUS_OFFSET          ( 0U )

/* CLB_DYN_Yaw_Status_b2 signal Enums */
typedef uint8 CALDYNCLBDYNYawStatus;
#define C_EYEQMSG_CALDYN_CLB_DYN_YAW_STATUS_INIT              ( CALDYNCLBDYNYawStatus ) ( 0U )
#define C_EYEQMSG_CALDYN_CLB_DYN_YAW_STATUS_SUCCESS           ( CALDYNCLBDYNYawStatus ) ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_YAW_STATUS_ERROR             ( CALDYNCLBDYNYawStatus ) ( 2U )

/* CLB_DYN_Yaw_Status_b2 signal Min & Max range limits */
#define C_EYEQMSG_CALDYN_CLB_DYN_YAW_STATUS_RMIN              ( 0U )
#define C_EYEQMSG_CALDYN_CLB_DYN_YAW_STATUS_RMAX              ( 2U )
#define C_EYEQMSG_CALDYN_CLB_DYN_YAW_STATUS_NUMR              ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_YAW_STATUS_DEMNR             ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_YAW_STATUS_OFFSET            ( 0U )

/* CLB_DYN_Cam_Height_Status_b2 signal Enums */
typedef uint8 CALDYNCLBDYNCamHeightStatus;
#define C_EYEQMSG_CALDYN_CLB_DYN_CAM_HEIGHT_STATUS_INIT       ( CALDYNCLBDYNCamHeightStatus ) ( 0U )
#define C_EYEQMSG_CALDYN_CLB_DYN_CAM_HEIGHT_STATUS_SUCCESS    ( CALDYNCLBDYNCamHeightStatus ) ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_CAM_HEIGHT_STATUS_ERROR      ( CALDYNCLBDYNCamHeightStatus ) ( 2U )

/* CLB_DYN_Cam_Height_Status_b2 signal Min & Max range limits */
#define C_EYEQMSG_CALDYN_CLB_DYN_CAM_HEIGHT_STATUS_RMIN       ( 0U )
#define C_EYEQMSG_CALDYN_CLB_DYN_CAM_HEIGHT_STATUS_RMAX       ( 2U )
#define C_EYEQMSG_CALDYN_CLB_DYN_CAM_HEIGHT_STATUS_NUMR       ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_CAM_HEIGHT_STATUS_DEMNR      ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_CAM_HEIGHT_STATUS_OFFSET     ( 0U )

/* CLB_DYN_Run_Mode_b3 signal Enums */
typedef uint8 CALDYNCLBDYNRunMode;
#define C_EYEQMSG_CALDYN_CLB_DYN_RUN_MODE_NONE                ( CALDYNCLBDYNRunMode ) ( 0U )
#define C_EYEQMSG_CALDYN_CLB_DYN_RUN_MODE_AUTOFIX             ( CALDYNCLBDYNRunMode ) ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_RUN_MODE_SPC                 ( CALDYNCLBDYNRunMode ) ( 2U )

/* CLB_DYN_Run_Mode_b3 signal Min & Max range limits */
#define C_EYEQMSG_CALDYN_CLB_DYN_RUN_MODE_RMIN                ( 0U )
#define C_EYEQMSG_CALDYN_CLB_DYN_RUN_MODE_RMAX                ( 6U )
#define C_EYEQMSG_CALDYN_CLB_DYN_RUN_MODE_NUMR                ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_RUN_MODE_DEMNR               ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_RUN_MODE_OFFSET              ( 0U )

/* CLB_DYN_Sync_ID_b8 signal Min & Max range limits */
#define C_EYEQMSG_CALDYN_CLB_DYN_SYNC_ID_RMIN                 ( 0U )
#define C_EYEQMSG_CALDYN_CLB_DYN_SYNC_ID_RMAX                 ( 255U )
#define C_EYEQMSG_CALDYN_CLB_DYN_SYNC_ID_NUMR                 ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_SYNC_ID_DEMNR                ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_SYNC_ID_OFFSET               ( 0U )

/* CLB_DYN_Protocol_Version_b8 signal Min & Max range limits */
#define C_EYEQMSG_CALDYN_CLB_DYN_PROTOCOL_VERSION_RMIN        ( 6U )
#define C_EYEQMSG_CALDYN_CLB_DYN_PROTOCOL_VERSION_RMAX        ( 6U )
#define C_EYEQMSG_CALDYN_CLB_DYN_PROTOCOL_VERSION_NUMR        ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_PROTOCOL_VERSION_DEMNR       ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_PROTOCOL_VERSION_OFFSET      ( 0U )

/* CLB_DYN_Header_CRC_b32 signal Min & Max range limits */
#define C_EYEQMSG_CALDYN_CLB_DYN_HEADER_CRC_RMIN              ( 0U )
#define C_EYEQMSG_CALDYN_CLB_DYN_HEADER_CRC_RMAX              ( 4294967295U )
#define C_EYEQMSG_CALDYN_CLB_DYN_HEADER_CRC_NUMR              ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_HEADER_CRC_DEMNR             ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_HEADER_CRC_OFFSET            ( 0U )

/* Reserved_1_b24 signal Min & Max range limits */
#define C_EYEQMSG_CALDYN_RESERVED_1_RMIN                      ( 0U )
#define C_EYEQMSG_CALDYN_RESERVED_1_RMAX                      ( 0U )
#define C_EYEQMSG_CALDYN_RESERVED_1_NUMR                      ( 1U )
#define C_EYEQMSG_CALDYN_RESERVED_1_DEMNR                     ( 1U )
#define C_EYEQMSG_CALDYN_RESERVED_1_OFFSET                    ( 0U )

/* CLB_DYN_Zero_byte_b8 signal Min & Max range limits */
#define C_EYEQMSG_CALDYN_CLB_DYN_ZERO_BYTE_RMIN               ( 0U )
#define C_EYEQMSG_CALDYN_CLB_DYN_ZERO_BYTE_RMAX               ( 255U )
#define C_EYEQMSG_CALDYN_CLB_DYN_ZERO_BYTE_NUMR               ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_ZERO_BYTE_DEMNR              ( 1U )
#define C_EYEQMSG_CALDYN_CLB_DYN_ZERO_BYTE_OFFSET             ( 0U )


/*****************************************************************************
                  Exported function-like macros
*****************************************************************************/
/*****************************************************************************
                  Exported defined macros
*****************************************************************************/
/*****************************************************************************
                  Exported types, enums definitions
*****************************************************************************/
typedef struct
{
   #if ENABLE_BIG_ENDIAN_FORMAT
      uint32        CLB_DYN_Zero_byte_b8                         : 8U;
      
      uint32        Reserved_1_1_b8                              : 8U;
      
      uint32        Reserved_1_2_b8                              : 8U;
      
      uint32        Reserved_1_3_b8                              : 8U;
      
      uint32        CLB_DYN_Header_CRC_1_b8                      : 8U;
      
      uint32        CLB_DYN_Header_CRC_2_b8                      : 8U;
      
      uint32        CLB_DYN_Header_CRC_3_b8                      : 8U;
      
      uint32        CLB_DYN_Header_CRC_4_b8                      : 8U;
      
      uint32        CLB_DYN_Protocol_Version_b8                  : 8U;
      
      uint32        CLB_DYN_Sync_ID_b8                           : 8U;
      
      uint32        unused1_b5                                   : 5;
      uint32        CLB_DYN_Run_Mode_b3                          : 3U;
      
      uint32        CLB_DYN_Cam_Height_Status_b2                 : 2U;
      
      uint32        CLB_DYN_Yaw_Status_b2                        : 2U;
      
      uint32        CLB_DYN_Pitch_Status_1_b1                    : 1U;
      
      uint32        unused2_b2                                   : 2;
      uint32        CLB_DYN_Pitch_Status_2_b1                    : 1U;
      
      uint32        CLB_DYN_Roll_Status_b2                       : 2U;
      
      uint32        CLB_DYN_Cam_Height_Error_b2                  : 2U;
      
      uint32        CLB_DYN_Yaw_Error_b2                         : 2U;
      
      uint32        Reserved_2_b1                                : 1U;
      
      uint32        CLB_DYN_Pitch_Error_b2                       : 2U;
      
      uint32        CLB_DYN_Roll_Error_b2                        : 2U;
      
      uint32        CLB_DYN_Pause_Reason_1_b4                    : 4U;
      
      uint32        CLB_DYN_Pause_Reason_2_b1                    : 1U;
      
      uint32        CLB_DYN_Cam_Height_Confidence_b7             : 7U;
      
      uint32        CLB_DYN_Yaw_Confidence_b7                    : 7U;
      
      uint32        CLB_DYN_Pitch_Confidence_1_b1                : 1U;
      
      uint32        CLB_DYN_Pitch_Confidence_2_b6                : 6U;
      
      uint32        Reserved_3_b2                                : 2U;
      
      uint32        CLB_DYN_Roll_Confidence_b7                   : 7U;
      
      uint32        CLB_DYN_Cam_Height_Progress_1_b1             : 1U;
      
      uint32        CLB_DYN_Cam_Height_Progress_2_b6             : 6U;
      
      uint32        CLB_DYN_Yaw_Progress_1_b2                    : 2U;
      
      uint32        CLB_DYN_Yaw_Progress_2_b5                    : 5U;
      
      uint32        CLB_DYN_Pitch_Progress_1_b3                  : 3U;
      
      uint32        CLB_DYN_Pitch_Progress_2_b4                  : 4U;
      
      uint32        Reserved_4_b4                                : 4U;
      
      uint32        CLB_DYN_Roll_Progress_b7                     : 7U;
      
      uint32        CLB_DYN_Total_Cam_Height_Time_1_b1           : 1U;
      
      uint32        CLB_DYN_Total_Cam_Height_Time_2_b8           : 8U;
      
      uint32        CLB_DYN_Total_Cam_Height_Time_3_b3           : 3U;
      
      uint32        Reserved_5_1_b5                              : 5U;
      
      uint32        Reserved_5_2_b8                              : 8U;
      
      uint32        CLB_DYN_Total_Cam_Height_Dist_1_b8           : 8U;
      
      uint32        CLB_DYN_Total_Cam_Height_Dist_2_b7           : 7U;
      
      uint32        CLB_DYN_Total_Yaw_Time_1_b1                  : 1U;
      
      uint32        CLB_DYN_Total_Yaw_Time_2_b8                  : 8U;
      
      uint32        CLB_DYN_Total_Yaw_Time_3_b3                  : 3U;
      
      uint32        Reserved_6_b5                                : 5U;
      
      uint32        CLB_DYN_Total_Yaw_Dist_1_b8                  : 8U;
      
      uint32        CLB_DYN_Total_Yaw_Dist_2_b7                  : 7U;
      
      uint32        CLB_DYN_Total_Pitch_Time_1_b1                : 1U;
      
      uint32        CLB_DYN_Total_Pitch_Time_2_b8                : 8U;
      
      uint32        CLB_DYN_Total_Pitch_Time_3_b3                : 3U;
      
      uint32        Reserved_7_b5                                : 5U;
      
      uint32        CLB_DYN_Total_Pitch_Dist_1_b8                : 8U;
      
      uint32        CLB_DYN_Total_Pitch_Dist_2_b7                : 7U;
      
      uint32        CLB_DYN_Total_Roll_Time_1_b1                 : 1U;
      
      uint32        CLB_DYN_Total_Roll_Time_2_b8                 : 8U;
      
      uint32        CLB_DYN_Total_Roll_Time_3_b3                 : 3U;
      
      uint32        Reserved_8_b5                                : 5U;
      
      uint32        CLB_DYN_Total_Roll_Dist_1_b8                 : 8U;
      
      uint32        CLB_DYN_Total_Roll_Dist_2_b7                 : 7U;
      
      uint32        CLB_DYN_Header_Buffer_1_b1                   : 1U;
      
      uint32        CLB_DYN_Header_Buffer_2_b8                   : 8U;
      
      uint32        CLB_DYN_Header_Buffer_3_b8                   : 8U;
      
      uint32        CLB_DYN_CRC_1_b8                             : 8U;
      
      uint32        CLB_DYN_CRC_2_b8                             : 8U;
      
      uint32        CLB_DYN_CRC_3_b8                             : 8U;
      
      uint32        CLB_DYN_CRC_4_b8                             : 8U;
      
      uint32        CLB_DYN_Yaw_Deg_1_sb8                        : 8U;
      
      uint32        CLB_DYN_Yaw_Deg_2_sb8                        : 8U;
      
      uint32        CLB_DYN_Yaw_Deg_3_sb8                        : 8U;
      
      uint32        CLB_DYN_Yaw_Deg_4_sb8                        : 8U;
      
      uint32        CLB_DYN_Pitch_Deg_1_sb8                      : 8U;
      
      uint32        CLB_DYN_Pitch_Deg_2_sb8                      : 8U;
      
      uint32        CLB_DYN_Pitch_Deg_3_sb8                      : 8U;
      
      uint32        CLB_DYN_Pitch_Deg_4_sb8                      : 8U;
      
      uint32        CLB_DYN_Yaw_Px_1_b8                          : 8U;
      
      uint32        CLB_DYN_Yaw_Px_2_b8                          : 8U;
      
      uint32        CLB_DYN_Pitch_Px_1_b8                        : 8U;
      
      uint32        CLB_DYN_Pitch_Px_2_b8                        : 8U;
      
      uint32        CLB_DYN_Roll_1_sb8                           : 8U;
      
      uint32        CLB_DYN_Roll_2_sb8                           : 8U;
      
      uint32        CLB_DYN_Roll_3_sb8                           : 8U;
      
      uint32        CLB_DYN_Roll_4_sb8                           : 8U;
      
      uint32        CLB_DYN_Cam_Height_1_b8                      : 8U;
      
      uint32        CLB_DYN_Cam_Height_2_b8                      : 8U;
      
      uint32        CLB_DYN_Buffer_1_b8                          : 8U;
      
      uint32        CLB_DYN_Buffer_2_b8                          : 8U;
      
   #else
      uint32        CLB_DYN_Zero_byte_b8                         : 8U;
      
      uint32        Reserved_1_b24                               : 24U;
      
      uint32        CLB_DYN_Header_CRC_b32                       : 32U;
      
      uint32        CLB_DYN_Protocol_Version_b8                  : 8U;
      
      uint32        CLB_DYN_Sync_ID_b8                           : 8U;
      
      uint32        CLB_DYN_Run_Mode_b3                          : 3U;
      
      uint32        CLB_DYN_Cam_Height_Status_b2                 : 2U;
      
      uint32        CLB_DYN_Yaw_Status_b2                        : 2U;
      
      uint32        CLB_DYN_Pitch_Status_b2                      : 2U;
      
      uint32        CLB_DYN_Roll_Status_b2                       : 2U;
      
      uint32        CLB_DYN_Cam_Height_Error_b2                  : 2U;
      
      uint32        CLB_DYN_Yaw_Error_b2                         : 2U;
      
      uint32        Reserved_2_b1                                : 1U;
      
      uint32        CLB_DYN_Pitch_Error_b2                       : 2U;
      
      uint32        CLB_DYN_Roll_Error_b2                        : 2U;
      
      uint32        CLB_DYN_Pause_Reason_b5                      : 5U;
      
      uint32        CLB_DYN_Cam_Height_Confidence_b7             : 7U;
      
      uint32        CLB_DYN_Yaw_Confidence_b7                    : 7U;
      
      uint32        CLB_DYN_Pitch_Confidence_b7                  : 7U;
      
      uint32        Reserved_3_b2                                : 2U;
      
      uint32        CLB_DYN_Roll_Confidence_b7                   : 7U;
      
      uint32        CLB_DYN_Cam_Height_Progress_b7               : 7U;
      
      uint32        CLB_DYN_Yaw_Progress_b7                      : 7U;
      
      uint32        CLB_DYN_Pitch_Progress_b7                    : 7U;
      
      uint32        Reserved_4_b4                                : 4U;
      
      uint32        CLB_DYN_Roll_Progress_b7                     : 7U;
      
      uint32        CLB_DYN_Total_Cam_Height_Time_b12            : 12U;
      
      uint32        Reserved_5_b13                               : 13U;
      
      uint32        CLB_DYN_Total_Cam_Height_Dist_b15            : 15U;
      
      uint32        CLB_DYN_Total_Yaw_Time_b12                   : 12U;
      
      uint32        Reserved_6_b5                                : 5U;
      
      uint32        CLB_DYN_Total_Yaw_Dist_b15                   : 15U;
      
      uint32        CLB_DYN_Total_Pitch_Time_b12                 : 12U;
      
      uint32        Reserved_7_b5                                : 5U;
      
      uint32        CLB_DYN_Total_Pitch_Dist_b15                 : 15U;
      
      uint32        CLB_DYN_Total_Roll_Time_b12                  : 12U;
      
      uint32        Reserved_8_b5                                : 5U;
      
      uint32        CLB_DYN_Total_Roll_Dist_b15                  : 15U;
      
      uint32        CLB_DYN_Header_Buffer_b17                    : 17U;
      
      uint32        CLB_DYN_CRC_b32                              : 32U;
      
      sint32        CLB_DYN_Yaw_Deg_sb32                         : 32;
      
      sint32        CLB_DYN_Pitch_Deg_sb32                       : 32;
      
      uint32        CLB_DYN_Yaw_Px_b16                           : 16U;
      
      uint32        CLB_DYN_Pitch_Px_b16                         : 16U;
      
      sint32        CLB_DYN_Roll_sb32                            : 32;
      
      uint32        CLB_DYN_Cam_Height_b16                       : 16U;
      
      uint32        CLB_DYN_Buffer_b16                           : 16U;
      
   #endif
} EYEQMSG_CALDYN_Params_t;


/*****************************************************************************
                  Exported function prototypes
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_CALDYN_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_CALDYN_Params_t * pCore_Calibration_Dynamic_protocol - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_Calibration_Dynamic_protocol message 
*    Core_Calibration_Dynamic_protocol message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_Calibration_Dynamic_protocol message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_CALDYN_ParamsApp_MsgDataStruct( EYEQMSG_CALDYN_Params_t * pCore_Calibration_Dynamic_protocol );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pCLB_DYN_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Zero_byte
*    CLB_DYN_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Zero_byte signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Zero_byte( uint8 * pCLB_DYN_Zero_byte );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_Reserved_1
*
* FUNCTION ARGUMENTS:
*    uint32 * pReserved_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1
*    Reserved_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1 signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_Reserved_1( uint32 * pReserved_1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Header_CRC
*
* FUNCTION ARGUMENTS:
*    uint32 * pCLB_DYN_Header_CRC - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Header_CRC
*    CLB_DYN_Header_CRC returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Header_CRC signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Header_CRC( uint32 * pCLB_DYN_Header_CRC );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pCLB_DYN_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Protocol_Version
*    CLB_DYN_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Protocol_Version signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Protocol_Version( uint8 * pCLB_DYN_Protocol_Version );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Sync_ID
*
* FUNCTION ARGUMENTS:
*    uint8 * pCLB_DYN_Sync_ID - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Sync_ID
*    CLB_DYN_Sync_ID returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Sync_ID signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Sync_ID( uint8 * pCLB_DYN_Sync_ID );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Run_Mode
*
* FUNCTION ARGUMENTS:
*    CALDYNCLBDYNRunMode * pCLB_DYN_Run_Mode - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Run_Mode
*    CLB_DYN_Run_Mode returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Run_Mode signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Run_Mode( CALDYNCLBDYNRunMode * pCLB_DYN_Run_Mode );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Cam_Height_Status
*
* FUNCTION ARGUMENTS:
*    CALDYNCLBDYNCamHeightStatus * pCLB_DYN_Cam_Height_Status - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Cam_Height_Status
*    CLB_DYN_Cam_Height_Status returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Cam_Height_Status signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Cam_Height_Status( CALDYNCLBDYNCamHeightStatus * pCLB_DYN_Cam_Height_Status );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Yaw_Status
*
* FUNCTION ARGUMENTS:
*    CALDYNCLBDYNYawStatus * pCLB_DYN_Yaw_Status - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Yaw_Status
*    CLB_DYN_Yaw_Status returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Yaw_Status signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Yaw_Status( CALDYNCLBDYNYawStatus * pCLB_DYN_Yaw_Status );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Pitch_Status
*
* FUNCTION ARGUMENTS:
*    CALDYNCLBDYNPitchStatus * pCLB_DYN_Pitch_Status - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Pitch_Status
*    CLB_DYN_Pitch_Status returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Pitch_Status signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Pitch_Status( CALDYNCLBDYNPitchStatus * pCLB_DYN_Pitch_Status );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Roll_Status
*
* FUNCTION ARGUMENTS:
*    CALDYNCLBDYNRollStatus * pCLB_DYN_Roll_Status - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Roll_Status
*    CLB_DYN_Roll_Status returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Roll_Status signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Roll_Status( CALDYNCLBDYNRollStatus * pCLB_DYN_Roll_Status );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Cam_Height_Error
*
* FUNCTION ARGUMENTS:
*    CALDYNCLBDYNCamHeightError * pCLB_DYN_Cam_Height_Error - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Cam_Height_Error
*    CLB_DYN_Cam_Height_Error returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Cam_Height_Error signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Cam_Height_Error( CALDYNCLBDYNCamHeightError * pCLB_DYN_Cam_Height_Error );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Yaw_Error
*
* FUNCTION ARGUMENTS:
*    CALDYNCLBDYNYawError * pCLB_DYN_Yaw_Error - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Yaw_Error
*    CLB_DYN_Yaw_Error returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Yaw_Error signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Yaw_Error( CALDYNCLBDYNYawError * pCLB_DYN_Yaw_Error );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_Reserved_2
*
* FUNCTION ARGUMENTS:
*    boolean * pReserved_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_2
*    Reserved_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_2 signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_Reserved_2( boolean * pReserved_2 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Pitch_Error
*
* FUNCTION ARGUMENTS:
*    CALDYNCLBDYNPitchError * pCLB_DYN_Pitch_Error - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Pitch_Error
*    CLB_DYN_Pitch_Error returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Pitch_Error signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Pitch_Error( CALDYNCLBDYNPitchError * pCLB_DYN_Pitch_Error );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Roll_Error
*
* FUNCTION ARGUMENTS:
*    CALDYNCLBDYNRollError * pCLB_DYN_Roll_Error - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Roll_Error
*    CLB_DYN_Roll_Error returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Roll_Error signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Roll_Error( CALDYNCLBDYNRollError * pCLB_DYN_Roll_Error );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Pause_Reason
*
* FUNCTION ARGUMENTS:
*    CALDYNCLBDYNPauseReason * pCLB_DYN_Pause_Reason - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Pause_Reason
*    CLB_DYN_Pause_Reason returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Pause_Reason signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Pause_Reason( CALDYNCLBDYNPauseReason * pCLB_DYN_Pause_Reason );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Cam_Height_Confidence
*
* FUNCTION ARGUMENTS:
*    uint8 * pCLB_DYN_Cam_Height_Confidence - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Cam_Height_Confidence
*    CLB_DYN_Cam_Height_Confidence returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Cam_Height_Confidence signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Cam_Height_Confidence( uint8 * pCLB_DYN_Cam_Height_Confidence );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Yaw_Confidence
*
* FUNCTION ARGUMENTS:
*    uint8 * pCLB_DYN_Yaw_Confidence - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Yaw_Confidence
*    CLB_DYN_Yaw_Confidence returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Yaw_Confidence signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Yaw_Confidence( uint8 * pCLB_DYN_Yaw_Confidence );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Pitch_Confidence
*
* FUNCTION ARGUMENTS:
*    uint8 * pCLB_DYN_Pitch_Confidence - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Pitch_Confidence
*    CLB_DYN_Pitch_Confidence returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Pitch_Confidence signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Pitch_Confidence( uint8 * pCLB_DYN_Pitch_Confidence );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_Reserved_3
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_3
*    Reserved_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_3 signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_Reserved_3( uint8 * pReserved_3 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Roll_Confidence
*
* FUNCTION ARGUMENTS:
*    uint8 * pCLB_DYN_Roll_Confidence - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Roll_Confidence
*    CLB_DYN_Roll_Confidence returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Roll_Confidence signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Roll_Confidence( uint8 * pCLB_DYN_Roll_Confidence );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Cam_Height_Progress
*
* FUNCTION ARGUMENTS:
*    uint8 * pCLB_DYN_Cam_Height_Progress - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Cam_Height_Progress
*    CLB_DYN_Cam_Height_Progress returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Cam_Height_Progress signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Cam_Height_Progress( uint8 * pCLB_DYN_Cam_Height_Progress );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Yaw_Progress
*
* FUNCTION ARGUMENTS:
*    uint8 * pCLB_DYN_Yaw_Progress - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Yaw_Progress
*    CLB_DYN_Yaw_Progress returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Yaw_Progress signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Yaw_Progress( uint8 * pCLB_DYN_Yaw_Progress );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Pitch_Progress
*
* FUNCTION ARGUMENTS:
*    uint8 * pCLB_DYN_Pitch_Progress - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Pitch_Progress
*    CLB_DYN_Pitch_Progress returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Pitch_Progress signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Pitch_Progress( uint8 * pCLB_DYN_Pitch_Progress );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_Reserved_4
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_4
*    Reserved_4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_4 signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_Reserved_4( uint8 * pReserved_4 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Roll_Progress
*
* FUNCTION ARGUMENTS:
*    uint8 * pCLB_DYN_Roll_Progress - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Roll_Progress
*    CLB_DYN_Roll_Progress returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Roll_Progress signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Roll_Progress( uint8 * pCLB_DYN_Roll_Progress );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Total_Cam_Height_Time
*
* FUNCTION ARGUMENTS:
*    uint16 * pCLB_DYN_Total_Cam_Height_Time - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Total_Cam_Height_Time
*    CLB_DYN_Total_Cam_Height_Time returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Total_Cam_Height_Time signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Total_Cam_Height_Time( uint16 * pCLB_DYN_Total_Cam_Height_Time );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_Reserved_5
*
* FUNCTION ARGUMENTS:
*    uint16 * pReserved_5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_5
*    Reserved_5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_5 signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_Reserved_5( uint16 * pReserved_5 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Total_Cam_Height_Dist
*
* FUNCTION ARGUMENTS:
*    uint16 * pCLB_DYN_Total_Cam_Height_Dist - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Total_Cam_Height_Dist
*    CLB_DYN_Total_Cam_Height_Dist returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Total_Cam_Height_Dist signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Total_Cam_Height_Dist( uint16 * pCLB_DYN_Total_Cam_Height_Dist );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Total_Yaw_Time
*
* FUNCTION ARGUMENTS:
*    uint16 * pCLB_DYN_Total_Yaw_Time - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Total_Yaw_Time
*    CLB_DYN_Total_Yaw_Time returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Total_Yaw_Time signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Total_Yaw_Time( uint16 * pCLB_DYN_Total_Yaw_Time );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_Reserved_6
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_6 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_6
*    Reserved_6 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_6 signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_Reserved_6( uint8 * pReserved_6 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Total_Yaw_Dist
*
* FUNCTION ARGUMENTS:
*    uint16 * pCLB_DYN_Total_Yaw_Dist - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Total_Yaw_Dist
*    CLB_DYN_Total_Yaw_Dist returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Total_Yaw_Dist signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Total_Yaw_Dist( uint16 * pCLB_DYN_Total_Yaw_Dist );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Total_Pitch_Time
*
* FUNCTION ARGUMENTS:
*    uint16 * pCLB_DYN_Total_Pitch_Time - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Total_Pitch_Time
*    CLB_DYN_Total_Pitch_Time returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Total_Pitch_Time signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Total_Pitch_Time( uint16 * pCLB_DYN_Total_Pitch_Time );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_Reserved_7
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_7 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_7
*    Reserved_7 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_7 signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_Reserved_7( uint8 * pReserved_7 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Total_Pitch_Dist
*
* FUNCTION ARGUMENTS:
*    uint16 * pCLB_DYN_Total_Pitch_Dist - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Total_Pitch_Dist
*    CLB_DYN_Total_Pitch_Dist returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Total_Pitch_Dist signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Total_Pitch_Dist( uint16 * pCLB_DYN_Total_Pitch_Dist );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Total_Roll_Time
*
* FUNCTION ARGUMENTS:
*    uint16 * pCLB_DYN_Total_Roll_Time - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Total_Roll_Time
*    CLB_DYN_Total_Roll_Time returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Total_Roll_Time signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Total_Roll_Time( uint16 * pCLB_DYN_Total_Roll_Time );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_Reserved_8
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_8 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_8
*    Reserved_8 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_8 signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_Reserved_8( uint8 * pReserved_8 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Total_Roll_Dist
*
* FUNCTION ARGUMENTS:
*    uint16 * pCLB_DYN_Total_Roll_Dist - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Total_Roll_Dist
*    CLB_DYN_Total_Roll_Dist returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Total_Roll_Dist signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Total_Roll_Dist( uint16 * pCLB_DYN_Total_Roll_Dist );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Header_Buffer
*
* FUNCTION ARGUMENTS:
*    uint32 * pCLB_DYN_Header_Buffer - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Header_Buffer
*    CLB_DYN_Header_Buffer returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Header_Buffer signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Header_Buffer( uint32 * pCLB_DYN_Header_Buffer );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_CRC
*
* FUNCTION ARGUMENTS:
*    uint32 * pCLB_DYN_CRC - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_CRC
*    CLB_DYN_CRC returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_CRC signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_CRC( uint32 * pCLB_DYN_CRC );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Yaw_Deg
*
* FUNCTION ARGUMENTS:
*    float32 * pCLB_DYN_Yaw_Deg - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Yaw_Deg
*    CLB_DYN_Yaw_Deg returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Yaw_Deg signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Yaw_Deg( float32 * pCLB_DYN_Yaw_Deg );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Pitch_Deg
*
* FUNCTION ARGUMENTS:
*    float32 * pCLB_DYN_Pitch_Deg - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Pitch_Deg
*    CLB_DYN_Pitch_Deg returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Pitch_Deg signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Pitch_Deg( float32 * pCLB_DYN_Pitch_Deg );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Yaw_Px
*
* FUNCTION ARGUMENTS:
*    uint16 * pCLB_DYN_Yaw_Px - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Yaw_Px
*    CLB_DYN_Yaw_Px returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Yaw_Px signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Yaw_Px( uint16 * pCLB_DYN_Yaw_Px );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Pitch_Px
*
* FUNCTION ARGUMENTS:
*    uint16 * pCLB_DYN_Pitch_Px - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Pitch_Px
*    CLB_DYN_Pitch_Px returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Pitch_Px signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Pitch_Px( uint16 * pCLB_DYN_Pitch_Px );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Roll
*
* FUNCTION ARGUMENTS:
*    float32 * pCLB_DYN_Roll - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Roll
*    CLB_DYN_Roll returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Roll signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Roll( float32 * pCLB_DYN_Roll );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Cam_Height
*
* FUNCTION ARGUMENTS:
*    uint16 * pCLB_DYN_Cam_Height - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Cam_Height
*    CLB_DYN_Cam_Height returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Cam_Height signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Cam_Height( uint16 * pCLB_DYN_Cam_Height );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CALDYN_CLB_DYN_Buffer
*
* FUNCTION ARGUMENTS:
*    uint16 * pCLB_DYN_Buffer - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_DYN_Buffer
*    CLB_DYN_Buffer returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_DYN_Buffer signal value of Core_Calibration_Dynamic_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CALDYN_CLB_DYN_Buffer( uint16 * pCLB_DYN_Buffer );
/*****************************************************************************
                  Exported object declarations
*****************************************************************************/
extern EYEQMSG_CALDYN_Params_t   EYEQMSG_CALDYN_Params_s;
extern EYEQMSG_CALDYN_Params_t   EYEQMSG_CALDYN_ParamsApp_s;
/****************************************************************************/
#endif /* _EYEQMSG_CALDYNPROCESS_H_ */


