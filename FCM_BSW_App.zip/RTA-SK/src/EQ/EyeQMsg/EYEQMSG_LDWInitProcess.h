#ifndef _EYEQMSG_LDWINITPROCESS_H_
#define _EYEQMSG_LDWINITPROCESS_H_

/*****************************************************************************
                  Included header files
*****************************************************************************/
#include <Std_Types.h>

/*****************************************************************************
                  Include files
*****************************************************************************/
/*****************************************************************************
                  Exported symbolic constants
*****************************************************************************/

/* Datagram message ID */
#define C_EYEQMSG_LDWINIT_MSG_ID                              ( 0xDBU )

/* Datagram message lengths */
#define C_EYEQMSG_LDWINIT_MSG_LEN                             ( sizeof(EYEQMSG_LDWINIT_Params_t) )

/* Protocol ENUMs */

/* MCU output messages */

/* LDW_Init Enums */
/* Reserved_10_b10 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_RESERVED_10_RMIN                    ( 0U )
#define C_EYEQMSG_LDWINIT_RESERVED_10_RMAX                    ( 0U )
#define C_EYEQMSG_LDWINIT_RESERVED_10_NUMR                    ( 1U )
#define C_EYEQMSG_LDWINIT_RESERVED_10_DEMNR                   ( 1U )
#define C_EYEQMSG_LDWINIT_RESERVED_10_OFFSET                  ( 0U )

/* inner_curve_tlc_shift_thresh_3_b11 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_INNER_CURVE_TLC_SHIFT_THRESH_3_RMIN ( 0U )
#define C_EYEQMSG_LDWINIT_INNER_CURVE_TLC_SHIFT_THRESH_3_RMAX ( 600U )
#define C_EYEQMSG_LDWINIT_INNER_CURVE_TLC_SHIFT_THRESH_3_NUMR ( 1 )
#define C_EYEQMSG_LDWINIT_INNER_CURVE_TLC_SHIFT_THRESH_3_DEMNR ( 100 )
#define C_EYEQMSG_LDWINIT_INNER_CURVE_TLC_SHIFT_THRESH_3_OFFSET ( -3 )

/* inner_curve_tlc_shift_thresh_2_b11 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_INNER_CURVE_TLC_SHIFT_THRESH_2_RMIN ( 0U )
#define C_EYEQMSG_LDWINIT_INNER_CURVE_TLC_SHIFT_THRESH_2_RMAX ( 600U )
#define C_EYEQMSG_LDWINIT_INNER_CURVE_TLC_SHIFT_THRESH_2_NUMR ( 1 )
#define C_EYEQMSG_LDWINIT_INNER_CURVE_TLC_SHIFT_THRESH_2_DEMNR ( 100 )
#define C_EYEQMSG_LDWINIT_INNER_CURVE_TLC_SHIFT_THRESH_2_OFFSET ( -3 )

/* Reserved_9_b10 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_RESERVED_9_RMIN                     ( 0U )
#define C_EYEQMSG_LDWINIT_RESERVED_9_RMAX                     ( 0U )
#define C_EYEQMSG_LDWINIT_RESERVED_9_NUMR                     ( 1U )
#define C_EYEQMSG_LDWINIT_RESERVED_9_DEMNR                    ( 1U )
#define C_EYEQMSG_LDWINIT_RESERVED_9_OFFSET                   ( 0U )

/* inner_curve_tlc_shift_thresh_1_b11 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_INNER_CURVE_TLC_SHIFT_THRESH_1_RMIN ( 0U )
#define C_EYEQMSG_LDWINIT_INNER_CURVE_TLC_SHIFT_THRESH_1_RMAX ( 600U )
#define C_EYEQMSG_LDWINIT_INNER_CURVE_TLC_SHIFT_THRESH_1_NUMR ( 1 )
#define C_EYEQMSG_LDWINIT_INNER_CURVE_TLC_SHIFT_THRESH_1_DEMNR ( 100 )
#define C_EYEQMSG_LDWINIT_INNER_CURVE_TLC_SHIFT_THRESH_1_OFFSET ( -3 )

/* inner_curve_tlc_shift_thresh_0_b11 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_INNER_CURVE_TLC_SHIFT_THRESH_0_RMIN ( 0U )
#define C_EYEQMSG_LDWINIT_INNER_CURVE_TLC_SHIFT_THRESH_0_RMAX ( 600U )
#define C_EYEQMSG_LDWINIT_INNER_CURVE_TLC_SHIFT_THRESH_0_NUMR ( 1 )
#define C_EYEQMSG_LDWINIT_INNER_CURVE_TLC_SHIFT_THRESH_0_DEMNR ( 100 )
#define C_EYEQMSG_LDWINIT_INNER_CURVE_TLC_SHIFT_THRESH_0_OFFSET ( -3 )

/* Reserved_8_b5 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_RESERVED_8_RMIN                     ( 0U )
#define C_EYEQMSG_LDWINIT_RESERVED_8_RMAX                     ( 0U )
#define C_EYEQMSG_LDWINIT_RESERVED_8_NUMR                     ( 1U )
#define C_EYEQMSG_LDWINIT_RESERVED_8_DEMNR                    ( 1U )
#define C_EYEQMSG_LDWINIT_RESERVED_8_OFFSET                   ( 0U )

/* inner_curve_tlc_reduced_3_b9 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_INNER_CURVE_TLC_REDUCED_3_RMIN      ( 0U )
#define C_EYEQMSG_LDWINIT_INNER_CURVE_TLC_REDUCED_3_RMAX      ( 200U )
#define C_EYEQMSG_LDWINIT_INNER_CURVE_TLC_REDUCED_3_NUMR      ( 1U )
#define C_EYEQMSG_LDWINIT_INNER_CURVE_TLC_REDUCED_3_DEMNR     ( 100U )
#define C_EYEQMSG_LDWINIT_INNER_CURVE_TLC_REDUCED_3_OFFSET    ( 0U )

/* inner_curve_tlc_reduced_2_b9 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_INNER_CURVE_TLC_REDUCED_2_RMIN      ( 0U )
#define C_EYEQMSG_LDWINIT_INNER_CURVE_TLC_REDUCED_2_RMAX      ( 200U )
#define C_EYEQMSG_LDWINIT_INNER_CURVE_TLC_REDUCED_2_NUMR      ( 1U )
#define C_EYEQMSG_LDWINIT_INNER_CURVE_TLC_REDUCED_2_DEMNR     ( 100U )
#define C_EYEQMSG_LDWINIT_INNER_CURVE_TLC_REDUCED_2_OFFSET    ( 0U )

/* inner_curve_tlc_reduced_1_b9 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_INNER_CURVE_TLC_REDUCED_1_RMIN      ( 0U )
#define C_EYEQMSG_LDWINIT_INNER_CURVE_TLC_REDUCED_1_RMAX      ( 200U )
#define C_EYEQMSG_LDWINIT_INNER_CURVE_TLC_REDUCED_1_NUMR      ( 1U )
#define C_EYEQMSG_LDWINIT_INNER_CURVE_TLC_REDUCED_1_DEMNR     ( 100U )
#define C_EYEQMSG_LDWINIT_INNER_CURVE_TLC_REDUCED_1_OFFSET    ( 0U )

/* Reserved_7_b5 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_RESERVED_7_RMIN                     ( 0U )
#define C_EYEQMSG_LDWINIT_RESERVED_7_RMAX                     ( 0U )
#define C_EYEQMSG_LDWINIT_RESERVED_7_NUMR                     ( 1U )
#define C_EYEQMSG_LDWINIT_RESERVED_7_DEMNR                    ( 1U )
#define C_EYEQMSG_LDWINIT_RESERVED_7_OFFSET                   ( 0U )

/* inner_curve_tlc_reduced_0_b9 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_INNER_CURVE_TLC_REDUCED_0_RMIN      ( 0U )
#define C_EYEQMSG_LDWINIT_INNER_CURVE_TLC_REDUCED_0_RMAX      ( 200U )
#define C_EYEQMSG_LDWINIT_INNER_CURVE_TLC_REDUCED_0_NUMR      ( 1U )
#define C_EYEQMSG_LDWINIT_INNER_CURVE_TLC_REDUCED_0_DEMNR     ( 100U )
#define C_EYEQMSG_LDWINIT_INNER_CURVE_TLC_REDUCED_0_OFFSET    ( 0U )

/* corridor_outer_boundary_3_b9 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_CORRIDOR_OUTER_BOUNDARY_3_RMIN      ( 0U )
#define C_EYEQMSG_LDWINIT_CORRIDOR_OUTER_BOUNDARY_3_RMAX      ( 200U )
#define C_EYEQMSG_LDWINIT_CORRIDOR_OUTER_BOUNDARY_3_NUMR      ( 1 )
#define C_EYEQMSG_LDWINIT_CORRIDOR_OUTER_BOUNDARY_3_DEMNR     ( 100 )
#define C_EYEQMSG_LDWINIT_CORRIDOR_OUTER_BOUNDARY_3_OFFSET    ( -2 )

/* corridor_outer_boundary_2_b9 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_CORRIDOR_OUTER_BOUNDARY_2_RMIN      ( 0U )
#define C_EYEQMSG_LDWINIT_CORRIDOR_OUTER_BOUNDARY_2_RMAX      ( 200U )
#define C_EYEQMSG_LDWINIT_CORRIDOR_OUTER_BOUNDARY_2_NUMR      ( 1 )
#define C_EYEQMSG_LDWINIT_CORRIDOR_OUTER_BOUNDARY_2_DEMNR     ( 100 )
#define C_EYEQMSG_LDWINIT_CORRIDOR_OUTER_BOUNDARY_2_OFFSET    ( -2 )

/* Reserved_6_b5 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_RESERVED_6_RMIN                     ( 0U )
#define C_EYEQMSG_LDWINIT_RESERVED_6_RMAX                     ( 0U )
#define C_EYEQMSG_LDWINIT_RESERVED_6_NUMR                     ( 1U )
#define C_EYEQMSG_LDWINIT_RESERVED_6_DEMNR                    ( 1U )
#define C_EYEQMSG_LDWINIT_RESERVED_6_OFFSET                   ( 0U )

/* corridor_outer_boundary_1_b9 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_CORRIDOR_OUTER_BOUNDARY_1_RMIN      ( 0U )
#define C_EYEQMSG_LDWINIT_CORRIDOR_OUTER_BOUNDARY_1_RMAX      ( 200U )
#define C_EYEQMSG_LDWINIT_CORRIDOR_OUTER_BOUNDARY_1_NUMR      ( 1 )
#define C_EYEQMSG_LDWINIT_CORRIDOR_OUTER_BOUNDARY_1_DEMNR     ( 100 )
#define C_EYEQMSG_LDWINIT_CORRIDOR_OUTER_BOUNDARY_1_OFFSET    ( -2 )

/* corridor_outer_boundary_0_b9 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_CORRIDOR_OUTER_BOUNDARY_0_RMIN      ( 0U )
#define C_EYEQMSG_LDWINIT_CORRIDOR_OUTER_BOUNDARY_0_RMAX      ( 200U )
#define C_EYEQMSG_LDWINIT_CORRIDOR_OUTER_BOUNDARY_0_NUMR      ( 1 )
#define C_EYEQMSG_LDWINIT_CORRIDOR_OUTER_BOUNDARY_0_DEMNR     ( 100 )
#define C_EYEQMSG_LDWINIT_CORRIDOR_OUTER_BOUNDARY_0_OFFSET    ( -2 )

/* inner_reset_offset_3_b9 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_INNER_RESET_OFFSET_3_RMIN           ( 0U )
#define C_EYEQMSG_LDWINIT_INNER_RESET_OFFSET_3_RMAX           ( 300U )
#define C_EYEQMSG_LDWINIT_INNER_RESET_OFFSET_3_NUMR           ( 1U )
#define C_EYEQMSG_LDWINIT_INNER_RESET_OFFSET_3_DEMNR          ( 100U )
#define C_EYEQMSG_LDWINIT_INNER_RESET_OFFSET_3_OFFSET         ( 0U )

/* Reserved_5_b5 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_RESERVED_5_RMIN                     ( 0U )
#define C_EYEQMSG_LDWINIT_RESERVED_5_RMAX                     ( 0U )
#define C_EYEQMSG_LDWINIT_RESERVED_5_NUMR                     ( 1U )
#define C_EYEQMSG_LDWINIT_RESERVED_5_DEMNR                    ( 1U )
#define C_EYEQMSG_LDWINIT_RESERVED_5_OFFSET                   ( 0U )

/* inner_reset_offset_2_b9 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_INNER_RESET_OFFSET_2_RMIN           ( 0U )
#define C_EYEQMSG_LDWINIT_INNER_RESET_OFFSET_2_RMAX           ( 300U )
#define C_EYEQMSG_LDWINIT_INNER_RESET_OFFSET_2_NUMR           ( 1U )
#define C_EYEQMSG_LDWINIT_INNER_RESET_OFFSET_2_DEMNR          ( 100U )
#define C_EYEQMSG_LDWINIT_INNER_RESET_OFFSET_2_OFFSET         ( 0U )

/* inner_reset_offset_1_b9 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_INNER_RESET_OFFSET_1_RMIN           ( 0U )
#define C_EYEQMSG_LDWINIT_INNER_RESET_OFFSET_1_RMAX           ( 300U )
#define C_EYEQMSG_LDWINIT_INNER_RESET_OFFSET_1_NUMR           ( 1U )
#define C_EYEQMSG_LDWINIT_INNER_RESET_OFFSET_1_DEMNR          ( 100U )
#define C_EYEQMSG_LDWINIT_INNER_RESET_OFFSET_1_OFFSET         ( 0U )

/* inner_reset_offset_0_b9 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_INNER_RESET_OFFSET_0_RMIN           ( 0U )
#define C_EYEQMSG_LDWINIT_INNER_RESET_OFFSET_0_RMAX           ( 300U )
#define C_EYEQMSG_LDWINIT_INNER_RESET_OFFSET_0_NUMR           ( 1U )
#define C_EYEQMSG_LDWINIT_INNER_RESET_OFFSET_0_DEMNR          ( 100U )
#define C_EYEQMSG_LDWINIT_INNER_RESET_OFFSET_0_OFFSET         ( 0U )

/* outer_dist_to_terminate_war_3_b8 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_OUTER_DIST_TO_TERMINATE_WAR_3_RMIN  ( 0U )
#define C_EYEQMSG_LDWINIT_OUTER_DIST_TO_TERMINATE_WAR_3_RMAX  ( 200U )
#define C_EYEQMSG_LDWINIT_OUTER_DIST_TO_TERMINATE_WAR_3_NUMR  ( 1 )
#define C_EYEQMSG_LDWINIT_OUTER_DIST_TO_TERMINATE_WAR_3_DEMNR ( 100 )
#define C_EYEQMSG_LDWINIT_OUTER_DIST_TO_TERMINATE_WAR_3_OFFSET ( -2 )

/* outer_dist_to_terminate_war_2_b8 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_OUTER_DIST_TO_TERMINATE_WAR_2_RMIN  ( 0U )
#define C_EYEQMSG_LDWINIT_OUTER_DIST_TO_TERMINATE_WAR_2_RMAX  ( 200U )
#define C_EYEQMSG_LDWINIT_OUTER_DIST_TO_TERMINATE_WAR_2_NUMR  ( 1 )
#define C_EYEQMSG_LDWINIT_OUTER_DIST_TO_TERMINATE_WAR_2_DEMNR ( 100 )
#define C_EYEQMSG_LDWINIT_OUTER_DIST_TO_TERMINATE_WAR_2_OFFSET ( -2 )

/* outer_dist_to_terminate_war_1_b8 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_OUTER_DIST_TO_TERMINATE_WAR_1_RMIN  ( 0U )
#define C_EYEQMSG_LDWINIT_OUTER_DIST_TO_TERMINATE_WAR_1_RMAX  ( 200U )
#define C_EYEQMSG_LDWINIT_OUTER_DIST_TO_TERMINATE_WAR_1_NUMR  ( 1 )
#define C_EYEQMSG_LDWINIT_OUTER_DIST_TO_TERMINATE_WAR_1_DEMNR ( 100 )
#define C_EYEQMSG_LDWINIT_OUTER_DIST_TO_TERMINATE_WAR_1_OFFSET ( -2 )

/* outer_dist_to_terminate_war_0_b8 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_OUTER_DIST_TO_TERMINATE_WAR_0_RMIN  ( 0U )
#define C_EYEQMSG_LDWINIT_OUTER_DIST_TO_TERMINATE_WAR_0_RMAX  ( 200U )
#define C_EYEQMSG_LDWINIT_OUTER_DIST_TO_TERMINATE_WAR_0_NUMR  ( 1 )
#define C_EYEQMSG_LDWINIT_OUTER_DIST_TO_TERMINATE_WAR_0_DEMNR ( 100 )
#define C_EYEQMSG_LDWINIT_OUTER_DIST_TO_TERMINATE_WAR_0_OFFSET ( -2 )

/* position_warning_dist_thresh_3_b8 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_POSITION_WARNING_DIST_THRESH_3_RMIN ( 0U )
#define C_EYEQMSG_LDWINIT_POSITION_WARNING_DIST_THRESH_3_RMAX ( 200U )
#define C_EYEQMSG_LDWINIT_POSITION_WARNING_DIST_THRESH_3_NUMR ( 1 )
#define C_EYEQMSG_LDWINIT_POSITION_WARNING_DIST_THRESH_3_DEMNR ( 100 )
#define C_EYEQMSG_LDWINIT_POSITION_WARNING_DIST_THRESH_3_OFFSET ( -1 )

/* position_warning_dist_thresh_2_b8 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_POSITION_WARNING_DIST_THRESH_2_RMIN ( 0U )
#define C_EYEQMSG_LDWINIT_POSITION_WARNING_DIST_THRESH_2_RMAX ( 200U )
#define C_EYEQMSG_LDWINIT_POSITION_WARNING_DIST_THRESH_2_NUMR ( 1 )
#define C_EYEQMSG_LDWINIT_POSITION_WARNING_DIST_THRESH_2_DEMNR ( 100 )
#define C_EYEQMSG_LDWINIT_POSITION_WARNING_DIST_THRESH_2_OFFSET ( -1 )

/* position_warning_dist_thresh_1_b8 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_POSITION_WARNING_DIST_THRESH_1_RMIN ( 0U )
#define C_EYEQMSG_LDWINIT_POSITION_WARNING_DIST_THRESH_1_RMAX ( 200U )
#define C_EYEQMSG_LDWINIT_POSITION_WARNING_DIST_THRESH_1_NUMR ( 1 )
#define C_EYEQMSG_LDWINIT_POSITION_WARNING_DIST_THRESH_1_DEMNR ( 100 )
#define C_EYEQMSG_LDWINIT_POSITION_WARNING_DIST_THRESH_1_OFFSET ( -1 )

/* position_warning_dist_thresh_0_b8 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_POSITION_WARNING_DIST_THRESH_0_RMIN ( 0U )
#define C_EYEQMSG_LDWINIT_POSITION_WARNING_DIST_THRESH_0_RMAX ( 200U )
#define C_EYEQMSG_LDWINIT_POSITION_WARNING_DIST_THRESH_0_NUMR ( 1 )
#define C_EYEQMSG_LDWINIT_POSITION_WARNING_DIST_THRESH_0_DEMNR ( 100 )
#define C_EYEQMSG_LDWINIT_POSITION_WARNING_DIST_THRESH_0_OFFSET ( -1 )

/* warning_line_tlc_3_b8 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_WARNING_LINE_TLC_3_RMIN             ( 0U )
#define C_EYEQMSG_LDWINIT_WARNING_LINE_TLC_3_RMAX             ( 200U )
#define C_EYEQMSG_LDWINIT_WARNING_LINE_TLC_3_NUMR             ( 1 )
#define C_EYEQMSG_LDWINIT_WARNING_LINE_TLC_3_DEMNR            ( 100 )
#define C_EYEQMSG_LDWINIT_WARNING_LINE_TLC_3_OFFSET           ( -1 )

/* warning_line_tlc_2_b8 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_WARNING_LINE_TLC_2_RMIN             ( 0U )
#define C_EYEQMSG_LDWINIT_WARNING_LINE_TLC_2_RMAX             ( 200U )
#define C_EYEQMSG_LDWINIT_WARNING_LINE_TLC_2_NUMR             ( 1 )
#define C_EYEQMSG_LDWINIT_WARNING_LINE_TLC_2_DEMNR            ( 100 )
#define C_EYEQMSG_LDWINIT_WARNING_LINE_TLC_2_OFFSET           ( -1 )

/* warning_line_tlc_1_b8 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_WARNING_LINE_TLC_1_RMIN             ( 0U )
#define C_EYEQMSG_LDWINIT_WARNING_LINE_TLC_1_RMAX             ( 200U )
#define C_EYEQMSG_LDWINIT_WARNING_LINE_TLC_1_NUMR             ( 1 )
#define C_EYEQMSG_LDWINIT_WARNING_LINE_TLC_1_DEMNR            ( 100 )
#define C_EYEQMSG_LDWINIT_WARNING_LINE_TLC_1_OFFSET           ( -1 )

/* warning_line_tlc_0_b8 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_WARNING_LINE_TLC_0_RMIN             ( 0U )
#define C_EYEQMSG_LDWINIT_WARNING_LINE_TLC_0_RMAX             ( 200U )
#define C_EYEQMSG_LDWINIT_WARNING_LINE_TLC_0_NUMR             ( 1 )
#define C_EYEQMSG_LDWINIT_WARNING_LINE_TLC_0_DEMNR            ( 100 )
#define C_EYEQMSG_LDWINIT_WARNING_LINE_TLC_0_OFFSET           ( -1 )

/* tlc_3_b8 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_TLC_3_RMIN                          ( 0U )
#define C_EYEQMSG_LDWINIT_TLC_3_RMAX                          ( 200U )
#define C_EYEQMSG_LDWINIT_TLC_3_NUMR                          ( 1U )
#define C_EYEQMSG_LDWINIT_TLC_3_DEMNR                         ( 100U )
#define C_EYEQMSG_LDWINIT_TLC_3_OFFSET                        ( 0U )

/* tlc_2_b8 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_TLC_2_RMIN                          ( 0U )
#define C_EYEQMSG_LDWINIT_TLC_2_RMAX                          ( 200U )
#define C_EYEQMSG_LDWINIT_TLC_2_NUMR                          ( 1U )
#define C_EYEQMSG_LDWINIT_TLC_2_DEMNR                         ( 100U )
#define C_EYEQMSG_LDWINIT_TLC_2_OFFSET                        ( 0U )

/* tlc_1_b8 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_TLC_1_RMIN                          ( 0U )
#define C_EYEQMSG_LDWINIT_TLC_1_RMAX                          ( 200U )
#define C_EYEQMSG_LDWINIT_TLC_1_NUMR                          ( 1U )
#define C_EYEQMSG_LDWINIT_TLC_1_DEMNR                         ( 100U )
#define C_EYEQMSG_LDWINIT_TLC_1_OFFSET                        ( 0U )

/* tlc_0_b8 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_TLC_0_RMIN                          ( 0U )
#define C_EYEQMSG_LDWINIT_TLC_0_RMAX                          ( 200U )
#define C_EYEQMSG_LDWINIT_TLC_0_NUMR                          ( 1U )
#define C_EYEQMSG_LDWINIT_TLC_0_DEMNR                         ( 100U )
#define C_EYEQMSG_LDWINIT_TLC_0_OFFSET                        ( 0U )

/* Reserved_4_b5 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_RESERVED_4_RMIN                     ( 0U )
#define C_EYEQMSG_LDWINIT_RESERVED_4_RMAX                     ( 0U )
#define C_EYEQMSG_LDWINIT_RESERVED_4_NUMR                     ( 1U )
#define C_EYEQMSG_LDWINIT_RESERVED_4_DEMNR                    ( 1U )
#define C_EYEQMSG_LDWINIT_RESERVED_4_OFFSET                   ( 0U )

/* narrow_lane_width_3_b9 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_NARROW_LANE_WIDTH_3_RMIN            ( 100U )
#define C_EYEQMSG_LDWINIT_NARROW_LANE_WIDTH_3_RMAX            ( 400U )
#define C_EYEQMSG_LDWINIT_NARROW_LANE_WIDTH_3_NUMR            ( 1U )
#define C_EYEQMSG_LDWINIT_NARROW_LANE_WIDTH_3_DEMNR           ( 100U )
#define C_EYEQMSG_LDWINIT_NARROW_LANE_WIDTH_3_OFFSET          ( 0U )

/* narrow_lane_width_2_b9 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_NARROW_LANE_WIDTH_2_RMIN            ( 100U )
#define C_EYEQMSG_LDWINIT_NARROW_LANE_WIDTH_2_RMAX            ( 400U )
#define C_EYEQMSG_LDWINIT_NARROW_LANE_WIDTH_2_NUMR            ( 1U )
#define C_EYEQMSG_LDWINIT_NARROW_LANE_WIDTH_2_DEMNR           ( 100U )
#define C_EYEQMSG_LDWINIT_NARROW_LANE_WIDTH_2_OFFSET          ( 0U )

/* narrow_lane_width_1_b9 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_NARROW_LANE_WIDTH_1_RMIN            ( 100U )
#define C_EYEQMSG_LDWINIT_NARROW_LANE_WIDTH_1_RMAX            ( 400U )
#define C_EYEQMSG_LDWINIT_NARROW_LANE_WIDTH_1_NUMR            ( 1U )
#define C_EYEQMSG_LDWINIT_NARROW_LANE_WIDTH_1_DEMNR           ( 100U )
#define C_EYEQMSG_LDWINIT_NARROW_LANE_WIDTH_1_OFFSET          ( 0U )

/* Reserved_3_b7 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_RESERVED_3_RMIN                     ( 0U )
#define C_EYEQMSG_LDWINIT_RESERVED_3_RMAX                     ( 0U )
#define C_EYEQMSG_LDWINIT_RESERVED_3_NUMR                     ( 1U )
#define C_EYEQMSG_LDWINIT_RESERVED_3_DEMNR                    ( 1U )
#define C_EYEQMSG_LDWINIT_RESERVED_3_OFFSET                   ( 0U )

/* narrow_lane_width_0_b9 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_NARROW_LANE_WIDTH_0_RMIN            ( 100U )
#define C_EYEQMSG_LDWINIT_NARROW_LANE_WIDTH_0_RMAX            ( 400U )
#define C_EYEQMSG_LDWINIT_NARROW_LANE_WIDTH_0_NUMR            ( 1U )
#define C_EYEQMSG_LDWINIT_NARROW_LANE_WIDTH_0_DEMNR           ( 100U )
#define C_EYEQMSG_LDWINIT_NARROW_LANE_WIDTH_0_OFFSET          ( 0U )

/* min_lane_width_hysteresis_3_b8 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_HYSTERESIS_3_RMIN    ( 0U )
#define C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_HYSTERESIS_3_RMAX    ( 100U )
#define C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_HYSTERESIS_3_NUMR    ( 1U )
#define C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_HYSTERESIS_3_DEMNR   ( 100U )
#define C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_HYSTERESIS_3_OFFSET  ( 0U )

/* min_lane_width_hysteresis_2_b8 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_HYSTERESIS_2_RMIN    ( 0U )
#define C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_HYSTERESIS_2_RMAX    ( 100U )
#define C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_HYSTERESIS_2_NUMR    ( 1U )
#define C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_HYSTERESIS_2_DEMNR   ( 100U )
#define C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_HYSTERESIS_2_OFFSET  ( 0U )

/* Reserved_2_b3 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_RESERVED_2_RMIN                     ( 0U )
#define C_EYEQMSG_LDWINIT_RESERVED_2_RMAX                     ( 0U )
#define C_EYEQMSG_LDWINIT_RESERVED_2_NUMR                     ( 1U )
#define C_EYEQMSG_LDWINIT_RESERVED_2_DEMNR                    ( 1U )
#define C_EYEQMSG_LDWINIT_RESERVED_2_OFFSET                   ( 0U )

/* min_lane_width_hysteresis_1_b8 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_HYSTERESIS_1_RMIN    ( 0U )
#define C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_HYSTERESIS_1_RMAX    ( 100U )
#define C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_HYSTERESIS_1_NUMR    ( 1U )
#define C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_HYSTERESIS_1_DEMNR   ( 100U )
#define C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_HYSTERESIS_1_OFFSET  ( 0U )

/* min_lane_width_hysteresis_0_b8 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_HYSTERESIS_0_RMIN    ( 0U )
#define C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_HYSTERESIS_0_RMAX    ( 100U )
#define C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_HYSTERESIS_0_NUMR    ( 1U )
#define C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_HYSTERESIS_0_DEMNR   ( 100U )
#define C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_HYSTERESIS_0_OFFSET  ( 0U )

/* ind_min_wrn_disable_3_b1 signal Enums */
typedef boolean LDWINITIndMinWrnDisable3;
#define C_EYEQMSG_LDWINIT_IND_MIN_WRN_DISABLE_3_FALSE         ( LDWINITIndMinWrnDisable3 ) ( 0U )
#define C_EYEQMSG_LDWINIT_IND_MIN_WRN_DISABLE_3_TRUE          ( LDWINITIndMinWrnDisable3 ) ( 1U )

/* ind_min_wrn_disable_3_b1 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_IND_MIN_WRN_DISABLE_3_RMIN          ( 0U )
#define C_EYEQMSG_LDWINIT_IND_MIN_WRN_DISABLE_3_RMAX          ( 1U )
#define C_EYEQMSG_LDWINIT_IND_MIN_WRN_DISABLE_3_NUMR          ( 1U )
#define C_EYEQMSG_LDWINIT_IND_MIN_WRN_DISABLE_3_DEMNR         ( 1U )
#define C_EYEQMSG_LDWINIT_IND_MIN_WRN_DISABLE_3_OFFSET        ( 0U )

/* ind_min_wrn_disable_2_b1 signal Enums */
typedef boolean LDWINITIndMinWrnDisable2;
#define C_EYEQMSG_LDWINIT_IND_MIN_WRN_DISABLE_2_FALSE         ( LDWINITIndMinWrnDisable2 ) ( 0U )
#define C_EYEQMSG_LDWINIT_IND_MIN_WRN_DISABLE_2_TRUE          ( LDWINITIndMinWrnDisable2 ) ( 1U )

/* ind_min_wrn_disable_2_b1 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_IND_MIN_WRN_DISABLE_2_RMIN          ( 0U )
#define C_EYEQMSG_LDWINIT_IND_MIN_WRN_DISABLE_2_RMAX          ( 1U )
#define C_EYEQMSG_LDWINIT_IND_MIN_WRN_DISABLE_2_NUMR          ( 1U )
#define C_EYEQMSG_LDWINIT_IND_MIN_WRN_DISABLE_2_DEMNR         ( 1U )
#define C_EYEQMSG_LDWINIT_IND_MIN_WRN_DISABLE_2_OFFSET        ( 0U )

/* ind_min_wrn_disable_1_b1 signal Enums */
typedef boolean LDWINITIndMinWrnDisable1;
#define C_EYEQMSG_LDWINIT_IND_MIN_WRN_DISABLE_1_FALSE         ( LDWINITIndMinWrnDisable1 ) ( 0U )
#define C_EYEQMSG_LDWINIT_IND_MIN_WRN_DISABLE_1_TRUE          ( LDWINITIndMinWrnDisable1 ) ( 1U )

/* ind_min_wrn_disable_1_b1 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_IND_MIN_WRN_DISABLE_1_RMIN          ( 0U )
#define C_EYEQMSG_LDWINIT_IND_MIN_WRN_DISABLE_1_RMAX          ( 1U )
#define C_EYEQMSG_LDWINIT_IND_MIN_WRN_DISABLE_1_NUMR          ( 1U )
#define C_EYEQMSG_LDWINIT_IND_MIN_WRN_DISABLE_1_DEMNR         ( 1U )
#define C_EYEQMSG_LDWINIT_IND_MIN_WRN_DISABLE_1_OFFSET        ( 0U )

/* ind_min_wrn_disable_0_b1 signal Enums */
typedef boolean LDWINITIndMinWrnDisable0;
#define C_EYEQMSG_LDWINIT_IND_MIN_WRN_DISABLE_0_FALSE         ( LDWINITIndMinWrnDisable0 ) ( 0U )
#define C_EYEQMSG_LDWINIT_IND_MIN_WRN_DISABLE_0_TRUE          ( LDWINITIndMinWrnDisable0 ) ( 1U )

/* ind_min_wrn_disable_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_IND_MIN_WRN_DISABLE_0_RMIN          ( 0U )
#define C_EYEQMSG_LDWINIT_IND_MIN_WRN_DISABLE_0_RMAX          ( 1U )
#define C_EYEQMSG_LDWINIT_IND_MIN_WRN_DISABLE_0_NUMR          ( 1U )
#define C_EYEQMSG_LDWINIT_IND_MIN_WRN_DISABLE_0_DEMNR         ( 1U )
#define C_EYEQMSG_LDWINIT_IND_MIN_WRN_DISABLE_0_OFFSET        ( 0U )

/* min_lane_width_3_b9 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_3_RMIN               ( 100U )
#define C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_3_RMAX               ( 400U )
#define C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_3_NUMR               ( 1U )
#define C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_3_DEMNR              ( 100U )
#define C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_3_OFFSET             ( 0U )

/* Reserved_1_b1 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_RESERVED_1_RMIN                     ( 0U )
#define C_EYEQMSG_LDWINIT_RESERVED_1_RMAX                     ( 0U )
#define C_EYEQMSG_LDWINIT_RESERVED_1_NUMR                     ( 1U )
#define C_EYEQMSG_LDWINIT_RESERVED_1_DEMNR                    ( 1U )
#define C_EYEQMSG_LDWINIT_RESERVED_1_OFFSET                   ( 0U )

/* min_lane_width_2_b9 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_2_RMIN               ( 100U )
#define C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_2_RMAX               ( 400U )
#define C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_2_NUMR               ( 1U )
#define C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_2_DEMNR              ( 100U )
#define C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_2_OFFSET             ( 0U )

/* min_lane_width_1_b9 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_1_RMIN               ( 100U )
#define C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_1_RMAX               ( 400U )
#define C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_1_NUMR               ( 1U )
#define C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_1_DEMNR              ( 100U )
#define C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_1_OFFSET             ( 0U )

/* min_lane_width_0_b9 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_0_RMIN               ( 100U )
#define C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_0_RMAX               ( 400U )
#define C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_0_NUMR               ( 1U )
#define C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_0_DEMNR              ( 100U )
#define C_EYEQMSG_LDWINIT_MIN_LANE_WIDTH_0_OFFSET             ( 0U )

/* LDW_Set_Enable_3_b1 signal Enums */
typedef boolean LDWINITLDWSetEnable3;
#define C_EYEQMSG_LDWINIT_LDW_SET_ENABLE_3_FALSE              ( LDWINITLDWSetEnable3 ) ( 0U )
#define C_EYEQMSG_LDWINIT_LDW_SET_ENABLE_3_TRUE               ( LDWINITLDWSetEnable3 ) ( 1U )

/* LDW_Set_Enable_3_b1 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_LDW_SET_ENABLE_3_RMIN               ( 0U )
#define C_EYEQMSG_LDWINIT_LDW_SET_ENABLE_3_RMAX               ( 1U )
#define C_EYEQMSG_LDWINIT_LDW_SET_ENABLE_3_NUMR               ( 1U )
#define C_EYEQMSG_LDWINIT_LDW_SET_ENABLE_3_DEMNR              ( 1U )
#define C_EYEQMSG_LDWINIT_LDW_SET_ENABLE_3_OFFSET             ( 0U )

/* LDW_Set_Enable_2_b1 signal Enums */
typedef boolean LDWINITLDWSetEnable2;
#define C_EYEQMSG_LDWINIT_LDW_SET_ENABLE_2_FALSE              ( LDWINITLDWSetEnable2 ) ( 0U )
#define C_EYEQMSG_LDWINIT_LDW_SET_ENABLE_2_TRUE               ( LDWINITLDWSetEnable2 ) ( 1U )

/* LDW_Set_Enable_2_b1 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_LDW_SET_ENABLE_2_RMIN               ( 0U )
#define C_EYEQMSG_LDWINIT_LDW_SET_ENABLE_2_RMAX               ( 1U )
#define C_EYEQMSG_LDWINIT_LDW_SET_ENABLE_2_NUMR               ( 1U )
#define C_EYEQMSG_LDWINIT_LDW_SET_ENABLE_2_DEMNR              ( 1U )
#define C_EYEQMSG_LDWINIT_LDW_SET_ENABLE_2_OFFSET             ( 0U )

/* LDW_Set_Enable_1_b1 signal Enums */
typedef boolean LDWINITLDWSetEnable1;
#define C_EYEQMSG_LDWINIT_LDW_SET_ENABLE_1_FALSE              ( LDWINITLDWSetEnable1 ) ( 0U )
#define C_EYEQMSG_LDWINIT_LDW_SET_ENABLE_1_TRUE               ( LDWINITLDWSetEnable1 ) ( 1U )

/* LDW_Set_Enable_1_b1 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_LDW_SET_ENABLE_1_RMIN               ( 0U )
#define C_EYEQMSG_LDWINIT_LDW_SET_ENABLE_1_RMAX               ( 1U )
#define C_EYEQMSG_LDWINIT_LDW_SET_ENABLE_1_NUMR               ( 1U )
#define C_EYEQMSG_LDWINIT_LDW_SET_ENABLE_1_DEMNR              ( 1U )
#define C_EYEQMSG_LDWINIT_LDW_SET_ENABLE_1_OFFSET             ( 0U )

/* LDW_Set_Enable_0_b1 signal Enums */
typedef boolean LDWINITLDWSetEnable0;
#define C_EYEQMSG_LDWINIT_LDW_SET_ENABLE_0_FALSE              ( LDWINITLDWSetEnable0 ) ( 0U )
#define C_EYEQMSG_LDWINIT_LDW_SET_ENABLE_0_TRUE               ( LDWINITLDWSetEnable0 ) ( 1U )

/* LDW_Set_Enable_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_LDW_SET_ENABLE_0_RMIN               ( 0U )
#define C_EYEQMSG_LDWINIT_LDW_SET_ENABLE_0_RMAX               ( 1U )
#define C_EYEQMSG_LDWINIT_LDW_SET_ENABLE_0_NUMR               ( 1U )
#define C_EYEQMSG_LDWINIT_LDW_SET_ENABLE_0_DEMNR              ( 1U )
#define C_EYEQMSG_LDWINIT_LDW_SET_ENABLE_0_OFFSET             ( 0U )

/* ILDW_Header_Buffer_b15 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_ILDW_HEADER_BUFFER_RMIN             ( 0U )
#define C_EYEQMSG_LDWINIT_ILDW_HEADER_BUFFER_RMAX             ( 0U )
#define C_EYEQMSG_LDWINIT_ILDW_HEADER_BUFFER_NUMR             ( 1U )
#define C_EYEQMSG_LDWINIT_ILDW_HEADER_BUFFER_DEMNR            ( 1U )
#define C_EYEQMSG_LDWINIT_ILDW_HEADER_BUFFER_OFFSET           ( 0U )

/* ILDW_Optional_Signals_b1 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_ILDW_OPTIONAL_SIGNALS_RMIN          ( 0U )
#define C_EYEQMSG_LDWINIT_ILDW_OPTIONAL_SIGNALS_RMAX          ( 0U )
#define C_EYEQMSG_LDWINIT_ILDW_OPTIONAL_SIGNALS_NUMR          ( 1U )
#define C_EYEQMSG_LDWINIT_ILDW_OPTIONAL_SIGNALS_DEMNR         ( 1U )
#define C_EYEQMSG_LDWINIT_ILDW_OPTIONAL_SIGNALS_OFFSET        ( 0U )

/* ILDW_Protocol_Version_b8 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_ILDW_PROTOCOL_VERSION_RMIN          ( 2U )
#define C_EYEQMSG_LDWINIT_ILDW_PROTOCOL_VERSION_RMAX          ( 2U )
#define C_EYEQMSG_LDWINIT_ILDW_PROTOCOL_VERSION_NUMR          ( 1U )
#define C_EYEQMSG_LDWINIT_ILDW_PROTOCOL_VERSION_DEMNR         ( 1U )
#define C_EYEQMSG_LDWINIT_ILDW_PROTOCOL_VERSION_OFFSET        ( 0U )

/* ILDW_Zero_byte_b8 signal Min & Max range limits */
#define C_EYEQMSG_LDWINIT_ILDW_ZERO_BYTE_RMIN                 ( 0U )
#define C_EYEQMSG_LDWINIT_ILDW_ZERO_BYTE_RMAX                 ( 0U )
#define C_EYEQMSG_LDWINIT_ILDW_ZERO_BYTE_NUMR                 ( 1U )
#define C_EYEQMSG_LDWINIT_ILDW_ZERO_BYTE_DEMNR                ( 1U )
#define C_EYEQMSG_LDWINIT_ILDW_ZERO_BYTE_OFFSET               ( 0U )


/*****************************************************************************
                  Exported function-like macros
*****************************************************************************/
/*****************************************************************************
                  Exported defined macros
*****************************************************************************/
/*****************************************************************************
                  Exported types, enums definitions
*****************************************************************************/
typedef struct
{
   #if ENABLE_BIG_ENDIAN_FORMAT
      uint32        ILDW_Zero_byte_b8                            : 8U;
      
      uint32        ILDW_Protocol_Version_b8                     : 8U;
      
      uint32        unused1_b7                                   : 7;
      uint32        ILDW_Optional_Signals_b1                     : 1U;
      
      uint32        ILDW_Header_Buffer_1_b7                      : 7U;
      
      uint32        ILDW_Header_Buffer_2_b8                      : 8U;
      
      uint32        LDW_Set_Enable_0_b1                          : 1U;
      
      uint32        LDW_Set_Enable_1_b1                          : 1U;
      
      uint32        LDW_Set_Enable_2_b1                          : 1U;
      
      uint32        LDW_Set_Enable_3_b1                          : 1U;
      
      uint32        min_lane_width_0_1_b4                        : 4U;
      
      uint32        min_lane_width_0_2_b5                        : 5U;
      
      uint32        min_lane_width_1_1_b3                        : 3U;
      
      uint32        min_lane_width_1_2_b6                        : 6U;
      
      uint32        min_lane_width_2_1_b2                        : 2U;
      
      uint32        min_lane_width_2_2_b7                        : 7U;
      
      uint32        Reserved_1_b1                                : 1U;
      
      uint32        min_lane_width_3_1_b8                        : 8U;
      
      uint32        min_lane_width_3_2_b1                        : 1U;
      
      uint32        ind_min_wrn_disable_0_b1                     : 1U;
      
      uint32        ind_min_wrn_disable_1_b1                     : 1U;
      
      uint32        ind_min_wrn_disable_2_b1                     : 1U;
      
      uint32        ind_min_wrn_disable_3_b1                     : 1U;
      
      uint32        min_lane_width_hysteresis_0_1_b3             : 3U;
      
      uint32        min_lane_width_hysteresis_0_2_b5             : 5U;
      
      uint32        min_lane_width_hysteresis_1_1_b3             : 3U;
      
      uint32        min_lane_width_hysteresis_1_2_b5             : 5U;
      
      uint32        Reserved_2_b3                                : 3U;
      
      uint32        min_lane_width_hysteresis_2_b8               : 8U;
      
      uint32        min_lane_width_hysteresis_3_b8               : 8U;
      
      uint32        narrow_lane_width_0_1_b8                     : 8U;
      
      uint32        narrow_lane_width_0_2_b1                     : 1U;
      
      uint32        Reserved_3_b7                                : 7U;
      
      uint32        narrow_lane_width_1_1_b8                     : 8U;
      
      uint32        narrow_lane_width_1_2_b1                     : 1U;
      
      uint32        narrow_lane_width_2_1_b7                     : 7U;
      
      uint32        narrow_lane_width_2_2_b2                     : 2U;
      
      uint32        narrow_lane_width_3_1_b6                     : 6U;
      
      uint32        narrow_lane_width_3_2_b3                     : 3U;
      
      uint32        Reserved_4_b5                                : 5U;
      
      uint32        tlc_0_b8                                     : 8U;
      
      uint32        tlc_1_b8                                     : 8U;
      
      uint32        tlc_2_b8                                     : 8U;
      
      uint32        tlc_3_b8                                     : 8U;
      
      uint32        warning_line_tlc_0_b8                        : 8U;
      
      uint32        warning_line_tlc_1_b8                        : 8U;
      
      uint32        warning_line_tlc_2_b8                        : 8U;
      
      uint32        warning_line_tlc_3_b8                        : 8U;
      
      uint32        position_warning_dist_thresh_0_b8            : 8U;
      
      uint32        position_warning_dist_thresh_1_b8            : 8U;
      
      uint32        position_warning_dist_thresh_2_b8            : 8U;
      
      uint32        position_warning_dist_thresh_3_b8            : 8U;
      
      uint32        outer_dist_to_terminate_war_0_b8             : 8U;
      
      uint32        outer_dist_to_terminate_war_1_b8             : 8U;
      
      uint32        outer_dist_to_terminate_war_2_b8             : 8U;
      
      uint32        outer_dist_to_terminate_war_3_b8             : 8U;
      
      uint32        inner_reset_offset_0_1_b8                    : 8U;
      
      uint32        inner_reset_offset_0_2_b1                    : 1U;
      
      uint32        inner_reset_offset_1_1_b7                    : 7U;
      
      uint32        inner_reset_offset_1_2_b2                    : 2U;
      
      uint32        inner_reset_offset_2_1_b6                    : 6U;
      
      uint32        inner_reset_offset_2_2_b3                    : 3U;
      
      uint32        Reserved_5_b5                                : 5U;
      
      uint32        inner_reset_offset_3_1_b8                    : 8U;
      
      uint32        inner_reset_offset_3_2_b1                    : 1U;
      
      uint32        corridor_outer_boundary_0_1_b7               : 7U;
      
      uint32        corridor_outer_boundary_0_2_b2               : 2U;
      
      uint32        corridor_outer_boundary_1_1_b6               : 6U;
      
      uint32        corridor_outer_boundary_1_2_b3               : 3U;
      
      uint32        Reserved_6_b5                                : 5U;
      
      uint32        corridor_outer_boundary_2_1_b8               : 8U;
      
      uint32        corridor_outer_boundary_2_2_b1               : 1U;
      
      uint32        corridor_outer_boundary_3_1_b7               : 7U;
      
      uint32        corridor_outer_boundary_3_2_b2               : 2U;
      
      uint32        inner_curve_tlc_reduced_0_1_b6               : 6U;
      
      uint32        inner_curve_tlc_reduced_0_2_b3               : 3U;
      
      uint32        Reserved_7_b5                                : 5U;
      
      uint32        inner_curve_tlc_reduced_1_1_b8               : 8U;
      
      uint32        inner_curve_tlc_reduced_1_2_b1               : 1U;
      
      uint32        inner_curve_tlc_reduced_2_1_b7               : 7U;
      
      uint32        inner_curve_tlc_reduced_2_2_b2               : 2U;
      
      uint32        inner_curve_tlc_reduced_3_1_b6               : 6U;
      
      uint32        inner_curve_tlc_reduced_3_2_b3               : 3U;
      
      uint32        Reserved_8_b5                                : 5U;
      
      uint32        inner_curve_tlc_shift_thresh_0_1_b8          : 8U;
      
      uint32        inner_curve_tlc_shift_thresh_0_2_b3          : 3U;
      
      uint32        inner_curve_tlc_shift_thresh_1_1_b5          : 5U;
      
      uint32        inner_curve_tlc_shift_thresh_1_2_b6          : 6U;
      
      uint32        Reserved_9_1_b2                              : 2U;
      
      uint32        Reserved_9_2_b8                              : 8U;
      
      uint32        inner_curve_tlc_shift_thresh_2_1_b8          : 8U;
      
      uint32        inner_curve_tlc_shift_thresh_2_2_b3          : 3U;
      
      uint32        inner_curve_tlc_shift_thresh_3_1_b5          : 5U;
      
      uint32        inner_curve_tlc_shift_thresh_3_2_b6          : 6U;
      
      uint32        Reserved_10_1_b2                             : 2U;
      
      uint32        Reserved_10_2_b8                             : 8U;
      
   #else
      uint32        ILDW_Zero_byte_b8                            : 8U;
      
      uint32        ILDW_Protocol_Version_b8                     : 8U;
      
      uint32        ILDW_Optional_Signals_b1                     : 1U;
      
      uint32        ILDW_Header_Buffer_b15                       : 15U;
      
      uint32        LDW_Set_Enable_0_b1                          : 1U;
      
      uint32        LDW_Set_Enable_1_b1                          : 1U;
      
      uint32        LDW_Set_Enable_2_b1                          : 1U;
      
      uint32        LDW_Set_Enable_3_b1                          : 1U;
      
      uint32        min_lane_width_0_b9                          : 9U;
      
      uint32        min_lane_width_1_b9                          : 9U;
      
      uint32        min_lane_width_2_b9                          : 9U;
      
      uint32        Reserved_1_b1                                : 1U;
      
      uint32        min_lane_width_3_b9                          : 9U;
      
      uint32        ind_min_wrn_disable_0_b1                     : 1U;
      
      uint32        ind_min_wrn_disable_1_b1                     : 1U;
      
      uint32        ind_min_wrn_disable_2_b1                     : 1U;
      
      uint32        ind_min_wrn_disable_3_b1                     : 1U;
      
      uint32        min_lane_width_hysteresis_0_b8               : 8U;
      
      uint32        min_lane_width_hysteresis_1_b8               : 8U;
      
      uint32        Reserved_2_b3                                : 3U;
      
      uint32        min_lane_width_hysteresis_2_b8               : 8U;
      
      uint32        min_lane_width_hysteresis_3_b8               : 8U;
      
      uint32        narrow_lane_width_0_b9                       : 9U;
      
      uint32        Reserved_3_b7                                : 7U;
      
      uint32        narrow_lane_width_1_b9                       : 9U;
      
      uint32        narrow_lane_width_2_b9                       : 9U;
      
      uint32        narrow_lane_width_3_b9                       : 9U;
      
      uint32        Reserved_4_b5                                : 5U;
      
      uint32        tlc_0_b8                                     : 8U;
      
      uint32        tlc_1_b8                                     : 8U;
      
      uint32        tlc_2_b8                                     : 8U;
      
      uint32        tlc_3_b8                                     : 8U;
      
      uint32        warning_line_tlc_0_b8                        : 8U;
      
      uint32        warning_line_tlc_1_b8                        : 8U;
      
      uint32        warning_line_tlc_2_b8                        : 8U;
      
      uint32        warning_line_tlc_3_b8                        : 8U;
      
      uint32        position_warning_dist_thresh_0_b8            : 8U;
      
      uint32        position_warning_dist_thresh_1_b8            : 8U;
      
      uint32        position_warning_dist_thresh_2_b8            : 8U;
      
      uint32        position_warning_dist_thresh_3_b8            : 8U;
      
      uint32        outer_dist_to_terminate_war_0_b8             : 8U;
      
      uint32        outer_dist_to_terminate_war_1_b8             : 8U;
      
      uint32        outer_dist_to_terminate_war_2_b8             : 8U;
      
      uint32        outer_dist_to_terminate_war_3_b8             : 8U;
      
      uint32        inner_reset_offset_0_b9                      : 9U;
      
      uint32        inner_reset_offset_1_b9                      : 9U;
      
      uint32        inner_reset_offset_2_b9                      : 9U;
      
      uint32        Reserved_5_b5                                : 5U;
      
      uint32        inner_reset_offset_3_b9                      : 9U;
      
      uint32        corridor_outer_boundary_0_b9                 : 9U;
      
      uint32        corridor_outer_boundary_1_b9                 : 9U;
      
      uint32        Reserved_6_b5                                : 5U;
      
      uint32        corridor_outer_boundary_2_b9                 : 9U;
      
      uint32        corridor_outer_boundary_3_b9                 : 9U;
      
      uint32        inner_curve_tlc_reduced_0_b9                 : 9U;
      
      uint32        Reserved_7_b5                                : 5U;
      
      uint32        inner_curve_tlc_reduced_1_b9                 : 9U;
      
      uint32        inner_curve_tlc_reduced_2_b9                 : 9U;
      
      uint32        inner_curve_tlc_reduced_3_b9                 : 9U;
      
      uint32        Reserved_8_b5                                : 5U;
      
      uint32        inner_curve_tlc_shift_thresh_0_b11           : 11U;
      
      uint32        inner_curve_tlc_shift_thresh_1_b11           : 11U;
      
      uint32        Reserved_9_b10                               : 10U;
      
      uint32        inner_curve_tlc_shift_thresh_2_b11           : 11U;
      
      uint32        inner_curve_tlc_shift_thresh_3_b11           : 11U;
      
      uint32        Reserved_10_b10                              : 10U;
      
   #endif
} EYEQMSG_LDWINIT_Params_t;


/*****************************************************************************
                  Exported function prototypes
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_LDWINIT_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_LDWINIT_Params_t * pLDW_Init - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LDW_Init message 
*    LDW_Init message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LDW_Init message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_LDWINIT_ParamsApp_MsgDataStruct( EYEQMSG_LDWINIT_Params_t * pLDW_Init );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_ILDW_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pILDW_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILDW_Zero_byte
*    ILDW_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILDW_Zero_byte signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_ILDW_Zero_byte( uint8 * pILDW_Zero_byte );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_ILDW_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pILDW_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILDW_Protocol_Version
*    ILDW_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILDW_Protocol_Version signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_ILDW_Protocol_Version( uint8 * pILDW_Protocol_Version );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_ILDW_Optional_Signals
*
* FUNCTION ARGUMENTS:
*    boolean * pILDW_Optional_Signals - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILDW_Optional_Signals
*    ILDW_Optional_Signals returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILDW_Optional_Signals signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_ILDW_Optional_Signals( boolean * pILDW_Optional_Signals );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_ILDW_Header_Buffer
*
* FUNCTION ARGUMENTS:
*    uint16 * pILDW_Header_Buffer - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ILDW_Header_Buffer
*    ILDW_Header_Buffer returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ILDW_Header_Buffer signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_ILDW_Header_Buffer( uint16 * pILDW_Header_Buffer );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_LDW_Set_Enable_0
*
* FUNCTION ARGUMENTS:
*    LDWINITLDWSetEnable0 * pLDW_Set_Enable_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LDW_Set_Enable_0
*    LDW_Set_Enable_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LDW_Set_Enable_0 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_LDW_Set_Enable_0( LDWINITLDWSetEnable0 * pLDW_Set_Enable_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_LDW_Set_Enable_1
*
* FUNCTION ARGUMENTS:
*    LDWINITLDWSetEnable1 * pLDW_Set_Enable_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LDW_Set_Enable_1
*    LDW_Set_Enable_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LDW_Set_Enable_1 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_LDW_Set_Enable_1( LDWINITLDWSetEnable1 * pLDW_Set_Enable_1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_LDW_Set_Enable_2
*
* FUNCTION ARGUMENTS:
*    LDWINITLDWSetEnable2 * pLDW_Set_Enable_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LDW_Set_Enable_2
*    LDW_Set_Enable_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LDW_Set_Enable_2 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_LDW_Set_Enable_2( LDWINITLDWSetEnable2 * pLDW_Set_Enable_2 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_LDW_Set_Enable_3
*
* FUNCTION ARGUMENTS:
*    LDWINITLDWSetEnable3 * pLDW_Set_Enable_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LDW_Set_Enable_3
*    LDW_Set_Enable_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LDW_Set_Enable_3 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_LDW_Set_Enable_3( LDWINITLDWSetEnable3 * pLDW_Set_Enable_3 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_min_lane_width_0
*
* FUNCTION ARGUMENTS:
*    uint16 * pmin_lane_width_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of min_lane_width_0
*    min_lane_width_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns min_lane_width_0 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_min_lane_width_0( uint16 * pmin_lane_width_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_min_lane_width_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pmin_lane_width_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of min_lane_width_1
*    min_lane_width_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns min_lane_width_1 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_min_lane_width_1( uint16 * pmin_lane_width_1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_min_lane_width_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pmin_lane_width_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of min_lane_width_2
*    min_lane_width_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns min_lane_width_2 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_min_lane_width_2( uint16 * pmin_lane_width_2 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_Reserved_1
*
* FUNCTION ARGUMENTS:
*    boolean * pReserved_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1
*    Reserved_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_Reserved_1( boolean * pReserved_1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_min_lane_width_3
*
* FUNCTION ARGUMENTS:
*    uint16 * pmin_lane_width_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of min_lane_width_3
*    min_lane_width_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns min_lane_width_3 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_min_lane_width_3( uint16 * pmin_lane_width_3 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_ind_min_wrn_disable_0
*
* FUNCTION ARGUMENTS:
*    LDWINITIndMinWrnDisable0 * pind_min_wrn_disable_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ind_min_wrn_disable_0
*    ind_min_wrn_disable_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ind_min_wrn_disable_0 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_ind_min_wrn_disable_0( LDWINITIndMinWrnDisable0 * pind_min_wrn_disable_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_ind_min_wrn_disable_1
*
* FUNCTION ARGUMENTS:
*    LDWINITIndMinWrnDisable1 * pind_min_wrn_disable_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ind_min_wrn_disable_1
*    ind_min_wrn_disable_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ind_min_wrn_disable_1 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_ind_min_wrn_disable_1( LDWINITIndMinWrnDisable1 * pind_min_wrn_disable_1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_ind_min_wrn_disable_2
*
* FUNCTION ARGUMENTS:
*    LDWINITIndMinWrnDisable2 * pind_min_wrn_disable_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ind_min_wrn_disable_2
*    ind_min_wrn_disable_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ind_min_wrn_disable_2 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_ind_min_wrn_disable_2( LDWINITIndMinWrnDisable2 * pind_min_wrn_disable_2 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_ind_min_wrn_disable_3
*
* FUNCTION ARGUMENTS:
*    LDWINITIndMinWrnDisable3 * pind_min_wrn_disable_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ind_min_wrn_disable_3
*    ind_min_wrn_disable_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ind_min_wrn_disable_3 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_ind_min_wrn_disable_3( LDWINITIndMinWrnDisable3 * pind_min_wrn_disable_3 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_min_lane_width_hysteresis_0
*
* FUNCTION ARGUMENTS:
*    uint8 * pmin_lane_width_hysteresis_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of min_lane_width_hysteresis_0
*    min_lane_width_hysteresis_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns min_lane_width_hysteresis_0 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_min_lane_width_hysteresis_0( uint8 * pmin_lane_width_hysteresis_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_min_lane_width_hysteresis_1
*
* FUNCTION ARGUMENTS:
*    uint8 * pmin_lane_width_hysteresis_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of min_lane_width_hysteresis_1
*    min_lane_width_hysteresis_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns min_lane_width_hysteresis_1 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_min_lane_width_hysteresis_1( uint8 * pmin_lane_width_hysteresis_1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_Reserved_2
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_2
*    Reserved_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_2 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_Reserved_2( uint8 * pReserved_2 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_min_lane_width_hysteresis_2
*
* FUNCTION ARGUMENTS:
*    uint8 * pmin_lane_width_hysteresis_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of min_lane_width_hysteresis_2
*    min_lane_width_hysteresis_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns min_lane_width_hysteresis_2 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_min_lane_width_hysteresis_2( uint8 * pmin_lane_width_hysteresis_2 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_min_lane_width_hysteresis_3
*
* FUNCTION ARGUMENTS:
*    uint8 * pmin_lane_width_hysteresis_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of min_lane_width_hysteresis_3
*    min_lane_width_hysteresis_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns min_lane_width_hysteresis_3 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_min_lane_width_hysteresis_3( uint8 * pmin_lane_width_hysteresis_3 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_narrow_lane_width_0
*
* FUNCTION ARGUMENTS:
*    uint16 * pnarrow_lane_width_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of narrow_lane_width_0
*    narrow_lane_width_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns narrow_lane_width_0 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_narrow_lane_width_0( uint16 * pnarrow_lane_width_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_Reserved_3
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_3
*    Reserved_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_3 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_Reserved_3( uint8 * pReserved_3 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_narrow_lane_width_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pnarrow_lane_width_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of narrow_lane_width_1
*    narrow_lane_width_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns narrow_lane_width_1 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_narrow_lane_width_1( uint16 * pnarrow_lane_width_1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_narrow_lane_width_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pnarrow_lane_width_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of narrow_lane_width_2
*    narrow_lane_width_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns narrow_lane_width_2 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_narrow_lane_width_2( uint16 * pnarrow_lane_width_2 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_narrow_lane_width_3
*
* FUNCTION ARGUMENTS:
*    uint16 * pnarrow_lane_width_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of narrow_lane_width_3
*    narrow_lane_width_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns narrow_lane_width_3 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_narrow_lane_width_3( uint16 * pnarrow_lane_width_3 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_Reserved_4
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_4
*    Reserved_4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_4 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_Reserved_4( uint8 * pReserved_4 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_tlc_0
*
* FUNCTION ARGUMENTS:
*    uint8 * ptlc_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of tlc_0
*    tlc_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns tlc_0 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_tlc_0( uint8 * ptlc_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_tlc_1
*
* FUNCTION ARGUMENTS:
*    uint8 * ptlc_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of tlc_1
*    tlc_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns tlc_1 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_tlc_1( uint8 * ptlc_1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_tlc_2
*
* FUNCTION ARGUMENTS:
*    uint8 * ptlc_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of tlc_2
*    tlc_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns tlc_2 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_tlc_2( uint8 * ptlc_2 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_tlc_3
*
* FUNCTION ARGUMENTS:
*    uint8 * ptlc_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of tlc_3
*    tlc_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns tlc_3 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_tlc_3( uint8 * ptlc_3 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_warning_line_tlc_0
*
* FUNCTION ARGUMENTS:
*    uint8 * pwarning_line_tlc_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of warning_line_tlc_0
*    warning_line_tlc_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns warning_line_tlc_0 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_warning_line_tlc_0( uint8 * pwarning_line_tlc_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_warning_line_tlc_1
*
* FUNCTION ARGUMENTS:
*    uint8 * pwarning_line_tlc_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of warning_line_tlc_1
*    warning_line_tlc_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns warning_line_tlc_1 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_warning_line_tlc_1( uint8 * pwarning_line_tlc_1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_warning_line_tlc_2
*
* FUNCTION ARGUMENTS:
*    uint8 * pwarning_line_tlc_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of warning_line_tlc_2
*    warning_line_tlc_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns warning_line_tlc_2 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_warning_line_tlc_2( uint8 * pwarning_line_tlc_2 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_warning_line_tlc_3
*
* FUNCTION ARGUMENTS:
*    uint8 * pwarning_line_tlc_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of warning_line_tlc_3
*    warning_line_tlc_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns warning_line_tlc_3 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_warning_line_tlc_3( uint8 * pwarning_line_tlc_3 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_position_warning_dist_thresh_0
*
* FUNCTION ARGUMENTS:
*    uint8 * pposition_warning_dist_thresh_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of position_warning_dist_thresh_0
*    position_warning_dist_thresh_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns position_warning_dist_thresh_0 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_position_warning_dist_thresh_0( uint8 * pposition_warning_dist_thresh_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_position_warning_dist_thresh_1
*
* FUNCTION ARGUMENTS:
*    uint8 * pposition_warning_dist_thresh_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of position_warning_dist_thresh_1
*    position_warning_dist_thresh_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns position_warning_dist_thresh_1 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_position_warning_dist_thresh_1( uint8 * pposition_warning_dist_thresh_1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_position_warning_dist_thresh_2
*
* FUNCTION ARGUMENTS:
*    uint8 * pposition_warning_dist_thresh_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of position_warning_dist_thresh_2
*    position_warning_dist_thresh_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns position_warning_dist_thresh_2 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_position_warning_dist_thresh_2( uint8 * pposition_warning_dist_thresh_2 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_position_warning_dist_thresh_3
*
* FUNCTION ARGUMENTS:
*    uint8 * pposition_warning_dist_thresh_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of position_warning_dist_thresh_3
*    position_warning_dist_thresh_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns position_warning_dist_thresh_3 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_position_warning_dist_thresh_3( uint8 * pposition_warning_dist_thresh_3 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_outer_dist_to_terminate_war_0
*
* FUNCTION ARGUMENTS:
*    uint8 * pouter_dist_to_terminate_war_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of outer_dist_to_terminate_war_0
*    outer_dist_to_terminate_war_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns outer_dist_to_terminate_war_0 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_outer_dist_to_terminate_war_0( uint8 * pouter_dist_to_terminate_war_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_outer_dist_to_terminate_war_1
*
* FUNCTION ARGUMENTS:
*    uint8 * pouter_dist_to_terminate_war_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of outer_dist_to_terminate_war_1
*    outer_dist_to_terminate_war_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns outer_dist_to_terminate_war_1 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_outer_dist_to_terminate_war_1( uint8 * pouter_dist_to_terminate_war_1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_outer_dist_to_terminate_war_2
*
* FUNCTION ARGUMENTS:
*    uint8 * pouter_dist_to_terminate_war_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of outer_dist_to_terminate_war_2
*    outer_dist_to_terminate_war_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns outer_dist_to_terminate_war_2 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_outer_dist_to_terminate_war_2( uint8 * pouter_dist_to_terminate_war_2 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_outer_dist_to_terminate_war_3
*
* FUNCTION ARGUMENTS:
*    uint8 * pouter_dist_to_terminate_war_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of outer_dist_to_terminate_war_3
*    outer_dist_to_terminate_war_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns outer_dist_to_terminate_war_3 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_outer_dist_to_terminate_war_3( uint8 * pouter_dist_to_terminate_war_3 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_inner_reset_offset_0
*
* FUNCTION ARGUMENTS:
*    uint16 * pinner_reset_offset_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of inner_reset_offset_0
*    inner_reset_offset_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns inner_reset_offset_0 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_inner_reset_offset_0( uint16 * pinner_reset_offset_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_inner_reset_offset_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pinner_reset_offset_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of inner_reset_offset_1
*    inner_reset_offset_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns inner_reset_offset_1 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_inner_reset_offset_1( uint16 * pinner_reset_offset_1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_inner_reset_offset_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pinner_reset_offset_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of inner_reset_offset_2
*    inner_reset_offset_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns inner_reset_offset_2 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_inner_reset_offset_2( uint16 * pinner_reset_offset_2 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_Reserved_5
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_5
*    Reserved_5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_5 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_Reserved_5( uint8 * pReserved_5 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_inner_reset_offset_3
*
* FUNCTION ARGUMENTS:
*    uint16 * pinner_reset_offset_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of inner_reset_offset_3
*    inner_reset_offset_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns inner_reset_offset_3 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_inner_reset_offset_3( uint16 * pinner_reset_offset_3 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_corridor_outer_boundary_0
*
* FUNCTION ARGUMENTS:
*    uint16 * pcorridor_outer_boundary_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of corridor_outer_boundary_0
*    corridor_outer_boundary_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns corridor_outer_boundary_0 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_corridor_outer_boundary_0( uint16 * pcorridor_outer_boundary_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_corridor_outer_boundary_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pcorridor_outer_boundary_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of corridor_outer_boundary_1
*    corridor_outer_boundary_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns corridor_outer_boundary_1 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_corridor_outer_boundary_1( uint16 * pcorridor_outer_boundary_1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_Reserved_6
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_6 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_6
*    Reserved_6 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_6 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_Reserved_6( uint8 * pReserved_6 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_corridor_outer_boundary_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pcorridor_outer_boundary_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of corridor_outer_boundary_2
*    corridor_outer_boundary_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns corridor_outer_boundary_2 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_corridor_outer_boundary_2( uint16 * pcorridor_outer_boundary_2 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_corridor_outer_boundary_3
*
* FUNCTION ARGUMENTS:
*    uint16 * pcorridor_outer_boundary_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of corridor_outer_boundary_3
*    corridor_outer_boundary_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns corridor_outer_boundary_3 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_corridor_outer_boundary_3( uint16 * pcorridor_outer_boundary_3 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_inner_curve_tlc_reduced_0
*
* FUNCTION ARGUMENTS:
*    uint16 * pinner_curve_tlc_reduced_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of inner_curve_tlc_reduced_0
*    inner_curve_tlc_reduced_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns inner_curve_tlc_reduced_0 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_inner_curve_tlc_reduced_0( uint16 * pinner_curve_tlc_reduced_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_Reserved_7
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_7 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_7
*    Reserved_7 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_7 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_Reserved_7( uint8 * pReserved_7 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_inner_curve_tlc_reduced_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pinner_curve_tlc_reduced_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of inner_curve_tlc_reduced_1
*    inner_curve_tlc_reduced_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns inner_curve_tlc_reduced_1 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_inner_curve_tlc_reduced_1( uint16 * pinner_curve_tlc_reduced_1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_inner_curve_tlc_reduced_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pinner_curve_tlc_reduced_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of inner_curve_tlc_reduced_2
*    inner_curve_tlc_reduced_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns inner_curve_tlc_reduced_2 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_inner_curve_tlc_reduced_2( uint16 * pinner_curve_tlc_reduced_2 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_inner_curve_tlc_reduced_3
*
* FUNCTION ARGUMENTS:
*    uint16 * pinner_curve_tlc_reduced_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of inner_curve_tlc_reduced_3
*    inner_curve_tlc_reduced_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns inner_curve_tlc_reduced_3 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_inner_curve_tlc_reduced_3( uint16 * pinner_curve_tlc_reduced_3 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_Reserved_8
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_8 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_8
*    Reserved_8 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_8 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_Reserved_8( uint8 * pReserved_8 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_inner_curve_tlc_shift_thresh_0
*
* FUNCTION ARGUMENTS:
*    uint16 * pinner_curve_tlc_shift_thresh_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of inner_curve_tlc_shift_thresh_0
*    inner_curve_tlc_shift_thresh_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns inner_curve_tlc_shift_thresh_0 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_inner_curve_tlc_shift_thresh_0( uint16 * pinner_curve_tlc_shift_thresh_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_inner_curve_tlc_shift_thresh_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pinner_curve_tlc_shift_thresh_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of inner_curve_tlc_shift_thresh_1
*    inner_curve_tlc_shift_thresh_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns inner_curve_tlc_shift_thresh_1 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_inner_curve_tlc_shift_thresh_1( uint16 * pinner_curve_tlc_shift_thresh_1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_Reserved_9
*
* FUNCTION ARGUMENTS:
*    uint16 * pReserved_9 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_9
*    Reserved_9 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_9 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_Reserved_9( uint16 * pReserved_9 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_inner_curve_tlc_shift_thresh_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pinner_curve_tlc_shift_thresh_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of inner_curve_tlc_shift_thresh_2
*    inner_curve_tlc_shift_thresh_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns inner_curve_tlc_shift_thresh_2 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_inner_curve_tlc_shift_thresh_2( uint16 * pinner_curve_tlc_shift_thresh_2 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_inner_curve_tlc_shift_thresh_3
*
* FUNCTION ARGUMENTS:
*    uint16 * pinner_curve_tlc_shift_thresh_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of inner_curve_tlc_shift_thresh_3
*    inner_curve_tlc_shift_thresh_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns inner_curve_tlc_shift_thresh_3 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_inner_curve_tlc_shift_thresh_3( uint16 * pinner_curve_tlc_shift_thresh_3 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_LDWINIT_Reserved_10
*
* FUNCTION ARGUMENTS:
*    uint16 * pReserved_10 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_10
*    Reserved_10 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_10 signal value of LDW_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_LDWINIT_Reserved_10( uint16 * pReserved_10 );
/*****************************************************************************
                  Exported object declarations
*****************************************************************************/
extern EYEQMSG_LDWINIT_Params_t   EYEQMSG_LDWINIT_Params_s;
extern EYEQMSG_LDWINIT_Params_t   EYEQMSG_LDWINIT_ParamsApp_s;
/****************************************************************************/
#endif /* _EYEQMSG_LDWINITPROCESS_H_ */


