#ifndef _EYEQMSG_CORECOMMONPROCESS_H_
#define _EYEQMSG_CORECOMMONPROCESS_H_

/*****************************************************************************
                  Included header files
*****************************************************************************/
#include <Std_Types.h>

/*****************************************************************************
                  Include files
*****************************************************************************/
/*****************************************************************************
                  Exported symbolic constants
*****************************************************************************/

/* Datagram message ID */
#define C_EYEQMSG_CORECOMMON_MSG_ID                           ( 0x52U )

/* Datagram message lengths */
#define C_EYEQMSG_CORECOMMON_MSG_LEN                          ( sizeof(EYEQMSG_CORECOMMON_Params_t) )

/* Protocol ENUMs */

/* MCU output messages */

/* Core_Common_protocol Enums */
/* Reserved_4_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORECOMMON_RESERVED_4_RMIN                  ( 0U )
#define C_EYEQMSG_CORECOMMON_RESERVED_4_RMAX                  ( 0U )
#define C_EYEQMSG_CORECOMMON_RESERVED_4_NUMR                  ( 1U )
#define C_EYEQMSG_CORECOMMON_RESERVED_4_DEMNR                 ( 1U )
#define C_EYEQMSG_CORECOMMON_RESERVED_4_OFFSET                ( 0U )

/* COM_Tunnel_Conf_b7 signal Min & Max range limits */
#define C_EYEQMSG_CORECOMMON_COM_TUNNEL_CONF_RMIN             ( 0U )
#define C_EYEQMSG_CORECOMMON_COM_TUNNEL_CONF_RMAX             ( 100U )
#define C_EYEQMSG_CORECOMMON_COM_TUNNEL_CONF_NUMR             ( 1U )
#define C_EYEQMSG_CORECOMMON_COM_TUNNEL_CONF_DEMNR            ( 100U )
#define C_EYEQMSG_CORECOMMON_COM_TUNNEL_CONF_OFFSET           ( 0U )

/* COM_Is_In_Tunnel_b2 signal Enums */
typedef uint8 CORECOMMONCOMIsInTunnel;
#define C_EYEQMSG_CORECOMMON_COM_IS_IN_TUNNEL_UNFILLED        ( CORECOMMONCOMIsInTunnel ) ( 0U )
#define C_EYEQMSG_CORECOMMON_COM_IS_IN_TUNNEL_FALSE           ( CORECOMMONCOMIsInTunnel ) ( 1U )
#define C_EYEQMSG_CORECOMMON_COM_IS_IN_TUNNEL_TRUE            ( CORECOMMONCOMIsInTunnel ) ( 2U )

/* COM_Is_In_Tunnel_b2 signal Min & Max range limits */
#define C_EYEQMSG_CORECOMMON_COM_IS_IN_TUNNEL_RMIN            ( 0U )
#define C_EYEQMSG_CORECOMMON_COM_IS_IN_TUNNEL_RMAX            ( 2U )
#define C_EYEQMSG_CORECOMMON_COM_IS_IN_TUNNEL_NUMR            ( 1U )
#define C_EYEQMSG_CORECOMMON_COM_IS_IN_TUNNEL_DEMNR           ( 1U )
#define C_EYEQMSG_CORECOMMON_COM_IS_IN_TUNNEL_OFFSET          ( 0U )

/* COM_Is_HighSpeed_Road_b1 signal Enums */
typedef boolean CORECOMMONCOMIsHighSpeedRoad;
#define C_EYEQMSG_CORECOMMON_COM_IS_HIGHSPEED_ROAD_FALSE      ( CORECOMMONCOMIsHighSpeedRoad ) ( 0U )
#define C_EYEQMSG_CORECOMMON_COM_IS_HIGHSPEED_ROAD_TRUE       ( CORECOMMONCOMIsHighSpeedRoad ) ( 1U )

/* COM_Is_HighSpeed_Road_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORECOMMON_COM_IS_HIGHSPEED_ROAD_RMIN       ( 0U )
#define C_EYEQMSG_CORECOMMON_COM_IS_HIGHSPEED_ROAD_RMAX       ( 1U )
#define C_EYEQMSG_CORECOMMON_COM_IS_HIGHSPEED_ROAD_NUMR       ( 1U )
#define C_EYEQMSG_CORECOMMON_COM_IS_HIGHSPEED_ROAD_DEMNR      ( 1U )
#define C_EYEQMSG_CORECOMMON_COM_IS_HIGHSPEED_ROAD_OFFSET     ( 0U )

/* COM_Is_HighSpeed_Road_V_b1 signal Enums */
typedef boolean CORECOMMONCOMIsHighSpeedRoadV;
#define C_EYEQMSG_CORECOMMON_COM_IS_HIGHSPEED_ROAD_V_FALSE    ( CORECOMMONCOMIsHighSpeedRoadV ) ( 0U )
#define C_EYEQMSG_CORECOMMON_COM_IS_HIGHSPEED_ROAD_V_TRUE     ( CORECOMMONCOMIsHighSpeedRoadV ) ( 1U )

/* COM_Is_HighSpeed_Road_V_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORECOMMON_COM_IS_HIGHSPEED_ROAD_V_RMIN     ( 0U )
#define C_EYEQMSG_CORECOMMON_COM_IS_HIGHSPEED_ROAD_V_RMAX     ( 1U )
#define C_EYEQMSG_CORECOMMON_COM_IS_HIGHSPEED_ROAD_V_NUMR     ( 1U )
#define C_EYEQMSG_CORECOMMON_COM_IS_HIGHSPEED_ROAD_V_DEMNR    ( 1U )
#define C_EYEQMSG_CORECOMMON_COM_IS_HIGHSPEED_ROAD_V_OFFSET   ( 0U )

/* COM_Driving_Side_b8 signal Enums */
typedef uint8 CORECOMMONCOMDrivingSide;
#define C_EYEQMSG_CORECOMMON_COM_DRIVING_SIDE_UNKNOWN         ( CORECOMMONCOMDrivingSide ) ( 0U )
#define C_EYEQMSG_CORECOMMON_COM_DRIVING_SIDE_LEFT            ( CORECOMMONCOMDrivingSide ) ( 1U )
#define C_EYEQMSG_CORECOMMON_COM_DRIVING_SIDE_RIGHT           ( CORECOMMONCOMDrivingSide ) ( 2U )

/* COM_Driving_Side_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORECOMMON_COM_DRIVING_SIDE_RMIN            ( 0U )
#define C_EYEQMSG_CORECOMMON_COM_DRIVING_SIDE_RMAX            ( 2U )
#define C_EYEQMSG_CORECOMMON_COM_DRIVING_SIDE_NUMR            ( 1U )
#define C_EYEQMSG_CORECOMMON_COM_DRIVING_SIDE_DEMNR           ( 1U )
#define C_EYEQMSG_CORECOMMON_COM_DRIVING_SIDE_OFFSET          ( 0U )

/* COM_Driving_Side_V_b1 signal Enums */
typedef boolean CORECOMMONCOMDrivingSideV;
#define C_EYEQMSG_CORECOMMON_COM_DRIVING_SIDE_V_FALSE         ( CORECOMMONCOMDrivingSideV ) ( 0U )
#define C_EYEQMSG_CORECOMMON_COM_DRIVING_SIDE_V_TRUE          ( CORECOMMONCOMDrivingSideV ) ( 1U )

/* COM_Driving_Side_V_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORECOMMON_COM_DRIVING_SIDE_V_RMIN          ( 0U )
#define C_EYEQMSG_CORECOMMON_COM_DRIVING_SIDE_V_RMAX          ( 1U )
#define C_EYEQMSG_CORECOMMON_COM_DRIVING_SIDE_V_NUMR          ( 1U )
#define C_EYEQMSG_CORECOMMON_COM_DRIVING_SIDE_V_DEMNR         ( 1U )
#define C_EYEQMSG_CORECOMMON_COM_DRIVING_SIDE_V_OFFSET        ( 0U )

/* COM_Region_Code_b5 signal Enums */
typedef uint8 CORECOMMONCOMRegionCode;
#define C_EYEQMSG_CORECOMMON_COM_REGION_CODE_WORLD            ( CORECOMMONCOMRegionCode ) ( 0U )
#define C_EYEQMSG_CORECOMMON_COM_REGION_CODE_EUROPE           ( CORECOMMONCOMRegionCode ) ( 1U )
#define C_EYEQMSG_CORECOMMON_COM_REGION_CODE_GULF             ( CORECOMMONCOMRegionCode ) ( 2U )
#define C_EYEQMSG_CORECOMMON_COM_REGION_CODE_USA              ( CORECOMMONCOMRegionCode ) ( 3U )
#define C_EYEQMSG_CORECOMMON_COM_REGION_CODE_CANADA           ( CORECOMMONCOMRegionCode ) ( 4U )
#define C_EYEQMSG_CORECOMMON_COM_REGION_CODE_JAPAN            ( CORECOMMONCOMRegionCode ) ( 5U )
#define C_EYEQMSG_CORECOMMON_COM_REGION_CODE_CHINA            ( CORECOMMONCOMRegionCode ) ( 6U )
#define C_EYEQMSG_CORECOMMON_COM_REGION_CODE_SOUTH_AFRICA     ( CORECOMMONCOMRegionCode ) ( 7U )
#define C_EYEQMSG_CORECOMMON_COM_REGION_CODE_KOREA            ( CORECOMMONCOMRegionCode ) ( 8U )
#define C_EYEQMSG_CORECOMMON_COM_REGION_CODE_AUSTRALIA_AND_NZ ( CORECOMMONCOMRegionCode ) ( 9U )
#define C_EYEQMSG_CORECOMMON_COM_REGION_CODE_UK               ( CORECOMMONCOMRegionCode ) ( 10U )
#define C_EYEQMSG_CORECOMMON_COM_REGION_CODE_INDIA            ( CORECOMMONCOMRegionCode ) ( 11U )

/* COM_Region_Code_b5 signal Min & Max range limits */
#define C_EYEQMSG_CORECOMMON_COM_REGION_CODE_RMIN             ( 0U )
#define C_EYEQMSG_CORECOMMON_COM_REGION_CODE_RMAX             ( 11U )
#define C_EYEQMSG_CORECOMMON_COM_REGION_CODE_NUMR             ( 1U )
#define C_EYEQMSG_CORECOMMON_COM_REGION_CODE_DEMNR            ( 1U )
#define C_EYEQMSG_CORECOMMON_COM_REGION_CODE_OFFSET           ( 0U )

/* COM_Region_Code_V_b1 signal Enums */
typedef boolean CORECOMMONCOMRegionCodeV;
#define C_EYEQMSG_CORECOMMON_COM_REGION_CODE_V_FALSE          ( CORECOMMONCOMRegionCodeV ) ( 0U )
#define C_EYEQMSG_CORECOMMON_COM_REGION_CODE_V_TRUE           ( CORECOMMONCOMRegionCodeV ) ( 1U )

/* COM_Region_Code_V_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORECOMMON_COM_REGION_CODE_V_RMIN           ( 0U )
#define C_EYEQMSG_CORECOMMON_COM_REGION_CODE_V_RMAX           ( 1U )
#define C_EYEQMSG_CORECOMMON_COM_REGION_CODE_V_NUMR           ( 1U )
#define C_EYEQMSG_CORECOMMON_COM_REGION_CODE_V_DEMNR          ( 1U )
#define C_EYEQMSG_CORECOMMON_COM_REGION_CODE_V_OFFSET         ( 0U )

/* COM_Exposure_Type_b2 signal Enums */
typedef uint8 CORECOMMONCOMExposureType;
#define C_EYEQMSG_CORECOMMON_COM_EXPOSURE_TYPE_TEXTURE_T0     ( CORECOMMONCOMExposureType ) ( 0U )
#define C_EYEQMSG_CORECOMMON_COM_EXPOSURE_TYPE_COLOR_C0       ( CORECOMMONCOMExposureType ) ( 1U )
#define C_EYEQMSG_CORECOMMON_COM_EXPOSURE_TYPE_TEXTURE_T1     ( CORECOMMONCOMExposureType ) ( 2U )
#define C_EYEQMSG_CORECOMMON_COM_EXPOSURE_TYPE_COLOR_C1       ( CORECOMMONCOMExposureType ) ( 3U )

/* COM_Exposure_Type_b2 signal Min & Max range limits */
#define C_EYEQMSG_CORECOMMON_COM_EXPOSURE_TYPE_RMIN           ( 0U )
#define C_EYEQMSG_CORECOMMON_COM_EXPOSURE_TYPE_RMAX           ( 3U )
#define C_EYEQMSG_CORECOMMON_COM_EXPOSURE_TYPE_NUMR           ( 1U )
#define C_EYEQMSG_CORECOMMON_COM_EXPOSURE_TYPE_DEMNR          ( 1U )
#define C_EYEQMSG_CORECOMMON_COM_EXPOSURE_TYPE_OFFSET         ( 0U )

/* COM_HIL_Mode_Status_b1 signal Enums */
typedef boolean CORECOMMONCOMHILModeStatus;
#define C_EYEQMSG_CORECOMMON_COM_HIL_MODE_STATUS_NOT_ACTIVE   ( CORECOMMONCOMHILModeStatus ) ( 0U )
#define C_EYEQMSG_CORECOMMON_COM_HIL_MODE_STATUS_ACTIVE       ( CORECOMMONCOMHILModeStatus ) ( 1U )

/* COM_HIL_Mode_Status_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORECOMMON_COM_HIL_MODE_STATUS_RMIN         ( 0U )
#define C_EYEQMSG_CORECOMMON_COM_HIL_MODE_STATUS_RMAX         ( 1U )
#define C_EYEQMSG_CORECOMMON_COM_HIL_MODE_STATUS_NUMR         ( 1U )
#define C_EYEQMSG_CORECOMMON_COM_HIL_MODE_STATUS_DEMNR        ( 1U )
#define C_EYEQMSG_CORECOMMON_COM_HIL_MODE_STATUS_OFFSET       ( 0U )

/* COM_DayTime_Indicator_b2 signal Enums */
typedef uint8 CORECOMMONCOMDayTimeIndicator;
#define C_EYEQMSG_CORECOMMON_COM_DAYTIME_INDICATOR_DAY        ( CORECOMMONCOMDayTimeIndicator ) ( 0U )
#define C_EYEQMSG_CORECOMMON_COM_DAYTIME_INDICATOR_NA         ( CORECOMMONCOMDayTimeIndicator ) ( 1U )
#define C_EYEQMSG_CORECOMMON_COM_DAYTIME_INDICATOR_NIGHT      ( CORECOMMONCOMDayTimeIndicator ) ( 2U )

/* COM_DayTime_Indicator_b2 signal Min & Max range limits */
#define C_EYEQMSG_CORECOMMON_COM_DAYTIME_INDICATOR_RMIN       ( 0U )
#define C_EYEQMSG_CORECOMMON_COM_DAYTIME_INDICATOR_RMAX       ( 2U )
#define C_EYEQMSG_CORECOMMON_COM_DAYTIME_INDICATOR_NUMR       ( 1U )
#define C_EYEQMSG_CORECOMMON_COM_DAYTIME_INDICATOR_DEMNR      ( 1U )
#define C_EYEQMSG_CORECOMMON_COM_DAYTIME_INDICATOR_OFFSET     ( 0U )

/* COM_Cam_Frame_ID_b32 signal Min & Max range limits */
#define C_EYEQMSG_CORECOMMON_COM_CAM_FRAME_ID_RMIN            ( 0U )
#define C_EYEQMSG_CORECOMMON_COM_CAM_FRAME_ID_RMAX            ( 4294967295U )
#define C_EYEQMSG_CORECOMMON_COM_CAM_FRAME_ID_NUMR            ( 1U )
#define C_EYEQMSG_CORECOMMON_COM_CAM_FRAME_ID_DEMNR           ( 1U )
#define C_EYEQMSG_CORECOMMON_COM_CAM_FRAME_ID_OFFSET          ( 0U )

/* COM_EyeQ_Frame_ID_b32 signal Min & Max range limits */
#define C_EYEQMSG_CORECOMMON_COM_EYEQ_FRAME_ID_RMIN           ( 0U )
#define C_EYEQMSG_CORECOMMON_COM_EYEQ_FRAME_ID_RMAX           ( 4294967295U )
#define C_EYEQMSG_CORECOMMON_COM_EYEQ_FRAME_ID_NUMR           ( 1U )
#define C_EYEQMSG_CORECOMMON_COM_EYEQ_FRAME_ID_DEMNR          ( 1U )
#define C_EYEQMSG_CORECOMMON_COM_EYEQ_FRAME_ID_OFFSET         ( 0U )

/* Reserved_3_b9 signal Min & Max range limits */
#define C_EYEQMSG_CORECOMMON_RESERVED_3_RMIN                  ( 0U )
#define C_EYEQMSG_CORECOMMON_RESERVED_3_RMAX                  ( 0U )
#define C_EYEQMSG_CORECOMMON_RESERVED_3_NUMR                  ( 1U )
#define C_EYEQMSG_CORECOMMON_RESERVED_3_DEMNR                 ( 1U )
#define C_EYEQMSG_CORECOMMON_RESERVED_3_OFFSET                ( 0U )

/* COM_Last_Clock_Sync_Error_b1 signal Enums */
typedef boolean CORECOMMONCOMLastClockSyncError;
#define C_EYEQMSG_CORECOMMON_COM_LAST_CLOCK_SYNC_ERROR_FALSE  ( CORECOMMONCOMLastClockSyncError ) ( 0U )
#define C_EYEQMSG_CORECOMMON_COM_LAST_CLOCK_SYNC_ERROR_TRUE   ( CORECOMMONCOMLastClockSyncError ) ( 1U )

/* COM_Last_Clock_Sync_Error_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORECOMMON_COM_LAST_CLOCK_SYNC_ERROR_RMIN   ( 0U )
#define C_EYEQMSG_CORECOMMON_COM_LAST_CLOCK_SYNC_ERROR_RMAX   ( 1U )
#define C_EYEQMSG_CORECOMMON_COM_LAST_CLOCK_SYNC_ERROR_NUMR   ( 1U )
#define C_EYEQMSG_CORECOMMON_COM_LAST_CLOCK_SYNC_ERROR_DEMNR  ( 1U )
#define C_EYEQMSG_CORECOMMON_COM_LAST_CLOCK_SYNC_ERROR_OFFSET ( 0U )

/* COM_Last_Clock_Sync_Skew_b22 signal Min & Max range limits */
#define C_EYEQMSG_CORECOMMON_COM_LAST_CLOCK_SYNC_SKEW_RMIN    ( 0U )
#define C_EYEQMSG_CORECOMMON_COM_LAST_CLOCK_SYNC_SKEW_RMAX    ( 200000U )
#define C_EYEQMSG_CORECOMMON_COM_LAST_CLOCK_SYNC_SKEW_NUMR    ( 1 )
#define C_EYEQMSG_CORECOMMON_COM_LAST_CLOCK_SYNC_SKEW_DEMNR   ( 1 )
#define C_EYEQMSG_CORECOMMON_COM_LAST_CLOCK_SYNC_SKEW_OFFSET  ( -100000 )

/* COM_Last_MCU_Sync_TS_b64 signal Min & Max range limits */
#define C_EYEQMSG_CORECOMMON_COM_LAST_MCU_SYNC_TS_RMIN        ( 0U )
#define C_EYEQMSG_CORECOMMON_COM_LAST_MCU_SYNC_TS_RMAX        ( 18446744073709551615U )
#define C_EYEQMSG_CORECOMMON_COM_LAST_MCU_SYNC_TS_NUMR        ( 1U )
#define C_EYEQMSG_CORECOMMON_COM_LAST_MCU_SYNC_TS_DEMNR       ( 1U )
#define C_EYEQMSG_CORECOMMON_COM_LAST_MCU_SYNC_TS_OFFSET      ( 0U )

/* COM_Frame_MCU_TS_Start_b64 signal Min & Max range limits */
#define C_EYEQMSG_CORECOMMON_COM_FRAME_MCU_TS_START_RMIN      ( 0U )
#define C_EYEQMSG_CORECOMMON_COM_FRAME_MCU_TS_START_RMAX      ( 18446744073709551615U )
#define C_EYEQMSG_CORECOMMON_COM_FRAME_MCU_TS_START_NUMR      ( 1U )
#define C_EYEQMSG_CORECOMMON_COM_FRAME_MCU_TS_START_DEMNR     ( 1U )
#define C_EYEQMSG_CORECOMMON_COM_FRAME_MCU_TS_START_OFFSET    ( 0U )

/* Reserved_2_b16 signal Min & Max range limits */
#define C_EYEQMSG_CORECOMMON_RESERVED_2_RMIN                  ( 0U )
#define C_EYEQMSG_CORECOMMON_RESERVED_2_RMAX                  ( 0U )
#define C_EYEQMSG_CORECOMMON_RESERVED_2_NUMR                  ( 1U )
#define C_EYEQMSG_CORECOMMON_RESERVED_2_DEMNR                 ( 1U )
#define C_EYEQMSG_CORECOMMON_RESERVED_2_OFFSET                ( 0U )

/* COM_Sync_Frame_ID_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORECOMMON_COM_SYNC_FRAME_ID_RMIN           ( 0U )
#define C_EYEQMSG_CORECOMMON_COM_SYNC_FRAME_ID_RMAX           ( 255U )
#define C_EYEQMSG_CORECOMMON_COM_SYNC_FRAME_ID_NUMR           ( 1U )
#define C_EYEQMSG_CORECOMMON_COM_SYNC_FRAME_ID_DEMNR          ( 1U )
#define C_EYEQMSG_CORECOMMON_COM_SYNC_FRAME_ID_OFFSET         ( 0U )

/* COM_Protocol_Version_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORECOMMON_COM_PROTOCOL_VERSION_RMIN        ( 8U )
#define C_EYEQMSG_CORECOMMON_COM_PROTOCOL_VERSION_RMAX        ( 8U )
#define C_EYEQMSG_CORECOMMON_COM_PROTOCOL_VERSION_NUMR        ( 1U )
#define C_EYEQMSG_CORECOMMON_COM_PROTOCOL_VERSION_DEMNR       ( 1U )
#define C_EYEQMSG_CORECOMMON_COM_PROTOCOL_VERSION_OFFSET      ( 0U )

/* COM_CRC_b32 signal Min & Max range limits */
#define C_EYEQMSG_CORECOMMON_COM_CRC_RMIN                     ( 0U )
#define C_EYEQMSG_CORECOMMON_COM_CRC_RMAX                     ( 4294967295U )
#define C_EYEQMSG_CORECOMMON_COM_CRC_NUMR                     ( 1U )
#define C_EYEQMSG_CORECOMMON_COM_CRC_DEMNR                    ( 1U )
#define C_EYEQMSG_CORECOMMON_COM_CRC_OFFSET                   ( 0U )

/* Reserved_1_b24 signal Min & Max range limits */
#define C_EYEQMSG_CORECOMMON_RESERVED_1_RMIN                  ( 0U )
#define C_EYEQMSG_CORECOMMON_RESERVED_1_RMAX                  ( 0U )
#define C_EYEQMSG_CORECOMMON_RESERVED_1_NUMR                  ( 1U )
#define C_EYEQMSG_CORECOMMON_RESERVED_1_DEMNR                 ( 1U )
#define C_EYEQMSG_CORECOMMON_RESERVED_1_OFFSET                ( 0U )

/* COM_Zero_byte_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORECOMMON_COM_ZERO_BYTE_RMIN               ( 0U )
#define C_EYEQMSG_CORECOMMON_COM_ZERO_BYTE_RMAX               ( 255U )
#define C_EYEQMSG_CORECOMMON_COM_ZERO_BYTE_NUMR               ( 1U )
#define C_EYEQMSG_CORECOMMON_COM_ZERO_BYTE_DEMNR              ( 1U )
#define C_EYEQMSG_CORECOMMON_COM_ZERO_BYTE_OFFSET             ( 0U )


/*****************************************************************************
                  Exported function-like macros
*****************************************************************************/
/*****************************************************************************
                  Exported defined macros
*****************************************************************************/
/*****************************************************************************
                  Exported types, enums definitions
*****************************************************************************/
typedef struct
{
   #if ENABLE_BIG_ENDIAN_FORMAT
      uint32        COM_Zero_byte_b8                             : 8U;
      
      uint32        Reserved_1_1_b8                              : 8U;
      
      uint32        Reserved_1_2_b8                              : 8U;
      
      uint32        Reserved_1_3_b8                              : 8U;
      
      uint32        COM_CRC_1_b8                                 : 8U;
      
      uint32        COM_CRC_2_b8                                 : 8U;
      
      uint32        COM_CRC_3_b8                                 : 8U;
      
      uint32        COM_CRC_4_b8                                 : 8U;
      
      uint32        COM_Protocol_Version_b8                      : 8U;
      
      uint32        COM_Sync_Frame_ID_b8                         : 8U;
      
      uint32        Reserved_2_1_b8                              : 8U;
      
      uint32        Reserved_2_2_b8                              : 8U;
      
      uint32        COM_Frame_MCU_TS_Start_1_b8                  : 8U;
      
      uint32        COM_Frame_MCU_TS_Start_2_b8                  : 8U;
      
      uint32        COM_Frame_MCU_TS_Start_3_b8                  : 8U;
      
      uint32        COM_Frame_MCU_TS_Start_4_b8                  : 8U;
      
      uint32        COM_Frame_MCU_TS_Start_5_b8                  : 8U;
      
      uint32        COM_Frame_MCU_TS_Start_6_b8                  : 8U;
      
      uint32        COM_Frame_MCU_TS_Start_7_b8                  : 8U;
      
      uint32        COM_Frame_MCU_TS_Start_8_b8                  : 8U;
      
      uint32        COM_Last_MCU_Sync_TS_1_b8                    : 8U;
      
      uint32        COM_Last_MCU_Sync_TS_2_b8                    : 8U;
      
      uint32        COM_Last_MCU_Sync_TS_3_b8                    : 8U;
      
      uint32        COM_Last_MCU_Sync_TS_4_b8                    : 8U;
      
      uint32        COM_Last_MCU_Sync_TS_5_b8                    : 8U;
      
      uint32        COM_Last_MCU_Sync_TS_6_b8                    : 8U;
      
      uint32        COM_Last_MCU_Sync_TS_7_b8                    : 8U;
      
      uint32        COM_Last_MCU_Sync_TS_8_b8                    : 8U;
      
      uint32        COM_Last_Clock_Sync_Skew_1_b8                : 8U;
      
      uint32        COM_Last_Clock_Sync_Skew_2_b8                : 8U;
      
      uint32        unused1_b2                                   : 2;
      uint32        COM_Last_Clock_Sync_Skew_3_b6                : 6U;
      
      uint32        COM_Last_Clock_Sync_Error_b1                 : 1U;
      
      uint32        Reserved_3_1_b1                              : 1U;
      
      uint32        Reserved_3_2_b8                              : 8U;
      
      uint32        COM_EyeQ_Frame_ID_1_b8                       : 8U;
      
      uint32        COM_EyeQ_Frame_ID_2_b8                       : 8U;
      
      uint32        COM_EyeQ_Frame_ID_3_b8                       : 8U;
      
      uint32        COM_EyeQ_Frame_ID_4_b8                       : 8U;
      
      uint32        COM_Cam_Frame_ID_1_b8                        : 8U;
      
      uint32        COM_Cam_Frame_ID_2_b8                        : 8U;
      
      uint32        COM_Cam_Frame_ID_3_b8                        : 8U;
      
      uint32        COM_Cam_Frame_ID_4_b8                        : 8U;
      
      uint32        unused2_b4                                   : 4;
      uint32        COM_DayTime_Indicator_b2                     : 2U;
      
      uint32        COM_HIL_Mode_Status_b1                       : 1U;
      
      uint32        COM_Exposure_Type_b2                         : 2U;
      
      uint32        COM_Region_Code_V_b1                         : 1U;
      
      uint32        COM_Region_Code_1_b2                         : 2U;
      
      uint32        COM_Region_Code_2_b3                         : 3U;
      
      uint32        COM_Driving_Side_V_b1                        : 1U;
      
      uint32        COM_Driving_Side_1_b4                        : 4U;
      
      uint32        COM_Driving_Side_2_b4                        : 4U;
      
      uint32        COM_Is_HighSpeed_Road_V_b1                   : 1U;
      
      uint32        COM_Is_HighSpeed_Road_b1                     : 1U;
      
      uint32        COM_Is_In_Tunnel_b2                          : 2U;
      
      uint32        COM_Tunnel_Conf_b7                           : 7U;
      
      uint32        Reserved_4_b1                                : 1U;
      
   #else
      uint32        COM_Zero_byte_b8                             : 8U;
      
      uint32        Reserved_1_b24                               : 24U;
      
      uint32        COM_CRC_b32                                  : 32U;
      
      uint32        COM_Protocol_Version_b8                      : 8U;
      
      uint32        COM_Sync_Frame_ID_b8                         : 8U;
      
      uint32        Reserved_2_b16                               : 16U;
      
      uint32        COM_Frame_MCU_TS_Start_1_b32                 : 32U;
      
      uint32        COM_Frame_MCU_TS_Start_2_b32                 : 32U;
      
      uint32        COM_Last_MCU_Sync_TS_1_b32                   : 32U;
      
      uint32        COM_Last_MCU_Sync_TS_2_b32                   : 32U;
      
      uint32        COM_Last_Clock_Sync_Skew_b22                 : 22U;
      
      uint32        COM_Last_Clock_Sync_Error_b1                 : 1U;
      
      uint32        Reserved_3_b9                                : 9U;
      
      uint32        COM_EyeQ_Frame_ID_b32                        : 32U;
      
      uint32        COM_Cam_Frame_ID_b32                         : 32U;
      
      uint32        COM_DayTime_Indicator_b2                     : 2U;
      
      uint32        COM_HIL_Mode_Status_b1                       : 1U;
      
      uint32        COM_Exposure_Type_b2                         : 2U;
      
      uint32        COM_Region_Code_V_b1                         : 1U;
      
      uint32        COM_Region_Code_b5                           : 5U;
      
      uint32        COM_Driving_Side_V_b1                        : 1U;
      
      uint32        COM_Driving_Side_b8                          : 8U;
      
      uint32        COM_Is_HighSpeed_Road_V_b1                   : 1U;
      
      uint32        COM_Is_HighSpeed_Road_b1                     : 1U;
      
      uint32        COM_Is_In_Tunnel_b2                          : 2U;
      
      uint32        COM_Tunnel_Conf_b7                           : 7U;
      
      uint32        Reserved_4_b1                                : 1U;
      
   #endif
} EYEQMSG_CORECOMMON_Params_t;


/*****************************************************************************
                  Exported function prototypes
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_CORECOMMON_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_CORECOMMON_Params_t * pCore_Common_protocol - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_Common_protocol message 
*    Core_Common_protocol message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_Common_protocol message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_CORECOMMON_ParamsApp_MsgDataStruct( EYEQMSG_CORECOMMON_Params_t * pCore_Common_protocol );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECOMMON_COM_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pCOM_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of COM_Zero_byte
*    COM_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns COM_Zero_byte signal value of Core_Common_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECOMMON_COM_Zero_byte( uint8 * pCOM_Zero_byte );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECOMMON_Reserved_1
*
* FUNCTION ARGUMENTS:
*    uint32 * pReserved_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1
*    Reserved_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1 signal value of Core_Common_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECOMMON_Reserved_1( uint32 * pReserved_1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECOMMON_COM_CRC
*
* FUNCTION ARGUMENTS:
*    uint32 * pCOM_CRC - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of COM_CRC
*    COM_CRC returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns COM_CRC signal value of Core_Common_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECOMMON_COM_CRC( uint32 * pCOM_CRC );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECOMMON_COM_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pCOM_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of COM_Protocol_Version
*    COM_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns COM_Protocol_Version signal value of Core_Common_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECOMMON_COM_Protocol_Version( uint8 * pCOM_Protocol_Version );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECOMMON_COM_Sync_Frame_ID
*
* FUNCTION ARGUMENTS:
*    uint8 * pCOM_Sync_Frame_ID - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of COM_Sync_Frame_ID
*    COM_Sync_Frame_ID returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns COM_Sync_Frame_ID signal value of Core_Common_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECOMMON_COM_Sync_Frame_ID( uint8 * pCOM_Sync_Frame_ID );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECOMMON_Reserved_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pReserved_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_2
*    Reserved_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_2 signal value of Core_Common_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECOMMON_Reserved_2( uint16 * pReserved_2 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECOMMON_COM_Frame_MCU_TS_Start
*
* FUNCTION ARGUMENTS:
*    uint64 * pCOM_Frame_MCU_TS_Start - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of COM_Frame_MCU_TS_Start
*    COM_Frame_MCU_TS_Start returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns COM_Frame_MCU_TS_Start signal value of Core_Common_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECOMMON_COM_Frame_MCU_TS_Start( uint64 * pCOM_Frame_MCU_TS_Start );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECOMMON_COM_Last_MCU_Sync_TS
*
* FUNCTION ARGUMENTS:
*    uint64 * pCOM_Last_MCU_Sync_TS - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of COM_Last_MCU_Sync_TS
*    COM_Last_MCU_Sync_TS returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns COM_Last_MCU_Sync_TS signal value of Core_Common_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECOMMON_COM_Last_MCU_Sync_TS( uint64 * pCOM_Last_MCU_Sync_TS );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECOMMON_COM_Last_Clock_Sync_Skew
*
* FUNCTION ARGUMENTS:
*    uint32 * pCOM_Last_Clock_Sync_Skew - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of COM_Last_Clock_Sync_Skew
*    COM_Last_Clock_Sync_Skew returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns COM_Last_Clock_Sync_Skew signal value of Core_Common_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECOMMON_COM_Last_Clock_Sync_Skew( uint32 * pCOM_Last_Clock_Sync_Skew );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECOMMON_COM_Last_Clock_Sync_Error
*
* FUNCTION ARGUMENTS:
*    CORECOMMONCOMLastClockSyncError * pCOM_Last_Clock_Sync_Error - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of COM_Last_Clock_Sync_Error
*    COM_Last_Clock_Sync_Error returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns COM_Last_Clock_Sync_Error signal value of Core_Common_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECOMMON_COM_Last_Clock_Sync_Error( CORECOMMONCOMLastClockSyncError * pCOM_Last_Clock_Sync_Error );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECOMMON_Reserved_3
*
* FUNCTION ARGUMENTS:
*    uint16 * pReserved_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_3
*    Reserved_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_3 signal value of Core_Common_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECOMMON_Reserved_3( uint16 * pReserved_3 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECOMMON_COM_EyeQ_Frame_ID
*
* FUNCTION ARGUMENTS:
*    uint32 * pCOM_EyeQ_Frame_ID - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of COM_EyeQ_Frame_ID
*    COM_EyeQ_Frame_ID returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns COM_EyeQ_Frame_ID signal value of Core_Common_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECOMMON_COM_EyeQ_Frame_ID( uint32 * pCOM_EyeQ_Frame_ID );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECOMMON_COM_Cam_Frame_ID
*
* FUNCTION ARGUMENTS:
*    uint32 * pCOM_Cam_Frame_ID - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of COM_Cam_Frame_ID
*    COM_Cam_Frame_ID returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns COM_Cam_Frame_ID signal value of Core_Common_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECOMMON_COM_Cam_Frame_ID( uint32 * pCOM_Cam_Frame_ID );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECOMMON_COM_DayTime_Indicator
*
* FUNCTION ARGUMENTS:
*    CORECOMMONCOMDayTimeIndicator * pCOM_DayTime_Indicator - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of COM_DayTime_Indicator
*    COM_DayTime_Indicator returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns COM_DayTime_Indicator signal value of Core_Common_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECOMMON_COM_DayTime_Indicator( CORECOMMONCOMDayTimeIndicator * pCOM_DayTime_Indicator );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECOMMON_COM_HIL_Mode_Status
*
* FUNCTION ARGUMENTS:
*    CORECOMMONCOMHILModeStatus * pCOM_HIL_Mode_Status - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of COM_HIL_Mode_Status
*    COM_HIL_Mode_Status returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns COM_HIL_Mode_Status signal value of Core_Common_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECOMMON_COM_HIL_Mode_Status( CORECOMMONCOMHILModeStatus * pCOM_HIL_Mode_Status );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECOMMON_COM_Exposure_Type
*
* FUNCTION ARGUMENTS:
*    CORECOMMONCOMExposureType * pCOM_Exposure_Type - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of COM_Exposure_Type
*    COM_Exposure_Type returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns COM_Exposure_Type signal value of Core_Common_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECOMMON_COM_Exposure_Type( CORECOMMONCOMExposureType * pCOM_Exposure_Type );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECOMMON_COM_Region_Code_V
*
* FUNCTION ARGUMENTS:
*    CORECOMMONCOMRegionCodeV * pCOM_Region_Code_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of COM_Region_Code_V
*    COM_Region_Code_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns COM_Region_Code_V signal value of Core_Common_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECOMMON_COM_Region_Code_V( CORECOMMONCOMRegionCodeV * pCOM_Region_Code_V );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECOMMON_COM_Region_Code
*
* FUNCTION ARGUMENTS:
*    CORECOMMONCOMRegionCode * pCOM_Region_Code - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of COM_Region_Code
*    COM_Region_Code returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns COM_Region_Code signal value of Core_Common_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECOMMON_COM_Region_Code( CORECOMMONCOMRegionCode * pCOM_Region_Code );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECOMMON_COM_Driving_Side_V
*
* FUNCTION ARGUMENTS:
*    CORECOMMONCOMDrivingSideV * pCOM_Driving_Side_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of COM_Driving_Side_V
*    COM_Driving_Side_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns COM_Driving_Side_V signal value of Core_Common_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECOMMON_COM_Driving_Side_V( CORECOMMONCOMDrivingSideV * pCOM_Driving_Side_V );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECOMMON_COM_Driving_Side
*
* FUNCTION ARGUMENTS:
*    CORECOMMONCOMDrivingSide * pCOM_Driving_Side - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of COM_Driving_Side
*    COM_Driving_Side returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns COM_Driving_Side signal value of Core_Common_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECOMMON_COM_Driving_Side( CORECOMMONCOMDrivingSide * pCOM_Driving_Side );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECOMMON_COM_Is_HighSpeed_Road_V
*
* FUNCTION ARGUMENTS:
*    CORECOMMONCOMIsHighSpeedRoadV * pCOM_Is_HighSpeed_Road_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of COM_Is_HighSpeed_Road_V
*    COM_Is_HighSpeed_Road_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns COM_Is_HighSpeed_Road_V signal value of Core_Common_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECOMMON_COM_Is_HighSpeed_Road_V( CORECOMMONCOMIsHighSpeedRoadV * pCOM_Is_HighSpeed_Road_V );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECOMMON_COM_Is_HighSpeed_Road
*
* FUNCTION ARGUMENTS:
*    CORECOMMONCOMIsHighSpeedRoad * pCOM_Is_HighSpeed_Road - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of COM_Is_HighSpeed_Road
*    COM_Is_HighSpeed_Road returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns COM_Is_HighSpeed_Road signal value of Core_Common_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECOMMON_COM_Is_HighSpeed_Road( CORECOMMONCOMIsHighSpeedRoad * pCOM_Is_HighSpeed_Road );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECOMMON_COM_Is_In_Tunnel
*
* FUNCTION ARGUMENTS:
*    CORECOMMONCOMIsInTunnel * pCOM_Is_In_Tunnel - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of COM_Is_In_Tunnel
*    COM_Is_In_Tunnel returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns COM_Is_In_Tunnel signal value of Core_Common_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECOMMON_COM_Is_In_Tunnel( CORECOMMONCOMIsInTunnel * pCOM_Is_In_Tunnel );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECOMMON_COM_Tunnel_Conf
*
* FUNCTION ARGUMENTS:
*    uint8 * pCOM_Tunnel_Conf - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of COM_Tunnel_Conf
*    COM_Tunnel_Conf returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns COM_Tunnel_Conf signal value of Core_Common_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECOMMON_COM_Tunnel_Conf( uint8 * pCOM_Tunnel_Conf );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECOMMON_Reserved_4
*
* FUNCTION ARGUMENTS:
*    boolean * pReserved_4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_4
*    Reserved_4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_4 signal value of Core_Common_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECOMMON_Reserved_4( boolean * pReserved_4 );
/*****************************************************************************
                  Exported object declarations
*****************************************************************************/
extern EYEQMSG_CORECOMMON_Params_t   EYEQMSG_CORECOMMON_Params_s;
extern EYEQMSG_CORECOMMON_Params_t   EYEQMSG_CORECOMMON_ParamsApp_s;
/****************************************************************************/
#endif /* _EYEQMSG_CORECOMMONPROCESS_H_ */


