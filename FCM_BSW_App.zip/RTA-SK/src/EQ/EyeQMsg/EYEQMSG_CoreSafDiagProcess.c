

/*****************************************************************************
                  Include files
*****************************************************************************/
/* The suggested include file order is: */
#include "EyeQ_defs.h"    /* EyeQ project common definitions file    */

#include "EYEQMSG_CoreSafDiagProcess.h"

/*****************************************************************************
                  Local symbolic constants
*****************************************************************************/
/*****************************************************************************
                  Local types, enums definitions
*****************************************************************************/
/*****************************************************************************
                  Local function prototypes
*****************************************************************************/
/*****************************************************************************
                  Local object definitions
*****************************************************************************/
/*****************************************************************************
                  Exported object definitions
*****************************************************************************/
EYEQMSG_CORESAFDIAG_Params_t   EYEQMSG_CORESAFDIAG_Params_s;
EYEQMSG_CORESAFDIAG_Params_t   EYEQMSG_CORESAFDIAG_ParamsApp_s;
/*****************************************************************************
                  Local function-like macros
*****************************************************************************/
/*****************************************************************************
                  Local defined macros
*****************************************************************************/
/*****************************************************************************
                  Function definitions
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_CORESAFDIAG_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_CORESAFDIAG_Params_t * pCore_Safety_Diagnostics_protocol - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_Safety_Diagnostics_protocol message 
*    Core_Safety_Diagnostics_protocol message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_Safety_Diagnostics_protocol message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_CORESAFDIAG_ParamsApp_MsgDataStruct( EYEQMSG_CORESAFDIAG_Params_t * pCore_Safety_Diagnostics_protocol )
{
   Std_ReturnType status = C_SIG_INVALID;
   if( pCore_Safety_Diagnostics_protocol != C_NULL_P )
   {
      status = C_SIG_VALID;
      * pCore_Safety_Diagnostics_protocol = EYEQMSG_CORESAFDIAG_ParamsApp_s;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pSD_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Zero_byte
*    SD_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Zero_byte signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Zero_byte( uint8 * pSD_Zero_byte )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pSD_Zero_byte != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Zero_byte_b8;
      * pSD_Zero_byte = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_Reserved_1
*
* FUNCTION ARGUMENTS:
*    uint32 * pReserved_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1
*    Reserved_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_Reserved_1( uint32 * pReserved_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pReserved_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.Reserved_1_b24;
      * pReserved_1 = signal_value;
      if( signal_value <= C_EYEQMSG_CORESAFDIAG_RESERVED_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_CRC
*
* FUNCTION ARGUMENTS:
*    uint32 * pSD_CRC - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_CRC
*    SD_CRC returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_CRC signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_CRC( uint32 * pSD_CRC )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pSD_CRC != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_CRC_b32;
      * pSD_CRC = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pSD_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Protocol_Version
*    SD_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Protocol_Version signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Protocol_Version( uint8 * pSD_Protocol_Version )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pSD_Protocol_Version != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Protocol_Version_b8;
      * pSD_Protocol_Version = signal_value;
      if( (signal_value >= C_EYEQMSG_CORESAFDIAG_SD_PROTOCOL_VERSION_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORESAFDIAG_SD_PROTOCOL_VERSION_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Sync_ID
*
* FUNCTION ARGUMENTS:
*    uint8 * pSD_Sync_ID - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Sync_ID
*    SD_Sync_ID returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Sync_ID signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Sync_ID( uint8 * pSD_Sync_ID )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pSD_Sync_ID != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Sync_ID_b8;
      * pSD_Sync_ID = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Challenge_Response1
*
* FUNCTION ARGUMENTS:
*    uint8 * pSD_Challenge_Response1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Challenge_Response1
*    SD_Challenge_Response1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Challenge_Response1 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Challenge_Response1( uint8 * pSD_Challenge_Response1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pSD_Challenge_Response1 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Challenge_Response1_b8;
      * pSD_Challenge_Response1 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Challenge_Response2
*
* FUNCTION ARGUMENTS:
*    uint8 * pSD_Challenge_Response2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Challenge_Response2
*    SD_Challenge_Response2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Challenge_Response2 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Challenge_Response2( uint8 * pSD_Challenge_Response2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pSD_Challenge_Response2 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Challenge_Response2_b8;
      * pSD_Challenge_Response2 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Challenge_Response3
*
* FUNCTION ARGUMENTS:
*    uint8 * pSD_Challenge_Response3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Challenge_Response3
*    SD_Challenge_Response3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Challenge_Response3 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Challenge_Response3( uint8 * pSD_Challenge_Response3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pSD_Challenge_Response3 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Challenge_Response3_b8;
      * pSD_Challenge_Response3 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Challenge_Response4
*
* FUNCTION ARGUMENTS:
*    uint8 * pSD_Challenge_Response4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Challenge_Response4
*    SD_Challenge_Response4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Challenge_Response4 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Challenge_Response4( uint8 * pSD_Challenge_Response4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pSD_Challenge_Response4 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Challenge_Response4_b8;
      * pSD_Challenge_Response4 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Challenge_Identifier
*
* FUNCTION ARGUMENTS:
*    uint8 * pSD_Challenge_Identifier - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Challenge_Identifier
*    SD_Challenge_Identifier returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Challenge_Identifier signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Challenge_Identifier( uint8 * pSD_Challenge_Identifier )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pSD_Challenge_Identifier != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Challenge_Identifier_b8;
      * pSD_Challenge_Identifier = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_Reserved_2
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_2
*    Reserved_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_2 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_Reserved_2( uint8 * pReserved_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pReserved_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.Reserved_2_b8;
      * pReserved_2 = signal_value;
      if( signal_value <= C_EYEQMSG_CORESAFDIAG_RESERVED_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_0
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit0 * pSD_Bit_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_0
*    SD_Bit_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_0 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_0( CORESAFDIAGSDBit0 * pSD_Bit_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit0 signal_value;
   
   if( pSD_Bit_0 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_0_b1;
      * pSD_Bit_0 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_1
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit1 * pSD_Bit_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_1
*    SD_Bit_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_1 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_1( CORESAFDIAGSDBit1 * pSD_Bit_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit1 signal_value;
   
   if( pSD_Bit_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_1_b1;
      * pSD_Bit_1 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_2
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit2 * pSD_Bit_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_2
*    SD_Bit_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_2 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_2( CORESAFDIAGSDBit2 * pSD_Bit_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit2 signal_value;
   
   if( pSD_Bit_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_2_b1;
      * pSD_Bit_2 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_3
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit3 * pSD_Bit_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_3
*    SD_Bit_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_3 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_3( CORESAFDIAGSDBit3 * pSD_Bit_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit3 signal_value;
   
   if( pSD_Bit_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_3_b1;
      * pSD_Bit_3 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_4
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit4 * pSD_Bit_4 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_4
*    SD_Bit_4 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_4 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_4( CORESAFDIAGSDBit4 * pSD_Bit_4 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit4 signal_value;
   
   if( pSD_Bit_4 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_4_b1;
      * pSD_Bit_4 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_5
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit5 * pSD_Bit_5 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_5
*    SD_Bit_5 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_5 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_5( CORESAFDIAGSDBit5 * pSD_Bit_5 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit5 signal_value;
   
   if( pSD_Bit_5 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_5_b1;
      * pSD_Bit_5 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_6
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit6 * pSD_Bit_6 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_6
*    SD_Bit_6 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_6 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_6( CORESAFDIAGSDBit6 * pSD_Bit_6 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit6 signal_value;
   
   if( pSD_Bit_6 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_6_b1;
      * pSD_Bit_6 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_7
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit7 * pSD_Bit_7 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_7
*    SD_Bit_7 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_7 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_7( CORESAFDIAGSDBit7 * pSD_Bit_7 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit7 signal_value;
   
   if( pSD_Bit_7 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_7_b1;
      * pSD_Bit_7 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_8
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit8 * pSD_Bit_8 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_8
*    SD_Bit_8 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_8 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_8( CORESAFDIAGSDBit8 * pSD_Bit_8 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit8 signal_value;
   
   if( pSD_Bit_8 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_8_b1;
      * pSD_Bit_8 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_9
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit9 * pSD_Bit_9 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_9
*    SD_Bit_9 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_9 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_9( CORESAFDIAGSDBit9 * pSD_Bit_9 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit9 signal_value;
   
   if( pSD_Bit_9 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_9_b1;
      * pSD_Bit_9 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_10
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit10 * pSD_Bit_10 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_10
*    SD_Bit_10 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_10 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_10( CORESAFDIAGSDBit10 * pSD_Bit_10 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit10 signal_value;
   
   if( pSD_Bit_10 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_10_b1;
      * pSD_Bit_10 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_11
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit11 * pSD_Bit_11 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_11
*    SD_Bit_11 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_11 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_11( CORESAFDIAGSDBit11 * pSD_Bit_11 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit11 signal_value;
   
   if( pSD_Bit_11 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_11_b1;
      * pSD_Bit_11 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_12
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit12 * pSD_Bit_12 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_12
*    SD_Bit_12 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_12 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_12( CORESAFDIAGSDBit12 * pSD_Bit_12 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit12 signal_value;
   
   if( pSD_Bit_12 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_12_b1;
      * pSD_Bit_12 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_13
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit13 * pSD_Bit_13 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_13
*    SD_Bit_13 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_13 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_13( CORESAFDIAGSDBit13 * pSD_Bit_13 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit13 signal_value;
   
   if( pSD_Bit_13 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_13_b1;
      * pSD_Bit_13 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_14
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit14 * pSD_Bit_14 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_14
*    SD_Bit_14 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_14 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_14( CORESAFDIAGSDBit14 * pSD_Bit_14 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit14 signal_value;
   
   if( pSD_Bit_14 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_14_b1;
      * pSD_Bit_14 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_15
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit15 * pSD_Bit_15 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_15
*    SD_Bit_15 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_15 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_15( CORESAFDIAGSDBit15 * pSD_Bit_15 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit15 signal_value;
   
   if( pSD_Bit_15 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_15_b1;
      * pSD_Bit_15 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_16
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit16 * pSD_Bit_16 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_16
*    SD_Bit_16 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_16 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_16( CORESAFDIAGSDBit16 * pSD_Bit_16 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit16 signal_value;
   
   if( pSD_Bit_16 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_16_b1;
      * pSD_Bit_16 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_17
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit17 * pSD_Bit_17 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_17
*    SD_Bit_17 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_17 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_17( CORESAFDIAGSDBit17 * pSD_Bit_17 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit17 signal_value;
   
   if( pSD_Bit_17 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_17_b1;
      * pSD_Bit_17 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_18
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit18 * pSD_Bit_18 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_18
*    SD_Bit_18 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_18 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_18( CORESAFDIAGSDBit18 * pSD_Bit_18 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit18 signal_value;
   
   if( pSD_Bit_18 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_18_b1;
      * pSD_Bit_18 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_19
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit19 * pSD_Bit_19 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_19
*    SD_Bit_19 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_19 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_19( CORESAFDIAGSDBit19 * pSD_Bit_19 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit19 signal_value;
   
   if( pSD_Bit_19 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_19_b1;
      * pSD_Bit_19 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_20
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit20 * pSD_Bit_20 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_20
*    SD_Bit_20 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_20 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_20( CORESAFDIAGSDBit20 * pSD_Bit_20 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit20 signal_value;
   
   if( pSD_Bit_20 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_20_b1;
      * pSD_Bit_20 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_21
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit21 * pSD_Bit_21 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_21
*    SD_Bit_21 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_21 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_21( CORESAFDIAGSDBit21 * pSD_Bit_21 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit21 signal_value;
   
   if( pSD_Bit_21 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_21_b1;
      * pSD_Bit_21 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_22
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit22 * pSD_Bit_22 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_22
*    SD_Bit_22 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_22 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_22( CORESAFDIAGSDBit22 * pSD_Bit_22 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit22 signal_value;
   
   if( pSD_Bit_22 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_22_b1;
      * pSD_Bit_22 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_23
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit23 * pSD_Bit_23 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_23
*    SD_Bit_23 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_23 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_23( CORESAFDIAGSDBit23 * pSD_Bit_23 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit23 signal_value;
   
   if( pSD_Bit_23 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_23_b1;
      * pSD_Bit_23 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_24
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit24 * pSD_Bit_24 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_24
*    SD_Bit_24 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_24 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_24( CORESAFDIAGSDBit24 * pSD_Bit_24 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit24 signal_value;
   
   if( pSD_Bit_24 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_24_b1;
      * pSD_Bit_24 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_25
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit25 * pSD_Bit_25 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_25
*    SD_Bit_25 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_25 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_25( CORESAFDIAGSDBit25 * pSD_Bit_25 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit25 signal_value;
   
   if( pSD_Bit_25 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_25_b1;
      * pSD_Bit_25 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_26
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit26 * pSD_Bit_26 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_26
*    SD_Bit_26 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_26 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_26( CORESAFDIAGSDBit26 * pSD_Bit_26 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit26 signal_value;
   
   if( pSD_Bit_26 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_26_b1;
      * pSD_Bit_26 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_27
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit27 * pSD_Bit_27 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_27
*    SD_Bit_27 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_27 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_27( CORESAFDIAGSDBit27 * pSD_Bit_27 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit27 signal_value;
   
   if( pSD_Bit_27 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_27_b1;
      * pSD_Bit_27 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_28
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit28 * pSD_Bit_28 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_28
*    SD_Bit_28 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_28 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_28( CORESAFDIAGSDBit28 * pSD_Bit_28 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit28 signal_value;
   
   if( pSD_Bit_28 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_28_b1;
      * pSD_Bit_28 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_29
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit29 * pSD_Bit_29 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_29
*    SD_Bit_29 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_29 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_29( CORESAFDIAGSDBit29 * pSD_Bit_29 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit29 signal_value;
   
   if( pSD_Bit_29 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_29_b1;
      * pSD_Bit_29 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_30
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit30 * pSD_Bit_30 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_30
*    SD_Bit_30 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_30 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_30( CORESAFDIAGSDBit30 * pSD_Bit_30 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit30 signal_value;
   
   if( pSD_Bit_30 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_30_b1;
      * pSD_Bit_30 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_31
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit31 * pSD_Bit_31 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_31
*    SD_Bit_31 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_31 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_31( CORESAFDIAGSDBit31 * pSD_Bit_31 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit31 signal_value;
   
   if( pSD_Bit_31 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_31_b1;
      * pSD_Bit_31 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_32
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit32 * pSD_Bit_32 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_32
*    SD_Bit_32 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_32 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_32( CORESAFDIAGSDBit32 * pSD_Bit_32 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit32 signal_value;
   
   if( pSD_Bit_32 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_32_b1;
      * pSD_Bit_32 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_33
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit33 * pSD_Bit_33 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_33
*    SD_Bit_33 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_33 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_33( CORESAFDIAGSDBit33 * pSD_Bit_33 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit33 signal_value;
   
   if( pSD_Bit_33 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_33_b1;
      * pSD_Bit_33 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_34
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit34 * pSD_Bit_34 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_34
*    SD_Bit_34 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_34 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_34( CORESAFDIAGSDBit34 * pSD_Bit_34 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit34 signal_value;
   
   if( pSD_Bit_34 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_34_b1;
      * pSD_Bit_34 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_35
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit35 * pSD_Bit_35 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_35
*    SD_Bit_35 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_35 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_35( CORESAFDIAGSDBit35 * pSD_Bit_35 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit35 signal_value;
   
   if( pSD_Bit_35 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_35_b1;
      * pSD_Bit_35 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_36
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit36 * pSD_Bit_36 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_36
*    SD_Bit_36 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_36 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_36( CORESAFDIAGSDBit36 * pSD_Bit_36 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit36 signal_value;
   
   if( pSD_Bit_36 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_36_b1;
      * pSD_Bit_36 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_37
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit37 * pSD_Bit_37 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_37
*    SD_Bit_37 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_37 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_37( CORESAFDIAGSDBit37 * pSD_Bit_37 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit37 signal_value;
   
   if( pSD_Bit_37 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_37_b1;
      * pSD_Bit_37 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_38
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit38 * pSD_Bit_38 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_38
*    SD_Bit_38 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_38 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_38( CORESAFDIAGSDBit38 * pSD_Bit_38 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit38 signal_value;
   
   if( pSD_Bit_38 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_38_b1;
      * pSD_Bit_38 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_39
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit39 * pSD_Bit_39 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_39
*    SD_Bit_39 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_39 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_39( CORESAFDIAGSDBit39 * pSD_Bit_39 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit39 signal_value;
   
   if( pSD_Bit_39 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_39_b1;
      * pSD_Bit_39 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_40
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit40 * pSD_Bit_40 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_40
*    SD_Bit_40 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_40 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_40( CORESAFDIAGSDBit40 * pSD_Bit_40 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit40 signal_value;
   
   if( pSD_Bit_40 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_40_b1;
      * pSD_Bit_40 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_41
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit41 * pSD_Bit_41 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_41
*    SD_Bit_41 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_41 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_41( CORESAFDIAGSDBit41 * pSD_Bit_41 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit41 signal_value;
   
   if( pSD_Bit_41 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_41_b1;
      * pSD_Bit_41 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_42
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit42 * pSD_Bit_42 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_42
*    SD_Bit_42 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_42 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_42( CORESAFDIAGSDBit42 * pSD_Bit_42 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit42 signal_value;
   
   if( pSD_Bit_42 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_42_b1;
      * pSD_Bit_42 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_43
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit43 * pSD_Bit_43 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_43
*    SD_Bit_43 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_43 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_43( CORESAFDIAGSDBit43 * pSD_Bit_43 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit43 signal_value;
   
   if( pSD_Bit_43 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_43_b1;
      * pSD_Bit_43 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_44
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit44 * pSD_Bit_44 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_44
*    SD_Bit_44 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_44 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_44( CORESAFDIAGSDBit44 * pSD_Bit_44 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit44 signal_value;
   
   if( pSD_Bit_44 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_44_b1;
      * pSD_Bit_44 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_45
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit45 * pSD_Bit_45 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_45
*    SD_Bit_45 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_45 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_45( CORESAFDIAGSDBit45 * pSD_Bit_45 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit45 signal_value;
   
   if( pSD_Bit_45 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_45_b1;
      * pSD_Bit_45 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_46
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit46 * pSD_Bit_46 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_46
*    SD_Bit_46 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_46 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_46( CORESAFDIAGSDBit46 * pSD_Bit_46 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit46 signal_value;
   
   if( pSD_Bit_46 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_46_b1;
      * pSD_Bit_46 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_47
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit47 * pSD_Bit_47 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_47
*    SD_Bit_47 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_47 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_47( CORESAFDIAGSDBit47 * pSD_Bit_47 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit47 signal_value;
   
   if( pSD_Bit_47 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_47_b1;
      * pSD_Bit_47 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_48
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit48 * pSD_Bit_48 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_48
*    SD_Bit_48 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_48 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_48( CORESAFDIAGSDBit48 * pSD_Bit_48 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit48 signal_value;
   
   if( pSD_Bit_48 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_48_b1;
      * pSD_Bit_48 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_49
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit49 * pSD_Bit_49 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_49
*    SD_Bit_49 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_49 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_49( CORESAFDIAGSDBit49 * pSD_Bit_49 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit49 signal_value;
   
   if( pSD_Bit_49 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_49_b1;
      * pSD_Bit_49 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_50
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit50 * pSD_Bit_50 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_50
*    SD_Bit_50 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_50 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_50( CORESAFDIAGSDBit50 * pSD_Bit_50 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit50 signal_value;
   
   if( pSD_Bit_50 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_50_b1;
      * pSD_Bit_50 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_51
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit51 * pSD_Bit_51 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_51
*    SD_Bit_51 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_51 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_51( CORESAFDIAGSDBit51 * pSD_Bit_51 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit51 signal_value;
   
   if( pSD_Bit_51 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_51_b1;
      * pSD_Bit_51 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_52
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit52 * pSD_Bit_52 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_52
*    SD_Bit_52 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_52 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_52( CORESAFDIAGSDBit52 * pSD_Bit_52 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit52 signal_value;
   
   if( pSD_Bit_52 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_52_b1;
      * pSD_Bit_52 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_53
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit53 * pSD_Bit_53 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_53
*    SD_Bit_53 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_53 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_53( CORESAFDIAGSDBit53 * pSD_Bit_53 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit53 signal_value;
   
   if( pSD_Bit_53 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_53_b1;
      * pSD_Bit_53 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_54
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit54 * pSD_Bit_54 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_54
*    SD_Bit_54 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_54 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_54( CORESAFDIAGSDBit54 * pSD_Bit_54 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit54 signal_value;
   
   if( pSD_Bit_54 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_54_b1;
      * pSD_Bit_54 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_55
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit55 * pSD_Bit_55 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_55
*    SD_Bit_55 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_55 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_55( CORESAFDIAGSDBit55 * pSD_Bit_55 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit55 signal_value;
   
   if( pSD_Bit_55 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_55_b1;
      * pSD_Bit_55 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_56
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit56 * pSD_Bit_56 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_56
*    SD_Bit_56 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_56 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_56( CORESAFDIAGSDBit56 * pSD_Bit_56 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit56 signal_value;
   
   if( pSD_Bit_56 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_56_b1;
      * pSD_Bit_56 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_57
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit57 * pSD_Bit_57 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_57
*    SD_Bit_57 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_57 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_57( CORESAFDIAGSDBit57 * pSD_Bit_57 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit57 signal_value;
   
   if( pSD_Bit_57 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_57_b1;
      * pSD_Bit_57 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_58
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit58 * pSD_Bit_58 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_58
*    SD_Bit_58 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_58 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_58( CORESAFDIAGSDBit58 * pSD_Bit_58 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit58 signal_value;
   
   if( pSD_Bit_58 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_58_b1;
      * pSD_Bit_58 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_59
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit59 * pSD_Bit_59 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_59
*    SD_Bit_59 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_59 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_59( CORESAFDIAGSDBit59 * pSD_Bit_59 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit59 signal_value;
   
   if( pSD_Bit_59 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_59_b1;
      * pSD_Bit_59 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_60
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit60 * pSD_Bit_60 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_60
*    SD_Bit_60 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_60 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_60( CORESAFDIAGSDBit60 * pSD_Bit_60 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit60 signal_value;
   
   if( pSD_Bit_60 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_60_b1;
      * pSD_Bit_60 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_61
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit61 * pSD_Bit_61 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_61
*    SD_Bit_61 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_61 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_61( CORESAFDIAGSDBit61 * pSD_Bit_61 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit61 signal_value;
   
   if( pSD_Bit_61 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_61_b1;
      * pSD_Bit_61 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_62
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit62 * pSD_Bit_62 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_62
*    SD_Bit_62 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_62 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_62( CORESAFDIAGSDBit62 * pSD_Bit_62 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit62 signal_value;
   
   if( pSD_Bit_62 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_62_b1;
      * pSD_Bit_62 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESAFDIAG_SD_Bit_63
*
* FUNCTION ARGUMENTS:
*    CORESAFDIAGSDBit63 * pSD_Bit_63 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of SD_Bit_63
*    SD_Bit_63 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns SD_Bit_63 signal value of Core_Safety_Diagnostics_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESAFDIAG_SD_Bit_63( CORESAFDIAGSDBit63 * pSD_Bit_63 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORESAFDIAGSDBit63 signal_value;
   
   if( pSD_Bit_63 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESAFDIAG_ParamsApp_s.SD_Bit_63_b1;
      * pSD_Bit_63 = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

