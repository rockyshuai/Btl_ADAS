#ifndef _EYEQMSG_CORELANEAPPLPROCESS_H_
#define _EYEQMSG_CORELANEAPPLPROCESS_H_

/*****************************************************************************
                  Included header files
*****************************************************************************/
#include <Std_Types.h>

/*****************************************************************************
                  Include files
*****************************************************************************/
/*****************************************************************************
                  Exported symbolic constants
*****************************************************************************/
#define C_EYEQMSG_CORELANEAPPLvH_VIRTUAL_OBJECT_INDEX_RMAX ( 12U )

/* Datagram message ID */
#define C_EYEQMSG_CORELANEAPPLvH_MSG_ID                       ( 0x8DU )
#define C_EYEQMSG_CORELANEAPPLvO_MSG_ID                       ( 0x8DU )
#define C_EYEQMSG_CORELANEAPPL_MSG_ID                         ( 0x8DU )

/* Datagram message lengths */
#define C_EYEQMSG_CORELANEAPPLvH_MSG_LEN                      ( sizeof(EYEQMSG_CORELANEAPPLvH_Params_t) )
#define C_EYEQMSG_CORELANEAPPLvO_MSG_LEN                      ( sizeof(EYEQMSG_CORELANEAPPLvO_Params_t) )
#define C_EYEQMSG_CORELANEAPPL_MSG_LEN                        ( sizeof(EYEQMSG_CORELANEAPPL_Params_t) )

/* Protocol ENUMs */

/* MCU output messages */

/* Virtual_HEADER_msg_Core_Lanes_Applications_protocol Enums */
/* LAP_Path_Pred_Second_C3_sb32 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_SECOND_C3_RMIN ( -0.004 )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_SECOND_C3_RMAX ( 0.004 )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_SECOND_C3_NUMR ( 1 )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_SECOND_C3_DEMNR ( 1 )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_SECOND_C3_OFFSET ( 0U )

/* LAP_Path_Pred_Second_C2_sb32 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_SECOND_C2_RMIN ( -0.125 )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_SECOND_C2_RMAX ( 0.125 )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_SECOND_C2_NUMR ( 1 )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_SECOND_C2_DEMNR ( 1 )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_SECOND_C2_OFFSET ( 0U )

/* LAP_Path_Pred_Second_C1_sb32 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_SECOND_C1_RMIN ( -2 )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_SECOND_C1_RMAX ( 2 )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_SECOND_C1_NUMR ( 1 )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_SECOND_C1_DEMNR ( 1 )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_SECOND_C1_OFFSET ( 0U )

/* LAP_Path_Pred_Second_C0_sb32 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_SECOND_C0_RMIN ( -30 )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_SECOND_C0_RMAX ( 30 )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_SECOND_C0_NUMR ( 1 )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_SECOND_C0_DEMNR ( 1 )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_SECOND_C0_OFFSET ( 0U )

/* LAP_Path_Pred_First_C3_sb32 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_FIRST_C3_RMIN  ( -0.004 )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_FIRST_C3_RMAX  ( 0.004 )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_FIRST_C3_NUMR  ( 1 )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_FIRST_C3_DEMNR ( 1 )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_FIRST_C3_OFFSET ( 0U )

/* LAP_Path_Pred_First_C2_sb32 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_FIRST_C2_RMIN  ( -0.125 )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_FIRST_C2_RMAX  ( 0.125 )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_FIRST_C2_NUMR  ( 1 )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_FIRST_C2_DEMNR ( 1 )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_FIRST_C2_OFFSET ( 0U )

/* LAP_Path_Pred_First_C1_sb32 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_FIRST_C1_RMIN  ( -2 )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_FIRST_C1_RMAX  ( 2 )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_FIRST_C1_NUMR  ( 1 )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_FIRST_C1_DEMNR ( 1 )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_FIRST_C1_OFFSET ( 0U )

/* LAP_Path_Pred_First_C0_sb32 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_FIRST_C0_RMIN  ( -30 )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_FIRST_C0_RMAX  ( 30 )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_FIRST_C0_NUMR  ( 1 )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_FIRST_C0_DEMNR ( 1 )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_FIRST_C0_OFFSET ( 0U )

/* Reserved_3_b2 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvH_RESERVED_3_RMIN              ( 0U )
#define C_EYEQMSG_CORELANEAPPLvH_RESERVED_3_RMAX              ( 0U )
#define C_EYEQMSG_CORELANEAPPLvH_RESERVED_3_NUMR              ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_RESERVED_3_DEMNR             ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_RESERVED_3_OFFSET            ( 0U )

/* LAP_Path_Pred_second_VR_End_b15 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_SECOND_VR_END_RMIN ( 0U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_SECOND_VR_END_RMAX ( 20000U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_SECOND_VR_END_NUMR ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_SECOND_VR_END_DEMNR ( 100U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_SECOND_VR_END_OFFSET ( 0U )

/* LAP_Path_Pred_First_VR_End_b15 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_FIRST_VR_END_RMIN ( 0U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_FIRST_VR_END_RMAX ( 20000U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_FIRST_VR_END_NUMR ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_FIRST_VR_END_DEMNR ( 100U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_FIRST_VR_END_OFFSET ( 0U )

/* Reserved_2_b11 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvH_RESERVED_2_RMIN              ( 0U )
#define C_EYEQMSG_CORELANEAPPLvH_RESERVED_2_RMAX              ( 0U )
#define C_EYEQMSG_CORELANEAPPLvH_RESERVED_2_NUMR              ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_RESERVED_2_DEMNR             ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_RESERVED_2_OFFSET            ( 0U )

/* LAP_Is_Triggered_SDM_Model_b2 signal Enums */
typedef uint8 CORELANEAPPLvHLAPIsTriggeredSDMModel;
#define C_EYEQMSG_CORELANEAPPLvH_LAP_IS_TRIGGERED_SDM_MODEL_NOT_AVAILABLE ( CORELANEAPPLvHLAPIsTriggeredSDMModel ) ( 0U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_IS_TRIGGERED_SDM_MODEL_TRIGGERED ( CORELANEAPPLvHLAPIsTriggeredSDMModel ) ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_IS_TRIGGERED_SDM_MODEL_NOT_TRIGGERED ( CORELANEAPPLvHLAPIsTriggeredSDMModel ) ( 2U )

/* LAP_Is_Triggered_SDM_Model_b2 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvH_LAP_IS_TRIGGERED_SDM_MODEL_RMIN ( 0U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_IS_TRIGGERED_SDM_MODEL_RMAX ( 2U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_IS_TRIGGERED_SDM_MODEL_NUMR ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_IS_TRIGGERED_SDM_MODEL_DEMNR ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_IS_TRIGGERED_SDM_MODEL_OFFSET ( 0U )

/* LAP_Path_Pred_Conf_b7 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_CONF_RMIN      ( 0U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_CONF_RMAX      ( 100U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_CONF_NUMR      ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_CONF_DEMNR     ( 100U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_CONF_OFFSET    ( 0U )

/* LAP_Path_Pred_Half_Width_b9 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_HALF_WIDTH_RMIN ( 0U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_HALF_WIDTH_RMAX ( 300U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_HALF_WIDTH_NUMR ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_HALF_WIDTH_DEMNR ( 100U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_HALF_WIDTH_OFFSET ( 0U )

/* LAP_Path_Pred_Second_Valid_b1 signal Enums */
typedef boolean CORELANEAPPLvHLAPPathPredSecondValid;
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_SECOND_VALID_FALSE ( CORELANEAPPLvHLAPPathPredSecondValid ) ( 0U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_SECOND_VALID_TRUE ( CORELANEAPPLvHLAPPathPredSecondValid ) ( 1U )

/* LAP_Path_Pred_Second_Valid_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_SECOND_VALID_RMIN ( 0U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_SECOND_VALID_RMAX ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_SECOND_VALID_NUMR ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_SECOND_VALID_DEMNR ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_SECOND_VALID_OFFSET ( 0U )

/* LAP_Path_Pred_First_Valid_b1 signal Enums */
typedef boolean CORELANEAPPLvHLAPPathPredFirstValid;
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_FIRST_VALID_FALSE ( CORELANEAPPLvHLAPPathPredFirstValid ) ( 0U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_FIRST_VALID_TRUE ( CORELANEAPPLvHLAPPathPredFirstValid ) ( 1U )

/* LAP_Path_Pred_First_Valid_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_FIRST_VALID_RMIN ( 0U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_FIRST_VALID_RMAX ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_FIRST_VALID_NUMR ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_FIRST_VALID_DEMNR ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_FIRST_VALID_OFFSET ( 0U )

/* LAP_Path_Pred_Available_b1 signal Enums */
typedef boolean CORELANEAPPLvHLAPPathPredAvailable;
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_AVAILABLE_FALSE ( CORELANEAPPLvHLAPPathPredAvailable ) ( 0U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_AVAILABLE_TRUE ( CORELANEAPPLvHLAPPathPredAvailable ) ( 1U )

/* LAP_Path_Pred_Available_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_AVAILABLE_RMIN ( 0U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_AVAILABLE_RMAX ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_AVAILABLE_NUMR ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_AVAILABLE_DEMNR ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_AVAILABLE_OFFSET ( 0U )

/* LAP_Path_Pred_CRC_b32 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_CRC_RMIN       ( 0U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_CRC_RMAX       ( 4294967295U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_CRC_NUMR       ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_CRC_DEMNR      ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PATH_PRED_CRC_OFFSET     ( 0U )

/* LAP_Vertical_Surface_C3_sb32 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvH_LAP_VERTICAL_SURFACE_C3_RMIN ( -0.0004 )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_VERTICAL_SURFACE_C3_RMAX ( 0.0004 )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_VERTICAL_SURFACE_C3_NUMR ( 1 )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_VERTICAL_SURFACE_C3_DEMNR ( 1 )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_VERTICAL_SURFACE_C3_OFFSET ( 0U )

/* LAP_Vertical_Surface_C2_sb32 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvH_LAP_VERTICAL_SURFACE_C2_RMIN ( -0.03 )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_VERTICAL_SURFACE_C2_RMAX ( 0.03 )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_VERTICAL_SURFACE_C2_NUMR ( 1 )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_VERTICAL_SURFACE_C2_DEMNR ( 1 )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_VERTICAL_SURFACE_C2_OFFSET ( 0U )

/* LAP_Vertical_Surface_C1_sb32 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvH_LAP_VERTICAL_SURFACE_C1_RMIN ( -0.784 )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_VERTICAL_SURFACE_C1_RMAX ( 0.784 )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_VERTICAL_SURFACE_C1_NUMR ( 1 )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_VERTICAL_SURFACE_C1_DEMNR ( 1 )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_VERTICAL_SURFACE_C1_OFFSET ( 0U )

/* LAP_Vertical_Surface_C0_sb32 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvH_LAP_VERTICAL_SURFACE_C0_RMIN ( -10 )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_VERTICAL_SURFACE_C0_RMAX ( 10 )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_VERTICAL_SURFACE_C0_NUMR ( 1 )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_VERTICAL_SURFACE_C0_DEMNR ( 1 )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_VERTICAL_SURFACE_C0_OFFSET ( 0U )

/* Reserved_1_b6 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvH_RESERVED_1_RMIN              ( 0U )
#define C_EYEQMSG_CORELANEAPPLvH_RESERVED_1_RMAX              ( 0U )
#define C_EYEQMSG_CORELANEAPPLvH_RESERVED_1_NUMR              ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_RESERVED_1_DEMNR             ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_RESERVED_1_OFFSET            ( 0U )

/* LAP_Vertical_Surface_VR_End_b15 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvH_LAP_VERTICAL_SURFACE_VR_END_RMIN ( 0U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_VERTICAL_SURFACE_VR_END_RMAX ( 20000U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_VERTICAL_SURFACE_VR_END_NUMR ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_VERTICAL_SURFACE_VR_END_DEMNR ( 100U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_VERTICAL_SURFACE_VR_END_OFFSET ( 0U )

/* LAP_Vertical_Surface_Available_b1 signal Enums */
typedef boolean CORELANEAPPLvHLAPVerticalSurfaceAvailable;
#define C_EYEQMSG_CORELANEAPPLvH_LAP_VERTICAL_SURFACE_AVAILABLE_NOT_VALID ( CORELANEAPPLvHLAPVerticalSurfaceAvailable ) ( 0U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_VERTICAL_SURFACE_AVAILABLE_VALID ( CORELANEAPPLvHLAPVerticalSurfaceAvailable ) ( 1U )

/* LAP_Vertical_Surface_Available_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvH_LAP_VERTICAL_SURFACE_AVAILABLE_RMIN ( 0U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_VERTICAL_SURFACE_AVAILABLE_RMAX ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_VERTICAL_SURFACE_AVAILABLE_NUMR ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_VERTICAL_SURFACE_AVAILABLE_DEMNR ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_VERTICAL_SURFACE_AVAILABLE_OFFSET ( 0U )

/* LAP_Is_Highway_Exit_Right_b1 signal Enums */
typedef boolean CORELANEAPPLvHLAPIsHighwayExitRight;
#define C_EYEQMSG_CORELANEAPPLvH_LAP_IS_HIGHWAY_EXIT_RIGHT_FALSE ( CORELANEAPPLvHLAPIsHighwayExitRight ) ( 0U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_IS_HIGHWAY_EXIT_RIGHT_TRUE ( CORELANEAPPLvHLAPIsHighwayExitRight ) ( 1U )

/* LAP_Is_Highway_Exit_Right_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvH_LAP_IS_HIGHWAY_EXIT_RIGHT_RMIN ( 0U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_IS_HIGHWAY_EXIT_RIGHT_RMAX ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_IS_HIGHWAY_EXIT_RIGHT_NUMR ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_IS_HIGHWAY_EXIT_RIGHT_DEMNR ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_IS_HIGHWAY_EXIT_RIGHT_OFFSET ( 0U )

/* LAP_Is_Highway_Exit_Left_b1 signal Enums */
typedef boolean CORELANEAPPLvHLAPIsHighwayExitLeft;
#define C_EYEQMSG_CORELANEAPPLvH_LAP_IS_HIGHWAY_EXIT_LEFT_FALSE ( CORELANEAPPLvHLAPIsHighwayExitLeft ) ( 0U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_IS_HIGHWAY_EXIT_LEFT_TRUE ( CORELANEAPPLvHLAPIsHighwayExitLeft ) ( 1U )

/* LAP_Is_Highway_Exit_Left_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvH_LAP_IS_HIGHWAY_EXIT_LEFT_RMIN ( 0U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_IS_HIGHWAY_EXIT_LEFT_RMAX ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_IS_HIGHWAY_EXIT_LEFT_NUMR ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_IS_HIGHWAY_EXIT_LEFT_DEMNR ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_IS_HIGHWAY_EXIT_LEFT_OFFSET ( 0U )

/* LAP_Is_Highway_Merge_Right_b1 signal Enums */
typedef boolean CORELANEAPPLvHLAPIsHighwayMergeRight;
#define C_EYEQMSG_CORELANEAPPLvH_LAP_IS_HIGHWAY_MERGE_RIGHT_FALSE ( CORELANEAPPLvHLAPIsHighwayMergeRight ) ( 0U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_IS_HIGHWAY_MERGE_RIGHT_TRUE ( CORELANEAPPLvHLAPIsHighwayMergeRight ) ( 1U )

/* LAP_Is_Highway_Merge_Right_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvH_LAP_IS_HIGHWAY_MERGE_RIGHT_RMIN ( 0U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_IS_HIGHWAY_MERGE_RIGHT_RMAX ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_IS_HIGHWAY_MERGE_RIGHT_NUMR ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_IS_HIGHWAY_MERGE_RIGHT_DEMNR ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_IS_HIGHWAY_MERGE_RIGHT_OFFSET ( 0U )

/* LAP_Is_Highway_Merge_Left_b1 signal Enums */
typedef boolean CORELANEAPPLvHLAPIsHighwayMergeLeft;
#define C_EYEQMSG_CORELANEAPPLvH_LAP_IS_HIGHWAY_MERGE_LEFT_FALSE ( CORELANEAPPLvHLAPIsHighwayMergeLeft ) ( 0U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_IS_HIGHWAY_MERGE_LEFT_TRUE ( CORELANEAPPLvHLAPIsHighwayMergeLeft ) ( 1U )

/* LAP_Is_Highway_Merge_Left_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvH_LAP_IS_HIGHWAY_MERGE_LEFT_RMIN ( 0U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_IS_HIGHWAY_MERGE_LEFT_RMAX ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_IS_HIGHWAY_MERGE_LEFT_NUMR ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_IS_HIGHWAY_MERGE_LEFT_DEMNR ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_IS_HIGHWAY_MERGE_LEFT_OFFSET ( 0U )

/* LAP_Exit_Merge_Available_b1 signal Enums */
typedef boolean CORELANEAPPLvHLAPExitMergeAvailable;
#define C_EYEQMSG_CORELANEAPPLvH_LAP_EXIT_MERGE_AVAILABLE_FALSE ( CORELANEAPPLvHLAPExitMergeAvailable ) ( 0U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_EXIT_MERGE_AVAILABLE_TRUE ( CORELANEAPPLvHLAPExitMergeAvailable ) ( 1U )

/* LAP_Exit_Merge_Available_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvH_LAP_EXIT_MERGE_AVAILABLE_RMIN ( 0U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_EXIT_MERGE_AVAILABLE_RMAX ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_EXIT_MERGE_AVAILABLE_NUMR ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_EXIT_MERGE_AVAILABLE_DEMNR ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_EXIT_MERGE_AVAILABLE_OFFSET ( 0U )

/* LAP_INTP_Count_b4 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvH_LAP_INTP_COUNT_RMIN          ( 0U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_INTP_COUNT_RMAX          ( 12U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_INTP_COUNT_NUMR          ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_INTP_COUNT_DEMNR         ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_INTP_COUNT_OFFSET        ( 0U )

/* LAP_INTP_Available_b1 signal Enums */
typedef boolean CORELANEAPPLvHLAPINTPAvailable;
#define C_EYEQMSG_CORELANEAPPLvH_LAP_INTP_AVAILABLE_FALSE     ( CORELANEAPPLvHLAPINTPAvailable ) ( 0U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_INTP_AVAILABLE_TRUE      ( CORELANEAPPLvHLAPINTPAvailable ) ( 1U )

/* LAP_INTP_Available_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvH_LAP_INTP_AVAILABLE_RMIN      ( 0U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_INTP_AVAILABLE_RMAX      ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_INTP_AVAILABLE_NUMR      ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_INTP_AVAILABLE_DEMNR     ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_INTP_AVAILABLE_OFFSET    ( 0U )

/* LAP_Snow_On_Road_b7 signal Enums */
typedef uint8 CORELANEAPPLvHLAPSnowOnRoad;
#define C_EYEQMSG_CORELANEAPPLvH_LAP_SNOW_ON_ROAD_FALSE       ( CORELANEAPPLvHLAPSnowOnRoad ) ( 0U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_SNOW_ON_ROAD_TRUE        ( CORELANEAPPLvHLAPSnowOnRoad ) ( 1U )

/* LAP_Snow_On_Road_b7 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvH_LAP_SNOW_ON_ROAD_RMIN        ( 0U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_SNOW_ON_ROAD_RMAX        ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_SNOW_ON_ROAD_NUMR        ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_SNOW_ON_ROAD_DEMNR       ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_SNOW_ON_ROAD_OFFSET      ( 0U )

/* LAP_Is_Construction_Area_b1 signal Enums */
typedef boolean CORELANEAPPLvHLAPIsConstructionArea;
#define C_EYEQMSG_CORELANEAPPLvH_LAP_IS_CONSTRUCTION_AREA_FALSE ( CORELANEAPPLvHLAPIsConstructionArea ) ( 0U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_IS_CONSTRUCTION_AREA_TRUE ( CORELANEAPPLvHLAPIsConstructionArea ) ( 1U )

/* LAP_Is_Construction_Area_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvH_LAP_IS_CONSTRUCTION_AREA_RMIN ( 0U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_IS_CONSTRUCTION_AREA_RMAX ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_IS_CONSTRUCTION_AREA_NUMR ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_IS_CONSTRUCTION_AREA_DEMNR ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_IS_CONSTRUCTION_AREA_OFFSET ( 0U )

/* LAP_Sync_ID_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvH_LAP_SYNC_ID_RMIN             ( 0U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_SYNC_ID_RMAX             ( 255U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_SYNC_ID_NUMR             ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_SYNC_ID_DEMNR            ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_SYNC_ID_OFFSET           ( 0U )

/* LAP_Protocol_Version_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PROTOCOL_VERSION_RMIN    ( 8U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PROTOCOL_VERSION_RMAX    ( 8U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PROTOCOL_VERSION_NUMR    ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PROTOCOL_VERSION_DEMNR   ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_PROTOCOL_VERSION_OFFSET  ( 0U )

/* LAP_Zero_byte_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvH_LAP_ZERO_BYTE_RMIN           ( 0U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_ZERO_BYTE_RMAX           ( 255U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_ZERO_BYTE_NUMR           ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_ZERO_BYTE_DEMNR          ( 1U )
#define C_EYEQMSG_CORELANEAPPLvH_LAP_ZERO_BYTE_OFFSET         ( 0U )


/* Virtual_OBJECT_msg_Core_Lanes_Applications_protocol Enums */
/* Reserved_6_0_b24 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvO_RESERVED_6_0_RMIN            ( 0U )
#define C_EYEQMSG_CORELANEAPPLvO_RESERVED_6_0_RMAX            ( 0U )
#define C_EYEQMSG_CORELANEAPPLvO_RESERVED_6_0_NUMR            ( 1U )
#define C_EYEQMSG_CORELANEAPPLvO_RESERVED_6_0_DEMNR           ( 1U )
#define C_EYEQMSG_CORELANEAPPLvO_RESERVED_6_0_OFFSET          ( 0U )

/* LAP_INTP_Role_0_b4 signal Enums */
typedef uint8 CORELANEAPPLvOLAPINTPRole0;
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_ROLE_0_UNDECIDED    ( CORELANEAPPLvOLAPINTPRole0 ) ( 0U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_ROLE_0_HOST_LEFT    ( CORELANEAPPLvOLAPINTPRole0 ) ( 1U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_ROLE_0_HOST_RIGHT   ( CORELANEAPPLvOLAPINTPRole0 ) ( 2U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_ROLE_0_NEXT_LEFT    ( CORELANEAPPLvOLAPINTPRole0 ) ( 3U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_ROLE_0_NEXT_RIGHT   ( CORELANEAPPLvOLAPINTPRole0 ) ( 4U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_ROLE_0_NEXT_NEXT_LEFT ( CORELANEAPPLvOLAPINTPRole0 ) ( 5U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_ROLE_0_NEXT_NEXT_RIGHT ( CORELANEAPPLvOLAPINTPRole0 ) ( 6U )

/* LAP_INTP_Role_0_b4 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_ROLE_0_RMIN         ( 0U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_ROLE_0_RMAX         ( 6U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_ROLE_0_NUMR         ( 1U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_ROLE_0_DEMNR        ( 1U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_ROLE_0_OFFSET       ( 0U )

/* LAP_INTP_SRD_0_b4 signal Enums */
typedef uint8 CORELANEAPPLvOLAPINTPSRD0;
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_SRD_0_UNDECIDED     ( CORELANEAPPLvOLAPINTPSRD0 ) ( 0U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_SRD_0_NEW_LANE      ( CORELANEAPPLvOLAPINTPSRD0 ) ( 1U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_SRD_0_CLOSING_LANE  ( CORELANEAPPLvOLAPINTPSRD0 ) ( 2U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_SRD_0_HATCHED_MERGE ( CORELANEAPPLvOLAPINTPSRD0 ) ( 3U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_SRD_0_HATCHED_SPLIT ( CORELANEAPPLvOLAPINTPSRD0 ) ( 4U )

/* LAP_INTP_SRD_0_b4 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_SRD_0_RMIN          ( 0U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_SRD_0_RMAX          ( 4U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_SRD_0_NUMR          ( 1U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_SRD_0_DEMNR         ( 1U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_SRD_0_OFFSET        ( 0U )

/* Reserved_5_0_b3 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvO_RESERVED_5_0_RMIN            ( 0U )
#define C_EYEQMSG_CORELANEAPPLvO_RESERVED_5_0_RMAX            ( 0U )
#define C_EYEQMSG_CORELANEAPPLvO_RESERVED_5_0_NUMR            ( 1U )
#define C_EYEQMSG_CORELANEAPPLvO_RESERVED_5_0_DEMNR           ( 1U )
#define C_EYEQMSG_CORELANEAPPLvO_RESERVED_5_0_OFFSET          ( 0U )

/* LAP_INTP_Long_Distance_0_b15 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_LONG_DISTANCE_0_RMIN ( 0U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_LONG_DISTANCE_0_RMAX ( 20000U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_LONG_DISTANCE_0_NUMR ( 1U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_LONG_DISTANCE_0_DEMNR ( 100U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_LONG_DISTANCE_0_OFFSET ( 0U )

/* LAP_INTP_Lat_Distance_0_b14 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_LAT_DISTANCE_0_RMIN ( 0U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_LAT_DISTANCE_0_RMAX ( 10000U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_LAT_DISTANCE_0_NUMR ( 1 )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_LAT_DISTANCE_0_DEMNR ( 100 )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_LAT_DISTANCE_0_OFFSET ( -50 )

/* Reserved_4_0_b2 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvO_RESERVED_4_0_RMIN            ( 0U )
#define C_EYEQMSG_CORELANEAPPLvO_RESERVED_4_0_RMAX            ( 0U )
#define C_EYEQMSG_CORELANEAPPLvO_RESERVED_4_0_NUMR            ( 1U )
#define C_EYEQMSG_CORELANEAPPLvO_RESERVED_4_0_DEMNR           ( 1U )
#define C_EYEQMSG_CORELANEAPPLvO_RESERVED_4_0_OFFSET          ( 0U )

/* LAP_INTP_Is_Start_0_b1 signal Enums */
typedef boolean CORELANEAPPLvOLAPINTPIsStart0;
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_IS_START_0_END_OF_TRANSITION ( CORELANEAPPLvOLAPINTPIsStart0 ) ( 0U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_IS_START_0_START_OF_TRANSITION ( CORELANEAPPLvOLAPINTPIsStart0 ) ( 1U )

/* LAP_INTP_Is_Start_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_IS_START_0_RMIN     ( 0U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_IS_START_0_RMAX     ( 1U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_IS_START_0_NUMR     ( 1U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_IS_START_0_DEMNR    ( 1U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_IS_START_0_OFFSET   ( 0U )

/* LAP_INTP_Type_0_b1 signal Enums */
typedef boolean CORELANEAPPLvOLAPINTPType0;
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_TYPE_0_SPLIT        ( CORELANEAPPLvOLAPINTPType0 ) ( 0U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_TYPE_0_MERGE        ( CORELANEAPPLvOLAPINTPType0 ) ( 1U )

/* LAP_INTP_Type_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_TYPE_0_RMIN         ( 0U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_TYPE_0_RMAX         ( 1U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_TYPE_0_NUMR         ( 1U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_TYPE_0_DEMNR        ( 1U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_TYPE_0_OFFSET       ( 0U )

/* LAP_INTP_Is_Valid_0_b1 signal Enums */
typedef boolean CORELANEAPPLvOLAPINTPIsValid0;
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_IS_VALID_0_NOT_VALID ( CORELANEAPPLvOLAPINTPIsValid0 ) ( 0U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_IS_VALID_0_VALID    ( CORELANEAPPLvOLAPINTPIsValid0 ) ( 1U )

/* LAP_INTP_Is_Valid_0_b1 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_IS_VALID_0_RMIN     ( 0U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_IS_VALID_0_RMAX     ( 1U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_IS_VALID_0_NUMR     ( 1U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_IS_VALID_0_DEMNR    ( 1U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_IS_VALID_0_OFFSET   ( 0U )

/* LAP_INTP_Confidence_0_b7 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_CONFIDENCE_0_RMIN   ( 0U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_CONFIDENCE_0_RMAX   ( 100U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_CONFIDENCE_0_NUMR   ( 1U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_CONFIDENCE_0_DEMNR  ( 100U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_CONFIDENCE_0_OFFSET ( 0U )

/* LAP_INTP_Distance_Age_0_b12 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_DISTANCE_AGE_0_RMIN ( 0U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_DISTANCE_AGE_0_RMAX ( 250U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_DISTANCE_AGE_0_NUMR ( 1U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_DISTANCE_AGE_0_DEMNR ( 1U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_DISTANCE_AGE_0_OFFSET ( 0U )

/* LAP_INTP_ID_0_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_ID_0_RMIN           ( 0U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_ID_0_RMAX           ( 255U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_ID_0_NUMR           ( 1U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_ID_0_DEMNR          ( 1U )
#define C_EYEQMSG_CORELANEAPPLvO_LAP_INTP_ID_0_OFFSET         ( 0U )


/*****************************************************************************
                  Exported function-like macros
*****************************************************************************/
/*****************************************************************************
                  Exported defined macros
*****************************************************************************/
/*****************************************************************************
                  Exported types, enums definitions
*****************************************************************************/
typedef struct
{
   #if ENABLE_BIG_ENDIAN_FORMAT
      uint32        LAP_Zero_byte_b8                             : 8U;
      
      uint32        LAP_Protocol_Version_b8                      : 8U;
      
      uint32        LAP_Sync_ID_b8                               : 8U;
      
      uint32        unused1_b7                                   : 7;
      uint32        LAP_Is_Construction_Area_b1                  : 1U;
      
      uint32        LAP_Snow_On_Road_b7                          : 7U;
      
      uint32        LAP_INTP_Available_b1                        : 1U;
      
      uint32        LAP_INTP_Count_b4                            : 4U;
      
      uint32        LAP_Exit_Merge_Available_b1                  : 1U;
      
      uint32        LAP_Is_Highway_Merge_Left_b1                 : 1U;
      
      uint32        LAP_Is_Highway_Merge_Right_b1                : 1U;
      
      uint32        LAP_Is_Highway_Exit_Left_b1                  : 1U;
      
      uint32        LAP_Is_Highway_Exit_Right_b1                 : 1U;
      
      uint32        LAP_Vertical_Surface_Available_b1            : 1U;
      
      uint32        LAP_Vertical_Surface_VR_End_1_b5             : 5U;
      
      uint32        LAP_Vertical_Surface_VR_End_2_b8             : 8U;
      
      uint32        LAP_Vertical_Surface_VR_End_3_b2             : 2U;
      
      uint32        Reserved_1_b6                                : 6U;
      
      uint32        LAP_Vertical_Surface_C0_1_sb8                : 8U;
      
      uint32        LAP_Vertical_Surface_C0_2_sb8                : 8U;
      
      uint32        LAP_Vertical_Surface_C0_3_sb8                : 8U;
      
      uint32        LAP_Vertical_Surface_C0_4_sb8                : 8U;
      
      uint32        LAP_Vertical_Surface_C1_1_sb8                : 8U;
      
      uint32        LAP_Vertical_Surface_C1_2_sb8                : 8U;
      
      uint32        LAP_Vertical_Surface_C1_3_sb8                : 8U;
      
      uint32        LAP_Vertical_Surface_C1_4_sb8                : 8U;
      
      uint32        LAP_Vertical_Surface_C2_1_sb8                : 8U;
      
      uint32        LAP_Vertical_Surface_C2_2_sb8                : 8U;
      
      uint32        LAP_Vertical_Surface_C2_3_sb8                : 8U;
      
      uint32        LAP_Vertical_Surface_C2_4_sb8                : 8U;
      
      uint32        LAP_Vertical_Surface_C3_1_sb8                : 8U;
      
      uint32        LAP_Vertical_Surface_C3_2_sb8                : 8U;
      
      uint32        LAP_Vertical_Surface_C3_3_sb8                : 8U;
      
      uint32        LAP_Vertical_Surface_C3_4_sb8                : 8U;
      
      uint32        LAP_Path_Pred_CRC_1_b8                       : 8U;
      
      uint32        LAP_Path_Pred_CRC_2_b8                       : 8U;
      
      uint32        LAP_Path_Pred_CRC_3_b8                       : 8U;
      
      uint32        LAP_Path_Pred_CRC_4_b8                       : 8U;
      
      uint32        LAP_Path_Pred_Available_b1                   : 1U;
      
      uint32        LAP_Path_Pred_First_Valid_b1                 : 1U;
      
      uint32        LAP_Path_Pred_Second_Valid_b1                : 1U;
      
      uint32        LAP_Path_Pred_Half_Width_1_b5                : 5U;
      
      uint32        LAP_Path_Pred_Half_Width_2_b4                : 4U;
      
      uint32        LAP_Path_Pred_Conf_1_b4                      : 4U;
      
      uint32        LAP_Path_Pred_Conf_2_b3                      : 3U;
      
      uint32        LAP_Is_Triggered_SDM_Model_b2                : 2U;
      
      uint32        Reserved_2_1_b3                              : 3U;
      
      uint32        Reserved_2_2_b8                              : 8U;
      
      uint32        LAP_Path_Pred_First_VR_End_1_b8              : 8U;
      
      uint32        LAP_Path_Pred_First_VR_End_2_b7              : 7U;
      
      uint32        LAP_Path_Pred_second_VR_End_1_b1             : 1U;
      
      uint32        LAP_Path_Pred_second_VR_End_2_b8             : 8U;
      
      uint32        LAP_Path_Pred_second_VR_End_3_b6             : 6U;
      
      uint32        Reserved_3_b2                                : 2U;
      
      uint32        LAP_Path_Pred_First_C0_1_sb8                 : 8U;
      
      uint32        LAP_Path_Pred_First_C0_2_sb8                 : 8U;
      
      uint32        LAP_Path_Pred_First_C0_3_sb8                 : 8U;
      
      uint32        LAP_Path_Pred_First_C0_4_sb8                 : 8U;
      
      uint32        LAP_Path_Pred_First_C1_1_sb8                 : 8U;
      
      uint32        LAP_Path_Pred_First_C1_2_sb8                 : 8U;
      
      uint32        LAP_Path_Pred_First_C1_3_sb8                 : 8U;
      
      uint32        LAP_Path_Pred_First_C1_4_sb8                 : 8U;
      
      uint32        LAP_Path_Pred_First_C2_1_sb8                 : 8U;
      
      uint32        LAP_Path_Pred_First_C2_2_sb8                 : 8U;
      
      uint32        LAP_Path_Pred_First_C2_3_sb8                 : 8U;
      
      uint32        LAP_Path_Pred_First_C2_4_sb8                 : 8U;
      
      uint32        LAP_Path_Pred_First_C3_1_sb8                 : 8U;
      
      uint32        LAP_Path_Pred_First_C3_2_sb8                 : 8U;
      
      uint32        LAP_Path_Pred_First_C3_3_sb8                 : 8U;
      
      uint32        LAP_Path_Pred_First_C3_4_sb8                 : 8U;
      
      uint32        LAP_Path_Pred_Second_C0_1_sb8                : 8U;
      
      uint32        LAP_Path_Pred_Second_C0_2_sb8                : 8U;
      
      uint32        LAP_Path_Pred_Second_C0_3_sb8                : 8U;
      
      uint32        LAP_Path_Pred_Second_C0_4_sb8                : 8U;
      
      uint32        LAP_Path_Pred_Second_C1_1_sb8                : 8U;
      
      uint32        LAP_Path_Pred_Second_C1_2_sb8                : 8U;
      
      uint32        LAP_Path_Pred_Second_C1_3_sb8                : 8U;
      
      uint32        LAP_Path_Pred_Second_C1_4_sb8                : 8U;
      
      uint32        LAP_Path_Pred_Second_C2_1_sb8                : 8U;
      
      uint32        LAP_Path_Pred_Second_C2_2_sb8                : 8U;
      
      uint32        LAP_Path_Pred_Second_C2_3_sb8                : 8U;
      
      uint32        LAP_Path_Pred_Second_C2_4_sb8                : 8U;
      
      uint32        LAP_Path_Pred_Second_C3_1_sb8                : 8U;
      
      uint32        LAP_Path_Pred_Second_C3_2_sb8                : 8U;
      
      uint32        LAP_Path_Pred_Second_C3_3_sb8                : 8U;
      
      uint32        LAP_Path_Pred_Second_C3_4_sb8                : 8U;
      
   #else
      uint32        LAP_Zero_byte_b8                             : 8U;
      
      uint32        LAP_Protocol_Version_b8                      : 8U;
      
      uint32        LAP_Sync_ID_b8                               : 8U;
      
      uint32        LAP_Is_Construction_Area_b1                  : 1U;
      
      uint32        LAP_Snow_On_Road_b7                          : 7U;
      
      uint32        LAP_INTP_Available_b1                        : 1U;
      
      uint32        LAP_INTP_Count_b4                            : 4U;
      
      uint32        LAP_Exit_Merge_Available_b1                  : 1U;
      
      uint32        LAP_Is_Highway_Merge_Left_b1                 : 1U;
      
      uint32        LAP_Is_Highway_Merge_Right_b1                : 1U;
      
      uint32        LAP_Is_Highway_Exit_Left_b1                  : 1U;
      
      uint32        LAP_Is_Highway_Exit_Right_b1                 : 1U;
      
      uint32        LAP_Vertical_Surface_Available_b1            : 1U;
      
      uint32        LAP_Vertical_Surface_VR_End_b15              : 15U;
      
      uint32        Reserved_1_b6                                : 6U;
      
      sint32        LAP_Vertical_Surface_C0_sb32                 : 32;
      
      sint32        LAP_Vertical_Surface_C1_sb32                 : 32;
      
      sint32        LAP_Vertical_Surface_C2_sb32                 : 32;
      
      sint32        LAP_Vertical_Surface_C3_sb32                 : 32;
      
      uint32        LAP_Path_Pred_CRC_b32                        : 32U;
      
      uint32        LAP_Path_Pred_Available_b1                   : 1U;
      
      uint32        LAP_Path_Pred_First_Valid_b1                 : 1U;
      
      uint32        LAP_Path_Pred_Second_Valid_b1                : 1U;
      
      uint32        LAP_Path_Pred_Half_Width_b9                  : 9U;
      
      uint32        LAP_Path_Pred_Conf_b7                        : 7U;
      
      uint32        LAP_Is_Triggered_SDM_Model_b2                : 2U;
      
      uint32        Reserved_2_b11                               : 11U;
      
      uint32        LAP_Path_Pred_First_VR_End_b15               : 15U;
      
      uint32        LAP_Path_Pred_second_VR_End_b15              : 15U;
      
      uint32        Reserved_3_b2                                : 2U;
      
      sint32        LAP_Path_Pred_First_C0_sb32                  : 32;
      
      sint32        LAP_Path_Pred_First_C1_sb32                  : 32;
      
      sint32        LAP_Path_Pred_First_C2_sb32                  : 32;
      
      sint32        LAP_Path_Pred_First_C3_sb32                  : 32;
      
      sint32        LAP_Path_Pred_Second_C0_sb32                 : 32;
      
      sint32        LAP_Path_Pred_Second_C1_sb32                 : 32;
      
      sint32        LAP_Path_Pred_Second_C2_sb32                 : 32;
      
      sint32        LAP_Path_Pred_Second_C3_sb32                 : 32;
      
   #endif
} EYEQMSG_CORELANEAPPLvH_Params_t;


typedef struct
{
   #if ENABLE_BIG_ENDIAN_FORMAT
      uint32        unused1_b544                                 : 544;
      uint32        LAP_INTP_ID_0_b8                             : 8U;
      
      uint32        LAP_INTP_Distance_Age_0_1_b8                 : 8U;
      
      uint32        unused2_b4                                   : 4;
      uint32        LAP_INTP_Distance_Age_0_2_b4                 : 4U;
      
      uint32        LAP_INTP_Confidence_0_1_b4                   : 4U;
      
      uint32        unused3_b1                                   : 1;
      uint32        LAP_INTP_Confidence_0_2_b3                   : 3U;
      
      uint32        LAP_INTP_Is_Valid_0_b1                       : 1U;
      
      uint32        LAP_INTP_Type_0_b1                           : 1U;
      
      uint32        LAP_INTP_Is_Start_0_b1                       : 1U;
      
      uint32        Reserved_4_0_b2                              : 2U;
      
      uint32        LAP_INTP_Lat_Distance_0_1_b8                 : 8U;
      
      uint32        LAP_INTP_Lat_Distance_0_2_b6                 : 6U;
      
      uint32        LAP_INTP_Long_Distance_0_1_b2                : 2U;
      
      uint32        LAP_INTP_Long_Distance_0_2_b8                : 8U;
      
      uint32        LAP_INTP_Long_Distance_0_3_b5                : 5U;
      
      uint32        Reserved_5_0_b3                              : 3U;
      
      uint32        LAP_INTP_SRD_0_b4                            : 4U;
      
      uint32        LAP_INTP_Role_0_b4                           : 4U;
      
      uint32        Reserved_6_0_1_b8                            : 8U;
      
      uint32        Reserved_6_0_2_b8                            : 8U;
      
      uint32        Reserved_6_0_3_b8                            : 8U;
      
   #else
      uint32        LAP_INTP_ID_0_b8                             : 8U;
      
      uint32        LAP_INTP_Distance_Age_0_b12                  : 12U;
      
      uint32        LAP_INTP_Confidence_0_b7                     : 7U;
      
      uint32        LAP_INTP_Is_Valid_0_b1                       : 1U;
      
      uint32        LAP_INTP_Type_0_b1                           : 1U;
      
      uint32        LAP_INTP_Is_Start_0_b1                       : 1U;
      
      uint32        Reserved_4_0_b2                              : 2U;
      
      uint32        LAP_INTP_Lat_Distance_0_b14                  : 14U;
      
      uint32        LAP_INTP_Long_Distance_0_b15                 : 15U;
      
      uint32        Reserved_5_0_b3                              : 3U;
      
      uint32        LAP_INTP_SRD_0_b4                            : 4U;
      
      uint32        LAP_INTP_Role_0_b4                           : 4U;
      
      uint32        Reserved_6_0_b24                             : 24U;
      
   #endif
} EYEQMSG_CORELANEAPPLvO_Params_t;


typedef struct
{
   EYEQMSG_CORELANEAPPLvH_Params_t EYEQMSG_CORELANEAPPLvH_Params_s;
   EYEQMSG_CORELANEAPPLvO_Params_t EYEQMSG_CORELANEAPPLvO_Params_as[C_EYEQMSG_CORELANEAPPLvH_VIRTUAL_OBJECT_INDEX_RMAX];
} EYEQMSG_CORELANEAPPL_Params_t;


/*****************************************************************************
                  Exported function prototypes
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pLAP_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Zero_byte
*    LAP_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Zero_byte signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Zero_byte( uint8 * pLAP_Zero_byte );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pLAP_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Protocol_Version
*    LAP_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Protocol_Version signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Protocol_Version( uint8 * pLAP_Protocol_Version );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Sync_ID
*
* FUNCTION ARGUMENTS:
*    uint8 * pLAP_Sync_ID - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Sync_ID
*    LAP_Sync_ID returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Sync_ID signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Sync_ID( uint8 * pLAP_Sync_ID );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Is_Construction_Area
*
* FUNCTION ARGUMENTS:
*    CORELANEAPPLvHLAPIsConstructionArea * pLAP_Is_Construction_Area - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Is_Construction_Area
*    LAP_Is_Construction_Area returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Is_Construction_Area signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Is_Construction_Area( CORELANEAPPLvHLAPIsConstructionArea * pLAP_Is_Construction_Area );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Snow_On_Road
*
* FUNCTION ARGUMENTS:
*    CORELANEAPPLvHLAPSnowOnRoad * pLAP_Snow_On_Road - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Snow_On_Road
*    LAP_Snow_On_Road returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Snow_On_Road signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Snow_On_Road( CORELANEAPPLvHLAPSnowOnRoad * pLAP_Snow_On_Road );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_INTP_Available
*
* FUNCTION ARGUMENTS:
*    CORELANEAPPLvHLAPINTPAvailable * pLAP_INTP_Available - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_INTP_Available
*    LAP_INTP_Available returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_INTP_Available signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_INTP_Available( CORELANEAPPLvHLAPINTPAvailable * pLAP_INTP_Available );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_INTP_Count
*
* FUNCTION ARGUMENTS:
*    uint8 * pLAP_INTP_Count - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_INTP_Count
*    LAP_INTP_Count returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_INTP_Count signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_INTP_Count( uint8 * pLAP_INTP_Count );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Exit_Merge_Available
*
* FUNCTION ARGUMENTS:
*    CORELANEAPPLvHLAPExitMergeAvailable * pLAP_Exit_Merge_Available - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Exit_Merge_Available
*    LAP_Exit_Merge_Available returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Exit_Merge_Available signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Exit_Merge_Available( CORELANEAPPLvHLAPExitMergeAvailable * pLAP_Exit_Merge_Available );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Is_Highway_Merge_Left
*
* FUNCTION ARGUMENTS:
*    CORELANEAPPLvHLAPIsHighwayMergeLeft * pLAP_Is_Highway_Merge_Left - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Is_Highway_Merge_Left
*    LAP_Is_Highway_Merge_Left returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Is_Highway_Merge_Left signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Is_Highway_Merge_Left( CORELANEAPPLvHLAPIsHighwayMergeLeft * pLAP_Is_Highway_Merge_Left );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Is_Highway_Merge_Right
*
* FUNCTION ARGUMENTS:
*    CORELANEAPPLvHLAPIsHighwayMergeRight * pLAP_Is_Highway_Merge_Right - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Is_Highway_Merge_Right
*    LAP_Is_Highway_Merge_Right returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Is_Highway_Merge_Right signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Is_Highway_Merge_Right( CORELANEAPPLvHLAPIsHighwayMergeRight * pLAP_Is_Highway_Merge_Right );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Is_Highway_Exit_Left
*
* FUNCTION ARGUMENTS:
*    CORELANEAPPLvHLAPIsHighwayExitLeft * pLAP_Is_Highway_Exit_Left - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Is_Highway_Exit_Left
*    LAP_Is_Highway_Exit_Left returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Is_Highway_Exit_Left signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Is_Highway_Exit_Left( CORELANEAPPLvHLAPIsHighwayExitLeft * pLAP_Is_Highway_Exit_Left );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Is_Highway_Exit_Right
*
* FUNCTION ARGUMENTS:
*    CORELANEAPPLvHLAPIsHighwayExitRight * pLAP_Is_Highway_Exit_Right - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Is_Highway_Exit_Right
*    LAP_Is_Highway_Exit_Right returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Is_Highway_Exit_Right signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Is_Highway_Exit_Right( CORELANEAPPLvHLAPIsHighwayExitRight * pLAP_Is_Highway_Exit_Right );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Vertical_Surface_Available
*
* FUNCTION ARGUMENTS:
*    CORELANEAPPLvHLAPVerticalSurfaceAvailable * pLAP_Vertical_Surface_Available - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Vertical_Surface_Available
*    LAP_Vertical_Surface_Available returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Vertical_Surface_Available signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Vertical_Surface_Available( CORELANEAPPLvHLAPVerticalSurfaceAvailable * pLAP_Vertical_Surface_Available );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Vertical_Surface_VR_End
*
* FUNCTION ARGUMENTS:
*    uint16 * pLAP_Vertical_Surface_VR_End - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Vertical_Surface_VR_End
*    LAP_Vertical_Surface_VR_End returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Vertical_Surface_VR_End signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Vertical_Surface_VR_End( uint16 * pLAP_Vertical_Surface_VR_End );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_Reserved_1
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1
*    Reserved_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1 signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_Reserved_1( uint8 * pReserved_1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Vertical_Surface_C0
*
* FUNCTION ARGUMENTS:
*    float32 * pLAP_Vertical_Surface_C0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Vertical_Surface_C0
*    LAP_Vertical_Surface_C0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Vertical_Surface_C0 signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Vertical_Surface_C0( float32 * pLAP_Vertical_Surface_C0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Vertical_Surface_C1
*
* FUNCTION ARGUMENTS:
*    float32 * pLAP_Vertical_Surface_C1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Vertical_Surface_C1
*    LAP_Vertical_Surface_C1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Vertical_Surface_C1 signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Vertical_Surface_C1( float32 * pLAP_Vertical_Surface_C1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Vertical_Surface_C2
*
* FUNCTION ARGUMENTS:
*    float32 * pLAP_Vertical_Surface_C2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Vertical_Surface_C2
*    LAP_Vertical_Surface_C2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Vertical_Surface_C2 signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Vertical_Surface_C2( float32 * pLAP_Vertical_Surface_C2 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Vertical_Surface_C3
*
* FUNCTION ARGUMENTS:
*    float32 * pLAP_Vertical_Surface_C3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Vertical_Surface_C3
*    LAP_Vertical_Surface_C3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Vertical_Surface_C3 signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Vertical_Surface_C3( float32 * pLAP_Vertical_Surface_C3 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_CRC
*
* FUNCTION ARGUMENTS:
*    uint32 * pLAP_Path_Pred_CRC - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Path_Pred_CRC
*    LAP_Path_Pred_CRC returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Path_Pred_CRC signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_CRC( uint32 * pLAP_Path_Pred_CRC );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_Available
*
* FUNCTION ARGUMENTS:
*    CORELANEAPPLvHLAPPathPredAvailable * pLAP_Path_Pred_Available - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Path_Pred_Available
*    LAP_Path_Pred_Available returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Path_Pred_Available signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_Available( CORELANEAPPLvHLAPPathPredAvailable * pLAP_Path_Pred_Available );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_First_Valid
*
* FUNCTION ARGUMENTS:
*    CORELANEAPPLvHLAPPathPredFirstValid * pLAP_Path_Pred_First_Valid - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Path_Pred_First_Valid
*    LAP_Path_Pred_First_Valid returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Path_Pred_First_Valid signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_First_Valid( CORELANEAPPLvHLAPPathPredFirstValid * pLAP_Path_Pred_First_Valid );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_Second_Valid
*
* FUNCTION ARGUMENTS:
*    CORELANEAPPLvHLAPPathPredSecondValid * pLAP_Path_Pred_Second_Valid - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Path_Pred_Second_Valid
*    LAP_Path_Pred_Second_Valid returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Path_Pred_Second_Valid signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_Second_Valid( CORELANEAPPLvHLAPPathPredSecondValid * pLAP_Path_Pred_Second_Valid );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_Half_Width
*
* FUNCTION ARGUMENTS:
*    uint16 * pLAP_Path_Pred_Half_Width - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Path_Pred_Half_Width
*    LAP_Path_Pred_Half_Width returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Path_Pred_Half_Width signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_Half_Width( uint16 * pLAP_Path_Pred_Half_Width );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_Conf
*
* FUNCTION ARGUMENTS:
*    uint8 * pLAP_Path_Pred_Conf - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Path_Pred_Conf
*    LAP_Path_Pred_Conf returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Path_Pred_Conf signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_Conf( uint8 * pLAP_Path_Pred_Conf );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Is_Triggered_SDM_Model
*
* FUNCTION ARGUMENTS:
*    CORELANEAPPLvHLAPIsTriggeredSDMModel * pLAP_Is_Triggered_SDM_Model - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Is_Triggered_SDM_Model
*    LAP_Is_Triggered_SDM_Model returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Is_Triggered_SDM_Model signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Is_Triggered_SDM_Model( CORELANEAPPLvHLAPIsTriggeredSDMModel * pLAP_Is_Triggered_SDM_Model );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_Reserved_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pReserved_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_2
*    Reserved_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_2 signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_Reserved_2( uint16 * pReserved_2 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_First_VR_End
*
* FUNCTION ARGUMENTS:
*    uint16 * pLAP_Path_Pred_First_VR_End - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Path_Pred_First_VR_End
*    LAP_Path_Pred_First_VR_End returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Path_Pred_First_VR_End signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_First_VR_End( uint16 * pLAP_Path_Pred_First_VR_End );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_second_VR_End
*
* FUNCTION ARGUMENTS:
*    uint16 * pLAP_Path_Pred_second_VR_End - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Path_Pred_second_VR_End
*    LAP_Path_Pred_second_VR_End returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Path_Pred_second_VR_End signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_second_VR_End( uint16 * pLAP_Path_Pred_second_VR_End );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_Reserved_3
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_3
*    Reserved_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_3 signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_Reserved_3( uint8 * pReserved_3 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_First_C0
*
* FUNCTION ARGUMENTS:
*    float32 * pLAP_Path_Pred_First_C0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Path_Pred_First_C0
*    LAP_Path_Pred_First_C0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Path_Pred_First_C0 signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_First_C0( float32 * pLAP_Path_Pred_First_C0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_First_C1
*
* FUNCTION ARGUMENTS:
*    float32 * pLAP_Path_Pred_First_C1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Path_Pred_First_C1
*    LAP_Path_Pred_First_C1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Path_Pred_First_C1 signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_First_C1( float32 * pLAP_Path_Pred_First_C1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_First_C2
*
* FUNCTION ARGUMENTS:
*    float32 * pLAP_Path_Pred_First_C2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Path_Pred_First_C2
*    LAP_Path_Pred_First_C2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Path_Pred_First_C2 signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_First_C2( float32 * pLAP_Path_Pred_First_C2 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_First_C3
*
* FUNCTION ARGUMENTS:
*    float32 * pLAP_Path_Pred_First_C3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Path_Pred_First_C3
*    LAP_Path_Pred_First_C3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Path_Pred_First_C3 signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_First_C3( float32 * pLAP_Path_Pred_First_C3 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_Second_C0
*
* FUNCTION ARGUMENTS:
*    float32 * pLAP_Path_Pred_Second_C0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Path_Pred_Second_C0
*    LAP_Path_Pred_Second_C0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Path_Pred_Second_C0 signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_Second_C0( float32 * pLAP_Path_Pred_Second_C0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_Second_C1
*
* FUNCTION ARGUMENTS:
*    float32 * pLAP_Path_Pred_Second_C1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Path_Pred_Second_C1
*    LAP_Path_Pred_Second_C1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Path_Pred_Second_C1 signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_Second_C1( float32 * pLAP_Path_Pred_Second_C1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_Second_C2
*
* FUNCTION ARGUMENTS:
*    float32 * pLAP_Path_Pred_Second_C2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Path_Pred_Second_C2
*    LAP_Path_Pred_Second_C2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Path_Pred_Second_C2 signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_Second_C2( float32 * pLAP_Path_Pred_Second_C2 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_Second_C3
*
* FUNCTION ARGUMENTS:
*    float32 * pLAP_Path_Pred_Second_C3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_Path_Pred_Second_C3
*    LAP_Path_Pred_Second_C3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_Path_Pred_Second_C3 signal value of Virtual_HEADER_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvH_LAP_Path_Pred_Second_C3( float32 * pLAP_Path_Pred_Second_C3 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvO_LAP_INTP_ID_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLAP_INTP_ID_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_INTP_ID_0
*    LAP_INTP_ID_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_INTP_ID_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvO_LAP_INTP_ID_0( uint8 objIndx_u8, uint8 * pLAP_INTP_ID_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvO_LAP_INTP_Distance_Age_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLAP_INTP_Distance_Age_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_INTP_Distance_Age_0
*    LAP_INTP_Distance_Age_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_INTP_Distance_Age_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvO_LAP_INTP_Distance_Age_0( uint8 objIndx_u8, uint16 * pLAP_INTP_Distance_Age_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvO_LAP_INTP_Confidence_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLAP_INTP_Confidence_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_INTP_Confidence_0
*    LAP_INTP_Confidence_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_INTP_Confidence_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvO_LAP_INTP_Confidence_0( uint8 objIndx_u8, uint8 * pLAP_INTP_Confidence_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvO_LAP_INTP_Is_Valid_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANEAPPLvOLAPINTPIsValid0 * pLAP_INTP_Is_Valid_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_INTP_Is_Valid_0
*    LAP_INTP_Is_Valid_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_INTP_Is_Valid_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvO_LAP_INTP_Is_Valid_0( uint8 objIndx_u8, CORELANEAPPLvOLAPINTPIsValid0 * pLAP_INTP_Is_Valid_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvO_LAP_INTP_Type_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANEAPPLvOLAPINTPType0 * pLAP_INTP_Type_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_INTP_Type_0
*    LAP_INTP_Type_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_INTP_Type_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvO_LAP_INTP_Type_0( uint8 objIndx_u8, CORELANEAPPLvOLAPINTPType0 * pLAP_INTP_Type_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvO_LAP_INTP_Is_Start_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANEAPPLvOLAPINTPIsStart0 * pLAP_INTP_Is_Start_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_INTP_Is_Start_0
*    LAP_INTP_Is_Start_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_INTP_Is_Start_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvO_LAP_INTP_Is_Start_0( uint8 objIndx_u8, CORELANEAPPLvOLAPINTPIsStart0 * pLAP_INTP_Is_Start_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvO_Reserved_4_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_4_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_4_0
*    Reserved_4_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_4_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvO_Reserved_4_0( uint8 objIndx_u8, uint8 * pReserved_4_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvO_LAP_INTP_Lat_Distance_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLAP_INTP_Lat_Distance_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_INTP_Lat_Distance_0
*    LAP_INTP_Lat_Distance_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_INTP_Lat_Distance_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvO_LAP_INTP_Lat_Distance_0( uint8 objIndx_u8, uint16 * pLAP_INTP_Lat_Distance_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvO_LAP_INTP_Long_Distance_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLAP_INTP_Long_Distance_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_INTP_Long_Distance_0
*    LAP_INTP_Long_Distance_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_INTP_Long_Distance_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvO_LAP_INTP_Long_Distance_0( uint8 objIndx_u8, uint16 * pLAP_INTP_Long_Distance_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvO_Reserved_5_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_5_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_5_0
*    Reserved_5_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_5_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvO_Reserved_5_0( uint8 objIndx_u8, uint8 * pReserved_5_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvO_LAP_INTP_SRD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANEAPPLvOLAPINTPSRD0 * pLAP_INTP_SRD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_INTP_SRD_0
*    LAP_INTP_SRD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_INTP_SRD_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvO_LAP_INTP_SRD_0( uint8 objIndx_u8, CORELANEAPPLvOLAPINTPSRD0 * pLAP_INTP_SRD_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvO_LAP_INTP_Role_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANEAPPLvOLAPINTPRole0 * pLAP_INTP_Role_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LAP_INTP_Role_0
*    LAP_INTP_Role_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LAP_INTP_Role_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvO_LAP_INTP_Role_0( uint8 objIndx_u8, CORELANEAPPLvOLAPINTPRole0 * pLAP_INTP_Role_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEAPPLvO_Reserved_6_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint32 * pReserved_6_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_6_0
*    Reserved_6_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_6_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Applications_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEAPPLvO_Reserved_6_0( uint8 objIndx_u8, uint32 * pReserved_6_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_CORELANEAPPL_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_CORELANEAPPL_Params_t * pCore_Lanes_Applications_protocol - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_Lanes_Applications_protocol message 
*    Core_Lanes_Applications_protocol message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_Lanes_Applications_protocol message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_CORELANEAPPL_ParamsApp_MsgDataStruct( EYEQMSG_CORELANEAPPL_Params_t * pCore_Lanes_Applications_protocol );
/*****************************************************************************
                  Exported object declarations
*****************************************************************************/
extern EYEQMSG_CORELANEAPPL_Params_t   EYEQMSG_CORELANEAPPL_Params_s;
extern EYEQMSG_CORELANEAPPL_Params_t   EYEQMSG_CORELANEAPPL_ParamsApp_s;
/****************************************************************************/
#endif /* _EYEQMSG_CORELANEAPPLPROCESS_H_ */


