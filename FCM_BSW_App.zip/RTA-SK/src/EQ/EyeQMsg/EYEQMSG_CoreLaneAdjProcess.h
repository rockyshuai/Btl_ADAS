#ifndef _EYEQMSG_CORELANEADJPROCESS_H_
#define _EYEQMSG_CORELANEADJPROCESS_H_

/*****************************************************************************
                  Included header files
*****************************************************************************/
#include <Std_Types.h>

/*****************************************************************************
                  Include files
*****************************************************************************/
/*****************************************************************************
                  Exported symbolic constants
*****************************************************************************/
#define C_EYEQMSG_CORELANEADJvH_VIRTUAL_OBJECT_INDEX_RMAX ( 8U )

/* Datagram message ID */
#define C_EYEQMSG_CORELANEADJvH_MSG_ID                        ( 0x8CU )
#define C_EYEQMSG_CORELANEADJvO_MSG_ID                        ( 0x8CU )
#define C_EYEQMSG_CORELANEADJ_MSG_ID                          ( 0x8CU )

/* Datagram message lengths */
#define C_EYEQMSG_CORELANEADJvH_MSG_LEN                       ( sizeof(EYEQMSG_CORELANEADJvH_Params_t) )
#define C_EYEQMSG_CORELANEADJvO_MSG_LEN                       ( sizeof(EYEQMSG_CORELANEADJvO_Params_t) )
#define C_EYEQMSG_CORELANEADJ_MSG_LEN                         ( sizeof(EYEQMSG_CORELANEADJ_Params_t) )

/* Protocol ENUMs */

/* MCU output messages */

/* Virtual_HEADER_msg_Core_Lanes_Adjacent_protocol Enums */
/* Reserved_1_b4 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEADJvH_RESERVED_1_RMIN               ( 0U )
#define C_EYEQMSG_CORELANEADJvH_RESERVED_1_RMAX               ( 0U )
#define C_EYEQMSG_CORELANEADJvH_RESERVED_1_NUMR               ( 1U )
#define C_EYEQMSG_CORELANEADJvH_RESERVED_1_DEMNR              ( 1U )
#define C_EYEQMSG_CORELANEADJvH_RESERVED_1_OFFSET             ( 0U )

/* LA_Adjacent_Count_b4 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEADJvH_LA_ADJACENT_COUNT_RMIN        ( 0U )
#define C_EYEQMSG_CORELANEADJvH_LA_ADJACENT_COUNT_RMAX        ( 8U )
#define C_EYEQMSG_CORELANEADJvH_LA_ADJACENT_COUNT_NUMR        ( 1U )
#define C_EYEQMSG_CORELANEADJvH_LA_ADJACENT_COUNT_DEMNR       ( 1U )
#define C_EYEQMSG_CORELANEADJvH_LA_ADJACENT_COUNT_OFFSET      ( 0U )

/* LA_Sync_ID_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEADJvH_LA_SYNC_ID_RMIN               ( 0U )
#define C_EYEQMSG_CORELANEADJvH_LA_SYNC_ID_RMAX               ( 255U )
#define C_EYEQMSG_CORELANEADJvH_LA_SYNC_ID_NUMR               ( 1U )
#define C_EYEQMSG_CORELANEADJvH_LA_SYNC_ID_DEMNR              ( 1U )
#define C_EYEQMSG_CORELANEADJvH_LA_SYNC_ID_OFFSET             ( 0U )

/* LA_Protocol_Version_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEADJvH_LA_PROTOCOL_VERSION_RMIN      ( 7U )
#define C_EYEQMSG_CORELANEADJvH_LA_PROTOCOL_VERSION_RMAX      ( 7U )
#define C_EYEQMSG_CORELANEADJvH_LA_PROTOCOL_VERSION_NUMR      ( 1U )
#define C_EYEQMSG_CORELANEADJvH_LA_PROTOCOL_VERSION_DEMNR     ( 1U )
#define C_EYEQMSG_CORELANEADJvH_LA_PROTOCOL_VERSION_OFFSET    ( 0U )

/* LA_Zero_byte_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEADJvH_LA_ZERO_BYTE_RMIN             ( 0U )
#define C_EYEQMSG_CORELANEADJvH_LA_ZERO_BYTE_RMAX             ( 255U )
#define C_EYEQMSG_CORELANEADJvH_LA_ZERO_BYTE_NUMR             ( 1U )
#define C_EYEQMSG_CORELANEADJvH_LA_ZERO_BYTE_DEMNR            ( 1U )
#define C_EYEQMSG_CORELANEADJvH_LA_ZERO_BYTE_OFFSET           ( 0U )


/* Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol Enums */
/* Reserved_6_0_b30 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEADJvO_RESERVED_6_0_RMIN             ( 0U )
#define C_EYEQMSG_CORELANEADJvO_RESERVED_6_0_RMAX             ( 0U )
#define C_EYEQMSG_CORELANEADJvO_RESERVED_6_0_NUMR             ( 1U )
#define C_EYEQMSG_CORELANEADJvO_RESERVED_6_0_DEMNR            ( 1U )
#define C_EYEQMSG_CORELANEADJvO_RESERVED_6_0_OFFSET           ( 0U )

/* LA_Detection_Source_0_b2 signal Enums */
typedef uint8 CORELANEADJvOLADetectionSource0;
#define C_EYEQMSG_CORELANEADJvO_LA_DETECTION_SOURCE_0_UNKNOWN ( CORELANEADJvOLADetectionSource0 ) ( 0U )
#define C_EYEQMSG_CORELANEADJvO_LA_DETECTION_SOURCE_0_FRONT   ( CORELANEADJvOLADetectionSource0 ) ( 1U )
#define C_EYEQMSG_CORELANEADJvO_LA_DETECTION_SOURCE_0_REAR    ( CORELANEADJvOLADetectionSource0 ) ( 2U )
#define C_EYEQMSG_CORELANEADJvO_LA_DETECTION_SOURCE_0_SIDE    ( CORELANEADJvOLADetectionSource0 ) ( 3U )

/* LA_Detection_Source_0_b2 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEADJvO_LA_DETECTION_SOURCE_0_RMIN    ( 0U )
#define C_EYEQMSG_CORELANEADJvO_LA_DETECTION_SOURCE_0_RMAX    ( 3U )
#define C_EYEQMSG_CORELANEADJvO_LA_DETECTION_SOURCE_0_NUMR    ( 1U )
#define C_EYEQMSG_CORELANEADJvO_LA_DETECTION_SOURCE_0_DEMNR   ( 1U )
#define C_EYEQMSG_CORELANEADJvO_LA_DETECTION_SOURCE_0_OFFSET  ( 0U )

/* LA_Line_C0_0_sb32 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEADJvO_LA_LINE_C0_0_RMIN             ( -30 )
#define C_EYEQMSG_CORELANEADJvO_LA_LINE_C0_0_RMAX             ( 30 )
#define C_EYEQMSG_CORELANEADJvO_LA_LINE_C0_0_NUMR             ( 1 )
#define C_EYEQMSG_CORELANEADJvO_LA_LINE_C0_0_DEMNR            ( 1 )
#define C_EYEQMSG_CORELANEADJvO_LA_LINE_C0_0_OFFSET           ( 0U )

/* LA_Line_C1_0_sb32 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEADJvO_LA_LINE_C1_0_RMIN             ( -2 )
#define C_EYEQMSG_CORELANEADJvO_LA_LINE_C1_0_RMAX             ( 2 )
#define C_EYEQMSG_CORELANEADJvO_LA_LINE_C1_0_NUMR             ( 1 )
#define C_EYEQMSG_CORELANEADJvO_LA_LINE_C1_0_DEMNR            ( 1 )
#define C_EYEQMSG_CORELANEADJvO_LA_LINE_C1_0_OFFSET           ( 0U )

/* LA_Line_C2_0_sb32 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEADJvO_LA_LINE_C2_0_RMIN             ( -0.125 )
#define C_EYEQMSG_CORELANEADJvO_LA_LINE_C2_0_RMAX             ( 0.125 )
#define C_EYEQMSG_CORELANEADJvO_LA_LINE_C2_0_NUMR             ( 1 )
#define C_EYEQMSG_CORELANEADJvO_LA_LINE_C2_0_DEMNR            ( 1 )
#define C_EYEQMSG_CORELANEADJvO_LA_LINE_C2_0_OFFSET           ( 0U )

/* LA_Line_C3_0_sb32 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEADJvO_LA_LINE_C3_0_RMIN             ( -0.004 )
#define C_EYEQMSG_CORELANEADJvO_LA_LINE_C3_0_RMAX             ( 0.004 )
#define C_EYEQMSG_CORELANEADJvO_LA_LINE_C3_0_NUMR             ( 1 )
#define C_EYEQMSG_CORELANEADJvO_LA_LINE_C3_0_DEMNR            ( 1 )
#define C_EYEQMSG_CORELANEADJvO_LA_LINE_C3_0_OFFSET           ( 0U )

/* Reserved_5_0_b25 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEADJvO_RESERVED_5_0_RMIN             ( 0U )
#define C_EYEQMSG_CORELANEADJvO_RESERVED_5_0_RMAX             ( 0U )
#define C_EYEQMSG_CORELANEADJvO_RESERVED_5_0_NUMR             ( 1U )
#define C_EYEQMSG_CORELANEADJvO_RESERVED_5_0_DEMNR            ( 1U )
#define C_EYEQMSG_CORELANEADJvO_RESERVED_5_0_OFFSET           ( 0U )

/* LA_Marker_Width_STD_0_b7 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEADJvO_LA_MARKER_WIDTH_STD_0_RMIN    ( 0U )
#define C_EYEQMSG_CORELANEADJvO_LA_MARKER_WIDTH_STD_0_RMAX    ( 100U )
#define C_EYEQMSG_CORELANEADJvO_LA_MARKER_WIDTH_STD_0_NUMR    ( 1U )
#define C_EYEQMSG_CORELANEADJvO_LA_MARKER_WIDTH_STD_0_DEMNR   ( 200U )
#define C_EYEQMSG_CORELANEADJvO_LA_MARKER_WIDTH_STD_0_OFFSET  ( 0U )

/* Reserved_4_0_b6 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEADJvO_RESERVED_4_0_RMIN             ( 0U )
#define C_EYEQMSG_CORELANEADJvO_RESERVED_4_0_RMAX             ( 0U )
#define C_EYEQMSG_CORELANEADJvO_RESERVED_4_0_NUMR             ( 1U )
#define C_EYEQMSG_CORELANEADJvO_RESERVED_4_0_DEMNR            ( 1U )
#define C_EYEQMSG_CORELANEADJvO_RESERVED_4_0_OFFSET           ( 0U )

/* LA_Marker_Width_0_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEADJvO_LA_MARKER_WIDTH_0_RMIN        ( 0U )
#define C_EYEQMSG_CORELANEADJvO_LA_MARKER_WIDTH_0_RMAX        ( 70U )
#define C_EYEQMSG_CORELANEADJvO_LA_MARKER_WIDTH_0_NUMR        ( 1U )
#define C_EYEQMSG_CORELANEADJvO_LA_MARKER_WIDTH_0_DEMNR       ( 100U )
#define C_EYEQMSG_CORELANEADJvO_LA_MARKER_WIDTH_0_OFFSET      ( 0U )

/* LA_Line_Side_0_b4 signal Enums */
typedef uint8 CORELANEADJvOLALineSide0;
#define C_EYEQMSG_CORELANEADJvO_LA_LINE_SIDE_0_NONE           ( CORELANEADJvOLALineSide0 ) ( 0U )
#define C_EYEQMSG_CORELANEADJvO_LA_LINE_SIDE_0_LEFT_LEFT_LANEMARK ( CORELANEADJvOLALineSide0 ) ( 1U )
#define C_EYEQMSG_CORELANEADJvO_LA_LINE_SIDE_0_LEFT_RIGHT_LANEMARK ( CORELANEADJvOLALineSide0 ) ( 2U )
#define C_EYEQMSG_CORELANEADJvO_LA_LINE_SIDE_0_RIGHT_LEFT_LANEMARK ( CORELANEADJvOLALineSide0 ) ( 3U )
#define C_EYEQMSG_CORELANEADJvO_LA_LINE_SIDE_0_RIGHT_RIGHT_LANEMARK ( CORELANEADJvOLALineSide0 ) ( 4U )

/* LA_Line_Side_0_b4 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEADJvO_LA_LINE_SIDE_0_RMIN           ( 0U )
#define C_EYEQMSG_CORELANEADJvO_LA_LINE_SIDE_0_RMAX           ( 4U )
#define C_EYEQMSG_CORELANEADJvO_LA_LINE_SIDE_0_NUMR           ( 1U )
#define C_EYEQMSG_CORELANEADJvO_LA_LINE_SIDE_0_DEMNR          ( 1U )
#define C_EYEQMSG_CORELANEADJvO_LA_LINE_SIDE_0_OFFSET         ( 0U )

/* LA_Lanemark_Type_Conf_0_b7 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEADJvO_LA_LANEMARK_TYPE_CONF_0_RMIN  ( 0U )
#define C_EYEQMSG_CORELANEADJvO_LA_LANEMARK_TYPE_CONF_0_RMAX  ( 100U )
#define C_EYEQMSG_CORELANEADJvO_LA_LANEMARK_TYPE_CONF_0_NUMR  ( 1U )
#define C_EYEQMSG_CORELANEADJvO_LA_LANEMARK_TYPE_CONF_0_DEMNR ( 100U )
#define C_EYEQMSG_CORELANEADJvO_LA_LANEMARK_TYPE_CONF_0_OFFSET ( 0U )

/* LA_DLM_Type_0_b3 signal Enums */
typedef uint8 CORELANEADJvOLADLMType0;
#define C_EYEQMSG_CORELANEADJvO_LA_DLM_TYPE_0_NOT_DLM         ( CORELANEADJvOLADLMType0 ) ( 0U )
#define C_EYEQMSG_CORELANEADJvO_LA_DLM_TYPE_0_SOLID_DASHED    ( CORELANEADJvOLADLMType0 ) ( 1U )
#define C_EYEQMSG_CORELANEADJvO_LA_DLM_TYPE_0_DASHED_SOLID    ( CORELANEADJvOLADLMType0 ) ( 2U )
#define C_EYEQMSG_CORELANEADJvO_LA_DLM_TYPE_0_SOLID_SOLID     ( CORELANEADJvOLADLMType0 ) ( 3U )
#define C_EYEQMSG_CORELANEADJvO_LA_DLM_TYPE_0_DASHED_DASHED   ( CORELANEADJvOLADLMType0 ) ( 4U )
#define C_EYEQMSG_CORELANEADJvO_LA_DLM_TYPE_0_UNDECIDED       ( CORELANEADJvOLADLMType0 ) ( 5U )

/* LA_DLM_Type_0_b3 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEADJvO_LA_DLM_TYPE_0_RMIN            ( 0U )
#define C_EYEQMSG_CORELANEADJvO_LA_DLM_TYPE_0_RMAX            ( 5U )
#define C_EYEQMSG_CORELANEADJvO_LA_DLM_TYPE_0_NUMR            ( 1U )
#define C_EYEQMSG_CORELANEADJvO_LA_DLM_TYPE_0_DEMNR           ( 1U )
#define C_EYEQMSG_CORELANEADJvO_LA_DLM_TYPE_0_OFFSET          ( 0U )

/* LA_Lanemark_Type_0_b4 signal Enums */
typedef uint8 CORELANEADJvOLALanemarkType0;
#define C_EYEQMSG_CORELANEADJvO_LA_LANEMARK_TYPE_0_UNDECIDED  ( CORELANEADJvOLALanemarkType0 ) ( 0U )
#define C_EYEQMSG_CORELANEADJvO_LA_LANEMARK_TYPE_0_SOLID      ( CORELANEADJvOLALanemarkType0 ) ( 1U )
#define C_EYEQMSG_CORELANEADJvO_LA_LANEMARK_TYPE_0_DASHED     ( CORELANEADJvOLALanemarkType0 ) ( 2U )
#define C_EYEQMSG_CORELANEADJvO_LA_LANEMARK_TYPE_0_DLM        ( CORELANEADJvOLALanemarkType0 ) ( 3U )
#define C_EYEQMSG_CORELANEADJvO_LA_LANEMARK_TYPE_0_BOTTS      ( CORELANEADJvOLALanemarkType0 ) ( 4U )
#define C_EYEQMSG_CORELANEADJvO_LA_LANEMARK_TYPE_0_HOV_LANE   ( CORELANEADJvOLALanemarkType0 ) ( 5U )

/* LA_Lanemark_Type_0_b4 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEADJvO_LA_LANEMARK_TYPE_0_RMIN       ( 0U )
#define C_EYEQMSG_CORELANEADJvO_LA_LANEMARK_TYPE_0_RMAX       ( 6U )
#define C_EYEQMSG_CORELANEADJvO_LA_LANEMARK_TYPE_0_NUMR       ( 1U )
#define C_EYEQMSG_CORELANEADJvO_LA_LANEMARK_TYPE_0_DEMNR      ( 1U )
#define C_EYEQMSG_CORELANEADJvO_LA_LANEMARK_TYPE_0_OFFSET     ( 0U )

/* Reserved_3_0_b2 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEADJvO_RESERVED_3_0_RMIN             ( 0U )
#define C_EYEQMSG_CORELANEADJvO_RESERVED_3_0_RMAX             ( 0U )
#define C_EYEQMSG_CORELANEADJvO_RESERVED_3_0_NUMR             ( 1U )
#define C_EYEQMSG_CORELANEADJvO_RESERVED_3_0_DEMNR            ( 1U )
#define C_EYEQMSG_CORELANEADJvO_RESERVED_3_0_OFFSET           ( 0U )

/* LA_Measured_VR_End_0_b15 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEADJvO_LA_MEASURED_VR_END_0_RMIN     ( 0U )
#define C_EYEQMSG_CORELANEADJvO_LA_MEASURED_VR_END_0_RMAX     ( 20000U )
#define C_EYEQMSG_CORELANEADJvO_LA_MEASURED_VR_END_0_NUMR     ( 1U )
#define C_EYEQMSG_CORELANEADJvO_LA_MEASURED_VR_END_0_DEMNR    ( 100U )
#define C_EYEQMSG_CORELANEADJvO_LA_MEASURED_VR_END_0_OFFSET   ( 0U )

/* LA_View_Range_End_0_b15 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEADJvO_LA_VIEW_RANGE_END_0_RMIN      ( 0U )
#define C_EYEQMSG_CORELANEADJvO_LA_VIEW_RANGE_END_0_RMAX      ( 20000U )
#define C_EYEQMSG_CORELANEADJvO_LA_VIEW_RANGE_END_0_NUMR      ( 1U )
#define C_EYEQMSG_CORELANEADJvO_LA_VIEW_RANGE_END_0_DEMNR     ( 100U )
#define C_EYEQMSG_CORELANEADJvO_LA_VIEW_RANGE_END_0_OFFSET    ( 0U )

/* Reserved_2_0_b9 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEADJvO_RESERVED_2_0_RMIN             ( 0U )
#define C_EYEQMSG_CORELANEADJvO_RESERVED_2_0_RMAX             ( 0U )
#define C_EYEQMSG_CORELANEADJvO_RESERVED_2_0_NUMR             ( 1U )
#define C_EYEQMSG_CORELANEADJvO_RESERVED_2_0_DEMNR            ( 1U )
#define C_EYEQMSG_CORELANEADJvO_RESERVED_2_0_OFFSET           ( 0U )

/* LA_View_Range_Start_0_b15 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEADJvO_LA_VIEW_RANGE_START_0_RMIN    ( 0U )
#define C_EYEQMSG_CORELANEADJvO_LA_VIEW_RANGE_START_0_RMAX    ( 20000U )
#define C_EYEQMSG_CORELANEADJvO_LA_VIEW_RANGE_START_0_NUMR    ( 1U )
#define C_EYEQMSG_CORELANEADJvO_LA_VIEW_RANGE_START_0_DEMNR   ( 100U )
#define C_EYEQMSG_CORELANEADJvO_LA_VIEW_RANGE_START_0_OFFSET  ( 0U )

/* LA_Availability_State_0_b2 signal Enums */
typedef uint8 CORELANEADJvOLAAvailabilityState0;
#define C_EYEQMSG_CORELANEADJvO_LA_AVAILABILITY_STATE_0_NOT_AVAILABLE ( CORELANEADJvOLAAvailabilityState0 ) ( 0U )
#define C_EYEQMSG_CORELANEADJvO_LA_AVAILABILITY_STATE_0_PREDICATED ( CORELANEADJvOLAAvailabilityState0 ) ( 1U )
#define C_EYEQMSG_CORELANEADJvO_LA_AVAILABILITY_STATE_0_DETECTED ( CORELANEADJvOLAAvailabilityState0 ) ( 2U )

/* LA_Availability_State_0_b2 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEADJvO_LA_AVAILABILITY_STATE_0_RMIN  ( 0U )
#define C_EYEQMSG_CORELANEADJvO_LA_AVAILABILITY_STATE_0_RMAX  ( 2U )
#define C_EYEQMSG_CORELANEADJvO_LA_AVAILABILITY_STATE_0_NUMR  ( 1U )
#define C_EYEQMSG_CORELANEADJvO_LA_AVAILABILITY_STATE_0_DEMNR ( 1U )
#define C_EYEQMSG_CORELANEADJvO_LA_AVAILABILITY_STATE_0_OFFSET ( 0U )

/* LA_Prediction_Reason_0_b6 signal Enums */
typedef uint8 CORELANEADJvOLAPredictionReason0;
#define C_EYEQMSG_CORELANEADJvO_LA_PREDICTION_REASON_0__0000001_LOSS ( CORELANEADJvOLAPredictionReason0 ) ( 0U )
#define C_EYEQMSG_CORELANEADJvO_LA_PREDICTION_REASON_0__000010_MERGE ( CORELANEADJvOLAPredictionReason0 ) ( 1U )
#define C_EYEQMSG_CORELANEADJvO_LA_PREDICTION_REASON_0__000100_SHADOW ( CORELANEADJvOLAPredictionReason0 ) ( 2U )
#define C_EYEQMSG_CORELANEADJvO_LA_PREDICTION_REASON_0__001000_DIVERGING ( CORELANEADJvOLAPredictionReason0 ) ( 3U )
#define C_EYEQMSG_CORELANEADJvO_LA_PREDICTION_REASON_0__010000_OCCLUDED ( CORELANEADJvOLAPredictionReason0 ) ( 4U )
#define C_EYEQMSG_CORELANEADJvO_LA_PREDICTION_REASON_0__100000_HEADWAY ( CORELANEADJvOLAPredictionReason0 ) ( 5U )

/* LA_Prediction_Reason_0_b6 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEADJvO_LA_PREDICTION_REASON_0_RMIN   ( 0U )
#define C_EYEQMSG_CORELANEADJvO_LA_PREDICTION_REASON_0_RMAX   ( 63U )
#define C_EYEQMSG_CORELANEADJvO_LA_PREDICTION_REASON_0_NUMR   ( 1U )
#define C_EYEQMSG_CORELANEADJvO_LA_PREDICTION_REASON_0_DEMNR  ( 1U )
#define C_EYEQMSG_CORELANEADJvO_LA_PREDICTION_REASON_0_OFFSET ( 0U )

/* LA_Color_Conf_0_b7 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEADJvO_LA_COLOR_CONF_0_RMIN          ( 0U )
#define C_EYEQMSG_CORELANEADJvO_LA_COLOR_CONF_0_RMAX          ( 100U )
#define C_EYEQMSG_CORELANEADJvO_LA_COLOR_CONF_0_NUMR          ( 1U )
#define C_EYEQMSG_CORELANEADJvO_LA_COLOR_CONF_0_DEMNR         ( 100U )
#define C_EYEQMSG_CORELANEADJvO_LA_COLOR_CONF_0_OFFSET        ( 0U )

/* LA_Color_0_b2 signal Enums */
typedef uint8 CORELANEADJvOLAColor0;
#define C_EYEQMSG_CORELANEADJvO_LA_COLOR_0_UNDECIDED          ( CORELANEADJvOLAColor0 ) ( 0U )
#define C_EYEQMSG_CORELANEADJvO_LA_COLOR_0_WHITE              ( CORELANEADJvOLAColor0 ) ( 1U )
#define C_EYEQMSG_CORELANEADJvO_LA_COLOR_0_YELLOW             ( CORELANEADJvOLAColor0 ) ( 2U )
#define C_EYEQMSG_CORELANEADJvO_LA_COLOR_0_BLUE               ( CORELANEADJvOLAColor0 ) ( 3U )

/* LA_Color_0_b2 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEADJvO_LA_COLOR_0_RMIN               ( 0U )
#define C_EYEQMSG_CORELANEADJvO_LA_COLOR_0_RMAX               ( 3U )
#define C_EYEQMSG_CORELANEADJvO_LA_COLOR_0_NUMR               ( 1U )
#define C_EYEQMSG_CORELANEADJvO_LA_COLOR_0_DEMNR              ( 1U )
#define C_EYEQMSG_CORELANEADJvO_LA_COLOR_0_OFFSET             ( 0U )

/* LA_Confidence_0_b7 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEADJvO_LA_CONFIDENCE_0_RMIN          ( 0U )
#define C_EYEQMSG_CORELANEADJvO_LA_CONFIDENCE_0_RMAX          ( 100U )
#define C_EYEQMSG_CORELANEADJvO_LA_CONFIDENCE_0_NUMR          ( 1U )
#define C_EYEQMSG_CORELANEADJvO_LA_CONFIDENCE_0_DEMNR         ( 100U )
#define C_EYEQMSG_CORELANEADJvO_LA_CONFIDENCE_0_OFFSET        ( 0U )

/* LA_Age_0_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEADJvO_LA_AGE_0_RMIN                 ( 0U )
#define C_EYEQMSG_CORELANEADJvO_LA_AGE_0_RMAX                 ( 255U )
#define C_EYEQMSG_CORELANEADJvO_LA_AGE_0_NUMR                 ( 1U )
#define C_EYEQMSG_CORELANEADJvO_LA_AGE_0_DEMNR                ( 1U )
#define C_EYEQMSG_CORELANEADJvO_LA_AGE_0_OFFSET               ( 0U )

/* LA_Lane_Track_ID_0_b8 signal Min & Max range limits */
#define C_EYEQMSG_CORELANEADJvO_LA_LANE_TRACK_ID_0_RMIN       ( 0U )
#define C_EYEQMSG_CORELANEADJvO_LA_LANE_TRACK_ID_0_RMAX       ( 255U )
#define C_EYEQMSG_CORELANEADJvO_LA_LANE_TRACK_ID_0_NUMR       ( 1U )
#define C_EYEQMSG_CORELANEADJvO_LA_LANE_TRACK_ID_0_DEMNR      ( 1U )
#define C_EYEQMSG_CORELANEADJvO_LA_LANE_TRACK_ID_0_OFFSET     ( 0U )


/*****************************************************************************
                  Exported function-like macros
*****************************************************************************/
/*****************************************************************************
                  Exported defined macros
*****************************************************************************/
/*****************************************************************************
                  Exported types, enums definitions
*****************************************************************************/
typedef struct
{
   #if ENABLE_BIG_ENDIAN_FORMAT
      uint32        LA_Zero_byte_b8                              : 8U;
      
      uint32        LA_Protocol_Version_b8                       : 8U;
      
      uint32        LA_Sync_ID_b8                                : 8U;
      
      uint32        unused1_b4                                   : 4;
      uint32        LA_Adjacent_Count_b4                         : 4U;
      
      uint32        Reserved_1_b4                                : 4U;
      
   #else
      uint32        LA_Zero_byte_b8                              : 8U;
      
      uint32        LA_Protocol_Version_b8                       : 8U;
      
      uint32        LA_Sync_ID_b8                                : 8U;
      
      uint32        LA_Adjacent_Count_b4                         : 4U;
      
      uint32        Reserved_1_b4                                : 4U;
      
   #endif
} EYEQMSG_CORELANEADJvH_Params_t;


typedef struct
{
   #if ENABLE_BIG_ENDIAN_FORMAT
      uint32        unused1_b32                                  : 32;
      uint32        LA_Lane_Track_ID_0_b8                        : 8U;
      
      uint32        LA_Age_0_b8                                  : 8U;
      
      uint32        unused2_b1                                   : 1;
      uint32        LA_Confidence_0_b7                           : 7U;
      
      uint32        LA_Color_0_1_b1                              : 1U;
      
      uint32        unused3_b6                                   : 6;
      uint32        LA_Color_0_2_b1                              : 1U;
      
      uint32        LA_Color_Conf_0_b7                           : 7U;
      
      uint32        LA_Prediction_Reason_0_b6                    : 6U;
      
      uint32        LA_Availability_State_0_b2                   : 2U;
      
      uint32        LA_View_Range_Start_0_1_b8                   : 8U;
      
      uint32        LA_View_Range_Start_0_2_b7                   : 7U;
      
      uint32        Reserved_2_0_1_b1                            : 1U;
      
      uint32        Reserved_2_0_2_b8                            : 8U;
      
      uint32        LA_View_Range_End_0_1_b8                     : 8U;
      
      uint32        LA_View_Range_End_0_2_b7                     : 7U;
      
      uint32        LA_Measured_VR_End_0_1_b1                    : 1U;
      
      uint32        LA_Measured_VR_End_0_2_b8                    : 8U;
      
      uint32        LA_Measured_VR_End_0_3_b6                    : 6U;
      
      uint32        Reserved_3_0_b2                              : 2U;
      
      uint32        LA_Lanemark_Type_0_b4                        : 4U;
      
      uint32        LA_DLM_Type_0_b3                             : 3U;
      
      uint32        LA_Lanemark_Type_Conf_0_1_b1                 : 1U;
      
      uint32        LA_Lanemark_Type_Conf_0_2_b6                 : 6U;
      
      uint32        LA_Line_Side_0_1_b2                          : 2U;
      
      uint32        LA_Line_Side_0_2_b2                          : 2U;
      
      uint32        LA_Marker_Width_0_1_b6                       : 6U;
      
      uint32        LA_Marker_Width_0_2_b2                       : 2U;
      
      uint32        Reserved_4_0_b6                              : 6U;
      
      uint32        LA_Marker_Width_STD_0_b7                     : 7U;
      
      uint32        Reserved_5_0_1_b1                            : 1U;
      
      uint32        Reserved_5_0_2_b8                            : 8U;
      
      uint32        Reserved_5_0_3_b8                            : 8U;
      
      uint32        Reserved_5_0_4_b8                            : 8U;
      
      uint32        LA_Line_C3_0_1_sb8                           : 8U;
      
      uint32        LA_Line_C3_0_2_sb8                           : 8U;
      
      uint32        LA_Line_C3_0_3_sb8                           : 8U;
      
      uint32        LA_Line_C3_0_4_sb8                           : 8U;
      
      uint32        LA_Line_C2_0_1_sb8                           : 8U;
      
      uint32        LA_Line_C2_0_2_sb8                           : 8U;
      
      uint32        LA_Line_C2_0_3_sb8                           : 8U;
      
      uint32        LA_Line_C2_0_4_sb8                           : 8U;
      
      uint32        LA_Line_C1_0_1_sb8                           : 8U;
      
      uint32        LA_Line_C1_0_2_sb8                           : 8U;
      
      uint32        LA_Line_C1_0_3_sb8                           : 8U;
      
      uint32        LA_Line_C1_0_4_sb8                           : 8U;
      
      uint32        LA_Line_C0_0_1_sb8                           : 8U;
      
      uint32        LA_Line_C0_0_2_sb8                           : 8U;
      
      uint32        LA_Line_C0_0_3_sb8                           : 8U;
      
      uint32        LA_Line_C0_0_4_sb8                           : 8U;
      
      uint32        LA_Detection_Source_0_b2                     : 2U;
      
      uint32        Reserved_6_0_1_b6                            : 6U;
      
      uint32        Reserved_6_0_2_b8                            : 8U;
      
      uint32        Reserved_6_0_3_b8                            : 8U;
      
      uint32        Reserved_6_0_4_b8                            : 8U;
      
   #else
      uint32        LA_Lane_Track_ID_0_b8                        : 8U;
      
      uint32        LA_Age_0_b8                                  : 8U;
      
      uint32        LA_Confidence_0_b7                           : 7U;
      
      uint32        LA_Color_0_b2                                : 2U;
      
      uint32        LA_Color_Conf_0_b7                           : 7U;
      
      uint32        LA_Prediction_Reason_0_b6                    : 6U;
      
      uint32        LA_Availability_State_0_b2                   : 2U;
      
      uint32        LA_View_Range_Start_0_b15                    : 15U;
      
      uint32        Reserved_2_0_b9                              : 9U;
      
      uint32        LA_View_Range_End_0_b15                      : 15U;
      
      uint32        LA_Measured_VR_End_0_b15                     : 15U;
      
      uint32        Reserved_3_0_b2                              : 2U;
      
      uint32        LA_Lanemark_Type_0_b4                        : 4U;
      
      uint32        LA_DLM_Type_0_b3                             : 3U;
      
      uint32        LA_Lanemark_Type_Conf_0_b7                   : 7U;
      
      uint32        LA_Line_Side_0_b4                            : 4U;
      
      uint32        LA_Marker_Width_0_b8                         : 8U;
      
      uint32        Reserved_4_0_b6                              : 6U;
      
      uint32        LA_Marker_Width_STD_0_b7                     : 7U;
      
      uint32        Reserved_5_0_b25                             : 25U;
      
      sint32        LA_Line_C3_0_sb32                            : 32;
      
      sint32        LA_Line_C2_0_sb32                            : 32;
      
      sint32        LA_Line_C1_0_sb32                            : 32;
      
      sint32        LA_Line_C0_0_sb32                            : 32;
      
      uint32        LA_Detection_Source_0_b2                     : 2U;
      
      uint32        Reserved_6_0_b30                             : 30U;
      
   #endif
} EYEQMSG_CORELANEADJvO_Params_t;


typedef struct
{
   EYEQMSG_CORELANEADJvH_Params_t EYEQMSG_CORELANEADJvH_Params_s;
   EYEQMSG_CORELANEADJvO_Params_t EYEQMSG_CORELANEADJvO_Params_as[C_EYEQMSG_CORELANEADJvH_VIRTUAL_OBJECT_INDEX_RMAX];
} EYEQMSG_CORELANEADJ_Params_t;


/*****************************************************************************
                  Exported function prototypes
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvH_LA_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pLA_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LA_Zero_byte
*    LA_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LA_Zero_byte signal value of Virtual_HEADER_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvH_LA_Zero_byte( uint8 * pLA_Zero_byte );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvH_LA_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pLA_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LA_Protocol_Version
*    LA_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LA_Protocol_Version signal value of Virtual_HEADER_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvH_LA_Protocol_Version( uint8 * pLA_Protocol_Version );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvH_LA_Sync_ID
*
* FUNCTION ARGUMENTS:
*    uint8 * pLA_Sync_ID - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LA_Sync_ID
*    LA_Sync_ID returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LA_Sync_ID signal value of Virtual_HEADER_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvH_LA_Sync_ID( uint8 * pLA_Sync_ID );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvH_LA_Adjacent_Count
*
* FUNCTION ARGUMENTS:
*    uint8 * pLA_Adjacent_Count - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LA_Adjacent_Count
*    LA_Adjacent_Count returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LA_Adjacent_Count signal value of Virtual_HEADER_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvH_LA_Adjacent_Count( uint8 * pLA_Adjacent_Count );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvH_Reserved_1
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1
*    Reserved_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1 signal value of Virtual_HEADER_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvH_Reserved_1( uint8 * pReserved_1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_LA_Lane_Track_ID_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLA_Lane_Track_ID_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LA_Lane_Track_ID_0
*    LA_Lane_Track_ID_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LA_Lane_Track_ID_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_LA_Lane_Track_ID_0( uint8 objIndx_u8, uint8 * pLA_Lane_Track_ID_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_LA_Age_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLA_Age_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LA_Age_0
*    LA_Age_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LA_Age_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_LA_Age_0( uint8 objIndx_u8, uint8 * pLA_Age_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_LA_Confidence_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLA_Confidence_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LA_Confidence_0
*    LA_Confidence_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LA_Confidence_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_LA_Confidence_0( uint8 objIndx_u8, uint8 * pLA_Confidence_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_LA_Color_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANEADJvOLAColor0 * pLA_Color_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LA_Color_0
*    LA_Color_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LA_Color_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_LA_Color_0( uint8 objIndx_u8, CORELANEADJvOLAColor0 * pLA_Color_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_LA_Color_Conf_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLA_Color_Conf_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LA_Color_Conf_0
*    LA_Color_Conf_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LA_Color_Conf_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_LA_Color_Conf_0( uint8 objIndx_u8, uint8 * pLA_Color_Conf_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_LA_Prediction_Reason_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANEADJvOLAPredictionReason0 * pLA_Prediction_Reason_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LA_Prediction_Reason_0
*    LA_Prediction_Reason_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LA_Prediction_Reason_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_LA_Prediction_Reason_0( uint8 objIndx_u8, CORELANEADJvOLAPredictionReason0 * pLA_Prediction_Reason_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_LA_Availability_State_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANEADJvOLAAvailabilityState0 * pLA_Availability_State_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LA_Availability_State_0
*    LA_Availability_State_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LA_Availability_State_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_LA_Availability_State_0( uint8 objIndx_u8, CORELANEADJvOLAAvailabilityState0 * pLA_Availability_State_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_LA_View_Range_Start_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLA_View_Range_Start_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LA_View_Range_Start_0
*    LA_View_Range_Start_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LA_View_Range_Start_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_LA_View_Range_Start_0( uint8 objIndx_u8, uint16 * pLA_View_Range_Start_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_Reserved_2_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pReserved_2_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_2_0
*    Reserved_2_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_2_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_Reserved_2_0( uint8 objIndx_u8, uint16 * pReserved_2_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_LA_View_Range_End_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLA_View_Range_End_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LA_View_Range_End_0
*    LA_View_Range_End_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LA_View_Range_End_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_LA_View_Range_End_0( uint8 objIndx_u8, uint16 * pLA_View_Range_End_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_LA_Measured_VR_End_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLA_Measured_VR_End_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LA_Measured_VR_End_0
*    LA_Measured_VR_End_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LA_Measured_VR_End_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_LA_Measured_VR_End_0( uint8 objIndx_u8, uint16 * pLA_Measured_VR_End_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_Reserved_3_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_3_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_3_0
*    Reserved_3_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_3_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_Reserved_3_0( uint8 objIndx_u8, uint8 * pReserved_3_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_LA_Lanemark_Type_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANEADJvOLALanemarkType0 * pLA_Lanemark_Type_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LA_Lanemark_Type_0
*    LA_Lanemark_Type_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LA_Lanemark_Type_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_LA_Lanemark_Type_0( uint8 objIndx_u8, CORELANEADJvOLALanemarkType0 * pLA_Lanemark_Type_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_LA_DLM_Type_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANEADJvOLADLMType0 * pLA_DLM_Type_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LA_DLM_Type_0
*    LA_DLM_Type_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LA_DLM_Type_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_LA_DLM_Type_0( uint8 objIndx_u8, CORELANEADJvOLADLMType0 * pLA_DLM_Type_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_LA_Lanemark_Type_Conf_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLA_Lanemark_Type_Conf_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LA_Lanemark_Type_Conf_0
*    LA_Lanemark_Type_Conf_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LA_Lanemark_Type_Conf_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_LA_Lanemark_Type_Conf_0( uint8 objIndx_u8, uint8 * pLA_Lanemark_Type_Conf_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_LA_Line_Side_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANEADJvOLALineSide0 * pLA_Line_Side_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LA_Line_Side_0
*    LA_Line_Side_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LA_Line_Side_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_LA_Line_Side_0( uint8 objIndx_u8, CORELANEADJvOLALineSide0 * pLA_Line_Side_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_LA_Marker_Width_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLA_Marker_Width_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LA_Marker_Width_0
*    LA_Marker_Width_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LA_Marker_Width_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_LA_Marker_Width_0( uint8 objIndx_u8, uint8 * pLA_Marker_Width_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_Reserved_4_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_4_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_4_0
*    Reserved_4_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_4_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_Reserved_4_0( uint8 objIndx_u8, uint8 * pReserved_4_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_LA_Marker_Width_STD_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLA_Marker_Width_STD_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LA_Marker_Width_STD_0
*    LA_Marker_Width_STD_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LA_Marker_Width_STD_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_LA_Marker_Width_STD_0( uint8 objIndx_u8, uint8 * pLA_Marker_Width_STD_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_Reserved_5_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint32 * pReserved_5_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_5_0
*    Reserved_5_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_5_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_Reserved_5_0( uint8 objIndx_u8, uint32 * pReserved_5_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_LA_Line_C3_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    float32 * pLA_Line_C3_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LA_Line_C3_0
*    LA_Line_C3_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LA_Line_C3_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_LA_Line_C3_0( uint8 objIndx_u8, float32 * pLA_Line_C3_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_LA_Line_C2_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    float32 * pLA_Line_C2_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LA_Line_C2_0
*    LA_Line_C2_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LA_Line_C2_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_LA_Line_C2_0( uint8 objIndx_u8, float32 * pLA_Line_C2_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_LA_Line_C1_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    float32 * pLA_Line_C1_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LA_Line_C1_0
*    LA_Line_C1_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LA_Line_C1_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_LA_Line_C1_0( uint8 objIndx_u8, float32 * pLA_Line_C1_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_LA_Line_C0_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    float32 * pLA_Line_C0_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LA_Line_C0_0
*    LA_Line_C0_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LA_Line_C0_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_LA_Line_C0_0( uint8 objIndx_u8, float32 * pLA_Line_C0_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_LA_Detection_Source_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELANEADJvOLADetectionSource0 * pLA_Detection_Source_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LA_Detection_Source_0
*    LA_Detection_Source_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LA_Detection_Source_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_LA_Detection_Source_0( uint8 objIndx_u8, CORELANEADJvOLADetectionSource0 * pLA_Detection_Source_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELANEADJvO_Reserved_6_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint32 * pReserved_6_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_6_0
*    Reserved_6_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_6_0 signal value of Virtual_OBJECT_msg_Core_Lanes_Adjacent_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELANEADJvO_Reserved_6_0( uint8 objIndx_u8, uint32 * pReserved_6_0 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_CORELANEADJ_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_CORELANEADJ_Params_t * pCore_Lanes_Adjacent_protocol - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_Lanes_Adjacent_protocol message 
*    Core_Lanes_Adjacent_protocol message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_Lanes_Adjacent_protocol message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_CORELANEADJ_ParamsApp_MsgDataStruct( EYEQMSG_CORELANEADJ_Params_t * pCore_Lanes_Adjacent_protocol );
/*****************************************************************************
                  Exported object declarations
*****************************************************************************/
extern EYEQMSG_CORELANEADJ_Params_t   EYEQMSG_CORELANEADJ_Params_s;
extern EYEQMSG_CORELANEADJ_Params_t   EYEQMSG_CORELANEADJ_ParamsApp_s;
/****************************************************************************/
#endif /* _EYEQMSG_CORELANEADJPROCESS_H_ */


