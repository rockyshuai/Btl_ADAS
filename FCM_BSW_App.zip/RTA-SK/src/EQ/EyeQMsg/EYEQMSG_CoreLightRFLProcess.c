

/*****************************************************************************
                  Include files
*****************************************************************************/
/* The suggested include file order is: */
#include "EyeQ_defs.h"    /* EyeQ project common definitions file    */

#include "EYEQMSG_CoreLightRFLProcess.h"

/*****************************************************************************
                  Local symbolic constants
*****************************************************************************/
/*****************************************************************************
                  Local types, enums definitions
*****************************************************************************/
/*****************************************************************************
                  Local function prototypes
*****************************************************************************/
/*****************************************************************************
                  Local object definitions
*****************************************************************************/
/*****************************************************************************
                  Exported object definitions
*****************************************************************************/
EYEQMSG_CORELIGHTRFL_Params_t   EYEQMSG_CORELIGHTRFL_Params_s;
EYEQMSG_CORELIGHTRFL_Params_t   EYEQMSG_CORELIGHTRFL_ParamsApp_s;
/*****************************************************************************
                  Local function-like macros
*****************************************************************************/
/*****************************************************************************
                  Local defined macros
*****************************************************************************/
/*****************************************************************************
                  Function definitions
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTRFLvH_LSR_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pLSR_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSR_Zero_byte
*    LSR_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSR_Zero_byte signal value of Virtual_HEADER_msg_Core_Light_Scene_RFL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTRFLvH_LSR_Zero_byte( uint8 * pLSR_Zero_byte )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pLSR_Zero_byte != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTRFL_ParamsApp_s.EYEQMSG_CORELIGHTRFLvH_Params_s.LSR_Zero_byte_b8;
      * pLSR_Zero_byte = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTRFLvH_LSR_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pLSR_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSR_Protocol_Version
*    LSR_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSR_Protocol_Version signal value of Virtual_HEADER_msg_Core_Light_Scene_RFL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTRFLvH_LSR_Protocol_Version( uint8 * pLSR_Protocol_Version )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pLSR_Protocol_Version != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTRFL_ParamsApp_s.EYEQMSG_CORELIGHTRFLvH_Params_s.LSR_Protocol_Version_b7;
      * pLSR_Protocol_Version = signal_value;
      if( (signal_value >= C_EYEQMSG_CORELIGHTRFLvH_LSR_PROTOCOL_VERSION_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORELIGHTRFLvH_LSR_PROTOCOL_VERSION_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTRFLvH_LSR_Sync_ID
*
* FUNCTION ARGUMENTS:
*    uint8 * pLSR_Sync_ID - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSR_Sync_ID
*    LSR_Sync_ID returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSR_Sync_ID signal value of Virtual_HEADER_msg_Core_Light_Scene_RFL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTRFLvH_LSR_Sync_ID( uint8 * pLSR_Sync_ID )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pLSR_Sync_ID != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTRFL_ParamsApp_s.EYEQMSG_CORELIGHTRFLvH_Params_s.LSR_Sync_ID_b8;
      * pLSR_Sync_ID = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTRFLvH_LSR_Running_Mode
*
* FUNCTION ARGUMENTS:
*    CORELIGHTRFLvHLSRRunningMode * pLSR_Running_Mode - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSR_Running_Mode
*    LSR_Running_Mode returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSR_Running_Mode signal value of Virtual_HEADER_msg_Core_Light_Scene_RFL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTRFLvH_LSR_Running_Mode( CORELIGHTRFLvHLSRRunningMode * pLSR_Running_Mode )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTRFLvHLSRRunningMode signal_value;
   
   if( pLSR_Running_Mode != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTRFL_ParamsApp_s.EYEQMSG_CORELIGHTRFLvH_Params_s.LSR_Running_Mode_b2;
      * pLSR_Running_Mode = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTRFLvH_LSR_Inactive_Reason
*
* FUNCTION ARGUMENTS:
*    CORELIGHTRFLvHLSRInactiveReason * pLSR_Inactive_Reason - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSR_Inactive_Reason
*    LSR_Inactive_Reason returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSR_Inactive_Reason signal value of Virtual_HEADER_msg_Core_Light_Scene_RFL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTRFLvH_LSR_Inactive_Reason( CORELIGHTRFLvHLSRInactiveReason * pLSR_Inactive_Reason )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTRFLvHLSRInactiveReason signal_value;
   
   if( pLSR_Inactive_Reason != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTRFL_ParamsApp_s.EYEQMSG_CORELIGHTRFLvH_Params_s.LSR_Inactive_Reason_b3;
      * pLSR_Inactive_Reason = signal_value;
      if( signal_value <= C_EYEQMSG_CORELIGHTRFLvH_LSR_INACTIVE_REASON_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTRFLvH_LSR_Strong_Reflectors_Count
*
* FUNCTION ARGUMENTS:
*    uint8 * pLSR_Strong_Reflectors_Count - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSR_Strong_Reflectors_Count
*    LSR_Strong_Reflectors_Count returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSR_Strong_Reflectors_Count signal value of Virtual_HEADER_msg_Core_Light_Scene_RFL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTRFLvH_LSR_Strong_Reflectors_Count( uint8 * pLSR_Strong_Reflectors_Count )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pLSR_Strong_Reflectors_Count != C_NULL_P )
   {
      signal_value = EYEQMSG_CORELIGHTRFL_ParamsApp_s.EYEQMSG_CORELIGHTRFLvH_Params_s.LSR_Strong_Reflectors_Count_b4;
      * pLSR_Strong_Reflectors_Count = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTRFLvO_LSR_ID_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLSR_ID_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSR_ID_0
*    LSR_ID_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSR_ID_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_RFL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTRFLvO_LSR_ID_0( uint8 objIndx_u8, uint8 * pLSR_ID_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Light_Scene_RFL_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELIGHTRFLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLSR_ID_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELIGHTRFL_ParamsApp_s.EYEQMSG_CORELIGHTRFLvO_Params_as[objIndx_u8].LSR_ID_0_b8;
         * pLSR_ID_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTRFLvO_LSR_Brightness_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLSR_Brightness_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSR_Brightness_0
*    LSR_Brightness_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSR_Brightness_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_RFL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTRFLvO_LSR_Brightness_0( uint8 objIndx_u8, uint8 * pLSR_Brightness_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Light_Scene_RFL_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELIGHTRFLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLSR_Brightness_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELIGHTRFL_ParamsApp_s.EYEQMSG_CORELIGHTRFLvO_Params_as[objIndx_u8].LSR_Brightness_0_b7;
         * pLSR_Brightness_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELIGHTRFLvO_LSR_BRIGHTNESS_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTRFLvO_LSR_Max_Brightness_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLSR_Max_Brightness_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSR_Max_Brightness_0
*    LSR_Max_Brightness_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSR_Max_Brightness_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_RFL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTRFLvO_LSR_Max_Brightness_0( uint8 objIndx_u8, uint8 * pLSR_Max_Brightness_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Light_Scene_RFL_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELIGHTRFLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLSR_Max_Brightness_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELIGHTRFL_ParamsApp_s.EYEQMSG_CORELIGHTRFLvO_Params_as[objIndx_u8].LSR_Max_Brightness_0_b7;
         * pLSR_Max_Brightness_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELIGHTRFLvO_LSR_MAX_BRIGHTNESS_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTRFLvO_LSR_Distance_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLSR_Distance_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSR_Distance_0
*    LSR_Distance_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSR_Distance_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_RFL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTRFLvO_LSR_Distance_0( uint8 objIndx_u8, uint16 * pLSR_Distance_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Light_Scene_RFL_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELIGHTRFLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLSR_Distance_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELIGHTRFL_ParamsApp_s.EYEQMSG_CORELIGHTRFLvO_Params_as[objIndx_u8].LSR_Distance_0_b9;
         * pLSR_Distance_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELIGHTRFLvO_LSR_DISTANCE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTRFLvO_Reserved_1_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    boolean * pReserved_1_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1_0
*    Reserved_1_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_RFL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTRFLvO_Reserved_1_0( uint8 objIndx_u8, boolean * pReserved_1_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Light_Scene_RFL_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELIGHTRFLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_1_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELIGHTRFL_ParamsApp_s.EYEQMSG_CORELIGHTRFLvO_Params_as[objIndx_u8].Reserved_1_0_b1;
         * pReserved_1_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELIGHTRFLvO_RESERVED_1_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTRFLvO_LSR_Top_Angle_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLSR_Top_Angle_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSR_Top_Angle_0
*    LSR_Top_Angle_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSR_Top_Angle_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_RFL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTRFLvO_LSR_Top_Angle_0( uint8 objIndx_u8, uint16 * pLSR_Top_Angle_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Light_Scene_RFL_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELIGHTRFLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLSR_Top_Angle_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELIGHTRFL_ParamsApp_s.EYEQMSG_CORELIGHTRFLvO_Params_as[objIndx_u8].LSR_Top_Angle_0_b12;
         * pLSR_Top_Angle_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELIGHTRFLvO_LSR_TOP_ANGLE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTRFLvO_LSR_Right_Angle_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLSR_Right_Angle_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSR_Right_Angle_0
*    LSR_Right_Angle_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSR_Right_Angle_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_RFL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTRFLvO_LSR_Right_Angle_0( uint8 objIndx_u8, uint16 * pLSR_Right_Angle_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Light_Scene_RFL_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELIGHTRFLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLSR_Right_Angle_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELIGHTRFL_ParamsApp_s.EYEQMSG_CORELIGHTRFLvO_Params_as[objIndx_u8].LSR_Right_Angle_0_b13;
         * pLSR_Right_Angle_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELIGHTRFLvO_LSR_RIGHT_ANGLE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTRFLvO_Reserved_2_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_2_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_2_0
*    Reserved_2_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_2_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_RFL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTRFLvO_Reserved_2_0( uint8 objIndx_u8, uint8 * pReserved_2_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Light_Scene_RFL_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELIGHTRFLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_2_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELIGHTRFL_ParamsApp_s.EYEQMSG_CORELIGHTRFLvO_Params_as[objIndx_u8].Reserved_2_0_b7;
         * pReserved_2_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELIGHTRFLvO_RESERVED_2_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTRFLvO_LSR_Bottom_Angle_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLSR_Bottom_Angle_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSR_Bottom_Angle_0
*    LSR_Bottom_Angle_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSR_Bottom_Angle_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_RFL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTRFLvO_LSR_Bottom_Angle_0( uint8 objIndx_u8, uint16 * pLSR_Bottom_Angle_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Light_Scene_RFL_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELIGHTRFLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLSR_Bottom_Angle_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELIGHTRFL_ParamsApp_s.EYEQMSG_CORELIGHTRFLvO_Params_as[objIndx_u8].LSR_Bottom_Angle_0_b12;
         * pLSR_Bottom_Angle_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELIGHTRFLvO_LSR_BOTTOM_ANGLE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTRFLvO_LSR_Left_Angle_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLSR_Left_Angle_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSR_Left_Angle_0
*    LSR_Left_Angle_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSR_Left_Angle_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_RFL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTRFLvO_LSR_Left_Angle_0( uint8 objIndx_u8, uint16 * pLSR_Left_Angle_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Light_Scene_RFL_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELIGHTRFLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLSR_Left_Angle_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELIGHTRFL_ParamsApp_s.EYEQMSG_CORELIGHTRFLvO_Params_as[objIndx_u8].LSR_Left_Angle_0_b13;
         * pLSR_Left_Angle_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELIGHTRFLvO_LSR_LEFT_ANGLE_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTRFLvO_Reserved_3_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pReserved_3_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_3_0
*    Reserved_3_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_3_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_RFL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTRFLvO_Reserved_3_0( uint8 objIndx_u8, uint8 * pReserved_3_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Light_Scene_RFL_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELIGHTRFLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pReserved_3_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELIGHTRFL_ParamsApp_s.EYEQMSG_CORELIGHTRFLvO_Params_as[objIndx_u8].Reserved_3_0_b7;
         * pReserved_3_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELIGHTRFLvO_RESERVED_3_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTRFLvO_LSR_Atten_Cent_Angle_H_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLSR_Atten_Cent_Angle_H_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSR_Atten_Cent_Angle_H_0
*    LSR_Atten_Cent_Angle_H_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSR_Atten_Cent_Angle_H_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_RFL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTRFLvO_LSR_Atten_Cent_Angle_H_0( uint8 objIndx_u8, uint16 * pLSR_Atten_Cent_Angle_H_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Light_Scene_RFL_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELIGHTRFLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLSR_Atten_Cent_Angle_H_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELIGHTRFL_ParamsApp_s.EYEQMSG_CORELIGHTRFLvO_Params_as[objIndx_u8].LSR_Atten_Cent_Angle_H_0_b13;
         * pLSR_Atten_Cent_Angle_H_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELIGHTRFLvO_LSR_ATTEN_CENT_ANGLE_H_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTRFLvO_LSR_Is_Cluster_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    CORELIGHTRFLvOLSRIsCluster0 * pLSR_Is_Cluster_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSR_Is_Cluster_0
*    LSR_Is_Cluster_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSR_Is_Cluster_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_RFL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTRFLvO_LSR_Is_Cluster_0( uint8 objIndx_u8, CORELIGHTRFLvOLSRIsCluster0 * pLSR_Is_Cluster_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORELIGHTRFLvOLSRIsCluster0 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Light_Scene_RFL_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELIGHTRFLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLSR_Is_Cluster_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELIGHTRFL_ParamsApp_s.EYEQMSG_CORELIGHTRFLvO_Params_as[objIndx_u8].LSR_Is_Cluster_0_b1;
         * pLSR_Is_Cluster_0 = signal_value;
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTRFLvO_LSR_Atten_Cent_Angle_Lat_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint16 * pLSR_Atten_Cent_Angle_Lat_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSR_Atten_Cent_Angle_Lat_0
*    LSR_Atten_Cent_Angle_Lat_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSR_Atten_Cent_Angle_Lat_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_RFL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTRFLvO_LSR_Atten_Cent_Angle_Lat_0( uint8 objIndx_u8, uint16 * pLSR_Atten_Cent_Angle_Lat_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Light_Scene_RFL_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELIGHTRFLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLSR_Atten_Cent_Angle_Lat_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELIGHTRFL_ParamsApp_s.EYEQMSG_CORELIGHTRFLvO_Params_as[objIndx_u8].LSR_Atten_Cent_Angle_Lat_0_b13;
         * pLSR_Atten_Cent_Angle_Lat_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELIGHTRFLvO_LSR_ATTEN_CENT_ANGLE_LAT_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORELIGHTRFLvO_LSR_Buffer_0
*
* FUNCTION ARGUMENTS:
*    uint8 objIndx_u8 - message index
*    uint8 * pLSR_Buffer_0 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of LSR_Buffer_0
*    LSR_Buffer_0 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns LSR_Buffer_0 signal value of Virtual_OBJECT_msg_Core_Light_Scene_RFL_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORELIGHTRFLvO_LSR_Buffer_0( uint8 objIndx_u8, uint8 * pLSR_Buffer_0 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   /* Grab the valid Virtual_OBJECT_msg_Core_Light_Scene_RFL_protocol signal */
   if( objIndx_u8 < C_EYEQMSG_CORELIGHTRFLvH_VIRTUAL_OBJECT_INDEX_RMAX)
   {
      if( pLSR_Buffer_0 != C_NULL_P )
      {
         signal_value = EYEQMSG_CORELIGHTRFL_ParamsApp_s.EYEQMSG_CORELIGHTRFLvO_Params_as[objIndx_u8].LSR_Buffer_0_b5;
         * pLSR_Buffer_0 = signal_value;
         if( signal_value <= C_EYEQMSG_CORELIGHTRFLvO_LSR_BUFFER_0_RMAX )
         {
            status = C_SIG_VALID;
         }
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_CORELIGHTRFL_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_CORELIGHTRFL_Params_t * pCore_Light_Scene_RFL_protocol - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_Light_Scene_RFL_protocol message 
*    Core_Light_Scene_RFL_protocol message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_Light_Scene_RFL_protocol message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_CORELIGHTRFL_ParamsApp_MsgDataStruct( EYEQMSG_CORELIGHTRFL_Params_t * pCore_Light_Scene_RFL_protocol )
{
   Std_ReturnType status = C_SIG_INVALID;
   if( pCore_Light_Scene_RFL_protocol != C_NULL_P )
   {
      status = C_SIG_VALID;
      * pCore_Light_Scene_RFL_protocol = EYEQMSG_CORELIGHTRFL_ParamsApp_s;
   }
   return ( status );
}

