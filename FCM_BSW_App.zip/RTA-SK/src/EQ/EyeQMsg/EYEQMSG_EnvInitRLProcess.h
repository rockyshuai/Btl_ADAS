#ifndef _EYEQMSG_ENVINITRLPROCESS_H_
#define _EYEQMSG_ENVINITRLPROCESS_H_

/*****************************************************************************
                  Included header files
*****************************************************************************/
#include <Std_Types.h>

/*****************************************************************************
                  Include files
*****************************************************************************/
/*****************************************************************************
                  Exported symbolic constants
*****************************************************************************/

/* Datagram message ID */
#define C_EYEQMSG_ENVINITRL_MSG_ID                            ( 0xE7U )

/* Datagram message lengths */
#define C_EYEQMSG_ENVINITRL_MSG_LEN                           ( sizeof(EYEQMSG_ENVINITRL_Params_t) )

/* Protocol ENUMs */

/* MCU output messages */

/* Environment_Init_rearCornerLeft Enums */
/* Reserved_3_b16 signal Min & Max range limits */
#define C_EYEQMSG_ENVINITRL_RESERVED_3_RMIN                   ( 0U )
#define C_EYEQMSG_ENVINITRL_RESERVED_3_RMAX                   ( 0U )
#define C_EYEQMSG_ENVINITRL_RESERVED_3_NUMR                   ( 1U )
#define C_EYEQMSG_ENVINITRL_RESERVED_3_DEMNR                  ( 1U )
#define C_EYEQMSG_ENVINITRL_RESERVED_3_OFFSET                 ( 0U )

/* IEnvironment_Bottom_Crop_b16 signal Min & Max range limits */
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_BOTTOM_CROP_RMIN     ( 0U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_BOTTOM_CROP_RMAX     ( 115U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_BOTTOM_CROP_NUMR     ( 1 )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_BOTTOM_CROP_DEMNR    ( 1 )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_BOTTOM_CROP_OFFSET   ( -135 )

/* IEnvironment_Top_Crop_b16 signal Min & Max range limits */
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_TOP_CROP_RMIN        ( 20U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_TOP_CROP_RMAX        ( 135U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_TOP_CROP_NUMR        ( 1U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_TOP_CROP_DEMNR       ( 1U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_TOP_CROP_OFFSET      ( 0U )

/* IEnvironment_MaxRoll_b16 signal Min & Max range limits */
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_MAXROLL_RMIN         ( 0U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_MAXROLL_RMAX         ( 451U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_MAXROLL_NUMR         ( 1U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_MAXROLL_DEMNR        ( 8192U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_MAXROLL_OFFSET       ( 0U )

/* IEnvironment_MaxYaw_b16 signal Min & Max range limits */
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_MAXYAW_RMIN          ( 0U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_MAXYAW_RMAX          ( 100U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_MAXYAW_NUMR          ( 1U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_MAXYAW_DEMNR         ( 1U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_MAXYAW_OFFSET        ( 0U )

/* IEnvironment_MinYaw_b16 signal Min & Max range limits */
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_MINYAW_RMIN          ( 0U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_MINYAW_RMAX          ( 100U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_MINYAW_NUMR          ( 1 )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_MINYAW_DEMNR         ( 1 )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_MINYAW_OFFSET        ( -100 )

/* IEnvironment_MaxHorizon_b16 signal Min & Max range limits */
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_MAXHORIZON_RMIN      ( 0U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_MAXHORIZON_RMAX      ( 360U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_MAXHORIZON_NUMR      ( 1 )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_MAXHORIZON_DEMNR     ( 1 )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_MAXHORIZON_OFFSET    ( -220 )

/* IEnvironment_MinHorizon_b16 signal Min & Max range limits */
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_MINHORIZON_RMIN      ( 0U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_MINHORIZON_RMAX      ( 380U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_MINHORIZON_NUMR      ( 1 )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_MINHORIZON_DEMNR     ( 1 )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_MINHORIZON_OFFSET    ( -380 )

/* IEnvironment_CamToRearAxle_b16 signal Min & Max range limits */
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_CAMTOREARAXLE_RMIN   ( 0U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_CAMTOREARAXLE_RMAX   ( 300U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_CAMTOREARAXLE_NUMR   ( 1 )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_CAMTOREARAXLE_DEMNR  ( 100 )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_CAMTOREARAXLE_OFFSET ( -3 )

/* IEnvironment_CamToFrontAxle_b16 signal Min & Max range limits */
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_CAMTOFRONTAXLE_RMIN  ( 0U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_CAMTOFRONTAXLE_RMAX  ( 600U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_CAMTOFRONTAXLE_NUMR  ( 1 )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_CAMTOFRONTAXLE_DEMNR ( 100 )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_CAMTOFRONTAXLE_OFFSET ( -3 )

/* IEnvironment_RefPX_Front_Bumper_b16 signal Min & Max range limits */
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_REFPX_FRONT_BUMPER_RMIN ( 0U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_REFPX_FRONT_BUMPER_RMAX ( 255U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_REFPX_FRONT_BUMPER_NUMR ( 1U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_REFPX_FRONT_BUMPER_DEMNR ( 100U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_REFPX_FRONT_BUMPER_OFFSET ( 0U )

/* IEnvironment_RightWheel_b16 signal Min & Max range limits */
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_RIGHTWHEEL_RMIN      ( 20U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_RIGHTWHEEL_RMAX      ( 500U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_RIGHTWHEEL_NUMR      ( 1U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_RIGHTWHEEL_DEMNR     ( 100U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_RIGHTWHEEL_OFFSET    ( 0U )

/* Reserved_2_b8 signal Min & Max range limits */
#define C_EYEQMSG_ENVINITRL_RESERVED_2_RMIN                   ( 0U )
#define C_EYEQMSG_ENVINITRL_RESERVED_2_RMAX                   ( 0U )
#define C_EYEQMSG_ENVINITRL_RESERVED_2_NUMR                   ( 1U )
#define C_EYEQMSG_ENVINITRL_RESERVED_2_DEMNR                  ( 1U )
#define C_EYEQMSG_ENVINITRL_RESERVED_2_OFFSET                 ( 0U )

/* IEnvironment_LeftWheel_b16 signal Min & Max range limits */
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_LEFTWHEEL_RMIN       ( 20U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_LEFTWHEEL_RMAX       ( 500U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_LEFTWHEEL_NUMR       ( 1U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_LEFTWHEEL_DEMNR      ( 100U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_LEFTWHEEL_OFFSET     ( 0U )

/* IEnvironment_WheelRadius_b8 signal Min & Max range limits */
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_WHEELRADIUS_RMIN     ( 0U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_WHEELRADIUS_RMAX     ( 50U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_WHEELRADIUS_NUMR     ( 1U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_WHEELRADIUS_DEMNR    ( 100U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_WHEELRADIUS_OFFSET   ( 0U )

/* Reserved_1_b4 signal Min & Max range limits */
#define C_EYEQMSG_ENVINITRL_RESERVED_1_RMIN                   ( 0U )
#define C_EYEQMSG_ENVINITRL_RESERVED_1_RMAX                   ( 0U )
#define C_EYEQMSG_ENVINITRL_RESERVED_1_NUMR                   ( 1U )
#define C_EYEQMSG_ENVINITRL_RESERVED_1_DEMNR                  ( 1U )
#define C_EYEQMSG_ENVINITRL_RESERVED_1_OFFSET                 ( 0U )

/* IEnvironment_WheelWidth_b6 signal Min & Max range limits */
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_WHEELWIDTH_RMIN      ( 0U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_WHEELWIDTH_RMAX      ( 50U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_WHEELWIDTH_NUMR      ( 1U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_WHEELWIDTH_DEMNR     ( 100U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_WHEELWIDTH_OFFSET    ( 0U )

/* IEnvironment_GPSToCam_dz_b11 signal Min & Max range limits */
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_GPSTOCAM_DZ_RMIN     ( 0U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_GPSTOCAM_DZ_RMAX     ( 2047U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_GPSTOCAM_DZ_NUMR     ( 1 )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_GPSTOCAM_DZ_DEMNR    ( 100 )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_GPSTOCAM_DZ_OFFSET   ( -10.24f )

/* IEnvironment_GPSToCam_dz_V_b1 signal Enums */
typedef boolean ENVINITRLIEnvironmentGPSToCamDzV;
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_GPSTOCAM_DZ_V_FALSE  ( ENVINITRLIEnvironmentGPSToCamDzV ) ( 0U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_GPSTOCAM_DZ_V_TRUE   ( ENVINITRLIEnvironmentGPSToCamDzV ) ( 1U )

/* IEnvironment_GPSToCam_dz_V_b1 signal Min & Max range limits */
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_GPSTOCAM_DZ_V_RMIN   ( 0U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_GPSTOCAM_DZ_V_RMAX   ( 1U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_GPSTOCAM_DZ_V_NUMR   ( 1U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_GPSTOCAM_DZ_V_DEMNR  ( 1U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_GPSTOCAM_DZ_V_OFFSET ( 0U )

/* IEnvironment_GPSToCam_dy_b9 signal Min & Max range limits */
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_GPSTOCAM_DY_RMIN     ( 0U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_GPSTOCAM_DY_RMAX     ( 511U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_GPSTOCAM_DY_NUMR     ( 1 )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_GPSTOCAM_DY_DEMNR    ( 100 )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_GPSTOCAM_DY_OFFSET   ( -2.56f )

/* IEnvironment_GPSToCam_dy_V_b1 signal Enums */
typedef boolean ENVINITRLIEnvironmentGPSToCamDyV;
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_GPSTOCAM_DY_V_FALSE  ( ENVINITRLIEnvironmentGPSToCamDyV ) ( 0U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_GPSTOCAM_DY_V_TRUE   ( ENVINITRLIEnvironmentGPSToCamDyV ) ( 1U )

/* IEnvironment_GPSToCam_dy_V_b1 signal Min & Max range limits */
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_GPSTOCAM_DY_V_RMIN   ( 0U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_GPSTOCAM_DY_V_RMAX   ( 1U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_GPSTOCAM_DY_V_NUMR   ( 1U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_GPSTOCAM_DY_V_DEMNR  ( 1U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_GPSTOCAM_DY_V_OFFSET ( 0U )

/* IEnvironment_Buffer1_b2 signal Min & Max range limits */
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_BUFFER1_RMIN         ( 0U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_BUFFER1_RMAX         ( 0U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_BUFFER1_NUMR         ( 1U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_BUFFER1_DEMNR        ( 1U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_BUFFER1_OFFSET       ( 0U )

/* IEnvironment_Buffer1_V_b1 signal Min & Max range limits */
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_BUFFER1_V_RMIN       ( 0U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_BUFFER1_V_RMAX       ( 0U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_BUFFER1_V_NUMR       ( 1U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_BUFFER1_V_DEMNR      ( 1U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_BUFFER1_V_OFFSET     ( 0U )

/* IEnvironment_GPSToCam_dx_b9 signal Min & Max range limits */
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_GPSTOCAM_DX_RMIN     ( 0U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_GPSTOCAM_DX_RMAX     ( 511U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_GPSTOCAM_DX_NUMR     ( 1 )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_GPSTOCAM_DX_DEMNR    ( 100 )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_GPSTOCAM_DX_OFFSET   ( -2.56f )

/* IEnvironment_GPSToCam_dx_V_b1 signal Enums */
typedef boolean ENVINITRLIEnvironmentGPSToCamDxV;
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_GPSTOCAM_DX_V_FALSE  ( ENVINITRLIEnvironmentGPSToCamDxV ) ( 0U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_GPSTOCAM_DX_V_TRUE   ( ENVINITRLIEnvironmentGPSToCamDxV ) ( 1U )

/* IEnvironment_GPSToCam_dx_V_b1 signal Min & Max range limits */
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_GPSTOCAM_DX_V_RMIN   ( 0U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_GPSTOCAM_DX_V_RMAX   ( 1U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_GPSTOCAM_DX_V_NUMR   ( 1U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_GPSTOCAM_DX_V_DEMNR  ( 1U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_GPSTOCAM_DX_V_OFFSET ( 0U )

/* IEnvironment_Optional_Signals_b3 signal Min & Max range limits */
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_OPTIONAL_SIGNALS_RMIN ( 4U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_OPTIONAL_SIGNALS_RMAX ( 4U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_OPTIONAL_SIGNALS_NUMR ( 1U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_OPTIONAL_SIGNALS_DEMNR ( 1U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_OPTIONAL_SIGNALS_OFFSET ( 0U )

/* IEnvironment_Protocol_Version_b8 signal Min & Max range limits */
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_PROTOCOL_VERSION_RMIN ( 5U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_PROTOCOL_VERSION_RMAX ( 5U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_PROTOCOL_VERSION_NUMR ( 1U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_PROTOCOL_VERSION_DEMNR ( 1U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_PROTOCOL_VERSION_OFFSET ( 0U )

/* IEnvironment_Zero_Byte_b8 signal Min & Max range limits */
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_ZERO_BYTE_RMIN       ( 0U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_ZERO_BYTE_RMAX       ( 0U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_ZERO_BYTE_NUMR       ( 1U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_ZERO_BYTE_DEMNR      ( 1U )
#define C_EYEQMSG_ENVINITRL_IENVIRONMENT_ZERO_BYTE_OFFSET     ( 0U )


/*****************************************************************************
                  Exported function-like macros
*****************************************************************************/
/*****************************************************************************
                  Exported defined macros
*****************************************************************************/
/*****************************************************************************
                  Exported types, enums definitions
*****************************************************************************/
typedef struct
{
   #if ENABLE_BIG_ENDIAN_FORMAT
      uint32        IEnvironment_Zero_Byte_b8                    : 8U;
      
      uint32        IEnvironment_Protocol_Version_b8             : 8U;
      
      uint32        unused1_b5                                   : 5;
      uint32        IEnvironment_Optional_Signals_b3             : 3U;
      
      uint32        IEnvironment_GPSToCam_dx_V_b1                : 1U;
      
      uint32        IEnvironment_GPSToCam_dx_1_b4                : 4U;
      
      uint32        IEnvironment_GPSToCam_dx_2_b5                : 5U;
      
      uint32        IEnvironment_Buffer1_V_b1                    : 1U;
      
      uint32        IEnvironment_Buffer1_b2                      : 2U;
      
      uint32        unused2_b2                                   : 2;
      uint32        IEnvironment_GPSToCam_dy_V_b1                : 1U;
      
      uint32        IEnvironment_GPSToCam_dy_1_b7                : 7U;
      
      uint32        IEnvironment_GPSToCam_dy_2_b2                : 2U;
      
      uint32        IEnvironment_GPSToCam_dz_V_b1                : 1U;
      
      uint32        IEnvironment_GPSToCam_dz_1_b5                : 5U;
      
      uint32        IEnvironment_GPSToCam_dz_2_b6                : 6U;
      
      uint32        IEnvironment_WheelWidth_1_b2                 : 2U;
      
      uint32        IEnvironment_WheelWidth_2_b4                 : 4U;
      
      uint32        Reserved_1_b4                                : 4U;
      
      uint32        IEnvironment_WheelRadius_b8                  : 8U;
      
      uint32        IEnvironment_LeftWheel_1_b8                  : 8U;
      
      uint32        IEnvironment_LeftWheel_2_b8                  : 8U;
      
      uint32        Reserved_2_b8                                : 8U;
      
      uint32        IEnvironment_RightWheel_1_b8                 : 8U;
      
      uint32        IEnvironment_RightWheel_2_b8                 : 8U;
      
      uint32        IEnvironment_RefPX_Front_Bumper_1_b8         : 8U;
      
      uint32        IEnvironment_RefPX_Front_Bumper_2_b8         : 8U;
      
      uint32        IEnvironment_CamToFrontAxle_1_b8             : 8U;
      
      uint32        IEnvironment_CamToFrontAxle_2_b8             : 8U;
      
      uint32        IEnvironment_CamToRearAxle_1_b8              : 8U;
      
      uint32        IEnvironment_CamToRearAxle_2_b8              : 8U;
      
      uint32        IEnvironment_MinHorizon_1_b8                 : 8U;
      
      uint32        IEnvironment_MinHorizon_2_b8                 : 8U;
      
      uint32        IEnvironment_MaxHorizon_1_b8                 : 8U;
      
      uint32        IEnvironment_MaxHorizon_2_b8                 : 8U;
      
      uint32        IEnvironment_MinYaw_1_b8                     : 8U;
      
      uint32        IEnvironment_MinYaw_2_b8                     : 8U;
      
      uint32        IEnvironment_MaxYaw_1_b8                     : 8U;
      
      uint32        IEnvironment_MaxYaw_2_b8                     : 8U;
      
      uint32        IEnvironment_MaxRoll_1_b8                    : 8U;
      
      uint32        IEnvironment_MaxRoll_2_b8                    : 8U;
      
      uint32        IEnvironment_Top_Crop_1_b8                   : 8U;
      
      uint32        IEnvironment_Top_Crop_2_b8                   : 8U;
      
      uint32        IEnvironment_Bottom_Crop_1_b8                : 8U;
      
      uint32        IEnvironment_Bottom_Crop_2_b8                : 8U;
      
      uint32        Reserved_3_1_b8                              : 8U;
      
      uint32        Reserved_3_2_b8                              : 8U;
      
   #else
      uint32        IEnvironment_Zero_Byte_b8                    : 8U;
      
      uint32        IEnvironment_Protocol_Version_b8             : 8U;
      
      uint32        IEnvironment_Optional_Signals_b3             : 3U;
      
      uint32        IEnvironment_GPSToCam_dx_V_b1                : 1U;
      
      uint32        IEnvironment_GPSToCam_dx_b9                  : 9U;
      
      uint32        IEnvironment_Buffer1_V_b1                    : 1U;
      
      uint32        IEnvironment_Buffer1_b2                      : 2U;
      
      uint32        IEnvironment_GPSToCam_dy_V_b1                : 1U;
      
      uint32        IEnvironment_GPSToCam_dy_b9                  : 9U;
      
      uint32        IEnvironment_GPSToCam_dz_V_b1                : 1U;
      
      uint32        IEnvironment_GPSToCam_dz_b11                 : 11U;
      
      uint32        IEnvironment_WheelWidth_b6                   : 6U;
      
      uint32        Reserved_1_b4                                : 4U;
      
      uint32        IEnvironment_WheelRadius_b8                  : 8U;
      
      uint32        IEnvironment_LeftWheel_b16                   : 16U;
      
      uint32        Reserved_2_b8                                : 8U;
      
      uint32        IEnvironment_RightWheel_b16                  : 16U;
      
      uint32        IEnvironment_RefPX_Front_Bumper_b16          : 16U;
      
      uint32        IEnvironment_CamToFrontAxle_b16              : 16U;
      
      uint32        IEnvironment_CamToRearAxle_b16               : 16U;
      
      uint32        IEnvironment_MinHorizon_b16                  : 16U;
      
      uint32        IEnvironment_MaxHorizon_b16                  : 16U;
      
      uint32        IEnvironment_MinYaw_b16                      : 16U;
      
      uint32        IEnvironment_MaxYaw_b16                      : 16U;
      
      uint32        IEnvironment_MaxRoll_b16                     : 16U;
      
      uint32        IEnvironment_Top_Crop_b16                    : 16U;
      
      uint32        IEnvironment_Bottom_Crop_b16                 : 16U;
      
      uint32        Reserved_3_b16                               : 16U;
      
   #endif
} EYEQMSG_ENVINITRL_Params_t;


/*****************************************************************************
                  Exported function prototypes
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_ENVINITRL_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_ENVINITRL_Params_t * pEnvironment_Init_rearCornerLeft - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Environment_Init_rearCornerLeft message 
*    Environment_Init_rearCornerLeft message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Environment_Init_rearCornerLeft message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_ENVINITRL_ParamsApp_MsgDataStruct( EYEQMSG_ENVINITRL_Params_t * pEnvironment_Init_rearCornerLeft );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRL_IEnvironment_Zero_Byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pIEnvironment_Zero_Byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IEnvironment_Zero_Byte
*    IEnvironment_Zero_Byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IEnvironment_Zero_Byte signal value of Environment_Init_rearCornerLeft message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRL_IEnvironment_Zero_Byte( uint8 * pIEnvironment_Zero_Byte );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRL_IEnvironment_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pIEnvironment_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IEnvironment_Protocol_Version
*    IEnvironment_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IEnvironment_Protocol_Version signal value of Environment_Init_rearCornerLeft message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRL_IEnvironment_Protocol_Version( uint8 * pIEnvironment_Protocol_Version );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRL_IEnvironment_Optional_Signals
*
* FUNCTION ARGUMENTS:
*    uint8 * pIEnvironment_Optional_Signals - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IEnvironment_Optional_Signals
*    IEnvironment_Optional_Signals returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IEnvironment_Optional_Signals signal value of Environment_Init_rearCornerLeft message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRL_IEnvironment_Optional_Signals( uint8 * pIEnvironment_Optional_Signals );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRL_IEnvironment_GPSToCam_dx_V
*
* FUNCTION ARGUMENTS:
*    ENVINITRLIEnvironmentGPSToCamDxV * pIEnvironment_GPSToCam_dx_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IEnvironment_GPSToCam_dx_V
*    IEnvironment_GPSToCam_dx_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IEnvironment_GPSToCam_dx_V signal value of Environment_Init_rearCornerLeft message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRL_IEnvironment_GPSToCam_dx_V( ENVINITRLIEnvironmentGPSToCamDxV * pIEnvironment_GPSToCam_dx_V );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRL_IEnvironment_GPSToCam_dx
*
* FUNCTION ARGUMENTS:
*    uint16 * pIEnvironment_GPSToCam_dx - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IEnvironment_GPSToCam_dx
*    IEnvironment_GPSToCam_dx returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IEnvironment_GPSToCam_dx signal value of Environment_Init_rearCornerLeft message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRL_IEnvironment_GPSToCam_dx( uint16 * pIEnvironment_GPSToCam_dx );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRL_IEnvironment_Buffer1_V
*
* FUNCTION ARGUMENTS:
*    boolean * pIEnvironment_Buffer1_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IEnvironment_Buffer1_V
*    IEnvironment_Buffer1_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IEnvironment_Buffer1_V signal value of Environment_Init_rearCornerLeft message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRL_IEnvironment_Buffer1_V( boolean * pIEnvironment_Buffer1_V );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRL_IEnvironment_Buffer1
*
* FUNCTION ARGUMENTS:
*    uint8 * pIEnvironment_Buffer1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IEnvironment_Buffer1
*    IEnvironment_Buffer1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IEnvironment_Buffer1 signal value of Environment_Init_rearCornerLeft message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRL_IEnvironment_Buffer1( uint8 * pIEnvironment_Buffer1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRL_IEnvironment_GPSToCam_dy_V
*
* FUNCTION ARGUMENTS:
*    ENVINITRLIEnvironmentGPSToCamDyV * pIEnvironment_GPSToCam_dy_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IEnvironment_GPSToCam_dy_V
*    IEnvironment_GPSToCam_dy_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IEnvironment_GPSToCam_dy_V signal value of Environment_Init_rearCornerLeft message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRL_IEnvironment_GPSToCam_dy_V( ENVINITRLIEnvironmentGPSToCamDyV * pIEnvironment_GPSToCam_dy_V );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRL_IEnvironment_GPSToCam_dy
*
* FUNCTION ARGUMENTS:
*    uint16 * pIEnvironment_GPSToCam_dy - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IEnvironment_GPSToCam_dy
*    IEnvironment_GPSToCam_dy returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IEnvironment_GPSToCam_dy signal value of Environment_Init_rearCornerLeft message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRL_IEnvironment_GPSToCam_dy( uint16 * pIEnvironment_GPSToCam_dy );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRL_IEnvironment_GPSToCam_dz_V
*
* FUNCTION ARGUMENTS:
*    ENVINITRLIEnvironmentGPSToCamDzV * pIEnvironment_GPSToCam_dz_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IEnvironment_GPSToCam_dz_V
*    IEnvironment_GPSToCam_dz_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IEnvironment_GPSToCam_dz_V signal value of Environment_Init_rearCornerLeft message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRL_IEnvironment_GPSToCam_dz_V( ENVINITRLIEnvironmentGPSToCamDzV * pIEnvironment_GPSToCam_dz_V );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRL_IEnvironment_GPSToCam_dz
*
* FUNCTION ARGUMENTS:
*    uint16 * pIEnvironment_GPSToCam_dz - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IEnvironment_GPSToCam_dz
*    IEnvironment_GPSToCam_dz returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IEnvironment_GPSToCam_dz signal value of Environment_Init_rearCornerLeft message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRL_IEnvironment_GPSToCam_dz( uint16 * pIEnvironment_GPSToCam_dz );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRL_IEnvironment_WheelWidth
*
* FUNCTION ARGUMENTS:
*    uint8 * pIEnvironment_WheelWidth - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IEnvironment_WheelWidth
*    IEnvironment_WheelWidth returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IEnvironment_WheelWidth signal value of Environment_Init_rearCornerLeft message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRL_IEnvironment_WheelWidth( uint8 * pIEnvironment_WheelWidth );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRL_Reserved_1
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1
*    Reserved_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1 signal value of Environment_Init_rearCornerLeft message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRL_Reserved_1( uint8 * pReserved_1 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRL_IEnvironment_WheelRadius
*
* FUNCTION ARGUMENTS:
*    uint8 * pIEnvironment_WheelRadius - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IEnvironment_WheelRadius
*    IEnvironment_WheelRadius returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IEnvironment_WheelRadius signal value of Environment_Init_rearCornerLeft message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRL_IEnvironment_WheelRadius( uint8 * pIEnvironment_WheelRadius );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRL_IEnvironment_LeftWheel
*
* FUNCTION ARGUMENTS:
*    uint16 * pIEnvironment_LeftWheel - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IEnvironment_LeftWheel
*    IEnvironment_LeftWheel returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IEnvironment_LeftWheel signal value of Environment_Init_rearCornerLeft message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRL_IEnvironment_LeftWheel( uint16 * pIEnvironment_LeftWheel );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRL_Reserved_2
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_2
*    Reserved_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_2 signal value of Environment_Init_rearCornerLeft message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRL_Reserved_2( uint8 * pReserved_2 );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRL_IEnvironment_RightWheel
*
* FUNCTION ARGUMENTS:
*    uint16 * pIEnvironment_RightWheel - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IEnvironment_RightWheel
*    IEnvironment_RightWheel returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IEnvironment_RightWheel signal value of Environment_Init_rearCornerLeft message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRL_IEnvironment_RightWheel( uint16 * pIEnvironment_RightWheel );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRL_IEnvironment_RefPX_Front_Bumper
*
* FUNCTION ARGUMENTS:
*    uint16 * pIEnvironment_RefPX_Front_Bumper - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IEnvironment_RefPX_Front_Bumper
*    IEnvironment_RefPX_Front_Bumper returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IEnvironment_RefPX_Front_Bumper signal value of Environment_Init_rearCornerLeft message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRL_IEnvironment_RefPX_Front_Bumper( uint16 * pIEnvironment_RefPX_Front_Bumper );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRL_IEnvironment_CamToFrontAxle
*
* FUNCTION ARGUMENTS:
*    uint16 * pIEnvironment_CamToFrontAxle - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IEnvironment_CamToFrontAxle
*    IEnvironment_CamToFrontAxle returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IEnvironment_CamToFrontAxle signal value of Environment_Init_rearCornerLeft message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRL_IEnvironment_CamToFrontAxle( uint16 * pIEnvironment_CamToFrontAxle );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRL_IEnvironment_CamToRearAxle
*
* FUNCTION ARGUMENTS:
*    uint16 * pIEnvironment_CamToRearAxle - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IEnvironment_CamToRearAxle
*    IEnvironment_CamToRearAxle returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IEnvironment_CamToRearAxle signal value of Environment_Init_rearCornerLeft message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRL_IEnvironment_CamToRearAxle( uint16 * pIEnvironment_CamToRearAxle );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRL_IEnvironment_MinHorizon
*
* FUNCTION ARGUMENTS:
*    uint16 * pIEnvironment_MinHorizon - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IEnvironment_MinHorizon
*    IEnvironment_MinHorizon returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IEnvironment_MinHorizon signal value of Environment_Init_rearCornerLeft message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRL_IEnvironment_MinHorizon( uint16 * pIEnvironment_MinHorizon );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRL_IEnvironment_MaxHorizon
*
* FUNCTION ARGUMENTS:
*    uint16 * pIEnvironment_MaxHorizon - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IEnvironment_MaxHorizon
*    IEnvironment_MaxHorizon returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IEnvironment_MaxHorizon signal value of Environment_Init_rearCornerLeft message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRL_IEnvironment_MaxHorizon( uint16 * pIEnvironment_MaxHorizon );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRL_IEnvironment_MinYaw
*
* FUNCTION ARGUMENTS:
*    uint16 * pIEnvironment_MinYaw - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IEnvironment_MinYaw
*    IEnvironment_MinYaw returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IEnvironment_MinYaw signal value of Environment_Init_rearCornerLeft message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRL_IEnvironment_MinYaw( uint16 * pIEnvironment_MinYaw );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRL_IEnvironment_MaxYaw
*
* FUNCTION ARGUMENTS:
*    uint16 * pIEnvironment_MaxYaw - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IEnvironment_MaxYaw
*    IEnvironment_MaxYaw returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IEnvironment_MaxYaw signal value of Environment_Init_rearCornerLeft message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRL_IEnvironment_MaxYaw( uint16 * pIEnvironment_MaxYaw );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRL_IEnvironment_MaxRoll
*
* FUNCTION ARGUMENTS:
*    uint16 * pIEnvironment_MaxRoll - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IEnvironment_MaxRoll
*    IEnvironment_MaxRoll returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IEnvironment_MaxRoll signal value of Environment_Init_rearCornerLeft message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRL_IEnvironment_MaxRoll( uint16 * pIEnvironment_MaxRoll );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRL_IEnvironment_Top_Crop
*
* FUNCTION ARGUMENTS:
*    uint16 * pIEnvironment_Top_Crop - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IEnvironment_Top_Crop
*    IEnvironment_Top_Crop returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IEnvironment_Top_Crop signal value of Environment_Init_rearCornerLeft message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRL_IEnvironment_Top_Crop( uint16 * pIEnvironment_Top_Crop );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRL_IEnvironment_Bottom_Crop
*
* FUNCTION ARGUMENTS:
*    uint16 * pIEnvironment_Bottom_Crop - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IEnvironment_Bottom_Crop
*    IEnvironment_Bottom_Crop returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IEnvironment_Bottom_Crop signal value of Environment_Init_rearCornerLeft message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRL_IEnvironment_Bottom_Crop( uint16 * pIEnvironment_Bottom_Crop );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRL_Reserved_3
*
* FUNCTION ARGUMENTS:
*    uint16 * pReserved_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_3
*    Reserved_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_3 signal value of Environment_Init_rearCornerLeft message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRL_Reserved_3( uint16 * pReserved_3 );
/*****************************************************************************
                  Exported object declarations
*****************************************************************************/
extern EYEQMSG_ENVINITRL_Params_t   EYEQMSG_ENVINITRL_Params_s;
extern EYEQMSG_ENVINITRL_Params_t   EYEQMSG_ENVINITRL_ParamsApp_s;
/****************************************************************************/
#endif /* _EYEQMSG_ENVINITRLPROCESS_H_ */


