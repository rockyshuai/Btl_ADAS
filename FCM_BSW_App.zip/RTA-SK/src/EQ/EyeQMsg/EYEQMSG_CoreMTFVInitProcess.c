

/*****************************************************************************
                  Include files
*****************************************************************************/
/* The suggested include file order is: */
#include "EyeQ_defs.h"    /* EyeQ project common definitions file    */

#include "EYEQMSG_CoreMTFVInitProcess.h"

/*****************************************************************************
                  Local symbolic constants
*****************************************************************************/
/*****************************************************************************
                  Local types, enums definitions
*****************************************************************************/
/*****************************************************************************
                  Local function prototypes
*****************************************************************************/
/*****************************************************************************
                  Local object definitions
*****************************************************************************/
/*****************************************************************************
                  Exported object definitions
*****************************************************************************/
EYEQMSG_COREMTFVINIT_Params_t   EYEQMSG_COREMTFVINIT_Params_s;
EYEQMSG_COREMTFVINIT_Params_t   EYEQMSG_COREMTFVINIT_ParamsApp_s;
/*****************************************************************************
                  Local function-like macros
*****************************************************************************/
/*****************************************************************************
                  Local defined macros
*****************************************************************************/
/*****************************************************************************
                  Function definitions
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_COREMTFVINIT_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_COREMTFVINIT_Params_t * pCore_MTFV_Init - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_MTFV_Init message 
*    Core_MTFV_Init message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_MTFV_Init message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_COREMTFVINIT_ParamsApp_MsgDataStruct( EYEQMSG_COREMTFVINIT_Params_t * pCore_MTFV_Init )
{
   Std_ReturnType status = C_SIG_INVALID;
   if( pCore_MTFV_Init != C_NULL_P )
   {
      status = C_SIG_VALID;
      * pCore_MTFV_Init = EYEQMSG_COREMTFVINIT_ParamsApp_s;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREMTFVINIT_IMTFV_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pIMTFV_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IMTFV_Zero_byte
*    IMTFV_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IMTFV_Zero_byte signal value of Core_MTFV_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREMTFVINIT_IMTFV_Zero_byte( uint8 * pIMTFV_Zero_byte )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pIMTFV_Zero_byte != C_NULL_P )
   {
      signal_value = EYEQMSG_COREMTFVINIT_ParamsApp_s.IMTFV_Zero_byte_b8;
      * pIMTFV_Zero_byte = signal_value;
      if( signal_value <= C_EYEQMSG_COREMTFVINIT_IMTFV_ZERO_BYTE_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREMTFVINIT_IMTFV_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pIMTFV_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IMTFV_Protocol_Version
*    IMTFV_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IMTFV_Protocol_Version signal value of Core_MTFV_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREMTFVINIT_IMTFV_Protocol_Version( uint8 * pIMTFV_Protocol_Version )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pIMTFV_Protocol_Version != C_NULL_P )
   {
      signal_value = EYEQMSG_COREMTFVINIT_ParamsApp_s.IMTFV_Protocol_Version_b8;
      * pIMTFV_Protocol_Version = signal_value;
      if( (signal_value >= C_EYEQMSG_COREMTFVINIT_IMTFV_PROTOCOL_VERSION_RMIN ) 
          && (signal_value <= C_EYEQMSG_COREMTFVINIT_IMTFV_PROTOCOL_VERSION_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREMTFVINIT_IMTFV_Optional_Signals
*
* FUNCTION ARGUMENTS:
*    uint16 * pIMTFV_Optional_Signals - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IMTFV_Optional_Signals
*    IMTFV_Optional_Signals returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IMTFV_Optional_Signals signal value of Core_MTFV_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREMTFVINIT_IMTFV_Optional_Signals( uint16 * pIMTFV_Optional_Signals )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pIMTFV_Optional_Signals != C_NULL_P )
   {
      signal_value = EYEQMSG_COREMTFVINIT_ParamsApp_s.IMTFV_Optional_Signals_b16;
      * pIMTFV_Optional_Signals = signal_value;
      if( signal_value <= C_EYEQMSG_COREMTFVINIT_IMTFV_OPTIONAL_SIGNALS_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREMTFVINIT_IMTFV_Cmera_Ientity
*
* FUNCTION ARGUMENTS:
*    COREMTFVINITIMTFVCmeraIentity * pIMTFV_Cmera_Ientity - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IMTFV_Cmera_Ientity
*    IMTFV_Cmera_Ientity returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IMTFV_Cmera_Ientity signal value of Core_MTFV_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREMTFVINIT_IMTFV_Cmera_Ientity( COREMTFVINITIMTFVCmeraIentity * pIMTFV_Cmera_Ientity )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREMTFVINITIMTFVCmeraIentity signal_value;
   
   if( pIMTFV_Cmera_Ientity != C_NULL_P )
   {
      signal_value = EYEQMSG_COREMTFVINIT_ParamsApp_s.IMTFV_Cmera_Ientity_b3;
      * pIMTFV_Cmera_Ientity = signal_value;
      if( signal_value <= C_EYEQMSG_COREMTFVINIT_IMTFV_CMERA_IENTITY_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREMTFVINIT_IMTFV_Fixed_Exposure
*
* FUNCTION ARGUMENTS:
*    uint16 * pIMTFV_Fixed_Exposure - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IMTFV_Fixed_Exposure
*    IMTFV_Fixed_Exposure returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IMTFV_Fixed_Exposure signal value of Core_MTFV_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREMTFVINIT_IMTFV_Fixed_Exposure( uint16 * pIMTFV_Fixed_Exposure )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pIMTFV_Fixed_Exposure != C_NULL_P )
   {
      signal_value = EYEQMSG_COREMTFVINIT_ParamsApp_s.IMTFV_Fixed_Exposure_b16;
      * pIMTFV_Fixed_Exposure = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREMTFVINIT_IMTFV_Mode
*
* FUNCTION ARGUMENTS:
*    COREMTFVINITIMTFVMode * pIMTFV_Mode - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IMTFV_Mode
*    IMTFV_Mode returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IMTFV_Mode signal value of Core_MTFV_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREMTFVINIT_IMTFV_Mode( COREMTFVINITIMTFVMode * pIMTFV_Mode )
{
   Std_ReturnType status = C_SIG_INVALID;
   COREMTFVINITIMTFVMode signal_value;
   
   if( pIMTFV_Mode != C_NULL_P )
   {
      signal_value = EYEQMSG_COREMTFVINIT_ParamsApp_s.IMTFV_Mode_b3;
      * pIMTFV_Mode = signal_value;
      if( signal_value <= C_EYEQMSG_COREMTFVINIT_IMTFV_MODE_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREMTFVINIT_Reserved_1
*
* FUNCTION ARGUMENTS:
*    uint16 * pReserved_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1
*    Reserved_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1 signal value of Core_MTFV_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREMTFVINIT_Reserved_1( uint16 * pReserved_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pReserved_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_COREMTFVINIT_ParamsApp_s.Reserved_1_b10;
      * pReserved_1 = signal_value;
      if( signal_value <= C_EYEQMSG_COREMTFVINIT_RESERVED_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

