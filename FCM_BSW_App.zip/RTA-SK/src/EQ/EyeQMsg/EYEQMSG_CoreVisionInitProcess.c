

/*****************************************************************************
                  Include files
*****************************************************************************/
/* The suggested include file order is: */
#include "EyeQ_defs.h"    /* EyeQ project common definitions file    */

#include "EYEQMSG_CoreVisionInitProcess.h"

/*****************************************************************************
                  Local symbolic constants
*****************************************************************************/
/*****************************************************************************
                  Local types, enums definitions
*****************************************************************************/
/*****************************************************************************
                  Local function prototypes
*****************************************************************************/
/*****************************************************************************
                  Local object definitions
*****************************************************************************/
/*****************************************************************************
                  Exported object definitions
*****************************************************************************/
EYEQMSG_COREVISIONINIT_Params_t   EYEQMSG_COREVISIONINIT_Params_s;
EYEQMSG_COREVISIONINIT_Params_t   EYEQMSG_COREVISIONINIT_ParamsApp_s;
/*****************************************************************************
                  Local function-like macros
*****************************************************************************/
/*****************************************************************************
                  Local defined macros
*****************************************************************************/
/*****************************************************************************
                  Function definitions
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_COREVISIONINIT_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_COREVISIONINIT_Params_t * pCore_Vision_Init - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_Vision_Init message 
*    Core_Vision_Init message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_Vision_Init message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_COREVISIONINIT_ParamsApp_MsgDataStruct( EYEQMSG_COREVISIONINIT_Params_t * pCore_Vision_Init )
{
   Std_ReturnType status = C_SIG_INVALID;
   if( pCore_Vision_Init != C_NULL_P )
   {
      status = C_SIG_VALID;
      * pCore_Vision_Init = EYEQMSG_COREVISIONINIT_ParamsApp_s;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREVISIONINIT_IVISION_Zero_Byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pIVISION_Zero_Byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IVISION_Zero_Byte
*    IVISION_Zero_Byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IVISION_Zero_Byte signal value of Core_Vision_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREVISIONINIT_IVISION_Zero_Byte( uint8 * pIVISION_Zero_Byte )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pIVISION_Zero_Byte != C_NULL_P )
   {
      signal_value = EYEQMSG_COREVISIONINIT_ParamsApp_s.IVISION_Zero_Byte_b8;
      * pIVISION_Zero_Byte = signal_value;
      if( signal_value <= C_EYEQMSG_COREVISIONINIT_IVISION_ZERO_BYTE_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREVISIONINIT_IVISION_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pIVISION_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IVISION_Protocol_Version
*    IVISION_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IVISION_Protocol_Version signal value of Core_Vision_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREVISIONINIT_IVISION_Protocol_Version( uint8 * pIVISION_Protocol_Version )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pIVISION_Protocol_Version != C_NULL_P )
   {
      signal_value = EYEQMSG_COREVISIONINIT_ParamsApp_s.IVISION_Protocol_Version_b8;
      * pIVISION_Protocol_Version = signal_value;
      if( (signal_value >= C_EYEQMSG_COREVISIONINIT_IVISION_PROTOCOL_VERSION_RMIN ) 
          && (signal_value <= C_EYEQMSG_COREVISIONINIT_IVISION_PROTOCOL_VERSION_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREVISIONINIT_IVISION_Optional_Signals
*
* FUNCTION ARGUMENTS:
*    uint16 * pIVISION_Optional_Signals - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IVISION_Optional_Signals
*    IVISION_Optional_Signals returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IVISION_Optional_Signals signal value of Core_Vision_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREVISIONINIT_IVISION_Optional_Signals( uint16 * pIVISION_Optional_Signals )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pIVISION_Optional_Signals != C_NULL_P )
   {
      signal_value = EYEQMSG_COREVISIONINIT_ParamsApp_s.IVISION_Optional_Signals_b16;
      * pIVISION_Optional_Signals = signal_value;
      if( signal_value <= C_EYEQMSG_COREVISIONINIT_IVISION_OPTIONAL_SIGNALS_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

