

/*****************************************************************************
                  Include files
*****************************************************************************/
/* The suggested include file order is: */
#include "EyeQ_defs.h"    /* EyeQ project common definitions file    */

#include "EYEQMSG_CoreCalStaticProcess.h"

/*****************************************************************************
                  Local symbolic constants
*****************************************************************************/
/*****************************************************************************
                  Local types, enums definitions
*****************************************************************************/
/*****************************************************************************
                  Local function prototypes
*****************************************************************************/
/*****************************************************************************
                  Local object definitions
*****************************************************************************/
/*****************************************************************************
                  Exported object definitions
*****************************************************************************/
EYEQMSG_CORECALSTATIC_Params_t   EYEQMSG_CORECALSTATIC_Params_s;
EYEQMSG_CORECALSTATIC_Params_t   EYEQMSG_CORECALSTATIC_ParamsApp_s;
/*****************************************************************************
                  Local function-like macros
*****************************************************************************/
/*****************************************************************************
                  Local defined macros
*****************************************************************************/
/*****************************************************************************
                  Function definitions
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_CORECALSTATIC_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_CORECALSTATIC_Params_t * pCore_Calibration_Static_protocol - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_Calibration_Static_protocol message 
*    Core_Calibration_Static_protocol message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_Calibration_Static_protocol message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_CORECALSTATIC_ParamsApp_MsgDataStruct( EYEQMSG_CORECALSTATIC_Params_t * pCore_Calibration_Static_protocol )
{
   Std_ReturnType status = C_SIG_INVALID;
   if( pCore_Calibration_Static_protocol != C_NULL_P )
   {
      status = C_SIG_VALID;
      * pCore_Calibration_Static_protocol = EYEQMSG_CORECALSTATIC_ParamsApp_s;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSTATIC_CLB_Stat_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pCLB_Stat_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_Stat_Zero_byte
*    CLB_Stat_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_Stat_Zero_byte signal value of Core_Calibration_Static_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSTATIC_CLB_Stat_Zero_byte( uint8 * pCLB_Stat_Zero_byte )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pCLB_Stat_Zero_byte != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECALSTATIC_ParamsApp_s.CLB_Stat_Zero_byte_b8;
      * pCLB_Stat_Zero_byte = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSTATIC_Reserved_1
*
* FUNCTION ARGUMENTS:
*    uint32 * pReserved_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1
*    Reserved_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1 signal value of Core_Calibration_Static_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSTATIC_Reserved_1( uint32 * pReserved_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pReserved_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECALSTATIC_ParamsApp_s.Reserved_1_b24;
      * pReserved_1 = signal_value;
      if( signal_value <= C_EYEQMSG_CORECALSTATIC_RESERVED_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSTATIC_CLB_Stat_CRC
*
* FUNCTION ARGUMENTS:
*    uint32 * pCLB_Stat_CRC - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_Stat_CRC
*    CLB_Stat_CRC returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_Stat_CRC signal value of Core_Calibration_Static_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSTATIC_CLB_Stat_CRC( uint32 * pCLB_Stat_CRC )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint32 signal_value;
   
   if( pCLB_Stat_CRC != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECALSTATIC_ParamsApp_s.CLB_Stat_CRC_b32;
      * pCLB_Stat_CRC = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSTATIC_CLB_Stat_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pCLB_Stat_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_Stat_Protocol_Version
*    CLB_Stat_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_Stat_Protocol_Version signal value of Core_Calibration_Static_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSTATIC_CLB_Stat_Protocol_Version( uint8 * pCLB_Stat_Protocol_Version )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pCLB_Stat_Protocol_Version != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECALSTATIC_ParamsApp_s.CLB_Stat_Protocol_Version_b8;
      * pCLB_Stat_Protocol_Version = signal_value;
      if( (signal_value >= C_EYEQMSG_CORECALSTATIC_CLB_STAT_PROTOCOL_VERSION_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORECALSTATIC_CLB_STAT_PROTOCOL_VERSION_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSTATIC_CLB_Sync_ID
*
* FUNCTION ARGUMENTS:
*    uint8 * pCLB_Sync_ID - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_Sync_ID
*    CLB_Sync_ID returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_Sync_ID signal value of Core_Calibration_Static_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSTATIC_CLB_Sync_ID( uint8 * pCLB_Sync_ID )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pCLB_Sync_ID != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECALSTATIC_ParamsApp_s.CLB_Sync_ID_b8;
      * pCLB_Sync_ID = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSTATIC_CLB_Stat_Run_Mode
*
* FUNCTION ARGUMENTS:
*    CORECALSTATICCLBStatRunMode * pCLB_Stat_Run_Mode - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_Stat_Run_Mode
*    CLB_Stat_Run_Mode returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_Stat_Run_Mode signal value of Core_Calibration_Static_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSTATIC_CLB_Stat_Run_Mode( CORECALSTATICCLBStatRunMode * pCLB_Stat_Run_Mode )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECALSTATICCLBStatRunMode signal_value;
   
   if( pCLB_Stat_Run_Mode != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECALSTATIC_ParamsApp_s.CLB_Stat_Run_Mode_b3;
      * pCLB_Stat_Run_Mode = signal_value;
      if( signal_value <= C_EYEQMSG_CORECALSTATIC_CLB_STAT_RUN_MODE_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSTATIC_CLB_Stat_Progress
*
* FUNCTION ARGUMENTS:
*    CORECALSTATICCLBStatProgress * pCLB_Stat_Progress - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_Stat_Progress
*    CLB_Stat_Progress returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_Stat_Progress signal value of Core_Calibration_Static_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSTATIC_CLB_Stat_Progress( CORECALSTATICCLBStatProgress * pCLB_Stat_Progress )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECALSTATICCLBStatProgress signal_value;
   
   if( pCLB_Stat_Progress != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECALSTATIC_ParamsApp_s.CLB_Stat_Progress_b7;
      * pCLB_Stat_Progress = signal_value;
      if( signal_value <= C_EYEQMSG_CORECALSTATIC_CLB_STAT_PROGRESS_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSTATIC_CLB_Stat_Error
*
* FUNCTION ARGUMENTS:
*    uint8 * pCLB_Stat_Error - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_Stat_Error
*    CLB_Stat_Error returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_Stat_Error signal value of Core_Calibration_Static_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSTATIC_CLB_Stat_Error( uint8 * pCLB_Stat_Error )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pCLB_Stat_Error != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECALSTATIC_ParamsApp_s.CLB_Stat_Error_b4;
      * pCLB_Stat_Error = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSTATIC_CLB_Stat_Header_Buffer
*
* FUNCTION ARGUMENTS:
*    uint8 * pCLB_Stat_Header_Buffer - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_Stat_Header_Buffer
*    CLB_Stat_Header_Buffer returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_Stat_Header_Buffer signal value of Core_Calibration_Static_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSTATIC_CLB_Stat_Header_Buffer( uint8 * pCLB_Stat_Header_Buffer )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pCLB_Stat_Header_Buffer != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECALSTATIC_ParamsApp_s.CLB_Stat_Header_Buffer_b2;
      * pCLB_Stat_Header_Buffer = signal_value;
      if( signal_value <= C_EYEQMSG_CORECALSTATIC_CLB_STAT_HEADER_BUFFER_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSTATIC_CLB_Stat_PH_Yaw
*
* FUNCTION ARGUMENTS:
*    float32 * pCLB_Stat_PH_Yaw - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_Stat_PH_Yaw
*    CLB_Stat_PH_Yaw returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_Stat_PH_Yaw signal value of Core_Calibration_Static_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSTATIC_CLB_Stat_PH_Yaw( float32 * pCLB_Stat_PH_Yaw )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float32SigDataType signal_value;
   
   if( pCLB_Stat_PH_Yaw != C_NULL_P )
   {
      signal_value.u = EYEQMSG_CORECALSTATIC_ParamsApp_s.CLB_Stat_PH_Yaw_sb32;
      * pCLB_Stat_PH_Yaw = signal_value.f;
      if( (signal_value.f >= C_EYEQMSG_CORECALSTATIC_CLB_STAT_PH_YAW_RMIN ) 
          && (signal_value.f <= C_EYEQMSG_CORECALSTATIC_CLB_STAT_PH_YAW_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSTATIC_CLB_Stat_PH_Pitch
*
* FUNCTION ARGUMENTS:
*    float32 * pCLB_Stat_PH_Pitch - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_Stat_PH_Pitch
*    CLB_Stat_PH_Pitch returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_Stat_PH_Pitch signal value of Core_Calibration_Static_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSTATIC_CLB_Stat_PH_Pitch( float32 * pCLB_Stat_PH_Pitch )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float32SigDataType signal_value;
   
   if( pCLB_Stat_PH_Pitch != C_NULL_P )
   {
      signal_value.u = EYEQMSG_CORECALSTATIC_ParamsApp_s.CLB_Stat_PH_Pitch_sb32;
      * pCLB_Stat_PH_Pitch = signal_value.f;
      if( (signal_value.f >= C_EYEQMSG_CORECALSTATIC_CLB_STAT_PH_PITCH_RMIN ) 
          && (signal_value.f <= C_EYEQMSG_CORECALSTATIC_CLB_STAT_PH_PITCH_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSTATIC_CLB_Stat_DIST_Yaw
*
* FUNCTION ARGUMENTS:
*    uint16 * pCLB_Stat_DIST_Yaw - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_Stat_DIST_Yaw
*    CLB_Stat_DIST_Yaw returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_Stat_DIST_Yaw signal value of Core_Calibration_Static_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSTATIC_CLB_Stat_DIST_Yaw( uint16 * pCLB_Stat_DIST_Yaw )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pCLB_Stat_DIST_Yaw != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECALSTATIC_ParamsApp_s.CLB_Stat_DIST_Yaw_b10;
      * pCLB_Stat_DIST_Yaw = signal_value;
      if( signal_value <= C_EYEQMSG_CORECALSTATIC_CLB_STAT_DIST_YAW_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSTATIC_CLB_Stat_DIST_Pitch
*
* FUNCTION ARGUMENTS:
*    uint16 * pCLB_Stat_DIST_Pitch - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_Stat_DIST_Pitch
*    CLB_Stat_DIST_Pitch returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_Stat_DIST_Pitch signal value of Core_Calibration_Static_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSTATIC_CLB_Stat_DIST_Pitch( uint16 * pCLB_Stat_DIST_Pitch )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pCLB_Stat_DIST_Pitch != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECALSTATIC_ParamsApp_s.CLB_Stat_DIST_Pitch_b10;
      * pCLB_Stat_DIST_Pitch = signal_value;
      if( signal_value <= C_EYEQMSG_CORECALSTATIC_CLB_STAT_DIST_PITCH_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSTATIC_Reserved_2
*
* FUNCTION ARGUMENTS:
*    uint16 * pReserved_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_2
*    Reserved_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_2 signal value of Core_Calibration_Static_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSTATIC_Reserved_2( uint16 * pReserved_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pReserved_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECALSTATIC_ParamsApp_s.Reserved_2_b12;
      * pReserved_2 = signal_value;
      if( signal_value <= C_EYEQMSG_CORECALSTATIC_RESERVED_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSTATIC_CLB_Stat_Roll
*
* FUNCTION ARGUMENTS:
*    float32 * pCLB_Stat_Roll - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_Stat_Roll
*    CLB_Stat_Roll returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_Stat_Roll signal value of Core_Calibration_Static_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSTATIC_CLB_Stat_Roll( float32 * pCLB_Stat_Roll )
{
   Std_ReturnType status = C_SIG_INVALID;
   Std_Float32SigDataType signal_value;
   
   if( pCLB_Stat_Roll != C_NULL_P )
   {
      signal_value.u = EYEQMSG_CORECALSTATIC_ParamsApp_s.CLB_Stat_Roll_sb32;
      * pCLB_Stat_Roll = signal_value.f;
      if( (signal_value.f >= C_EYEQMSG_CORECALSTATIC_CLB_STAT_ROLL_RMIN ) 
          && (signal_value.f <= C_EYEQMSG_CORECALSTATIC_CLB_STAT_ROLL_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSTATIC_CLB_Stat_CAM_Height
*
* FUNCTION ARGUMENTS:
*    uint16 * pCLB_Stat_CAM_Height - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_Stat_CAM_Height
*    CLB_Stat_CAM_Height returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_Stat_CAM_Height signal value of Core_Calibration_Static_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSTATIC_CLB_Stat_CAM_Height( uint16 * pCLB_Stat_CAM_Height )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pCLB_Stat_CAM_Height != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECALSTATIC_ParamsApp_s.CLB_Stat_CAM_Height_b16;
      * pCLB_Stat_CAM_Height = signal_value;
      if( (signal_value >= C_EYEQMSG_CORECALSTATIC_CLB_STAT_CAM_HEIGHT_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORECALSTATIC_CLB_STAT_CAM_HEIGHT_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSTATIC_CLB_Recorder_Status
*
* FUNCTION ARGUMENTS:
*    CORECALSTATICCLBRecorderStatus * pCLB_Recorder_Status - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_Recorder_Status
*    CLB_Recorder_Status returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_Recorder_Status signal value of Core_Calibration_Static_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSTATIC_CLB_Recorder_Status( CORECALSTATICCLBRecorderStatus * pCLB_Recorder_Status )
{
   Std_ReturnType status = C_SIG_INVALID;
   CORECALSTATICCLBRecorderStatus signal_value;
   
   if( pCLB_Recorder_Status != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECALSTATIC_ParamsApp_s.CLB_Recorder_Status_b3;
      * pCLB_Recorder_Status = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORECALSTATIC_CLB_Stat_Buffer
*
* FUNCTION ARGUMENTS:
*    uint16 * pCLB_Stat_Buffer - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of CLB_Stat_Buffer
*    CLB_Stat_Buffer returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns CLB_Stat_Buffer signal value of Core_Calibration_Static_protocol message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORECALSTATIC_CLB_Stat_Buffer( uint16 * pCLB_Stat_Buffer )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pCLB_Stat_Buffer != C_NULL_P )
   {
      signal_value = EYEQMSG_CORECALSTATIC_ParamsApp_s.CLB_Stat_Buffer_b13;
      * pCLB_Stat_Buffer = signal_value;
      if( signal_value <= C_EYEQMSG_CORECALSTATIC_CLB_STAT_BUFFER_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

