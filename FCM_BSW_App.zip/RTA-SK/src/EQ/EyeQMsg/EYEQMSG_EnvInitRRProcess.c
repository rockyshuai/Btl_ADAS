

/*****************************************************************************
                  Include files
*****************************************************************************/
/* The suggested include file order is: */
#include "EyeQ_defs.h"    /* EyeQ project common definitions file    */

#include "EYEQMSG_EnvInitRRProcess.h"

/*****************************************************************************
                  Local symbolic constants
*****************************************************************************/
/*****************************************************************************
                  Local types, enums definitions
*****************************************************************************/
/*****************************************************************************
                  Local function prototypes
*****************************************************************************/
/*****************************************************************************
                  Local object definitions
*****************************************************************************/
/*****************************************************************************
                  Exported object definitions
*****************************************************************************/
EYEQMSG_ENVINITRR_Params_t   EYEQMSG_ENVINITRR_Params_s;
EYEQMSG_ENVINITRR_Params_t   EYEQMSG_ENVINITRR_ParamsApp_s;
/*****************************************************************************
                  Local function-like macros
*****************************************************************************/
/*****************************************************************************
                  Local defined macros
*****************************************************************************/
/*****************************************************************************
                  Function definitions
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_ENVINITRR_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_ENVINITRR_Params_t * pEnvironment_Init_rearCornerRight - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Environment_Init_rearCornerRight message 
*    Environment_Init_rearCornerRight message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Environment_Init_rearCornerRight message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_ENVINITRR_ParamsApp_MsgDataStruct( EYEQMSG_ENVINITRR_Params_t * pEnvironment_Init_rearCornerRight )
{
   Std_ReturnType status = C_SIG_INVALID;
   if( pEnvironment_Init_rearCornerRight != C_NULL_P )
   {
      status = C_SIG_VALID;
      * pEnvironment_Init_rearCornerRight = EYEQMSG_ENVINITRR_ParamsApp_s;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRR_IEnvironment_Zero_Byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pIEnvironment_Zero_Byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IEnvironment_Zero_Byte
*    IEnvironment_Zero_Byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IEnvironment_Zero_Byte signal value of Environment_Init_rearCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRR_IEnvironment_Zero_Byte( uint8 * pIEnvironment_Zero_Byte )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pIEnvironment_Zero_Byte != C_NULL_P )
   {
      signal_value = EYEQMSG_ENVINITRR_ParamsApp_s.IEnvironment_Zero_Byte_b8;
      * pIEnvironment_Zero_Byte = signal_value;
      if( signal_value <= C_EYEQMSG_ENVINITRR_IENVIRONMENT_ZERO_BYTE_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRR_IEnvironment_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pIEnvironment_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IEnvironment_Protocol_Version
*    IEnvironment_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IEnvironment_Protocol_Version signal value of Environment_Init_rearCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRR_IEnvironment_Protocol_Version( uint8 * pIEnvironment_Protocol_Version )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pIEnvironment_Protocol_Version != C_NULL_P )
   {
      signal_value = EYEQMSG_ENVINITRR_ParamsApp_s.IEnvironment_Protocol_Version_b8;
      * pIEnvironment_Protocol_Version = signal_value;
      if( (signal_value >= C_EYEQMSG_ENVINITRR_IENVIRONMENT_PROTOCOL_VERSION_RMIN ) 
          && (signal_value <= C_EYEQMSG_ENVINITRR_IENVIRONMENT_PROTOCOL_VERSION_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRR_IEnvironment_Optional_Signals
*
* FUNCTION ARGUMENTS:
*    uint8 * pIEnvironment_Optional_Signals - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IEnvironment_Optional_Signals
*    IEnvironment_Optional_Signals returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IEnvironment_Optional_Signals signal value of Environment_Init_rearCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRR_IEnvironment_Optional_Signals( uint8 * pIEnvironment_Optional_Signals )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pIEnvironment_Optional_Signals != C_NULL_P )
   {
      signal_value = EYEQMSG_ENVINITRR_ParamsApp_s.IEnvironment_Optional_Signals_b3;
      * pIEnvironment_Optional_Signals = signal_value;
      if( (signal_value >= C_EYEQMSG_ENVINITRR_IENVIRONMENT_OPTIONAL_SIGNALS_RMIN ) 
          && (signal_value <= C_EYEQMSG_ENVINITRR_IENVIRONMENT_OPTIONAL_SIGNALS_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRR_IEnvironment_GPSToCam_dx_V
*
* FUNCTION ARGUMENTS:
*    ENVINITRRIEnvironmentGPSToCamDxV * pIEnvironment_GPSToCam_dx_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IEnvironment_GPSToCam_dx_V
*    IEnvironment_GPSToCam_dx_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IEnvironment_GPSToCam_dx_V signal value of Environment_Init_rearCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRR_IEnvironment_GPSToCam_dx_V( ENVINITRRIEnvironmentGPSToCamDxV * pIEnvironment_GPSToCam_dx_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   ENVINITRRIEnvironmentGPSToCamDxV signal_value;
   
   if( pIEnvironment_GPSToCam_dx_V != C_NULL_P )
   {
      signal_value = EYEQMSG_ENVINITRR_ParamsApp_s.IEnvironment_GPSToCam_dx_V_b1;
      * pIEnvironment_GPSToCam_dx_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRR_IEnvironment_GPSToCam_dx
*
* FUNCTION ARGUMENTS:
*    uint16 * pIEnvironment_GPSToCam_dx - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IEnvironment_GPSToCam_dx
*    IEnvironment_GPSToCam_dx returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IEnvironment_GPSToCam_dx signal value of Environment_Init_rearCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRR_IEnvironment_GPSToCam_dx( uint16 * pIEnvironment_GPSToCam_dx )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pIEnvironment_GPSToCam_dx != C_NULL_P )
   {
      signal_value = EYEQMSG_ENVINITRR_ParamsApp_s.IEnvironment_GPSToCam_dx_b9;
      * pIEnvironment_GPSToCam_dx = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRR_IEnvironment_Buffer1_V
*
* FUNCTION ARGUMENTS:
*    boolean * pIEnvironment_Buffer1_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IEnvironment_Buffer1_V
*    IEnvironment_Buffer1_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IEnvironment_Buffer1_V signal value of Environment_Init_rearCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRR_IEnvironment_Buffer1_V( boolean * pIEnvironment_Buffer1_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   boolean signal_value;
   
   if( pIEnvironment_Buffer1_V != C_NULL_P )
   {
      signal_value = EYEQMSG_ENVINITRR_ParamsApp_s.IEnvironment_Buffer1_V_b1;
      * pIEnvironment_Buffer1_V = signal_value;
      if( signal_value <= C_EYEQMSG_ENVINITRR_IENVIRONMENT_BUFFER1_V_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRR_IEnvironment_Buffer1
*
* FUNCTION ARGUMENTS:
*    uint8 * pIEnvironment_Buffer1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IEnvironment_Buffer1
*    IEnvironment_Buffer1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IEnvironment_Buffer1 signal value of Environment_Init_rearCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRR_IEnvironment_Buffer1( uint8 * pIEnvironment_Buffer1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pIEnvironment_Buffer1 != C_NULL_P )
   {
      signal_value = EYEQMSG_ENVINITRR_ParamsApp_s.IEnvironment_Buffer1_b2;
      * pIEnvironment_Buffer1 = signal_value;
      if( signal_value <= C_EYEQMSG_ENVINITRR_IENVIRONMENT_BUFFER1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRR_IEnvironment_GPSToCam_dy_V
*
* FUNCTION ARGUMENTS:
*    ENVINITRRIEnvironmentGPSToCamDyV * pIEnvironment_GPSToCam_dy_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IEnvironment_GPSToCam_dy_V
*    IEnvironment_GPSToCam_dy_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IEnvironment_GPSToCam_dy_V signal value of Environment_Init_rearCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRR_IEnvironment_GPSToCam_dy_V( ENVINITRRIEnvironmentGPSToCamDyV * pIEnvironment_GPSToCam_dy_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   ENVINITRRIEnvironmentGPSToCamDyV signal_value;
   
   if( pIEnvironment_GPSToCam_dy_V != C_NULL_P )
   {
      signal_value = EYEQMSG_ENVINITRR_ParamsApp_s.IEnvironment_GPSToCam_dy_V_b1;
      * pIEnvironment_GPSToCam_dy_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRR_IEnvironment_GPSToCam_dy
*
* FUNCTION ARGUMENTS:
*    uint16 * pIEnvironment_GPSToCam_dy - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IEnvironment_GPSToCam_dy
*    IEnvironment_GPSToCam_dy returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IEnvironment_GPSToCam_dy signal value of Environment_Init_rearCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRR_IEnvironment_GPSToCam_dy( uint16 * pIEnvironment_GPSToCam_dy )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pIEnvironment_GPSToCam_dy != C_NULL_P )
   {
      signal_value = EYEQMSG_ENVINITRR_ParamsApp_s.IEnvironment_GPSToCam_dy_b9;
      * pIEnvironment_GPSToCam_dy = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRR_IEnvironment_GPSToCam_dz_V
*
* FUNCTION ARGUMENTS:
*    ENVINITRRIEnvironmentGPSToCamDzV * pIEnvironment_GPSToCam_dz_V - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IEnvironment_GPSToCam_dz_V
*    IEnvironment_GPSToCam_dz_V returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IEnvironment_GPSToCam_dz_V signal value of Environment_Init_rearCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRR_IEnvironment_GPSToCam_dz_V( ENVINITRRIEnvironmentGPSToCamDzV * pIEnvironment_GPSToCam_dz_V )
{
   Std_ReturnType status = C_SIG_INVALID;
   ENVINITRRIEnvironmentGPSToCamDzV signal_value;
   
   if( pIEnvironment_GPSToCam_dz_V != C_NULL_P )
   {
      signal_value = EYEQMSG_ENVINITRR_ParamsApp_s.IEnvironment_GPSToCam_dz_V_b1;
      * pIEnvironment_GPSToCam_dz_V = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRR_IEnvironment_GPSToCam_dz
*
* FUNCTION ARGUMENTS:
*    uint16 * pIEnvironment_GPSToCam_dz - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IEnvironment_GPSToCam_dz
*    IEnvironment_GPSToCam_dz returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IEnvironment_GPSToCam_dz signal value of Environment_Init_rearCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRR_IEnvironment_GPSToCam_dz( uint16 * pIEnvironment_GPSToCam_dz )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pIEnvironment_GPSToCam_dz != C_NULL_P )
   {
      signal_value = EYEQMSG_ENVINITRR_ParamsApp_s.IEnvironment_GPSToCam_dz_b11;
      * pIEnvironment_GPSToCam_dz = signal_value;
      status = C_SIG_VALID;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRR_IEnvironment_WheelWidth
*
* FUNCTION ARGUMENTS:
*    uint8 * pIEnvironment_WheelWidth - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IEnvironment_WheelWidth
*    IEnvironment_WheelWidth returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IEnvironment_WheelWidth signal value of Environment_Init_rearCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRR_IEnvironment_WheelWidth( uint8 * pIEnvironment_WheelWidth )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pIEnvironment_WheelWidth != C_NULL_P )
   {
      signal_value = EYEQMSG_ENVINITRR_ParamsApp_s.IEnvironment_WheelWidth_b6;
      * pIEnvironment_WheelWidth = signal_value;
      if( signal_value <= C_EYEQMSG_ENVINITRR_IENVIRONMENT_WHEELWIDTH_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRR_Reserved_1
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_1 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_1
*    Reserved_1 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_1 signal value of Environment_Init_rearCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRR_Reserved_1( uint8 * pReserved_1 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pReserved_1 != C_NULL_P )
   {
      signal_value = EYEQMSG_ENVINITRR_ParamsApp_s.Reserved_1_b4;
      * pReserved_1 = signal_value;
      if( signal_value <= C_EYEQMSG_ENVINITRR_RESERVED_1_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRR_IEnvironment_WheelRadius
*
* FUNCTION ARGUMENTS:
*    uint8 * pIEnvironment_WheelRadius - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IEnvironment_WheelRadius
*    IEnvironment_WheelRadius returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IEnvironment_WheelRadius signal value of Environment_Init_rearCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRR_IEnvironment_WheelRadius( uint8 * pIEnvironment_WheelRadius )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pIEnvironment_WheelRadius != C_NULL_P )
   {
      signal_value = EYEQMSG_ENVINITRR_ParamsApp_s.IEnvironment_WheelRadius_b8;
      * pIEnvironment_WheelRadius = signal_value;
      if( signal_value <= C_EYEQMSG_ENVINITRR_IENVIRONMENT_WHEELRADIUS_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRR_IEnvironment_LeftWheel
*
* FUNCTION ARGUMENTS:
*    uint16 * pIEnvironment_LeftWheel - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IEnvironment_LeftWheel
*    IEnvironment_LeftWheel returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IEnvironment_LeftWheel signal value of Environment_Init_rearCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRR_IEnvironment_LeftWheel( uint16 * pIEnvironment_LeftWheel )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pIEnvironment_LeftWheel != C_NULL_P )
   {
      signal_value = EYEQMSG_ENVINITRR_ParamsApp_s.IEnvironment_LeftWheel_b16;
      * pIEnvironment_LeftWheel = signal_value;
      if( (signal_value >= C_EYEQMSG_ENVINITRR_IENVIRONMENT_LEFTWHEEL_RMIN ) 
          && (signal_value <= C_EYEQMSG_ENVINITRR_IENVIRONMENT_LEFTWHEEL_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRR_Reserved_2
*
* FUNCTION ARGUMENTS:
*    uint8 * pReserved_2 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_2
*    Reserved_2 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_2 signal value of Environment_Init_rearCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRR_Reserved_2( uint8 * pReserved_2 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pReserved_2 != C_NULL_P )
   {
      signal_value = EYEQMSG_ENVINITRR_ParamsApp_s.Reserved_2_b8;
      * pReserved_2 = signal_value;
      if( signal_value <= C_EYEQMSG_ENVINITRR_RESERVED_2_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRR_IEnvironment_RightWheel
*
* FUNCTION ARGUMENTS:
*    uint16 * pIEnvironment_RightWheel - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IEnvironment_RightWheel
*    IEnvironment_RightWheel returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IEnvironment_RightWheel signal value of Environment_Init_rearCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRR_IEnvironment_RightWheel( uint16 * pIEnvironment_RightWheel )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pIEnvironment_RightWheel != C_NULL_P )
   {
      signal_value = EYEQMSG_ENVINITRR_ParamsApp_s.IEnvironment_RightWheel_b16;
      * pIEnvironment_RightWheel = signal_value;
      if( (signal_value >= C_EYEQMSG_ENVINITRR_IENVIRONMENT_RIGHTWHEEL_RMIN ) 
          && (signal_value <= C_EYEQMSG_ENVINITRR_IENVIRONMENT_RIGHTWHEEL_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRR_IEnvironment_RefPX_Front_Bumper
*
* FUNCTION ARGUMENTS:
*    uint16 * pIEnvironment_RefPX_Front_Bumper - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IEnvironment_RefPX_Front_Bumper
*    IEnvironment_RefPX_Front_Bumper returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IEnvironment_RefPX_Front_Bumper signal value of Environment_Init_rearCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRR_IEnvironment_RefPX_Front_Bumper( uint16 * pIEnvironment_RefPX_Front_Bumper )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pIEnvironment_RefPX_Front_Bumper != C_NULL_P )
   {
      signal_value = EYEQMSG_ENVINITRR_ParamsApp_s.IEnvironment_RefPX_Front_Bumper_b16;
      * pIEnvironment_RefPX_Front_Bumper = signal_value;
      if( signal_value <= C_EYEQMSG_ENVINITRR_IENVIRONMENT_REFPX_FRONT_BUMPER_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRR_IEnvironment_CamToFrontAxle
*
* FUNCTION ARGUMENTS:
*    uint16 * pIEnvironment_CamToFrontAxle - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IEnvironment_CamToFrontAxle
*    IEnvironment_CamToFrontAxle returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IEnvironment_CamToFrontAxle signal value of Environment_Init_rearCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRR_IEnvironment_CamToFrontAxle( uint16 * pIEnvironment_CamToFrontAxle )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pIEnvironment_CamToFrontAxle != C_NULL_P )
   {
      signal_value = EYEQMSG_ENVINITRR_ParamsApp_s.IEnvironment_CamToFrontAxle_b16;
      * pIEnvironment_CamToFrontAxle = signal_value;
      if( signal_value <= C_EYEQMSG_ENVINITRR_IENVIRONMENT_CAMTOFRONTAXLE_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRR_IEnvironment_CamToRearAxle
*
* FUNCTION ARGUMENTS:
*    uint16 * pIEnvironment_CamToRearAxle - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IEnvironment_CamToRearAxle
*    IEnvironment_CamToRearAxle returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IEnvironment_CamToRearAxle signal value of Environment_Init_rearCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRR_IEnvironment_CamToRearAxle( uint16 * pIEnvironment_CamToRearAxle )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pIEnvironment_CamToRearAxle != C_NULL_P )
   {
      signal_value = EYEQMSG_ENVINITRR_ParamsApp_s.IEnvironment_CamToRearAxle_b16;
      * pIEnvironment_CamToRearAxle = signal_value;
      if( signal_value <= C_EYEQMSG_ENVINITRR_IENVIRONMENT_CAMTOREARAXLE_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRR_IEnvironment_MinHorizon
*
* FUNCTION ARGUMENTS:
*    uint16 * pIEnvironment_MinHorizon - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IEnvironment_MinHorizon
*    IEnvironment_MinHorizon returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IEnvironment_MinHorizon signal value of Environment_Init_rearCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRR_IEnvironment_MinHorizon( uint16 * pIEnvironment_MinHorizon )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pIEnvironment_MinHorizon != C_NULL_P )
   {
      signal_value = EYEQMSG_ENVINITRR_ParamsApp_s.IEnvironment_MinHorizon_b16;
      * pIEnvironment_MinHorizon = signal_value;
      if( signal_value <= C_EYEQMSG_ENVINITRR_IENVIRONMENT_MINHORIZON_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRR_IEnvironment_MaxHorizon
*
* FUNCTION ARGUMENTS:
*    uint16 * pIEnvironment_MaxHorizon - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IEnvironment_MaxHorizon
*    IEnvironment_MaxHorizon returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IEnvironment_MaxHorizon signal value of Environment_Init_rearCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRR_IEnvironment_MaxHorizon( uint16 * pIEnvironment_MaxHorizon )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pIEnvironment_MaxHorizon != C_NULL_P )
   {
      signal_value = EYEQMSG_ENVINITRR_ParamsApp_s.IEnvironment_MaxHorizon_b16;
      * pIEnvironment_MaxHorizon = signal_value;
      if( signal_value <= C_EYEQMSG_ENVINITRR_IENVIRONMENT_MAXHORIZON_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRR_IEnvironment_MinYaw
*
* FUNCTION ARGUMENTS:
*    uint16 * pIEnvironment_MinYaw - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IEnvironment_MinYaw
*    IEnvironment_MinYaw returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IEnvironment_MinYaw signal value of Environment_Init_rearCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRR_IEnvironment_MinYaw( uint16 * pIEnvironment_MinYaw )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pIEnvironment_MinYaw != C_NULL_P )
   {
      signal_value = EYEQMSG_ENVINITRR_ParamsApp_s.IEnvironment_MinYaw_b16;
      * pIEnvironment_MinYaw = signal_value;
      if( signal_value <= C_EYEQMSG_ENVINITRR_IENVIRONMENT_MINYAW_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRR_IEnvironment_MaxYaw
*
* FUNCTION ARGUMENTS:
*    uint16 * pIEnvironment_MaxYaw - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IEnvironment_MaxYaw
*    IEnvironment_MaxYaw returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IEnvironment_MaxYaw signal value of Environment_Init_rearCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRR_IEnvironment_MaxYaw( uint16 * pIEnvironment_MaxYaw )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pIEnvironment_MaxYaw != C_NULL_P )
   {
      signal_value = EYEQMSG_ENVINITRR_ParamsApp_s.IEnvironment_MaxYaw_b16;
      * pIEnvironment_MaxYaw = signal_value;
      if( signal_value <= C_EYEQMSG_ENVINITRR_IENVIRONMENT_MAXYAW_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRR_IEnvironment_MaxRoll
*
* FUNCTION ARGUMENTS:
*    uint16 * pIEnvironment_MaxRoll - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IEnvironment_MaxRoll
*    IEnvironment_MaxRoll returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IEnvironment_MaxRoll signal value of Environment_Init_rearCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRR_IEnvironment_MaxRoll( uint16 * pIEnvironment_MaxRoll )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pIEnvironment_MaxRoll != C_NULL_P )
   {
      signal_value = EYEQMSG_ENVINITRR_ParamsApp_s.IEnvironment_MaxRoll_b16;
      * pIEnvironment_MaxRoll = signal_value;
      if( signal_value <= C_EYEQMSG_ENVINITRR_IENVIRONMENT_MAXROLL_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRR_IEnvironment_Top_Crop
*
* FUNCTION ARGUMENTS:
*    uint16 * pIEnvironment_Top_Crop - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IEnvironment_Top_Crop
*    IEnvironment_Top_Crop returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IEnvironment_Top_Crop signal value of Environment_Init_rearCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRR_IEnvironment_Top_Crop( uint16 * pIEnvironment_Top_Crop )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pIEnvironment_Top_Crop != C_NULL_P )
   {
      signal_value = EYEQMSG_ENVINITRR_ParamsApp_s.IEnvironment_Top_Crop_b16;
      * pIEnvironment_Top_Crop = signal_value;
      if( (signal_value >= C_EYEQMSG_ENVINITRR_IENVIRONMENT_TOP_CROP_RMIN ) 
          && (signal_value <= C_EYEQMSG_ENVINITRR_IENVIRONMENT_TOP_CROP_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRR_IEnvironment_Bottom_Crop
*
* FUNCTION ARGUMENTS:
*    uint16 * pIEnvironment_Bottom_Crop - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IEnvironment_Bottom_Crop
*    IEnvironment_Bottom_Crop returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IEnvironment_Bottom_Crop signal value of Environment_Init_rearCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRR_IEnvironment_Bottom_Crop( uint16 * pIEnvironment_Bottom_Crop )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pIEnvironment_Bottom_Crop != C_NULL_P )
   {
      signal_value = EYEQMSG_ENVINITRR_ParamsApp_s.IEnvironment_Bottom_Crop_b16;
      * pIEnvironment_Bottom_Crop = signal_value;
      if( signal_value <= C_EYEQMSG_ENVINITRR_IENVIRONMENT_BOTTOM_CROP_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_ENVINITRR_Reserved_3
*
* FUNCTION ARGUMENTS:
*    uint16 * pReserved_3 - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Reserved_3
*    Reserved_3 returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Reserved_3 signal value of Environment_Init_rearCornerRight message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_ENVINITRR_Reserved_3( uint16 * pReserved_3 )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pReserved_3 != C_NULL_P )
   {
      signal_value = EYEQMSG_ENVINITRR_ParamsApp_s.Reserved_3_b16;
      * pReserved_3 = signal_value;
      if( signal_value <= C_EYEQMSG_ENVINITRR_RESERVED_3_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

