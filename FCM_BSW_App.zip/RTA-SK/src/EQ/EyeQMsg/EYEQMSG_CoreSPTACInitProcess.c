

/*****************************************************************************
                  Include files
*****************************************************************************/
/* The suggested include file order is: */
#include "EyeQ_defs.h"    /* EyeQ project common definitions file    */

#include "EYEQMSG_CoreSPTACInitProcess.h"

/*****************************************************************************
                  Local symbolic constants
*****************************************************************************/
/*****************************************************************************
                  Local types, enums definitions
*****************************************************************************/
/*****************************************************************************
                  Local function prototypes
*****************************************************************************/
/*****************************************************************************
                  Local object definitions
*****************************************************************************/
/*****************************************************************************
                  Exported object definitions
*****************************************************************************/
EYEQMSG_CORESPTACINIT_Params_t   EYEQMSG_CORESPTACINIT_Params_s;
EYEQMSG_CORESPTACINIT_Params_t   EYEQMSG_CORESPTACINIT_ParamsApp_s;
/*****************************************************************************
                  Local function-like macros
*****************************************************************************/
/*****************************************************************************
                  Local defined macros
*****************************************************************************/
/*****************************************************************************
                  Function definitions
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_CORESPTACINIT_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_CORESPTACINIT_Params_t * pCore_SPTAC_Init - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_SPTAC_Init message 
*    Core_SPTAC_Init message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_SPTAC_Init message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_CORESPTACINIT_ParamsApp_MsgDataStruct( EYEQMSG_CORESPTACINIT_Params_t * pCore_SPTAC_Init )
{
   Std_ReturnType status = C_SIG_INVALID;
   if( pCore_SPTAC_Init != C_NULL_P )
   {
      status = C_SIG_VALID;
      * pCore_SPTAC_Init = EYEQMSG_CORESPTACINIT_ParamsApp_s;
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESPTACINIT_ISPTAC_Zero_byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pISPTAC_Zero_byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ISPTAC_Zero_byte
*    ISPTAC_Zero_byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ISPTAC_Zero_byte signal value of Core_SPTAC_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESPTACINIT_ISPTAC_Zero_byte( uint8 * pISPTAC_Zero_byte )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pISPTAC_Zero_byte != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESPTACINIT_ParamsApp_s.ISPTAC_Zero_byte_b8;
      * pISPTAC_Zero_byte = signal_value;
      if( signal_value <= C_EYEQMSG_CORESPTACINIT_ISPTAC_ZERO_BYTE_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESPTACINIT_ISPTAC_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pISPTAC_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ISPTAC_Protocol_Version
*    ISPTAC_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ISPTAC_Protocol_Version signal value of Core_SPTAC_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESPTACINIT_ISPTAC_Protocol_Version( uint8 * pISPTAC_Protocol_Version )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint8 signal_value;
   
   if( pISPTAC_Protocol_Version != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESPTACINIT_ParamsApp_s.ISPTAC_Protocol_Version_b8;
      * pISPTAC_Protocol_Version = signal_value;
      if( (signal_value >= C_EYEQMSG_CORESPTACINIT_ISPTAC_PROTOCOL_VERSION_RMIN ) 
          && (signal_value <= C_EYEQMSG_CORESPTACINIT_ISPTAC_PROTOCOL_VERSION_RMAX ) )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_CORESPTACINIT_ISPTAC_Optional_Signals
*
* FUNCTION ARGUMENTS:
*    uint16 * pISPTAC_Optional_Signals - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of ISPTAC_Optional_Signals
*    ISPTAC_Optional_Signals returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns ISPTAC_Optional_Signals signal value of Core_SPTAC_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_CORESPTACINIT_ISPTAC_Optional_Signals( uint16 * pISPTAC_Optional_Signals )
{
   Std_ReturnType status = C_SIG_INVALID;
   uint16 signal_value;
   
   if( pISPTAC_Optional_Signals != C_NULL_P )
   {
      signal_value = EYEQMSG_CORESPTACINIT_ParamsApp_s.ISPTAC_Optional_Signals_b16;
      * pISPTAC_Optional_Signals = signal_value;
      if( signal_value <= C_EYEQMSG_CORESPTACINIT_ISPTAC_OPTIONAL_SIGNALS_RMAX )
      {
         status = C_SIG_VALID;
      }
   }
   return ( status );
}

