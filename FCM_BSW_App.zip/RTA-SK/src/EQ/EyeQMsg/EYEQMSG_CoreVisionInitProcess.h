#ifndef _EYEQMSG_COREVISIONINITPROCESS_H_
#define _EYEQMSG_COREVISIONINITPROCESS_H_

/*****************************************************************************
                  Included header files
*****************************************************************************/
#include <Std_Types.h>

/*****************************************************************************
                  Include files
*****************************************************************************/
/*****************************************************************************
                  Exported symbolic constants
*****************************************************************************/

/* Datagram message ID */
#define C_EYEQMSG_COREVISIONINIT_MSG_ID                       ( 0x92U )

/* Datagram message lengths */
#define C_EYEQMSG_COREVISIONINIT_MSG_LEN                      ( sizeof(EYEQMSG_COREVISIONINIT_Params_t) )

/* Protocol ENUMs */

/* MCU output messages */

/* Core_Vision_Init Enums */
/* IVISION_Optional_Signals_b16 signal Min & Max range limits */
#define C_EYEQMSG_COREVISIONINIT_IVISION_OPTIONAL_SIGNALS_RMIN ( 0U )
#define C_EYEQMSG_COREVISIONINIT_IVISION_OPTIONAL_SIGNALS_RMAX ( 0U )
#define C_EYEQMSG_COREVISIONINIT_IVISION_OPTIONAL_SIGNALS_NUMR ( 1U )
#define C_EYEQMSG_COREVISIONINIT_IVISION_OPTIONAL_SIGNALS_DEMNR ( 1U )
#define C_EYEQMSG_COREVISIONINIT_IVISION_OPTIONAL_SIGNALS_OFFSET ( 0U )

/* IVISION_Protocol_Version_b8 signal Min & Max range limits */
#define C_EYEQMSG_COREVISIONINIT_IVISION_PROTOCOL_VERSION_RMIN ( 5U )
#define C_EYEQMSG_COREVISIONINIT_IVISION_PROTOCOL_VERSION_RMAX ( 5U )
#define C_EYEQMSG_COREVISIONINIT_IVISION_PROTOCOL_VERSION_NUMR ( 1U )
#define C_EYEQMSG_COREVISIONINIT_IVISION_PROTOCOL_VERSION_DEMNR ( 1U )
#define C_EYEQMSG_COREVISIONINIT_IVISION_PROTOCOL_VERSION_OFFSET ( 0U )

/* IVISION_Zero_Byte_b8 signal Min & Max range limits */
#define C_EYEQMSG_COREVISIONINIT_IVISION_ZERO_BYTE_RMIN       ( 0U )
#define C_EYEQMSG_COREVISIONINIT_IVISION_ZERO_BYTE_RMAX       ( 0U )
#define C_EYEQMSG_COREVISIONINIT_IVISION_ZERO_BYTE_NUMR       ( 1U )
#define C_EYEQMSG_COREVISIONINIT_IVISION_ZERO_BYTE_DEMNR      ( 1U )
#define C_EYEQMSG_COREVISIONINIT_IVISION_ZERO_BYTE_OFFSET     ( 0U )


/*****************************************************************************
                  Exported function-like macros
*****************************************************************************/
/*****************************************************************************
                  Exported defined macros
*****************************************************************************/
/*****************************************************************************
                  Exported types, enums definitions
*****************************************************************************/
typedef struct
{
   #if ENABLE_BIG_ENDIAN_FORMAT
      uint32        IVISION_Zero_Byte_b8                         : 8U;
      
      uint32        IVISION_Protocol_Version_b8                  : 8U;
      
      uint32        IVISION_Optional_Signals_1_b8                : 8U;
      
      uint32        IVISION_Optional_Signals_2_b8                : 8U;
      
   #else
      uint32        IVISION_Zero_Byte_b8                         : 8U;
      
      uint32        IVISION_Protocol_Version_b8                  : 8U;
      
      uint32        IVISION_Optional_Signals_b16                 : 16U;
      
   #endif
} EYEQMSG_COREVISIONINIT_Params_t;


/*****************************************************************************
                  Exported function prototypes
*****************************************************************************/

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_COREVISIONINIT_ParamsApp_MsgDataStruct
*
* FUNCTION ARGUMENTS:
*    EYEQMSG_COREVISIONINIT_Params_t * pCore_Vision_Init - referenced structure variable for message return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of Core_Vision_Init message 
*    Core_Vision_Init message structure returned in reference of msgStructure
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns Core_Vision_Init message structure
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_COREVISIONINIT_ParamsApp_MsgDataStruct( EYEQMSG_COREVISIONINIT_Params_t * pCore_Vision_Init );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREVISIONINIT_IVISION_Zero_Byte
*
* FUNCTION ARGUMENTS:
*    uint8 * pIVISION_Zero_Byte - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IVISION_Zero_Byte
*    IVISION_Zero_Byte returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IVISION_Zero_Byte signal value of Core_Vision_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREVISIONINIT_IVISION_Zero_Byte( uint8 * pIVISION_Zero_Byte );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREVISIONINIT_IVISION_Protocol_Version
*
* FUNCTION ARGUMENTS:
*    uint8 * pIVISION_Protocol_Version - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IVISION_Protocol_Version
*    IVISION_Protocol_Version returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IVISION_Protocol_Version signal value of Core_Vision_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREVISIONINIT_IVISION_Protocol_Version( uint8 * pIVISION_Protocol_Version );

/*----------------------------------------------------------------------------
*
* FUNCTION NAME: EYEQMSG_Get_COREVISIONINIT_IVISION_Optional_Signals
*
* FUNCTION ARGUMENTS:
*    uint16 * pIVISION_Optional_Signals - referenced variable for signal value return
*
* RETURN VALUE:
*    Std_ReturnType flag indicating validity of IVISION_Optional_Signals
*    IVISION_Optional_Signals returned in reference of signalValue
*
* FUNCTION DESCRIPTION AND RESTRICTIONS:
*    Returns IVISION_Optional_Signals signal value of Core_Vision_Init message
*---------------------------------------------------------------------------*/
Std_ReturnType EYEQMSG_Get_COREVISIONINIT_IVISION_Optional_Signals( uint16 * pIVISION_Optional_Signals );
/*****************************************************************************
                  Exported object declarations
*****************************************************************************/
extern EYEQMSG_COREVISIONINIT_Params_t   EYEQMSG_COREVISIONINIT_Params_s;
extern EYEQMSG_COREVISIONINIT_Params_t   EYEQMSG_COREVISIONINIT_ParamsApp_s;
/****************************************************************************/
#endif /* _EYEQMSG_COREVISIONINITPROCESS_H_ */


