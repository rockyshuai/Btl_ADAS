#include <CanTrcv_Cfg.h>

extern void CanTrcv_Init(void);