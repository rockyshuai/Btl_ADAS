#include "CanTrcv.h"
#include <Spi.h>
#include <Dio.h>

uint16 CanTrcv_TxBuff[5] = { 0 };
uint16 CanTrcv_RxBuff[5] = { 0 };
Std_ReturnType CanTrcv_ret_status;

void CanTrcv_Init(void)
{
   uint8 seq_index;

   CanTrcv_TxBuff[0] = 0x4C05;// CanTrcv baudrate 500k 
   CanTrcv_TxBuff[1] = 0x4022;// disable PN 0x4022
   CanTrcv_TxBuff[2] = 0x0207;// Enter normal mode
   CanTrcv_TxBuff[3] = 0x0300;// Read mode
   CanTrcv_TxBuff[4] = 0x4400;// Read Status

   //Dio_WriteChannel(DioConf_DioChannel_Rain_Spi_Cs, STD_ON);

   for (seq_index = 0; seq_index < 5; seq_index++)
   {
      CanTrcv_ret_status = Spi_SetupEB(SpiConf_SpiChannel_SpiChannel_CAN0, 
                                       (Spi_DataBufferType*) &CanTrcv_TxBuff[seq_index],
                                       (Spi_DataBufferType*) &CanTrcv_RxBuff[seq_index],
                                       1);
      if (E_OK == CanTrcv_ret_status)
      {
         CanTrcv_ret_status = Spi_SyncTransmit(SpiConf_SpiSequence_SpiSequence_CAN0);
         if (E_OK != CanTrcv_ret_status)
         {
            seq_index = 6;
         }
      }
      else
      {
         seq_index = 6;
      }
      
   }

}