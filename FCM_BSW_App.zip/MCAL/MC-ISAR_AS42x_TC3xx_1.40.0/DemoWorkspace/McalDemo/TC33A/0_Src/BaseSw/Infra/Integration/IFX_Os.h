/*******************************************************************************
**                                                                            **
** Copyright (C) Infineon Technologies (2018)                                 **
**                                                                            **
** All rights reserved.                                                       **
**                                                                            **
** This document contains proprietary information belonging to Infineon       **
** Technologies. Passing on and copying of this document, and communication   **
** of its contents is not permitted without prior written authorization.      **
**                                                                            **
********************************************************************************
**                                                                            **
**  FILENAME     : IFX_Os.h                                                   **
**                                                                            **
**  VERSION      : 0.0.4                                                      **
**                                                                            **
**  DATE         : 2018-10-11                                                 **
**                                                                            **
**  VARIANT      : NA                                                         **
**                                                                            **
**  PLATFORM     : Infineon AURIX2G                                           **
**                                                                            **
**  AUTHOR       : DL-AUTOSAR-Engineering                                     **
**                                                                            **
**  VENDOR       : Infineon Technologies                                      **
**                                                                            **
**  DESCRIPTION : Stub header file for OS APIs                                **
**                                                                            **
**  SPECIFICATION(S) :  AUTOSAR Release 4.2.2                                 **
**                                                                            **
**  MAY BE CHANGED BY USER : YES                                              **
**                                                                            **
*******************************************************************************/

/*******************************************************************************
*******************************************************************************/
#ifndef IFX_OS_H
#define IFX_OS_H

#include "Mcal_Compiler.h"

/*******************************************************************************
**                      Include Section                                       **
*******************************************************************************/
#include "Os.h"

#endif /* IFX_OS_H  */
