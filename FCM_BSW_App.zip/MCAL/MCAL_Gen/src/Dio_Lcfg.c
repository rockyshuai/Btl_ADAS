
/*******************************************************************************
**                                                                            **
** Copyright (C) Infineon Technologies (2019)                                 **
**                                                                            **
** All rights reserved.                                                       **
**                                                                            **
** This document contains proprietary information belonging to Infineon       **
** Technologies. Passing on and copying of this document, and communication   **
** of its contents is not permitted without prior written authorization.      **
**                                                                            **
********************************************************************************
**                                                                            **
**  FILENAME  : Dio_Lcfg.c                                                    **
**                                                                            **
**  VERSION   : 1.30.0_6.0.0                                                  **
**                                                                            **
**  DATE, TIME: 2021-03-30, 14:28:36       !!!IGNORE-LINE!!!                  **
**                                                                            **
**  GENERATOR : Build b170330-0431           !!!IGNORE-LINE!!!                **
**                                                                            **
**  BSW MODULE DECRIPTION : Dio.bmd                                           **
**                                                                            **
**  VARIANT   : Variant LT                                                    **
**                                                                            **
**  PLATFORM  : Infineon AURIX2G                                              **
**                                                                            **
**  AUTHOR    : DL-AUTOSAR-Engineering                                        **
**                                                                            **
**  VENDOR    : Infineon Technologies                                         **
**                                                                            **
**  DESCRIPTION  : Dio configuration generated out of ECUC file               **
**                                                                            **
**  SPECIFICATION(S) : Specification of Dio Driver, AUTOSAR Release 4.2.2     **
**                                                                            **
**  MAY BE CHANGED BY USER : no                                               **
**                                                                            **
*******************************************************************************/


    
  /*******************************************************************************
  **                             Includes                                       **
  *******************************************************************************/

  /* Include Port Module File */
  #include "Dio.h"

  /*******************************************************************************
  **                      Private Macro Definitions                             **
  *******************************************************************************/

  /*******************************************************************************
  **                      Global Constant Definitions                           **
  *******************************************************************************/
  
  /* Memory mapping of the DIO configuration */
  #define DIO_START_SEC_CONFIG_DATA_ASIL_B_GLOBAL_UNSPECIFIED
  /* MISRA2012_RULE_4_10_JUSTIFICATION: To be compliant with autosar guidelines 
  Dio_Memmap.h header is included without safegaurd.*/
  #include "Dio_MemMap.h"
  /*
      Configuration of DIO Channel groups 
  */
              
static const Dio_ChannelGroupType Dio_kChannelGroupConfig[DIO_CHANNELGROUPCOUNT]=
  {
  
    {/* DioPort_0, DioChGrpId_P0_0 */
    (Dio_PortLevelType)0x3ff, /* Mask    */
    (uint8)0,              /* Offset  */
    (Dio_PortType)0          /* Port Id */
    }
    ,
    {/* DioPort_0, DioChGrpId_P0_1 */
    (Dio_PortLevelType)0x1000, /* Mask    */
    (uint8)12,              /* Offset  */
    (Dio_PortType)0          /* Port Id */
    }
    ,
    {/* DioPort_2, DioChGrpId_P2_0 */
    (Dio_PortLevelType)0x1fc, /* Mask    */
    (uint8)2,              /* Offset  */
    (Dio_PortType)2          /* Port Id */
    }
    ,
    {/* DioPort_10, DioChGrpId_P10_0 */
    (Dio_PortLevelType)0x1ff, /* Mask    */
    (uint8)0,              /* Offset  */
    (Dio_PortType)10          /* Port Id */
    }
    ,
    {/* DioPort_11, DioChGrpId_P11_0 */
    (Dio_PortLevelType)0xff00, /* Mask    */
    (uint8)8,              /* Offset  */
    (Dio_PortType)11          /* Port Id */
    }
    ,
    {/* DioPort_14, DioChGrpId_P14_0 */
    (Dio_PortLevelType)0x3ff, /* Mask    */
    (uint8)0,              /* Offset  */
    (Dio_PortType)14          /* Port Id */
    }
    ,
    {/* DioPort_15, DioChGrpId_P15_0 */
    (Dio_PortLevelType)0x1ff, /* Mask    */
    (uint8)0,              /* Offset  */
    (Dio_PortType)15          /* Port Id */
    }
    ,
    {/* DioPort_20, DioChGrpId_P20_0 */
    (Dio_PortLevelType)0x3c0, /* Mask    */
    (uint8)6,              /* Offset  */
    (Dio_PortType)20          /* Port Id */
    }
    ,
    {/* DioPort_20, DioChGrpId_P20_1 */
    (Dio_PortLevelType)0xf, /* Mask    */
    (uint8)0,              /* Offset  */
    (Dio_PortType)20          /* Port Id */
    }
    ,
    {/* DioPort_21, DioChGrpId_P21_0 */
    (Dio_PortLevelType)0x3f, /* Mask    */
    (uint8)0,              /* Offset  */
    (Dio_PortType)21          /* Port Id */
    }
    ,
    {/* DioPort_22, DioChGrpId_P22_0 */
    (Dio_PortLevelType)0x1f, /* Mask    */
    (uint8)0,              /* Offset  */
    (Dio_PortType)22          /* Port Id */
    }
    ,
    {/* DioPort_23, DioChGrpId_P23_0 */
    (Dio_PortLevelType)0x20, /* Mask    */
    (uint8)5,              /* Offset  */
    (Dio_PortType)23          /* Port Id */
    }
    ,
    {/* DioPort_23, DioChGrpId_P23_1 */
    (Dio_PortLevelType)0x2, /* Mask    */
    (uint8)1,              /* Offset  */
    (Dio_PortType)23          /* Port Id */
    }
    ,
    {/* DioPort_32, DioChGrpId_P32_0 */
    (Dio_PortLevelType)0x10, /* Mask    */
    (uint8)4,              /* Offset  */
    (Dio_PortType)32          /* Port Id */
    }
    ,
    {/* DioPort_33, DioChGrpId_P33_0 */
    (Dio_PortLevelType)0xff, /* Mask    */
    (uint8)0,              /* Offset  */
    (Dio_PortType)33          /* Port Id */
    }
    ,
    {/* DioPort_34, DioChGrpId_P34_0 */
    (Dio_PortLevelType)0xe, /* Mask    */
    (uint8)1,              /* Offset  */
    (Dio_PortType)34          /* Port Id */
    }
};

  static const Dio_PortChannelIdType Dio_kPortChannelConfig[] =
  { 
    {
    /* Port0*/
      DIO_PORT_CONFIGURED,
      (0x12f8U)
    },
    {
    /* Port2*/
      DIO_PORT_CONFIGURED,
      (0x0130U)
    },
    {
    /* Port10*/
      DIO_PORT_CONFIGURED,
      (0x0068U)
    },
    {
    /* Port11*/
      DIO_PORT_CONFIGURED,
      (0x8000U)
    },
    {
    /* Port12*/
      DIO_PORT_NOT_CONFIGURED,
      (0x0000U)
    },
    {
    /* Port14*/
      DIO_PORT_CONFIGURED,
      (0x0234U)
    },
    {
    /* Port15*/
      DIO_PORT_CONFIGURED,
      (0x0130U)
    },
    {
    /* Port20*/
      DIO_PORT_CONFIGURED,
      (0x03cbU)
    },
    {
    /* Port21*/
      DIO_PORT_CONFIGURED,
      (0x0001U)
    },
    {
    /* Port22*/
      DIO_PORT_CONFIGURED,
      (0x0010U)
    },
    {
    /* Port23*/
      DIO_PORT_CONFIGURED,
      (0x0022U)
    },
    {
    /* Port32*/
      DIO_PORT_CONFIGURED,
      (0x0010U)
    },
    {
    /* Port33*/
      DIO_PORT_CONFIGURED,
      (0x00ffU)
    },
    {
    /* Port34*/
      DIO_PORT_CONFIGURED,
      (0x000eU)
    }
  };
    const Dio_ConfigType Dio_Config =
    {
                
      /* Dio Port and Channelconfiguration */
            &Dio_kPortChannelConfig[0],
      /* Dio Channelgroup configuration */
      
        &Dio_kChannelGroupConfig[0],
      /* Configured number of Dio Channelgroups for configuration */
      DIO_CHANNELGROUPCOUNT
    };
  #define DIO_STOP_SEC_CONFIG_DATA_ASIL_B_GLOBAL_UNSPECIFIED
    /* MISRA2012_RULE_4_10_JUSTIFICATION: To be compliant with autosar guidelines 
    Dio_Memmap.h header is included without safegaurd.*/
    /* MISRA2012_RULE_20_1_JUSTIFICATION: Dio_Memmap.h header included as per Autosar 
    guidelines. */
  #include "Dio_MemMap.h"

/*******************************************************************************
**                      Private Constant Definitions                          **
*******************************************************************************/
