
/*******************************************************************************
**                                                                            **
** Copyright (C) Infineon Technologies (2019)                                 **
**                                                                            **
** All rights reserved.                                                       **
**                                                                            **
** This document contains proprietary information belonging to Infineon       **
** Technologies. Passing on and copying of this document, and communication   **
** of its contents is not permitted without prior written authorization.      **
**                                                                            **
********************************************************************************
**                                                                            **
**  FILENAME  : Smu_PBCfg.c                                                   **
**                                                                            **
**  VERSION   : 6.0.0                                                         **
**                                                                            **
**  DATE, TIME: 2020-10-20, 11:37:35             !!!IGNORE-LINE!!!            **
**                                                                            **
**  GENERATOR : Build b170330-0431               !!!IGNORE-LINE!!!            **
**                                                                            **
**  BSW MODULE DECRIPTION : NA                                                **
**                                                                            **
**  VARIANT   : Variant PB                                                    **
**                                                                            **
**  PLATFORM  : Infineon AURIX2G                                              **
**                                                                            **
**  AUTHOR    : DL-AUTOSAR-Engineering                                        **
**                                                                            **
**  VENDOR    : Infineon Technologies                                         **
**                                                                            **
**  DESCRIPTION  : Smu configuration generated out of ECUC file               **
**                                                                            **
**  SPECIFICATION(S) : NA                                                     **
**                                                                            **
**  MAY BE CHANGED BY USER : no                                               **
**                                                                            **
*******************************************************************************/
#include "Smu.h"


      


/*******************************************************************************
**                      Private Macro definition                              **
*******************************************************************************/

/*******************************************************************************
**                      Configuration Options                                 **
*******************************************************************************/

/*******************************************************************************
**                      Private Type Definitions                              **
*******************************************************************************/


/*******************************************************************************
**                      Private Function Declarations                         **
*******************************************************************************/


/*******************************************************************************
**                      Global Variable Definitions                           **
*******************************************************************************/

/*******************************************************************************
**                      Global Funtion Declarations                           **
*******************************************************************************/

/*******************************************************************************
**                      Global Constant Definitions                           **
*******************************************************************************/
/* Memory Mapping the configuration constant */
#define SMU_START_SEC_CONFIG_DATA_ASIL_B_GLOBAL_UNSPECIFIED 
/* MISRA2012_RULE_4_10_JUSTIFICATION: Smu_Memmap.h is repeatedly included
* without include guard. This is as per AUTOSAR */
/* MISRA2012_RULE_20_1_JUSTIFICATION: declaration of notification functions
* before include memap.h - Accepted deviation in AUTOSAR */
#include "Smu_MemMap.h"

/* SMU Module Configuration */
/* MISRA2012_RULE_8_7_JUSTIFICATION: Module configuration data structure
declaration is as per Autosar guidelines. This data structure is needed
by SW units using Smu Driver APIs hence it should be declared as extern in 
the SW unit from where it is used */
/* MISRA2012_RULE_8_4_JUSTIFICATION: Module configuration data structure
declaration is as per Autosar guidelines. This data structure is needed
by SW units using Smu Driver APIs hence it should be declared as extern in 
the SW unit from where it is used */


const Smu_ConfigType Smu_Config =
{
  
  /* FSP Cfg for Smu_core*/
  (uint32)0x400000U,
  
  /* AGC Cfg for SmuCore*/
  (uint32)0x0U,
  
  /* RTC Cfg for SmuCore*/
  (uint32)0x3fff00U,
  
  /* RTAC00 Cfg for SmuCore*/
  (uint32)0x0U,
  
  /* RTAC01 Cfg for SmuCore*/
  (uint32)0x0U,
  
  /* RTAC10 Cfg for SmuCore*/
  (uint32)0x0U,
  
  /* RTAC11 Cfg for SmuCore*/
  (uint32)0x0U,
  
  /* CMD_STDBY config for SmuStdby*/
  (uint32)0x0U, 
  
  /*AlarmConfig for SmuCore*/
  {
    0x0U,0x0U,0x0U,
    0x0U,0x0U,0x0U,
    0x0U,0x0U,0x0U,
    0x0U,0x0U,0x0U,
    0x0U,0x0U,0x0U,
    0x0U,0x0U,0x0U,
    0x0U,0x0U,0x0U,
    0x0U,0x0U,0x0U,
    0x0U,0x0U,0x0U,
    0x0U,0x0U,0x0U,
    0x0U,0x1U,0x0U,
    0x0U,0x0U,0x0U
  },
  
  /*AlarmFspConfig for SmuCore*/
  {
    0x0U,0x0U,0x0U,0x0U,0x0U,0x0U,0x0U,0x0U,0x0U,0x0U,0x0U,0x0U},
  
  /*AlarmFspConfig for SmuStdby*/
  {
    0x0U,0x0U}
};
#define SMU_STOP_SEC_CONFIG_DATA_ASIL_B_GLOBAL_UNSPECIFIED 
/* MISRA2012_RULE_4_10_JUSTIFICATION: Smu_Memmap.h is repeatedly included
 * without include guard. This is as per AUTOSAR */
/* MISRA2012_RULE_20_1_JUSTIFICATION: declaration of notification functions
 * before include memap.h - Accepted deviation in AUTOSAR */
#include "Smu_MemMap.h"
