
 
/*<VersionHead>
 * This Configuration File is generated using versions (automatically filled in) as listed below.
 *
 * $Generator__: CanTrcv / AR42.6.0.0                Module Package Version
 * $Editor_____: ISOLAR-A/B 7.0.1_7.0.1                Tool Version
 * $Model______: 2.3.0.4                 ECU Parameter Definition Version
 *

 </VersionHead>*/


/**
 ***************************************************************************************************
 * \moduledescription
 *                      CanTrcv Auto generated configuration header file
 *
 * \scope               CONF
 ***************************************************************************************************
 */

#ifndef CANTRCV_CFG_H_
#define CANTRCV_CFG_H_



# include "Spi.h"
# include "EcuM.h"


/*
 ***************************************************************************************************
 * Defines
 ***************************************************************************************************
 */

#define CANTRCV_PRV_GEN_MAJOR_VERSION    6
#define CANTRCV_PRV_GEN_MINOR_VERSION    0
#define CANTRCV_PRV_GEN_PATCH_VERSION    0

#define CANTRCV_CFG_CONFIGURED

#define CANTRCV_VARIANT_PRECOMPILE   1
#define CANTRCV_VARIANT_LINKTIME     2
#define CANTRCV_VARIANT_POSTBUILD    3



#define CANTRCV_VARIANT               CANTRCV_VARIANT_PRECOMPILE 

#define CANTRCV_CFG_NUMBER_OF_CANTRCV  1u

#define CANTRCV_CANTRCVCHANNEL_0    0      /*  Index for CanTrcvChannel_0  */
#define CANTRCV_IDX_LIST CANTRCV_CANTRCVCHANNEL_0

 
#define CANTRCV_INDEX_OFFSET  0

/* Symbolic Names for CanTrcvChannelId */
#define  CanTrcvConf_CanTrcvChannel_CanTrcvChannel_0   0  // CanTrcv : CanTrcvChannel_0

/* Wakeup Enabled if one CanTrcv is configured with CANTRCV_WAKEUP_BY_POLLING = ON */
#define CANTRCV_CFG_WAKEUP_BY_NODE_USED STD_ON

#ifndef CANTRCV_ECUM_USED   // Value could be overwritten in integrator code
# define CANTRCV_ECUM_USED   STD_ON
#endif
/* Wakeup Reason functionality in SetWakeupMode */
#define CANTRCV_CFG_CLEAR_WUPREASON_IN_SETWAKEUPMODE STD_OFF

/* Config parameter to change the return value of FrTrcv_CheckWakeupByTransceiver between STD_ON: AR4.0 = wakeup-info and STD_OFF: AR4.2=Function behavior.*/ 
#define CANTRCV_RB_CHECKWAKEUP_RETURNVAL  STD_OFF

/* Config parameter to change the EcuM notification for asynchron Trcv*/
#define CANTRCV_CFG_CHECKWAKEUP_SYNC  0u
#define CANTRCV_CFG_CHECKWAKEUP_ASYNC 1u
#define CANTRCV_RB_CHECKWAKEUP_ASYNC_MODE  CANTRCV_CFG_CHECKWAKEUP_ASYNC

/* Enables partial network API */
#define CANTRCV_HW_PN_SUPPORT STD_OFF

/* As defined in AR SWS parameter configures the availability of CanTrcv_GetVersionInfo */
#define CANTRCV_GET_VERSION_INFO STD_OFF

/* enables/disables DET (at least for one trcv)*/
#define CANTRCV_DEV_ERROR_DETECT   STD_OFF

/* enables/disables DEM (at least for one trcv)*/
#define CANTRCV_CFG_TJA1145_DEM_ENABLE   STD_OFF

/* enables/disables DEM for Cdd Type of transciver (at least for one trcv)*/
#define CANTRCV_CFG_CDD_DEM_ENABLE   STD_OFF

/* enables/disables Mode Propogation dem for Dio based*/
#define CANTRCV_MODE_PROPOGATION_REPORTING_DIO_BASED   STD_OFF

/* enables/disables Mode Propogation dem for SPI based*/
#define CANTRCV_MODE_PROPOGATION_REPORTING_SPI_BASED   STD_OFF

/* enables/disables Mode Propogation dem for Cdd based*/
#define CANTRCV_MODE_PROPOGATION_REPORTING_CDD_BASED   STD_OFF

/* Config parameter to decide if global functions should be declared in this component or in RTE */ 
#define CANTRCV_CFG_RB_RTE_IN_USE  STD_ON

#define CANTRCV_CFG_CDD_USED               STD_OFF
 
#define CANTRCV_CDD_DIO_CONFIGURED          STD_OFF  

#define CANTRCV_CFG_NUMBER_OF_CDD_CANTRCV         0 

#define CANTRCV_CFG_DIO_DEFAULT             STD_OFF
#define CANTRCV_CFG_SPI_USED                STD_ON
#define CANTRCV_CFG_SPI_SEQ_MAX             1
#define CANTRCV_CFG_SPI_DATA_MAX            41
#define CANTRCV_INDICATION_ASYNC            0
#define CANTRCV_INDICATION_IMMEDIATELY      1
#define CANTRCV_CFG_RB_INDICATION_BEHAVIOUR CANTRCV_INDICATION_ASYNC

/* SPI: STD_ON: external buffers are used; STD_OFF: internal buffers are used */
/* value is set according SPI_CHANNEL_BUFFERS_ALLOWED */
#define CANTRCV_SPI_EXTERNBUFFER            STD_ON
#define CANTRCV_CFG_SPI_TJA1145_USED        STD_ON
#define CANTRCV_CFG_CS9XX_USED              STD_OFF
#define CANTRCV_CFG_BUS_ERR_FLAG_GENERAL    STD_OFF
#define CANTRCV_CFG_TJA1145_MAX             1
#define CANTRCV_CFG_TJA1145_SPI_INIT_MAX    29
#define CANTRCV_CFG_TJA1145_SPI_CTRL_MAX    12
#define CANTRCV_CFG_TJA1145_SPI_CTRL_RW_MAX 12

#define CANTRCV_CFG_TJA1145_READ_ONLY_MASK  0x0100uL
#define CANTRCV_CFG_TJA1145_SPI_REG0A_A     0
#define CANTRCV_CFG_TJA1145_SPI_LK2C_MASK        0x04u  // 0x20 to 0x2F -
#define CANTRCV_CFG_TJA1145_SPI_LK1C_MASK        0x02u  // 0x10 to 0x1F -
#define CANTRCV_CFG_TJA1145_SPI_LK0C_MASK        0x01u  // 0x06 to 0x09 -
#define CANTRCV_CFG_TJA1145_SPI_REG01       5
#define CANTRCV_CFG_TJA1145_SPI_MC_AND_MASK      0x0007u // Mask to read out Mode
#define CANTRCV_CFG_TJA1145_SPI_MC_NM_AND_MASK   0xFEF8u // Mask for normal Mode and Cleared ReadOnlyBit
#define CANTRCV_CFG_TJA1145_SPI_MC_NM_OR_MASK    0x0007u // Mask for normal Mode
#define CANTRCV_CFG_TJA1145_SPI_MC_SM_AND_MASK   0xFEF8u // Mask for sleep Mode and Cleared ReadOnlyBit
#define CANTRCV_CFG_TJA1145_SPI_MC_SM_OR_MASK    0x0001u // Mask for sleep Mode
#define CANTRCV_CFG_TJA1145_SPI_MC_SBM_AND_MASK  0xFEF8u // Mask for standby Mode and Cleared ReadOnlyBit
#define CANTRCV_CFG_TJA1145_SPI_MC_SBM_OR_MASK   0x0004u // Mask for standby Mode
#define CANTRCV_CFG_TJA1145_SPI_REG20            4
#define CANTRCV_CFG_TJA1145_SPI_CMC_NM_AND_MASK  (~(CANTRCV_CFG_TJA1145_READ_ONLY_MASK + 3uL))    // Mask for normal Mode
#define CANTRCV_CFG_TJA1145_SPI_CMC_SM_AND_MASK  (~(CANTRCV_CFG_TJA1145_READ_ONLY_MASK + 3uL))    // Mask for sleep Mode
#define CANTRCV_CFG_TJA1145_SPI_CMC_SM_OR_MASK   0x00u    // Mask for sleep Mode. Always 0
#define CANTRCV_CFG_TJA1145_SPI_CMC_SBM_AND_MASK (~(CANTRCV_CFG_TJA1145_READ_ONLY_MASK + 3uL))    // Mask for standby Mode
#define CANTRCV_CFG_TJA1145_SPI_CMC_SBM_OR_MASK  0x00u    // Mask for standby Mode. Always 0
#define CANTRCV_CFG_TJA1145_SPI_CPNC_MASK        0x10u
#define CANTRCV_CFG_TJA1145_SPI_REG4C       6
#define CANTRCV_CFG_TJA1145_SPI_REG03       7
#define CANTRCV_CFG_TJA1145_SPI_REG22       8
#define CANTRCV_CFG_TJA1145_SPI_CFS_MASK    1u
#define CANTRCV_CFG_TJA1145_SPI_CBSS_MASK   8u
#define CANTRCV_CFG_TJA1145_SPI_CTS_MASK    128u
#define CANTRCV_CFG_TJA1145_SPI_REG4B       9
#define CANTRCV_CFG_TJA1145_SPI_WPVS_MASK   0x02u
#define CANTRCV_CFG_TJA1145_SPI_REG60       1
#define CANTRCV_CFG_TJA1145_SPI_WPE_MASK    0x08u
#define CANTRCV_CFG_TJA1145_SPI_REG61       2
#define CANTRCV_CFG_TJA1145_SPI_PO_MASK     0x10u
#define CANTRCV_CFG_TJA1145_SPI_REG63       3
#define CANTRCV_CFG_TJA1145_SPI_CW_MASK     0x01u
#define CANTRCV_CFG_TJA1145_SPI_PO_MASK     0x10u
#define CANTRCV_CFG_TJA1145_SPI_CBS_MASK    0x10u
#define CANTRCV_CFG_TJA1145_SPI_PNFDE_MASK  0x20u
#define CANTRCV_CFG_TJA1145_SPI_REG64       10
#define CANTRCV_CFG_TJA1145_SPI_WPR_MASK    0x02u
#define CANTRCV_CFG_TJA1145_SPI_WPF_MASK    0x01u
#define CANTRCV_CFG_TJA1145_SPI_REG0A_E     11

/* enables multiple wakeup reasons */
#define CANTRCV_CFG_WU_BY_BUS_AND_PIN                CANTRCV_WU_NOT_SUPPORTED
#define CANTRCV_CFG_WU_BY_BUS_AND_POWER_ON           CANTRCV_WU_NOT_SUPPORTED
#define CANTRCV_CFG_WU_BY_PIN_AND_POWER_ON           CANTRCV_WU_NOT_SUPPORTED
#define CANTRCV_CFG_WU_BY_BUS_AND_PIN_AND_POWER_ON   CANTRCV_WU_NOT_SUPPORTED

/* enables/disables ASR3 Api(for all trcv)*/
#define CANTRCV_CFG_USE_ASR31_API   STD_OFF

#if(CANTRCV_HW_PN_SUPPORT == STD_ON)
typedef enum
{
    CANTRCV_PN_ENABLED  = 0,
    CANTRCV_PN_DISABLED = 1
}CanTrcv_PNActivationType;

typedef enum
{
    CANTRCV_FLAG_SET        = 0,
    CANTRCV_FLAG_CLEARED    = 1
}CanTrcv_TrcvFlagStateType;

/* Data Structure for PN information */
typedef struct
{
    boolean BusErrFlag;         // CANTRCV_CFG_BUS_ERR_FLAG
    boolean PnEnabled;          // CanTrcvPnEnabled
    boolean PowerOnFlag;        // CanTrcvPowerOnFlag
}CanTrcv_PnTrcv_tst;
#endif

#if CANTRCV_CFG_SPI_USED == STD_ON
# if CANTRCV_ECUM_USED == STD_OFF
// It is not possible to filter out WakeupSourceRef in CanTrcv_Spi_tst because struct is generated and generator
// does not know if integrator reconfigured ECUM availability. So EcuM_WakeupSourceType is defined in CanTrcv
typedef uint32      EcuM_WakeupSourceType;
# endif

typedef struct
{
    uint8                 No;         // 0-based Number specific for each Spi-Trcv-Type
    Spi_ChannelType       Channel;
    Spi_SequenceType      Sequence;
    EcuM_WakeupSourceType WakeupSourceRef;
    uint16                InitStartPos;
    uint16                ControlStartPos;
    uint16                ControlEndPos;
    uint8                 SpecReg1;     // Transceiver specific register value. For TJA1145 Bit CMC in normal mode
}CanTrcv_Spi_tst;
#endif



/* Data Structure for DEM information (only used for no-rba_Trcv) Same index as CanTrcv_PnTrcv_tst*/
#if (CANTRCV_CFG_TJA1145_DEM_ENABLE == STD_ON)
typedef struct
{
    Dem_EventIdType     EventId;    // DemEventId
}CanTrcv_Dem_tst;
#endif

/* Structure to pointer of functions */
typedef P2FUNC(void,           RBA_TRCV_APPL_CODE, CanTrcv_Init_t)(uint8 Transceiver);
typedef P2FUNC(Std_ReturnType, RBA_TRCV_APPL_CODE, CanTrcv_SetOpMode_t)(uint8 Transceiver, CanTrcv_TrcvModeType OpMode);
typedef P2FUNC(Std_ReturnType, RBA_TRCV_APPL_CODE, CanTrcv_GetOpMode_t)(uint8 Transceiver, P2VAR(CanTrcv_TrcvModeType, AUTOMATIC, CANTRCV_APPL_DATA) OpMode);
typedef P2FUNC(Std_ReturnType, RBA_TRCV_APPL_CODE, CanTrcv_GetBusWuReason_t)(uint8 Transceiver, P2VAR(CanTrcv_TrcvWakeupReasonType, AUTOMATIC, CANTRCV_APPL_DATA) reason);
typedef P2FUNC(Std_ReturnType, RBA_TRCV_APPL_CODE, CanTrcv_SetWakeupMode_t)(uint8 Transceiver, CanTrcv_TrcvWakeupModeType TrcvWakeupMode);
typedef P2FUNC(Std_ReturnType, RBA_TRCV_APPL_CODE, CanTrcv_CheckWakeup_t)(uint8 Transceiver, Std_ReturnType *WakeInfo);

typedef struct
{
    CanTrcv_Init_t              Init;
    CanTrcv_SetOpMode_t         SetOpMode;
    CanTrcv_GetOpMode_t         GetOpMode;
    CanTrcv_GetBusWuReason_t    GetBusWuReason;
    CanTrcv_SetWakeupMode_t     SetWakeupMode;
    CanTrcv_CheckWakeup_t       CheckWakeup;
    uint8                       CddNo;
}CanTrcv_FctP_tst;


#if (CANTRCV_CFG_CDD_USED == STD_ON)
/* Structure to pointer of CDD functions */
typedef P2FUNC(Std_ReturnType, RBA_TRCV_APPL_CODE, CanTrcv_SetOpModeCdd_t)(CanTrcv_TrcvModeType OpMode);
typedef P2FUNC(Std_ReturnType, RBA_TRCV_APPL_CODE, CanTrcv_GetOpModeCdd_t)(P2VAR(CanTrcv_TrcvModeType, AUTOMATIC, CANTRCV_APPL_DATA) OpMode);
typedef P2FUNC(Std_ReturnType, RBA_TRCV_APPL_CODE, CanTrcv_GetBusWuReasonCdd_t)(P2VAR(CanTrcv_TrcvWakeupReasonType, AUTOMATIC, CANTRCV_APPL_DATA) reason);
typedef P2FUNC(Std_ReturnType, RBA_TRCV_APPL_CODE, CanTrcv_SetWakeupModeCdd_t)(CanTrcv_TrcvWakeupModeType TrcvWakeupMode);
typedef P2FUNC(Std_ReturnType, RBA_TRCV_APPL_CODE, CanTrcv_CheckWakeupCdd_t)(void);

typedef struct
{
    CanTrcv_SetOpModeCdd_t         SetOpModeCdd;
    CanTrcv_GetOpModeCdd_t         GetOpModeCdd;
    CanTrcv_GetBusWuReasonCdd_t    GetBusWuReasonCdd;
    CanTrcv_SetWakeupModeCdd_t     SetWakeupModeCdd;
    CanTrcv_CheckWakeupCdd_t       CheckWakeupCdd;
#if (CANTRCV_MODE_PROPOGATION_REPORTING_CDD_BASED == STD_ON) && (CANTRCV_CFG_CDD_USED == STD_ON)
    Dem_EventIdType                CddPropModeDemEvent;  /*To hold the Dem event configured*/
    uint8                          CddModeChangeDelay;   /*To hold the configured delay time*/
#endif
}CanTrcv_CddFctP_tst;

/*This structure is required to hold the details of CDD transceiver mode change delay time
 * Requested mode and flag where Dem monitoring strats only after setmode is requested*/
#if (CANTRCV_MODE_PROPOGATION_REPORTING_CDD_BASED == STD_ON) && (CANTRCV_CFG_CDD_USED == STD_ON)
typedef struct
{
    CanTrcv_TrcvModeType           CanTrcv_CddReqMode;  /*latest requested mode*/
    uint8                          CanTrcv_CddDelaycount; /*Minimum time required to refect the requested mode in Cdd type if Transceiver*/
    uint8                          CanTrcv_CddModeReady; /*Flag to start the unexpected mode detection only after setmode is requested*/
}CanTrcv_CddModeProp_tst;
#endif

#if (CANTRCV_CDD_DIO_CONFIGURED == STD_ON)
typedef struct
{
    Dio_ChannelType Pin;
    uint16 Invert;
}CanTrcv_DioArray_tst;
#endif
#endif

typedef struct
{
    CONST(uint8, CANTRCV_CFG)             *CanTrcv_TrcvType;
#if (CANTRCV_CFG_CDD_USED == STD_ON)
  CONST(CanTrcv_CddFctP_tst, CANTRCV_CFG)  *CanTrcv_CddFctP_st;
#if (CANTRCV_CDD_DIO_CONFIGURED == STD_ON)
  CONST(CanTrcv_DioArray_tst, CANTRCV_CFG)  *CanTrcv_CddDio_ast;
#endif
#endif 
#if (CANTRCV_CFG_CS9XX_USED == STD_ON)
    CONST(uint8, CANTRCV_CFG)             *CanTrcv_CddIdMapping_au8;
#endif
    CONST(CanTrcv_FctP_tst, RBA_TRCV_CFG) *CanTrcv_FctP_st;
#if CANTRCV_CFG_SPI_USED == STD_ON
    CONST(uint8, CANTRCV_CFG)             *CanTrcv_Cfg_SpiPos_au8;
    CONST(CanTrcv_Spi_tst, CANTRCV_CFG)   *CanTrcv_SpiArray_ast;
    CONST(uint16,CANTRCV_CFG)       *CanTrcv_CfgSpiChannel_ao; 
# if(CANTRCV_HW_PN_SUPPORT == STD_ON)
    CONST (CanTrcv_PnTrcv_tst, CANTRCV_CFG)  *CanTrcv_PnTrcv_st;
# endif
#endif
}CanTrcv_ConfigType;


#define CANTRCV_START_SEC_CONFIG_DATA_POSTBUILD_UNSPECIFIED
#include "CanTrcv_MemMap.h"


/*Post build CanTrcv_Config */

/* Config Structure for Variant  */
extern CONST(uint8, CANTRCV_CFG) CanTrcv_TrcvType[];

/* Cdd Config Structures */


extern CONST(CanTrcv_FctP_tst, RBA_TRCV_CFG)  CanTrcv_FctP_st[];

/* Spi related Structures*/
#if CANTRCV_CFG_SPI_USED == STD_ON
extern CONST(uint8, CANTRCV_CFG) CanTrcv_Cfg_SpiPos_au8[];
extern CONST(CanTrcv_Spi_tst, CANTRCV_CFG)    CanTrcv_SpiArray_ast[];
extern CONST(uint16,CANTRCV_CFG) CanTrcv_CfgSpiChannel_ao[];
# if(CANTRCV_HW_PN_SUPPORT == STD_ON)
extern CONST(CanTrcv_PnTrcv_tst, CANTRCV_CFG) CanTrcv_PnTrcv_st[];
#endif
#endif


#if CANTRCV_CFG_SPI_USED == STD_ON
#if (CANTRCV_CFG_TJA1145_DEM_ENABLE == STD_ON)
extern CONST (CanTrcv_Dem_tst, CANTRCV_CFG)   CanTrcv_Dem_st[];
#if (CANTRCV_MODE_PROPOGATION_REPORTING_SPI_BASED == STD_ON)
extern CONST (CanTrcv_Dem_tst, CANTRCV_CFG)   CanTrcv_PropDem_st[];
#endif
#endif
#endif

extern CONST (EcuM_WakeupSourceType, CANTRCV_CFG) CanTrcv_WakeupSource_ao[];

#define CANTRCV_STOP_SEC_CONFIG_DATA_POSTBUILD_UNSPECIFIED
#include "CanTrcv_MemMap.h"

#endif //end of define CANTRCV_CFG_H

