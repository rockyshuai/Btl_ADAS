// No rba_Trcv relevant Trcv configured -> empty file
  