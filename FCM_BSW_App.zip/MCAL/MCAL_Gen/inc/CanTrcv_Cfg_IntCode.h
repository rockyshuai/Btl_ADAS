/*
 * This is a template file. It defines integration functions necessary to complete RTA-BSW.
 * The integrator must complete the templates before deploying software containing functions defined in this file.
 * Once templates have been completed, the integrator should delete the #error line.
 * Note: The integrator is responsible for updates made to this file.
 *
 * To remove the following error define the macro NOT_READY_FOR_TESTING_OR_DEPLOYMENT with a compiler option (e.g. -D NOT_READY_FOR_TESTING_OR_DEPLOYMENT)
 * The removal of the error only allows the user to proceed with the building phase
 */
/*#ifndef NOT_READY_FOR_TESTING_OR_DEPLOYMENT
#error The content of this file is a template which provides empty stubs. The content of this file must be completed by the integrator accordingly to project specific requirements
#else
#warning The content of this file is a template which provides empty stubs. The content of this file must be completed by the integrator accordingly to project specific requirements
#endif*/ /* NOT_READY_FOR_TESTING_OR_DEPLOYMENT */



#ifndef CANTRCV_CFG_INTCODE_
# define CANTRCV_CFG_INTCODE_

// Some MCALs do not follow the AR 4.2 definition of Spi_SetupEB. The integrator should check the compatibility of the
// used MCAL to ensure that the signature of Spi_SetupEB matches the AR 4.2 definition and, if so, uncomment the below
// macro definition. If not the integrator shall define Spi_RbSetupEB to match the AR 4.2 defintion of Spi_SetupEB.
// This definition is only required if CANTRCV_SPI_EXTERNBUFFER == STD_ON.
#define Spi_RbSetupEB Spi_SetupEB

// timeoutvalue for SPI-Commands. How often is SPI called before giving up
# define CANTRCV_CFG_SPI_RETRIES    1000uL

// define CANTRCV_CFG_STATIC should not be changed
# define CANTRCV_CFG_STATIC static

// adaption to specific SPI commands should be done here
//# define CANTRCV_SPI_TRANSMIT(seq) (Spi_RbTransmit(seq))
//# define CANTRCV_SPI_TRANSMIT(seq) (Spi_AsyncTransmit(seq))
# define CANTRCV_SPI_TRANSMIT(seq) (Spi_SyncTransmit(seq))

// If SPI does not generate the symbolic name of sequence or channel, than the defines can be added here
//# define SPI_SEQUENCE 2
//# define SPI_CHANNEL  2

// adaption to DEM, an EventId of 0 is ignored as it is invalid according to AR 4.2
# define CAN_TRCV_DEM_REPORTERRORSTATUS(EventId, EventStatus) \
do{ \
 if(EventId !=0u)\
 {\
    Dem_ReportErrorStatus(EventId, EventStatus);\
 }\
}while(0)

#endif // CANTRCV_CFG_INTCODE_
