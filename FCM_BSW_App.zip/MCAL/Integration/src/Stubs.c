
#include "Stubs.h"
#include "Std_Types.h"
#include "EcuM.h"
#include "IfxStm_reg.h"
#include "Rte_Const.h"
#include "Rte_Main.h"
#include "Gpt.h"
#include "Dio.h"
#include "Irq.h"
#include "Smu.h"
#include "Os.h"

#include "EyeQProtMgr.h"
#include "ComAdpr.h"
#include "SysPwr.h"

#include "IfxSrc_reg.h"
#include "Icu_17_TimerIp.h"

static void DemoApp_Eru_Init(void);

/******************************************************************************/

/* DEFINITION OF LOCAL MACROS */

#if (RTE_PERIODIC_COUNTER_TICK_INTERVAL_US<100UL)
#error	"The TICK_PERIOD_US assignement need to be reviewed if the SYSTEM tick period goes below 100us"
#else
#define TICK_PERIOD_US		(24950)
#endif

/******************************************************************************/

FUNC(void, OS_CALLOUT_CODE) StartupHook(void)
{
}

/* debugging counter for SystemTick Gpt Notification */
volatile uint32 TOM_notification_cnt;
volatile uint16 TOM_notification_cnt_lmt = 250u;
//volatile Dio_ChannelType Stub_ASWTaskLedChannel = DioConf_DioChannel_LED_D309;
//volatile Dio_ChannelType Stub_BSWTaskLedChannel = DioConf_DioChannel_LED_D302;
volatile uint16 Stub_ASWTaskLedCntLmt = 50u;
volatile uint16 Stub_BSWTaskLedCntLmt = 500u;
static uint16 Stub_ASWTaskLedCnt;
static uint16 Stub_BSWTaskLedCnt;
static Dio_LevelType Stub_ASWTaskLedLevel = STD_OFF;
static Dio_LevelType Stub_BSWTaskLedLevel = STD_OFF;

void Stub_AswTaskLedUpdateTick(void)
{
	if (0u == Stub_ASWTaskLedCnt)
	{
		Stub_ASWTaskLedLevel = (STD_OFF == Stub_ASWTaskLedLevel) ? STD_ON : STD_OFF;
		/* DIO toggle to test the ASW task period (period = DIO period / 2 */
		Dio_WriteChannel(DioConf_DioChannel_LED_D309, Stub_ASWTaskLedLevel);
	}

	Stub_ASWTaskLedCnt = (Stub_ASWTaskLedCnt + 1 >= Stub_ASWTaskLedCntLmt) ? 0u : Stub_ASWTaskLedCnt + 1u;
}

void Stub_BswTaskLedUpdateTick(void)
{
	if (0u == Stub_BSWTaskLedCnt)
	{
		Stub_BSWTaskLedLevel = (STD_OFF == Stub_BSWTaskLedLevel) ? STD_ON : STD_OFF;
		/* DIO toggle to test the ASW task period (period = DIO period / 2 */
		Dio_WriteChannel(DioConf_DioChannel_LED_D302, Stub_BSWTaskLedLevel);
	}

	Stub_BSWTaskLedCnt = (Stub_BSWTaskLedCnt + 1 >= Stub_BSWTaskLedCntLmt) ? 0u : Stub_BSWTaskLedCnt + 1u;
}

void Stub_SetLedFlashTime(uint16 FlashTime)
{
	TOM_notification_cnt_lmt = FlashTime;
}

void Gpt_Cbk_Notification(void)
{
	static Dio_LevelType led_level=STD_OFF;
	static uint16 led_counter = 0;

	TOM_notification_cnt++;
	IncrementCounter(Rte_TickCounter);

	/* wait 50 periods before toggling the LED */
	if(led_counter == 0)
	{
		led_level = (led_level==STD_OFF)?STD_ON:STD_OFF;
		/* DIO toggle to test the system tick period (sys tick period = DIO period / 2 */
		Dio_WriteChannel(DioConf_DioChannel_LED_D306, led_level);
	}

	led_counter = (led_counter + 1 >= TOM_notification_cnt_lmt) ? 0 : led_counter+1;

	/* Timing critical tasks shall be scheduled in non-preemptable timers */
	SysPwr_MainFunction();
}

/**************************************************************/
/* IRQ initialization code example 								  */
/**************************************************************/
void IC_McalIrq_Init ( void )
{
#if (IRQ_CCU6_EXIST == STD_ON)
	IrqCcu6_Init();
#endif/*End of IRQ_CCU6_EXIST*/

#if (IRQ_CAN_EXIST == STD_ON)
	IrqCan_Init();
#endif/*End of IRQ_CAN_EXIST*/

#if (IRQ_GPT12_EXIST == STD_ON)
	IrqGpt_Init();
#endif/*End of IRQ_CCU6_EXIST*/

#if (IRQ_GTM_EXIST == STD_ON)
	IrqGtm_Init();
#endif/*End of IRQ_GTM_EXIST*/

#if (IRQ_GPSRGROUP_EXIST == STD_ON)
	IrqGpsrGroup_Init();
#endif/*End of IRQ_GPSRGROUP_EXIST*/

#if (IRQ_FLEXRAY_EXIST == STD_ON)
	IrqFlexray_Init();
#endif/*End of IRQ_FLEXRAY_EXIST*/

#if (IRQ_QSPI_EXIST == STD_ON)
//	IrqSpi_Init();
#endif/*End of IRQ_QSPI_EXIST*/

#if (IRQ_ASCLIN_EXIST == STD_ON)
	IrqAsclin_Init();
#endif/*End of IRQ_ASCLIN_EXIST*/

#if (IRQ_ADC_EXIST == STD_ON)
	IrqAdc_Init();
#endif/*End of IRQ_ADC_EXIST*/

#if (IRQ_GETH_EXIST == STD_ON)
	IrqEthernet_Init();
#endif/*End of IRQ_GETH_EXIST*/

#if (IRQ_DMA_EXIST == STD_ON)
//	IrqDma_Init();
#endif/*End of IRQ_DMA_EXIST*/

#if (IRQ_SCU_EXIST == STD_ON)
	IrqScu_Init();
#endif/*End of IRQ_SCU_EXIST*/

#if (IRQ_DMU_EXIST == STD_ON)
	IrqDmu_Init();
#endif/*End of IRQ_DMU_EXIST*/

#if (IRQ_HSSL_EXIST == STD_ON)
	IrqHssl_Init();
#endif/*End of IRQ_HSSL_EXIST*/

#if (IRQ_SENT_EXIST == STD_ON)
	IrqSent_Init();
#endif/*End of IRQ_SENT_EXIST*/

#if (IRQ_DSADC_EXIST == STD_ON)
	IrqDsadc_Init();
#endif/*End of IRQ_DSADC_EXIST*/

#if (IRQ_STM_EXIST == STD_ON)
	IrqStm_Init();
#endif/*End of IRQ_STM_EXIST*/

#if (IRQ_I2C_EXIST == STD_ON)
	IrqI2c_Init();
#endif/*End of IRQ_I2C_EXIST*/

	DemoApp_Eru_Init();
}

void IC_RteTimerStart ( void )
{
	(void)Rte_Start();

	Gpt_StartTimer(GptConf_GptChannelConfiguration_GptChannelConfiguration_0,TICK_PERIOD_US);
	Gpt_EnableNotification(GptConf_GptChannelConfiguration_GptChannelConfiguration_0);
}

/**************************************************************/
/* Called during ShutdownOS 								  */
/**************************************************************/
FUNC(void, OS_CALLOUT_CODE)ShutdownHook(StatusType Error)
{
	EcuM_Shutdown();
}

/**************************************************************/
/* implementation of the blank check missing in MCAL		  */
/**************************************************************/
FUNC(AccessType, OS_APPL_CODE) Os_Cbk_CheckMemoryAccess(ApplicationType Application, TaskType TaskID, ISRType ISRID, MemoryStartAddressType Address, MemorySizeType Size) {
    (void)Application;
    (void)TaskID;
    (void)ISRID;
    (void)Address;
    (void)Size;
    return (AccessType)(0U);
}

void Fee_17_IllegalStateNotification(void)
{
	/* Call back shoudl be implemented according to software architecture definition */
	ErrorHook(1);
}

static void DemoApp_Eru_Init(void)
{
      /* Set SCUERU0 Interrupt Priority */
//      IrqScu_Init();     
   /* IrqScu_Init(); */
	/* Enable Service Request */
   //SRC_CCU61SR0.B.SRE = 1u;
   SRC_SCUERU0.B.SRE = 1u;
   //SRC_CCU61SR1.B.SRE = 1u;
   SRC_SCUERU1.B.SRE = 1u;
   //SRC_CCU61SR2.B.SRE = 1u;
   SRC_SCUERU2.B.SRE = 1u;
   //SRC_CCU61SR3.B.SRE = 1u;
   SRC_SCUERU3.B.SRE = 1u;
   
   /* Initialize ICU configuration */
   Icu_17_TimerIp_Init(&Icu_17_TimerIp_Config);
   
   /* Initialize ERU registers for trigger Events */
   Icu_17_TimerIp_EnableNotification(IcuConf_IcuChannel_Icu_Eru_CoreDump);
   Icu_17_TimerIp_EnableNotification(IcuConf_IcuChannel_Icu_Eru_TimeSync);
   Icu_17_TimerIp_EnableNotification(IcuConf_IcuChannel_Icu_Eru_ErrOut);
   Icu_17_TimerIp_EnableNotification(IcuConf_IcuChannel_Icu_Eru_HighTemp);
   Icu_17_TimerIp_EnableNotification(IcuConf_IcuChannel_Icu_Eru_BistFail);
}
