/*
 *
 * 	Clock initializzation Funcntion
 *
 *
 */

#include "McuFunc.h"
#include "Mcu.h"

void McuFunc_InitializeClock(void)
{
	/* Initialize MCU Clock*/
	/* parameter 0 is chosen here by default, the first clock configuration */
	Mcu_InitClock(0);
	/* wait till PLL lock */
	while(Mcu_GetPllStatus() != MCU_PLL_LOCKED);
	/* distribute the clock */
	Mcu_DistributePllClock();
}
