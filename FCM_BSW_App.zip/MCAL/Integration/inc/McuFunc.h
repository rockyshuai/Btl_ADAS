#ifndef  _MCUFUNC_H
#define  _MCUFUNC_H

extern void McuFunc_InitializeClock(void);

#endif /* _MCUFUNC_H */
