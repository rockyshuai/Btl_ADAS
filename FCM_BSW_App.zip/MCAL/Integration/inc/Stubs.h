#ifndef  _STUBS_H
#define  _STUBS_H


/************************************************************/

#include "Fee.h"
#include "Fls.h"
#include "rba_FeeFs1_Prv.h"

extern void IC_McalIrq_Init ( void );

extern void IC_RteTimerStart ( void );

extern void Gpt_Cbk_Notification(void);

extern void Stub_AswTaskLedUpdateTick(void);
extern void Stub_BswTaskLedUpdateTick(void);

#endif /* _STUBS_H */
