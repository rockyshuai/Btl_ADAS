/*
 * Wdg.h
 *
 *  Created on: Aug 14, 2016
 *      Author: VHG1HC
 */

#ifndef WDG_H_
#define WDG_H_

#define Wdg_17_Scu_Config                         Wdg_17_Scu_Config_0

#endif /* WDG_H_ */
