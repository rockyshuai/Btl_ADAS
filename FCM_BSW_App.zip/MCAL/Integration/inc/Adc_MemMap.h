/* ********************************************************************************************************************
 *
 * COPYRIGHT RESERVED, 2015 Robert Bosch GmbH. All rights reserved.
 * The reproduction, distribution and utilization of this document as well as the communication of its contents to
 * others without explicit authorization is prohibited. Offenders will be held liable for the payment of damages.
 * All rights reserved in the event of the grant of a patent, utility model or design.
 *
 ******************************************************************************************************************* */

/* ********************************************************************************************************************
 * ADMINISTRATIVE INFORMATION
 * $Domain____:$
 * $Namespace_:\Comp\Adc$
 * $Class_____:$
 * $Name______:Adc Driver$
 * $Variant___:AR40.2.5.0$
 * $Revision__:0$
 * $Author____:BOSCH$
 ******************************************************************************************************************* */

/****************************************************************************
 *                                 ETAS GmbH
 *                      D-70469 Stuttgart, Borsigstr. 14
 *****************************************************************************
 * Project : ADC Driver
 * Component : Adc
 * Date : Mon June 27 2016
 * Version : 1.0
 * Description : RTA-BASE first revision
 ****************************************************************************/


#if defined ADC_START_SEC_CODE
/* MISRA RULE 19.15 VIOLATION: MemMap header concept - no protection against repeated inclusion intended */
    #undef ADC_START_SEC_CODE
    #define  BSW_START_SEC_DEFAULT_CODE
    #include "Bsw_MemMap.h"
#elif defined ADC_STOP_SEC_CODE
    #undef ADC_STOP_SEC_CODE
    #define  BSW_STOP_SEC_DEFAULT_CODE
    #include "Bsw_MemMap.h"



/*********************************************************************************************************************/
// #else
 //   #error "Adc_MemMap.h: unknown MemMap define "
#endif

