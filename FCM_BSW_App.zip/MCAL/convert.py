import re
import sys


def main():
    arguments = len(sys.argv) - 1

    if arguments != 2:
        print("Error in input parameters.\nUsage: convert.py infile outfile")
        sys.exit(-1)

    infilename = sys.argv[1]
    outfilename = sys.argv[2]

    with open(infilename,'r') as infile, open(outfilename,'w') as outfile:
        outfile.write(re.sub('/AUTOSAR_Can/EcucModuleDefs/','/AURIX2G/EcucDefs/',infile.read()))

if __name__ == "__main__":
    main()